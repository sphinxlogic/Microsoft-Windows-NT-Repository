/*****************************************************************************
/*
                                 Support.c

Miscellaneous support functions for HTTPd.


VERSION HISTORY
---------------
17-JAN-2000  MGD  bugfix; HttpHeaderChallenge()
23-DEC-2000  MGD  GenerateUniqueId() substitute '@' for '_',
                  remove non-DECC strftime() kludge (VAXC no longer supported!)
01-OCT-2000  MGD  move privilege functions here
27-AUG-2000  MGD  add !SL to WriteFormatted()
09-AUG-2000  MGD  bugfix; ParseQueryField() string length check
11-JUN-2000  MGD  add ParseNetMask()
08-APR-2000  MGD  add GenerateUniqueId() based on Apache implementation
04-MAR-2000  MGD  add WriteFormatted() and it's siblings
                  WriteFao(), WriteFaol(), WriteFaoNet(),
                  remove CopyTohtml(), UrlEncodeString(),
                  improved SearchTextString()
01-JAN-2000  MGD  support ODS-2 and ODS-5,
                  add formatted OPCOM messages
15-OCT-1999  MGD  use common 'HttpdProcessId'
28-AUG-1999  MGD  add strzcpy(), GetVmsVersion()
25-MAY-1999  MGD  reverse the order of the digest and basic challenges
                  (MS IE5 will not authenticate if digest comes first!!)
31-MAR-1999  MGD  bugfix; HttpHeaderChallenge() 'AuthRealmPtr' NULL check
18-JAN-1999  MGD  FaoPrint() and WriteFaoStdout() for sys$fao()
                  variable-argument string printing,
                  provide proxy accounting logical and zeroing
01-OCT-1998  MGD  HttpHeader() "Content-Type: text/...; charset=...",
                  support SET mapping rules for charset and content-type,
                  UrlEncodeString(),
                  bugfix; NameOfDirectoryFile()
10-AUG-1998  MGD  refined CopyToHtml() slightly,
                  bugfix; TimeSetTimezone() unsigned to signed longs
10-JUL-1998  MGD  a little Y2K insurance
21-JUN-1998  MGD  changed format of request logical
02-APR-1998  MGD  after email about non-conforming date formats back to RFC1123
12-MAR-1998  MGD  added FormatProtection()
08-JAN-1997  MGD  TimeSetGmt() now can use SYS$TIMEZONE_DIFFERENTIAL
05-OCT-1997  MGD  additional list processing functions
28-SEP-1997  MGD  accounting structure has grown beyond 255 bytes
09-AUG-1997  MGD  message database, added SearchTextString() and
                  NameOfDirectoryFile() functions
12-JUL-1997  MGD  EnableSysPrv(), DisableSysPrv()
07-JUL-1997  MGD  attempt to reduce dynamic memory fragmentation within C RTL
                  using HEAP_MIN_CHUNK_SIZE functionality,
                   prevent request logical redefinition if keep-alive timeout 
16-JUN-1997  MGD  generic linked list functions
12-MAR-1997  MGD  HTTP header generation
01-FEB-1997  MGD  HTTPd version 4
01-OCT-1996  MGD  report menu
18-JUN-1996  MGD  bugfix; HTTPD$GMT conversion to VMS delta time TimeSetGmt()
06-APR-1996  MGD  persistent connections ("keep-alive")
01-DEC-1995  MGD  HTTPd version 3.0
27-SEP-1995  MGD  provide GMT functions
20-DEC-1994  MGD  initial development
*/
/*****************************************************************************/

/* standard C header files */
#include <ctype.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

/* VMS related header files */
#include <descrip.h>
#include <jpidef.h>
#include <libdef.h>
#include <libdtdef.h>
#include <lnmdef.h>
#include <opcdef.h>
#include <prvdef.h>
#include <psldef.h>
#include <rms.h>
#include <ssdef.h>
#include <stsdef.h>
#include <syidef.h>

/* application related header files */
#include "wasd.h"

#define WASD_MODULE "SUPPORT"

/******************/
/* global storage */
/******************/

#define RFC_1123_DATE yup

boolean  OdsExtended,
         TimeAheadOfGmt;

int  OpcomMessages,
     OpcomTarget;

unsigned long  TimeGmtDeltaBinary [2];

char  TimeGmtString [48],
      TimeGmtVmsString [50];

char  HttpProtocol [] = "HTTP/1.0";

char  *DayName [] =
   { "", "Monday", "Tuesday", "Wednesday",
     "Thursday", "Friday", "Saturday", "Sunday" };

char  *MonthName [] =
   { "", "January", "February", "March", "April", "May", "June",
         "July", "August", "September", "October", "November", "December" };

/********************/
/* external storage */
/********************/

#ifdef DBUG
extern boolean Debug;
#else
#define Debug 0 
#endif

extern boolean  AccountingZeroOnStartup,
                AuthPromiscuous,
                MonitorEnabled,
                ProxyServingEnabled,
                ProxyCacheFreeSpaceAvailable;

extern int ServerPort;
extern unsigned long  HttpdProcessId;
extern unsigned long  SysPrvMask[];

extern char  ErrorSanityCheck[],
             ProcessName[],
             ServerHostName[],
             SoftwareID[];

extern struct AccountingStruct Accounting;
extern struct ConfigStruct  Config;
extern struct MsgStruct  Msgs;
extern struct ProxyAccountingStruct  ProxyAccounting;

/*****************************************************************************/
/*
Declare an AST, exit if there is any problem ... must have out ASTs!
*/ 

void SysDclAst
(
void *Address,
unsigned long Parameter
)
{
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "SysDclAst()\n");

   if (VMSok (status = sys$dclast (Address,Parameter, 0))) return;
   ErrorExitVmsStatus (status, "sys$dclast()", FI_LI);
}

/*****************************************************************************/
/*
If we can't get SYSPRV when we need it, or more importantly, if we can't turn
it off when we're finished with it the exit the server!
*/ 

EnableSysPrv ()

{
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "EnableSysPrv()\n");

#if OPERATE_WITH_SYSPRV
   if (OperateWithSysPrv) return;
#endif

   if (VMSok (status = sys$setprv (1, &SysPrvMask, 0, 0))) return;
   ErrorExitVmsStatus (status, "sys$setprv()", FI_LI);
}

/*****************************************************************************/
/*
If we can't get SYSPRV when we need it, or more importantly, if we can't turn
it off when we're finished with it the exit the server!
*/ 

DisableSysPrv ()

{
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "DisableSysPrv()\n");

#if OPERATE_WITH_SYSPRV
   if (OperateWithSysPrv) return;
#endif

   if (VMSok (status = sys$setprv (0, &SysPrvMask, 0, 0))) return;
   ErrorExitVmsStatus (status, "sys$setprv()", FI_LI);
}

/*****************************************************************************/
/*
Generic list handling function.  Add entry to head of list.
*/ 

void* ListAddHead
(
register struct ListHeadStruct *lptr,
register struct ListEntryStruct *eptr
)
{
   /*********/
   /* begin */
   /*********/

   if (Debug)
   {
      fprintf (stdout, "ListAddHead() %d %d\n", lptr, eptr);
      ListDebug (lptr);
   }

   if (lptr->HeadPtr == NULL)
   {
      /* empty list */
      lptr->HeadPtr = lptr->TailPtr = eptr;
      eptr->PrevPtr = eptr->NextPtr = NULL;
      lptr->EntryCount++;
      if (Debug) ListDebug (lptr);
      return (eptr);
   }
   else
   {
      /* non-empty list */
      eptr->PrevPtr = NULL;
      eptr->NextPtr = lptr->HeadPtr;
      eptr->NextPtr->PrevPtr = lptr->HeadPtr = eptr;
      lptr->EntryCount++;
      if (Debug) ListDebug (lptr);
      return (eptr);
   }
}

/*****************************************************************************/
/*
Generic list handling function.  Add entry to tail of list.
*/ 

void* ListAddTail
(
register struct ListHeadStruct *lptr,
register struct ListEntryStruct *eptr
)
{
   /*********/
   /* begin */
   /*********/

   if (Debug)
   {
      fprintf (stdout, "ListAddTail() %d %d\n", lptr, eptr);
      ListDebug (lptr);
   }

   if (lptr->HeadPtr == NULL)
   {
      /* empty list */
      lptr->HeadPtr = lptr->TailPtr = eptr;
      eptr->PrevPtr = eptr->NextPtr = NULL;
      lptr->EntryCount++;
      if (Debug) ListDebug (lptr);
      return (eptr);
   }
   else
   {
      /* non-empty list */
      eptr->NextPtr = NULL;
      eptr->PrevPtr = lptr->TailPtr;
      eptr->PrevPtr->NextPtr = lptr->TailPtr = eptr;
      lptr->EntryCount++;
      if (Debug) ListDebug (lptr);
      return (eptr);
   }
}

/*****************************************************************************/
/*
Generic list handling function.  Add entry 2 "in front of" entry 1.
*/ 

void* ListAddBefore
(
register struct ListHeadStruct *lptr,
register struct ListEntryStruct *e1ptr,
register struct ListEntryStruct *e2ptr
)
{
   /*********/
   /* begin */
   /*********/

   if (Debug)
   {
      fprintf (stdout, "ListAddBefore() %d %d %d\n", lptr, e1ptr, e2ptr);
      ListDebug (lptr);
   }

   if (lptr->HeadPtr == e1ptr)
   {
      /* at head of list */
      e1ptr->PrevPtr = e2ptr;
      e2ptr->PrevPtr = NULL;
      e2ptr->NextPtr = e1ptr;
      lptr->HeadPtr = e2ptr;
      return (e2ptr);
   }
   else
   {
      /* not at head of list */
      if (e1ptr->PrevPtr != NULL)
      {
         e2ptr->PrevPtr = e1ptr->PrevPtr;
         e2ptr->PrevPtr->NextPtr = e2ptr;
      }
      e1ptr->PrevPtr = e2ptr;
      e2ptr->NextPtr = e1ptr;
      return (e2ptr);
   }

   if (Debug) ListDebug (lptr);
}

/*****************************************************************************/
/*
Generic list handling function.  Remove entry from list.  Check first that
entry looks legitimate, return NULL if not!
*/ 

void* ListRemove
(
register struct ListHeadStruct *lptr,
register struct ListEntryStruct *eptr
)
{
   /*********/
   /* begin */
   /*********/

   if (Debug)
   {
      fprintf (stdout, "ListRemove() %d %d\n", lptr, eptr);
      ListDebug (lptr);
   }

   if (eptr->PrevPtr == NULL)
   {                                                                        
      /* at head of list */
      if (eptr->NextPtr == NULL)
      {
         /* only entry in list */
         if (lptr->HeadPtr != eptr || lptr->TailPtr != eptr) return (NULL);
         lptr->HeadPtr = lptr->TailPtr = NULL;
         if (lptr->EntryCount) lptr->EntryCount--;
         if (Debug) ListDebug (lptr);
         return (eptr);
      }
      else
      {
         /* remove from head of list */
         if (lptr->HeadPtr != eptr) return (NULL);
         eptr->NextPtr->PrevPtr = NULL;
         lptr->HeadPtr = eptr->NextPtr;
         if (lptr->EntryCount) lptr->EntryCount--;
         if (Debug) ListDebug (lptr);
         return (eptr);
      }
   }
   else
   {
      /* not at head of list */
      if (eptr->NextPtr == NULL)
      {
         /* at tail of list */
         if (lptr->TailPtr != eptr) return (NULL);
         eptr->PrevPtr->NextPtr = NULL;
         lptr->TailPtr = eptr->PrevPtr;
         if (lptr->EntryCount) lptr->EntryCount--;
         if (Debug) ListDebug (lptr);
         return (eptr);
      }
      else
      {
         /* somewhere in the middle! */
         if (eptr->PrevPtr->NextPtr != eptr ||
             eptr->NextPtr->PrevPtr != eptr) return (NULL);
         eptr->PrevPtr->NextPtr = eptr->NextPtr;
         eptr->NextPtr->PrevPtr = eptr->PrevPtr;
         if (lptr->EntryCount) lptr->EntryCount--;
         if (Debug) ListDebug (lptr);
         return (eptr);
      }
   }
}

/*****************************************************************************/
/*
Generic list handling function.  If not already there move it to the head.
*/ 

#ifdef __DECC
#pragma inline(ListMoveHead)
#endif

void* ListMoveHead
(
struct ListHeadStruct *lptr,
struct ListEntryStruct *eptr
)
{
   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "ListMoveHead() %d %d %d\n",
               lptr, lptr->HeadPtr, eptr);

   /* move entry to the head of the cache list */
   if (lptr->HeadPtr != eptr)
   {
      ListRemove (lptr, eptr);
      ListAddHead (lptr, eptr);
   }

   return (eptr);
}

/*****************************************************************************/
/*
Generic list handling function.  If not already there move it to the tail.
*/ 

#ifdef __DECC
#pragma inline(ListMoveTail)
#endif

void* ListMoveTail
(
struct ListHeadStruct *lptr,
struct ListEntryStruct *eptr
)
{
   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "ListMoveTail() %d %d %d\n",
               lptr, lptr->HeadPtr, eptr);

   /* move entry to the head of the cache list */
   if (lptr->TailPtr != eptr)
   {
      ListRemove (lptr, eptr);
      ListAddTail (lptr, eptr);
   }

   return (eptr);
}

/*****************************************************************************/
/*
Generic list handling function.  Check if a specific entry is in specific list.
*/ 

void* ListCheck
(
register struct ListHeadStruct *lptr,
register struct ListEntryStruct *eptr
)
{
   register struct ListEntryStruct  *teptr;

   /*********/
   /* begin */
   /*********/

   fprintf (stdout, "ListCheck() %d %d %d %d\n",
            lptr, lptr->HeadPtr, lptr->TailPtr, lptr->EntryCount);

   for (teptr = lptr->HeadPtr; teptr != NULL; teptr = teptr->NextPtr)
      if (teptr == eptr) return (eptr);
   return (NULL);
}

/*****************************************************************************/
/*
list the entries in the list.
*/ 

ListDebug (register struct ListHeadStruct* lptr)

{
   register struct ListEntryStruct  *eptr;

   /*********/
   /* begin */
   /*********/

   fprintf (stdout, "ListDebug() %d %d %d %d\n",
            lptr, lptr->HeadPtr, lptr->TailPtr, lptr->EntryCount);

   for (eptr = lptr->HeadPtr; eptr != NULL; eptr = eptr->NextPtr)
      fprintf (stdout, "%d <- %d -> %d\n", eptr->PrevPtr, eptr, eptr->NextPtr);
}

/*****************************************************************************/
/*
This is a variable-argument wrapper for WriteFormatted(), see that for greater
detail.  This function just gets all the arguments from the call stack and puts
them into a longword vector that WriteFormatted() can use.  'LengthPtr'
provides storage for returning the length of the generated string.  The
resultant string is always null-terminated (unless an error), hence the
'BufferSize' can always only store 'BufferSize'-1 characters.  'LengthPtr'
provides storage for the number of characters minus the null-termination.
*/

int WriteFao
(
char *BufferPtr,
int BufferSize,
unsigned short *LengthPtr,
char *FormatString,
...
)
{
   int  status,
        argcnt;
   unsigned long  *vecptr;
   unsigned long  FaoVector [128];
   va_list  argptr;

   /*********/
   /* begin */
   /*********/

   va_count (argcnt);

   if (Debug) fprintf (stdout, "WriteFao() %d\n", argcnt);

   if (argcnt > 128+4) return (SS$_OVRMAXARG);

   vecptr = FaoVector;
   va_start (argptr, FormatString);
   for (argcnt -= 4; argcnt; argcnt--)
      *vecptr++ = va_arg (argptr, unsigned long);
   va_end (argptr);

   status = WriteFormatted (NULL, BufferPtr, BufferSize, LengthPtr,
                            FormatString, &FaoVector);
   if (Debug) fprintf (stdout, "WriteFormatted() %%X%08.08X\n", status);
   return (status);
}

/****************************************************************************/
/*
WriteFaol()-formatted print statement.  A fixed-size, internal buffer is used
and the result output to the <stdout> stream.
*/

int WriteFaoStdout
(
char *FormatString,
...
)
{
   int  status,
        argcnt;
   unsigned short  Length;
   unsigned long  *vecptr;
   unsigned long  FaoVector [128];
   char  Buffer [2048];
   va_list  argptr;

   /*********/
   /* begin */
   /*********/

   va_count (argcnt);

   if (Debug)
      fprintf (stdout, "WriteFaoStdout() |%s| %d\n", FormatString, argcnt);

   if (argcnt > 128+1) return (SS$_OVRMAXARG);

   vecptr = FaoVector;
   va_start (argptr, FormatString);
   for (argcnt -= 1; argcnt; argcnt--)
      *vecptr++ = va_arg (argptr, unsigned long);
   va_end (argptr);

   status = WriteFaol (Buffer, sizeof(Buffer), &Length,
                       FormatString, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "WriteFaol()", FI_LI);

   fputs (Buffer, stdout);

   return (status);
}

/****************************************************************************/
/*
WriteFaol()-formatted print statement.  A fixed-size, internal buffer of 986
bytes maximum is used and the result output as an OPCOM message.
*/

int WriteFaoOpcom
(
char *FormatString,
...
)
{
   static $DESCRIPTOR (OpcomDsc, "");

   int  status,
        argcnt;
   unsigned short  Length;
   unsigned long  *vecptr;
   unsigned long  FaoVector [128+2];
   va_list  argptr;
   struct
   {
      unsigned long  TargetType;
      unsigned long  RequestId;
      char  MsgText [986+1];
   } OpcomMsg;

   /*********/
   /* begin */
   /*********/

   va_count (argcnt);

   if (Debug)
      fprintf (stdout, "WriteFaoOpcom() |%s| %d\n", FormatString, argcnt);

   if (argcnt > 128+1) return (SS$_OVRMAXARG);

   vecptr = FaoVector;
   *vecptr++ = ProcessName;
   *vecptr++ = FormatString;
   va_start (argptr, FormatString);
   for (argcnt -= 1; argcnt; argcnt--)
      *vecptr++ = va_arg (argptr, unsigned long);
   va_end (argptr);

   status = WriteFaol (OpcomMsg.MsgText, sizeof(OpcomMsg.MsgText), &Length,
                       "Process !AZ reports\r\n!%%", &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "WriteFaol()", FI_LI);

   if (Debug) fprintf (stdout, "%d |%s|\n", Length, OpcomMsg.MsgText);

   OpcomMsg.TargetType = OPC$_RQ_RQST + ((OpcomTarget & 0xffffff) << 8);
   OpcomMsg.RequestId = 0;

   OpcomDsc.dsc$a_pointer = &OpcomMsg;
   OpcomDsc.dsc$w_length = Length + 8;

   status = sys$sndopr (&OpcomDsc, 0);
   if (Debug) fprintf (stdout, "sys$sndopr() %%X%08.08X\n", status);

   return (status);
}

/*****************************************************************************/
/*
This is a variable-argument wrapper for WriteFormatted(), see that for greater
detail.  This function just gets all the arguments from the call stack and puts
them into a longword vector that WriteFormatted() can use.

This function has a #define in NET.H making it available as NetWriteFao().
*/

int WriteFaoNet
(
struct RequestStruct *rqptr,
char *FormatString,
...
)
{
   int  status,
        argcnt;
   unsigned long  *vecptr;
   unsigned long  FaoVector [128];
   va_list  argptr;

   /*********/
   /* begin */
   /*********/

   va_count (argcnt);

   if (Debug) fprintf (stdout, "WriteFaoNet() %d\n", argcnt);

   if (argcnt > 128+2) return (SS$_OVRMAXARG);

   vecptr = FaoVector;
   va_start (argptr, FormatString);
   for (argcnt -= 2; argcnt; argcnt--)
      *vecptr++ = va_arg (argptr, unsigned long);
   va_end (argptr);

   status = WriteFormatted (rqptr, NULL, 0, NULL, FormatString, &FaoVector);
   if (Debug) fprintf (stdout, "WriteFormatted() %%X%08.08X\n", status);
   return (status);
}

/*****************************************************************************/
/*
Formatted write using sys$faol()-like directives, just a functional subset, it
also differs in some significant ways, including extended functionality.  The
function can write into either specified storage or into the request's output
buffer (probably more efficient that sys$fao()ing into storage then copying
this to the network buffer).  With the advent of ODS-5, and extended file
specifications it becomes possible for file names to contain HTML and URL
forbidden characters.  A simple method for effectively escaping and encoding
these was required, hence the !HZ and !UZ (etc.) directives.  All parameters
are passed via a sys$faol()-like pointer-to-longword-vector.  Strings are
always assumed to be null-terminated.

A resultant string is always null-terminated (even after an error), hence the
'BufferSize' can always only store 'BufferSize'-1 characters.  'LengthPtr'
provides storage for the number of characters minus the null-termination.

Directives Supported
~~~~~~~~~~~~~~~~~~~~
!AC    counted ASCII string (first byte must be count, i.e. 0 to 255 chars)
!AZ    string
!HZ    string, add HTML-escaped
!UZ    string, add URL-encoded
!A5    ODS-5 file specification, (un-escapes ODS-5, i.e. "^_" into " ") 
!AF    file specification, (un-escapes ODS-5 characters, i.e. "^_" into " ") 
!AV    VMS-style specification, (un-escapes ODS-5 chars, i.e. "^_" into " ") 
!H5    ODS-5 file specification, add HTML-escaped
!HF    file specification, add HTML-escaped
!HV    VMS-style specification, add HTML-escaped
!SL    decimal, signed longword
!SQ    signed quadword
!U5    ODS-5 file specification, add URL-encoded 
!UF    file specification, add URL-encoded 
!UV    VMS-style specification, add URL-encoded
!UL    decimal, unsigned longword
!XL    hexadecimal, longword
!ZL    zero-filled decimal, unsigned longword
!%D    date/time
!%M    full status message string (returned from sys$getmsg())
!%m    text-only status message string (returned from sys$getmsg())
!%S    if the last converted numeric value was not 1 add "S"
!%s    if the last converted numeric value was not 1 add "s"
!%T    time
!%W    weekday/date/time (field-width applies to date/time component only)
!%?    simple conditional, "!%?string if *vector TRUE\rstring if FALSE\r"
!%%    nested format string address from vector (FILO stacks the current one)
!+     step-over the next parameter from the vector (anything BUT a "!%%")
!-     back-up to the previous parameter in the vector (anything BUT a "!%%")
!<     begin specified width output field (cannot nest, must have width!)
!>     end specified width output field
!!     exclamation mark

Each directive can have a positive, decimal integer between the '!' and the
directive providing a field width, e.g. "!10HZ", or have the field width taken
from the vector using "!#HZ".  These behave in the same manner as the sys$fao()
field width parameter. 

Any directive may use the indirect character (unlike sys$fao(), where only
numeric directives may).  This indicates the vector value is the 32 bit address
of the value, rather than the value itself, e.g. "!@AZ", "!10@UL", etc.

Any numeric directive may have a comma immediately following the '!'.  This
causes a number in excess of 3 digits to have commas inserted, e.g. "!,UL",
"!,10UL".  Caution - this can truncate to the right on field-width constrained
fields.

The 'xF' and 'xV' family of directives specially process file names.  The rules
are these.  If extended file specifications apply to the architecture and they
are enabled for processing (i.e. at least one is mapped), then the string
supplied is checked for ODS-2 compliance (i.e. "A-Z", "0-9", "_", "-", ".",
"$", "/", "~", ":", "[", "]") and if any character outside of these is present
it is considered an extended file name.

For an 'xF' directive an ODS-2 compliant string is always forced to lower-case,
extended-compliant strings are left as-is (note that all upper-case ODS-5 names
are also forced lower case using this algorithm).  For an 'xV' directive the
case is left unchanged.  Extended-compliant strings have '^' escape sequences
converted to the equivalent un-escaped character.  To render these as-are a
'!HZ' directive should be used.

This function has a #define in NET.H making it available as NetWriteFaol(), and
a #define in SUPPORT.H making it available as WriteFaol().
*/ 

int WriteFormatted
(
struct RequestStruct *rqptr,
char *BufferPtr,
int BufferSize,
unsigned short *LengthPtr,
char *FormatString,
unsigned long *VectorPtr
)
{
#define FORMAT_STACK_MAX 8

   static char  HexDigits [] = "0123456789abcdef";
   static char  EncBuffer [] = "%xx";
   static $DESCRIPTOR (SLFaoDsc, "!SL\0");
   static $DESCRIPTOR (SLWidthFaoDsc, "!#SL\0");
   static $DESCRIPTOR (ULFaoDsc, "!UL\0");
   static $DESCRIPTOR (ULWidthFaoDsc, "!#UL\0");
   static $DESCRIPTOR (XLFaoDsc, "!XL\0");
   static $DESCRIPTOR (XLWidthFaoDsc, "!#XL\0");
   static $DESCRIPTOR (ZLFaoDsc, "!ZL\0");
   static $DESCRIPTOR (ZLWidthFaoDsc, "!#ZL\0");
   static $DESCRIPTOR (SQFaoDsc, "!@SQ\0");
   static $DESCRIPTOR (SQWidthFaoDsc, "!#@SQ\0");
   static $DESCRIPTOR (PDFaoDsc, "!%D\0");
   static $DESCRIPTOR (PTFaoDsc, "!%T\0");
   static $DESCRIPTOR (DayDateTimeFaoDsc, "!AZ, !#%D\0");

   static char  String [256];
   static $DESCRIPTOR (StringDsc, String);

   register int  ch, bcnt, brcnt, fw, ofw, idx;
   register char  *bptr, *cptr, *fptr, *sptr;

   boolean  CommaNumber,
            HtmlEscaped,
            IndirectValue,
            PathOdsExtended,
            UrlEncoded,
            VmsFormat;
   int  status,
        CommaCount,
        LastNumericValue, 
        PrevBcnt,
        SysGetMsgFlags;
   unsigned short  Length;
   unsigned long  DayOfWeek,
                  VectorValue;
   unsigned long  BinTime [2];
   unsigned long  *BinTimePtr;
   char  *LastFptr;
   char  *FormatStack [FORMAT_STACK_MAX];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "WriteFormatted() |%s|\n", FormatString);

   status = SS$_NORMAL;
   LastNumericValue = 1; 
   /* start with output-field-width set to infinite */
   ofw = -1;

   if (LengthPtr != NULL) *LengthPtr = 0;

   if (BufferPtr == NULL)
   {
      /* first call, initialize a buffer */
      if (rqptr->rqOutput.BufferStructPtr == NULL)
         NetWriteBufferedInit (rqptr, true);

      bptr = rqptr->rqOutput.BufferCurrentPtr;
      bcnt = PrevBcnt = rqptr->rqOutput.BufferCount;
      brcnt = rqptr->rqOutput.BufferRemaining;
   }
   else
   {
      /* writing to specified storage */
      if (!(brcnt = BufferSize)) return (SS$_BADPARAM);
      bptr = BufferPtr;
      bcnt = PrevBcnt = 0;
   }

   /* put initial format string into index zero of the format string stack */
   idx = 0;
   FormatStack[idx] = FormatString;

   /*************************/
   /* nested format strings */
   /*************************/

   for (;;)
   {
      /*****************/
      /* format string */
      /*****************/

      fptr = FormatStack[idx];
      while (*fptr)
      {
         while (*fptr && *fptr != '!' && ofw)
         {
            /* a literal character */
            if (brcnt--)
            {
               *bptr++ = *fptr++;
               bcnt++; 
               ofw--;
               continue;
            }
            /* if writing to storage then it's overflowed */
            if (BufferPtr != NULL)
            {
               BufferPtr[BufferSize-1] = '\0';
               return (SS$_BUFFEROVF);
            }
            /* need another network buffer */
            NetWriteBufferedInit (rqptr, false);
            bptr = rqptr->rqOutput.BufferCurrentPtr;
            brcnt = rqptr->rqOutput.BufferRemaining;
         }
         /* if end of literal characters (i.e. not a '!') then break */
         if (!*fptr) break;

         /* if no character follows the '!' then just forget it */
         LastFptr = fptr;
         if (!*++fptr) break;

         /*********************/
         /* format directives */
         /*********************/

         /** if (Debug) fprintf (stdout, "fptr |%10.10s|\n", fptr); **/

         if (*fptr == ',')
         {
            fptr++;
            CommaNumber = true;
         }
         else
            CommaNumber = false;

         if (isdigit(*fptr))
         {
            /* field-width */
            fw = atoi(fptr);
            while (isdigit(*fptr)) fptr++;
            /* for writes into network buffers, let's keep this < 1024 */
            if (BufferPtr == NULL) fw &= 0xfff;
         }
         else
         if (*fptr == '#')
         {
            /* field-width from vector */
            fptr++;
            fw = (int)*VectorPtr++;
            /* for writes into network buffers, let's keep this < 1024 */
            if (BufferPtr == NULL) fw &= 0xfff;
         }
         else
            fw = -1;
         /** if (Debug) fprintf (stdout, "fw: %d\n", fw); **/

         if (*fptr == '@')
         {
            fptr++;
            IndirectValue = true;
         }
         else
            IndirectValue = false;

         /* default is no string to copy if it drops through */
         sptr = NULL;
         /* used in file name formatting directives */
         HtmlEscaped = PathOdsExtended = UrlEncoded = VmsFormat = false;

         /* directives in guessed order of most common usage */
         if (*(unsigned short*)fptr == 'AZ')
         {
            /**************************/
            /* null-terminated string */
            /**************************/

            fptr += 2;
            if (IndirectValue)
            {
               if (!*VectorPtr)
               {
                  status = SS$_ACCVIO;
                  break;
               }
               sptr = *(char*)*VectorPtr++;
            }
            else
               sptr = (char*)*VectorPtr++;
            if (!sptr)
            {
               status = SS$_ACCVIO;
               break;
            }
            if (Debug) fprintf (stdout, "!AZ |%s|\n", sptr);
            /* drop through to buffer the string pointed to by 'sptr' */
         }
         else
         if (*(unsigned short*)fptr == 'HZ')
         {
            /****************************************/
            /* null-terminated, HTML-escaped string */
            /****************************************/

            fptr += 2;
            if (IndirectValue)
            {
               if (!*VectorPtr)
               {
                  status = SS$_ACCVIO;
                  break;
               }
               cptr = *(char*)*VectorPtr++;
            }
            else
               cptr = (char*)*VectorPtr++;
            if (!cptr)
            {
               status = SS$_ACCVIO;
               break;
            }
            if (Debug) fprintf (stdout, "!HZ |%s|\n", cptr);

            while (*cptr && fw && ofw)
            {
               fw--;
               ofw--;
               switch (ch = *cptr++)
               {
                  case '<' :
                     sptr = "&lt;";
                     break;
                  case '>' :
                     sptr = "&gt;";
                     break;
                  case '&' :
                     sptr = "&amp;";
                     break;
                  case '\"' :
                     sptr = "&quot;";
                     break;
                  default :
                     /* insert this character as-is */
                     if (!brcnt)
                     {
                        /* if writing to storage then it's overflowed */
                        if (BufferPtr != NULL)
                        {
                           BufferPtr[BufferSize-1] = '\0';
                           return (SS$_BUFFEROVF);
                        }
                        /* need another network buffer */
                        NetWriteBufferedInit (rqptr, false);
                        bptr = rqptr->rqOutput.BufferCurrentPtr;
                        brcnt = rqptr->rqOutput.BufferRemaining;
                     }
                     *bptr++ = ch;
                     bcnt++; 
                     brcnt--;
                     continue;
               }

               /* add the escaped character */
               while (*sptr)
               {
                  if (brcnt--)
                  {
                     *bptr++ = *sptr++;
                     bcnt++; 
                     continue;
                  }
                  /* if writing to storage then it's overflowed */
                  if (BufferPtr != NULL)
                  {
                     BufferPtr[BufferSize-1] = '\0';
                     return (SS$_BUFFEROVF);
                  }
                  /* need another network buffer */
                  NetWriteBufferedInit (rqptr, false);
                  bptr = rqptr->rqOutput.BufferCurrentPtr;
                  brcnt = rqptr->rqOutput.BufferRemaining;
               }
            }
            /* only if required drop through to space-fill */
            if (fw <= 0) continue;
            /* no string to copy  */
            sptr = NULL;
         }
         else
         if (*(unsigned short*)fptr == 'UZ')
         {
            /***************************************/
            /* null-terminated, URL-encoded string */
            /***************************************/

            fptr += 2;
            if (IndirectValue)
            {
               if (!*VectorPtr)
               {
                  status = SS$_ACCVIO;
                  break;
               }
               cptr = *(char*)*VectorPtr++;
            }
            else
               cptr = (char*)*VectorPtr++;
            if (!cptr)
            {
               status = SS$_ACCVIO;
               break;
            }
            if (Debug) fprintf (stdout, "!UZ |%s|\n", cptr);

            while (*cptr && fw && ofw)
            {
               fw--;
               ofw--;
               ch = *cptr++;
               if (isalnum(ch) ||
                   ch == '/' ||
                   ch == '-' ||
                   ch == '_' ||
                   ch == '$' ||
                   ch == '*' ||
                   ch == ':' ||
                   ch == '[' ||
                   ch == ']' ||
                   ch == ';' ||
                   ch == '~' ||
                   ch == '.')
               {
                  /* insert this character as-is */
                  if (!brcnt)
                  {
                     /* if writing to storage then it's overflowed */
                     if (BufferPtr != NULL)
                     {
                        BufferPtr[BufferSize-1] = '\0';
                        return (SS$_BUFFEROVF);
                     }
                     /* need another network buffer */
                     NetWriteBufferedInit (rqptr, false);
                     bptr = rqptr->rqOutput.BufferCurrentPtr;
                     brcnt = rqptr->rqOutput.BufferRemaining;
                  }
                  *bptr++ = ch;
                  bcnt++;
                  brcnt--;
                  continue;
               }

               /* encode this character */
               EncBuffer[1] = HexDigits[(ch & 0xf0) >> 4];
               EncBuffer[2] = HexDigits[ch & 0x0f];
               sptr = EncBuffer;
               /* add the encoded character */
               while (*sptr)
               {
                  if (brcnt--)
                  {
                     *bptr++ = *sptr++;
                     bcnt++; 
                     continue;
                  }
                  /* if writing to storage then it's overflowed */
                  if (BufferPtr != NULL)
                  {
                     BufferPtr[BufferSize-1] = '\0';
                     return (SS$_BUFFEROVF);
                  }
                  /* need another network buffer */
                  NetWriteBufferedInit (rqptr, false);
                  bptr = rqptr->rqOutput.BufferCurrentPtr;
                  brcnt = rqptr->rqOutput.BufferRemaining;
               }
            }
            /* only if required drop through to space-fill */
            if (fw <= 0) continue;
            /* no string to copy  */
            sptr = NULL;
         }
         else
         if (*(unsigned short*)fptr == 'UL')
         {
            /*********************/
            /* unsigned longword */
            /*********************/
   
            fptr += 2;
            if (IndirectValue)
            {
               if (!*VectorPtr)
               {
                  status = SS$_ACCVIO;
                  break;
               }
               LastNumericValue = *(unsigned long*)VectorPtr++;
            }
            else
               LastNumericValue = *VectorPtr++;
            if (Debug) fprintf (stdout, "!UL %d\n", LastNumericValue);
            if (fw > 0)
               status = sys$fao (&ULWidthFaoDsc, 0, &StringDsc,
                                 fw, LastNumericValue);
            else
               status = sys$fao (&ULFaoDsc, 0, &StringDsc,
                                 LastNumericValue);
            if (VMSnok (status)) break;
            if (!CommaNumber) fw = -1;
            sptr = String;
            /* drop through to buffer the string pointed to by 'sptr' */
         }
         else
         if (*(unsigned short*)fptr == 'XL')
         {
            /************************/
            /* hexadecimal longword */
            /************************/

            fptr += 2;
            if (IndirectValue)
            {
               if (!*VectorPtr)
               {
                  status = SS$_ACCVIO;
                  break;
               }
               LastNumericValue = *(unsigned long*)VectorPtr++;
            }
            else
               LastNumericValue = *VectorPtr++;
            if (Debug) fprintf (stdout, "!UL %d\n", LastNumericValue);
            if (fw > 0)
               status = sys$fao (&XLWidthFaoDsc, 0, &StringDsc,
                                 fw, LastNumericValue);
            else
               status = sys$fao (&XLFaoDsc, 0, &StringDsc,
                                 LastNumericValue);
            if (VMSnok (status)) break;
            if (!CommaNumber) fw = -1;
            sptr = String;
            /* drop through to buffer the string pointed to by 'sptr' */
         }
         else
         if (*(unsigned short*)fptr == 'ZL')
         {
            /************************/
            /* zero-filled longword */
            /************************/

            fptr += 2;
            if (IndirectValue)
            {
               if (!*VectorPtr)
               {
                  status = SS$_ACCVIO;
                  break;
               }
               LastNumericValue = *(unsigned long*)VectorPtr++;
            }
            else
               LastNumericValue = *VectorPtr++;
            if (Debug) fprintf (stdout, "!UL %d\n", LastNumericValue);
            if (fw > 0)
               status = sys$fao (&ZLWidthFaoDsc, 0, &StringDsc,
                                 fw, LastNumericValue);
            else
               status = sys$fao (&ZLFaoDsc, 0, &StringDsc,
                                 LastNumericValue);
            if (VMSnok (status)) break;
            if (!CommaNumber) fw = -1;
            sptr = String;
            /* drop through to buffer the string pointed to by 'sptr' */
         }
         else
         if (*(unsigned short*)fptr == 'SQ')
         {
            /*******************/
            /* signed quadword */
            /*******************/
   
            /*
               Note that the "!SQ" directive is being used, for VMS 6.2
               the "!UQ" && "!UJ" loop infinitely for signed values.
               Also note the indirect character MUST be used (i.e. "!@SQ").
            */

            fptr += 2;
            if (IndirectValue)
            {
               if (!*VectorPtr)
               {
                  status = SS$_ACCVIO;
                  break;
               }
               LastNumericValue = *((unsigned long*)(*VectorPtr));
            }
            else
            {
               /* must be indirect */
               status = SS$_BADPARAM;
               break;
            }
            if (Debug) fprintf (stdout, "!SQ %d\n", LastNumericValue);
#ifdef __ALPHA
            if (fw > 0)
               status = sys$fao (&SQWidthFaoDsc, 0, &StringDsc,
                                 fw, *VectorPtr++);
            else
               status = sys$fao (&SQFaoDsc, 0, &StringDsc,
                                 *VectorPtr++);
#else /* __ALPHA */
            /* no such directive for VAX, limp along with "!UL" */
            if (fw > 0)
               status = sys$fao (&ULWidthFaoDsc, 0, &StringDsc,
                                 fw, LastNumericValue);
            else
               status = sys$fao (&ULFaoDsc, 0, &StringDsc,
                                 LastNumericValue);
            *VectorPtr++;
#endif /* __ALPHA */
            if (VMSnok (status)) break;
            if (!CommaNumber) fw = -1;
            sptr = String;
            /* drop through to buffer the string pointed to by 'sptr' */
         }
         else
         if (*(unsigned short*)fptr == 'SL')
         {
            /*******************/
            /* signed longword */
            /*******************/
   
            fptr += 2;
            if (IndirectValue)
            {
               if (!*VectorPtr)
               {
                  status = SS$_ACCVIO;
                  break;
               }
               LastNumericValue = *(unsigned long*)VectorPtr++;
            }
            else
               LastNumericValue = *VectorPtr++;
            if (Debug) fprintf (stdout, "!SL %d\n", LastNumericValue);
            if (fw > 0)
               status = sys$fao (&SLWidthFaoDsc, 0, &StringDsc,
                                 fw, LastNumericValue);
            else
               status = sys$fao (&SLFaoDsc, 0, &StringDsc,
                                 LastNumericValue);
            if (VMSnok (status)) break;
            if (!CommaNumber) fw = -1;
            sptr = String;
            /* drop through to buffer the string pointed to by 'sptr' */
         }
         else
         if (*(unsigned short*)fptr == '%D')
         {
            /*************/
            /* date/time */
            /*************/

            fptr += 2;
            if (IndirectValue)
            {
               if (!*VectorPtr)
               {
                  status = SS$_ACCVIO;
                  break;
               }
               VectorValue = *(unsigned long*)VectorPtr++;
            }
            else
               VectorValue = *VectorPtr++;
            if (Debug) fprintf (stdout, "!%%D %d\n", VectorValue);

            status = sys$fao (&PDFaoDsc, 0, &StringDsc, VectorValue);
            if (VMSnok (status)) break;

            for (sptr = String; *sptr && *sptr != '-'; sptr++);
            /* absolute times have leading space changed to leading zero */
            if (*sptr && String[0] == ' ')
               (sptr = String)[0] = '0';
            else
            if (*sptr)
               sptr = String;
            else
               /* delta times have leading spaces absorbed */
               for (sptr = String; *sptr && *sptr == ' '; sptr++);
            /* drop through to buffer the string pointed to by 'sptr' */
         }
         else
         if (*(unsigned short*)fptr == '%W')
         {
            /*********************/
            /* weekday/date/time */
            /*********************/

            fptr += 2;
            if (IndirectValue)
            {
               if (!*VectorPtr)
               {
                  status = SS$_ACCVIO;
                  break;
               }
               BinTimePtr = *(unsigned long*)VectorPtr++;
            }
            else
               BinTimePtr = *VectorPtr++;
            if (Debug) fprintf (stdout, "!%%W %d\n", BinTimePtr);

            if (BinTimePtr == NULL) sys$gettim (BinTimePtr = &BinTime);
            if (!BinTimePtr[0] && !BinTimePtr[1])
               sptr = "(none)";
            else
            if (VMSnok (lib$day_of_week (BinTimePtr, &DayOfWeek)))
               sptr = "*ERROR*1";
            else
            if (VMSnok (sys$fao (&DayDateTimeFaoDsc, 0, &StringDsc,
                DayName[DayOfWeek], fw > 0 ? fw : 23, BinTimePtr)))
               sptr = "*ERROR*2";
            else
               sptr = String;
            /* reset the field-width (only applies to date/time) */
            if (fw > 0) fw = -1;
            /* drop through to buffer the string pointed to by 'sptr' */
         }
         else
         if (*(unsigned short*)fptr == '%%')
         {
            /************************/
            /* nested format string */
            /************************/

            fptr += 2;
            if (idx >= FORMAT_STACK_MAX)
            {
               status = SS$_OVRMAXARG;
               break;
            }
            if (IndirectValue)
            {
               if (!*VectorPtr)
               {
                  status = SS$_ACCVIO;
                  break;
               }
               cptr = *(char*)*VectorPtr++;
            }
            else
               cptr = (char*)*VectorPtr++;
            if (!cptr)
            {
               status = SS$_ACCVIO;
               break;
            }
            /* if empty then just continue with the current format string */
            if (!cptr[0]) continue;
            /* save the current format string pointer */
            FormatStack[idx++] = fptr;
            /* set the new format string pointer */
            fptr = FormatStack[idx] = cptr;
            if (Debug) fprintf (stdout, "!%%%% idx: %d fptr |%s|\n", idx, fptr);
            continue;
         }
         else
         if (*(unsigned short*)fptr == 'AF' ||
             (VmsFormat = *(unsigned short*)fptr == 'AV') ||
             (PathOdsExtended = VmsFormat =
                 (*(unsigned short*)fptr == 'A5')) ||
             (HtmlEscaped = (*(unsigned short*)fptr == 'HF')) ||
             (HtmlEscaped = VmsFormat = (*(unsigned short*)fptr == 'HV')) ||
             (PathOdsExtended = HtmlEscaped = VmsFormat =
                 (*(unsigned short*)fptr == 'H5')) ||
             (UrlEncoded = (*(unsigned short*)fptr == 'UF')) ||
             (UrlEncoded = VmsFormat = (*(unsigned short*)fptr == 'UV')) ||
             (PathOdsExtended = UrlEncoded = VmsFormat =
                 (*(unsigned short*)fptr == 'U5')))
         {
            /*********************************************/
            /* null-terminated, encoded/escaped filename */
            /*********************************************/

            fptr += 2;
            if (IndirectValue)
            {
               if (!*VectorPtr)
               {
                  status = SS$_ACCVIO;
                  break;
               }
               cptr = *(char*)*VectorPtr++;
            }
            else
               cptr = (char*)*VectorPtr++;
            if (!cptr)
            {
               status = SS$_ACCVIO;
               break;
            }
            if (Debug) fprintf (stdout, "!%c%c |%s|\n", fptr[0], fptr[1], cptr);

#ifdef ODS_EXTENDED

            /* if it doesn't look ODS-2-like then treat as if extended */
            if (!PathOdsExtended && OdsExtended)
            {
               for (sptr = cptr; *sptr; sptr++)
                  if (!(isupper(*sptr) ||
                        isdigit(*sptr) ||
                        *sptr == '/' ||
                        *sptr == '~' ||
                        *sptr == '.' ||
                        *sptr == '_' ||
                        *sptr == '-' ||
                        *sptr == ':' ||
                        *sptr == '[' ||
                        *sptr == ']' ||
                        *sptr == '$'))
                     break;
               if (*sptr) PathOdsExtended = true;
            }

#else /* ODS_EXTENDED */

            PathOdsExtended = false;

#endif /* ODS_EXTENDED */

            if (Debug)
               fprintf (stdout, "PathOdsExtended: %d\n", PathOdsExtended);

            while (*cptr && fw && ofw)
            {
               fw--;
               ofw--;

#ifdef ODS_EXTENDED

               if (PathOdsExtended)
               {
                  if (*cptr == '^' && *(cptr+1))
                  {
                     /* ODS-5 extended specification escape character */
                     cptr++;
                     switch (*cptr)
                     {
                        case '!' :
                        case '#' :
                        case '&' :
                        case '\'' :
                        case '`' :
                        case '(' :
                        case ')' :
                        case '+' :
                        case '@' :
                        case '{' :
                        case '}' :
                        case '.' :
                        case ',' :
                        case ';' :
                        case '[' :
                        case ']' :
                        case '%' :
                        case '^' :
                        case '=' :
                        case ' ' :
                           ch = *cptr;
                           break;
                        case '_' :
                           ch = ' ';
                           break;
                        default :
                           if (isxdigit (ch))
                           {
                              ch = 0;
                              if (*cptr >= '0' && *cptr <= '9')
                                 ch = (*cptr - (int)'0') << 4;
                              else
                              if (tolower(*cptr) >= 'a' &&
                                  tolower(*cptr) <= 'f')
                                 ch = (tolower(*cptr) - (int)'a' + 10) << 4;
                              cptr++;   
                              if (*cptr >= '0' && *cptr <= '9')
                                 ch += (*cptr - (int)'0');
                              else
                              if (tolower(*cptr) >= 'a' &&
                                  tolower(*cptr) <= 'f')
                                 ch += (tolower(*cptr) - (int)'a' + 10);
                              if (*cptr) cptr;
                           }
                           else
                              ch = *cptr;
                     }
                     cptr++;
                  }
                  else
                     ch = *cptr++;
               }
               else

#endif /* ODS_EXTENDED */

               {
                  /* not an extended file specification */
                  if (VmsFormat)
                     ch = *cptr++;
                  else
                     ch = tolower(*cptr++);
               }
   
               if (HtmlEscaped)
               {
                  switch (ch)
                  {
                     case '<' :
                        sptr = "&lt;";
                        break;
                     case '>' :
                        sptr = "&gt;";
                        break;
                     case '&' :
                        sptr = "&amp;";
                        break;
                     case '\"' :
                        sptr = "&quot;";
                        break;
                     default :
                        /* insert this character as-is */
                        if (!brcnt)
                        {
                           /* if writing to storage then it's overflowed */
                           if (BufferPtr != NULL)
                           {
                              BufferPtr[BufferSize-1] = '\0';
                              return (SS$_BUFFEROVF);
                           }
                           /* need another network buffer */
                           NetWriteBufferedInit (rqptr, false);
                           bptr = rqptr->rqOutput.BufferCurrentPtr;
                           brcnt = rqptr->rqOutput.BufferRemaining;
                        }
                        *bptr++ = ch;
                        bcnt++;
                        brcnt--;
                        continue;
                  }
               }
               else
               if (UrlEncoded)
               {
                  if (isalnum(ch) ||
                      ch == '/' ||
                      ch == '-' ||
                      ch == '_' ||
                      ch == '$' ||
                      ch == '*' ||
                      ch == ':' ||
                      ch == '[' ||
                      ch == ']' ||
                      ch == ';' ||
                      ch == '~' ||
                      ch == '.')
                  {
                     /* insert this character as-is */
                     if (!brcnt)
                     {
                        /* if writing to storage then it's overflowed */
                        if (BufferPtr != NULL)
                        {
                           BufferPtr[BufferSize-1] = '\0';
                           return (SS$_BUFFEROVF);
                        }
                        /* need another network buffer */
                        NetWriteBufferedInit (rqptr, false);
                        bptr = rqptr->rqOutput.BufferCurrentPtr;
                        brcnt = rqptr->rqOutput.BufferRemaining;
                     }
                     *bptr++ = ch;
                     bcnt++;
                     brcnt--;
                     continue;
                  }
                  /* encode this character */
                  EncBuffer[1] = HexDigits[(ch & 0xf0) >> 4];
                  EncBuffer[2] = HexDigits[ch & 0x0f];
                  sptr = EncBuffer;
               }
               else
               {
                  /* insert the character as-is */
                  if (!brcnt)
                  {
                     /* if writing to storage then it's overflowed */
                     if (BufferPtr != NULL)
                     {
                        BufferPtr[BufferSize-1] = '\0';
                        return (SS$_BUFFEROVF);
                     }
                     /* need another network buffer */
                     NetWriteBufferedInit (rqptr, false);
                     bptr = rqptr->rqOutput.BufferCurrentPtr;
                     brcnt = rqptr->rqOutput.BufferRemaining;
                  }
                  *bptr++ = ch;
                  bcnt++;
                  brcnt--;
                  continue;
               }

               /* add the escaped/encoded character */
               while (*sptr)
               {
                  if (brcnt--)
                  {
                     *bptr++ = *sptr++;
                     bcnt++; 
                     continue;
                  }
                  /* if writing to storage then it's overflowed */
                  if (BufferPtr != NULL)
                  {
                     BufferPtr[BufferSize-1] = '\0';
                     return (SS$_BUFFEROVF);
                  }
                  /* need another network buffer */
                  NetWriteBufferedInit (rqptr, false);
                  bptr = rqptr->rqOutput.BufferCurrentPtr;
                  brcnt = rqptr->rqOutput.BufferRemaining;
               }
            }
            HtmlEscaped = UrlEncoded = VmsFormat = false;

            /* only if required drop through to space-fill */
            if (fw <= 0) continue;
            /* no string to copy  */
            sptr = NULL;
         }
         else
         if (*(unsigned short*)fptr == '%M' ||
             *(unsigned short*)fptr == '%m')
         {
            /******************/
            /* status message */
            /******************/

            if (*(unsigned short*)fptr == '%M')
               SysGetMsgFlags = 15;
            else
               SysGetMsgFlags = 1;
            fptr += 2;
            if (IndirectValue)
            {
               if (!*VectorPtr)
               {
                  status = SS$_ACCVIO;
                  break;
               }
               VectorValue = *(unsigned long*)VectorPtr++;
            }
            else
               VectorValue = *VectorPtr++;
            if (Debug) fprintf (stdout, "!%%M %d\n", VectorValue);

            status = sys$getmsg (VectorValue, &Length, &StringDsc,
                                 SysGetMsgFlags, 0);
            if (VMSnok (status))
            {
               ErrorNoticed (status, "sys$getmsg()", FI_LI);
               sptr = "*ERROR* sys$getmsg()";
            }
            else
            {
               String[Length] = '\0';
               sptr = String + 1;
            }
            if (Debug) fprintf (stdout, "sys$getmsg() |%s|\n", String);
            /* drop through to buffer the string pointed to by 'sptr' */
         }
         else
         if (*(unsigned short*)fptr == 'AC')
         {
            /************************/
            /* counted ASCII string */
            /************************/

            fptr += 2;
            if (IndirectValue)
            {
               if (!*VectorPtr)
               {
                  status = SS$_ACCVIO;
                  break;
               }
               cptr = *(char*)*VectorPtr++;
            }
            else
               cptr = (char*)*VectorPtr++;
            if (!cptr)
            {
               status = SS$_ACCVIO;
               break;
            }
            if (Debug)
               fprintf (stdout, "!AC %d |%s|\n", (unsigned int)*cptr, cptr+1);

            /* get the count byte */
            ch = (unsigned int)*cptr++;
            while (ch)
            {
               if (brcnt--)
               {
                  *bptr++ = *cptr++;
                  bcnt++; 
                  ch--;
                  continue;
               }
               /* if writing to storage then it's overflowed */
               if (BufferPtr != NULL)
               {
                  BufferPtr[BufferSize-1] = '\0';
                  return (SS$_BUFFEROVF);
               }
               /* need another network buffer */
               NetWriteBufferedInit (rqptr, false);
               bptr = rqptr->rqOutput.BufferCurrentPtr;
               brcnt = rqptr->rqOutput.BufferRemaining;
            }
            /* only if required drop through to space-fill */
            if (fw <= 0) continue;
            /* no string to copy  */
            sptr = NULL;
         }
         else
         if (*(unsigned short*)fptr == '%T')
         {
            /********/
            /* time */
            /********/

            fptr += 2;
            if (IndirectValue)
            {
               if (!*VectorPtr)
               {
                  status = SS$_ACCVIO;
                  break;
               }
               VectorValue = *(unsigned long*)VectorPtr++;
            }
            else
               VectorValue = *VectorPtr++;
            if (Debug) fprintf (stdout, "!%%T %d\n", VectorValue);

            status = sys$fao (&PTFaoDsc, 0, &StringDsc, VectorValue);
            if (VMSnok (status)) break;
            sptr = String;
            /* drop through to buffer the string pointed to by 'sptr' */
         }
         else
         if (*(unsigned short*)fptr == '%s' ||
             *(unsigned short*)fptr == '%S')
         {
            /******************/
            /* add 'S' or 's' */
            /******************/

            if (Debug) fprintf (stdout, "!%%%c\n", fptr+1);
            if (LastNumericValue == 1)
            {
               fptr += 2;
               continue;
            }
            fptr++;
            fw = -1;
            if (*fptr++ == 's')
               sptr = "s";
            else
               sptr = "S";
            /* drop through to buffer the string pointed to by 'sptr' */
         }
         else
         if (*(unsigned short*)fptr == '%?')
         {
            /**********************/
            /* simple conditional */
            /**********************/

            /* e.g. "!%?string if *vector TRUE\rstring if FALSE\r" */
            fptr += 2;
            if (IndirectValue)
            {
               if (!*VectorPtr)
               {
                  status = SS$_ACCVIO;
                  break;
               }
               VectorValue = *(unsigned long*)VectorPtr++;
            }
            else
               VectorValue = *VectorPtr++;
            if (Debug) fprintf (stdout, "!%%? %d\n", VectorValue);

            if (!VectorValue)
            {
               /* if false skip over the true string */
               while (*fptr && *fptr != '\r') fptr++;
               if (*fptr == '\r') fptr++;
               if (!*fptr) break;
            }
            while (*fptr && *fptr != '\r' && fw && ofw)
            {
               if (brcnt--)
               {
                  *bptr++ = *fptr++;
                  bcnt++; 
                  fw--;
                  ofw--;
                  continue;
               }
               /* if writing to storage then it's overflowed */
               if (BufferPtr != NULL)
               {
                  BufferPtr[BufferSize-1] = '\0';
                  return (SS$_BUFFEROVF);
               }
               /* need another network buffer */
               NetWriteBufferedInit (rqptr, false);
               bptr = rqptr->rqOutput.BufferCurrentPtr;
               brcnt = rqptr->rqOutput.BufferRemaining;
            }
            if (*fptr != '\r')
            {
               /* field-width has expired before the return */
               while (*fptr && *fptr != '\r') fptr++;
            }
            if (*fptr == '\r') fptr++;
            if (VectorValue)
            {
               /* was true, skip over the false string */
               while (*fptr && *fptr != '\r') fptr++;
               if (*fptr == '\r') fptr++;
            }
            /* only if required drop through to space-fill */
            if (fw <= 0) continue;
         }
         else
         if (*fptr == '+')
         {
            /**************************/
            /* discard next parameter */
            /**************************/

            fptr++;
            VectorValue = *VectorPtr++;
            if (Debug) fprintf (stdout, "!+ %d\n", VectorValue);
         }
         else
         if (*fptr == '-')
         {
            /****************************/
            /* reuse previous parameter */
            /****************************/

            fptr++;
            VectorValue = *--VectorPtr;
            if (Debug) fprintf (stdout, "!- %d\n", VectorValue);
         }
         else
         if (*fptr == '!')
         {
            /****************************/
            /* an escaped '!' character */
            /****************************/

            if (Debug) fprintf (stdout, "!!\n");
            fptr++;
            sptr = "!";
            /* drop through to buffer the string pointed to by 'sptr' */
         }
         else
         if (*fptr == '*')
         {
            /*****************************/
            /* multiple '*'+1 characters */
            /*****************************/

            if (Debug) fprintf (stdout, "!*\n");
            if (!*++fptr) fw = 0;
            while (fw > 0 && ofw)
            {
               if (brcnt--)
               {
                  *bptr++ = *fptr;
                  bcnt++; 
                  fw--;
                  ofw--;
                  continue;
               }
               /* if writing to storage then it's overflowed */
               if (BufferPtr != NULL)
               {
                  BufferPtr[BufferSize-1] = '\0';
                  return (SS$_BUFFEROVF);
               }
               /* need another network buffer */
               NetWriteBufferedInit (rqptr, false);
               bptr = rqptr->rqOutput.BufferCurrentPtr;
               brcnt = rqptr->rqOutput.BufferRemaining;
            }
            if (*fptr) fptr++;
            continue;
         }
         else
         if (*fptr == '<')
         {
            /****************************/
            /* begin output-field-width */
            /****************************/

            if (Debug) fprintf (stdout, "!<\n");
            fptr++;
            if (ofw >= 0)
            {
               /* can't nest these little blighters! */
               status = SS$_BADPARAM;
               break;
            }
            ofw = fw;
            continue;
         }
         else
         if (*fptr == '>')
         {
            /**************************/
            /* end output-field-width */
            /**************************/

            if (Debug) fprintf (stdout, "!>\n");
            fptr++;
            if (ofw < 0)
            {
               /* didn't notice a leading "!<" */
               status = SS$_BADPARAM;
               break;
            }
            /* get (any) current outstanding that needs space-filling */
            fw = ofw;
            /* reset output-field-width to infinite */
            ofw = -1;
            /* only if required drop through to space-fill */
            if (fw <= 0) continue;
         }
         else
         {
            if (Debug) fprintf (stdout, "!%c%c\n", fptr[0], fptr[1]);
            status = SS$_BADPARAM;
            break;
         }

         /*********************************/
         /* copy a string into the buffer */
         /*********************************/

         if (sptr != NULL && CommaNumber)
         {
            Length = strlen(sptr);
            if (((Length-1) / 3) >= 1)
            {
               if (!(CommaCount = Length % 3))
                  CommaCount = 3;

               while (*sptr && fw && ofw)
               {
                  if (brcnt--)
                  {
                     if (!CommaCount--)
                     {
                        *bptr++ = ',';
                        bcnt++; 
                        fw--;
                        ofw--;
                        CommaCount = 3;
                        continue;
                     }
                     *bptr++ = *sptr++;
                     bcnt++; 
                     fw--;
                     ofw--;
                     continue;
                  }
                  /* if writing to storage then it's overflowed */
                  if (BufferPtr != NULL)
                  {
                     BufferPtr[BufferSize-1] = '\0';
                     return (SS$_BUFFEROVF);
                  }
                  /* need another network buffer */
                  NetWriteBufferedInit (rqptr, false);
                  bptr = rqptr->rqOutput.BufferCurrentPtr;
                  brcnt = rqptr->rqOutput.BufferRemaining;
               }
               /* only if required drop through to space-fill */
               if (fw <= 0) continue;
               sptr = NULL;
            }
            /* drop thru to copy 3 or less digits into the buffer */
         }

         if (sptr != NULL)
         {
            while (*sptr && fw && ofw)
            {
               if (brcnt--)
               {
                  *bptr++ = *sptr++;
                  bcnt++; 
                  fw--;
                  ofw--;
                  continue;
               }
               /* if writing to storage then it's overflowed */
               if (BufferPtr != NULL)
               {
                  BufferPtr[BufferSize-1] = '\0';
                  return (SS$_BUFFEROVF);
               }
               /* need another network buffer */
               NetWriteBufferedInit (rqptr, false);
               bptr = rqptr->rqOutput.BufferCurrentPtr;
               brcnt = rqptr->rqOutput.BufferRemaining;
            }
         }

         /***************************************************/
         /* if positive field-width, right-fill with spaces */
         /***************************************************/

         if (fw <= 0) continue;

         while (fw > 0 && ofw)
         {
            if (brcnt--)
            {
               *bptr++ = ' ';
               bcnt++; 
               fw--;
               ofw--;
               continue;
            }
            /* if writing to storage then it's overflowed */
            if (BufferPtr != NULL)
            {
               BufferPtr[BufferSize-1] = '\0';
               return (SS$_BUFFEROVF);
            }
            /* need another network buffer */
            NetWriteBufferedInit (rqptr, false);
            bptr = rqptr->rqOutput.BufferCurrentPtr;
            brcnt = rqptr->rqOutput.BufferRemaining;
         }
      }

      /*********************/
      /* end format string */
      /*********************/

      if (VMSnok (status)) break;

      /* if there are still pointers on the format stack */
      if (!idx) break;
      idx--;
   }

   /*****************************/
   /* end nested format strings */
   /*****************************/

   if (VMSnok (status))
   {
      /* if an error was detected append from the offending directive */
      fptr = LastFptr;
      while (*fptr)
      {
         if (brcnt--)
         {
            *bptr++ = *fptr++;
            bcnt++; 
            fw--;
            ofw--;
            continue;
         }
         /* if writing to storage then it's overflowed */
         if (BufferPtr != NULL)
         {
            BufferPtr[BufferSize-1] = '\0';
            return (SS$_BUFFEROVF);
         }
         /* need another network buffer */
         NetWriteBufferedInit (rqptr, false);
         bptr = rqptr->rqOutput.BufferCurrentPtr;
         brcnt = rqptr->rqOutput.BufferRemaining;
      }
   }

   if (Debug) fprintf (stdout, "%d bytes\n", bcnt - PrevBcnt);

   if (BufferPtr == NULL)
   {
      rqptr->rqOutput.BufferCurrentPtr = bptr;
      rqptr->rqOutput.BufferRemaining = brcnt;
      rqptr->rqOutput.BufferCount = bcnt;
   }
   else
   {
      *bptr = '\0';
      if (Debug) fprintf (stdout, "|%s|\n", BufferPtr);
   }

   if (LengthPtr != NULL)
   {
      if (bcnt - PrevBcnt > 65535)
      {
         /* indicate that we can't represent what we've written to buffer */
         *LengthPtr = 65535;
         status = SS$_BUFFEROVF;
      }
      else
         *LengthPtr = bcnt - PrevBcnt;
   }

   return (status);
}
   
/*****************************************************************************/
/*
Generate the appropriate server signature returned the supplied buffer.
*/

char* ServerSignature
(
struct RequestStruct *rqptr,
char *BufferPtr,
int BufferSize
)
{
   int  status,
        ServerPortNumber;
   char  *ServerHostNamePtr;
   char  EmailBuffer [256];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ServerSignature()\n");

   if (!Config.cfServer.Signature)
   {
      BufferPtr[0] = '\0';
      return (BufferPtr);
   }

   if (rqptr == NULL)
   {
      ServerHostNamePtr = ServerHostName;
      ServerPortNumber = ServerPort;
   }
   else
   {
      ServerHostNamePtr = rqptr->ServicePtr->ServerHostName;
      ServerPortNumber = rqptr->ServicePtr->ServerPort;
   }

   if (Config.cfServer.Signature == CONFIG_SERVER_SIGNATURE_EMAIL &&
       Config.cfServer.AdminEmail[0])
   {
      status = WriteFao (EmailBuffer, sizeof(EmailBuffer), NULL,
                         "<A HREF=\"mailto:!AZ\">!AZ</A>",
                         Config.cfServer.AdminEmail, ServerHostNamePtr);
      if (VMSnok (status)) ErrorNoticed (status, "WriteFao()", FI_LI);
   }
   else
      EmailBuffer[0] = '\0';

   status = WriteFao (BufferPtr, BufferSize, NULL,
                      MsgFor(rqptr, MSG_STATUS_SIGNATURE),
                      HTTPD_NAME, HTTPD_VERSION,
                      EmailBuffer[0] ? EmailBuffer : ServerHostNamePtr,
                      ServerPortNumber);
   if (VMSnok (status)) ErrorNoticed (status, "WriteFao()", FI_LI);

   if (Debug) fprintf (stdout, "BufferPtr |%s|\n", BufferPtr);
   return (BufferPtr);
}
   
/*****************************************************************************/
/*
Create an HTTP format local time string in the storage pointed at by
'TimeString', e.g. "Fri, 25 Aug 1995 17:32:40" (RFC1123). If 'BinTimePtr' is
null the time string represents the current time. If it points to a quadword,
VMS time value the string represents that time. 'TimeString' must point to
storage large enough for 31 characters.
*/

int HttpLocalTimeString
(
char *TimeString,
unsigned long *BinTimePtr
)
{
   /* alternate formats for time string */
#ifdef RFC_1123_DATE
   /* day, dd mmm yyyy hh:mm */
   static $DESCRIPTOR (HttpTimeFaoDsc, "!3AZ, !2ZW !3AZ !4ZW !2ZW:!2ZW:!2ZW");
#else
   /* weekday, dd-mmm-yyyy hh:mm */
   static $DESCRIPTOR (HttpTimeFaoDsc, "!3AZ, !2ZW-!3AZ-!4ZW !2ZW:!2ZW:!2ZW");
#endif

   static $DESCRIPTOR (TimeStringDsc, "");

   int  status;
   unsigned long  BinTime [2];
   unsigned short  Length;
   unsigned short  NumTime [7];
   unsigned long  DayOfWeek;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HttpLocalTimeString()\n");

   if (BinTimePtr == NULL)
      sys$gettim (&BinTime);
   else
   {
      BinTime[0] = BinTimePtr[0];
      BinTime[1] = BinTimePtr[1];
   }

   status = sys$numtim (&NumTime, &BinTime);
   if (Debug)
      fprintf (stdout, "sys$numtim() %%X%08.08X %d %d %d %d %d %d %d\n",
               status, NumTime[0], NumTime[1], NumTime[2],
               NumTime[3], NumTime[4], NumTime[5], NumTime[6]);

   if (VMSnok (status = lib$day_of_week (&BinTime, &DayOfWeek)))
      return (status);
   if (Debug)
      fprintf (stdout, "lib$day_of_week() %%X%08.08X is %d\n",
               status, DayOfWeek);

   /* set the descriptor address and size of the resultant time string */
   TimeStringDsc.dsc$w_length = 25;
   TimeStringDsc.dsc$a_pointer = TimeString;

   status = sys$fao (&HttpTimeFaoDsc, &Length, &TimeStringDsc,
                     DayName[DayOfWeek], NumTime[2], MonthName[NumTime[1]],
                     NumTime[0], NumTime[3], NumTime[4], NumTime[5]);
   if (VMSnok (status) || status == SS$_BUFFEROVF)
   {
      if (Debug) fprintf (stdout, "sys$fao() %%X%08.08X\n", status);
      TimeString[0] = '\0';
   }
   else
      TimeString[Length] = '\0';
   if (Debug) fprintf (stdout, "|%s|\n", TimeString);

   return (status);
}

/*****************************************************************************/
/*
Create an HTTP format Greenwich Mean Time (UTC) time string in the storage 
pointed at by 'TimeString', e.g. "Fri, 25 Aug 1995 17:32:40 GMT" (RFC1123). 
This must be at least 30 characters capacity.  If 'BinTimePtr' is null the 
time string represents the current time.  If it points to a quadword, VMS time 
value the string represents that time.  'TimeString' must point to storage 
large enough for 31 characters.
*/

int HttpGmTimeString
(
char *TimeString,
unsigned long *BinTimePtr
)
{
   /* alternate formats for time string */
#ifdef RFC_1123_DATE
   /* day, dd mmm yyyy hh:mm */
   static $DESCRIPTOR (HttpTimeFaoDsc,
          "!3AZ, !2ZW !3AZ !4ZW !2ZW:!2ZW:!2ZW GMT");
#else
   /* weekday, dd-mmm-yyyy hh:mm */
   static $DESCRIPTOR (HttpTimeFaoDsc,
          "!3AZ, !2ZW-!3AZ-!4ZW !2ZW:!2ZW:!2ZW GMT");
#endif

   static $DESCRIPTOR (TimeStringDsc, "");

   int  status;
   unsigned long  BinTime [2],
                  GmTime [2];
   unsigned short  Length;
   unsigned short  NumTime [7];
   unsigned long  DayOfWeek;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HttpGmTimeString()\n");

   if (BinTimePtr == NULL)
      sys$gettim (&GmTime);
   else
   {
      GmTime[0] = BinTimePtr[0];
      GmTime[1] = BinTimePtr[1];
   }

   if (VMSnok (status = TimeAdjustGMT (true, &GmTime)))
      return (status);

   status = sys$numtim (&NumTime, &GmTime);
   if (Debug)
      fprintf (stdout, "sys$numtim() %%X%08.08X %d %d %d %d %d %d %d\n",
               status, NumTime[0], NumTime[1], NumTime[2],
               NumTime[3], NumTime[4], NumTime[5], NumTime[6]);

   if (VMSnok (status = lib$day_of_week (&GmTime, &DayOfWeek)))
      return (status);
   if (Debug)
      fprintf (stdout, "lib$day_of_week() %%X%08.08X is %d\n",
               status, DayOfWeek);

   /* set the descriptor address and size of the resultant time string */
   TimeStringDsc.dsc$w_length = 29;
   TimeStringDsc.dsc$a_pointer = TimeString;

   status = sys$fao (&HttpTimeFaoDsc, &Length, &TimeStringDsc,
                     DayName[DayOfWeek], NumTime[2], MonthName[NumTime[1]],
                     NumTime[0], NumTime[3], NumTime[4], NumTime[5]);
   if (VMSnok (status) || status == SS$_BUFFEROVF)
   {
      if (Debug) fprintf (stdout, "sys$fao() %%X%08.08X\n", status);
      TimeString[0] = '\0';
   }
   else
      TimeString[Length] = '\0';
   if (Debug) fprintf (stdout, "|%s|\n", TimeString);

   return (status);
}

/*****************************************************************************/
/*
Given a string such as "Fri, 25 Aug 1995 17:32:40 GMT" (RFC1123), or "Friday,
25-Aug-1995 17:32:40 GMT" (RFC 1036), create an internal, local, binary time
with the current GMT offset.  See complementary function HttpGmTimeString().
*/ 

int HttpGmTime
(
char *TimeString,
unsigned long *BinTimePtr
)
{
   static char  *MonthName [] =
      { "", "Jan", "Feb", "Mar", "Apr", "May", "Jun",
            "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };

   register char  *tptr;

   int  status;
   unsigned short  Length;
   unsigned short  NumTime [7] = { 0,0,0,0,0,0,0 };
   unsigned long  DayOfWeek;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HttpGmTime() |%s|\n", TimeString);

   tptr = TimeString;
   /* hunt straight for the comma after the weekday name! */
   while (*tptr && *tptr != ',') tptr++;
   if (*tptr) tptr++;
   /* span white space between weekday name and date */
   while (*tptr && ISLWS(*tptr)) tptr++;
   /** if (Debug) fprintf (stdout, "tptr |%s|\n", tptr); **/
   if (!*tptr) return (STS$K_ERROR);

   /* get the date and then skip to month name */
   if (isdigit(*tptr)) NumTime[2] = atoi (tptr);
   while (*tptr && isdigit(*tptr)) tptr++;
   while (*tptr && (*tptr == '-' || ISLWS(*tptr))) tptr++;
   /** if (Debug) fprintf (stdout, "tptr |%s|\n", tptr); **/
   if (!*tptr) return (STS$K_ERROR);

   /* get the month number from the name and skip to the year */
   for (NumTime[1] = 1; NumTime[1] <= 12; NumTime[1]++)
      if (strsame (tptr, MonthName[NumTime[1]], 3)) break;
   if (NumTime[1] > 12) return (STS$K_ERROR);
   while (*tptr && isalpha(*tptr)) tptr++;
   while (*tptr && (*tptr == '-' || ISLWS(*tptr))) tptr++;
   /** if (Debug) fprintf (stdout, "tptr |%s|\n", tptr); **/
   if (!*tptr) return (STS$K_ERROR);

   /* get the year and then skip to the hour */
   if (isdigit(*tptr))
   {
      NumTime[0] = atoi (tptr);
      if (NumTime[0] <= 99)
      {
         /* for older browsers supplying 2 digit years, some Y2K insurance! */
         if (NumTime[0] >= 70)
            NumTime[0] += 1900;
         else
            NumTime[0] += 2000;
      }
   }
   while (*tptr && isdigit(*tptr)) tptr++;
   while (*tptr && ISLWS(*tptr)) tptr++;
   /** if (Debug) fprintf (stdout, "tptr |%s|\n", tptr); **/
   if (!*tptr) return (STS$K_ERROR);

   /* get the hour, minute and second */
   if (isdigit(*tptr)) NumTime[3] = atoi (tptr);
   while (*tptr && isdigit(*tptr)) tptr++;
   if (*tptr == ':') tptr++;
   if (isdigit(*tptr)) NumTime[4] = atoi (tptr);
   while (*tptr && isdigit(*tptr)) tptr++;
   if (*tptr == ':') tptr++;
   if (isdigit(*tptr)) NumTime[5] = atoi (tptr);
   while (*tptr && isdigit(*tptr)) tptr++;
   if (*tptr == ':') tptr++;
   if (!*tptr) return (STS$K_ERROR);

   /* the only thing remaining should be the "GMT" */
   while (*tptr && ISLWS(*tptr)) tptr++;
   /** if (Debug) fprintf (stdout, "tptr |%s|\n", tptr); **/
   if (!strsame (tptr, "GMT", 3)) return (STS$K_ERROR);

   /*******************************************/
   /* convert what looks like legitimate GMT! */
   /*******************************************/

   if (Debug)
      fprintf (stdout, "NumTime[] %d %d %d %d %d %d %d\n",
               NumTime[0], NumTime[1], NumTime[2], NumTime[3], 
               NumTime[4], NumTime[5], NumTime[6]); 
   status = lib$cvt_vectim (&NumTime, BinTimePtr);
   if (VMSnok (status)) return (status);
   if (Debug) fprintf (stdout, "lib$cvt_vectim() %%X%08.08X\n", status);

   return (TimeAdjustGMT (false, BinTimePtr));
}

/*****************************************************************************/
/*
Determine the offset from GMT (UTC) using either the HTTPD$GMT or
SYS$TIMEZONE_DIFFERENTIAL logicals. If HTTPD$GMT is not defined time should be
set from the timezone differential logical. Function RequestBegin() calls
this every hour to recheck GMT offset and detect daylight saving or other
timezone changes.
*/

int TimeSetGMT ()

{
   static boolean  UseTimezoneDifferential = false;

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "TimeSetGMT()\n");

   if (!UseTimezoneDifferential)
   {
      status = TimeSetHttpdGmt();
      /* return if error and that error was not that the name did not exist */
      if (VMSok (status) || status != SS$_NOLOGNAM) return (status);
   }

   UseTimezoneDifferential = true;
   return (TimeSetTimezone());
}

/*****************************************************************************/
/*
The SYS$TIMEZONE_DIFFERENTIAL logical contains the number of seconds offset
from GMT (UTC) as a positive (ahead) or negative (behind) number.  Set the
'TimeGmtString' global storage to a "+hh:mm" or "-hh:mm" string equivalent, and
the 'TimeAheadOfGmt' global boolean and 'TimeGmtVmsString' delta-time global
string.
*/

int TimeSetTimezone ()

{
   static unsigned short  Length;
   static $DESCRIPTOR (TimezoneLogicalNameDsc, "SYS$TIMEZONE_DIFFERENTIAL");
   static $DESCRIPTOR (LnmSystemDsc, "LNM$SYSTEM");
   static $DESCRIPTOR (TimeGmtStringFaoDsc, "!AZ!2ZL:!2ZL");
   static $DESCRIPTOR (TimeGmtVmsStringFaoDsc, "0 !2ZL:!2ZL");
   static $DESCRIPTOR (TimeGmtStringDsc, TimeGmtString);
   static struct {
      short int  buf_len;
      short int  item;
      unsigned char   *buf_addr;
      unsigned short  *short_ret_len;
   } LnmItems [] =
   {
      { sizeof(TimeGmtString)-1, LNM$_STRING, TimeGmtString, &Length },
      { 0,0,0,0 }
   };

   int  status;
   long  Hours,
         Minutes,
         Seconds;
   char  *SignPtr;
   $DESCRIPTOR (TimeGmtVmsStringDsc, TimeGmtVmsString);

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "TimeSetTimezone()\n");

   status = sys$trnlnm (0, &LnmSystemDsc, &TimezoneLogicalNameDsc, 0, &LnmItems);
   if (Debug) fprintf (stdout, "sys$trnlnm() %%X%08.08X\n", status);
   if (VMSnok (status)) return (status);

   TimeGmtString[Length] = '\0';
   if (Debug) fprintf (stdout, "TimeGmtString |%s|\n", TimeGmtString);
   Seconds = atol(TimeGmtString);
   if (Seconds < 0)
   {
      TimeAheadOfGmt = false;
      Seconds = -Seconds;
      SignPtr = "-";
   }
   else
   {
      TimeAheadOfGmt = true;
      SignPtr = "+";
   }
   Hours = Seconds / 3600;
   Minutes = (Seconds - Hours * 3600) / 60;
   if (Debug)
      fprintf (stdout, "%d %s%d:%d\n", Seconds, SignPtr, Hours, Minutes);
   sys$fao (&TimeGmtStringFaoDsc, &Length, &TimeGmtStringDsc,
            SignPtr, Hours, Minutes);
   TimeGmtString[Length] = '\0';
   if (Debug) fprintf (stdout, "TimeGmtString |%s|\n", TimeGmtString);

   sys$fao (&TimeGmtVmsStringFaoDsc, &Length, &TimeGmtVmsStringDsc,
            Hours, Minutes);
   TimeGmtVmsString[Length] = '\0';
   if (Debug) fprintf (stdout, "TimeGmtVmsString |%s|\n", TimeGmtVmsString);

   TimeGmtVmsStringDsc.dsc$w_length = Length;

   if (VMSnok (status =
       sys$bintim (&TimeGmtVmsStringDsc, &TimeGmtDeltaBinary)))
      return (status);
   if (TimeGmtDeltaBinary[0] || TimeGmtDeltaBinary[1])
      return (status);
   /* time must have been zero, make it one, one-hundreth of a second */
   TimeGmtDeltaBinary[0] = -100000;
   TimeGmtDeltaBinary[1] = -1;
   return (SS$_NORMAL);
}

/*****************************************************************************/
/*
Translate the logical HTTPD$GMT (defined to be something like "+10:30" or "-
01:15") and convert it into a delta time structure and store in 
'TimeGmtDeltaBinary'.  Store whether it is in advance or behind GMT in boolean 
'TimeAheadOfGmt'.  Store the logical string in 'TimeGmtString'.
*/

int TimeSetHttpdGmt ()

{
   static unsigned short  Length;
   static $DESCRIPTOR (GmtLogicalNameDsc, "HTTPD$GMT");
   static $DESCRIPTOR (LnmFileDevDsc, "LNM$FILE_DEV");
   static struct {
      short int  buf_len;
      short int  item;
      unsigned char   *buf_addr;
      unsigned short  *short_ret_len;
   } LnmItems [] =
   {
      { sizeof(TimeGmtString)-1, LNM$_STRING, TimeGmtString, &Length },
      { 0,0,0,0 }
   };

   register char  *cptr, *sptr;

   int  status;
   $DESCRIPTOR (TimeGmtVmsStringDsc, TimeGmtVmsString);

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "TimeSetHttpdGmt()\n");

   status = sys$trnlnm (0, &LnmFileDevDsc, &GmtLogicalNameDsc, 0, &LnmItems);
   if (Debug) fprintf (stdout, "sys$trnlnm() %%X%08.08X\n", status);
   if (VMSnok (status)) return (status);

   TimeGmtString[Length] = '\0';
   if (Debug) fprintf (stdout, "TimeGmtString |%s|\n", TimeGmtString);

   if (TimeGmtString[0] == '$') return (SS$_NORMAL);

   if (*(cptr = TimeGmtString) == '-')
      TimeAheadOfGmt = false;
   else
      TimeAheadOfGmt = true;
   if (*cptr == '+' || *cptr == '-') cptr++;
   sptr = TimeGmtVmsString;
   *sptr++ = '0';
   *sptr++ = ' ';
   while (*cptr) *sptr++ = *cptr++;
   *sptr = '\0';
   if (Debug) fprintf (stdout, "TimeGmtVmsString |%s|\n", TimeGmtVmsString);

   TimeGmtVmsStringDsc.dsc$w_length = sptr - TimeGmtVmsString;

   if (VMSnok (status =
       sys$bintim (&TimeGmtVmsStringDsc, &TimeGmtDeltaBinary)))
      return (status);
   if (TimeGmtDeltaBinary[0] || TimeGmtDeltaBinary[1])
      return (status);
   /* time must have been zero, make it one, one-hundreth of a second */
   TimeGmtDeltaBinary[0] = -100000;
   TimeGmtDeltaBinary[1] = -1;
   return (SS$_NORMAL);
}

/*****************************************************************************/
/*
The GMT is generated by calculating using an offset using 
'TimeGmtDeltaOffset' and boolean 'TimeAheadOfGmt'.  Adjust either to or from 
GMT.
*/ 

int TimeAdjustGMT
(
boolean ToGmTime,
unsigned long *BinTimePtr
)
{
   int  status;
   unsigned long  AdjustedTime [2];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "TimeAdjustGMT() ToGmTime: %d\n", ToGmTime);

   if ((ToGmTime && TimeAheadOfGmt) || (!ToGmTime && !TimeAheadOfGmt))
   {
      /* to GMT from local and ahead of GMT, or to local from GMT and behind */
      status = lib$sub_times (BinTimePtr, &TimeGmtDeltaBinary, &AdjustedTime);
      if (Debug) fprintf (stdout, "lib$sub_times() %%X%08.08X\n", status);
   }
   else
   {
      /* to GMT from local and behind GMT, or to local from GMT and ahead */
      status = lib$add_times (BinTimePtr, &TimeGmtDeltaBinary, &AdjustedTime);
      if (Debug) fprintf (stdout, "lib$add_times() %%X%08.08X\n", status);
   }

   if (Debug)
   {
      unsigned short  Length;
      char  String [64];
      $DESCRIPTOR (AdjustedTimeFaoDsc, "AdjustedTime: |!%D|\n");
      $DESCRIPTOR (StringDsc, String);

      sys$fao (&AdjustedTimeFaoDsc, &Length, &StringDsc, &AdjustedTime);
      String[Length] = '\0';
      fputs (String, stdout);
   }

   BinTimePtr[0] = AdjustedTime[0];
   BinTimePtr[1] = AdjustedTime[1];

   return (status);
}

/*****************************************************************************/
/*
*/

char* DigitDayTime (unsigned long *BinTimePtr)

{
   static char  TimeString [16];
   static $DESCRIPTOR (TimeFaoDsc, "!2ZL !2ZL:!2ZL:!2ZL\0");
   static $DESCRIPTOR (TimeStringDsc, TimeString);

   int  status;
   unsigned long  BinTime[2];
   unsigned short  NumTime [7];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "DigitDayTime()\n");

   if (BinTimePtr == NULL) sys$gettim (BinTimePtr = &BinTime);
   if (VMSnok (status = sys$numtim (&NumTime, BinTimePtr)))
      return ("*ERROR*");
   if (VMSnok (sys$fao (&TimeFaoDsc, 0, &TimeStringDsc,
               NumTime[2], NumTime[3], NumTime[4], NumTime[5])))
      return ("*ERROR*");
   return (TimeString);
}

/*****************************************************************************/
/*
Return a pointer to the name of the day of the week for the supplied binary
time.  If a NULL pointer to the binary time then return current day of week.
*/

char* DayOfWeekName (unsigned long *BinTimePtr)

{
   int  status;
   unsigned long  DayOfWeek;
   unsigned long  BinTime[2];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "DayOfWeekName()\n");

   if (BinTimePtr == NULL) sys$gettim (BinTimePtr = &BinTime);
   if (VMSnok (status = lib$day_of_week (BinTimePtr, &DayOfWeek)))
      DayOfWeek = 0;
   if (Debug)
      fprintf (stdout, "lib$day_of_week() %%X%08.08X is %d\n",
               status, DayOfWeek);
   return (DayName[DayOfWeek]);
}

/*****************************************************************************/
/*
If the content length has changed, or if it has been modified since the
specified date and time then return a normal status indicating that the object
has been modified.  If not modified then creat a 304 HTTP header and return a
LIB$_NEGTIM status to indicate the file should not be sent.  With VMS'
fractions of a second, add one second to the specified 'since' time to ensure a
reliable comparison.

Implements defacto HTTP/1.0 persistent connections.  Currently we only provide
"keep-alive" response if we're sending a file in binary mode and know its
precise length. An accurate "Content-Length:" field is vital for the client's
correct reception of the transmitted data.  The only other time a "keep-alive"
response can be provided is HERE, where a 304 header is returned (it has a
content length of precisely zero!)
*/ 
 
int HttpIfModifiedSince
(
struct RequestStruct *rqptr,
unsigned long *LastModifiedBinTimePtr,
int LastContentLength
)
{
   static unsigned long  OneSecondDelta [2] = { -10000000, -1 };

   int  status;
   unsigned long  AdjustedBinTime[2],
                  ScratchBinTime [2];
   char  *KeepAlivePtr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "HttpIfModifiedSince() %d %d\n",
               LastContentLength, rqptr->rqHeader.IfModifiedSinceLength);

   if (rqptr->rqHeader.IfModifiedSinceLength >= 0 &&
       LastContentLength >= 0 &&
       rqptr->rqHeader.IfModifiedSinceLength != LastContentLength)
   {
      if (Debug) fprintf (stdout, "different lengths\n");
      return (SS$_NORMAL);
   }

   if (!rqptr->rqTime.IfModifiedSinceVMS64bit[0] &&
       !rqptr->rqTime.IfModifiedSinceVMS64bit[1])
   {
      if (Debug) fprintf (stdout, "no if-modified-since\n");
      return (SS$_NORMAL);
   }

   /* add one second to the modified time, ensures a negative time */
   if (VMSnok (status =
       lib$add_times (&rqptr->rqTime.IfModifiedSinceVMS64bit,
                      &OneSecondDelta, &AdjustedBinTime)))
   {
      rqptr->rqResponse.ErrorTextPtr = "sys$add_times()";
      ErrorVmsStatus (rqptr, status, FI_LI);
      return (status);
   }
   if (Debug) fprintf (stdout, "sys$add_times() %%X%08.08X\n", status);

   if (Debug)
      WriteFaoStdout ("last: !%D this: !%D\n",
                      LastModifiedBinTimePtr, &AdjustedBinTime);

   /* if a positive time results the file has been modified */
   if (VMSok (status =
       lib$sub_times (LastModifiedBinTimePtr,
                      &AdjustedBinTime, &ScratchBinTime)))
      return (status);

   if (Debug) fprintf (stdout, "sys$sub_times() %%X%08.08X\n", status);
   if (status != LIB$_NEGTIM)
   {
      rqptr->rqResponse.ErrorTextPtr = "sys$sub_times()";
      ErrorVmsStatus (rqptr, status, FI_LI);
      return (status);
   }

   /*****************/
   /* not modified! */
   /*****************/

   rqptr->rqResponse.HttpStatus = 304;

   /* return a "keep-alive" response field if configured and was requested */
   if (Config.cfTimeout.SecondsKeepAlive && rqptr->KeepAliveRequest)
   {
      rqptr->KeepAliveResponse = true;
      rqptr->rqNet.KeepAliveCount++;
      KeepAlivePtr = DEFAULT_KEEPALIVE_HTTP_HEADER;
   }
   else
      KeepAlivePtr = "";

   /* note the zero content length! */
   HttpHeader (rqptr, rqptr->rqResponse.HttpStatus,
               NULL, 0, NULL, KeepAlivePtr);

   return (LIB$_NEGTIM);
}

/*****************************************************************************/
/*
Return the a pointer to abbreviated meaning of the supplied HTTP status code.
These are typical of those included on the response header status line.
*/

char *HttpStatusCodeText (int StatusCode)

{
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HttpStatusCodeText() %d\n", StatusCode);

   switch (StatusCode)
   {
      case 100 : return ("Continue"); /* (HTTP/1.1) */
      case 101 : return ("Switching Protocols"); /* (HTTP/1.1) */
      case 200 : return ("OK");
      case 201 : return ("Created");
      case 202 : return ("Accepted");
      case 203 : return ("No Content");
      case 204 : return ("Non-authoritative"); /* (HTTP/1.1) */
      case 205 : return ("Reset Content"); /* (HTTP/1.1) */
      case 206 : return ("Partial Content"); /* (HTTP/1.1) */
      case 300 : return ("Multiple Choices"); /* (HTTP/1.1) */
      case 301 : return ("Moved Permanently");
      case 302 : return ("Moved Temporarily");
      case 303 : return ("See Other"); /* (HTTP/1.1) */
      case 304 : return ("Not Modified");
      case 305 : return ("Use Proxy"); /* (HTTP/1.1) */
      case 400 : return ("Bad Request");
      case 401 : return ("Authorization Required");
      case 402 : return ("Payment Required"); /* (HTTP/1.1) */
      case 403 : return ("Forbidden");
      case 404 : return ("Not Found");
      case 405 : return ("Not Allowed"); /* (HTTP/1.1) */
      case 406 : return ("Not Acceptable"); /* (HTTP/1.1) */
      case 407 : return ("Proxy Authentication Required"); /* (HTTP/1.1) */
      case 408 : return ("Request Timeout"); /* (HTTP/1.1) */
      case 409 : return ("Conflict"); /* (HTTP/1.1) */
      case 410 : return ("Gone"); /* (HTTP/1.1) */
      case 411 : return ("Length Required"); /* (HTTP/1.1) */
      case 412 : return ("Precondition Failed"); /* (HTTP/1.1) */
      case 413 : return ("Request Entity Too Large"); /* (HTTP/1.1) */
      case 414 : return ("Request URI Too Long"); /* (HTTP/1.1) */
      case 415 : return ("Unsupported Media Type"); /* (HTTP/1.1) */
      case 500 : return ("Internal Error");
      case 501 : return ("Not Implemented");
      case 502 : return ("Bad Gateway");
      case 503 : return ("Service Unavailable");
      case 504 : return ("Gateway Timeout"); /* (HTTP/1.1) */
      case 505 : return ("HTTP Version Not Supported"); /* (HTTP/1.1) */
      default :  return ("Unknown Code!");
   }
}

/*****************************************************************************/
/*
Return the a pointer an explanation of the supplied HTTP status code.  These
are supplied from the message database can be are used in error messages, etc.
*/

char *HttpStatusCodeExplanation
(
struct RequestStruct *rqptr,
int StatusCode
)
{
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HttpStatusCodeExplanation()\n");

   switch (StatusCode)
   {
      /* continue (HTTP/1.1) */
      case 100 : return (MsgFor(rqptr,MSG_HTTP_100));
      /* switching protocols (HTTP/1.1) */
      case 101 : return (MsgFor(rqptr,MSG_HTTP_101));
      /* success */
      case 200 : return (MsgFor(rqptr,MSG_HTTP_200));
      /* created */
      case 201 : return (MsgFor(rqptr,MSG_HTTP_201));
      /* accepted */
      case 202 : return (MsgFor(rqptr,MSG_HTTP_202));
      /* non-authoritative (HTTP/1.1) */
      case 203 : return (MsgFor(rqptr,MSG_HTTP_203));
      /* no content */
      case 204 : return (MsgFor(rqptr,MSG_HTTP_204));
      /* reset content (HTTP/1.1) */
      case 205 : return (MsgFor(rqptr,MSG_HTTP_205));
      /* partial content (HTTP/1.1) */
      case 206 : return (MsgFor(rqptr,MSG_HTTP_206));
      /* multiple choices (HTTP/1.1) */
      case 300 : return (MsgFor(rqptr,MSG_HTTP_300));
      /* moved permanently */
      case 301 : return (MsgFor(rqptr,MSG_HTTP_301));
      /* moved temporarily */
      case 302 : return (MsgFor(rqptr,MSG_HTTP_302));
      /* see other (HTTP/1.1)  */
      case 303 : return (MsgFor(rqptr,MSG_HTTP_303));
      /* not modified */
      case 304 : return (MsgFor(rqptr,MSG_HTTP_304));
      /* use proxy (HTTP/1.1)  */
      case 305 : return (MsgFor(rqptr,MSG_HTTP_305));
      /* bad request */
      case 400 : return (MsgFor(rqptr,MSG_HTTP_400));
      /* authorization required */
      case 401 : return (MsgFor(rqptr,MSG_HTTP_401));
      /* payment required */
      case 402 : return (MsgFor(rqptr,MSG_HTTP_402));
      /* forbidden */
      case 403 : return (MsgFor(rqptr,MSG_HTTP_403));
      /* not found */
      case 404 : return (MsgFor(rqptr,MSG_HTTP_404));
      /* method not allowed (HTTP/1.1) */
      case 405 : return (MsgFor(rqptr,MSG_HTTP_405));
      /* not acceptable (HTTP/1.1) */
      case 406 : return (MsgFor(rqptr,MSG_HTTP_406));
      /* proxy authentication required (HTTP/1.1) */
      case 407 : return (MsgFor(rqptr,MSG_HTTP_407));
      /* request timeout (HTTP/1.1) */
      case 408 : return (MsgFor(rqptr,MSG_HTTP_408));
      /* resource conflict (HTTP/1.1) */
      case 409 : return (MsgFor(rqptr,MSG_HTTP_409));
      /* gone (HTTP/1.1) */
      case 410 : return (MsgFor(rqptr,MSG_HTTP_410));
      /* length required (HTTP/1.1) */
      case 411 : return (MsgFor(rqptr,MSG_HTTP_411));
      /* precondition failed (HTTP/1.1) */
      case 412 : return (MsgFor(rqptr,MSG_HTTP_412));
      /* request entity too large (HTTP/1.1) */
      case 413 : return (MsgFor(rqptr,MSG_HTTP_413));
      /* request-URI too long (HTTP/1.1) */
      case 414 : return (MsgFor(rqptr,MSG_HTTP_414));
      /* unsupported media type (HTTP/1.1) */
      case 415 : return (MsgFor(rqptr,MSG_HTTP_415));
      /* internal error */
      case 500 : return (MsgFor(rqptr,MSG_HTTP_500));
      /* not implemented */
      case 501 : return (MsgFor(rqptr,MSG_HTTP_501));
      /* bad gateway */
      case 502 : return (MsgFor(rqptr,MSG_HTTP_502));
      /* service unavailable */
      case 503 : return (MsgFor(rqptr,MSG_HTTP_503));
      /* gateway timeout (HTTP/1.1) */
      case 504 : return (MsgFor(rqptr,MSG_HTTP_504));
      /* HTTP version not supported (HTTP/1.1) */
      case 505 : return (MsgFor(rqptr,MSG_HTTP_505));
      /* unknown code! */
      default :
         return ("The server is reporting an UNKNOWN status code!");
   }
}

/*****************************************************************************/
/*
Generate a VmGetHeap()ed string containing an HTTP response header, pointed to
by 'rqptr->rqResponse.HeaderPtr' with 'rqptr->rqResponse.HeaderLength' also set. Will
generate success as well as error response headers, incorporating required
authorization challenges if a 401 status.

If no response status code is supplied as a parameter it defaults to whatever
'rqptr->rqResponse.HttpStatus' is set.  If this is not set both default to 200.
UNLESS this header is for a redirected error report in which case both are set
to the status code of the original request and generate any required
authorization challenges against the original realm if a 401 status!

If a content-type has been supplied with the call (and it always should be!)
generate a "content-type:" header line, with "charset" component if set for the
server or request.  A path-set content-type overrides the parameter.

If a modified time is supplied generate a "last-modified:" header line.

If the request is marked as pre-expired then generate an "expires:" header line
containing the current GMT time.

'OtherHeaderPtr' is a catch-all parameter.  This string is directly included as
part of the HTTP header and so should contain correct carriage control, e.g.
"Keep-Alive:\r\n".

This function will always generate a header (only failing if it cannot allocate
memory, in which case the server exits).  If an error is detected when doing so
a bogus 500 header is created with an embedded indication of where the problem
occured.  The request will continue but generally when delivered the error
indication will be obvious.
*/

HttpHeader
(
struct RequestStruct *rqptr,
int ResponseStatusCode,
char *ContentTypePtr,
int ContentLength,
unsigned long *ModifiedBinTimePtr,
char *OtherHeaderPtr
)
{
   static char  ErrorHeader [] =
"HTTP/1.0 500 Internal error\r\n\
Content-Type: text/plain\r\n\
\r\n\
Internal server error occured generating the HTTP response header!\n\
Please report to this site's administrator.\n\
\n\0";
   static int  ErrorHeaderLength = sizeof(ErrorHeader)-1;

   static char  HeaderFao [] =
"!AZ !UL !AZ\r\n\
!%%\
!%%\
Server: !AZ\r\n\
Date: !AZ\r\n\
!%%\
!%%\
!%%\
!%%\
!%%\
!AZ\
\r\n";

   static $DESCRIPTOR (BufferDsc, "");

   int  status, idx;
   unsigned short  Length;
   unsigned long  FaoVector [32];
   unsigned long  *vecptr;
   char  *cptr, *sptr, *zptr;
   char  *AuthRealmBufferPtr,
         *CharsetPtr,
         *SemiColonPtr;
   char  ContentTypeString [128],
         ModifiedString [32],
         Buffer [2048];

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "HttpHeader() %d |%s| %d\n",
               ResponseStatusCode, ContentTypePtr, ContentLength);

   rqptr->rqResponse.HeaderLength = 0;
   rqptr->rqResponse.HeaderPtr = NULL;

   if (!ResponseStatusCode) ResponseStatusCode = rqptr->rqResponse.HttpStatus;
   if (!ResponseStatusCode) ResponseStatusCode = 200;
   rqptr->rqResponse.HttpStatus = ResponseStatusCode;

   if (rqptr->RedirectErrorStatusCode)
   {
      /* special case ... processing redirected error report */
      rqptr->rqResponse.HttpStatus = rqptr->RedirectErrorStatusCode;

      /* if authorization error then generate authentication challenge(s) */
      if (rqptr->rqResponse.HttpStatus == 401)
      {
         /* of course, use the realm of the original request! */
         sptr = rqptr->rqAuth.RealmDescrPtr;
         rqptr->rqAuth.RealmDescrPtr = rqptr->RedirectErrorAuthRealmDescrPtr;
         HttpHeaderChallenge (rqptr);
         rqptr->rqAuth.RealmDescrPtr = sptr;
      }
   }
   else
   if (rqptr->rqResponse.HttpStatus == 401 ||
       rqptr->rqResponse.HttpStatus == 407)
      HttpHeaderChallenge (rqptr);

   /* if the path has a content-type SET against it then that overrides */
   if (rqptr->rqPathSet.ContentTypePtr != NULL)
      ContentTypePtr = rqptr->rqPathSet.ContentTypePtr;

   if (ContentTypePtr != NULL &&
       strsame (ContentTypePtr, "text/", 5))
   {
      /* content-type is text of some sort */
      SemiColonPtr = NULL;
      zptr = (sptr = ContentTypeString) + sizeof(ContentTypeString);
      /* as we copy note where any "; charset=" begins */
      for (cptr = ContentTypePtr; *cptr && sptr < zptr; *sptr++ = *cptr++)
         if (*cptr == ';') SemiColonPtr = sptr;

      /* if the path has a charset SET against it then that overrides */
      if ((CharsetPtr = rqptr->rqPathSet.CharsetPtr) == NULL)
      {
         /* if the server has a default charset then use that */
         if (Config.cfContent.CharsetDefault[0])
            CharsetPtr = Config.cfContent.CharsetDefault;
      }

      if (CharsetPtr != NULL)
      {
         if (SemiColonPtr != NULL) sptr = SemiColonPtr;
         for (cptr = "; charset="; *cptr && sptr < zptr; *sptr++ = *cptr++);
         for (cptr = CharsetPtr; *cptr && sptr < zptr; *sptr++ = *cptr++);
      }

      if (sptr >= zptr)
      {
         ErrorNoticed (0, "HttpHeader()", FI_LI);
         rqptr->rqResponse.HeaderPtr = ErrorHeader;
         rqptr->rqResponse.HeaderLength = ErrorHeaderLength;
         return;
      }
      *sptr = '\0';
      ContentTypePtr = ContentTypeString;
   }

   if (OtherHeaderPtr == NULL) OtherHeaderPtr = "";

   vecptr = FaoVector;

   *vecptr++ = HttpProtocol;
   *vecptr++ = rqptr->rqResponse.HttpStatus;
   *vecptr++ = HttpStatusCodeText(rqptr->rqResponse.HttpStatus);

   if (rqptr->rqResponse.HttpStatus == 401 ||
       rqptr->rqResponse.HttpStatus == 407)
   {
      if (rqptr->rqAuth.BasicChallengePtr[0])
      {
         *vecptr++ = "!AZ\r\n";
         *vecptr++ = rqptr->rqAuth.BasicChallengePtr;
      }
      else
         *vecptr++ = "";
      if (rqptr->rqAuth.DigestChallengePtr[0])
      {
         *vecptr++ = "!AZ\r\n";
         *vecptr++ = rqptr->rqAuth.DigestChallengePtr;
      }
      else
         *vecptr++ = "";
   }
   else
   {
      *vecptr++ = "";
      *vecptr++ = "";
   }

   *vecptr++ = SoftwareID;
   *vecptr++ = rqptr->rqTime.GmDateTime;

   if (ModifiedBinTimePtr == NULL)
      *vecptr++ = "";
   else
   {
      if (VMSnok (status =
          HttpGmTimeString (ModifiedString, ModifiedBinTimePtr)))
      {
         ErrorNoticed (status, "HttpHeader()", FI_LI);
         rqptr->rqResponse.HeaderPtr = ErrorHeader;
         rqptr->rqResponse.HeaderLength = ErrorHeaderLength;
         return;
      }
      *vecptr++ = "Last-Modified: !AZ\r\n";
      *vecptr++ = ModifiedString;
   }

   if (rqptr->rqResponse.PreExpired ||
       rqptr->rqPathSet.Expired)
   {
      *vecptr++ = "Expires: !AZ\r\n";
      if (ModifiedBinTimePtr == NULL)
         *vecptr++ = "Fri, 13 Jan 1978 14:00:00 GMT";
      else
         /* already generated immediately above */
         *vecptr++ = ModifiedString;
   }
   else
      *vecptr++ = "";

   if (ContentTypePtr == NULL)
      *vecptr++ = "";
   else
   {
      *vecptr++ = "Content-Type: !AZ\r\n";
      *vecptr++ = ContentTypePtr;
   }

   if (ContentLength >= 0)
   {
      *vecptr++ = "Content-Length: !UL\r\n";
      *vecptr++ = ContentLength;
   }
   else
      *vecptr++ = "";

   for (idx = 0; idx < RESPONSE_COOKIE_MAX; idx++)
   {
      if (rqptr->rqResponse.CookiePtr[idx] == NULL) continue;
      *vecptr++ = "Set-Cookie: !AZ\r\n!%%";
      *vecptr++ = rqptr->rqResponse.CookiePtr[idx];
   }
   *vecptr++ = "";

   *vecptr++ = OtherHeaderPtr;

   BufferDsc.dsc$a_pointer = Buffer;
   BufferDsc.dsc$w_length = sizeof(Buffer) - 1;

   status = WriteFaol (Buffer, sizeof(Buffer), &Length, HeaderFao, &FaoVector);
   if (VMSnok (status) || status == SS$_BUFFEROVF)
   {
      ErrorNoticed (status, "HttpHeader()", FI_LI);
      rqptr->rqResponse.HeaderPtr = ErrorHeader;
      rqptr->rqResponse.HeaderLength = ErrorHeaderLength;
      return;
   }
   Buffer[Length] = '\0';

   cptr = VmGetHeap (rqptr, Length+1);
   memcpy (cptr, Buffer, Length+1);
   rqptr->rqResponse.HeaderLength = Length;
   rqptr->rqResponse.HeaderPtr = cptr;

   if (Debug) fprintf (stdout, "|%s|\n", Buffer);
}

/*****************************************************************************/
/*
Generate DIGEST and/or BASIC challenges as appropriate.  If the response status
code is 401 (authorization needed) and no realm has been specified change the
code to 403 (forbidden) and just return.
*/

HttpHeaderChallenge (struct RequestStruct *rqptr)

{
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HttpHeaderChallenge()\n");

   /* without a realm for authentication convert it to forbidden */
   if ((rqptr->rqResponse.HttpStatus == 401 ||
        rqptr->rqResponse.HttpStatus == 407) &&
       (rqptr->rqAuth.RealmDescrPtr == NULL ||
        !rqptr->rqAuth.RealmDescrPtr[0]))
   {
      rqptr->rqResponse.HttpStatus = 403;
      return;
   }

   if (!rqptr->rqAuth.ChallengeScheme)
   {
      /* ensure at least a BASIC challenge is generated if promiscuous */
      if (Config.cfAuth.BasicEnabled || AuthPromiscuous)
         rqptr->rqAuth.ChallengeScheme |= AUTH_SCHEME_BASIC;
      if (Config.cfAuth.DigestEnabled)
         rqptr->rqAuth.ChallengeScheme |= AUTH_SCHEME_DIGEST;

      /* if neither scheme enabled don't challenge */
      if (!rqptr->rqAuth.ChallengeScheme) rqptr->rqResponse.HttpStatus = 403;
   }

   if ((rqptr->rqAuth.ChallengeScheme & AUTH_SCHEME_BASIC) &&
       rqptr->rqAuth.BasicChallengePtr == NULL)
      BasicChallenge (rqptr);
   if (rqptr->rqAuth.BasicChallengePtr == NULL)
      rqptr->rqAuth.BasicChallengePtr = "";

   if ((rqptr->rqAuth.ChallengeScheme & AUTH_SCHEME_DIGEST) &&
       rqptr->rqAuth.DigestChallengePtr == NULL)
      DigestChallenge (rqptr, "");
   if (rqptr->rqAuth.DigestChallengePtr == NULL)
      rqptr->rqAuth.DigestChallengePtr = "";
}

/*****************************************************************************/
/*
Append a string onto a HTTP header located in HTTPd heap allocated memory. 
This header string must already exist (created by HttpHeader200() or
equivalent).  The new string is appended to the current header, just before the
header terminating empty line.  Any string added must contain correct HTTP
header carriage control.
*/

HttpHeaderAppend
(
struct RequestStruct *rqptr,
char *StringPtr,
int StringLength
)
{
   char  *cptr,
         *HeaderPtr;
   int  HeaderLength;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "HttpHeaderAppend()\n%d |%s|\n",
               rqptr->rqResponse.HeaderLength, rqptr->rqResponse.HeaderPtr);

   if ((HeaderPtr = rqptr->rqResponse.HeaderPtr) == NULL) return;

   HeaderLength = rqptr->rqResponse.HeaderLength;
   if (StringLength <= 0) StringLength = strlen(StringPtr);

   HeaderPtr = VmReallocHeap (rqptr, HeaderPtr,
                              HeaderLength+StringLength, FI_LI);
   /* point to just before the header terminating empty line */
   cptr = HeaderPtr + HeaderLength - 2;
   memcpy (cptr, StringPtr, StringLength);
   /* add the new header terminating empty line */
   cptr += StringLength;
   *cptr++ = '\r';
   *cptr++ = '\n';
   *cptr = '\0';

   rqptr->rqResponse.HeaderPtr = HeaderPtr;
   rqptr->rqResponse.HeaderLength = HeaderLength + StringLength;

   if (Debug)
      fprintf (stdout, "%d |%s|\n", rqptr->rqResponse.HeaderLength, HeaderPtr);
}

/*****************************************************************************/
/*
A heap string is one located in HTTPd heap allocated memory.  Append the
supplied, null-terminated string to that pointed to by the heap string pointer. 
If this is NULL then allocate new memory, if not reallocate sufficient memory
to append the new string.  Return a pointer the string.
*/

char* HeapStringAppend
(
struct RequestStruct *rqptr,
char *HeapStringPtr,
char *StringPtr,
int StringLength
)
{
   int  HeapStringLength;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HeapStringAppend()\n|%s|\n", HeapStringPtr);

   if (StringLength <= 0) StringLength = strlen(StringPtr);

   if (HeapStringPtr == NULL)
   {
      HeapStringPtr = VmGetHeap (rqptr, StringLength+1);
      memcpy (HeapStringPtr, StringPtr, StringLength+1);
      if (Debug) fprintf (stdout, "|%s|\n", HeapStringPtr);
      return (HeapStringPtr);
   }
   else
   {
      HeapStringLength = strlen(HeapStringPtr);

      HeapStringPtr = VmReallocHeap (rqptr, HeapStringPtr,
                                     HeapStringLength+StringLength+1, FI_LI);
      /* copy just past the original end-of-string (incl. terminating null) */
      memcpy (HeapStringPtr+HeapStringLength, StringPtr, StringLength+1);
      if (Debug) fprintf (stdout, "|%s|\n", HeapStringPtr);
      return (HeapStringPtr);
   }
}

/*****************************************************************************/
/*
A heap string is one located in HTTPd heap allocated memory.  Prepend the
supplied, null-terminated string to that pointed to by the heap string pointer. 
If this is NULL then allocate new memory, if not reallocate sufficient memory
to append the new string.  Return a pointer the string.
*/

char* HeapStringPrepend
(
struct RequestStruct *rqptr,
char *HeapStringPtr,
char *StringPtr,
int StringLength
)
{
   int  HeapStringLength;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HeapStringPrepend()\n|%s|\n", HeapStringPtr);

   if (StringLength <= 0) StringLength = strlen(StringPtr);

   if (HeapStringPtr == NULL)
   {
      HeapStringPtr = VmGetHeap (rqptr, StringLength+1);
      memcpy (HeapStringPtr, StringPtr, StringLength+1);
      if (Debug) fprintf (stdout, "|%s|\n", HeapStringPtr);
      return (HeapStringPtr);
   }
   else
   {
      HeapStringLength = strlen(HeapStringPtr);
      HeapStringPtr = VmReallocHeap (rqptr, HeapStringPtr,
                                     HeapStringLength+StringLength+1, FI_LI);
      /* shift the existing string along in memory creating a gap */
      memcpy (HeapStringPtr+HeapStringLength,
              HeapStringPtr,
              HeapStringLength+1);  /* includes terminating null */
      /* copy just past the original end-of-string */
      memcpy (HeapStringPtr, StringPtr, StringLength);
      if (Debug) fprintf (stdout, "|%s|\n", HeapStringPtr);
      return (HeapStringPtr);
   }
}

/*****************************************************************************/
/*
Returns 1 if time 1 is later than time 2, 0 if the same, and -1 if time 1 is
earlier than time 2.
*/

int CompareVmsBinTimes
(
unsigned long *BinTime1Ptr,
unsigned long *BinTime2Ptr
)
{
   int  status;
   unsigned long  BinTime [2];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "CompareVmsBinTimes()\n");

   status = lib$sub_times (BinTime1Ptr, BinTime2Ptr, BinTime);
   if (Debug) fprintf (stdout, "lib$sub_times() %%X%08.08X\n", status);
   if (status == LIB$_NEGTIM)
   {
      if (Debug) fprintf (stdout, "1 < 2\n");
      return (-1);
   }
   else
   if (VMSok (status))
   {
      if (BinTime1Ptr[0] == BinTime2Ptr[0] && BinTime1Ptr[1] == BinTime2Ptr[1])
      {
         if (Debug) fprintf (stdout, "1 == 2\n");
         return (0);
      }
      else
      {
         if (Debug) fprintf (stdout, "1 > 2\n");
         return (1); 
      }
   }
   else
      ErrorExitVmsStatus (status, "lib$sub_times()", FI_LI);
}

/*****************************************************************************/
/*
Returns a pointer to a VmGetHeap()ed string of <META ...> tags for an
internally generated HTML document.
*/

char* HtmlMetaInfo
(
struct RequestStruct *rqptr,
char *VmsInfoPtr
)
{
   register unsigned long  *vecptr;

   int  status;
   unsigned long  FaoVector [16];
   unsigned short  Length;
   char  *MetaPtr;
   char  Buffer [2048];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "HtmlMetaInfo()\n");

   vecptr = &FaoVector;
   *vecptr++ = SoftwareID;
   *vecptr++ = rqptr->rqTime.GmDateTime;

   if (rqptr->RemoteUser[0])
   {
      *vecptr++ = "<META NAME=\"author\" CONTENT=\"!HZ.\'!HZ\'@!AZ\">\n";
      *vecptr++ = rqptr->RemoteUser;
      *vecptr++ = rqptr->rqAuth.RealmDescrPtr;
      *vecptr++ = rqptr->ServicePtr->ServerHostPort;
   }
   else
   {
      *vecptr++ = "<META NAME=\"host\" CONTENT=\"!AZ\">\n";
      *vecptr++ = rqptr->ServicePtr->ServerHostPort;
   }

   if (VmsInfoPtr != NULL && VmsInfoPtr[0])
   {
      if (Config.cfReport.MetaInfoEnabled)
      {
         *vecptr++ = "<META NAME=\"VMS\" CONTENT=\"!HZ\">\n!%%";
         *vecptr++ = VmsInfoPtr;
         if (rqptr->PathOds)
         {
            *vecptr++ = "<META NAME=\"ODS\" CONTENT=\"!UL\">\n";
            *vecptr++ = rqptr->PathOds;
         }
         else
            *vecptr++ = "";
      }
      else
         *vecptr++ = "";
   }
   else
      *vecptr++ = "";

   status = WriteFaol (Buffer, sizeof(Buffer), &Length,
"<META NAME=\"generator\" CONTENT=\"!AZ\">\n\
<META NAME=\"date\" CONTENT=\"!AZ\">\n\
!%%\
!%%",
      &FaoVector);

   if (VMSnok (status) || status == SS$_BUFFEROVF)
   {
      ErrorNoticed (status, "WriteFaol()", FI_LI);
      return ("<!-- META overflow ERROR -->\n");
   }

   MetaPtr = VmGetHeap (rqptr, Length+1);
   memcpy (MetaPtr, Buffer, Length+1);

   return (MetaPtr);
}

/*****************************************************************************/
/*
Zero server accounting structure and service counters.  Redefine monitor
logicals to reflect this.
*/ 

ZeroAccounting ()

{
   int  ZeroedCount;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ZeroAccounting()\n");

   ZeroedCount = Accounting.ZeroedCount;
   memset (&Accounting, 0, sizeof(Accounting));
   Accounting.ZeroedCount = ZeroedCount + 1;
   NetServiceZeroAccounting ();

   /* minimum duration must be set very high */
   Accounting.ResponseDurationMin = 0xffffffff;

   memset ((char*)&ProxyAccounting, 0, sizeof(ProxyAccounting));
   ProxyAccounting.ServingEnabled = ProxyServingEnabled;
   ProxyAccounting.FreeSpaceAvailable = ProxyCacheFreeSpaceAvailable;

   if (MonitorEnabled) DefineMonitorLogicals (NULL);
}

/*****************************************************************************/
/*
There are enough exit points from the function that actually does the logical
name processing that this function wraps it with the appropriate privilege
changes to make sure we don't miss any!
*/ 

DefineMonitorLogicals (struct RequestStruct *rqptr)

{
   static unsigned long  SysNamMask [2] = { PRV$M_SYSNAM, 0 };

   int  status,
        SetPrvStatus;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "DefineMonitorLogicals()\n");

   /* turn on SYSNAM to allow access to system table */
   if (VMSnok (status = sys$setprv (1, &SysNamMask, 0, 0)))
   {
      if (Debug) fprintf (stdout, "sys$setprv() %%X%08.08X\n", status);
      return (status);
   }

   status = DefineMonitorLogicalsHere (rqptr);

   /* turn off SYSNAM */
   if (VMSnok (SetPrvStatus = sys$setprv (0, &SysNamMask, 0, 0)))
   {
      if (Debug) fprintf (stdout, "sys$setprv() %%X%08.08X\n", SetPrvStatus);
      /* do NOT keep processing if there is a problem turning off SYSNAM! */
      ErrorExitVmsStatus (SetPrvStatus, "disabling SYSNAM", FI_LI);
   }

   return (status);
}

/*****************************************************************************/
/*
Define two/three logicals used by the HTTPd monitor utility.  The value of the 
count logical is the binary contents of the server counter data structure.  
The value of the request logical is some information on the latest request to 
complete.  The PID logical is defined only once, the first time this function 
is called.
*/ 

DefineMonitorLogicalsHere (struct RequestStruct *rqptr)

{
   static boolean  Initialized = false;
   static unsigned long  PslUser = PSL$C_USER;
   static char  CountLogicalName1 [32],
                CountLogicalName2 [32],
                CountLogicalName3 [32],
                RequestLogicalName [32],
                RequestLogicalValue [256];

   static $DESCRIPTOR (CountLogicalName1Dsc, CountLogicalName1);
   static $DESCRIPTOR (CountLogicalName2Dsc, CountLogicalName2);
   static $DESCRIPTOR (CountLogicalName3Dsc, CountLogicalName3);
   static $DESCRIPTOR (LnmSystemDsc, "LNM$SYSTEM");
   static $DESCRIPTOR (RequestLogicalNameDsc, RequestLogicalName);
   static $DESCRIPTOR (RequestLogicalValueDsc, RequestLogicalValue);
   /*
      "day time\0client-host\0status\0rx\0tx\0duration\0" +
      "request-scheme//server-host:port\0method resource"
   */
   static $DESCRIPTOR (RequestLogicalValueFaoDsc,
"!2ZL !2ZL:!2ZL:!2ZL\0!UL\0!UL\0!UL\0!UL.!#ZL\0!AZ//!AZ:!AZ\0!AZ\0!AZ !AZ");

   static struct
   {
      unsigned short  buf_len;
      unsigned short  item;
      unsigned char   *buf_addr;
      unsigned short  *short_ret_len;
   }
   LnmCount1Item [] =
   {
      { 255, LNM$_STRING, &Accounting, 0 },
      { 0,0,0,0 }
   },
   LnmCount2Item [] =
   {
      { sizeof(Accounting)-255, LNM$_STRING, ((char*)&Accounting)+255, 0 },
      { 0,0,0,0 }
   },
   LnmCount3Item [] =
   {
      { sizeof(ProxyAccounting), LNM$_STRING, &ProxyAccounting, 0 },
      { 0,0,0,0 }
   },
   LnmRequestItem [] =
   {
      { 0, LNM$_STRING, RequestLogicalValue, 0 },
      { 0,0,0,0 }
   };

   register unsigned long  *vecptr;

   boolean  KeepAliveTimeout;
   int  status;
   unsigned short  Length;
   unsigned long  FaoVector [32];
   char  *RequestUriPtr;
   unsigned long  Seconds,
                  SubSeconds;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "DefineMonitorLogicalsHere()\n");

   if (!Initialized)
   {
      /**********************/
      /* first time through */
      /**********************/

      /* local storage */
      char  PidLogicalName [16];
      $DESCRIPTOR (PidLogicalNameDsc, PidLogicalName);
      $DESCRIPTOR (PidLogicalNameFaoDsc, "HTTPD!UL$PID");
      $DESCRIPTOR (CountLogicalName1FaoDsc, "HTTPD!UL$COUNT1");
      $DESCRIPTOR (CountLogicalName2FaoDsc, "HTTPD!UL$COUNT2");
      $DESCRIPTOR (CountLogicalName3FaoDsc, "HTTPD!UL$COUNT3");
      $DESCRIPTOR (RequestLogicalNameFaoDsc, "HTTPD!UL$REQUEST");
      static struct
      {
         unsigned short  buf_len;
         unsigned short  item;
         unsigned char   *buf_addr;
         unsigned short  *short_ret_len;
      }
      LnmPidItem [] =
      {
         { sizeof(HttpdProcessId), LNM$_STRING, &HttpdProcessId, 0 },
         { 0,0,0,0 }
      };

      if (Debug)
         fprintf (stdout, "sizeof(Accounting): %d\n", sizeof(Accounting));

      Initialized = true;

      /* define a logical name containing the PID of the server process */
      sys$fao (&PidLogicalNameFaoDsc, &Length, &PidLogicalNameDsc,
               ServerPort);
      PidLogicalName[PidLogicalNameDsc.dsc$w_length = Length] = '\0';
      if (Debug) fprintf (stdout, "PidLogicalName |%s|\n", PidLogicalName);
      if (VMSnok (status =
          sys$crelnm (0, &LnmSystemDsc, &PidLogicalNameDsc, &PslUser,
                      &LnmPidItem)))
         return (status);

      /* generate approriate names for the count and request logicals */
      sys$fao (&CountLogicalName1FaoDsc, &Length, &CountLogicalName1Dsc,
               ServerPort);
      CountLogicalName1[CountLogicalName1Dsc.dsc$w_length = Length] = '\0';
      if (Debug)
         fprintf (stdout, "CountLogicalName1 |%s|\n", CountLogicalName1);
      sys$fao (&CountLogicalName2FaoDsc, &Length, &CountLogicalName2Dsc,
               ServerPort);
      CountLogicalName2[CountLogicalName2Dsc.dsc$w_length = Length] = '\0';
      if (Debug)
         fprintf (stdout, "CountLogicalName2 |%s|\n", CountLogicalName2);
      sys$fao (&CountLogicalName3FaoDsc, &Length, &CountLogicalName3Dsc,
               ServerPort);
      CountLogicalName3[CountLogicalName3Dsc.dsc$w_length = Length] = '\0';
      if (Debug)
         fprintf (stdout, "CountLogicalName3 |%s|\n", CountLogicalName3);
      sys$fao (&RequestLogicalNameFaoDsc, &Length, &RequestLogicalNameDsc,
               ServerPort);
      RequestLogicalName[RequestLogicalNameDsc.dsc$w_length = Length] = '\0';
      if (Debug)
         fprintf (stdout, "RequestLogicalName |%s|\n", RequestLogicalName);

      /* attempt to read the values of any previous count logical name */
      if (VMSok (status =
          sys$trnlnm (0, &LnmSystemDsc, &CountLogicalName1Dsc, 0,
                      &LnmCount1Item)))
      if (VMSok (status =
          sys$trnlnm (0, &LnmSystemDsc, &CountLogicalName2Dsc, 0,
                      &LnmCount2Item)))
      if (VMSok (status =
          sys$trnlnm (0, &LnmSystemDsc, &CountLogicalName3Dsc, 0,
                      &LnmCount3Item)))
         Accounting.StartupCount++;
      else
      {
         if (status != SS$_NOLOGNAM)
            return (status);
      }
   }

   /*****************************************/
   /* (re)define count and request logicals */
   /*****************************************/

   if (rqptr == NULL)
   {
      KeepAliveTimeout = false;
      if (!RequestLogicalValue[0]) LnmRequestItem[0].buf_len = 1;
   }
   else
   if (!(KeepAliveTimeout = rqptr->KeepAliveTimeout))
   {
      if (rqptr->rqHeader.RequestUriPtr == NULL)
         RequestUriPtr = "";
      else
         RequestUriPtr = rqptr->rqHeader.RequestUriPtr;

      vecptr = FaoVector;
      *vecptr++ = rqptr->rqTime.VmsVector[2];
      *vecptr++ = rqptr->rqTime.VmsVector[3];
      *vecptr++ = rqptr->rqTime.VmsVector[4];
      *vecptr++ = rqptr->rqTime.VmsVector[5];
      *vecptr++ = rqptr->rqResponse.HttpStatus;
      *vecptr++ = rqptr->BytesRawRx;
      *vecptr++ = rqptr->BytesRawTx;

      Seconds = rqptr->rqResponse.Duration / USECS_IN_A_SECOND;
      SubSeconds = (rqptr->rqResponse.Duration % USECS_IN_A_SECOND) /
                   DURATION_UNITS_USECS;
      *vecptr++ = Seconds;
      *vecptr++ = DURATION_DECIMAL_PLACES;
      *vecptr++ = SubSeconds;

      *vecptr++ = rqptr->ServicePtr->RequestSchemeNamePtr;
      *vecptr++ = rqptr->ServicePtr->ServerHostName;
      *vecptr++ = rqptr->ServicePtr->ServerPortString;
      *vecptr++ = rqptr->rqNet.ClientHostName;
      *vecptr++ = rqptr->rqHeader.MethodName;
      *vecptr++ = RequestUriPtr;

      status = sys$faol (&RequestLogicalValueFaoDsc, &Length,
                         &RequestLogicalValueDsc, &FaoVector);

      if (Debug) fprintf (stdout, "sys$faol() %%X%08.08X\n", status);
      RequestLogicalValue[LnmRequestItem[0].buf_len = Length] = '\0';
      if (Debug)
         fprintf (stdout, "RequestLogicalValue |%s|\n", RequestLogicalValue);
   }

   if (VMSnok (status =
       sys$crelnm (0, &LnmSystemDsc, &CountLogicalName1Dsc, &PslUser,
                   &LnmCount1Item)))
      return (status);

   if (VMSnok (status =
       sys$crelnm (0, &LnmSystemDsc, &CountLogicalName2Dsc, &PslUser,
                   &LnmCount2Item)))
      return (status);

   if (VMSnok (status =
       sys$crelnm (0, &LnmSystemDsc, &CountLogicalName3Dsc, &PslUser,
                   &LnmCount3Item)))
      return (status);

   if (!KeepAliveTimeout)
   {
      if (VMSnok (status =
          sys$crelnm (0, &LnmSystemDsc, &RequestLogicalNameDsc, &PslUser,
                      &LnmRequestItem)))
         return (status);
   }

   return (SS$_NORMAL);
}

/*****************************************************************************/
/*
Convert a VMS quadword, binary time to a Unix-style time component structure.
*/

boolean TimeVmsToUnix
(
unsigned long *BinTimePtr,
struct tm *TmPtr
)
{
   static unsigned long  LibDayOfWeek = LIB$K_DAY_OF_WEEK;
   static unsigned long  LibDayOfYear = LIB$K_DAY_OF_YEAR;

   int  status;
   unsigned long  DayOfWeek,
                  DayOfYear;
   unsigned short  NumTime [7];
   unsigned long  BinTime [2];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "TimeVmsToUnix()\n");

   if (BinTimePtr == NULL) sys$gettim (BinTimePtr = &BinTime);

   if (VMSnok (status = sys$numtim (&NumTime, BinTimePtr)))
      return (status);

   lib$cvt_from_internal_time (&LibDayOfWeek, &DayOfWeek, BinTimePtr);
   lib$cvt_from_internal_time (&LibDayOfYear, &DayOfYear, BinTimePtr);

   TmPtr->tm_sec = NumTime[5];
   TmPtr->tm_min = NumTime[4];
   TmPtr->tm_hour = NumTime[3];
   TmPtr->tm_mday = NumTime[2];
   TmPtr->tm_mon = NumTime[1] - 1;
   TmPtr->tm_year = NumTime[0] - 1900;
   TmPtr->tm_wday = DayOfWeek;
   TmPtr->tm_yday = DayOfYear;
   TmPtr->tm_isdst = 0;

   if (Debug) fprintf (stdout, "%s", asctime(TmPtr));

   return (SS$_NORMAL);
}

/*****************************************************************************/
/*
Parse a network mask from the supplied string.
The mask is a dotted-decimal network address, a slash, then a dotted-decimal
mask (e.g. "131.185.250.23/255.255.255.192", i.e. a 6 bit subnet).
Return a NULL if there is a problem with the mask, or a pointer to the first
character following the mask.
*/

char* ParseNetMask
(
char *String,
struct NetMaskStruct *NetMaskPtr
)
{
   int  idx;
   int  OctetsMask [4],
        OctetsNetwork [4];
   char  *cptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ParseNetMask() |%s|\n", String);

   /* set all octets to -1 as a sentinal for checking we get all required */
   for (idx = 0; idx <= 3; idx++) OctetsNetwork[idx] = OctetsMask[idx] = -1;

   sscanf (String, "%d.%d.%d.%d/%d.%d.%d.%d",
           &OctetsNetwork[0], &OctetsNetwork[1],
           &OctetsNetwork[2], &OctetsNetwork[3],
           &OctetsMask[0], &OctetsMask[1],
           &OctetsMask[2], &OctetsMask[3]);

   if (Debug)
      fprintf (stdout, "%d.%d.%d.%d/%d.%d.%d.%d\n",
               OctetsNetwork[0], OctetsNetwork[1],
               OctetsNetwork[2], OctetsNetwork[3],
               OctetsMask[0], OctetsMask[1],
               OctetsMask[2], OctetsMask[3]);

   for (idx = 0; idx <= 3; idx++)
   {
      if (OctetsNetwork[idx] < 0 || OctetsNetwork[idx] > 255) return (NULL);
      if (OctetsMask[idx] < 0 || OctetsMask[idx] > 255) return (NULL);
      ((unsigned char*)&NetMaskPtr->BitsNetwork)[idx] =
         (unsigned char)(OctetsNetwork[idx]);
      ((unsigned char*)&NetMaskPtr->BitsMask)[idx] =
         (unsigned char)(OctetsMask[idx]);
   }

   if (Debug)
      fprintf (stdout, "%08.08X/%08.08X\n",
               NetMaskPtr->BitsNetwork, NetMaskPtr->BitsMask);

   /* now scan across the string's components */
   for (cptr = String;
        *cptr && (isdigit(*cptr) || *cptr == '.' || *cptr == '/');
        cptr++);
   return (cptr);
}

/*****************************************************************************/
/*
A null terminated string is parsed for the next "fieldname=fieldvalue[&]"
pair.  If an error is encountered generated an error message and return NULL,
otherwise return a pointer to the next pair or end-of-string.
*/

char* ParseQueryField
(
struct RequestStruct *rqptr,
char *QueryString,
char *FieldName,
int SizeOfFieldName,
char *FieldValue,
int SizeOfFieldValue,
char *SourceCodeFile,
int SourceCodeLine
)
{
   register char  *cptr, *qptr, *sptr, *zptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ParseQueryField() |%s|\n", QueryString);

   qptr = QueryString;
   zptr = (sptr = FieldName) + SizeOfFieldName;
   while (*qptr && *qptr != '=')
   {
      while (*qptr == '\r' || *qptr == '\n') qptr++;
      while (*qptr && *qptr != '=' &&
             *qptr != '\r' && *qptr != '\n' && sptr < zptr) *sptr++ = *qptr++;
   }
   if (sptr >= zptr)
   {
      ErrorGeneralOverflow (rqptr, SourceCodeFile, SourceCodeLine);
      return (NULL);
   }
   *sptr = '\0';
   if (Debug) fprintf (stdout, "FieldName |%s|\n", FieldName);

   if (*qptr++ != '=')
   {
      rqptr->rqResponse.HttpStatus = 400;
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_REQUEST_URL_ENC),
                    SourceCodeFile, SourceCodeLine);
      return (NULL);
   }

   zptr = (sptr = FieldValue) + SizeOfFieldValue;
   while (*qptr && *qptr != '&' && sptr < zptr)
   {
      while (*qptr == '\r' || *qptr == '\n') qptr++;
      while (*qptr && *qptr != '&' &&
             *qptr != '\r' && *qptr != '\n' && sptr < zptr) *sptr++ = *qptr++;
   }
   if (sptr >= zptr)
   {
      ErrorGeneralOverflow (rqptr, SourceCodeFile, SourceCodeLine);
      return (NULL);
   }
   *sptr = '\0';
   if (Debug) fprintf (stdout, "FieldValue |%s|\n", FieldValue);

   if (*qptr && *qptr != '&')
   {
      rqptr->rqResponse.HttpStatus = 400;
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_REQUEST_URL_ENC),
                    SourceCodeFile, SourceCodeLine);
      return (NULL);
   }
   if (*qptr) qptr++;

   if (UrlDecodeString (FieldValue) < 0)
   {
      rqptr->rqResponse.HttpStatus = 400;
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_REQUEST_URL_ENC),
                    SourceCodeFile, SourceCodeLine);
      return (NULL);
   }

   return (qptr);
}

/****************************************************************************/
/*
generate a standard VMS protection string from the mask. 'String' must be at
least 28 bytes (better use 32 :^)  Returns the length of the string.
*/ 
 
int FormatProtection
(
unsigned short pmask,
char *String
)
{
   register char  *sptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "FormatProtection() %%X%04.04X\n", pmask);

   sptr = String;

   if (!(pmask & 0x0001)) *sptr++ = 'R';
   if (!(pmask & 0x0002)) *sptr++ = 'W';
   if (!(pmask & 0x0004)) *sptr++ = 'E';
   if (!(pmask & 0x0008)) *sptr++ = 'D';
   *sptr++ = ',';
   if (!(pmask & 0x0010)) *sptr++ = 'R';
   if (!(pmask & 0x0020)) *sptr++ = 'W';
   if (!(pmask & 0x0040)) *sptr++ = 'E';
   if (!(pmask & 0x0080)) *sptr++ = 'D';
   *sptr++ = ',';
   if (!(pmask & 0x0100)) *sptr++ = 'R';
   if (!(pmask & 0x0200)) *sptr++ = 'W';
   if (!(pmask & 0x0400)) *sptr++ = 'E';
   if (!(pmask & 0x0800)) *sptr++ = 'D';
   *sptr++ = ',';
   if (!(pmask & 0x1000)) *sptr++ = 'R';
   if (!(pmask & 0x2000)) *sptr++ = 'W';
   if (!(pmask & 0x4000)) *sptr++ = 'E';
   if (!(pmask & 0x8000)) *sptr++ = 'D';

   *sptr = '\0';
   if (Debug) fprintf (stdout, "|%s|\n", String);
   return (sptr - String);
}
 
/****************************************************************************/
/*
URL-decodes a string in place (can do this because URL-decoded text is always
the same or less than the length of the original).  Returns the number of
characters in the decoded string, or -1 to indicate a URL-encoding error.
*/ 
 
int UrlDecodeString (char *String)

{
   char  *cptr, *sptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "UrlDecodeString() |%s|\n", String);

   cptr = sptr = String;
   while (*cptr)
   {
      switch (*cptr)
      {
         case '=' :
         case '&' :
            /* URL-forbidden characters */
            return (-1);

         case '+' :
            *sptr++ = ' ';
            cptr++;
            break;

         case '%' :
            cptr++;
            if (*cptr >= '0' && *cptr <= '9')
               *sptr = (*cptr - '0') << 4;
            else
            if (toupper(*cptr) >= 'A' && toupper(*cptr) <= 'F')
               *sptr = (toupper(*cptr) - '7') << 4;
            else
               return (-1);
            if (*cptr) cptr++;
            if (*cptr >= '0' && *cptr <= '9')
               *sptr |= *cptr - '0';
            else
            if (toupper(*cptr) >= 'A' && toupper(*cptr) <= 'F')
               *sptr |= toupper(*cptr) - '7';
            else
               return (-1);
            sptr++;
            if (*cptr) cptr++;
            break;

         default :
            *sptr++ = *cptr++;
      }
   }
   *sptr = '\0';
   if (Debug) fprintf (stdout, "|%s|\n", String);
   return (sptr - String);
}
 
/*****************************************************************************/
/*
Generate a unique request identifier.  Based on the description and code of the
Apache Group's "mod_unique" module.  One change has been made to allow the ID
to be used as part of VMS file names, the substitution of '@' for '_'.
*/

char* GenerateUniqueId (struct RequestStruct *rqptr)

{
   static unsigned char  ValueTable [] =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-";

   static int  UniqueIdCount = 0;
   static char  UniqueIdString [UNIQUE_ID_SIZE+8];

   register int  idx;
   register char *sptr; 
   register unsigned char  *cptr; 

   unsigned long  TimeStamp;

#ifdef __ALPHA
#   pragma member_alignment __save
#   pragma nomember_alignment
#endif

   struct {
      unsigned int  Stamp;
      unsigned int  IpAddr;
      unsigned int  Pid;
      unsigned short  Count;
      unsigned short  Zeroes;
   } UniqueId;

#ifdef __ALPHA
#   pragma member_alignment __restore
#endif

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "GenerateUniqueId()\n");

   TimeStamp = decc$fix_time (&rqptr->rqTime.Vms64bit);

   UniqueId.Stamp = htonl(TimeStamp);
   UniqueId.IpAddr = htonl(rqptr->ServicePtr->ServerIpAddress);
   UniqueId.Pid = htonl(HttpdProcessId);
   UniqueId.Count = htons(UniqueIdCount);
   /* this is just padding for the encoding */
   UniqueId.Zeroes = 0;
   UniqueIdCount++;

   sptr = UniqueIdString;
   cptr = (unsigned char*)&UniqueId;
   for (idx = 0; idx < sizeof(UniqueId)-sizeof(short); idx += 3)
   {
      *sptr++ = ValueTable[cptr[idx]>>2];
      *sptr++ = ValueTable[((cptr[idx] & 0x03) << 4) |
                           ((cptr[idx+1] & 0xf0) >> 4)];
      *sptr++ = ValueTable[((cptr[idx+1] & 0x0f) << 2) |
                           ((cptr[idx+2] & 0xc0) >> 6)];
      *sptr++ = ValueTable[cptr[idx+2] & 0x3f];
   }
   UniqueIdString[UNIQUE_ID_SIZE] = '\0';
   if (Debug) fprintf (stdout, "UniqueIdString |%s|\n", UniqueIdString);

   return (UniqueIdString);
}

/*****************************************************************************/
/*
String search allowing wildcard "*" (matching any multiple characters) and "%" 
(matching any single character).  Returns NULL if not found or a pointer to
start of matched string.  Setting 'ImpliedWildcards' means the 'SearchFor'
string is processed as if enclosed by '*' wildcard characters.
*/ 

char* SearchTextString
( 
char *SearchIn,
char *SearchFor,
boolean CaseSensitive,
boolean ImpliedWildcards,
int *MatchedLengthPtr
)
{
   register char  *cptr, *sptr, *inptr;
   char  *RestartCptr,
         *RestartInptr,
         *MatchPtr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "SearchTextString() |%s|%s|\n", SearchIn, SearchFor);

   if (MatchedLengthPtr != NULL) *MatchedLengthPtr = 0;
   if (!*(cptr = SearchFor)) return (NULL);
   inptr = MatchPtr = SearchIn;

   if (ImpliedWildcards)
   {
      /* skip leading text up to first matching character (if any!) */
      if (*cptr != '*' && *cptr != '%')
      {
         if (CaseSensitive)
            while (*inptr && *inptr != *cptr) inptr++;
         else
            while (*inptr && toupper(*inptr) != toupper(*cptr)) inptr++;
         if (Debug && !*inptr) fprintf (stdout, "1. NOT matched!\n");
         if (!*inptr) return (NULL);
         cptr++;
         MatchPtr = inptr++;
      }
   }

   for (;;)
   {
      if (CaseSensitive)
      {
         while (*cptr && *inptr && *cptr == *inptr)
         {
            cptr++;
            inptr++;
         }
      }
      else
      {
         while (*cptr && *inptr && toupper(*cptr) == toupper(*inptr))
         {
            cptr++;
            inptr++;
         }
      }

      if (ImpliedWildcards)
      {
         if (!*cptr)
         {
            if (Debug) fprintf (stdout, "1. matched!\n");
            if (MatchedLengthPtr != NULL) *MatchedLengthPtr = inptr - MatchPtr;
            return (MatchPtr);
         }
      }
      else
      {
         if (!*cptr && !*inptr)
         {
            if (Debug) fprintf (stdout, "2. matched!\n");
            if (MatchedLengthPtr != NULL) *MatchedLengthPtr = inptr - MatchPtr;
            return (MatchPtr);
         }
         if (*cptr != '*' && *cptr != '%')
         {
            if (Debug && !*inptr) fprintf (stdout, "3. NOT matched!\n");
            return (NULL);
         }
      }

      if (*cptr != '*' && *cptr != '%')
      {
         if (!*inptr)
         {
            if (Debug) fprintf (stdout, "4. NOT matched!\n");
            return (NULL);
         }
         cptr = SearchFor;
         MatchPtr = ++inptr;
         continue;
      }

      if (*cptr == '%')
      {
         /* single char wildcard processing */
         if (!*inptr) break;
         cptr++;
         inptr++;
         continue;
      }

      /* asterisk wildcard matching */
      while (*cptr == '*') cptr++;

      /* an asterisk wildcard at end matches all following */
      if (!*cptr)
      {
         if (Debug) fprintf (stdout, "5. matched!\n");
         while (*inptr) inptr++;
         if (MatchedLengthPtr != NULL) *MatchedLengthPtr = inptr - MatchPtr;
         return (MatchPtr);
      }

      /* note the current position in the string (first after the wildcard) */
      RestartCptr = cptr;
      for (;;)
      {
         /* find first char in SearchIn matching char after wildcard */
         if (CaseSensitive)
            while (*inptr && *cptr != *inptr) inptr++;
         else
            while (*inptr && toupper(*cptr) != toupper(*inptr)) inptr++;
         /* if did not find matching char in SearchIn being searched */
         if (Debug && !*inptr) fprintf (stdout, "6. NOT matched!\n");
         if (!*inptr) return (NULL);
         /* note the current position in SearchIn being searched */
         RestartInptr = inptr;
         /* try to match the remainder of the string and SearchIn */
         if (CaseSensitive)
         {
            while (*cptr && *inptr && *cptr == *inptr)
            {
               cptr++;
               inptr++;
            }
         }
         else
         {
            while (*cptr && *inptr && toupper(*cptr) == toupper(*inptr))
            {
               cptr++;
               inptr++;
            }
         }
         /* if reached the end of both string and SearchIn - match! */
         if (ImpliedWildcards)
         {
            if (!*cptr)
            {
               if (Debug) fprintf (stdout, "7. matched!\n");
               if (MatchedLengthPtr != NULL)
                  *MatchedLengthPtr = inptr - MatchPtr;
               return (MatchPtr);
            }
         }
         else
         {
            if (!*cptr && !*inptr)
            {
               if (Debug) fprintf (stdout, "8. matched!\n");
               if (MatchedLengthPtr != NULL)
                  *MatchedLengthPtr = inptr - MatchPtr;
               return (MatchPtr);
            }
         }
         /* break to the external loop if we encounter another wildcard */
         if (*cptr == '*' || *cptr == '%') break;
         /* lets have another go */
         cptr = RestartCptr;
         /* starting the character following the previous attempt */
         inptr = MatchPtr = RestartInptr + 1;
      }
   }
}

/****************************************************************************/
/*
Copies null-terminated string 'SourcePtr' to 'DestinationPtr'.  Copies no more
than 'SizeOfDestination'-1 then terminates with a null character, effectively
truncating the string.  Returns length of copied string.
*/ 

boolean strzcpy
(
char *DestinationPtr,
char *SourcePtr,
int SizeOfDestination
)
{
   register char  *cptr, *sptr, *zptr;

   /*********/
   /* begin */
   /*********/

   zptr = (sptr = DestinationPtr) + SizeOfDestination - 1;
   for (cptr = SourcePtr; *cptr && sptr < zptr; *sptr++ = *cptr++);
   *sptr = '\0';
   return (sptr - DestinationPtr);
}

/*****************************************************************************/
/*
Just return the process' current BYTLM quota.
*/ 

GetJpiBytLm ()

{
   static unsigned long  Pid = 0;

   static unsigned long  JpiBytLm;
   static struct
   {
      unsigned short  buf_len;
      unsigned short  item;
      unsigned char   *buf_addr;
      unsigned short  *short_ret_len;
   }
      JpiItems [] =
   {
      { sizeof(JpiBytLm), JPI$_BYTLM, &JpiBytLm, 0 },
      {0,0,0,0}
   };

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "GetJpiBytLm()\n");

   if (VMSok (status = sys$getjpiw (0, &Pid, 0, &JpiItems, 0, 0, 0)))
      return (JpiBytLm);
   ErrorExitVmsStatus (status, "sys$getjpiw()", FI_LI);
}

/****************************************************************************/
/*
Does a case-insensitive, character-by-character string compare and returns 
true if two strings are the same, or false if not.  If a maximum number of 
characters are specified only those will be compared, if the entire strings 
should be compared then specify the number of characters as 0.
*/ 
 
boolean strsame
(
register char *sptr1,
register char *sptr2,
register int  count
)
{
   /*********/
   /* begin */
   /*********/

/**
   if (Debug) fprintf (stdout, "strsame() |%s|%s| %d\n", sptr1, sptr2, count);
**/

   while (*sptr1 && *sptr2)
   {
      if (toupper (*sptr1++) != toupper (*sptr2++)) return (false);
      if (count)
         if (!--count) return (true);
   }
   if (*sptr1 || *sptr2)
      return (false);
   else
      return (true);
}
 
/****************************************************************************/

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         