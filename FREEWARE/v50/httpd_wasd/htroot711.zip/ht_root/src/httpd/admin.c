/*****************************************************************************/
/*
                                Admin.c

Server administration support functions for HTTPd.  Many of the reports and
forms used for revision are produced by functions within the core-function
module.  The control function allow server restart, exit, abort, mapping file
reload, authorization path reload and authentication cache purging.


VERSION HISTORY
---------------
02-OCT-2000  MGD  DETACH now an allowed privilege
13-SEP-2000  MGD  ProxyMainReport() call refined
26-AUG-2000  MGD  consolidated WATCH processing and peek
18-JUN-2000  MGD  "All Services" directives,
                  site log item,
                  service configuration,
                  add a little JavaScript to enhance the admin menu
28-MAY-2000  MGD  use $getjpi ...lm values from server startup
04-MAR-2000  MGD  use NetWriteFaol(), et.al.
13-JAN-2000  MGD  improve log messages, add OPCOM messaging
30-OCT-1999  MGD  unbundled WATCH functionality to its own module
10-OCT-1999  MGD  show process report,
                  move service statistics report to NET.C module,
                  CacheReport() now only optionally reports cached files
04-SEP-1999  MGD  remove WatchRequestHeader()
11-JUN-1999  MGD  bugfix; WatchFilter()
12-APR-1999  MGD  WatchDataDump() for request and response bodies
10-JAN-1999  MGD  add proxy items to WATCH menu,
                  add proxy report
07-NOV-1998  MGD  WATCH facility
16-MAR-1998  MGD  server abort changed to "exit NOW", added "restart NOW"
05-OCT-1997  MGD  file cache
28-SEP-1997  MGD  request durations
06-SEP-1997  MGD  service list
09-AUG-1997  MGD  message database
07-JUL-1997  MGD  activity report and logging control functions,
                  reworked the control function (it was getting untidy)
08-JUN-1997  MGD  "Other" menu item, with "Clients" and "Scripting" reports,
                  AdminRequestReport() and DclScriptingReport() functions
01-FEB-1997  MGD  new for HTTPd version 4
*/
/*****************************************************************************/

/* standard C header files */
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdarg.h>

/* VMS related header files */
#include <descrip.h>
#include <jpidef.h>
#include <libdef.h>
#include <libdtdef.h>
#include <prvdef.h>
#include <ssdef.h>
#include <stsdef.h>
#include <syidef.h>

/* application related header files */
#include "wasd.h"

#define WASD_MODULE "ADMIN"

/******************/
/* global storage */
/******************/

char  ErrorControlDoAll [] = "Directives to all servers \
(/DO=/ALL) not enabled.",
      ErrorLoggingNotEnabled [] = "Logging is not currently enabled.",
      ErrorLoggingAlreadyEnabled [] = "Logging is already enabled.";

/********************/
/* external storage */
/********************/

#ifdef DBUG
extern boolean Debug;
#else
#define Debug 0 
#endif

extern boolean  CacheEnabled,
                ControlDoAllEnabled,
                ControlExitRequested,
                ControlRestartRequested,
                LoggingEnabled,
                MonitorEnabled,
                OperateWithSysPrv,
                ProtocolHttpsConfigured;

extern int  CacheHits0,
            CacheHits10,
            CacheHits100,
            CacheHits100plus,
            CacheHitCount,
            CacheLoadCount,
            CacheMemoryInUse,
            CacheTotalKBytesMax,
            ConnectCountCurrent,
            ExitStatus,
            HttpdJpiAstLm,
            HttpdJpiBioLm,
            HttpdJpiBytLm,
            HttpdJpiDioLm,
            HttpdJpiEnqLm,
            HttpdJpiFilLm,
            HttpdJpiPgFlQuo,
            HttpdJpiPrcLm,
            HttpdJpiTqLm,
            OpcomMessages,
            ProxyServiceCount,
            RequestHistoryMax,
            WatchDisabled,
            WatchEnabled;

extern unsigned long  HttpdProcessId;

extern unsigned long  HttpdStartBinTime[];

extern char  BuildInfo[],
             ErrorSanityCheck[],
             HttpdUserName[],
             ServerHostPort[],
             SoftwareID[],
             TimeGmtString[],
             Utility[];

extern struct AccountingStruct Accounting;
extern struct ConfigStruct  Config;
extern struct MsgStruct  Msgs;
extern struct ProxyAccountingStruct ProxyAccounting;

/*****************************************************************************/
/*
*/ 

AdminBegin
(
struct RequestStruct *rqptr,
void *NextTaskFunction
)
{
   register char  *cptr;

   boolean  UseServerDatabase,
            ControlDoAll;
   int  status;
   unsigned short  Length;
   char  FieldName [128],
         FieldValue [256],
         FilePath [ODS_MAX_FILE_NAME_LENGTH+1],
         NumberString [16],
         Path [ODS_MAX_FILE_NAME_LENGTH+1],
         ProcessIdString [16],
         ProcessIdUserName [13],
         VirtualHostNamePort [256];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AdminBegin()\n");

   if (rqptr->WatchItem &&
       (WatchEnabled & WATCH_RESPONSE))
      WatchThis (rqptr, FI_LI, WATCH_RESPONSE,
                      "ADMIN !AZ", rqptr->rqHeader.PathInfoPtr);

   if (!rqptr->AccountingDone)
      rqptr->AccountingDone = ++Accounting.DoServerAdminCount;

   if (!rqptr->RemoteUser[0])
   {
      rqptr->rqResponse.HttpStatus = 403;
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_AUTH_REQUIRED), FI_LI);
      SysDclAst (NextTaskFunction, rqptr);
      return;
   }

   /********************************************/
   /* modules that parse their own query field */
   /********************************************/

   if (strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REVISE_HTA,
                sizeof(ADMIN_REVISE_HTA)-1))
   {
      HTAdminBegin (rqptr, NextTaskFunction);
      return;
   }

   if (strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REPORT_ACTIVITY, -1))
   {
      GraphActivityReport (rqptr, NextTaskFunction);
      return;
   }

   if (strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_GRAPHIC_ACTIVITY, -1))
   {
      GraphActivityPlotBegin (rqptr, NextTaskFunction);
      return;
   }

   if (strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REPORT_PROCESS, -1))
   {
      WatchProcessReport (rqptr, NextTaskFunction);
      return;
   }

   if (strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REPORT_WATCH, -1))
   {
      if (rqptr->rqHeader.QueryStringLength)
         WatchBegin (rqptr, NextTaskFunction);
      else
         WatchReport (rqptr, NextTaskFunction);
      return;
   }

   if (strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_CONTROL_DELETE_PROCESS, -1))
   {
      /********************/
      /* delete a process */
      /********************/

      WatchDeleteProcess (rqptr, NextTaskFunction);
      return;
   }

   /**********************/
   /* parse query string */
   /**********************/

   ControlDoAll = false;
   UseServerDatabase = true;
   FilePath[0] =
      Path[0] =
      ProcessIdString[0] =
      ProcessIdUserName[0] =
      VirtualHostNamePort[0] = '\0';

   cptr = rqptr->rqHeader.QueryStringPtr;
   while (*cptr)
   {
      cptr = ParseQueryField (rqptr, cptr,
                              FieldName, sizeof(FieldName),
                              FieldValue, sizeof(FieldValue),
                              FI_LI);
      if (cptr == NULL)
      {
         /* error occured */
         SysDclAst (NextTaskFunction, rqptr);
         return;
      }

      if (strsame (FieldName, "file", -1))
      {
         if (toupper(FieldValue[0]) == 'Y')
            UseServerDatabase = false;
         else
         if (toupper(FieldValue[0]) == 'N')
            UseServerDatabase = true;
      }
      else
      if (strsame (FieldName, "virtual", -1))
         strzcpy (VirtualHostNamePort, FieldValue, sizeof(VirtualHostNamePort));
      else
      if (strsame (FieldName, "server", -1))
      {
         if (toupper(FieldValue[0]) == 'Y')
            UseServerDatabase = true;
         else
         if (toupper(FieldValue[0]) == 'N')
            UseServerDatabase = false;
      }
      else
      if (strsame (FieldName, "edit", -1))
         strzcpy (FilePath, FieldValue, sizeof(FilePath));
      else
      if (strsame (FieldName, "path", -1))
         strzcpy (Path, FieldValue, sizeof(Path));
      else
      if (strsame (FieldName, "pid", -1))
         strzcpy (ProcessIdString, FieldValue, sizeof(ProcessIdString));
      else
      if (strsame (FieldName, "puser", -1))
         strzcpy (ProcessIdUserName, FieldValue, sizeof(ProcessIdUserName));
      else
      if (strsame (FieldName, "at", -1) ||
          strsame (FieldName, "this", -1))
         strzcpy (NumberString, FieldValue, sizeof(NumberString));
      else
      if (strsame (FieldName, "doall", -1))
         ControlDoAll = true;
      else
      {
         rqptr->rqResponse.HttpStatus = 400;
         ErrorGeneral (rqptr, "Unknown query field.", FI_LI);
         SysDclAst (NextTaskFunction, rqptr);
         return;
      }
   }

   /***************/
   /* do function */
   /***************/

   if (strsame (rqptr->rqHeader.PathInfoPtr, HTTPD_ADMIN, -1) ||
       strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REPORT, -1) ||
       strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REVISE, -1) ||
       strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_CONTROL, -1))
   {
      /********/
      /* menu */
      /********/

      AdminMenu (rqptr, NextTaskFunction);
      return;
   }
   else
   if (strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REPORT,
                sizeof(ADMIN_REPORT)-1))
   {
      /***********/
      /* reports */
      /***********/

      if (strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REPORT_AUTH_USER, -1))
      {
         AuthCacheTreeReport (rqptr, NextTaskFunction);
         return;
      }
      else
      if (strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REPORT_CACHE, -1))
      {
         CacheReport (rqptr, NextTaskFunction, false);
         return;
      }
      else
      if (strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REPORT_CACHE_ENTRIES, -1))
      {
         CacheReport (rqptr, NextTaskFunction, true);
         return;
      }
      else
      if (strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REPORT_CONFIG, -1))
      {
         ConfigReport (rqptr, NextTaskFunction, UseServerDatabase);
         return;
      }
      else
      if (strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REPORT_DCL, -1))
      {
         DclScriptingReport (rqptr, NextTaskFunction);
         return;
      }
      else
      if (strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REPORT_PROCESS, -1))
      {
         WatchShowProcess (rqptr, NextTaskFunction,
                           ProcessIdString, ProcessIdUserName);
         return;
      }
      else
      if (strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REPORT_DECNET, -1))
      {
         DECnetScriptingReport (rqptr, NextTaskFunction);
         return;
      }
      else
      if (strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REPORT_MEMORY, -1))
      {
         VmReport (rqptr, NextTaskFunction);
         return;
      }
      else
      if (strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REPORT_MESSAGES, -1))
      {
         MsgReport (rqptr, NextTaskFunction, UseServerDatabase);
         return;
      }
      else
      if (strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REPORT_AUTH_PATHS, -1))
      {
         AuthConfigReport (rqptr, NextTaskFunction,
                           UseServerDatabase, VirtualHostNamePort);
         return;
      }
      else
      if (strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REPORT_PROXY, -1))
      {
         ProxyMaintReport (rqptr, NextTaskFunction, false);
         return;
      }
      else
      if (strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REPORT_PROXY_HOSTCACHE, -1))
      {
         ProxyMaintReport (rqptr, NextTaskFunction, true);
         return;
      }
      else
      if (strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REPORT_REQUEST, -1))
      {
         RequestReport (rqptr, NextTaskFunction, false);
         return;
      }
      else
      if (strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REPORT_REQUEST_HISTORY, -1))
      {
         RequestReport (rqptr, NextTaskFunction, true);
         return;
      }
      else
      if (strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REPORT_SERVICES, -1))
      {
         ServiceReport (rqptr, NextTaskFunction, UseServerDatabase);
         return;
      }
      else
      if (strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REPORT_SHOW_PROCESS, -1))
      {
         WatchShowProcess (rqptr, NextTaskFunction,
                           ProcessIdString, ProcessIdUserName);
         return;
      }
      else
      if (strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REPORT_STATS, -1))
      {
         AdminReportServerStats (rqptr, NextTaskFunction);
         return;
      }
      else
      if (strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REPORT_MAPPING, -1))
      {
         MapUrl_Report (rqptr, NextTaskFunction,
                        UseServerDatabase, VirtualHostNamePort);
         return;
      }
      else
      if (strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REPORT_SSL, -1))
      {
         SeSoLaReport (rqptr, NextTaskFunction);
         return;
      }
   }
   else
   if (strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REVISE,
                sizeof(ADMIN_REVISE)-1))
   {
      /**************************/
      /* configuration/revision */
      /**************************/

      if (strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REVISE_CONFIG, -1))
      {
         ConfigRevise (rqptr, NextTaskFunction, UseServerDatabase);
         return;
      }
      else
      if (strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REVISE_SERVICES, -1))
      {
         ServiceConfigRevise (rqptr, NextTaskFunction, UseServerDatabase);
         return;
      }
      else
      if (strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REVISE_MESSAGES, -1))
      {
         MsgRevise (rqptr, NextTaskFunction, UseServerDatabase);
         return;
      }
      else
      if (strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_REVISE_HTA, -1))
      {
         AuthConfigReport (rqptr, NextTaskFunction,
                           UseServerDatabase, VirtualHostNamePort);
         return;
      }
   }
   else
   if (strsame (rqptr->rqHeader.PathInfoPtr, ADMIN_CONTROL,
                sizeof(ADMIN_CONTROL)-1))
   {
      /******************/
      /* server control */
      /******************/

      AdminControl (rqptr, NextTaskFunction, ControlDoAll);
      return;
   }

   /********************/
   /* unknown function */
   /********************/

   rqptr->rqResponse.HttpStatus = 400;
   ErrorGeneral (rqptr, "Unknown function.", FI_LI);
   SysDclAst (NextTaskFunction, rqptr);
}

/*****************************************************************************/
/*
Provide a menu of HTTPd server administration functions.
*/ 

AdminMenu
(
struct RequestStruct *rqptr,
void *NextTaskFunction
)
{
   char  ResponseFao [] =
"<HTML>\n\
<HEAD>\n\
!AZ\
<TITLE>HTTPd !AZ ... Server Administration Menu</TITLE>\n\
<SCRIPT LANGUAGE=\"JavaScript\">\n\
<!!--\n\
function doIt(link,doing) {\n\
!%%\
   if (doing == \"restart\") return \
confirm (\"Restart \" + scope + \" after allowing current requests to complete?\");\n\
   if (doing == \"restartNow\") return \
confirm (\"Restart \" + scope + \" DISCONNECTING current requests?\");\n\
   if (doing == \"exit\") return \
confirm (\"Exit \" + scope + \" allowing current requests to complete?\");\n\
   if (doing == \"exitNow\") return \
confirm (\"Exit \" + scope + \" DISCONNECTING current requests?\");\n\
   return true;\n\
}\n\
// -->\n\
</SCRIPT>\n\
</HEAD>\n\
!AZ\n\
<H2><NOBR>HTTPd !AZ</NOBR></H2>\n\
<H3>Server Administration Menu</H3>\n\
<P>\n\
\
<FORM NAME=doallForm>\n\
\
<TABLE CELLPADDING=5 CELLSPACING=0 BORDER=1>\n\
\
<TR><TH COLSPAN=2>Configuration</TH><TR>\n\
\
<TD COLSPAN=2 ALIGN=center VALIGN=top>\n\
\
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=0>\n\
\
<TR><TD></TD><TD>|</TD>\
<TH COLSPAN=2>Report</TH><TD>|</TD>\n\
<TH COLSPAN=3>Revise</TH><TD>|</TD>\n\
<TH>&nbsp;Action</TH><TD>|</TD><TR>\n\
\
<TR>\n\
<TH>Server</TH>\n\
<TD>&nbsp;</TD>\n\
<TD COLSPAN=2 ALIGN=left>[<A HREF=\"!AZ\">Statistics</A>]</TD>\n\
<TD>&nbsp;</TD>\n\
<TD COLSPAN=2 ALIGN=right>[<A HREF=\"!AZ!AZ?as=entry\">Site-Log</A>]</TD>\n\
<TD>[<A HREF=\"!AZ!AZ\">Edit</A>]</TD>\n\
<TD>&nbsp;</TD>\n\
<TD>[<A HREF=\"!AZ\" onClick=\"return doIt(this,null)\">Zero</A>]</TD>\n\
</TR>\n\
\
<TR>\n\
<TH>Configuration</TH>\n\
<TD>&nbsp;</TD>\n\
<TD>[<A HREF=\"!AZ?server=yes\">Server</A>]</TD>\n\
<TD>[<A HREF=\"!AZ?file=yes\">File</A>]</TD>\n\
<TD>&nbsp;</TD>\n\
<TD ALIGN=right>[<A HREF=\"!AZ?server=yes\">Server</A>]</TD>\n\
<TD ALIGN=right>[<A HREF=\"!AZ?file=yes\">File</A>]</TD>\n\
<TD>[<A HREF=\"!AZ!AZ\">Edit</A>]</TD>\n\
</TR>\n\
\
<TR>\n\
<TH>Services</TH>\n\
<TD>&nbsp;</TD>\n\
<TD>[<A HREF=\"!AZ?server=yes\">Server</A>]</TD>\n\
<TD>[<A HREF=\"!AZ?file=yes\">File</A>]</TD>\n\
<TD>&nbsp;</TD>\n\
<TD ALIGN=right>[<A HREF=\"!AZ?server=yes\">Server</A>]</TD>\n\
<TD ALIGN=right>[<A HREF=\"!AZ?file=yes\">File</A>]</TD>\n\
<TD>[<A HREF=\"!AZ!AZ\">Edit</A>]</TD>\n\
</TR>\n\
\
<TR>\n\
<TH>Messages</TH>\n\
<TD>&nbsp;</TD>\n\
<TD>[<A HREF=\"!AZ?server=yes\">Server</A>]</TD>\n\
<TD>[<A HREF=\"!AZ?file=yes\">File</A>]</TD>\n\
<TD>&nbsp;</TD>\n\
<TD ALIGN=right>[<A HREF=\"!AZ?server=yes\">Server</A>]</TD>\n\
<TD ALIGN=right>[<A HREF=\"!AZ?file=yes\">File</A>]</TD>\n\
<TD>[<A HREF=\"!AZ!AZ\">Edit</A>]</TD>\n\
<TD>&nbsp;</TD>\n\
<TD>&nbsp;</TD>\n\
</TR>\n\
\
<TR>\n\
<TH>Mapping Rules</TH>\n\
<TD>&nbsp;</TD>\n\
<TD>[<A HREF=\"!AZ?server=yes\">Server</A>]</TD>\n\
<TD>[<A HREF=\"!AZ?file=yes\">File</A>]</TD>\n\
<TD>&nbsp;</TD>\n\
<TD>&nbsp;</TD>\n\
<TD>&nbsp;</TD>\n\
<TD>[<A HREF=\"!AZ!AZ\">Edit</A>]</TD>\n\
<TD>&nbsp;</TD>\n\
<TD>[<A HREF=\"!AZ\" onClick=\"return doIt(this,null)\">Reload</A>]</TD>\n\
</TR>\n\
\
<TR>\n\
<TH>Path Authorization</TH>\n\
<TD>&nbsp;</TD>\n\
<TD>[<A HREF=\"!AZ?server=yes\">Server</A>]</TD>\n\
<TD>[<A HREF=\"!AZ?file=yes\">File</A>]</TD>\n\
<TD>&nbsp;</TD>\n\
<TD>&nbsp;</TD>\n\
<TD>&nbsp;</TD>\n\
<TD>[<A HREF=\"!AZ!AZ\">Edit</A>]</TD>\n\
<TD>&nbsp;</TD>\n\
<TD>[<A HREF=\"!AZ\" onClick=\"return doIt(this,null)\">Reload</A>]</TD>\n\
</TR>\n\
\
<TR>\n\
<TH>User Authentication</TH>\n\
<TD>&nbsp;</TD>\n\
<TD>[<A HREF=\"!AZ\">Server</A>]</TD>\n\
<TD>&nbsp;</TD>\n\
<TD>&nbsp;</TD>\n\
<TD COLSPAN=2 ALIGN=right>[<A HREF=\"!AZ\">HTA</A>]</TD>\n\
<TD>&nbsp;</TD>\n\
<TD>&nbsp;</TD>\n\
<TD>[<A HREF=\"!AZ\" onClick=\"return doIt(this,null)\">Purge</A>]</TD>\n\
</TR>\n\
\
<TR>\n\
<TH>Other Reports</TH>\n\
<TD>&nbsp;</TD>\n\
<TD COLSPAN=8><NOBR>\n\
[<A HREF=\"!AZ\">Cache</A>]\n\
[<A HREF=\"!AZ\">DCL</A>]\n\
[<A HREF=\"!AZ\">DECnet</A>]\n\
[<A HREF=\"!AZ\">Memory</A>]\n\
[<A HREF=\"!AZ\">Process</A>]\n\
<BR>\n\
[!%%]\n\
[<A HREF=\"!AZ\">Request</A>]\n\
[!%%]\n\
[!%%]\n\
<BR>\n\
[!%%!%%!%%!%%!%%!%%!%%!%%<FONT SIZE=-1>hours activity</FONT>]\n\
</NOBR></TD></TR>\n\
\
</TABLE>\n\
\
<TR>\n\
<TH><FONT COLOR=\"#ff0000\">Control</FONT></TH>\n\
\
<TD ROWSPAN=2 ALIGN=CENTER VALIGN=top>\n\
\
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=0>\n\
<TR><TH COLSPAN=4 ALIGN=center VALIGN=top>\
<FONT SIZE=-1><NOBR>!20%W</NOBR></FONT></TH></TR>\n\
<TR><TD COLSPAN=4 ALIGN=center VALIGN=top>\
<FONT SIZE=-2><NOBR>!AZ (!AZ)</NOBR></FONT></TD></TR>\n\
\
<TR><TH></TH></TR>\n\
\
<TR><TH ROWSPAN=3 ALIGN=left VALIGN=top><FONT SIZE=-1>Times</FONT></TH>\n\
<TH ALIGN=right><FONT SIZE=-1>Server:</FONT></TH>\
<TD align=right><FONT SIZE=-1><NOBR>!%D</NOBR></FONT></TD></TR>\n\
\
<TH ALIGN=right><FONT SIZE=-1>Process:</FONT></TH>\
<TD align=right><FONT SIZE=-1><NOBR>!%D</NOBR></FONT></TD></TR>\n\
\
<TR><TH ALIGN=right><FONT SIZE=-1>CPU:</FONT></TH>\
<TD align=right><FONT SIZE=-1><NOBR>!UL !2ZL:!2ZL:!2ZL.!2ZL</NOBR></FONT></TD></TR>\n\
\
<TR><TH ROWSPAN=2 ALIGN=left VALIGN=top><FONT SIZE=-1>Requests&nbsp;</FONT></TH>\n\
<TH ALIGN=right><FONT SIZE=-1>Read:</FONT></TH>\
<TD align=right><FONT SIZE=-1>!,UL</FONT></TD></TR>\n\
\
<TR><TH ALIGN=right><FONT SIZE=-1>Write:</FONT></TH>\
<TD align=right><FONT SIZE=-1>!,UL</FONT></TD></TR>\n\
\
<TR><TH ROWSPAN=2 ALIGN=left VALIGN=top><FONT SIZE=-1>Bytes</FONT></TH>\n\
<TH ALIGN=right><FONT SIZE=-1>Rx:</FONT></TH>\
<TD align=right><FONT SIZE=-1>!,@SQ</FONT></TD></TR>\n\
\
<TR><TH ALIGN=right><FONT SIZE=-1>Tx:</FONT></TH>\
<TD align=right><FONT SIZE=-1>!,@SQ</FONT></TD></TR>\n\
\
</TABLE>\n\
\
</TD></TR>\n\
<TR><TD VALIGN=top>\n\
\
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=0>\n\
<TR><TD VALIGN=top ALIGN=left>\n\
\
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=0>\n\
<TR><TD><FONT SIZE=+1>[</FONT>\
<A HREF=\"!AZ\" onClick=\"return doIt(this,\'restart\')\">RESTART</A>\
<FONT SIZE=+1>]</FONT></TD></TR>\n\
<TR><TD><FONT SIZE=+1>[</FONT>\
<A HREF=\"!AZ\" onClick=\"return doIt(this,\'restartNow\')\">\
<FONT SIZE=-1>RESTART</FONT>NOW</A>\
<FONT SIZE=+1>]</FONT></TD></TR>\n\
<TR><TD><FONT SIZE=+1>[</FONT>\
<A HREF=\"!AZ\" onClick=\"return doIt(this,\'exit\')\">EXIT</A>\
<FONT SIZE=+1>]</FONT></TD></TR>\n\
<TR><TD><FONT SIZE=+1>[</FONT>\
<A HREF=\"!AZ\" onClick=\"return doIt(this,\'exitNow\')\">\
<FONT SIZE=-1>EXIT</FONT>NOW</A>\
<FONT SIZE=+1>]</FONT></TD></TR>\n\
</TABLE>\n\
\
</TD><TD>&nbsp;</TD><TD VALIGN=top>\n\
\
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=0>\n\
<TR><TD ALIGN=right><B>Log</B></TD><TD>!%%</TD></TR>\n\
<TR><TD ALIGN=right><B>Cache</B></TD><TD>!%%</TD></TR>\n\
<TR><TD ALIGN=right><B>Proxy</B></TD><TD>!%%</TD></TR>\n\
</TABLE>\n\
\
</TD></TR>\n\
\
!%%\
\
</TABLE>\n\
\
</TD></TR>\n\
</TABLE>\n\
\
</FORM>\n\
\
</BODY>\n\
</HTML>\n";

   static unsigned long  LibDeltaHours = LIB$K_DELTA_HOURS;

   static unsigned long  JpiCpuTime,
                         Pid = 0;
   static unsigned long  ProcessUpTime [2],
                         ImageUpTime [2],
                         CurrentTime [2],
                         JpiLoginTime [2];

   static struct
   {
      unsigned short  buf_len;
      unsigned short  item;
      unsigned char   *buf_addr;
      unsigned short  *short_ret_len;
   }
   JpiItems [] =
   {
      { sizeof(JpiCpuTime), JPI$_CPUTIM, &JpiCpuTime, 0 },
      { sizeof(JpiLoginTime), JPI$_LOGINTIM, &JpiLoginTime, 0 },
      {0,0,0,0}
   };

   register char  *cptr;
   register unsigned long  *vecptr;

   boolean  VmsMozilla3;
   int  status,
        ServerCount;
   unsigned short  Length;
   unsigned long  StartDeltaHours;
   unsigned long  FaoVector [128];
   char  *ServerListPtr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AdminMenu()\n");

   if (VMSnok (status = sys$getjpiw (0, &Pid, 0, &JpiItems, 0, 0, 0)))
   {
      rqptr->rqResponse.ErrorTextPtr = "sys$getjpiw()";
      ErrorVmsStatus (rqptr, status, FI_LI);
      SysDclAst (NextTaskFunction, rqptr);
      return;
   }

   sys$gettim (&CurrentTime);
   lib$sub_times (&CurrentTime, &HttpdStartBinTime, &ImageUpTime);
   lib$sub_times (&CurrentTime, &JpiLoginTime, &ProcessUpTime);
   lib$cvt_from_internal_time (&LibDeltaHours, &StartDeltaHours, &ImageUpTime);
   if (Debug) fprintf (stdout, "StartDeltaHours: %d\n", StartDeltaHours);

   /* get the number (if any) of other HTTP servers on this node/cluster */
   ServerListPtr = ControlAllHttpdList ("<BR>", &ServerCount);

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_ADMIN;
   HTTP_HEADER_200_HTML (rqptr);

   vecptr = FaoVector;

   *vecptr++ = HtmlMetaInfo (rqptr, NULL);
   *vecptr++ = ServerHostPort;

   if (ServerCount > 1)
   {
      /* this check must be omitted of the checkbox is omitted */
      *vecptr++ =
"   scope = \"this server\";\n\
   if (document.doallForm.doall.checked) {\n\
      if (link.href.indexOf(\"?\") >= 0) link.href = \
link.href.substring(0,link.href.indexOf(\"?\"));\n\
      link.href = link.href + \"?doall=yes\";\n\
      scope = \"all !UL servers\";\n\
   }\n";
      *vecptr++ = ServerCount;
   }
   else
      *vecptr++ = "scope = \"server\";\n";

   *vecptr++ = Config.cfServer.AdminBodyTag;
   *vecptr++ = ServerHostPort;

   /* statistics */
   *vecptr++ = ADMIN_REPORT_STATS;
   *vecptr++ = ADMIN_SCRIPT_UPD;
   *vecptr++ = ADMIN_REVISE_SITELOG;
   *vecptr++ = ADMIN_SCRIPT_UPD;
   *vecptr++ = ADMIN_REVISE_SITELOG;
   *vecptr++ = ADMIN_CONTROL_ZERO;

   /* configuration */
   *vecptr++ = ADMIN_REPORT_CONFIG;
   *vecptr++ = ADMIN_REPORT_CONFIG;
   *vecptr++ = ADMIN_REVISE_CONFIG;
   *vecptr++ = ADMIN_REVISE_CONFIG;
   *vecptr++ = ADMIN_SCRIPT_UPD;
   *vecptr++ = ADMIN_REVISE_CONFIG;

   /* services */
   *vecptr++ = ADMIN_REPORT_SERVICES;
   *vecptr++ = ADMIN_REPORT_SERVICES;
   *vecptr++ = ADMIN_REVISE_SERVICES;
   *vecptr++ = ADMIN_REVISE_SERVICES;
   *vecptr++ = ADMIN_SCRIPT_UPD;
   *vecptr++ = ADMIN_REVISE_SERVICES;

   /* messages */
   *vecptr++ = ADMIN_REPORT_MESSAGES;
   *vecptr++ = ADMIN_REPORT_MESSAGES;
   *vecptr++ = ADMIN_REVISE_MESSAGES;
   *vecptr++ = ADMIN_REVISE_MESSAGES;
   *vecptr++ = ADMIN_SCRIPT_UPD;
   *vecptr++ = ADMIN_REVISE_MESSAGES;

   /* mapping */
   *vecptr++ = ADMIN_REPORT_MAPPING;
   *vecptr++ = ADMIN_REPORT_MAPPING;
   *vecptr++ = ADMIN_SCRIPT_UPD;
   *vecptr++ = ADMIN_REVISE_MAPPING;
   *vecptr++ = ADMIN_CONTROL_MAPPING_LOAD;

   /* authorization */
   *vecptr++ = ADMIN_REPORT_AUTH_PATHS;
   *vecptr++ = ADMIN_REPORT_AUTH_PATHS;
   *vecptr++ = ADMIN_SCRIPT_UPD;
   *vecptr++ = ADMIN_REVISE_AUTH_PATHS;
   *vecptr++ = ADMIN_CONTROL_AUTH_LOAD;

   /* authentication */
   *vecptr++ = ADMIN_REPORT_AUTH_USER;
   *vecptr++ = ADMIN_REVISE_HTA;
   *vecptr++ = ADMIN_CONTROL_AUTH_PURGE;

   /* other */
   *vecptr++ = ADMIN_REPORT_CACHE;
   *vecptr++ = ADMIN_REPORT_DCL;
   *vecptr++ = ADMIN_REPORT_DECNET;
   *vecptr++ = ADMIN_REPORT_MEMORY;
   *vecptr++ = ADMIN_REPORT_PROCESS;

   /* proxy serving */
   if (ProxyServiceCount)
   {
      *vecptr++ = "<A HREF=\"!AZ\">Proxy</A>";
      *vecptr++ = ADMIN_REPORT_PROXY;
   }
   else
      *vecptr++ = "Proxy";

   /* request */
   *vecptr++ = ADMIN_REPORT_REQUEST;

   /* SSL */
   if (ProtocolHttpsConfigured)
   {
      *vecptr++ = "<A HREF=\"!AZ\">SSL</A>";
      *vecptr++ = ADMIN_REPORT_SSL;
   }
   else
      *vecptr++ = "SSL";

   /* WATCH facility */
   if (WatchDisabled)
      *vecptr++ = "WATCH";
   else
   {
      *vecptr++ = "<A HREF=\"!AZ\">WATCH</A>";
      *vecptr++ = ADMIN_REPORT_WATCH;
   }

   /* activity */
   if (Config.cfMisc.ActivityNumberOfDays)
   {
      *vecptr++ = "<A HREF=\"!AZ?1\">1</A>,\n";
      *vecptr++ = ADMIN_REPORT_ACTIVITY;
   }
   else
      *vecptr++ = "1, ";
   if (Config.cfMisc.ActivityNumberOfDays && StartDeltaHours >= 1)
   {
      *vecptr++ = "<A HREF=\"!AZ?2\">2</A>,\n";
      *vecptr++ = ADMIN_REPORT_ACTIVITY;
   }
   else
      *vecptr++ = "2, ";
   if (Config.cfMisc.ActivityNumberOfDays && StartDeltaHours >= 2)
   {
      *vecptr++ = "<A HREF=\"!AZ?4\">4</A>,\n";
      *vecptr++ = ADMIN_REPORT_ACTIVITY;
   }
   else
      *vecptr++ = "4, ";
   if (Config.cfMisc.ActivityNumberOfDays && StartDeltaHours >= 4)
   {
      *vecptr++ = "<A HREF=\"!AZ?12\">12</A>,\n";
      *vecptr++ = ADMIN_REPORT_ACTIVITY;
   }
   else
      *vecptr++ = "12, ";
   if (Config.cfMisc.ActivityNumberOfDays && StartDeltaHours >= 12)
   {
      *vecptr++ = "<A HREF=\"!AZ?24\">24</A>,\n";
      *vecptr++ = ADMIN_REPORT_ACTIVITY;
   }
   else
      *vecptr++ = "24, ";
   if (Config.cfMisc.ActivityNumberOfDays >= 3 && StartDeltaHours >= 24)
   {
      *vecptr++ = "<A HREF=\"!AZ?72\">72</A>,\n";
      *vecptr++ = ADMIN_REPORT_ACTIVITY;
   }
   else
      *vecptr++ = "72, ";
   if (Config.cfMisc.ActivityNumberOfDays >= 7 && StartDeltaHours >= 72)
   {
      *vecptr++ = "<A HREF=\"!AZ?168\">168</A>,\n";
      *vecptr++ = ADMIN_REPORT_ACTIVITY;
   }
   else
      *vecptr++ = "168, ";
   if (Config.cfMisc.ActivityNumberOfDays >= 28 && StartDeltaHours >= 168)
   {
      *vecptr++ = "<A HREF=\"!AZ?672\">672</A>\n";
      *vecptr++ = ADMIN_REPORT_ACTIVITY;
   }
   else
      *vecptr++ = "672 ";

   /* informational accounting */
   *vecptr++ = &rqptr->rqTime.Vms64bit;
   *vecptr++ = rqptr->rqTime.GmDateTime;
   *vecptr++ = TimeGmtString;
   *vecptr++ = &ImageUpTime;
   *vecptr++ = &ProcessUpTime;
   *vecptr++ = JpiCpuTime / 8640000;             /* CPU day */
   *vecptr++ = (JpiCpuTime % 8640000) / 360000;  /* CPU hour */
   *vecptr++ = (JpiCpuTime % 360000) / 6000;     /* CPU minute */
   *vecptr++ = (JpiCpuTime % 6000 ) / 100;       /* CPU second */
   *vecptr++ = JpiCpuTime % 100;                 /* CPU 10 milliseconds */
   *vecptr++ = Accounting.MethodGetCount +
               Accounting.MethodHeadCount;
   *vecptr++ = Accounting.MethodDeleteCount +
               Accounting.MethodPostCount +
               Accounting.MethodPutCount;
   *vecptr++ = &Accounting.QuadBytesRawRx;
   *vecptr++ = &Accounting.QuadBytesRawTx;

   /* server control menu items */
   *vecptr++ = ADMIN_CONTROL_RESTART;
   *vecptr++ = ADMIN_CONTROL_RESTART_NOW;
   *vecptr++ = ADMIN_CONTROL_EXIT;
   *vecptr++ = ADMIN_CONTROL_EXIT_NOW;

   /* logging control menu items */
   if (LoggingEnabled)
   {
      *vecptr++ =
"<NOBR>[On] [<A HREF=\"!AZ\" onClick=\"return doIt(this,null)\">Off</A>] \
[<A HREF=\"!AZ\" onClick=\"doIt(this,null)\">Flush</A>]</NOBR>";
      *vecptr++ = ADMIN_CONTROL_LOG_OFF;
      *vecptr++ = ADMIN_CONTROL_LOG_FLUSH;
   }
   else
   {
      *vecptr++ =
"<NOBR>[<A HREF=\"!AZ\" onClick=\"return doIt(this,null)\">On</A>] \
[Off] [Flush]</NOBR>";
      *vecptr++ = ADMIN_CONTROL_LOG_ON;
   }

   /* cache control menu items */
   if (CacheEnabled)
   {
      *vecptr++ =
"<NOBR>[On] [<A HREF=\"!AZ\" onClick=\"return doIt(this,null)\">Off</A>] \
[<A HREF=\"!AZ\" onClick=\"return doIt(this,null)\">Purge</A>]</NOBR>";
      *vecptr++ = ADMIN_CONTROL_CACHE_OFF;
      *vecptr++ = ADMIN_CONTROL_CACHE_PURGE;
   }
   else
   {
      *vecptr++ =
"<NOBR>[<A HREF=\"!AZ\" onClick=\"return doIt(this,null)\">On</A>] \
[Off] [Purge]</NOBR>";
      *vecptr++ = ADMIN_CONTROL_CACHE_ON;
   }

   /* proxy control  */
   if (ProxyServiceCount)
   {
      *vecptr++ = "<NOBR>[<A HREF=\"!AZ\">Adjust</A>]</NOBR>";
      *vecptr++ = ADMIN_CONTROL_PROXY_ADJUST;
   }
   else
      *vecptr++ = "<NOBR>[Adjust]</NOBR>";

   /* detect the original VMS Netscape 3.0 browser (see below) */
   if (ServerCount > 1 &&
       rqptr->rqHeader.UserAgentPtr != NULL &&
       strstr (rqptr->rqHeader.UserAgentPtr, "ozilla/3.") != NULL &&
       strstr (rqptr->rqHeader.UserAgentPtr, "VMS") != NULL)
      VmsMozilla3 = true;
   else
      VmsMozilla3 = false;

   if (ServerCount > 1 && VmsMozilla3)
   {
      /*
         The original VMS Netscape 3.0 browser JavaScript has problems
         formatting the JavaScript-driven output of the block below.
         Here just assume the browser's JavaScript is enabled, hard-wiring
         the JavaScript-driven multi-server functionality into the page.
      */
      *vecptr++ =
"\n\
<TR><TD COLSPAN=3 ALIGN=left>\n\
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=0>\n\
<TR><TH ALIGN=right VALIGN=top>\n\
<NOBR><INPUT TYPE=checkbox NAME=doall> All !UL Servers:&nbsp;</NOBR>\n\
</TH><TD ALIGN=left>\n\
<FONT SIZE=-1>!%%</FONT>\n\
</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
\n";
      *vecptr++ = ServerCount;
      *vecptr++ = ServerListPtr;
   }
   else
   if (ServerCount > 1)
   {
      *vecptr++ =
"<SCRIPT LANGUAGE=\"JavaScript\">\n\
<!!--\n\
document.write(\"\
<TR><TD COLSPAN=3 ALIGN=left>\\n\\\n\
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=0>\\n\\\n\
<TR><TH ALIGN=right VALIGN=top>\\n\\\n\
<NOBR><INPUT TYPE=checkbox NAME=doall> All !UL Servers:&nbsp;</NOBR>\\n\\\n\
</TH><TD ALIGN=left>\\n\\\n\
<FONT SIZE=-1>!%%</FONT>\\n\\\n\
</TD></TR>\\n\\\n\
</TABLE>\\n\\\n\
</TD></TR>\\n\");\n\
// -->\n\
</SCRIPT>\n\
";
      *vecptr++ = ServerCount;
      *vecptr++ = ServerListPtr;
   }
   else
      *vecptr++ = "";

   status = NetWriteFaol (rqptr, ResponseFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   SysDclAst (NextTaskFunction, rqptr);
}

/*****************************************************************************/
/*
Return report on the HTTPd server's activities.
*/ 

AdminReportServerStats
(
struct RequestStruct *rqptr,
void *NextTaskFunction
)
{
/* ALTPRI and SETPRI synonyms? */
#define IMAG_PRIV_0_ALLOWED \
    (~(PRV$M_ALTPRI | PRV$M_DETACH | PRV$M_PRMMBX | PRV$M_PSWAPM | \
       PRV$M_SYSNAM | PRV$M_SYSLCK | PRV$M_SYSPRV | PRV$M_WORLD))

#define IMAG_PRIV_1_ALLOWED (~(0x00000000))


/*
   VAX VMS does not seem to like "!@UQ" and must be made "!@UJ"!!!
   The VAX version not supporting this doesn't seem to be documented,
   but at run-time returns a %X00000014 status (%SYSTEM-F-BADPARAM).
   Implication: VAX version can only report a maximum of 2^32-1 bytes, or
   4,294,967,295 before overflow, AXP 2^64-1 (calculator gave an ERROR :^)
*/

   static char ResponseFao [] =
"<HTML>\n\
<HEAD>\n\
!AZ\
<TITLE>HTTPd !AZ ... Server Statistics</TITLE>\n\
</HEAD>\n\
!AZ\n\
<H2><NOBR>HTTPd !AZ</NOBR></H2>\n\
<H3>Server Statistics</H3>\n\
!20%W\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Software</TH></TD></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=RIGHT>Version:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=RIGHT>Build:</TH><TD>!AZ</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Server Process</TH></TD></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR>\
<TH ALIGN=RIGHT ALIGN=RIGHT>Name:</TH><TD>!AZ</TD>\
<TH ALIGN=RIGHT>PID:</TH><TD><A HREF=\"!AZ?pid=!8XL\">!8XL</A></TD>\
<TH ALIGN=RIGHT>User:</TH><TD>!AZ</TD>\
</TR>\n\
<TR>\
<TH ALIGN=RIGHT>AuthPriv:</TH><TD>!AZ</TD>\
<TH ALIGN=RIGHT>ImagPriv:</TH><TD>!AZ</TD>\
<TH ALIGN=RIGHT>CurPriv:</TH><TD>!AZ</TD>\
</TR>\n\
<TR>\
<TH ALIGN=RIGHT>Startup:</TH><TD>!UL</TD>\
<TH ALIGN=RIGHT>Last Exit:</TH><TD>!AZ</TD>\
<TH ALIGN=RIGHT>Zeroed:</TH><TD>!UL</TD>\
</TR>\n\
<TR>\
<TH ALIGN=RIGHT>Server:</TH><TD>!%D</TD>\
<TH ALIGN=RIGHT>Process:</TH><TD>!%D</TD>\
<TH ALIGN=RIGHT>CPU:</TH><TD>!UL !2ZL:!2ZL:!2ZL.!2ZL</TD>\n\
</TR>\n\
<TR>\
<TH ALIGN=RIGHT>Pg.Faults:</TH><TD>!UL</TD>\n\
<TH ALIGN=RIGHT>Pg.Used:</TH><TD>!UL%</TD>\
</TR>\n\
<TR>\
<TH ALIGN=RIGHT>WsSize:</TH><TD>!UL</TD>\
<TH ALIGN=RIGHT>WsPeak:</TH><TD>!UL</TD>\n\
<TH ALIGN=RIGHT>PeakVirt:</TH><TD>!UL</TD>\
</TR>\n\
<TR>\
<TH ALIGN=RIGHT>AST:</TH><TD>!UL / !UL</TD>\
<TH ALIGN=RIGHT>BIO:</TH><TD>!UL / !UL</TD>\
<TH ALIGN=RIGHT>BYT:</TH><TD>!UL / !UL</TD>\
</TR>\n\
<TR>\
<TH ALIGN=RIGHT>DIO:</TH><TD>!UL / !UL</TD>\
<TH ALIGN=RIGHT>ENQ:</TH><TD>!UL / !UL</TD>\
<TH ALIGN=RIGHT>FIL:</TH><TD>!UL / !UL</TD>\
</TR>\n\
<TR>\
<TH ALIGN=RIGHT>PRC:</TH><TD>!UL / !UL</TD>\
<TH ALIGN=RIGHT>TQ:</TH><TD>!UL / !UL</TD>\n\
</TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n";

   static char  StatisticsFao [] =
"<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Server Processing</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=0 CELLSPACING=0 BORDER=0>\n\
<TR><TD VALIGN=top>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right><U>Connection</U></TH></TR>\n\
<TR><TH ALIGN=RIGHT>Total:</TH><TD>!UL</TD></TR>\n\
<TR><TH ALIGN=RIGHT>Accepted:</TH><TD>!UL</TD></TR>\n\
<TR><TH ALIGN=RIGHT>Rejected:</TH><TD>!UL</TD></TR>\n\
<TR><TH ALIGN=RIGHT>Current:</TH><TD>!UL</TD></TR>\n\
<TR><TH ALIGN=RIGHT>Peak:</TH><TD>!UL</TD></TR>\n\
<TR><TH ALIGN=RIGHT>Busy:</TH><TD>!UL</TD></TR>\n\
<TR><TH ALIGN=RIGHT>SSL:</TH><TD>!UL</TD></TR>\n\
</TABLE>\n\
</TD><TD VALIGN=top>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right><U>Request</U></TH></TR>\n\
<TR><TH ALIGN=right>Total:</TH><TD>!UL</TD></TR>\n\
<TR><TH ALIGN=right>Parsed:</TH><TD>!UL</TD></TR>\n\
<TR><TH ALIGN=right>Error:</TH><TD>!UL</TD></TR>\n\
<TR><TH ALIGN=right>Forbidden:</TH><TD>!UL</TD></TR>\n\
<TR><TH ALIGN=right>Redirect:</TH>\
<TD>!UL / !UL &nbsp;<FONT SIZE=-1><I>(rem/loc)</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>Keep-Alive:</TH>\
<TD>!UL / !UL &nbsp;<FONT SIZE=-1><I>(total/max)</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>No-cache:</TH>\
<TD>!UL &nbsp;<FONT SIZE=-1><I>(Pragma:)</I></FONT></TD></TR>\n\
<TR><TH ALIGN=RIGHT>Total Rx:</TH><TD>!,@SQ</TD></TR>\n\
<TR><TH ALIGN=RIGHT>Tx:</TH><TD>!,@SQ</TD></TR>\n\
</TABLE>\n\
</TD><TD VALIGN=top>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right><U>Method</U></TH></TR>\n\
<TR><TH ALIGN=right>GET:</TH><TD>!UL</TD></TR>\n\
<TR><TH ALIGN=right>HEAD:</TH><TD>!UL</TD></TR>\n\
<TR><TH ALIGN=right>POST:</TH><TD>!UL</TD></TR>\n\
<TR><TH ALIGN=right>PUT:</TH><TD>!UL</TD></TR>\n\
</TABLE>\n\
</TD><TD VALIGN=top>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right><U>Response</U></TH></TR>\n\
<TR><TH ALIGN=right><I>1nn</I>:</TH><TD>!UL</TD></TR>\n\
<TR><TH ALIGN=right>2nn:</TH><TD>!UL</TD></TR>\n\
<TR><TH ALIGN=right>3nn:</TH><TD>!UL</TD></TR>\n\
<TR><TH ALIGN=right>4nn:</TH><TD>!UL</TD></TR>\n\
<TR><TH ALIGN=right>5nn:</TH><TD>!UL</TD></TR>\n\
<TR><TH ALIGN=right><I>none</I>:</TH><TD>!UL</TD></TR>\n\
</TABLE>\n\
</TD><TD VALIGN=top>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right><U>Duration</U></TH></TR>\n\
<TR><TH ALIGN=right>Min:</TH><TD ALIGN=right>!UL.!#ZL</TD></TR>\n\
<TR><TH ALIGN=right>Max:</TH><TD ALIGN=right>!UL.!#ZL</TD></TR>\n\
<TR><TH ALIGN=right>Ave:</TH><TD ALIGN=right>!UL.!#ZL</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Server Modules</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=0 CELLSPACING=0 BORDER=0>\n\
<TR><TD VALIGN=top>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right COLSPAN=2>Admin:</TH><TD>!UL</TD></TR>\n\
<TR><TH ALIGN=right COLSPAN=2>Directory:</TH><TD>!UL</TD></TR>\n\
<TR><TH ALIGN=right COLSPAN=2>File:</TH>\
<TD COLSPAN=2>!UL / !UL &nbsp;<FONT SIZE=-1><I>(all/304)</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right COLSPAN=2>IsMap:</TH><TD>!UL</TD></TR>\n\
<TR><TH ALIGN=right COLSPAN=2>Menu:</TH><TD>!UL</TD></TR>\n\
<TR><TH ALIGN=right COLSPAN=2>Put:</TH><TD>!UL</TD></TR>\n\
<TR><TH ALIGN=right COLSPAN=2>Proxy:</TH><TD COLSPAN=2>!UL</TD></TR>\n\
<TR><TH ALIGN=right COLSPAN=2>SSI:</TH><TD>!UL</TD></TR>\n\
<TR><TH ALIGN=right COLSPAN=2>Update:</TH><TD>!UL</TD></TR>\n\
</TABLE>\n\
</TD><TD VALIGN=top>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right><U>DCL</U></TH></TR>\n\
<TR><TH ALIGN=right>CGI-script:</TH><TD>!UL</TD></TR>\n\
<TR><TH ALIGN=right>CGIplus-script:</TH>\
<TD>!UL / !UL &nbsp;<FONT SIZE=-1><I>(all/reused)</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>RTE-script:</TH>\
<TD>!UL / !UL &nbsp;<FONT SIZE=-1><I>(all/reused)</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>Autoscripted:</TH><TD>!UL</TD></TR>\n\
<TR><TH ALIGN=right>CLI:</TH><TD>!UL</TD></TR>\n\
<TR><TH ALIGN=right>Processes Created:</TH><TD>!UL</TD></TR>\n\
</TABLE>\n\
</TD><TD VALIGN=top>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right><U>DECnet</U></TH></TR>\n\
<TR><TH ALIGN=right>Connect:</TH>\
<TD>!UL / !UL &nbsp;<FONT SIZE=-1><I>(all/fail)</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>CGI-script:</TH><TD>!UL</TD></TR>\n\
<TR><TH ALIGN=right>OSU-script:</TH><TD>!UL</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>File Cache</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right>Memory:</TH>\
<TD COLSPAN=2>!UL / !UL kB\
 &nbsp;<FONT SIZE=-1><I>(cur/max)</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>Loads:</TH><TD>!UL</TD></TR>\n\
<TR><TH ALIGN=right>Not Hit:</TH><TD>!UL</TD><TD>!UL%</TD></TR>\n\
<TR><TH ALIGN=right>Total Hit:</TH><TD>!UL</TD><TD>!UL%</TD></TR>\n\
<TR><TH ALIGN=right>1-9:</TH><TD>!UL</TD><TD>!UL%</TD></TR>\n\
<TR><TH ALIGN=right>10-99:</TH><TD>!UL</TD><TD>!UL%</TD></TR>\n\
<TR><TH ALIGN=right>&gt;100:</TH><TD>!UL</TD><TD>!UL%</TD></TR>\n\
<TR><TD COLSPAN=3><FONT SIZE=-1>\
<SUP>*</SUP><I>counts are per-startup only</I></FONT></TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Authorization</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=0 CELLSPACING=0 BORDER=0>\n\
<TR><TH><U>Paths</U></TH><TH COLSPAN=2><U>Authentication</U></TH></TR>\n\
<TR><TD VALIGN=top>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right COLSPAN=2>Success:</TH><TD>!UL</TD></TR>\n\
<TR><TH ALIGN=right COLSPAN=2>Failure:</TH><TD>!UL</TD></TR>\n\
</TABLE>\n\
</TD><TD VALIGN=top>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right><U>Source</U></TH>\n\
<TR><TH ALIGN=right>Cache:</TH><TD>!UL</TD>\n\
<TR><TH ALIGN=right>Agent:</TH><TD >!UL</TD>\n\
<TR><TH ALIGN=right>HTA:</TH><TD >!UL</TD>\n\
<TR><TH ALIGN=right>List:</TH><TD >!UL</TD>\n\
<TR><TH ALIGN=right>SYSUAF:</TH><TD>!UL</TD></TR>\n\
</TABLE>\n\
</TD><TD VALIGN=top>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right><U>Scheme</U></TH></TR>\n\
<TR><TH ALIGN=right>Basic:</TH><TD>!UL</TD></TR>\n\
<TR><TH ALIGN=right>Digest:</TH><TD>!UL</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n";

   static char OtherFao [] =
"<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Other</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right>StreamLF document conversions:</TH><TD>!UL</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
</BODY>\n\
</HTML>\n";

   static char  SysPrvWarning[] = "<FONT COLOR=\"#ff0000\">SYSPRV</FONT>";
   static char  PrivWarning[] = "<FONT COLOR=\"#ff0000\">WARNING</FONT>";
   static char  PrivExpected[] = "as expected";

   static char  JpiPrcNam [16],
                JpiUserName [13],
                LastExitStatus [16];

   static unsigned long  JpiAstCnt,
                         JpiBioCnt,
                         JpiBytCnt,
                         JpiCpuTime,
                         JpiDioCnt,
                         JpiEnqCnt,
                         JpiFilCnt,
                         JpiPageFlts,
                         JpiPagFilCnt,
                         JpiPid,
                         JpiPrcCnt,
                         JpiTqCnt,
                         JpiVirtPeak,
                         JpiWsSize,
                         JpiWsPeak,
                         Pid;

   static unsigned long  CurrentTime [2],
                         ImageUpTime [2],
                         JpiAuthPriv [2],
                         JpiCurPriv [2],
                         JpiImagPriv [2],
                         JpiLoginTime [2],
                         ProcessUpTime [2];

   static $DESCRIPTOR (LastExitStatusDsc, LastExitStatus);
   static $DESCRIPTOR (LastExitStatusFaoDsc, "%X!XL\0");
   static struct
   {
      unsigned short  buf_len;
      unsigned short  item;
      unsigned char   *buf_addr;
      unsigned short  *short_ret_len;
   }
      JpiItems [] =
   {
      { sizeof(JpiAstCnt), JPI$_ASTCNT, &JpiAstCnt, 0 },
      { sizeof(JpiAuthPriv), JPI$_AUTHPRIV, &JpiAuthPriv, 0 },
      { sizeof(JpiBioCnt), JPI$_BIOCNT, &JpiBioCnt, 0 },
      { sizeof(JpiBytCnt), JPI$_BYTCNT, &JpiBytCnt, 0 },
      { sizeof(JpiCpuTime), JPI$_CPUTIM, &JpiCpuTime, 0 },
      { sizeof(JpiCurPriv), JPI$_CURPRIV, &JpiCurPriv, 0 },
      { sizeof(JpiDioCnt), JPI$_DIOCNT, &JpiDioCnt, 0 },
      { sizeof(JpiEnqCnt), JPI$_ENQCNT, &JpiEnqCnt, 0 },
      { sizeof(JpiFilCnt), JPI$_FILCNT, &JpiFilCnt, 0 },
      { sizeof(JpiImagPriv), JPI$_IMAGPRIV, &JpiImagPriv, 0 },
      { sizeof(JpiLoginTime), JPI$_LOGINTIM, &JpiLoginTime, 0 },
      { sizeof(JpiPageFlts), JPI$_PAGEFLTS, &JpiPageFlts, 0 },
      { sizeof(JpiPagFilCnt), JPI$_PAGFILCNT, &JpiPagFilCnt, 0 },
      { sizeof(JpiPid), JPI$_PID, &JpiPid, 0 },
      { sizeof(JpiPrcCnt), JPI$_PRCCNT, &JpiPrcCnt, 0 },
      { sizeof(JpiPrcNam), JPI$_PRCNAM, &JpiPrcNam, 0 },
      { sizeof(JpiTqCnt), JPI$_TQCNT, &JpiTqCnt, 0 },
      { sizeof(JpiUserName), JPI$_USERNAME, &JpiUserName, 0 },
      { sizeof(JpiVirtPeak), JPI$_VIRTPEAK, &JpiVirtPeak, 0 },
      { sizeof(JpiWsSize), JPI$_WSSIZE, &JpiWsSize, 0 },
      { sizeof(JpiWsPeak), JPI$_WSPEAK, &JpiWsPeak, 0 },
      {0,0,0,0}
   };

   register unsigned int  bit;
   register unsigned long  *vecptr;
   register char  *cptr;

   int  status;

   unsigned long  ResponseDuration,
                  Remainder,
                  Seconds,
                  SubSeconds;

   unsigned long  FaoVector [128];

   char  *AuthPrivPtr,
         *CurPrivPtr,
         *ImagPrivPtr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AdminReportServerStats()\n");

   if (VMSnok (status = sys$getjpiw (0, &Pid, 0, &JpiItems, 0, 0, 0)))
   {
      rqptr->rqResponse.ErrorTextPtr = "sys$getjpiw()";
      ErrorVmsStatus (rqptr, status, FI_LI);
      SysDclAst (NextTaskFunction, rqptr);
      return;
   }

   JpiUserName[12] = '\0';
   for (cptr = JpiUserName; *cptr && *cptr != ' '; cptr++);
   *cptr = '\0';
   if (Debug) fprintf (stdout, "JpiUserName |%s|\n", JpiUserName);

   JpiPrcNam[15] = '\0';
   for (cptr = JpiPrcNam; *cptr && *cptr != ' '; cptr++);
   *cptr = '\0';
   if (Debug) fprintf (stdout, "JpiPrcNam |%s|\n", JpiPrcNam);

   sys$gettim (&CurrentTime);
   lib$sub_times (&CurrentTime, &HttpdStartBinTime, &ImageUpTime);
   lib$sub_times (&CurrentTime, &JpiLoginTime, &ProcessUpTime);

   if (Accounting.LastExitStatus)
      sys$fao (&LastExitStatusFaoDsc, 0, &LastExitStatusDsc, 
               Accounting.LastExitStatus);
   else
      strcpy (LastExitStatus, "<I>(none)</I>");

   if ((JpiAuthPriv[0] & ~(PRV$M_NETMBX | PRV$M_TMPMBX)) || JpiAuthPriv[1])
      AuthPrivPtr = PrivWarning;
   else
      AuthPrivPtr = PrivExpected;

   if ((JpiImagPriv[0] & IMAG_PRIV_0_ALLOWED) ||
       (JpiImagPriv[1] & IMAG_PRIV_1_ALLOWED))
      ImagPrivPtr = PrivWarning;
   else
      ImagPrivPtr = PrivExpected;

   if (OperateWithSysPrv)
   {
      if ((JpiCurPriv[0] & ~(PRV$M_NETMBX | PRV$M_TMPMBX | PRV$M_SYSPRV)) ||
          JpiCurPriv[1])
         CurPrivPtr = PrivWarning;
      else
         CurPrivPtr = SysPrvWarning;
   }
   else
   if ((JpiCurPriv[0] & ~(PRV$M_NETMBX | PRV$M_TMPMBX)) || JpiCurPriv[1])
      CurPrivPtr = PrivWarning;
   else
      CurPrivPtr = PrivExpected;

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_ADMIN;
   HTTP_HEADER_200_HTML (rqptr);

   vecptr = FaoVector;

   /* META info */
   *vecptr++ = HtmlMetaInfo (rqptr, NULL);

   /* page title, etc. */
   *vecptr++ = ServerHostPort;
   *vecptr++ = Config.cfServer.AdminBodyTag;
   *vecptr++ = ServerHostPort;
   *vecptr++ = &rqptr->rqTime.Vms64bit;

   /* server */
   *vecptr++ = (unsigned long)SoftwareID;
   *vecptr++ = (unsigned long)BuildInfo;
   *vecptr++ = (unsigned long)JpiPrcNam;
   *vecptr++ = ADMIN_REPORT_SHOW_PROCESS;
   *vecptr++ = JpiPid;
   *vecptr++ = JpiPid;
   *vecptr++ = (unsigned long)JpiUserName;
   *vecptr++ = AuthPrivPtr;
   *vecptr++ = ImagPrivPtr;
   *vecptr++ = CurPrivPtr;
   *vecptr++ = Accounting.StartupCount;
   *vecptr++ = LastExitStatus;
   *vecptr++ = Accounting.ZeroedCount;
   *vecptr++ = &ImageUpTime;
   *vecptr++ = &ProcessUpTime;
   *vecptr++ = JpiCpuTime / 8640000;             /* CPU day */
   *vecptr++ = (JpiCpuTime % 8640000) / 360000;  /* CPU hour */
   *vecptr++ = (JpiCpuTime % 360000) / 6000;     /* CPU minute */
   *vecptr++ = (JpiCpuTime % 6000 ) / 100;       /* CPU second */
   *vecptr++ = JpiCpuTime % 100;                 /* CPU 10 milliseconds */
   *vecptr++ = JpiPageFlts;
   *vecptr++ = 100 - ((JpiPagFilCnt * 100) / HttpdJpiPgFlQuo);
   *vecptr++ = JpiWsSize;
   *vecptr++ = JpiWsPeak;
   *vecptr++ = JpiVirtPeak;
   *vecptr++ = JpiAstCnt;
   *vecptr++ = HttpdJpiAstLm;
   *vecptr++ = JpiBioCnt;
   *vecptr++ = HttpdJpiBioLm;
   *vecptr++ = JpiBytCnt;
   *vecptr++ = HttpdJpiBytLm;
   *vecptr++ = JpiDioCnt;
   *vecptr++ = HttpdJpiDioLm;
   *vecptr++ = JpiEnqCnt;
   *vecptr++ = HttpdJpiEnqLm;
   *vecptr++ = JpiFilCnt;
   *vecptr++ = HttpdJpiFilLm;
   *vecptr++ = JpiPrcCnt;
   *vecptr++ = HttpdJpiPrcLm;
   *vecptr++ = JpiTqCnt;
   *vecptr++ = HttpdJpiTqLm;

   status = NetWriteFaol (rqptr, ResponseFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   /************/
   /* services */
   /************/

   if (VMSnok (NetServiceReportStats (rqptr)))
   {
      SysDclAst (NextTaskFunction, rqptr);
      return;
   }

   /**************/
   /* statistics */
   /**************/

   vecptr = FaoVector;

   /* connections */
   *vecptr++ = Accounting.ConnectCount;
   *vecptr++ = Accounting.ConnectAcceptedCount;
   *vecptr++ = Accounting.ConnectRejectedCount;
   *vecptr++ = Accounting.ConnectCurrent;
   *vecptr++ = Accounting.ConnectPeak;
   *vecptr++ = Accounting.ConnectTooBusyCount;
   *vecptr++ = Accounting.ConnectSslCount;

   /* requests */
   *vecptr++ = Accounting.RequestTotalCount;
   *vecptr++ = Accounting.RequestParseCount;
   *vecptr++ = Accounting.RequestErrorCount;
   *vecptr++ = Accounting.RequestForbiddenCount;
   *vecptr++ = Accounting.RedirectRemoteCount;
   *vecptr++ = Accounting.RedirectLocalCount;
   *vecptr++ = Accounting.RequestKeepAliveCount;
   *vecptr++ = Accounting.RequestKeepAliveMax;
   *vecptr++ = Accounting.RequestPragmaNoCacheCount;

   *vecptr++ = &Accounting.QuadBytesRawRx;
   *vecptr++ = &Accounting.QuadBytesRawTx;

   /* HTTP methods */
   *vecptr++ = Accounting.MethodGetCount;
   *vecptr++ = Accounting.MethodHeadCount;
   *vecptr++ = Accounting.MethodPostCount;
   *vecptr++ = Accounting.MethodPutCount;

   /* responses */
   *vecptr++ = Accounting.ResponseStatusCodeCountArray[1];
   *vecptr++ = Accounting.ResponseStatusCodeCountArray[2];
   *vecptr++ = Accounting.ResponseStatusCodeCountArray[3];
   *vecptr++ = Accounting.ResponseStatusCodeCountArray[4];
   *vecptr++ = Accounting.ResponseStatusCodeCountArray[5];
   *vecptr++ = Accounting.ResponseStatusCodeCountArray[0];

   /* response duration */
   if (Accounting.ResponseDurationMin == -1)
   {
      *vecptr++ = 0;
      *vecptr++ = DURATION_DECIMAL_PLACES;
      *vecptr++ = 0;
   }
   else
   {
      Seconds = Accounting.ResponseDurationMin / USECS_IN_A_SECOND;
      SubSeconds = (Accounting.ResponseDurationMin % USECS_IN_A_SECOND) /
                   DURATION_UNITS_USECS;
      *vecptr++ = Seconds;
      *vecptr++ = DURATION_DECIMAL_PLACES;
      *vecptr++ = SubSeconds;
   }
   Seconds = Accounting.ResponseDurationMax / USECS_IN_A_SECOND;
   SubSeconds = (Accounting.ResponseDurationMax % USECS_IN_A_SECOND) /
                DURATION_UNITS_USECS;
   *vecptr++ = Seconds;
   *vecptr++ = DURATION_DECIMAL_PLACES;
   *vecptr++ = SubSeconds;

   if (Accounting.ResponseDurationCount)
   {
      status = lib$ediv (&Accounting.ResponseDurationCount,
                         &Accounting.QuadResponseDuration,
                         &ResponseDuration, &Remainder);
      if (Debug) fprintf (stdout, "lib$ediv() %%X%08.08X\n", status);
   }
   else
      ResponseDuration = 0;

   Seconds = ResponseDuration / USECS_IN_A_SECOND;
   SubSeconds = (ResponseDuration % USECS_IN_A_SECOND) / DURATION_UNITS_USECS;
   *vecptr++ = Seconds;
   *vecptr++ = DURATION_DECIMAL_PLACES;
   *vecptr++ = SubSeconds;

   /* modules */
   *vecptr++ = Accounting.DoServerAdminCount;
   *vecptr++ = Accounting.DoDirectoryCount;
   *vecptr++ = Accounting.DoFileCount;
   *vecptr++ = Accounting.DoFileNotModifiedCount;
   *vecptr++ = Accounting.DoIsMapCount;
   *vecptr++ = Accounting.DoMenuCount;
   *vecptr++ = Accounting.DoPutCount;
   *vecptr++ = ProxyAccounting.MethodConnectCount +
               ProxyAccounting.MethodGetCount +
               ProxyAccounting.MethodHeadCount +
               ProxyAccounting.MethodPostCount +
               ProxyAccounting.MethodPutCount,
   *vecptr++ = Accounting.DoSsiCount;
   *vecptr++ = Accounting.DoUpdateCount;
   *vecptr++ = Accounting.DoScriptCount;
   *vecptr++ = Accounting.DoCgiPlusScriptCount;
   *vecptr++ = Accounting.DclCgiPlusReusedCount;
   *vecptr++ = Accounting.DoRteScriptCount;
   *vecptr++ = Accounting.DclRteReusedCount;
   *vecptr++ = Accounting.DoAutoScriptCount;
   *vecptr++ = Accounting.DoDclCommandCount;
   *vecptr++ = Accounting.DclCrePrcCount;
   *vecptr++ = Accounting.DoDECnetCount;
   *vecptr++ = Accounting.DoDECnetCount -
               Accounting.DoDECnetCgiCount -
               Accounting.DoDECnetOsuCount;
   *vecptr++ = Accounting.DoDECnetCgiCount;
   *vecptr++ = Accounting.DoDECnetOsuCount;

   /* cache */
   *vecptr++ = CacheMemoryInUse >> 10;
   *vecptr++ = CacheTotalKBytesMax;
   *vecptr++ = CacheLoadCount;
   *vecptr++ = CacheHits0;
   if (CacheLoadCount)
      *vecptr++ = CacheHits0 * 100 / CacheLoadCount;
   else
      *vecptr++ = 0;
   *vecptr++ = CacheHitCount;
   if (CacheLoadCount)
      *vecptr++ = CacheHitCount * 100 / CacheLoadCount;
   else
      *vecptr++ = 0;
   *vecptr++ = CacheHits10;
   if (CacheHitCount)
      *vecptr++ = CacheHits10 * 100 / CacheHitCount;
   else
      *vecptr++ = 0;
   *vecptr++ = CacheHits100;
   if (CacheHitCount)
      *vecptr++ = CacheHits100 * 100 / CacheHitCount;
   else
      *vecptr++ = 0;
   *vecptr++ = CacheHits100plus;
   if (CacheHitCount)
      *vecptr++ = CacheHits100plus * 100 / CacheHitCount;
   else
      *vecptr++ = 0;

   /* authorization */
   /*
      Note that the total number of paths being authorized may be
      greater than the total number of authentications.  This happens
      if a request contains both script and path authorizations,
      resulting in two authorizations for the one request!
   */
   *vecptr++ = Accounting.AuthAuthorizedCount;
   *vecptr++ = Accounting.AuthNotAuthorizedCount;
   *vecptr++ = Accounting.AuthBasicCount +
               Accounting.AuthDigestCount -
               Accounting.AuthAgentCount -
               Accounting.AuthHtDatabaseCount -
               Accounting.AuthSimpleListCount -
               Accounting.AuthVmsCount;
   *vecptr++ = Accounting.AuthAgentCount;
   *vecptr++ = Accounting.AuthHtDatabaseCount;
   *vecptr++ = Accounting.AuthSimpleListCount;
   *vecptr++ = Accounting.AuthVmsCount;
   *vecptr++ = Accounting.AuthBasicCount;
   *vecptr++ = Accounting.AuthDigestCount;

   status = NetWriteFaol (rqptr, StatisticsFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   /* proxy serving */
   status = ProxyMaintStatisticsReport (rqptr);
   if (VMSnok (status) || status == SS$_BUFFEROVF)
   {
      rqptr->rqResponse.ErrorTextPtr = "ProxyMaintStatisticsReport()";
      ErrorVmsStatus (rqptr, status, FI_LI);
      SysDclAst (NextTaskFunction, rqptr);
      return;
   }

   /* other */
   vecptr = FaoVector;
   *vecptr++ = Accounting.StreamLfConversionCount;

   status = NetWriteFaol (rqptr, OtherFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   SysDclAst (NextTaskFunction, rqptr);
}

/*****************************************************************************/
/*
Execute server administration menu control actions.
*/ 

AdminControl
(
struct RequestStruct *rqptr,
void *NextTaskFunction,
boolean ControlDoAll
)
{
   int  status;
   char  *cptr, *sptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AdminControl()\n");

   cptr = rqptr->rqHeader.PathInfoPtr;

   if (ControlDoAll)
   {
      /*********************/
      /* /DO=/ALL commands */
      /*********************/

      if (!ControlDoAllEnabled)
      {
         rqptr->rqResponse.HttpStatus = 500;
         ErrorGeneral (rqptr, ErrorControlDoAll, FI_LI);
         SysDclAst (NextTaskFunction, rqptr);
         return;
      }

      if (strsame (cptr, ADMIN_CONTROL_DECNET_PURGE, -1))
         sptr = CONTROL_DECNET_PURGE;
      else
      if (strsame (cptr, ADMIN_CONTROL_DECNET_FORCE, -1))
         sptr = CONTROL_DECNET_DISCONNECT;
      else
      if (strsame (cptr, ADMIN_CONTROL_EXIT, -1))
         sptr = CONTROL_EXIT;
      else
      if (strsame (cptr, ADMIN_CONTROL_EXIT_NOW, -1))
         sptr = CONTROL_EXIT_NOW;
      else
      if (strsame (cptr, ADMIN_CONTROL_RESTART, -1))
         sptr = CONTROL_RESTART;
      else
      if (strsame (cptr, ADMIN_CONTROL_RESTART_NOW, -1))
         sptr = CONTROL_RESTART_NOW;
      else
      if (strsame (cptr, ADMIN_CONTROL_MAPPING_LOAD, -1))
         sptr = CONTROL_MAP;
      else
      if (strsame (cptr, ADMIN_CONTROL_AUTH_LOAD, -1))
         sptr = CONTROL_AUTH_LOAD;
      else
      if (strsame (cptr, ADMIN_CONTROL_AUTH_PURGE, -1))
         sptr = CONTROL_AUTH_PURGE;
      else
      if (strsame (cptr, ADMIN_CONTROL_ZERO, -1))
         sptr = CONTROL_ZERO;
      else
      if (strsame (cptr, ADMIN_CONTROL_CACHE_ON, -1))
         sptr = CONTROL_CACHE_ON;
      else
      if (strsame (cptr, ADMIN_CONTROL_CACHE_OFF, -1))
         sptr = CONTROL_CACHE_OFF;
      else
      if (strsame (cptr, ADMIN_CONTROL_CACHE_PURGE, -1))
         sptr = CONTROL_CACHE_PURGE;
      else
      if (strsame (cptr, ADMIN_CONTROL_LOG_ON, -1))
         sptr = CONTROL_LOG_OPEN;
      else
      if (strsame (cptr, ADMIN_CONTROL_LOG_OFF, -1))
         sptr = CONTROL_LOG_CLOSE;
      else
      if (strsame (cptr, ADMIN_CONTROL_LOG_FLUSH, -1))
         sptr = CONTROL_LOG_FLUSH;
      else
         sptr = "*ERROR*";

      cptr = ControlDoAllLock (sptr);
      if (cptr[0] == '!')
      {
         rqptr->rqResponse.HttpStatus = 500;
         ErrorGeneral (rqptr, cptr+1, FI_LI);
      }
      else
         ReportSuccess (rqptr,
"The directive &quot;!AZ&quot; has been (en)queued, with !AZ.",
            sptr, cptr);
   }
   else
   if (strsame (cptr, ADMIN_CONTROL_DECNET_PURGE, -1))
   {
      /********************************/
      /* purge network scripting task */
      /********************************/

      DECnetDisconnect (rqptr, NextTaskFunction, false);
      return;
   }
   else
   if (strsame (cptr, ADMIN_CONTROL_DECNET_FORCE, -1))
   {
      /***********************************************/
      /* forcably disconnect network scripting tasks */
      /***********************************************/

      DECnetDisconnect (rqptr, NextTaskFunction, true);
      return;
   }
   else
   if (strsame (cptr, ADMIN_CONTROL_EXIT, -1))
   {
      /***************/
      /* server exit */
      /***************/

      if (ConnectCountCurrent > 1)
      {         
         ReportSuccess (rqptr,
"$<FONT COLOR=\"#ff0000\">Server !AZ will exit when !UL other, \
in-progress request(s) complete.</FONT>",
            ServerHostPort, ConnectCountCurrent-1);

         /* stop the server from receiving incoming requests */
         NetShutdownServerSocket ();
         ControlExitRequested = true;
      }
      else
      {
         ReportSuccess (rqptr,
"$<FONT COLOR=\"#ff0000\">Server !AZ exiting now!!</FONT>",
            ServerHostPort);

         WriteFaoStdout ("%!AZ-I-ADMIN, !20%D, !AZ.\'!AZ\'@!AZ, server exit\n",
                         Utility, 0, rqptr->RemoteUser,
                         rqptr->rqAuth.RealmPtr, rqptr->rqNet.ClientHostName);

         if (OpcomMessages & OPCOM_ADMIN)
            WriteFaoOpcom ("%!AZ-I-ADMIN, !AZ.\'!AZ\'@!AZ, server exit",
                           Utility, rqptr->RemoteUser,
                           rqptr->rqAuth.RealmPtr, rqptr->rqNet.ClientHostName);

         ControlDelay (CONTROL_DELAY_EXIT);
      }
   }
   else
   if (strsame (cptr, ADMIN_CONTROL_EXIT_NOW, -1))
   {
      /********************/
      /* server exit NOW! */
      /********************/

      ReportSuccess (rqptr,
"$<FONT COLOR=\"#ff0000\">Server !AZ exiting <B>NOW!!</B></FONT>",
         ServerHostPort);

      WriteFaoStdout ("%!AZ-I-ADMIN, !20%D, !AZ.\'!AZ\'@!AZ, server exit NOW!!\n",
                      Utility, 0, rqptr->RemoteUser,
                      rqptr->rqAuth.RealmPtr, rqptr->rqNet.ClientHostName);

      if (OpcomMessages & OPCOM_ADMIN)
         WriteFaoOpcom ("%!AZ-I-ADMIN, !AZ.\'!AZ\'@!AZ, server exit NOW!!",
                        Utility, rqptr->RemoteUser,
                        rqptr->rqAuth.RealmPtr, rqptr->rqNet.ClientHostName);

      ControlDelay (CONTROL_DELAY_EXIT);
   }
   else
   if (strsame (cptr, ADMIN_CONTROL_RESTART, -1))
   {
      /******************/
      /* server restart */
      /******************/

      if (ConnectCountCurrent > 1)
      {
         ReportSuccess (rqptr,
"$<FONT COLOR=\"#ff0000\">Server !AZ will restart when !UL other, \
in-progress request(s) complete.</FONT>",
            ServerHostPort, ConnectCountCurrent-1);

         /* stop the server from receiving incoming requests */
         NetShutdownServerSocket ();
         ControlRestartRequested = true;
      }
      else
      {
         ReportSuccess (rqptr,
"$<FONT COLOR=\"#ff0000\">Server !AZ restarting now!!</FONT>",
            ServerHostPort);

         WriteFaoStdout ("%!AZ-I-ADMIN, !20%D, !AZ.\'!AZ\'@!AZ, server restart\n",
                         Utility, 0, rqptr->RemoteUser,
                         rqptr->rqAuth.RealmPtr, rqptr->rqNet.ClientHostName);

         if (OpcomMessages & OPCOM_ADMIN)
            WriteFaoOpcom ("%!AZ-I-ADMIN, !AZ.\'!AZ\'@!AZ, server restart",
                           Utility, rqptr->RemoteUser,
                           rqptr->rqAuth.RealmPtr, rqptr->rqNet.ClientHostName);

         ControlDelay (CONTROL_DELAY_RESTART);
      }
   }
   else
   if (strsame (cptr, ADMIN_CONTROL_RESTART_NOW, -1))
   {
      /***********************/
      /* server restart NOW! */
      /***********************/

      ReportSuccess (rqptr,
"$<FONT COLOR=\"#ff0000\">Server !AZ restarting <B>NOW!!</B></FONT>",
         ServerHostPort);

      WriteFaoStdout ("%!AZ-I-ADMIN, !20%D, !AZ.\'!AZ\'@!AZ, server restart NOW!!\n",
                      Utility, 0, rqptr->RemoteUser,
                      rqptr->rqAuth.RealmPtr, rqptr->rqNet.ClientHostName);

      if (OpcomMessages & OPCOM_ADMIN)
         WriteFaoOpcom ("%!AZ-I-ADMIN, !AZ.\'!AZ\'@!AZ, server restart NOW!!",
                        Utility, rqptr->RemoteUser,
                        rqptr->rqAuth.RealmPtr, rqptr->rqNet.ClientHostName);

      ControlDelay (CONTROL_DELAY_RESTART);
   }
   else
   if (strsame (cptr, ADMIN_CONTROL_DCL_PURGE, -1))
   {
      /******************************/
      /* purge DCL script processes */
      /******************************/

      DclPurgeScriptProcesses (rqptr, NextTaskFunction, false);
      return;
   }
   else
   if (strsame (cptr, ADMIN_CONTROL_DCL_DELETE, -1))
   {
      /****************************************/
      /* forcably delete DCL script processes */
      /****************************************/

      DclPurgeScriptProcesses (rqptr, NextTaskFunction, true);
      return;
   }
   else
   if (strsame (cptr, ADMIN_CONTROL_MAPPING_LOAD, -1))
   {
      /************************/
      /* reload mapping rules */
      /************************/

      WriteFaoStdout ("%!AZ-I-ADMIN, !20%D, !AZ.\'!AZ\'@!AZ, mapping rules reload\n",
                      Utility, 0, rqptr->RemoteUser,
                      rqptr->rqAuth.RealmPtr, rqptr->rqNet.ClientHostName);

      if (OpcomMessages & OPCOM_ADMIN)
         WriteFaoOpcom ("%!AZ-I-ADMIN, !AZ.\'!AZ\'@!AZ, mapping rules reload",
                        Utility, rqptr->RemoteUser,
                        rqptr->rqAuth.RealmPtr, rqptr->rqNet.ClientHostName);

      MapUrl_ControlReload (rqptr, NextTaskFunction);
      return;
   }
   else
   if (strsame (cptr, ADMIN_CONTROL_AUTH_LOAD, -1))
   {
      /*****************************/
      /* authorization path reload */
      /*****************************/

      WriteFaoStdout ("%!AZ-I-ADMIN, !20%D, !AZ.\'!AZ\'@!AZ, authorization paths reload\n",
                      Utility, 0, rqptr->RemoteUser,
                      rqptr->rqAuth.RealmPtr, rqptr->rqNet.ClientHostName);
      if (OpcomMessages & OPCOM_ADMIN)
         WriteFaoOpcom ("%!AZ-I-ADMIN, !AZ.\'!AZ\'@!AZ, authorization paths reload",
                        Utility, rqptr->RemoteUser,
                        rqptr->rqAuth.RealmPtr, rqptr->rqNet.ClientHostName);

      AuthConfigReload (rqptr, NextTaskFunction);
      return;
   }
   else
   if (strsame (cptr, ADMIN_CONTROL_AUTH_PURGE, -1))
   {
      /******************************/
      /* purge authentication cache */
      /******************************/

      WriteFaoStdout ("%!AZ-I-ADMIN, !20%D !AZ.\'!AZ\'@!AZ, purge authentication cache\n",
                      Utility, 0, rqptr->RemoteUser,
                      rqptr->rqAuth.RealmPtr, rqptr->rqNet.ClientHostName);
      if (OpcomMessages & OPCOM_ADMIN)
         WriteFaoOpcom ("%!AZ-I-ADMIN, !AZ.\'!AZ\'@!AZ, purge authentication cache",
                        Utility, rqptr->RemoteUser,
                        rqptr->rqAuth.RealmPtr, rqptr->rqNet.ClientHostName);

      /* fake it :^) */
      rqptr->rqHeader.QueryStringPtr = "do=purge";
      HTAdminBegin (rqptr, NextTaskFunction);
      return;
   }
   else
   if (strsame (cptr, ADMIN_CONTROL_ZERO, -1))
   {
      /*******************/
      /* zero accounting */
      /*******************/

      ZeroAccounting ();

      WriteFaoStdout ("%!AZ-I-ADMIN, !20%D, !AZ.\'!AZ\'@!AZ, accounting zeroed\n",
                      Utility, 0, rqptr->RemoteUser,
                      rqptr->rqAuth.RealmPtr, rqptr->rqNet.ClientHostName);

      if (OpcomMessages & OPCOM_ADMIN)
         WriteFaoOpcom ("%!AZ-I-ADMIN, !AZ.\'!AZ\'@!AZ, accounting zeroed",
                        Utility, rqptr->RemoteUser,
                        rqptr->rqAuth.RealmPtr, rqptr->rqNet.ClientHostName);

      ReportSuccess (rqptr, "$Server !AZ accounting zeroed.", ServerHostPort);
   }
   else
   if (strsame (cptr, ADMIN_CONTROL_CACHE_ON, -1))
   {
      /****************/
      /* enable cache */
      /****************/

      if (CacheEnabled)
      {
         rqptr->rqResponse.HttpStatus = 409;
         ErrorGeneral (rqptr, "Cache already enabled.", FI_LI);
      }
      else
      {
         CacheEnabled = true;
         ReportSuccess (rqptr, "$Server !AZ cache enabled.", ServerHostPort);
      }
   }
   else
   if (strsame (cptr, ADMIN_CONTROL_CACHE_OFF, -1))
   {
      /*****************/
      /* disable cache */
      /*****************/

      if (CacheEnabled)
      {
         CacheEnabled = false;
         ReportSuccess (rqptr, "$Server !AZ cache disabled.", ServerHostPort);
      }
      else
      {
         rqptr->rqResponse.HttpStatus = 409;
         ErrorGeneral (rqptr, "Cache already disabled.", FI_LI);
      }
   }
   else
   if (strsame (cptr, ADMIN_CONTROL_CACHE_PURGE, -1))
   {
      /***************/
      /* purge cache */
      /***************/

      if (CacheEnabled)
      {
         int  PurgeCount, MarkedForPurgeCount;

         CachePurge (false, &PurgeCount, &MarkedForPurgeCount);

         ReportSuccess (rqptr,
"$Server !AZ cache !UL purged, !UL marked for purge.",
            ServerHostPort, PurgeCount, MarkedForPurgeCount);
      }
      else
      {
         rqptr->rqResponse.HttpStatus = 409;
         ErrorGeneral (rqptr, "Cache not enabled.", FI_LI);
      }
   }
   else
   if (strsame (cptr, ADMIN_CONTROL_LOG_ON, -1))
   {
      /******************/
      /* enable logging */
      /******************/

      if (LoggingEnabled)
      {
         rqptr->rqResponse.HttpStatus = 409;
         ErrorGeneral (rqptr, "Logging already enabled.", FI_LI);
      }
      else
      if (VMSok (status = Logging (NULL, LOGGING_OPEN)))
      {
         WriteFaoStdout ("%!AZ-I-ADMIN, !20%D, !AZ.\'!AZ\'@!AZ, logging enabled\n",
                         Utility, 0, rqptr->RemoteUser,
                         rqptr->rqAuth.RealmPtr, rqptr->rqNet.ClientHostName);

         if (OpcomMessages & OPCOM_ADMIN)
            WriteFaoOpcom ("%!AZ-I-ADMIN, !AZ.\'!AZ\'@!AZ, logging enabled",
                           Utility, rqptr->RemoteUser,
                           rqptr->rqAuth.RealmPtr, rqptr->rqNet.ClientHostName);

         ReportSuccess (rqptr, "$Server !AZ logging enabled.", ServerHostPort);
      }
      else
      {
         rqptr->rqResponse.ErrorTextPtr = "Logging could NOT be enabled";
         ErrorVmsStatus (rqptr, status, FI_LI);
      }
   }
   else
   if (strsame (cptr, ADMIN_CONTROL_LOG_OFF, -1))
   {
      /*******************/
      /* disable logging */
      /*******************/

      if (!LoggingEnabled)
      {
         rqptr->rqResponse.HttpStatus = 409;
         ErrorGeneral (rqptr, "Logging not currently enabled.", FI_LI);
      }
      else
      if (VMSok (status = Logging (NULL, LOGGING_CLOSE)))
      {
         WriteFaoStdout ("%!AZ-I-ADMIN, !20%D, !AZ.\'!AZ\'@!AZ, logging disabled\n",
                         Utility, 0, rqptr->RemoteUser,
                         rqptr->rqAuth.RealmPtr, rqptr->rqNet.ClientHostName);

         if (OpcomMessages & OPCOM_ADMIN)
            WriteFaoOpcom ("%!AZ-I-ADMIN, !AZ.\'!AZ\'@!AZ, logging disabled",
                           Utility, rqptr->RemoteUser,
                           rqptr->rqAuth.RealmPtr, rqptr->rqNet.ClientHostName);

         ReportSuccess (rqptr, "$Server !AZ logging disabled.", ServerHostPort);
      }
      else
      {
         rqptr->rqResponse.ErrorTextPtr = "Logging could NOT be disabled!";
         ErrorVmsStatus (rqptr, status, FI_LI);
      }
   }
   else
   if (strsame (cptr, ADMIN_CONTROL_LOG_FLUSH, -1))
   {
      /*************/
      /* flush log */
      /*************/

      if (!LoggingEnabled)
      {
         rqptr->rqResponse.HttpStatus = 409;
         ErrorGeneral (rqptr, ErrorLoggingNotEnabled, FI_LI);
      }
      else
      if (VMSok (status = Logging (NULL, LOGGING_FLUSH)))
      {
         WriteFaoStdout ("%!AZ-I-ADMIN, !20%D, !AZ.\'!AZ\'@!AZ, log flushed\n",
                         Utility, 0, rqptr->RemoteUser,
                         rqptr->rqAuth.RealmPtr, rqptr->rqNet.ClientHostName);

         if (OpcomMessages & OPCOM_ADMIN)
            WriteFaoOpcom ("%!AZ-I-ADMIN, !AZ.\'!AZ\'@!AZ, log flushed",
                           Utility, rqptr->RemoteUser,
                           rqptr->rqAuth.RealmPtr, rqptr->rqNet.ClientHostName);

         ReportSuccess (rqptr, "$Server !AZ log flushed.", ServerHostPort);
      }
      else
      {
         rqptr->rqResponse.ErrorTextPtr = "Log could NOT be flushed!";
         ErrorVmsStatus (rqptr, status, FI_LI);
      }
   }
   else
   if (strsame (cptr, ADMIN_CONTROL_PROXY, -1))
   {
      /*****************/
      /* proxy serving */
      /*****************/

      ProxyMaintControl (rqptr);
   }
   else
   if (strsame (cptr, ADMIN_CONTROL_PROXY_ADJUST, -1))
   {
      /**************************************/
      /* adjust proxy serving configuration */
      /**************************************/

      ProxyMaintAdjust (rqptr, NextTaskFunction);
      return;
   }
   else
   {
      /********************/
      /* unknown function */
      /********************/

      rqptr->rqResponse.HttpStatus = 400;
      ErrorGeneral (rqptr, "Unknown control function.", FI_LI);
   }

   SysDclAst (NextTaskFunction, rqptr);
}

/****************************************************************************/

*                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  