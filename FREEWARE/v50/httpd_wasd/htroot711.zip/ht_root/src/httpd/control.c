/*****************************************************************************/
/*
                                 Control.c

This module implements the HTTPd command-line, and the distributed, to-all
server processes (from command-line or Admin Menu), control functionality.

Command-line server control commands:

  o  AUTH=LOAD   reload authorization file
  o  AUTH=PURGE  purge authentication records from cache
  o  CACHE=ON    turn file caching on
  o  CACHE=OFF   turn file caching off
  o  CACHE=PURGE         purge all data cached
  o  DCL=DELETE  unconditionally delete all DCL script processes, busy or not
  o  DCL=PURGE   delete idle script processes, mark busy for later deletion
  o  DECNET=PURGE        disconnect idle DECnet script tasks
  o  DECNET=DISCONNECT   forceably disconnect all DECnet script tasks
  o  EXIT        exit after all client activity complete (nothing new started)
  o  EXIT=NOW    exit right now regardless of connections
  o  LIST        *special-case* when used with /ALL just list all servers
  o  LOG=OPEN    open the log file
  o *LOG=OPEN=name       open the log file using the specified name
  o *LOG=REOPEN          closes then reopens the log (to change format perhaps)
  o *LOG=REOPEN=name     log is closed and then reopened using specified name
  o  LOG=CLOSE   close the log file
  o  LOG=FLUSH   flush the log file
  o *LOG=FORMAT=string   set the log format (requires subsequent open/reopen)
  o *LOG=PERIOD=string   set the log period (requires subsequent open/reopen)
  o  MAP         reload mapping rule file
  o  PROXY=on                proxy processing enabled
  o  PROXY=off               proxy processing disabled
  o  PROXY=purge=reactive    reactive cache purge
  o  PROXY=purge=routine     routine cache purge
  o  PROXY=purge=host        host name cache purge
  o  RESTART      restart the image, effectively exit and re-execute
  o  RESTART=NOW  restart the image right now regardless of connections
  o  ZERO         zero accounting

These commands are entered at the DCL command line (interpreted in the CLI.c
module) in the following manner.

  $ HTTPD /DO=command

If /ALL is added then the command is applied to all HTTPd server processes on
the node or cluster (asuming there is more than one executing, requires
SYSLCK).  Due to architectural constraints, those commands marked "*" in the
above list cannot be used with the /ALL qualifier.                    

  $ HTTPD /DO=command /ALL

For example:

  $ HTTPD /DO=EXIT           the server exits if when clients connected
  $ HTTPD /DO=EXIT=NOW       the server exists immediately
  $ HTTPD /DO=RESTART        server exits and then restarts
  $ HTTPD /DO=RESTART/ALL    all servers on node/cluster exit and restarts
  $ HTTPD /DO=DCL=PURGE      delete all persistent DCL script processes
  $ HTTPD /DO=LOG=CLOSE      close the log file
  $ HTTPD /DO=ZERO/ALL       zero the accounting on all servers
  $ HTTPD /DO=LIST/ALL       *special-case*, just list all servers

Node/cluster directives are implemented using cluster-wide locking and resource
names.  Servers could potentially be grouped using these resource names.  The
/ALL qualifier accepts an optional string that will become the lock resource
name.  Hence when servers belonging to a particular group are started up the
startup procedure would include something like "/ALL=1", and then Admin Menu
directives would apply to only those in that group, and command-line directives
would be used "/DO=command/ALL=1", etc.  Note that the /ALL= parameter can be
any alphanumeric string up to 8 characters.


VERSION HISTORY
---------------
03-DEC-2000  MGD  bugfix; CachePurge()
18-JUN-2000  MGD  add node/cluster-wide, sys$enq()-driven directives (/ALL)
12-JAN-2000  MGD  rework control reporting, adding OPCOM messages
20-JAN-1999  MGD  proxy serving controls
15-AUG-1998  MGD  decnet=purge, decnet=disconnect
16-MAR-1998  MGD  restart=now
05-OCT-1997  MGD  cache and logging period control
28-SEP-1997  MGD  reinstated some convenience commands (AUTH, DCL, and ZERO)
01-FEB-1997  MGD  HTTPd version 4 (removed much of its previous functionality)
01-OCT-1996  MGD  minor changes to authorization do commands
01-JUL-1996  MGD  controls for path/realm-based authorization/authentication
01-DEC-1995  MGD  HTTPd version 3
12-APR-1995  MGD  support logging
03-APR-1995  MGD  support authorization
20-DEC-1994  MGD  initial development for multi-threaded version of HTTPd
*/
/*****************************************************************************/

/* standard C header files */
#include <ctype.h>
#include <stdio.h>
#include <string.h>

/* VMS related header files */
#include <descrip.h>
#include <iodef.h>
#include <jpidef.h>
#include <lckdef.h>
#include <lkidef.h>
#include <prvdef.h>
#include <psldef.h>
#include <ssdef.h>
#include <stsdef.h>

/* application-related header files */
#include "wasd.h"

#define WASD_MODULE "CONTROL"

/******************/
/* global storage */
/******************/

/* 5 seconds */
$DESCRIPTOR (ControlCommandTimeoutDsc, "0 00:00:05.00");

boolean  ControlDoAllEnabled,
         ControlDoAllHttpd,
         ControlDoAllLockAstOutstanding,
         ControlExitRequested,
         ControlRestartRequested;

unsigned short  ControlMbxChannel;

unsigned long  ControlPid;

unsigned long  ControlSysLckMask [2] = { PRV$M_SYSLCK, 0 },
               ControlWorldMask [2] = { PRV$M_WORLD, 0 };

char  ControlBuffer [256],
      ControlMbxName [32],
      ControlProcessName [16],
      ControlUserName [13];
      
struct AnIOsb  ControlMbxReadIOsb,
               ControlMbxWriteIOsb;

$DESCRIPTOR (ControlMbxNameDsc, ControlMbxName);
$DESCRIPTOR (ControlMbxNameFaoDsc, "HTTPD!UL$CONTROL");

$DESCRIPTOR (ControlLockNameDsc, "");
struct lksb  ControlLockDoLksb,
             ControlLockWaitLksb;

/********************/
/* external storage */
/********************/

#ifdef DBUG
extern boolean Debug;
#else
#define Debug 0 
#endif

extern boolean  CacheEnabled,
                HttpdServerExecuting,
                MonitorEnabled,
                ProxyServingEnabled,
                OperateWithSysPrv;

extern int  ConnectCountCurrent,
            ExitStatus,
            OpcomMessages,
            ProxyServiceCount,
            ServerPort;

extern char  ErrorSanityCheck[],
             LoggingFileName[],
             LoggingFormatUser[],
             LoggingPeriodName[],
             ServerGroupResName[],
             SoftwareID[],
             Utility[];

extern struct AccountingStruct Accounting;
extern struct ProxyAccountingStruct ProxyAccounting;

/*****************************************************************************/
/*
This, and the other supporting functions, are used by the serving HTTPd 
process.  Create a system-permanent mailbox for the receipt of control 
messages sent by another process.
*/ 

int ControlHttpd ()

{
   /* no world or group access, full owner and system access */
#  define ControlMbxProtectionMask 0xff00

   /*
       PRMMBX to allow a permanent mailbox to be created.
       SYSNAM to create its logical name in the system table.
       SYSPRV just in case it was originally created by a privileged,
              non-HTTPd account (as has happened to me when developing!)
   */
   static unsigned long
      CreMbxPrvMask [2] = { PRV$M_PRMMBX | PRV$M_SYSNAM | PRV$M_SYSPRV, 0 },
      CreMbxSysPrvMask [2] = { PRV$M_PRMMBX | PRV$M_SYSNAM, 0 };
   int  status,
        SetPrvStatus;
   unsigned short  Length;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ControlHttpd()\n");

   if (VMSnok (status =
       sys$fao (&ControlMbxNameFaoDsc, &Length, &ControlMbxNameDsc,
                ServerPort)))
   {
      if (Debug) fprintf (stdout, "sys$fao() %%X%08.08X\n", status);
      return (status);
   }
   ControlMbxName[ControlMbxNameDsc.dsc$w_length = Length] = '\0';
   if (Debug) fprintf (stdout, "ControlMbxName |%s|\n", ControlMbxName);

   /* turn on privileges to allow access to the permanent mailbox */
   if (VMSnok (status = sys$setprv (1, &CreMbxPrvMask, 0, 0)))
   {
      if (Debug) fprintf (stdout, "sys$setprv() %%X%08.08X\n", status);
      return (status);
   }

   status = sys$crembx (1,
                        &ControlMbxChannel,
                        sizeof(ControlBuffer),
                        sizeof(ControlBuffer),
                        ControlMbxProtectionMask,
                        PSL$C_USER,
                        &ControlMbxNameDsc,
                        0);
   if (Debug) fprintf (stdout, "sys$crembx() %%X%08.08X\n", status);

   if (VMSok (status))
   {
     /* pro-actively mark the mailbox for deletion */
      status = sys$delmbx (ControlMbxChannel);
      if (Debug) fprintf (stdout, "sys$delmbx() %%X%08.08X\n", status);
   }

   /* if normally operating with SYSPRV on then do not turn it off */
   if (OperateWithSysPrv)
      SetPrvStatus = sys$setprv (0, &CreMbxSysPrvMask, 0, 0);
   else
      SetPrvStatus = sys$setprv (0, &CreMbxPrvMask, 0, 0);
   if (VMSnok (SetPrvStatus))
   {
      if (Debug) fprintf (stdout, "sys$setprv() %%X%08.08X\n", SetPrvStatus);
      /* do NOT keep processing if there is a problem turning them off! */
      ErrorExitVmsStatus (SetPrvStatus, "sys$setprv()", FI_LI);
   }

   if (VMSnok (status)) return (status);

   /* queue up the first asynchronous read from the control mailbox */
   return (sys$qio (0, ControlMbxChannel, IO$_READVBLK, &ControlMbxReadIOsb,
                    &ControlMbxReadAst, 0,
                    ControlBuffer, sizeof(ControlBuffer)-1, 0, 0, 0, 0));
}

/*****************************************************************************/
/*
An asynchronous read from the system-permanent control mailbox has completed.  
Act on the command string read into the buffer.
*/ 

ControlMbxReadAst ()

{
   static boolean  NoWorldPriv;
   static unsigned long  GetJpiControlFlags = JPI$M_IGNORE_TARGET_STATUS;

   static struct
   {
      unsigned short  buf_len;
      unsigned short  item;
      unsigned char   *buf_addr;
      unsigned short  *short_ret_len;
   }
   JpiItems [] =
   {
      { sizeof(GetJpiControlFlags), JPI$_GETJPI_CONTROL_FLAGS,
        &GetJpiControlFlags, 0 },
      { sizeof(ControlPid), JPI$_PID, &ControlPid, 0 },
      { sizeof(ControlProcessName), JPI$_PRCNAM, &ControlProcessName, 0 },
      { sizeof(ControlUserName), JPI$_USERNAME, &ControlUserName, 0 },
      { 0,0,0,0 }
   };

   register char  *cptr, *sptr;

   int  status;
   char  Scratch [256];

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout,
               "ControlMbxReadAst() Count: %d Status: %%X%08.08X PID: 08.08X\n",
               ControlMbxReadIOsb.Count,
               ControlMbxReadIOsb.Status,
               ControlMbxReadIOsb.MbxPid);

   if (VMSnok (status = ControlMbxReadIOsb.Status) &&
       ControlMbxReadIOsb.Status != SS$_ABORT &&
       ControlMbxReadIOsb.Status != SS$_CANCEL)
      ErrorExitVmsStatus (status, "ControlMbxReadAst()", FI_LI);

   ControlPid = ControlMbxReadIOsb.MbxPid;

   /* use WORLD to allow access to other processes */
   status = ControlEnableWorld ();
   if (VMSnok (status) || status == SS$_NOTALLPRIV)
   {
      if (!NoWorldPriv)
      {
         NoWorldPriv = true;
         fprintf (stdout, "%%%s-W-CONTROL, installed without WORLD privilege\n",
                  Utility);
      }
   }

   if (!NoWorldPriv)
   {
      status = sys$getjpiw (0, &ControlPid, 0, &JpiItems, 0, 0, 0);
      if (Debug) fprintf (stdout, "sys$getjpiw() %%X%08.08X\n", status);
   }
   else
      status = SS$_NOPRIV;
   if (VMSok (status))
   {
      ControlUserName[12] = '\0';
      for (cptr = ControlUserName; *cptr && *cptr != ' '; cptr++);
      *cptr = '\0';
      if (Debug)
         fprintf (stdout, "ControlUserName |%s|\n", ControlUserName);

      (cptr = ControlProcessName)[15] = '\0';
      cptr--;
      while (cptr > ControlProcessName && *cptr == ' ') cptr--;
      *cptr = '\0';
      if (Debug)
         fprintf (stdout, "ControlProcessName |%s|\n", ControlProcessName);
   }
   else
   {
      strcpy (ControlProcessName, "?");
      strcpy (ControlUserName, "?");
   }

   ControlDisableWorld ();

   ControlBuffer[ControlMbxReadIOsb.Count] = '\0';
   if (Debug) fprintf (stdout, "ControlBuffer |%s|\n", ControlBuffer);

   if (strsame (ControlBuffer, CONTROL_AUTH_LOAD, -1))
   {
      if (VMSok (AuthConfigInit ()))
         ControlMessage ("authorization loaded");
      else
         ControlMessage ("!loading authorization rules");
      return;
   }
   if (strsame (ControlBuffer, CONTROL_AUTH_PURGE, -1))
   {
      AuthCacheTreeFree ();
      ControlMessage ("authentication cache purged");
      return;
   }
   if (strsame (ControlBuffer, CONTROL_CACHE_ON, -1))
   {
      if (CacheEnabled)
         ControlMessage ("!cache already enabled");
      else
      {
         CacheEnabled = true;
         ControlMessage ("cache enabled");
      }
      return;
   }
   if (strsame (ControlBuffer, CONTROL_CACHE_OFF, -1))
   {
      if (CacheEnabled)
      {
         CacheEnabled = false;
         ControlMessage ("cache disabled");
      }
      else
         ControlMessage ("!cache already disabled");
      return;
   }
   if (strsame (ControlBuffer, CONTROL_CACHE_PURGE, -1))
   {
      int  PurgeCount, MarkedForPurgeCount;
      CachePurge (false, &PurgeCount, &MarkedForPurgeCount);
      sprintf (Scratch, "%d purged, %d marked for purge",
               PurgeCount, MarkedForPurgeCount);
      ControlMessage (Scratch);
      return;
   }
   if (strsame (ControlBuffer, CONTROL_DCL_DELETE, -1))
   {
      cptr = DclControlPurgeScriptProcesses (true);
      ControlMessage (cptr);
      return;
   }
   if (strsame (ControlBuffer, CONTROL_DCL_PURGE, -1))
   {
      cptr = DclControlPurgeScriptProcesses (false);
      ControlMessage (cptr);
      return;
   }
   if (strsame (ControlBuffer, CONTROL_DECNET_DISCONNECT, -1))
   {
      cptr = DECnetControlDisconnect (true);
      ControlMessage (cptr);
      return;
   }
   if (strsame (ControlBuffer, CONTROL_DECNET_PURGE, -1))
   {
      cptr = DECnetControlDisconnect (false);
      ControlMessage (cptr);
      return;
   }
   if (strsame (ControlBuffer, CONTROL_EXIT, -1))
   {
      if (ConnectCountCurrent)
      {
         /* stop the server from receiving incoming requests */
         NetShutdownServerSocket ();
         ControlExitRequested = true;
         ControlMessage ("exiting when all clients disconnected");
         return;
      }
      else
      {
         ControlMessage ("exiting now");
         ExitStatus = SS$_NORMAL;
         HttpdExit (&ExitStatus);
         sys$delprc (0, 0);
      }
   }
   else
   if (strsame (ControlBuffer, CONTROL_EXIT_NOW, -1) ||
       strsame (ControlBuffer, CONTROL_ABORT, -1))
   {
      ControlMessage ("server exit NOW!");
      ExitStatus = SS$_NORMAL;
      HttpdExit (&ExitStatus);
      sys$delprc (0, 0);
   }
   else
   if (strsame (ControlBuffer, CONTROL_LOG_OPEN_AS, -1))
   {
      strcpy (Scratch, "log opened");
      cptr = ControlBuffer;
      while (*cptr && *cptr != '=') cptr++;
      if (*cptr) cptr++;
      while (*cptr && *cptr != '=') cptr++;
      if (*cptr)
      {
         cptr++;
         sptr = LoggingFileName;
         while (*cptr) *sptr++ = toupper(*cptr++);
         *sptr = '\0';
         sprintf (Scratch+10, "\n \\%s\\", LoggingFileName);
      }
      if (VMSok (Logging (NULL, LOGGING_OPEN)))
         ControlMessage (Scratch);
      else
         ControlMessage ("!log not opened");
      return;
   }
   if (strsame (ControlBuffer, CONTROL_LOG_CLOSE, -1))
   {
      if (VMSok (Logging (NULL, LOGGING_CLOSE)))
         ControlMessage ("log closed");
      else
         ControlMessage ("!log not closed");
      return;
   }
   if (strsame (ControlBuffer, CONTROL_LOG_FLUSH, -1))
   {
      if (VMSok (Logging (NULL, LOGGING_FLUSH)))
         ControlMessage ("log flushed");
      else
         ControlMessage ("!log not flushed");
      return;
   }
   if (strsame (ControlBuffer, CONTROL_LOG_FORMAT_AS, -1))
   {
      cptr = ControlBuffer;
      while (*cptr && *cptr != '=') cptr++;
      if (*cptr) cptr++;
      while (*cptr && *cptr != '=') cptr++;
      if (*cptr)
      {
         strcpy (LoggingFormatUser, cptr+1);
         sprintf (Scratch, "log format changed\n \\%s\\",
                  LoggingFormatUser);
         ControlMessage (Scratch);
         return;
      }
      ControlMessage ("!syntax error");
      return;
   }
   if (strsame (ControlBuffer, CONTROL_LOG_PERIOD_AS, -1))
   {
      cptr = ControlBuffer;
      while (*cptr && *cptr != '=') cptr++;
      if (*cptr) cptr++;
      while (*cptr && *cptr != '=') cptr++;
      if (*cptr)
      {
         strcpy (LoggingPeriodName, cptr+1);
         sprintf (Scratch, "log period changed\n \\%s\\",
                  LoggingFormatUser);
         ControlMessage (Scratch);
         return;
      }
      ControlMessage ("!syntax error");
      return;
   }
   if (strsame (ControlBuffer, CONTROL_LOG_REOPEN_AS, -1))
   {
      cptr = ControlBuffer;
      while (*cptr && *cptr != '=') cptr++;
      if (*cptr) cptr++;
      while (*cptr && *cptr != '=') cptr++;
      if (*cptr)
      {
         cptr++;
         sptr = LoggingFileName;
         while (*cptr) *sptr++ = toupper(*cptr++);
         *sptr = '\0';
         sprintf (Scratch, "log reopened\n \\%s\\", LoggingFileName);
      }
      else
         strcpy (Scratch, "log reopened");
      if (VMSnok (Logging (NULL, LOGGING_CLOSE)))
      {
         ControlMessage ("!log not closed");
         return;
      }
      if (VMSok (Logging (NULL, LOGGING_OPEN)))
         ControlMessage (Scratch);
      else
         ControlMessage ("!log not reopened");
      return;
   }
   if (strsame (ControlBuffer, CONTROL_MAP, -1))
   {
      cptr = MapUrl_Load();
      if (!cptr[0] && cptr[1])
      {
         /* error */
         Scratch[0] = '!';
         strcpy (Scratch+1, cptr+1);
         ControlMessage (Scratch);
      }
      else
         ControlMessage ("mapping rules loaded");
      return;
   }
   if (strsame (ControlBuffer, CONTROL_PROXY_ON, -1))
   {
      if (ProxyServingEnabled)
         ControlMessage ("!proxy serving already enabled");
      else
      {
         ProxyServingEnabled = ProxyAccounting.ServingEnabled = true;
         ControlMessage ("proxy serving enabled");
      }
      return;
   }
   if (strsame (ControlBuffer, CONTROL_PROXY_OFF, -1))
   {
      if (!ProxyServingEnabled)
         ControlMessage ("!proxy serving already disabled");
      else
      {
         ProxyServingEnabled = ProxyAccounting.ServingEnabled = false;
         ControlMessage ("proxy serving disabled");
      }
      return;
   }
   if (strsame (ControlBuffer, CONTROL_PROXY_PURGE_HOST, -1))
   {
      ProxyResolveHostCache (NULL, NULL, 0);
      ControlMessage ("purged proxy host name cache");
      return;
   }
   if (strsame (ControlBuffer, CONTROL_PROXY_PURGE_REACTIVE, -1))
   {
      if (ProxyMaintScanBegin (PROXY_MAINT_SCAN_REACTIVE))
         ControlMessage ("beginning reactive proxy cache purge");
      else
         ControlMessage ("!reactive proxy cache purge NOT STARTED");
      return;
   }
   if (strsame (ControlBuffer, CONTROL_PROXY_PURGE_ROUTINE, -1))
   {
      if (ProxyMaintScanBegin (PROXY_MAINT_SCAN_ROUTINE))
         ControlMessage ("beginning routine proxy cache purge");
      else
         ControlMessage ("!routine proxy cache purge NOT STARTED");
      return;
   }
   if (strsame (ControlBuffer, CONTROL_RESTART, -1))
   {
      /* relies on the supporting DCL procedure looping immediately */
      if (ConnectCountCurrent)
      {
         /* stop the server from receiving incoming requests */
         ControlMessage ("restarting when all clients disconnected");
         NetShutdownServerSocket ();
         ControlRestartRequested = true;
         return;
      }
      else
      {
         ControlMessage ("restarting now");
         sleep (1);
         exit (SS$_NORMAL);
      }
   }
   if (strsame (ControlBuffer, CONTROL_RESTART_NOW, -1))
   {
      /* relies on the supporting DCL procedure looping immediately */
      ControlMessage ("restarting NOW!");
      sleep (1);
      exit (SS$_NORMAL);
   }
   if (strsame (ControlBuffer, CONTROL_ZERO, -1))
   {
      ZeroAccounting ();
      ControlMessage ("accounting zeroed");
      return;
   }

   /*********/
   /* what? */
   /*********/

   /* all handled situations must return/exit before here */
   ControlMessage ("!directive not understood!");
}

/*****************************************************************************/
/*
This is the function used by the controlling process.  Synchronously write the 
command to the HTTPd control mailbox, then synchronously read the response.  
Set a timer to limit the wait for the command to be read, and then response to 
be written, by the HTTPd process.
*/ 

int ControlCommand (char *Command)

{
   int  status;
   unsigned short  Length;
   unsigned long  CommandTimeout[2];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ControlCommand() |%s|\n", Command);

   if (VMSnok (status =
       sys$fao (&ControlMbxNameFaoDsc, &Length, &ControlMbxNameDsc,
                ServerPort)))
   {
      if (Debug) fprintf (stdout, "sys$fao() %%X%08.08X\n", status);
      return (status);
   }
   ControlMbxName[ControlMbxNameDsc.dsc$w_length = Length] = '\0';
   if (Debug) fprintf (stdout, "ControlMbxName |%s|\n", ControlMbxName);

   if (VMSnok (status =
       sys$assign (&ControlMbxNameDsc, &ControlMbxChannel, 0, 0, 0)))
   {
      if (status == SS$_NOSUCHDEV)
      {
         fprintf (stdout,
         "%%%s-E-NOSUCHDEV, server (control mailbox) does not exist\n",
         Utility);
         return (status | STS$M_INHIB_MSG);
      }
      return (status);
   }

   /* initialize a delta-time seconds structure used in sys$setimr() */
   if (VMSnok (status =
       sys$bintim (&ControlCommandTimeoutDsc, &CommandTimeout)))
   {
      if (Debug) fprintf (stdout, "sys$bintim() %%X%08.08X\n", status);
      exit (status);
   }

   status = sys$setimr (0, &CommandTimeout, &ControlCommandTimeoutAst, 0, 0);
   if (Debug) fprintf (stdout, "sys$setimr() %%X%08.08X\n", status);

   /* synchronously write the command to the HTTPd process */
   status = sys$qiow (0, ControlMbxChannel, IO$_WRITEVBLK,
                      &ControlMbxReadIOsb, 0, 0,
                      Command, strlen(Command), 0, 0, 0, 0);
   if (Debug)
      fprintf (stdout, "sys$qiow() %%X%08.08X IOsb.Status: %%X%08.08X\n",
               status, ControlMbxReadIOsb.Status);
   if (VMSok (status) && VMSnok (ControlMbxReadIOsb.Status))
      status = ControlMbxReadIOsb.Status;
   if (status == SS$_ABORT)
   {
      /* timer has expired */
      fprintf (stdout,
      "%%%s-E-TIMEOUT, server failed to respond within 5 seconds\n",
      Utility);
      return (SS$_TIMEOUT | STS$M_INHIB_MSG);
   }
   if (VMSnok (status)) return (status);

   /* read the acknowledgement from the HTTPd process */
   status = sys$qiow (0, ControlMbxChannel, IO$_READVBLK,
                      &ControlMbxReadIOsb, 0, 0,
                      ControlBuffer, sizeof(ControlBuffer)-1, 0, 0, 0, 0);
   if (Debug)
      fprintf (stdout, "sys$qiow() %%X%08.08X IOsb.Status: %%X%08.08X\n",
               status, ControlMbxReadIOsb.Status);
   if (VMSok (status) && VMSnok (ControlMbxReadIOsb.Status))
      status = ControlMbxReadIOsb.Status;
   if (VMSok (status))
   {
      ControlBuffer[ControlMbxReadIOsb.Count] = '\0';
      if (Debug) fprintf (stdout, "%s\n", ControlBuffer);
   }

   if (status == SS$_ABORT)
   {
      /* timer has expired */
      fprintf (stdout,
         "%%%s-E-TIMEOUT, server failed to respond within 5 seconds\n",
         Utility);
      return (SS$_TIMEOUT | STS$M_INHIB_MSG);
   }
   if (VMSnok (status)) return (status);

   /* cancel the timer */
   sys$cantim (0, 0);

   /* present the response to the user (leading '!' indicates an error) */
   if (ControlBuffer[0] == '!')
      fprintf (stdout, "%%%s-E-RESPONSE, %s\n", Utility, ControlBuffer+1);
   else
      fprintf (stdout, "%%%s-I-RESPONSE, %s\n", Utility, ControlBuffer);

   return (status);
}

/*****************************************************************************/
/*
Report a control request/response, to the process log (SYS$OUTPUT) and
optionally as OPCOM messages.  Also queue as an I/O to the mailbox with AST. 
When the I/O completes the AST routine queues another read from the control
mailbox, setting the situation for another control command to be sent to the
HTTPd.  This function should always be called as the final I/O of control
output.
*/

ControlMessage (char *String)

{
   int  status;

   if (Debug) fprintf (stdout, "ControlMessage()\n");

   if (String[0] == '!')
   {
      WriteFaoStdout (
"%!AZ-I-CONTROL, !20%D, !8XL !AZ \"!AZ\", \'!AZ\'\n\
-!AZ-E-RESPONSE, \'!AZ\'\n",
         Utility, 0, ControlPid, ControlUserName, ControlProcessName,
         ControlBuffer, Utility, String+1);

      if (OpcomMessages & OPCOM_CONTROL)
         WriteFaoOpcom (
"%!AZ-I-CONTROL, !8XL !AZ \"!AZ\", \'!AZ\'\r\n\
-!AZ-E-RESPONSE, \'!AZ\'",
            Utility, ControlPid, ControlUserName, ControlProcessName,
            ControlBuffer, Utility, String+1);
   }
   else
   {
      WriteFaoStdout (
"%!AZ-I-CONTROL, !20%D, !8XL !AZ \"!AZ\", \'!AZ\'\n\
-!AZ-I-RESPONSE, \'!AZ\'\n",
         Utility, 0, ControlPid, ControlUserName, ControlProcessName,
         ControlBuffer, Utility, String);

      if (OpcomMessages & OPCOM_CONTROL)
         WriteFaoOpcom (
"%!AZ-I-CONTROL, !8XL !AZ \"!AZ\", \'!AZ\'\r\n\
-!AZ-I-RESPONSE, \'!AZ\'",
               Utility, ControlPid, ControlUserName, ControlProcessName,
               ControlBuffer, Utility, String);
   }

   status = sys$qio (0, ControlMbxChannel, IO$_WRITEVBLK,
                     &ControlMbxWriteIOsb, &ControlMbxWriteAst, 0,
                     String, strlen(String), 0, 0, 0, 0);
   if (Debug) fprintf (stdout, "sys$qio() %%X%08.08X\n", status);
}

/*****************************************************************************/
/*
This function is called after the HTTPd process has asynchronously written a 
response back to the controlling process, and that I/O has been read.  It 
merely queues another asynchronous read from the control mailbox.
*/ 

ControlMbxWriteAst ()

{
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout,
               "ControlMbxWriteAst() IO %d Status %%X%08.08X\n",
               ControlMbxWriteIOsb.Count, ControlMbxWriteIOsb.Status);

   /* queue up another read from the control mailbox */
   sys$qio (0, ControlMbxChannel, IO$_READVBLK, &ControlMbxReadIOsb,
            &ControlMbxReadAst, 0,
            ControlBuffer, sizeof(ControlBuffer)-1, 0, 0, 0, 0);
}

/*****************************************************************************/
/*
When the timer expires this function is called as an AST routine.  It merely 
cancels the outstanding I/O on the control mailbox channel.  This is detected 
by an I/O return code of SS$_CANCEL.
*/

ControlCommandTimeoutAst ()

{
   if (Debug) fprintf (stdout, "ControlCommandTimeoutAst()\n");

   sys$cancel (ControlMbxChannel);
}

/*****************************************************************************/
/*
Exits or restarts the server after a short delay.  This delay is introduced to
give a controlling request (e.g. via the Admin Menu) a chance to complete
processing (e.g. deliver success message) before the action is taken.

Is called directly by the requesting function with a parameter of
CONTROL_DELAY_EXIT or CONTROL_DELAY_RESTART.  A timer with AST delivery back to
this function is set, the AST parameter the same as the original with a flag
inserted indicating it really should be done *this* time!
*/

ControlDelay (int Action)

{
   static unsigned long  OneSecondDelta [2] = { -10000000, -1 };

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ControlDelay() %d\n", Action);

   if (!(Action & CONTROL_DELAY_DO))
   {
      status = sys$setimr (0, &OneSecondDelta, &ControlDelay,
                           Action | CONTROL_DELAY_DO, 0);
      if (VMSnok (status)) ErrorExitVmsStatus (status, "sys$setimr()", FI_LI);
      return;
   }

   switch (Action & ~CONTROL_DELAY_DO)
   {
      case CONTROL_DELAY_EXIT :

         ExitStatus = SS$_NORMAL;
         HttpdExit (&ExitStatus);
         sys$delprc (0, 0);

      case CONTROL_DELAY_RESTART :

         exit (SS$_NORMAL);

      default :

         ErrorExitVmsStatus (SS$_BUGCHECK, ErrorSanityCheck, FI_LI);
   }
}

/*****************************************************************************/
/*
*/

ControlEnableSysLck ()

{
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ControlEnableSysLck()\n");

   status = sys$setprv (1, &ControlSysLckMask, 0, 0);
   if (Debug) fprintf (stdout, "sys$setprv() %%X%08.08X\n", status);
   return (status);
}

/*****************************************************************************/
/*
*/

ControlDisableSysLck ()

{
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ControlDisableSysLck()\n");

   status = sys$setprv (0, &ControlSysLckMask, 0, 0);
   if (Debug) fprintf (stdout, "sys$setprv() %%X%08.08X\n", status);
   if (VMSnok (status))
   {
      /* do NOT keep processing if there is a problem turning them off! */
      ErrorExitVmsStatus (status, "sys$setprv()", FI_LI);
   }
   return (status);
}

/*****************************************************************************/
/*
*/

ControlEnableWorld ()

{
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ControlEnableWorld()\n");

   status = sys$setprv (1, &ControlWorldMask, 0, 0);
   if (Debug) fprintf (stdout, "sys$setprv() %%X%08.08X\n", status);
   return (status);
}

/*****************************************************************************/
/*
*/

ControlDisableWorld ()

{
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ControlDisableWorld()\n");

   status = sys$setprv (0, &ControlWorldMask, 0, 0);
   if (Debug) fprintf (stdout, "sys$setprv() %%X%08.08X\n", status);
   if (VMSnok (status))
   {
      /* do NOT keep processing if there is a problem turning them off! */
      ErrorExitVmsStatus (status, "sys$setprv()", FI_LI);
   }
   return (status);
}

/*****************************************************************************/
/*
Enqueues a CR (concurrent read) lock on the specified resource name.  This sits
waiting for a blocking AST to be delivered indicating a server is wishing to
initiate a cluster-wide action by enqueuing an EX (exclusive) lock for the same
resource.  Release the lock then immediately enqueue another read so that the
lock value block subsequently written to by the EX mode lock is read.  This
will contain a maximum 16 byte, zero-terminated string with the command.  The
AST delivery will provide this value block to ControlAllHttpdAst().
*/

int ControlAllHttpd (int AstParam)

{
   int  status,
        slen;
   char  *cptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ControlAllHttpd() %d\n", AstParam);

   /* turn on SYSLCK to allow SYSTEM locks to be enqueued */
   status = ControlEnableSysLck ();
   if (status == SS$_NOTALLPRIV)
   {
      WriteFaoStdout ("%!AZ-W-CONTROL, no SYSLCK, /DO=/ALL disabled\n",
                      Utility);
      if (OpcomMessages & OPCOM_CONTROL)
         WriteFaoOpcom ("%!AZ-W-CONTROL, no SYSLCK, /DO=/ALL disabled");
      ControlDoAllEnabled = false;
      return (status);
   }

   if (!AstParam)
   {
      /******************/
      /* server startup */
      /******************/

      /* remember, a specific resource name can also be set using /ALL= */
      ControlLockNameDsc.dsc$a_pointer = ServerGroupResName;
      ControlLockNameDsc.dsc$w_length = strlen(ServerGroupResName);
      if (Debug)
        fprintf (stdout, "%d |%s|\n",
                 ControlLockNameDsc.dsc$w_length,
                 ControlLockNameDsc.dsc$a_pointer);

      /* when this lock goes 'blocking' call this self-same function with (1) */
      status = sys$enqw (0, LCK$K_CRMODE, &ControlLockWaitLksb,
                         LCK$M_SYSTEM, &ControlLockNameDsc, 0,
                         0, 1, &ControlAllHttpd, 0, 2, 0);
      if (Debug) fprintf (stdout, "CR sys$enqw() %%X%08.08X\n", status);
      if (VMSok (status))
         ControlDoAllEnabled = true;
      else
      {
         ErrorNoticed (status, "sys$enqw()", FI_LI);
         ControlDoAllEnabled = false;
      }

      ControlDisableSysLck ();

      return (status);
   }

   /******************************************/
   /* AST delivery, lock is blocking EX mode */
   /******************************************/

   /* dequeue the original 'waiting' lock */
   status = sys$deq (ControlLockWaitLksb.lksb$l_lkid, 0, 0, 0);
   if (Debug) fprintf (stdout, "sys$deq() %%X%08.08X\n", status);
   if (VMSnok (status))
   {
      ErrorNoticed (status, "sys$deq()", FI_LI);
      ControlDoAllEnabled = false;
      ControlDisableSysLck ();
      return (status);
   }

   /* 
      Enqueue a lock ready to read the lock value block.  This lock will
      stay in the waiting queue until after the controlling process has
      enqueued/dequeued the EX mode lock (see ControlDoAllLock()) at which
      time it will AST to ControlAllHttpdAst().
      This CR lock is then left on the granted queue as the "interested-party"
      lock ready for the next directive, ASTing to ControlAllHttpd().
      Note: this is NOT a sys$enqw(), it's asynchronous!
   */
   status = sys$enq (0, LCK$K_CRMODE, &ControlLockWaitLksb,
                     LCK$M_VALBLK | LCK$M_SYSTEM,  &ControlLockNameDsc, 0,
                     &ControlAllHttpdAst, 1, &ControlAllHttpd, 0, 2, 0);
   if (Debug) fprintf (stdout, "CR sys$enq() %%X%08.08X\n", status);
   if (VMSnok (status))
   {
      ErrorNoticed (status, "sys$enqw()", FI_LI);
      ControlDoAllEnabled = false;
   }

   ControlDisableSysLck ();
   return (status);
}

/*****************************************************************************/
/*
The EX (exclusive) lock enqueued by the controlling process has been dequeued
allowing this AST to be delivered.  The control directive is now in the lock
value block.  Do what it is requesting.  This AST is required to allow
AdminControl() to use it as part of an executing server, which also requires an
*/

ControlAllHttpdAst ()

{
   int  status,
        slen;
   char  *cptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ControlAllHttpdAst()\n");

   /* get the lock value block written by the dequeued EX mode lock */
   cptr = ControlLockWaitLksb.lksb$b_valblk;
   slen = strlen(cptr);
   if (Debug) fprintf (stdout, "cptr %d |%s|\n", slen, cptr);

   WriteFaoStdout ("%!AZ-I-DOALL, !20%D, \'!AZ\'\n", Utility, 0, cptr);

   if (OpcomMessages & OPCOM_CONTROL)
      WriteFaoOpcom ("%!AZ-I-DOALL, \'!AZ\'", Utility, cptr);

   if (strsame (cptr, CONTROL_AUTH_LOAD, -1))
      AuthConfigInit ();
   else
   if (strsame (cptr, CONTROL_AUTH_PURGE, -1))
      AuthCacheTreeFree ();
   else
   if (strsame (cptr, CONTROL_CACHE_ON, -1))
      CacheEnabled = true;
   else
   if (strsame (cptr, CONTROL_CACHE_OFF, -1))
      CacheEnabled = false;
   else
   if (strsame (cptr, CONTROL_CACHE_PURGE, -1))
      CachePurge (false, NULL, NULL);
   else
   if (strsame (cptr, CONTROL_DCL_DELETE, -1))
      DECnetControlDisconnect (true);
   else
   if (strsame (cptr, CONTROL_DCL_PURGE, -1))
      DclControlPurgeScriptProcesses (false);
   else
   if (strsame (cptr, CONTROL_DECNET_PURGE, -1))
      DECnetControlDisconnect (true);
   else
   if (strsame (cptr, CONTROL_DECNET_DISCONNECT, -1))
      DECnetControlDisconnect (false);
   else
   if (strsame (cptr, CONTROL_EXIT, -1))
   {
      if (ConnectCountCurrent)
      {
         /* stop the server from receiving incoming requests */
         NetShutdownServerSocket ();
         ControlExitRequested = true;
      }
      else
         ControlDelay (CONTROL_DELAY_EXIT);
   }
   else
   if (strsame (cptr, CONTROL_EXIT_NOW, -1))
      ControlDelay (CONTROL_DELAY_EXIT);
   else
   if (strsame (cptr, CONTROL_LOG_OPEN, -1))
      Logging (NULL, LOGGING_OPEN);
   else
   if (strsame (cptr, CONTROL_LOG_CLOSE, -1))
      Logging (NULL, LOGGING_CLOSE);
   else
   if (strsame (cptr, CONTROL_LOG_FLUSH, -1))
      Logging (NULL, LOGGING_FLUSH);
   else
   if (strsame (cptr, CONTROL_MAP, -1))
      MapUrl_Load ();
   else
   if (strsame (cptr, CONTROL_PROXY_ON, -1))
   {
      if (ProxyServiceCount)
         ProxyServingEnabled = ProxyAccounting.ServingEnabled = true;
   }
   else
   if (strsame (cptr, CONTROL_PROXY_OFF, -1))
   {
      if (ProxyServiceCount)
         ProxyServingEnabled = ProxyAccounting.ServingEnabled = false;
   }
   else
   if (strsame (cptr, CONTROL_PROXY_PURGE_REACTIVE, slen))
   {
      if (ProxyServiceCount)
         ProxyMaintScanBegin (PROXY_MAINT_SCAN_REACTIVE);
   }
   else
   if (strsame (cptr, CONTROL_PROXY_PURGE_ROUTINE, slen))
   {
      if (ProxyServiceCount)
         ProxyMaintScanBegin (PROXY_MAINT_SCAN_ROUTINE);
   }
   else
   if (strsame (cptr, CONTROL_PROXY_PURGE_HOST, slen))
   {
      if (ProxyServiceCount)
         ProxyResolveHostCache (NULL, NULL, 0);
   }
   else
   if (strsame (cptr, CONTROL_RESTART, -1))
   {
      if (ConnectCountCurrent)
      {
         /* stop the server from receiving incoming requests */
         NetShutdownServerSocket ();
         ControlRestartRequested = true;
      }
      else
         ControlDelay (CONTROL_DELAY_RESTART);
   }
   else
   if (strsame (cptr, CONTROL_RESTART_NOW, -1))
      ControlDelay (CONTROL_DELAY_RESTART);
   else
   if (strsame (cptr, CONTROL_ZERO, -1))
      ZeroAccounting ();
}

/*****************************************************************************/
/*
CR locks indicate server involvement.  NL locks any other utility, etc., (e.g.
httpdmon) that may have an interest in the server locks.  This function gets
all lock associated with the server group resource and then goes through them
noting each CR lock.  From these it can set the count of the the number of
servers in the group (number of CR locks) and/or create a list of the processes
with these CR locks.  It returns a pointer to a string containing either an
error message or the list of processes.
*/

char* ControlAllHttpdList
(
char *Separator,
int *CrLockCountPtr
)
{
   static int  ListBufferSize = 0;
   static unsigned short  JpiNodeNameLen,
                          JpiPrcNamLen;
   static char  *ListBufferPtr = NULL;
   static char  JpiNodeName [7],
                JpiPrcNam [16];

   static struct
   {
      unsigned short  buf_len;
      unsigned short  item;
      unsigned char   *buf_addr;
      unsigned short  *short_ret_len;
   }
   JpiItems [] =
   {
      { sizeof(JpiNodeName)-1, JPI$_NODENAME, &JpiNodeName, &JpiNodeNameLen },
      { sizeof(JpiPrcNam)-1, JPI$_PRCNAM, &JpiPrcNam, &JpiPrcNamLen },
      { 0,0,0,0 }
   };

   static struct
   {
      unsigned short  TotalLength,  /* bits 0..15 */
                      LockLength;  /* bits 16..30 */
   } ReturnLength;

   static struct
   {
      unsigned short  buf_len;
      unsigned short  item;
      unsigned char   *buf_addr;
      unsigned long  *long_ret_len;
   }
   LkiItems [] =
   {
      { 0, LKI$_LOCKS, 0, &ReturnLength },
      {0,0,0,0}
   };

   int  status,
        ListBytes,
        LockCount,
        RqMode;
   unsigned long  LkiPid;
   char  *liptr;
   char  LockInfo [2048];  /* at 56 bytes per lock is ~35 servers */

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ControlAllHttpdList()\n");

   if (CrLockCountPtr != NULL) *CrLockCountPtr = 0;

   if (!ControlDoAllEnabled) return ("not enabled");

   LkiItems[0].buf_addr = LockInfo;
   LkiItems[0].buf_len = sizeof(LockInfo);

   /* turn on SYSLCK to allow SYSTEM locks to be queried */
   status = ControlEnableSysLck ();
   if (VMSnok (status) || status == SS$_NOTALLPRIV) return ("!no SYSLCK");

   /* if this is not a CLI command then use the server waiting CR lock ID */
   if (HttpdServerExecuting)
      status = sys$getlkiw (0, &ControlLockWaitLksb.lksb$l_lkid, &LkiItems,
                            0, 0, 0, 0);
   else
      status = sys$getlkiw (0, &ControlLockDoLksb.lksb$l_lkid, &LkiItems,
                            0, 0, 0, 0);
   if (Debug) fprintf (stdout, "sys$getlkiw() %%X%08.08X\n", status);

   /* turn off SYSLCK */
   ControlDisableSysLck ();

   if (VMSnok (status))
   {
      ErrorNoticed (status, "sys$getlkiw()", FI_LI);
      return ("!failed to get lock information");
   }

   if (ReturnLength.LockLength)
   {
      if (ReturnLength.LockLength & 0x8000)
         return ("!insufficient space!");
      LockCount = ReturnLength.TotalLength / ReturnLength.LockLength;
   }
   else
      LockCount = 0;

   if (Debug)
      fprintf (stdout, "LockLength: %d TotalLength: %d count:%d\n",
               ReturnLength.LockLength, ReturnLength.TotalLength, LockCount);

   if (LockCount <= 1) return ("!no other servers!");

   ListBytes = (sizeof(JpiNodeName) + sizeof(JpiPrcNam) +
                strlen(Separator) + 2) * LockCount;
   if (Debug) fprintf (stdout, "ListBytes: %d\n", ListBytes);
   if (ListBytes > ListBufferSize)
   {
      if (ListBufferPtr != NULL) VmFree (ListBufferPtr, FI_LI);
      ListBufferPtr = VmGet (ListBufferSize = ListBytes);
   }
   ListBufferPtr[0] = '\0';

   /* use WORLD to allow access to other processes */
   status = ControlEnableWorld ();
   if (VMSnok (status) || status == SS$_NOTALLPRIV) return ("!no WORLD");

   liptr = &LockInfo;
   while (LockCount--)
   {
      LkiPid = ((unsigned long*)liptr)[1];
      RqMode = ((unsigned char*)liptr)[12];
      liptr += ReturnLength.LockLength;
      if (Debug) fprintf (stdout, "PID: %08.08X RqMode: %d\n", LkiPid, RqMode);

      /* only counting CR locks */
      if (RqMode != LCK$K_CRMODE) continue;
      if (CrLockCountPtr != NULL) *CrLockCountPtr += 1;

      /* if not interested in generating a list */
      if (Separator == NULL) continue;

      status = sys$getjpiw (0, &LkiPid, 0, &JpiItems, 0, 0, 0);
      if (Debug) fprintf (stdout, "sys$getjpiw() %%X%08.08X\n", status);
      if (VMSnok (status)) continue;

      JpiNodeName[JpiNodeNameLen] = '\0';
      JpiPrcNam[JpiPrcNamLen] = '\0';
      if (Debug) fprintf (stdout, "|%s|%s|\n", JpiNodeName, JpiPrcNam);

      if (ListBufferPtr[0]) strcat (ListBufferPtr, Separator);
      strcat (ListBufferPtr, JpiNodeName);
      strcat (ListBufferPtr, "::");
      strcat (ListBufferPtr, JpiPrcNam);
   }

   ControlDisableWorld ();

   if (Debug && CrLockCountPtr != NULL)
      fprintf (stdout, "*CrLockCountPtr: %d\n", *CrLockCountPtr);

   return (ListBufferPtr);
}

/*****************************************************************************/
/*
Check that the command is known and can be done via a /ALL or via the
Administration Menu. Enqueues a CR (concurrent read) lock on the specified
resource name, then gets the number of current locks (i.e. other processes)
currently with an interest in that lock.  Then converts that lock to EX
(exclusive) and using a sys$deq() writes the command string into the 16 byte
lock value block.  When the exclusive lock is removed the other processes
waiting on CR locks get them, reading the value block and excuting the command
therein.
*/

char* ControlDoAllLock (char *Command)

{
#  define STRING_SIZE 512

   static char  *StringPtr = NULL;

   int  status,
        ServerCount;
   char  *cptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ControlDoAllLock() |%s|\n", Command);

   if (StringPtr == NULL) StringPtr = VmGet(STRING_SIZE);

   if (strsame (Command, CONTROL_AUTH_LOAD, -1) ||
       strsame (Command, CONTROL_AUTH_PURGE, -1) ||
       strsame (Command, CONTROL_CACHE_ON, -1) ||
       strsame (Command, CONTROL_CACHE_OFF, -1) ||
       strsame (Command, CONTROL_CACHE_PURGE, -1) ||
       strsame (Command, CONTROL_DCL_DELETE, -1) ||
       strsame (Command, CONTROL_DCL_PURGE, -1) ||
       strsame (Command, CONTROL_DECNET_PURGE, -1) ||
       strsame (Command, CONTROL_DECNET_DISCONNECT, -1) ||
       strsame (Command, CONTROL_EXIT, -1) ||
       strsame (Command, CONTROL_EXIT_NOW, -1) ||
       strsame (Command, CONTROL_LIST, -1) ||
       strsame (Command, CONTROL_LOG_OPEN, -1) ||
       strsame (Command, CONTROL_LOG_CLOSE, -1) ||
       strsame (Command, CONTROL_LOG_FLUSH, -1) ||
       strsame (Command, CONTROL_MAP, -1) ||
       strsame (Command, CONTROL_PROXY_ON, -1) ||
       strsame (Command, CONTROL_PROXY_OFF, -1) ||
       strsame (Command, CONTROL_PROXY_PURGE_REACTIVE, -1) ||
       strsame (Command, CONTROL_PROXY_PURGE_ROUTINE, -1) ||
       strsame (Command, CONTROL_PROXY_PURGE_HOST, -1) ||
       strsame (Command, CONTROL_RESTART, -1) ||
       strsame (Command, CONTROL_RESTART_NOW, -1) ||
       strsame (Command, CONTROL_ZERO, -1))
   {
      /* remember, a specific resource name can also be set using /ALL= */
      ControlLockNameDsc.dsc$a_pointer = ServerGroupResName;
      ControlLockNameDsc.dsc$w_length = strlen(ServerGroupResName);
      if (Debug)
        fprintf (stdout, "%d |%s|\n",
                 ControlLockNameDsc.dsc$w_length,
                 ControlLockNameDsc.dsc$a_pointer);

      /* turn on SYSLCK to allow SYSTEM locks to be enqueued */
      status = ControlEnableSysLck ();
      if (status == SS$_NOTALLPRIV)
         return ("no SYSLCK, /DO=/ALL not enabled");

      /* enqueue a just-interested NL lock */
      status = sys$enqw (0, LCK$K_NLMODE, &ControlLockDoLksb,
                         LCK$M_SYSTEM, &ControlLockNameDsc, 0,
                         0, 0, 0, 0, 2, 0);
      if (Debug) fprintf (stdout, "NL sys$enqw() %%X%08.08X\n", status);
      if (VMSnok (status)) return ("!sys$enqw() failed!");

      /* get a list of the servers this will be queued against */
      cptr = ControlAllHttpdList (", ", &ServerCount);

      if (strsame (Command, CONTROL_LIST, -1))
      {
         /**********************************/
         /* CLI special case, /DO=LIST/ALL */
         /**********************************/

         WriteFao (StringPtr, STRING_SIZE, 0, "!UL server!%s; !AZ",
                   ServerCount, cptr);

         /* image exit dequeues lock */
         return (StringPtr);
      }

      /* store the command (first 15 chars anyway) in the status block */
      memcpy (ControlLockDoLksb.lksb$b_valblk, Command, 15);
      ControlLockDoLksb.lksb$b_valblk[15] = '\0';

      /* do this before sys$enq() in case the AST's delivered immediately */
      ControlDoAllLockAstOutstanding = true;

      /* note: this is NOT a sys$enqw(), it's asynchronous */
      status = sys$enq (0, LCK$K_EXMODE, &ControlLockDoLksb,
                        LCK$M_CONVERT | LCK$M_SYSTEM, 0, 
                        0, &ControlDoAllLockAst, 1, 0, 0, 2, 0);
      if (Debug) fprintf (stdout, "EX sys$enq() %%X%08.08X\n", status);
      if (VMSnok (status))
      {
         if (HttpdServerExecuting) ErrorNoticed (status, "sys$enqw()", FI_LI);
         return ("!sys$enqw() failed!");
      }

      /* turn off SYSLCK */
      ControlDisableSysLck ();

      WriteFao (StringPtr, STRING_SIZE-1, 0, "!UL server!%s notified; !AZ",
                ServerCount, cptr);
      return (StringPtr);
   }
   else
   if (strsame (Command, CONTROL_LOG_OPEN_AS, strlen(CONTROL_LOG_OPEN_AS)) ||
       strsame (Command, CONTROL_LOG_REOPEN, strlen(CONTROL_LOG_REOPEN)) ||
       strsame (Command, CONTROL_LOG_REOPEN_AS, strlen(CONTROL_LOG_REOPEN_AS)) ||
       strsame (Command, CONTROL_LOG_FORMAT_AS, strlen(CONTROL_LOG_FORMAT_AS)) ||
       strsame (Command, CONTROL_LOG_PERIOD_AS, strlen(CONTROL_LOG_PERIOD_AS)))
      return ("!cannot do this via /ALL");
   else
      return ("!what?");
}

/*****************************************************************************/
/*
To allow ControlDoAllLock() to be used from ADMIN.C and the Administration Menu
ControlAllHttpd() must be allowed to be AST-driven.  This function executes
when the all the "interested-party" locks have dequeued, and just dequeues the
EX mode lock set up by ControlAllLock(), writing the lock value block.  AST
granularity is required to allow AdminControl() to use it as part of an
executing server.
*/

ControlDoAllLockAst ()

{
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ControlDoAllLockAst()\n");

   ControlDoAllLockAstOutstanding = false;

   /* turn on SYSLCK to allow SYSTEM locks to be converted */
   status = ControlEnableSysLck ();
   if (status == SS$_NOTALLPRIV) return;

   status = sys$deq (ControlLockDoLksb.lksb$l_lkid,
                     ControlLockDoLksb.lksb$b_valblk, 0, 0);
   if (Debug) fprintf (stdout, "sys$deq() %%X%08.08X\n", status);
   if (VMSnok (status)) ErrorNoticed (status, "sys$deq()", FI_LI);

   /* turn off SYSLCK */
   ControlDisableSysLck ();
}

/*****************************************************************************/
/*
Just a wrapper for command-line access to ControlDoAllLock().
*/

int ControlAllCommand (char *Command)

{
   char  *cptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ControlAllCommand() |%s|\n", Command);

   ControlDoAllEnabled = true;

   cptr = ControlDoAllLock (Command);
   while (ControlDoAllLockAstOutstanding)
   {
      sleep (1);
      if (ControlDoAllLockAstOutstanding)
         WriteFaoStdout ("%!AZ-I-DOALL, waiting for (en)queueing to complete\n",
                         Utility);
   }
   if (cptr[0] == '!')
   {
      WriteFaoStdout ("%!AZ-E-DOALL, !AZ\n", Utility, cptr+1);
      return (STS$K_ERROR | STS$M_INHIB_MSG);
   }
   WriteFaoStdout ("%!AZ-I-DOALL, !AZ\n", Utility, cptr);
   return (SS$_NORMAL);
}

/*****************************************************************************/

