/*****************************************************************************/
/*
                                 Proxy.c

*************
** CAUTION **
*************

THIS MODULE IS TASK-ORIENTED, NOT REQUEST-ORIENTED.

That is, most of the functions take a pointer to proxy task rather than a
pointer to request as do other modules. The reason is simple. Many of these
functions are designed for use independently of a request.

Implements a basic HTTP proxy service in conjunction with ProxyCache.c module.
This module provides all the request parsing, networking, response parsing and
writing to the client.  The ProxyCache.c module provides the caching in files
of candidate requests.

All errors related to connecting to, requesting from, and processing the
response from the proxied server are reported as 502s (gateway failures).  Any
errors such as buffer overflows, etc., are reported as 500 (internal problems).


VERSION HISTORY
---------------
03-SEP-2000  MGD  bugfix; ProxyResolveHostLookup() can be called multiple
                  during host name resolution - only allocate channel once!!
                  bugfix; ProxyResolveHostLookup() hash collision list
04-JUL-2000  MGD  bugfix; ProxyEnd() for CONNECT (proxy SSL)
11-JUN-2000  MGD  refine numeric host detection,
                  ProxyRebuildRequest() now dynamically allocates a rebuild
                  buffer based on 'NetReadBufferSize'
01-JUN-2000  MGD  bugfix; use 'rqHeader.RequestUriPtr' as '->RequestUriPtr'
                  (non-URL-decoded path plus query string)
29-APR-2000  MGD  proxy authorization
04-MAR-2000  MGD  use NetWriteFaol(), et.al.
04-DEC-1999  MGD  default host name cache purge now 24 hours
11-NOV-1999  MGD  provide "ETag:" propagation
25-OCT-1999  MGD  remove NETLIB support
10-OCT-1999  MGD  just sys$dassn() the socket
26-JUN-1999  MGD  bugfix; ProxyEnd() call in ProxyReadResponseAst(),
                  bugfix; header pointer in ProxyHttp09ResponseHeader(),
                  always initialize cache parameters (even if not enabled),
                  revised request run down ProxyShutdownSocket()
19-AUG-1998  MGD  initial development (recommenced DEC 1998)
*/
/*****************************************************************************/

/* standard C header files */
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>

/* VMS related header files */
#include <descrip.h>
#include <dvidef.h>
#include <iodef.h>
#include <psldef.h>
#include <ssdef.h>
#include <stsdef.h>

/* application-related header files */
#include "wasd.h"

#define WASD_MODULE "PROXY"

#define PROXY_CONTENT_MAX 2048

/******************/
/* global storage */
/******************/

int ProxyHostCacheHashTableEntries = 256;
int ProxyReadBufferSize = 4096;

boolean ProxyAddForwardedByEnabled,
        ProxyServingEnabled;

int  ProxyHostCachePurgeHours,
     ProxyHostCachePurgeMinutes,
     ProxyHostLookupRetryCount,
     ProxyServiceCount;

struct ProxyAccountingStruct  ProxyAccounting;

extern struct dsc$descriptor InetDeviceDsc;

extern int  NetReadBufferSize,
            OptionEnabled;

extern struct {
   unsigned short  Length;
   unsigned short  Parameter;
   char  *Address;
} ReuseAddress,
  ReuseAddressSocketOption,
  ClientSocketOption;

extern struct {
   unsigned short  Protocol;
   unsigned char  Type;
   unsigned char  Family;
} TcpSocket;

/********************/
/* external storage */
/********************/

#ifdef DBUG
extern boolean Debug;
#else
#define Debug 0 
#endif

extern boolean  MonitorEnabled;

extern int  WatchEnabled;

extern char  ErrorSanityCheck[],
             HttpProtocol[],
             ServerHostPort[],
             SoftwareID[],
             Utility[];

extern struct AccountingStruct  Accounting;
extern struct ConfigStruct  Config;
extern struct MsgStruct  Msgs;
extern struct ServiceStruct  *ServiceListHead;

/****************************************************************************/
/*
*/

ProxyInit ()

{
   register char  *cptr;
   register struct ServiceStruct  *svptr;

   boolean  CacheEnabled;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyInit()\n");
 
   ProxyServingEnabled = ProxyAccounting.ServingEnabled = CacheEnabled = false;
   ProxyServiceCount = 0;

   /* copy the configuration parameters, ensuring they're reasonable */
   ProxyHostLookupRetryCount = Config.cfProxy.HostLookupRetryCount;
   if (ProxyHostLookupRetryCount < 0 || ProxyHostLookupRetryCount > 100)
      ProxyHostLookupRetryCount = 0;
   ProxyHostCachePurgeHours = Config.cfProxy.HostCachePurgeHours;
   if (ProxyHostCachePurgeHours < 1 || ProxyHostCachePurgeHours > 168)
      ProxyHostCachePurgeHours  = PROXY_HOST_CACHE_PURGE_DEFAULT;
   ProxyHostCachePurgeMinutes = ProxyHostCachePurgeHours * 60;

   /* just some information about the proxy services */
   for (svptr = ServiceListHead; svptr != NULL; svptr = svptr->NextPtr)
   {
      if (!(svptr->ProxyService || svptr->ConnectService)) continue;

      ProxyServiceCount++;

      if (svptr->ProxyChainHostName[0])
         fprintf (stdout, "%%%s-I-PROXY, %s chains to %s\n",
                  Utility, svptr->ServerHostPort,
                  svptr->ProxyChainHostPort);

      if (svptr->ProxyService)
      {
         fprintf (stdout, "%%%s-I-PROXY, HTTP service %s",
                  Utility, svptr->ServerHostPort);
         if (svptr->ProxyAuthRequired)
            fprintf (stdout, " (auth)");
         if (svptr->ProxyFileCacheEnabled)
         {
            CacheEnabled = true;
            fprintf (stdout, " (cached)");
         }
         if (svptr->ConnectService)
            fprintf (stdout, " (connect)");
         fputs ("\n", stdout);
      }
      else
      if (svptr->ConnectService)
      {
         fprintf (stdout, "%%%s-I-PROXY, connect service %s",
                  Utility, svptr->ServerHostPort);
         if (svptr->ProxyAuthRequired)
            fprintf (stdout, " (auth)");
         fputs ("\n", stdout);
      }
   }

   if (ProxyServiceCount)
   {
      ProxyServingEnabled = ProxyAccounting.ServingEnabled = true;

      /* initialize the host name cache */
      ProxyResolveHostCache (NULL, NULL, 0);

      /* initialize the proxy file cache (at least parameters) */
      ProxyCacheInit (CacheEnabled);

      if (Config.cfProxy.ServingEnabled)
         fprintf (stdout, "%%%s-I-PROXY, processing enabled\n", Utility);
      else
      {
         fprintf (stdout,
"%%%s-W-PROXY, disabled in configuration, services not enabled!\n",
                  Utility);
         ProxyServingEnabled = ProxyAccounting.ServingEnabled = false;
      }
   }
}

/****************************************************************************/
/*
************
*** NOTE ***  This function takes a pointer to a request!!!
************

*/

ProxyRequestBegin (struct RequestStruct *rqptr)

{
   register struct ProxyTaskStruct  *tkptr;

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyRequestBegin()\n");

   if (!ProxyServiceCount)
   {
      rqptr->rqResponse.HttpStatus = 403;
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_PROXY_NONE_CONFIGURED), FI_LI);
      RequestEnd (rqptr);
      return;
   }

   if (!ProxyServingEnabled)
   {
      rqptr->rqResponse.HttpStatus = 503;
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_PROXY_DISABLED), FI_LI);
      RequestEnd (rqptr);
      return;
   }

   if (rqptr->rqHeader.Method == HTTP_METHOD_CONNECT)
   {
      if (!rqptr->ServicePtr->ConnectService)
      {
         rqptr->rqResponse.HttpStatus = 403;
         ErrorGeneral (rqptr, MsgFor(rqptr,MSG_PROXY_NOT_CONNECT), FI_LI);
         RequestEnd (rqptr);
         return;
      }
   }
   else
   {
      if (!rqptr->ServicePtr->ProxyService)
      {
         rqptr->rqResponse.HttpStatus = 403;
         ErrorGeneral (rqptr, MsgFor(rqptr,MSG_PROXY_NOT_SERVICE), FI_LI);
         RequestEnd (rqptr);
         return;
      }
   }

   /* set up the task structure (only ever one per request!) */
   rqptr->ProxyTaskPtr = tkptr = (struct ProxyTaskStruct*)
      VmGetHeap (rqptr, sizeof(struct ProxyTaskStruct));

   /* point from the task structure to the request structure */
   tkptr->RequestPtr = rqptr;

   /* point to the service structure */
   tkptr->ServicePtr = rqptr->ServicePtr;

   /* if this request is being WATCHed, then this proxy task is too! */
   tkptr->WatchItem = rqptr->WatchItem;

   /* copy the request method number  and HTTP version number */
   tkptr->HttpMethod = rqptr->rqHeader.Method;
   tkptr->RequestHttpVersion = rqptr->rqHeader.HttpVersion;

   /* allocate a buffer used for creating the MD5 digest, network I/O, etc. */
   if (tkptr->ResponseBufferPtr == NULL)
   {
      tkptr->ResponseBufferPtr =
         tkptr->ResponseBufferCurrentPtr =
         VmGetHeap (rqptr, ProxyReadBufferSize);
      tkptr->ResponseBufferSize =
         tkptr->ResponseBufferRemaining =
         ProxyReadBufferSize;
   }

   /* a little accounting */
   switch (tkptr->HttpMethod)
   {
      case HTTP_METHOD_CONNECT :
         ProxyAccounting.MethodConnectCount++;
         break;
      case HTTP_METHOD_DELETE :
         ProxyAccounting.MethodDeleteCount++;
         break;
      case HTTP_METHOD_GET :
         ProxyAccounting.MethodGetCount++;
         break;
      case HTTP_METHOD_HEAD :
         ProxyAccounting.MethodHeadCount++;
         break;
      case HTTP_METHOD_POST :
         ProxyAccounting.MethodPostCount++;
         break;
      case HTTP_METHOD_PUT :
         ProxyAccounting.MethodPutCount++;
         break;
      default :
         ErrorExitVmsStatus (SS$_BUGCHECK, ErrorSanityCheck, FI_LI);
   }

   if (tkptr->HttpMethod == HTTP_METHOD_CONNECT)
   {
      /******************/
      /* CONNECT method */
      /******************/

      if (VMSnok (status = ProxyHttpConnectParse (rqptr)))
      {
         RequestEnd (rqptr);
         return;
      }

      ProxyResolveHost (tkptr);

      /* eventually ASTs/calls ProxyHostConnect() to continue processing */
      return;
   }

   /***************************/
   /* GET, POST, etc. methods */
   /***************************/

   /* get the method, host (and port), path and query string */
   if (VMSnok (status = ProxyRequestParse (rqptr)))
   {
      RequestEnd (rqptr);
      return;
   }

   if (tkptr->WatchItem &&
       (WatchEnabled & WATCH_PROXY))
      WatchThis (rqptr, FI_LI, WATCH_PROXY,
                 "!AZ !AZ !AZ", tkptr->RequestHttpMethodNamePtr,
                 tkptr->RequestHostNamePort, tkptr->RequestUriPtr);

   /* if caching is enabled for this service then see if it can be used */
   if (rqptr->ServicePtr->ProxyFileCacheEnabled)
      if (VMSok (ProxyCacheReadBegin (tkptr)))
         return;

   /* nope, cache couldn't be used, begin a network transaction */
   ProxyResolveHost (tkptr);

   /* eventually ASTs/calls ProxyHostConnect() to continue processing */
}

/*****************************************************************************/
/*
Only called when a cache check has failed to be able to supply the request.
Merely call ProxyResolveHost() to begin an attempt to supply the request from
the remote server.
*/

ProxyReadCacheFailed (struct ProxyTaskStruct *tkptr)

{
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyReadCacheFailed()\n");

   ProxyResolveHost (tkptr);

   /* eventually ASTs/calls ProxyHostConnect() to continue processing */
} 

/****************************************************************************/
/*
************
*** NOTE ***  This function takes a pointer to a request!!!
************

Parse the various components from the proxy request.
*/

ProxyRequestParse (struct RequestStruct *rqptr)

{
   register char  *cptr, *sptr, *zptr;
   register struct ProxyTaskStruct  *tkptr;

   int  Length;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "ProxyRequestParse() |%s|\n", rqptr->MappedPathPtr);

   /* get a local pointer to the proxy task structure */
   tkptr = rqptr->ProxyTaskPtr;

   cptr = rqptr->rqHeader.RequestUriPtr;
   zptr = (sptr = tkptr->RequestSchemeName) +
          sizeof(tkptr->RequestSchemeName)-1;
   while (*cptr && *cptr != ':' && sptr < zptr) *sptr++ = *cptr++;
   if (*cptr && sptr < zptr) *sptr++ = *cptr++;
   if (sptr >= zptr)
   {
      Accounting.RequestErrorCount++;
      rqptr->rqResponse.HttpStatus = 502;
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_REQUEST_FORMAT), FI_LI);
      return (STS$K_ERROR);
   }
   *sptr = '\0';
   if (Debug)
      fprintf (stdout, "RequestSchemeName |%s|\n", tkptr->RequestSchemeName);

   /* only "http:" is currently supported */
   if (!strsame (tkptr->RequestSchemeName, "http:", -1))
   {
      rqptr->rqResponse.HttpStatus = 502;
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_PROXY_REQUEST_SCHEME), FI_LI);
      return (STS$K_ERROR);
   }

   /*************************/
   /* get server host name  */
   /*************************/

   if (*((unsigned short*)cptr) == '//')
   {
      cptr += 2;
      zptr = (sptr = tkptr->RequestHostName) + sizeof(tkptr->RequestHostName)-1;
      while (*cptr && *cptr != ':' && *cptr != '/' && sptr < zptr)
         *sptr++ = *cptr++;
   }
   else
      sptr = zptr = NULL;
   if (sptr >= zptr || (*cptr && *cptr != ':' && *cptr != '/'))
   {
      Accounting.RequestErrorCount++;
      rqptr->rqResponse.HttpStatus = 502;
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_REQUEST_FORMAT), FI_LI);
      return (STS$K_ERROR);
   }
   *sptr = '\0';
   if (Debug)
      fprintf (stdout, "RequestHostName |%s|\n", tkptr->RequestHostName);

   /******************************/
   /* get (optional) server port */
   /******************************/

   if (*cptr == ':')
   {
      cptr++;
      if (isdigit(*cptr))
      {
         zptr = (sptr = tkptr->RequestPortString) +
                sizeof(tkptr->RequestPortString)-1;
         while (*cptr && isdigit(*cptr) && sptr < zptr) *sptr++ = *cptr++;
         if (sptr >= zptr)
         {
            Accounting.RequestErrorCount++;
            rqptr->rqResponse.HttpStatus = 502;
            ErrorGeneral (rqptr, MsgFor(rqptr,MSG_REQUEST_FORMAT), FI_LI);
            return (STS$K_ERROR);
         }
         *sptr = '\0';
         tkptr->RequestPort = atol (tkptr->RequestPortString);
      }
      else
      {
         tkptr->RequestPort = 80;
         memcpy (tkptr->RequestPortString, "80", 3);
      }
   }
   else
   {
      tkptr->RequestPort = 80;
      memcpy (tkptr->RequestPortString, "80", 3);
   }
   if (Debug)
      fprintf (stdout, "RequestPort: %d |%s|\n",
               tkptr->RequestPort, tkptr->RequestPortString);

   /***************************************/
   /* get request URI and if query string */
   /***************************************/

   if (*cptr == '/')
      tkptr->RequestUriPtr = cptr;
   else
      tkptr->RequestUriPtr = "/";

   if (rqptr->rqHeader.QueryStringPtr[0])
      tkptr->RequestQueryStringPresent = true;
   else
      tkptr->RequestQueryStringPresent = false;

   /*******************************/
   /* point to any request cookie */
   /*******************************/

   tkptr->RequestHttpCookiePtr = rqptr->rqHeader.CookiePtr;

   /***********************/
   /* composite name:port */
   /***********************/

   /* store host name/port as FIRST ITEM in cache data block */
   zptr = (sptr = tkptr->RequestHostNamePort) +
          sizeof(tkptr->RequestHostNamePort);
   for (cptr = tkptr->RequestHostName;
        *cptr && sptr < zptr;
        *sptr++ = *cptr++);
   if (sptr < zptr) *sptr++ = ':';
   for (cptr = tkptr->RequestPortString;
        *cptr && sptr < zptr;
        *sptr++ = *cptr++);
   if (sptr >= zptr)
   {
      rqptr->rqResponse.HttpStatus = 500;
      ErrorGeneralOverflow (rqptr, FI_LI);
      return (STS$K_ERROR);
   }
   *sptr = '\0';
   tkptr->RequestHostNamePortLength = sptr - tkptr->RequestHostNamePort;
   if (Debug)
      fprintf (stdout, "RequestHostNamePort |%s|\n",
               tkptr->RequestHostNamePort);

   tkptr->RequestHttpMethod = rqptr->rqHeader.Method;
   tkptr->RequestHttpMethodNamePtr = rqptr->rqHeader.MethodName;
   tkptr->RequestPragmaNoCache = rqptr->PragmaNoCache;

   return (SS$_NORMAL);
} 

/*****************************************************************************/
/*
************
*** NOTE ***  This function takes a pointer to a request!!!
************

HTTP CONNECT method (allows SSL connections thorugh firewall system).  Parse
the host name and optional port from the request.
*/

ProxyHttpConnectParse (struct RequestStruct *rqptr)

{
   register struct ProxyTaskStruct  *tkptr;
   register char  *cptr, *sptr, *zptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "ProxyHttpConnectParse() |%s|\n", rqptr->MappedPathPtr);

   tkptr = rqptr->ProxyTaskPtr;

   cptr = rqptr->MappedPathPtr;

   /*************************/
   /* get server host name  */
   /*************************/

   zptr = (sptr = tkptr->RequestHostName) + sizeof(tkptr->RequestHostName)-1;
   while (*cptr && *cptr != ':' && *cptr != '/' && sptr < zptr)
      *sptr++ = *cptr++;

   if (sptr >= zptr || (*cptr && *cptr != ':'))
   {
      Accounting.RequestErrorCount++;
      rqptr->rqResponse.HttpStatus = 502;
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_REQUEST_FORMAT), FI_LI);
      return (STS$K_ERROR);
   }
   *sptr = '\0';
   if (Debug)
      fprintf (stdout, "RequestHostName |%s|\n", tkptr->RequestHostName);

   /******************************/
   /* get (optional) server port */
   /******************************/

   if (*cptr == ':')
   {
      cptr++;
      if (isdigit(*cptr))
      {
         zptr = (sptr = tkptr->RequestPortString) +
                sizeof(tkptr->RequestPortString)-1;
         while (*cptr && isdigit(*cptr) && sptr < zptr) *sptr++ = *cptr++;
         if (sptr >= zptr)
         {
            Accounting.RequestErrorCount++;
            rqptr->rqResponse.HttpStatus = 502;
            ErrorGeneral (rqptr, MsgFor(rqptr,MSG_REQUEST_FORMAT), FI_LI);
            return (STS$K_ERROR);
         }
         *sptr = '\0';
         tkptr->RequestPort = atol (tkptr->RequestPortString);
      }
      else
      {
         tkptr->RequestPort = 443;
         memcpy (tkptr->RequestPortString, "443", 4);
      }
   }
   else
   {
      tkptr->RequestPort = 443;
      memcpy (tkptr->RequestPortString, "443", 4);
   }
   if (Debug)
      fprintf (stdout, "RequestPort: %d |%s|\n",
               tkptr->RequestPort, tkptr->RequestPortString);

   /****************************/
   /* build host name and port */
   /****************************/

   zptr = (sptr = tkptr->RequestHostNamePort) +
          sizeof(tkptr->RequestHostNamePort);
   for (cptr = tkptr->RequestHostName;
        *cptr && sptr < zptr;
        *sptr++ = *cptr++);
   if (sptr < zptr) *sptr++ = ':';
   for (cptr = tkptr->RequestPortString;
        *cptr && sptr < zptr;
        *sptr++ = *cptr++);
   if (sptr >= zptr)
   {
      rqptr->rqResponse.HttpStatus = 500;
      ErrorGeneralOverflow (rqptr, FI_LI);
      return (STS$K_ERROR);
   }
   *sptr = '\0';
   tkptr->RequestHostNamePortLength = sptr - tkptr->RequestHostNamePort;
   if (Debug)
      fprintf (stdout, "RequestHostNamePort |%s|\n",
               tkptr->RequestHostNamePort);

   return (SS$_NORMAL);
} 

/*****************************************************************************/
/*
If a proxied request is being supplied from cache then end that (basically
close the associated cache file).  If supplied via a network transaction and
the socket was created then shut and close the socket.  If concurrently writing
a request body to the proxied server then just return after closing the socket. 
The body write will receive an error and call this function to close the
request down.  Finally deallocate proxy memory and if an associated request
structure end that request.
*/

ProxyEnd (struct ProxyTaskStruct *tkptr)

{
   static long  Addx2 = 2;

   int  status;
   unsigned long  QuadScratch [2];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyEnd()\n");

   if (tkptr->ReadFab.fab$w_ifi ||
       tkptr->LoadFab.fab$w_ifi)
   {
      /* cache read or load files are open, finalize cache file processing */
      ProxyCacheEnd (tkptr);
      return;
   }

   ProxyCloseSocket (tkptr);

   /* any outstanding I/O with the proxied server then forget it */
   if (tkptr->ProxyReadRawAstFunctionPtr != NULL ||
       tkptr->ProxyWriteRawAstFunctionPtr != NULL)
      return;

   /* any outstanding I/O with the client then forget it */
   if (tkptr->HttpMethod == HTTP_METHOD_CONNECT &&
       (tkptr->RequestPtr->rqNet.ReadRawAstFunctionPtr != NULL ||
        tkptr->RequestPtr->rqNet.WriteRawAstFunctionPtr != NULL))
   {
      NetCloseSocket (tkptr->RequestPtr);
      return;
   }

   /*********************************/
   /* finally end the proxy request */
   /*********************************/

   /* a little (double-precision) accounting */
   if (tkptr->BytesRawTx)
   {
      QuadScratch[0] = tkptr->BytesRawTx;
      QuadScratch[1] = 0;
      lib$addx (&QuadScratch, &ProxyAccounting.QuadBytesRawTx,
                &ProxyAccounting.QuadBytesRawTx, &Addx2);
      if (tkptr->NotCacheable)
      {
         QuadScratch[0] = tkptr->BytesRawTx;
         QuadScratch[1] = 0;
         lib$addx (&QuadScratch, &ProxyAccounting.QuadBytesNotCacheableTx,
                   &ProxyAccounting.QuadBytesNotCacheableTx, &Addx2);
      }
   }
   if (tkptr->BytesRawRx)
   {
      QuadScratch[0] = tkptr->BytesRawRx;
      QuadScratch[1] = 0;
      lib$addx (&QuadScratch, &ProxyAccounting.QuadBytesRawRx,
                &ProxyAccounting.QuadBytesRawRx, &Addx2);
      if (tkptr->NotCacheable)
      {
         QuadScratch[0] = tkptr->BytesRawRx;
         QuadScratch[1] = 0;
         lib$addx (&QuadScratch, &ProxyAccounting.QuadBytesNotCacheableRx,
                   &ProxyAccounting.QuadBytesNotCacheableRx, &Addx2);
      }
   }
   if (tkptr->ProxyCacheReadBytes)
   {
      QuadScratch[0] = tkptr->ProxyCacheReadBytes;
      QuadScratch[1] = 0;
      lib$addx (&QuadScratch, &ProxyAccounting.QuadBytesCacheTx,
                &ProxyAccounting.QuadBytesCacheTx, &Addx2);
      if (tkptr->RequestPtr != NULL)
      {
         QuadScratch[0] = tkptr->RequestPtr->rqHeader.RequestHeaderLength;
         QuadScratch[1] = 0;
         lib$addx (&QuadScratch, &ProxyAccounting.QuadBytesCacheRx,
                   &ProxyAccounting.QuadBytesCacheRx, &Addx2);
      }
   }

   if (tkptr->RequestPtr == NULL)
   {
      /* no request heap, free autonomous task memory */
      if (tkptr->ResponseBufferPtr != NULL)
         VmFree (tkptr->ResponseBufferPtr, FI_LI);
   }
   else
   {
      /* request heap memory will be freed by request rundown */
      if (tkptr->HttpMethod == HTTP_METHOD_CONNECT)
      {
         if (tkptr->WatchItem &&
             (WatchEnabled & WATCH_PROXY))
            WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY,
                       "HTTP CONNECT concluded");
      }

      /* indicate this no longer has an associated proxy task */
      tkptr->RequestPtr->ProxyTaskPtr = NULL;

      RequestEnd (tkptr->RequestPtr);
   }
} 

/****************************************************************************/
/*
Resolve the host name/address into the 32 bit, binary IP address.  For names
use the local cache of IP addresses or resolve using the TCP/IP agent's name
service.
*/

ProxyResolveHost (struct ProxyTaskStruct *tkptr)

{
   int  status,
        IpAddress;
   char  *cptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "ProxyResolveHost() |%s|\n", tkptr->RequestHostName);

   if (tkptr->ServicePtr->ProxyChainIpAddress)
   {
      /*********************************************************/
      /* this proxy server requests from another proxy server! */
      /*********************************************************/

      if (tkptr->WatchItem &&
          (WatchEnabled & WATCH_PROXY))
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY,
                    "HOST-PROXY-CHAIN !AZ",
                    tkptr->ServicePtr->ProxyChainHostName);

      tkptr->ConnectIpAddress = tkptr->ServicePtr->ProxyChainIpAddress;
      tkptr->ConnectPort = tkptr->ServicePtr->ProxyChainPort;
      tkptr->ConnectHostNamePortPtr =
         tkptr->ServicePtr->ProxyChainHostPort;
      tkptr->ProxyLookupIOsb.Status = SS$_NORMAL;

      ProxyHostConnect (tkptr);
      return;
   }

   tkptr->ConnectPort = tkptr->RequestPort;
   tkptr->ConnectHostNamePortPtr = tkptr->RequestHostNamePort;

   if (isdigit(tkptr->RequestHostName[0]))
   {
      for (cptr = tkptr->RequestHostName;
           *cptr && (isdigit(*cptr) || *cptr == '.');
           cptr++);
      if (!*cptr)
      {
         /*************************************/
         /* address in the form "131.185.2.4" */
         /*************************************/

         if (tkptr->WatchItem &&
             (WatchEnabled & WATCH_PROXY))
            WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY,
                       "HOST-NUMERIC !AZ", tkptr->RequestHostName);

         ProxyAccounting.LookupNoneCount++;

         if ((IpAddress = inet_addr (tkptr->RequestHostName)) != -1)
            tkptr->ProxyLookupIOsb.Status = SS$_NORMAL;
         else
            tkptr->ProxyLookupIOsb.Status = PROXY_ERROR_HOST_UNKNOWN;

         if (VMSok (tkptr->ProxyLookupIOsb.Status))
            tkptr->RequestHostIpAddress = tkptr->ConnectIpAddress = IpAddress;

         ProxyHostConnect (tkptr);
         return;
      }
   }

   /*************************************************/
   /* address in the form "www.dsto.defence.gov.au" */
   /*************************************************/

   if ((IpAddress =
        ProxyResolveHostCache (NULL, tkptr->RequestHostName, 0)) != -1)
   {
      if (tkptr->WatchItem &&
          (WatchEnabled & WATCH_PROXY))
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY,
                    "HOST-CACHE !AZ", tkptr->RequestHostName);

      ProxyAccounting.LookupCacheCount++;

      tkptr->RequestHostIpAddress = tkptr->ConnectIpAddress = IpAddress;
      tkptr->ProxyLookupIOsb.Status = SS$_NORMAL;

      ProxyHostConnect (tkptr);
      return;
   }

   /************************************/
   /* resolve host using TCP/IP lookup */
   /************************************/

   ProxyAccounting.LookupDnsCount++;

   ProxyResolveHostLookup (tkptr);
}


/*****************************************************************************/
/*
Asynchronous host address lookup from host name.  This can be called multiple
times during host resolution.
*/

ProxyResolveHostLookup (struct ProxyTaskStruct *tkptr)

{
   static unsigned char ControlSubFunction [4] =
      { INETACP_FUNC$C_GETHOSTBYNAME, INETACP$C_TRANS, 0, 0 };
   static struct dsc$descriptor AddressDsc =
      { 0, DSC$K_DTYPE_T, DSC$K_CLASS_S, 0};
   static struct dsc$descriptor ControlSubFunctionDsc =
      { 4, DSC$K_DTYPE_T, DSC$K_CLASS_S, &ControlSubFunction };
   static struct dsc$descriptor ClientHostNameDsc =
      { 0, DSC$K_DTYPE_T, DSC$K_CLASS_S, 0};

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "ProxyResolveHostLookup() |%s|\n",
               tkptr->RequestHostName);

   if (!tkptr->ProxyLookupRetryCount)
      tkptr->ProxyLookupRetryCount = ProxyHostLookupRetryCount;

   if (tkptr->WatchItem &&
       (WatchEnabled & WATCH_PROXY))
      WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY,
                 "HOST-LOOKUP !UL !AZ",
                 ProxyHostLookupRetryCount - tkptr->ProxyLookupRetryCount + 1,
                 tkptr->RequestHostName);

   if (!tkptr->ProxyChannel)
   {
      /* assign a channel to the internet template device */
      if (VMSnok (status =
          sys$assign (&InetDeviceDsc, &tkptr->ProxyChannel, 0, 0)))
      {
         /* leave it to the AST function to report! */
         tkptr->ProxyLookupIOsb.Status = status;
         ProxyHostConnect (tkptr);
         return;
      }

      tkptr->ResolveHostAddressDsc.dsc$b_class = DSC$K_CLASS_S;
      tkptr->ResolveHostAddressDsc.dsc$b_dtype = DSC$K_DTYPE_T;
      tkptr->ResolveHostAddressDsc.dsc$w_length =
          sizeof(tkptr->ResolveHostAddrBuff);
      tkptr->ResolveHostAddressDsc.dsc$a_pointer =
          &tkptr->ResolveHostAddrBuff;

      tkptr->ResolveHostNameDsc.dsc$b_class = DSC$K_CLASS_S;
      tkptr->ResolveHostNameDsc.dsc$b_dtype = DSC$K_DTYPE_T;
      tkptr->ResolveHostNameDsc.dsc$w_length = strlen(tkptr->RequestHostName);
      tkptr->ResolveHostNameDsc.dsc$a_pointer = &tkptr->RequestHostName;
   }

   if (Debug) fprintf (stdout, "sys$qio() IO$_ACPCONTROL\n");
   status = sys$qio (0, tkptr->ProxyChannel, IO$_ACPCONTROL,
                     &tkptr->ProxyLookupIOsb, &ProxyHostConnect, tkptr,
                     &ControlSubFunctionDsc,
                     &tkptr->ResolveHostNameDsc, &tkptr->ResolveHostLength,
                     &tkptr->ResolveHostAddressDsc, 0, 0);
   if (Debug)
      fprintf (stdout, "sys$qio() %%X%08.08X IOsb %%X%08.08X\n",
               status, tkptr->ProxyLookupIOsb.Status);

   if (VMSnok (status))
   {
      /* leave it to the AST function to report! */
      tkptr->ProxyLookupIOsb.Status = status;
      ProxyHostConnect (tkptr);
      return;
   }
}

/*****************************************************************************/
/*
Host name to IP address cache.  Hash table with collision list.  To
(re)initialize call with 'HostName' parameter NULL.  To find a host IP address
in the table call with 'HostName' the host name to be searched for and
'IpAddress' set to zero.  To add/update an entry call with 'HostName' set to
the host name and 'IpAddress' set to the 32 bit IP address.
*/ 

int ProxyResolveHostCache
(
struct RequestStruct *rqptr,
char *HostName,
int IpAddress
)
{
   struct HostHashTableStruct
   {
      int  IpAddress,
           HitCount,
           HostNameLength;
      char  *HostNamePtr;
      struct HostHashTableStruct  *HashCollisionNextPtr;
   };
   static int  HashTableEntries;
   static unsigned long  HashTableMask;
   static struct HostHashTableStruct  **HostHashTable;
   static boolean  CacheInitialized = false;

   register unsigned long  HashValue;
   register char  *cptr, *sptr;
   register struct HostHashTableStruct  *chtptr, *htptr;

   int  status,
        Length;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "ProxyResolveHostCache() %d |%s| %08.08X\n",
               rqptr, HostName, IpAddress);

   if (rqptr == NULL &&
       HostName == NULL &&
       CacheInitialized)
   {
      /*****************************/
      /* purge the host cache list */
      /*****************************/

      int  idx;

      for (idx = 0; idx < HashTableEntries; idx++)
      {
         if ((htptr = HostHashTable[idx]) == NULL) continue;
         for (chtptr = htptr->HashCollisionNextPtr;
              chtptr != NULL;
              chtptr = chtptr->HashCollisionNextPtr)
         {
            if (Debug)
               fprintf (stdout, "%d |%s| %d\n",
                        chtptr->HostNameLength, chtptr->HostNamePtr,
                        chtptr->HashCollisionNextPtr);
            VmFree (chtptr->HostNamePtr, FI_LI);
            VmFree (chtptr, FI_LI);
         }
         VmFree (htptr->HostNamePtr, FI_LI);
         VmFree (htptr, FI_LI);
      }
      VmFree (HostHashTable, FI_LI);
      HashTableEntries = 0;
      CacheInitialized = false;
   }

   if (!CacheInitialized)
   {
      /******************************/
      /* create the host cache list */
      /******************************/

      int  cnt;

      CacheInitialized = true;
      /* ensure it's something reasonable */
      if ((HashTableEntries = ProxyHostCacheHashTableEntries) < 128)
         HashTableEntries = 128;
      /* hash table needs to be a power of 2 (i.e. 64, 128, 256, 512 ...) */
      for (cnt = 0; HashTableEntries; cnt++)
         HashTableEntries = HashTableEntries >> 1;
      HashTableEntries = 1;
      while (--cnt) HashTableEntries = HashTableEntries << 1;
      /* e.g. cache table size of 512 becomes a mask of 0x1ff */
      HashTableMask = HashTableEntries - 1;
      /* now allocate memory for the actual table */
      HostHashTable =
         VmGet (sizeof(struct HostHashTableStruct*) * HashTableEntries);

      ProxyResolveHostCacheTimer (0);

      if (HostName == NULL) return (0);
   }

   if (rqptr != NULL)
   {
      /************************/
      /* dump host name cache */
      /************************/

      static char  HostNameDumpFao [] =
"<TR><TH ALIGN=right>!UL.</TH>\
<TD ALIGN=left>!AZ</TD>\
<TD ALIGN=left>!UL.!UL.!UL.!UL</TD>\
<TD ALIGN=right>!UL</TD></TR><!!-- !UL !UL -->\n";

      static char  NotNoneFao [] =
"<TR><TD ALIGN=center COLSPAN=4><I>(none)</I></TD></TR>\n";

      int  idx,
           HostNameCount;
      unsigned long  *vecptr;
      unsigned long  FaoVector [16];

      HostNameCount = 0;
      for (idx = 0; idx < HashTableEntries; idx++)
      {
         if ((htptr = HostHashTable[idx]) == NULL) continue;
         while (htptr != NULL)
         {
            HostNameCount++;

            vecptr = FaoVector;
            *vecptr++ = HostNameCount;
            *vecptr++ = htptr->HostNamePtr;
            *vecptr++ = htptr->IpAddress & 0x000000ff;
            *vecptr++ = (htptr->IpAddress & 0x0000ff00) >> 8;
            *vecptr++ = (htptr->IpAddress & 0x00ff0000) >> 16;
            *vecptr++ = ((htptr->IpAddress & 0xff000000) >> 24) & 0xff;
            *vecptr++ = htptr->HitCount;
            /* little bit of inside information! */
            *vecptr++ = idx;
            *vecptr++ = htptr->HashCollisionNextPtr;

            status = NetWriteFaol (rqptr, HostNameDumpFao, &FaoVector);
            if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

            htptr = htptr->HashCollisionNextPtr;
         }
      }

      if (!HostNameCount)
      {
         status = NetWriteFaol (rqptr, NotNoneFao, NULL);
         if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
      }                                       

      return (0);
   }

   if (!HostName[0]) return (-1);

   /**********/
   /* search */
   /**********/

   /* generate lower-case hash */
   HashValue = 1;
   for (cptr = HostName; *cptr; cptr++)
      HashValue = ((tolower(*cptr)*541)^(HashValue*3)) & HashTableMask;
   Length = cptr - HostName;
   if (Debug) fprintf (stdout, "%d %d\n", HashValue, Length);

   /************************/
   /* check the hash table */
   /************************/

   if ((htptr = HostHashTable[HashValue]) == NULL)
   {
      /* did not find it, return if not adding a cache entry */
      if (!IpAddress)
      {
         if (Debug) fprintf (stdout, "IpAddress: %08.08x\n", -1);
         return (-1);
      }

      /* adding a new cache entry */
      htptr = HostHashTable[HashValue] =
         VmGet (sizeof(struct HostHashTableStruct));
      htptr->HostNamePtr = VmGet (Length+1);
      memcpy (htptr->HostNamePtr, HostName, Length+1);
      htptr->HostNameLength = Length;
      htptr->IpAddress = IpAddress;
      htptr->HitCount = 0;
      return (IpAddress);
   }

   /* hit! now, ensure the hash hit is for the same path */
   if (htptr->HostNameLength == Length)
   {
      /* case insensitive string compare of host names */
      cptr = HostName;
      sptr = htptr->HostNamePtr;
      while (*cptr && *sptr && tolower(*cptr) == tolower(*sptr))
      {
         cptr++;
         sptr++;
      }
      if (!*cptr && !*sptr)
      {
         /* yup, the same ... hash table hit straight-up! */
         if (Debug) fprintf (stdout, "IpAddress: %08.08x\n", htptr->IpAddress);

         if (!IpAddress)
         {
            /* return IP address if not revising a cache entry */
            htptr->HitCount++;
            return (htptr->IpAddress);
         }

         /* updating a cache entry */
         htptr->IpAddress = IpAddress;
         htptr->HitCount = 0;
         return (IpAddress);
      }
   }

   /*************/
   /* collision */
   /*************/

   /* process any collision list, using a collision-specific pointer!!! */
   for (chtptr = htptr->HashCollisionNextPtr;
        chtptr != NULL;
        chtptr = chtptr->HashCollisionNextPtr)
   {
      if (Debug)
         fprintf (stdout, "%d |%s| %d\n",
                  chtptr->HostNameLength, chtptr->HostNamePtr,
                  chtptr->HashCollisionNextPtr);

      if (Length != chtptr->HostNameLength) continue;

      /* case insensitive string compare of host names */
      cptr = HostName;
      sptr = chtptr->HostNamePtr;
      while (*cptr && *sptr && tolower(*cptr) == tolower(*sptr))
      {
         cptr++;
         sptr++;
      }
      if (!*cptr && !*sptr)
      {
         /* yup, the same ... found on collision list! */
         if (Debug) fprintf (stdout, "IpAddress: %08.08x\n", chtptr->IpAddress);

         if (!IpAddress)
         {
            /* return IP address if not revising a cache entry */
            chtptr->HitCount++;
            return (chtptr->IpAddress);
         }

         /* updating a collision list cache entry */
         chtptr->IpAddress = IpAddress;
         chtptr->HitCount = 0;
         return (IpAddress);
      }
   }

   /* did not find it, return if not adding a cache entry */
   if (!IpAddress)
   {
      if (Debug) fprintf (stdout, "IpAddress: %08.08x\n", -1);
      return (-1);
   }

   /* adding a cache entry to the *head* of the collision list */
   chtptr = VmGet (sizeof(struct HostHashTableStruct));
   chtptr->HashCollisionNextPtr = htptr->HashCollisionNextPtr;
   htptr->HashCollisionNextPtr = chtptr;
   chtptr->HostNamePtr = VmGet (Length+1);
   memcpy (chtptr->HostNamePtr, HostName, Length+1);
   chtptr->HostNameLength = Length;
   chtptr->IpAddress = IpAddress;
   chtptr->HitCount = 0;
   return (IpAddress);
}

/*****************************************************************************/
/*
Timer AST to purge the host name cache.
*/ 

ProxyResolveHostCacheTimer (int RequestId)

{
   int  status;
   unsigned long  PurgeDelta [2] = { -600000000, -1 };

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "ProxyResolveHostCacheTimer()\n");

   /* in case there's an outstanding timer */
   status = sys$cantim (&ProxyResolveHostCacheTimer, 0);
   if (Debug) fprintf (stdout, "sys$cantim() %%X%08.08X\n", status);

   /* if a timer expiry then purge the host name cache */
   if (RequestId) ProxyResolveHostCache (NULL, NULL, 0);

   /* this is one minute delta */
   PurgeDelta[0] = -600000000;
   PurgeDelta[1] = -1;

   /* multiply by the number of minutes between host cache purges */
   if (VMSnok (status =
       lib$mult_delta_time (&ProxyHostCachePurgeMinutes, &PurgeDelta)))
      ErrorExitVmsStatus (status, "lib$mult_delta_time()", FI_LI);

   /* queue up a timer event scheduling the next cache purge */
   if (VMSnok (status =
       sys$setimr (0, &PurgeDelta, &ProxyResolveHostCacheTimer,
                   &ProxyResolveHostCacheTimer, 0)))
      ErrorExitVmsStatus (status, "sys$setimr()", FI_LI);
}

/****************************************************************************/
/*
Called as an AST from ProxyResolveHost().  Check that the host name has been
resolved.  If not report the error. Create a socket and attempt to connect to
the remote, proxied server host.  AST to ProxyHostConnectAst().
*/

ProxyHostConnect (struct ProxyTaskStruct *tkptr)

{
   /* this is five seconds delta */
   static unsigned long  RetryDelta [2] = { -50000000, -1 };
   static boolean  UseClientSocketOption = true;

   register struct RequestStruct  *rqptr;

   int  status;
   struct AnIOsb  IOsb;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "ProxyHostConnect() |%s| %%X%08.08X\n",
               tkptr->RequestHostNamePort, tkptr->ProxyLookupIOsb.Status);

   /* get associated request (if any) */
   rqptr = tkptr->RequestPtr;

   if (VMSnok (tkptr->ProxyLookupIOsb.Status))
   {
      /******************************/
      /* host name resolution error */
      /******************************/

      if (tkptr->ProxyLookupIOsb.Status == PROXY_ERROR_HOST_UNKNOWN)
      {
         /* if DNS resolution is particularly slow we need to retry! */
         if (Debug)
            fprintf (stdout, "retry count: %d\n",
                     tkptr->ProxyLookupRetryCount);
         if (tkptr->ProxyLookupRetryCount) tkptr->ProxyLookupRetryCount--;
         if (tkptr->ProxyLookupRetryCount)
         {
            /* queue up a timer event scheduling the next retry */
            if (VMSok (status =
                sys$setimr (0, &RetryDelta, &ProxyResolveHostLookup, tkptr, 0)))
               return;

            rqptr->rqResponse.HttpStatus = 500;
            rqptr->rqResponse.ErrorTextPtr = tkptr->RequestHostNamePort;
            ErrorVmsStatus (rqptr, status, FI_LI);
            ProxyEnd (tkptr);
            return;
         }
      }

      if (tkptr->WatchItem &&
          (WatchEnabled & WATCH_PROXY))
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY,
                    "HOST-LOOKUP !AZ %X!8XL %!%M",
                    tkptr->RequestHostName,
                    tkptr->ProxyLookupIOsb.Status,
                    tkptr->ProxyLookupIOsb.Status);

      /* dispose of the non-connected channel/socket used for the lookup */
      ProxyCloseSocket (tkptr);

      ProxyAccounting.LookupErrorCount++;

      tkptr->ResponseStatusCode = 502;
      if (rqptr != NULL)
      {
         /* request associated with task */
         rqptr->rqResponse.HttpStatus = 502;
         rqptr->rqResponse.ErrorTextPtr = tkptr->RequestHostNamePort;
         switch (tkptr->ProxyLookupIOsb.Status)
         {
            case PROXY_ERROR_HOST_UNKNOWN :
               ErrorGeneral (rqptr,
                  MsgFor(rqptr,MSG_PROXY_HOST_UNKNOWN), FI_LI);
            default :
               ErrorVmsStatus (rqptr, tkptr->ProxyLookupIOsb.Status, FI_LI);
         }
      }
      ProxyEnd (tkptr);
      return;
   }

   /************************/
   /* asynchronous lookup? */
   /************************/

   if (tkptr->ProxyChannel)
   {
      /* channel will only be present after ACP host address lookup */
      tkptr->RequestHostIpAddress =
         tkptr->ConnectIpAddress =
         tkptr->ResolveHostAddrBuff[0];

      /* cache this resolved address */
      ProxyResolveHostCache (NULL, tkptr->RequestHostName,
                                   tkptr->ConnectIpAddress);
   }

   /*******************/
   /* connect to host */
   /*******************/

   ProxyAccounting.NetworkCount++;

   if (Debug) fprintf (stdout, "IpAddress %08.08X\n", tkptr->ConnectIpAddress);

   if (tkptr->WatchItem &&
       (WatchEnabled & WATCH_PROXY))
   {
      char  *ConnectToPtr;

      if (tkptr->ServicePtr->ProxyChainIpAddress)
         ConnectToPtr = tkptr->ServicePtr->ProxyChainHostPort;
      else
         ConnectToPtr = tkptr->ConnectHostNamePortPtr;

      WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY,
                 "CONTACT !UL.!UL.!UL.!UL:!UL",
                 /* q&d address to dotted-decimal */
                 tkptr->ConnectIpAddress & 0x000000ff,
                 (tkptr->ConnectIpAddress & 0x0000ff00) >> 8,
                 (tkptr->ConnectIpAddress & 0x00ff0000) >> 16,
                 (tkptr->ConnectIpAddress & 0xff000000) >> 24,
                 tkptr->RequestPort);
   }

   /* if a channel was not assigned during ACP host address lookup */
   if (!tkptr->ProxyChannel)
   {
      /* assign a channel to the internet template device */
      if (VMSnok (status =
          sys$assign (&InetDeviceDsc, &tkptr->ProxyChannel, 0, 0)))
      {
         /* leave it to the AST function to report! */
         tkptr->ProxyConnectIOsb.Status = status;
         SysDclAst (ProxyHostConnectAst, tkptr);
         return;
      }
   }

   /* make the channel a TCP, connection-oriented socket */
   if (UseClientSocketOption)
   {
      if (Debug) fprintf (stdout, "sys$qiow() IO$_SETMODE\n");
      status = sys$qiow (0, tkptr->ProxyChannel, IO$_SETMODE,
                         &tkptr->ProxyConnectIOsb, 0, 0,
                         &TcpSocket, 0, 0, 0, &ClientSocketOption, 0);
      if (Debug)
         fprintf (stdout, "sys$qiow() %%X%08.08X IOsb.Status %%X%08.08X\n",
               status, tkptr->ProxyConnectIOsb.Status);

      /* Multinet 3.2 UCX driver barfs on FULL_DUPLEX_CLOSE, try without */
      if (VMSok (status) && VMSnok (tkptr->ProxyConnectIOsb.Status))
      {
         /* deassign existing channel, assign a new channel, before retrying */
         sys$dassgn (tkptr->ProxyChannel);
         if (VMSnok (status =
             sys$assign (&InetDeviceDsc, &tkptr->ProxyChannel, 0, 0)))
         {
            /* leave it to the AST function to report! */
            tkptr->ProxyConnectIOsb.Status = status;
            SysDclAst (ProxyHostConnectAst, tkptr);
            return;
         }
      }
   }

   if (!UseClientSocketOption ||
       VMSok (status) && VMSnok (tkptr->ProxyConnectIOsb.Status))
   {
      /* Multinet 3.2 UCX driver barfs on FULL_DUPLEX_CLOSE, use without */
      if (Debug) fprintf (stdout, "sys$qiow() IO$_SETMODE\n");
      status = sys$qiow (0, tkptr->ProxyChannel, IO$_SETMODE,
                         &tkptr->ProxyConnectIOsb, 0, 0,
                         &TcpSocket, 0, 0, 0, 0, 0);
      if (Debug)
         fprintf (stdout, "sys$qiow() %%X%08.08X IOsb.Status %%X%08.08X\n",
                  status, tkptr->ProxyConnectIOsb.Status);

      /* seeing this worked OK let's not bother with the first one again */
      if (UseClientSocketOption &&
          VMSok (status) && VMSok (tkptr->ProxyConnectIOsb.Status))
         UseClientSocketOption = false;
   }

   if (VMSok (status) && VMSnok (tkptr->ProxyConnectIOsb.Status))
      status = tkptr->ProxyConnectIOsb.Status;
   if (VMSnok (status))
   {
      /* leave it to the AST function to report! */
      tkptr->ProxyConnectIOsb.Status = status;
      SysDclAst (ProxyHostConnectAst, tkptr);
      return;
   }

   memset (&tkptr->ProxySocketName, 0, sizeof(tkptr->ProxySocketName));
   tkptr->ProxySocketName.sin_family = UCX$C_AF_INET;
   tkptr->ProxySocketName.sin_port = htons (tkptr->ConnectPort);
   memcpy (&tkptr->ProxySocketName.sin_addr.s_addr,
           &tkptr->ConnectIpAddress, 4);

   tkptr->ProxySocketNameItem.Length = sizeof(tkptr->ProxySocketName);
   tkptr->ProxySocketNameItem.ItemCode = UCX$C_SOCK_NAME;
   tkptr->ProxySocketNameItem.Address = &tkptr->ProxySocketName;

   if (Debug) fprintf (stdout, "sys$qio() IO$_ACCESS\n");
   status = sys$qio (0, tkptr->ProxyChannel, IO$_ACCESS,
                     &tkptr->ProxyConnectIOsb, &ProxyHostConnectAst, tkptr,
                     0, 0, &tkptr->ProxySocketNameItem, 0, 0, 0);
   if (Debug)
      fprintf (stdout, "sys$qio() %%X%08.08X IOsb.Status %%X%08.08X\n",
               status, tkptr->ProxyConnectIOsb.Status);

   if (VMSnok (status))
   {
      /* leave it to the AST function to report! */
      tkptr->ProxyConnectIOsb.Status = status;
      SysDclAst (ProxyHostConnectAst, tkptr);
      return;
   }
}

/****************************************************************************/
/*
Called as an AST from ProxyHostConnect().  The remote server host connect
attempt has completed and either been successful or returned an error status. 
If an error then explain it and end proxy processing.  If successful then write
the request to the remote server.  This ASTs to ProxyWriteRequestAst().
*/

ProxyHostConnectAst (struct ProxyTaskStruct *tkptr)

{
   register struct RequestStruct  *rqptr;

   int  status;
   char  *cptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "ProxyHostConnectAst() |%s| %%X%08.08X\n",
               tkptr->RequestHostNamePort, tkptr->ProxyConnectIOsb.Status);

   /* get associated request (if any) */
   rqptr = tkptr->RequestPtr;

   if (VMSnok (tkptr->ProxyConnectIOsb.Status))
   {
      /*****************/
      /* connect error */
      /*****************/

      if (tkptr->WatchItem &&
          (WatchEnabled & WATCH_PROXY))
         WatchThis (rqptr, FI_LI, WATCH_PROXY,
                    "CONTACT %X!8XL %!%M",
                    tkptr->ProxyConnectIOsb.Status,
                    tkptr->ProxyConnectIOsb.Status);

      /* dispose of the non-connected channel/socket used for the lookup */
      ProxyCloseSocket (tkptr);

      tkptr->ResponseStatusCode = 502;
      if (rqptr != NULL)
      {
         /* request associated with task */
         rqptr->rqResponse.HttpStatus = 502;

         switch (tkptr->ProxyConnectIOsb.Status)
         {
            case PROXY_ERROR_CONNECT_REFUSED :

               if (tkptr->ServicePtr->ProxyChainIpAddress)
                  cptr = MsgFor(rqptr,MSG_PROXY_CHAIN_REFUSED);
               else
                  cptr = MsgFor(rqptr,MSG_PROXY_CONNECT_REFUSED);

               ErrorGeneral (rqptr, cptr, FI_LI);
               break;

            case PROXY_ERROR_HOST_UNREACHABLE :

               if (tkptr->ServicePtr->ProxyChainIpAddress)
                  cptr = MsgFor(rqptr,MSG_PROXY_CHAIN_UNREACHABLE);
               else
                  cptr = MsgFor(rqptr,MSG_PROXY_HOST_UNREACHABLE);

               ErrorGeneral (rqptr, cptr, FI_LI);
               break;

            default :

               if (tkptr->ServicePtr->ProxyChainIpAddress)
               {
                  rqptr->rqResponse.ErrorTextPtr =
                     MsgFor(rqptr,MSG_PROXY_CHAIN_FAILURE);
                  rqptr->rqResponse.ErrorOtherTextPtr =
                     tkptr->ServicePtr->ProxyChainHostPort;
               }
               else
                  rqptr->rqResponse.ErrorTextPtr = tkptr->RequestHostNamePort;
               ErrorVmsStatus (rqptr, tkptr->ProxyConnectIOsb.Status, FI_LI);
         }
      }

      ProxyEnd (tkptr);
      return;
   }

   if (tkptr->HttpMethod == HTTP_METHOD_CONNECT)
   {
      /*************************/
      /* HTTP "CONNECT" method */
      /*************************/

      if (tkptr->WatchItem &&
          (WatchEnabled & WATCH_PROXY))
         WatchThis (rqptr, FI_LI, WATCH_PROXY,
                    "HTTP CONNECT established");

      HttpHeader (rqptr, 200, NULL, -1, NULL, NULL);
      rqptr->rqResponse.HeaderSent = true;

      NetWriteRaw (rqptr, &ProxyHttpConnectNetWriteAst,
                   rqptr->rqResponse.HeaderPtr, rqptr->rqResponse.HeaderLength);

      NetReadRaw (tkptr->RequestPtr, &ProxyHttpConnectNetReadAst,
                  tkptr->RequestPtr->rqNet.ReadBufferPtr,
                  tkptr->RequestPtr->rqNet.ReadBufferSize);

      return;
   }

   /*************************************/ 
   /* HTTP "GET", "POST", etc., methods */
   /*************************************/ 

   /* rebuild, then write request header */
   ProxyRebuildRequest (rqptr);

   if (tkptr->WatchItem &&
       (WatchEnabled & WATCH_PROXY_REQU_HDR))
   {
      WatchThis (rqptr, FI_LI, WATCH_PROXY_REQU_HDR,
                 "REQUEST HEADER !UL bytes", tkptr->RebuiltRequestLength);
      WatchData (tkptr->RebuiltRequestPtr, tkptr->RebuiltRequestLength);
   }

   ProxyWriteRaw (tkptr, &ProxyWriteRequestAst,
                  tkptr->RebuiltRequestPtr,
                  tkptr->RebuiltRequestLength);
}

/****************************************************************************/
/*
************
*** NOTE ***  This function takes a pointer to a request!!!
************

*/

ProxyHttpConnectNetWriteAst (struct RequestStruct *rqptr)

{
   register struct ProxyTaskStruct  *tkptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) 
      fprintf (stdout, "ProxyHttpConnectNetWriteAst() %%X%08.08X %d\n",
               rqptr->rqNet.WriteIOsb.Status, rqptr->rqNet.WriteIOsb.Count);

   tkptr = rqptr->ProxyTaskPtr; 

   if (VMSnok (rqptr->rqNet.WriteIOsb.Status))
   {
      ProxyEnd (tkptr);
      return;
   }

   ProxyReadRaw (tkptr, &ProxyHttpConnectProxyReadAst,
                 tkptr->ResponseBufferPtr,
                 tkptr->ResponseBufferSize);
}

/****************************************************************************/
/*
************
*** NOTE ***  This function takes a pointer to a request!!!
************

*/

ProxyHttpConnectNetReadAst (struct RequestStruct *rqptr)

{
   register struct ProxyTaskStruct  *tkptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "ProxyHttpConnectNetReadAst() %%X%08.08X %d\n",
               rqptr->rqNet.ReadIOsb.Status, rqptr->rqNet.ReadIOsb.Count);

   tkptr = rqptr->ProxyTaskPtr; 

   if (VMSnok (rqptr->rqNet.ReadIOsb.Status))
   {
      ProxyEnd (tkptr);
      return;
   }

   ProxyWriteRaw (tkptr, &ProxyHttpConnectProxyWriteAst,
                  rqptr->rqNet.ReadBufferPtr,
                  rqptr->rqNet.ReadIOsb.Count);
}

/****************************************************************************/
/*
*/

ProxyHttpConnectProxyWriteAst (struct ProxyTaskStruct *tkptr)

{
   register struct RequestStruct *rqptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) 
      fprintf (stdout, "ProxyHttpConnectProxyWriteAst() %%X%08.08X %d\n",
               tkptr->ProxyWriteIOsb.Status, tkptr->ProxyWriteIOsb.Count);

   /* get associated request (if any) */
   rqptr = tkptr->RequestPtr;

   if (VMSnok (tkptr->ProxyWriteIOsb.Status))
   {
      ProxyEnd (tkptr);
      return;
   }

   NetReadRaw (tkptr->RequestPtr, &ProxyHttpConnectNetReadAst,
               tkptr->RequestPtr->rqNet.ReadBufferPtr,
               tkptr->RequestPtr->rqNet.ReadBufferSize);
}

/****************************************************************************/
/*
AST completion of read from proxied server.
*/

ProxyHttpConnectProxyReadAst (struct ProxyTaskStruct *tkptr)

{
   register struct RequestStruct *rqptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "ProxyHttpConnectProxyReadAst() %%X%08.08X %d\n",
               tkptr->ProxyReadIOsb.Status, tkptr->ProxyReadIOsb.Count);

   /* get associated request (if any) */
   rqptr = tkptr->RequestPtr;

   if (VMSnok (tkptr->ProxyReadIOsb.Status))
   {
      ProxyEnd (tkptr);
      return;
   }

   NetWriteRaw (tkptr->RequestPtr, &ProxyHttpConnectNetWriteAst,
                tkptr->ResponseBufferPtr,
                tkptr->ProxyReadIOsb.Count);
}

/****************************************************************************/
/*
Called as an AST from ProxyWriteRequest().  The write of the request header to
the remote server has completed. If the is a body to the request (i.e. a POST
or PUT method) then call the function to BEGIN CONCURRENTLY writing that.  If
no body check the status of the proxy write. If not successful then report the
error and end the proxy processing.  If OK then queue a read from the remote
server to begin to get the response.
*/

ProxyWriteRequestAst (struct ProxyTaskStruct *tkptr)

{
   register char  *cptr, *sptr, *zptr;
   register struct RequestStruct *rqptr;

   int  DataLength;
   char  *DataPtr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyWriteRequestAst()\n");

   /* get associated request (if any) */
   rqptr = tkptr->RequestPtr;

   if (Debug)
      fprintf (stdout, "ProxyWriteIOsb.Status: %%X%08.08X\n",
               tkptr->ProxyWriteIOsb.Status);

   if (VMSnok (tkptr->ProxyWriteIOsb.Status))
   {
      /***********************/
      /* write request error */
      /***********************/

      if (tkptr->ProxyChannel)
      {
         /* the socket has not been deliberately closed, so ... */
         tkptr->ResponseStatusCode = 502;
         if (rqptr != NULL)
         {
            /* a request associated with this proxy task */
            rqptr->rqResponse.HttpStatus = 502;
            rqptr->rqResponse.ErrorTextPtr = tkptr->RequestHostNamePort;
            ErrorVmsStatus (rqptr, tkptr->ProxyWriteIOsb.Status, FI_LI);
         }
      }

      /* toodleoo */
      ProxyEnd (tkptr);
      return;
   }

   if (rqptr->rqBody.CurrentCount)
   {
      /**********************************************************/
      /* concurrently send body as well as waiting for response */
      /**********************************************************/

      tkptr->ContentPtr = rqptr->rqBody.BufferPtr;
      tkptr->ContentCount = rqptr->rqBody.CurrentCount;

      ProxyWriteRequestBody (tkptr);

      /* just drop throught to begin reading response */
   }

   /*************************************/
   /* begin (wait for) reading response */
   /*************************************/

   tkptr->ResponseHeaderPtr = tkptr->ResponseBufferCurrentPtr;
   tkptr->ResponseBodyLength =
      tkptr->ResponseHeaderLength =
      tkptr->ResponseConsecutiveNewLineCount = 0;

   /* responses can quite legitimately have a content-length of zero, so ... */
   tkptr->ResponseContentLength = -1;

   ProxyReadRaw (tkptr, &ProxyReadResponseAst,
                 tkptr->ResponseBufferCurrentPtr,
                 tkptr->ResponseBufferRemaining);
}

/****************************************************************************/
/*
Called both as an AST (from itself) and also from ProxyWriteRequestAst() to
begin/continue writing the body to the remote server.  First check the status
of the last write and if an error report it and end proxy processing.  If
successful and there is more of the body to be sent do that ASTing back to this
same function.  If the body has been completely sent then just return
terminating this independent activity.
*/

ProxyWriteRequestBody (struct ProxyTaskStruct *tkptr)

{
   register struct RequestStruct *rqptr;

   int  DataLength;
   char  *DataPtr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "ProxyWriteRequestBody() %d %d\n",
               tkptr->ContentPtr, tkptr->ContentCount);

   /* get associated request (if any) */
   rqptr = tkptr->RequestPtr;

   if (Debug)
      fprintf (stdout, "ProxyWriteIOsb.Status: %%X%08.08X\n",
               tkptr->ProxyWriteIOsb.Status);

   if (VMSnok (tkptr->ProxyWriteIOsb.Status))
   {
      /********************/
      /* write body error */
      /********************/

      if (tkptr->ProxyChannel)
      {
         /* the socket has not been deliberately closed, so ... */
         tkptr->ResponseStatusCode = 502;
         if (rqptr != NULL)
         {
            /* a request associated with this proxy task */
            rqptr->rqResponse.HttpStatus = 502;
            rqptr->rqResponse.ErrorTextPtr = tkptr->RequestHostNamePort;
            ErrorVmsStatus (rqptr, tkptr->ProxyWriteIOsb.Status, FI_LI);
         }
      }

      /* finale */
      ProxyEnd (tkptr);
      return;
   }

   if (!tkptr->ContentCount) 
   {
      /****************************/
      /* request body is finished */
      /****************************/

      /* just finish up this concurrent activity */
      return;
   }

   /************************************/
   /* request body is sent in "chunks" */
   /************************************/

   DataPtr = tkptr->ContentPtr;
   if (tkptr->ContentCount > PROXY_CONTENT_MAX)
      DataLength = PROXY_CONTENT_MAX;
   else
      DataLength = tkptr->ContentCount;
   tkptr->ContentCount -= DataLength;
   tkptr->ContentPtr += DataLength;

   if (Debug)
   {
      fprintf (stdout, "%d %d\n", DataPtr, DataLength);
      fprintf (stdout, "|%*.*s|\n", DataLength, DataLength, DataPtr);
   }

   if (tkptr->WatchItem &&
       (WatchEnabled & WATCH_PROXY_REQU_BDY))
   {
      WatchThis (rqptr, FI_LI, WATCH_PROXY_REQU_BDY,
                 "REQUEST BODY !UL bytes", DataLength);
      WatchDataDump (DataPtr, DataLength);
   }

   ProxyWriteRaw (tkptr, &ProxyWriteRequestBody, DataPtr, DataLength);
}

/****************************************************************************/
/*
Called as an AST when the read of a buffer from the proxied server completes.
It checks for, and analyzes, the response header.  When the response header
has been analyzed a decision is made as to whether the response is cachable.
If cacheable this function stops executing while the cache file is created.
When that is complete ProxyReadResponseCacheWrite() is called as an AST to
write the first buffer of data into the file.  If not cacheable then if
associated with a request the data is written to the client via the network.
*/

ProxyReadResponseAst (struct ProxyTaskStruct *tkptr)

{
   register char  *cptr, *sptr, *zptr;
   register struct RequestStruct  *rqptr;

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyReadResponseAst()\n");

   /* get associated request (if any) */
   rqptr = tkptr->RequestPtr;

   if (Debug)
      fprintf (stdout, "ProxyReadIOsb.Status: %%X%08.08X %d\n",
               tkptr->ProxyReadIOsb.Status,
               tkptr->ProxyReadIOsb.Count);

   if (VMSnok (tkptr->ProxyReadIOsb.Status))
   {
      /**************/
      /* read error */
      /**************/

      if (tkptr->ProxyChannel)
      {
         /* the socket has not been deliberately shut down */

         if (tkptr->ResponseBytes)
         {
            /* we got some bytes back from the remote server */
            if (tkptr->ResponseHttpVersion != HTTP_VERSION_0_9 &&
                !tkptr->ResponseHeaderLength)
            {
               /* header was not completely received */
               tkptr->ResponseStatusCode = 502;
               if (rqptr != NULL)
               {
                  /* request associated with task */
                  rqptr->rqResponse.HttpStatus = 502;
                  ErrorGeneral (rqptr,
                     MsgFor(rqptr,MSG_PROXY_RESPONSE_HEADER), FI_LI);
               }
            }
         }
         else
         {
            /* absolutely no bytes at all from the remote server */
            tkptr->ResponseStatusCode = 502;
            if (rqptr != NULL)
            {
               /* request associated with task */
               rqptr->rqResponse.HttpStatus = 502;
               rqptr->rqResponse.ErrorTextPtr = tkptr->RequestHostNamePort;
               switch (tkptr->ProxyReadIOsb.Status)
               {
                  case PROXY_ERROR_HOST_DISCONNECTED :
                     /* disconnected by third party */
                     ErrorGeneral (rqptr,
                        MsgFor(rqptr,MSG_PROXY_HOST_DISCONNECTED), FI_LI);
                     break;
                  default :
                     ErrorVmsStatus (rqptr, tkptr->ProxyReadIOsb.Status, FI_LI);
               }
            }
         }
      }

      /* finis */
      ProxyEnd (tkptr);
      return;
   }

   tkptr->ResponseBytes += tkptr->ProxyReadIOsb.Count;

   if (tkptr->ResponseConsecutiveNewLineCount < 2)
   {                                                                        
      /***************************/
      /* examine response header */
      /***************************/

      tkptr->ResponseBufferCurrentPtr += tkptr->ProxyReadIOsb.Count;
      tkptr->ResponseBufferRemaining -= tkptr->ProxyReadIOsb.Count;

      status = ProxyFindResponseHeader (tkptr);

      if (Debug)
         fprintf (stdout, "ProxyFindResponseHeader() %%X%08.08X\n", status);

      if (VMSnok (status))
      {
         tkptr->ResponseStatusCode = 502;
         if (rqptr != NULL)
         {
            /* request associated with task */
            rqptr->rqResponse.HttpStatus = 502;
            ErrorGeneral (rqptr,
               MsgFor(rqptr,MSG_PROXY_RESPONSE_HEADER), FI_LI);
         }

         ProxyEnd (tkptr);
         return;
      }

      if (tkptr->ResponseConsecutiveNewLineCount < 2)
      {
         /*******************************************/
         /* entire header has not yet been received */
         /*******************************************/

         ProxyReadRaw (tkptr, &ProxyReadResponseAst,
                       tkptr->ResponseBufferCurrentPtr,
                       tkptr->ResponseBufferRemaining);
         return;
      }

      /****************************/
      /* header has been received */
      /****************************/

      if (tkptr->ResponseHttpVersion == HTTP_VERSION_0_9)
      {
         if (tkptr->WatchItem &&
             (WatchEnabled & WATCH_PROXY_RESP_HDR))
         {
            WatchThis (rqptr, FI_LI, WATCH_PROXY_RESP_HDR,
                       "RESPONSE HTTP/0.9");
         }
      }
      else
      {
         if (tkptr->WatchItem &&
             (WatchEnabled & WATCH_PROXY_RESP_HDR))
         {
            WatchThis (rqptr, FI_LI, WATCH_PROXY_RESP_HDR,
                       "RESPONSE HEADER !UL bytes",
                       tkptr->ResponseHeaderLength);
            WatchData (tkptr->ResponseHeaderPtr,
                       tkptr->ResponseHeaderLength);
         }
      }

      /* request associated with task */
      if (rqptr != NULL) rqptr->rqResponse.HttpStatus = tkptr->ResponseStatusCode;

      /* this portion to (any) cache file (includes cache file description) */
      tkptr->ResponseBufferCachePtr = tkptr->ResponseBufferPtr;
      tkptr->ResponseBufferCacheCount = tkptr->ResponseBufferCurrentPtr -
                                        tkptr->ResponseBufferPtr;

      /* this portion to (any) network client (excludes cache description) */
      tkptr->ResponseBufferNetPtr = tkptr->ResponseHeaderPtr;
      tkptr->ResponseBufferNetCount = tkptr->ResponseBufferCurrentPtr -
                                      tkptr->ResponseHeaderPtr;

      if (tkptr->ResponseBufferCurrentPtr >
          tkptr->ResponseHeaderPtr + tkptr->ResponseHeaderLength)
      {
         /******************************************************/
         /* (some of) the response body has also been received */
         /******************************************************/

         tkptr->ResponseBodyLength =
            tkptr->ResponseBufferCurrentPtr -
            (tkptr->ResponseHeaderPtr + tkptr->ResponseHeaderLength);

         if (tkptr->WatchItem &&
             (WatchEnabled & WATCH_PROXY_RESP_BDY))
         {
            WatchThis (rqptr, FI_LI, WATCH_PROXY_RESP_BDY,
                       "RESPONSE BODY !UL bytes",
                       tkptr->ResponseBodyLength);
            WatchDataDump (tkptr->ResponseHeaderPtr +
                           tkptr->ResponseHeaderLength,
                           tkptr->ResponseBodyLength);
         }
      }

      if (tkptr->ServicePtr->ProxyFileCacheEnabled &&
          tkptr->ProxyCacheSuitable)
      {
         /***********************/
         /* begin proxy caching */
         /***********************/

         status = ProxyCacheLoadBegin (tkptr);

         /* error status means the file was not a candidate for being cached */
         if (VMSok (status)) return;
      }
   }
   else
   {
      /*******************************/
      /* just receiving the body now */
      /*******************************/

      tkptr->ResponseBodyLength += tkptr->ProxyReadIOsb.Count;

      /* both cache file and network contents are identical from here */
      tkptr->ResponseBufferNetPtr =
         tkptr->ResponseBufferCachePtr =
         tkptr->ResponseBufferPtr;
      tkptr->ResponseBufferNetCount =
         tkptr->ResponseBufferCacheCount =
         tkptr->ProxyReadIOsb.Count;

      if (tkptr->WatchItem &&
          (WatchEnabled & WATCH_PROXY_RESP_BDY))
      {
         WatchThis (rqptr, FI_LI, WATCH_PROXY_RESP_BDY,
                    "RESPONSE BODY !UL bytes", tkptr->ProxyReadIOsb.Count);
         WatchDataDump (tkptr->ResponseBufferPtr,
                        tkptr->ProxyReadIOsb.Count);
      }
   }

   /*******************************************************/
   /* to cache file (then any client) or direct to client */
   /*******************************************************/

   if (tkptr->LoadFab.fab$w_ifi)
      ProxyCacheLoadWrite (tkptr);
   else
      ProxyResponseNetWrite (tkptr);
}

/****************************************************************************/
/*
If a cache load is in progress this function is called when the file write is
complete. If not in progress then this is called directly from
ProxyReadResponseAst(). If a request is associated with the task the current
buffer is written out to the client via the network.  If no request then the
next buffer is read from the proxied server.
*/

ProxyResponseNetWrite (struct ProxyTaskStruct *tkptr)

{
   register struct RequestStruct  *rqptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyResponseNetWrite()\n");

   /* get associated request (if any) */
   rqptr = tkptr->RequestPtr;

   if (rqptr != NULL)
   {
      /* request associated with task */

      NetWrite (tkptr->RequestPtr, &ProxyResponseNetWriteAst,
                tkptr->ResponseBufferNetPtr,
                tkptr->ResponseBufferNetCount);
   }
   else
   {
      /* no associated request, just read some more */
      ProxyReadRaw (tkptr, &ProxyReadResponseAst,
                    tkptr->ResponseBufferPtr,
                    tkptr->ResponseBufferSize);
   }
}

/****************************************************************************/
/*
************
*** NOTE ***  This function takes a pointer to a request!!!
************

Just a wrapper for when NetWrite() is used to AST queue a read of the next part
of the response. Check the network write status and if OK then queue another
read of data from the proxied server.
*/

ProxyResponseNetWriteAst (struct RequestStruct *rqptr)

{
   register struct ProxyTaskStruct  *tkptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyReadResponseAstNetWrite()\n");

   tkptr = rqptr->ProxyTaskPtr; 

   if (Debug)
      fprintf (stdout, "NetWriteIOsb.Status: %%X%08.08X\n",
               rqptr->rqNet.WriteIOsb.Status);
   if (VMSnok (rqptr->rqNet.WriteIOsb.Status))
   {
      /* write to client failed, just abandon the request */
      ProxyEnd (rqptr->ProxyTaskPtr);
      return;
   }

   ProxyReadRaw (tkptr, &ProxyReadResponseAst,
                 tkptr->ResponseBufferPtr,
                 tkptr->ResponseBufferSize);
}

/****************************************************************************/
/*
Just queue a read of the next buffer-full from the remote server.
*/

ProxyReadResponseNext (struct ProxyTaskStruct *tkptr)

{
   register struct RequestStruct  *rqptr;

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyReadResponseNext()\n");

   /* get associated request (if any) */
   rqptr = tkptr->RequestPtr;

   ProxyReadRaw (tkptr, &ProxyReadResponseAst,
                 tkptr->ResponseBufferPtr,
                 tkptr->ResponseBufferSize);
}

/****************************************************************************/
/*
Check the HTTP version.  If it doesn't look like an HTTP/1.n then assume its an
HTTP/0.9 (stream of HTML) and don't look for header fields.  Look through the
data received from the remote server so far for two consecutive blank lines
(two newlines or two carriage-return/newline combinations).  This delimits the
response header.  When found parse the response header.
*/

int ProxyFindResponseHeader (struct ProxyTaskStruct *tkptr)

{
   register int  cnlcnt;
   register char  *cptr, *zptr;

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyFindResponseHeader()\n");

   cnlcnt = tkptr->ResponseConsecutiveNewLineCount;
   cptr = tkptr->ResponseHeaderPtr;
   zptr = tkptr->ResponseBufferCurrentPtr;

   if (Debug)
   {
      int  len;
      len = tkptr->ResponseBufferCurrentPtr - tkptr->ResponseHeaderPtr;
      fprintf (stdout, "|%*s|\ncnlcnt: %d *cptr: %d\n",
               len, tkptr->ResponseHeaderPtr, cnlcnt, *cptr);
   }

   if (!tkptr->ResponseHttpVersion)
   {
      /***************************************/
      /* check it's not an HTTP/0.9 response */
      /***************************************/

      /* must look something like "HTTP/1.0 200" */
      if (memcmp (cptr, "HTTP/", 5) ||
          !isdigit(cptr[5]) ||
          cptr[6] != '.' ||
          !isdigit(cptr[7]))
      {
         ProxyHttp09ResponseHeader (tkptr);
         return (SS$_NORMAL);
      }
      for (cptr += 8; *cptr && ISLWS(*cptr) && cptr < zptr; cptr++);
      if (!isdigit(cptr[0]) ||
          !isdigit(cptr[1]) ||
          !isdigit(cptr[2]) ||
          (!ISLWS(cptr[3]) && NOTEOL(cptr[3])))
      {
         ProxyHttp09ResponseHeader (tkptr);
         return (SS$_NORMAL);
      }

      if (!memcmp (cptr, "HTTP/1.0", 8))
         tkptr->ResponseHttpVersion = HTTP_VERSION_1_0;
      else
      if (!memcmp (cptr, "HTTP/1.1", 8))
         tkptr->ResponseHttpVersion = HTTP_VERSION_1_1;
      else
         tkptr->ResponseHttpVersion = HTTP_VERSION_UNKNOWN;
   }

   /******************************/
   /* look for the end-of-header */
   /******************************/

   while (*cptr && cnlcnt < 2 && cptr < zptr)
   {
      if (*cptr == '\r') cptr++;
      if (!*cptr) break;
      if (*cptr != '\n')
      {
         cptr++;
         cnlcnt = 0;
         continue;
      }
      cptr++;
      cnlcnt++;
   }
   if (Debug) fprintf (stdout, "cnlcnt: %d\n", cnlcnt);

   if ((tkptr->ResponseConsecutiveNewLineCount = cnlcnt) >= 2)
   {
      /* found the end of the response header */
      tkptr->ResponseHeaderLength = cptr - (char*)tkptr->ResponseHeaderPtr;

      if (Debug)
         fprintf (stdout, "%d |%*.*s|\n",
                  tkptr->ResponseHeaderLength,
                  tkptr->ResponseHeaderLength, tkptr->ResponseHeaderLength,
                  tkptr->ResponseHeaderPtr);

      status = ProxyParseResponseHeader (tkptr);
      if (Debug)
         fprintf (stdout, "ProxyParseResponseHeader() %%X%08.08X\n", status);
      return (status);
   }

   return (SS$_NORMAL);
}


/****************************************************************************/
/*
Fudge status response components for HTTP/0.9.  Leave the
'tkptr->ResponseHeaderPtr' pointing where-ever but set the
'tkptr->ResponseHeaderLength' to zero.
*/

ProxyHttp09ResponseHeader (struct ProxyTaskStruct *tkptr)

{
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyHttp09ResponseHeader()\n");

   tkptr->ProxyCacheSuitable = false;
   tkptr->ResponseConsecutiveNewLineCount = 2;
   tkptr->ResponseHeaderLength = 0;
   /* do not touch 'tkptr->ResponseHeaderPtr' upon penalty of bug! */
   tkptr->ResponseHttpVersion = HTTP_VERSION_0_9;
   strcpy (tkptr->ResponseHttpProtocol, "HTTP/0.9");
   strcpy (tkptr->ResponseStatusCodeString, "200");
   tkptr->ResponseStatusCode = 200;
   strcpy (tkptr->ResponseStatusDescription, HttpStatusCodeText(200));

   if (Debug)
      fprintf (stdout, "|%s|%s|%d|%s|\n",
               tkptr->ResponseHttpProtocol,
               tkptr->ResponseStatusCodeString,
               tkptr->ResponseStatusCode,
               tkptr->ResponseStatusDescription);
}


/****************************************************************************/
/*
Scan through the remote server response header.  Items of interest include the
three digit status code from the first line, any "Content-Length:", "Expires:"
and "Last-Modified:" header lines, as these are use in determining whether any
given response is suitable for file caching if enabled.
*/

int ProxyParseResponseHeader (struct ProxyTaskStruct *tkptr)

{
   register char  *cptr, *czptr, *hzptr, *sptr, *zptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyParseResponseHeader()\n");

   /* initialize content length to indicate it was not set */
   tkptr->ResponseContentLength = -1;

   cptr = tkptr->ResponseHeaderPtr;
   czptr = cptr + tkptr->ResponseHeaderLength;

   /************************/
   /* response status line */
   /************************/

   zptr = (sptr = tkptr->ResponseHttpProtocol) +
          sizeof(tkptr->ResponseHttpProtocol);
   while (cptr < czptr && !ISLWS(*cptr) && NOTEOL(*cptr) && sptr < zptr)
      *sptr++ = *cptr++;
   if (sptr >= zptr) sptr = tkptr->ResponseHttpProtocol;
   *sptr = '\0';

   while (cptr < czptr && ISLWS(*cptr) && NOTEOL(*cptr)) cptr++;

   zptr = (sptr = tkptr->ResponseStatusCodeString) +
          sizeof(tkptr->ResponseStatusCodeString);
   while (cptr < czptr && !ISLWS(*cptr) && NOTEOL(*cptr) && sptr < zptr)
      *sptr++ = *cptr++;
   if (sptr >= zptr) sptr = tkptr->ResponseStatusCodeString;
   *sptr = '\0';
   tkptr->ResponseStatusCode = atoi(tkptr->ResponseStatusCodeString);

   while (cptr < czptr && ISLWS(*cptr) && NOTEOL(*cptr)) cptr++;

   zptr = (sptr = tkptr->ResponseStatusDescription) +
          sizeof(tkptr->ResponseStatusDescription);
   while (cptr < czptr && NOTEOL(*cptr) && sptr < zptr)
      *sptr++ = *cptr++;
   if (sptr >= zptr) sptr--;
   *sptr = '\0';

   if (Debug)
      fprintf (stdout, "|%s|%s|%d|%s|\n",
               tkptr->ResponseHttpProtocol,
               tkptr->ResponseStatusCodeString,
               tkptr->ResponseStatusCode,
               tkptr->ResponseStatusDescription);

   /* status description string can, after all, be empty! */
   if (!tkptr->ResponseHttpProtocol[0] ||
       !tkptr->ResponseStatusCodeString[0] ||
       !tkptr->ResponseStatusCode)
      return (STS$K_ERROR);

   /*********************************/
   /* rest of relevant header lines */
   /*********************************/

   while (cptr < czptr && NOTEOL(*cptr)) cptr++;
   while (cptr < czptr && EOL(*cptr)) cptr++;

   while (cptr < czptr)
   {
      /* scan down to the carriage-control of the field line */
      hzptr = cptr;      
      while (hzptr < czptr && NOTEOL(*hzptr)) hzptr++;

      if (Debug)
         fprintf (stdout, "cptr |%*.*s|\n", hzptr-cptr, hzptr-cptr, cptr);

      if (toupper(*cptr) == 'C' &&
          strsame (cptr, "Content-Length:", 15))
      {
         cptr += 15;
         while (cptr < hzptr && ISLWS(*cptr)) cptr++;
         tkptr->ResponseContentLength = atoi(cptr);
         if (Debug)
            fprintf (stdout, "Content-Length: %d\n",
                     tkptr->ResponseContentLength);
      }
      else
      if (toupper(*cptr) == 'E' &&
          strsame (cptr, "Expires:", 8))
      {
         cptr += 8;
         while (cptr < hzptr && ISLWS(*cptr)) cptr++;
         zptr = (sptr = tkptr->ResponseExpires) +
            sizeof(tkptr->ResponseExpires);
         while (cptr < hzptr && sptr < zptr) *sptr++ = *cptr++;
         if (sptr >= zptr) sptr = tkptr->ResponseExpires;
         *sptr = '\0';
         if (Debug)
            fprintf (stdout, "Expires: |%s|\n",
                     tkptr->ResponseExpires);
         if (VMSnok (HttpGmTime (tkptr->ResponseExpires,
                                 &tkptr->ResponseExpiresBinaryTime)))
         {
            if (Debug) fprintf (stdout, "Expires: NBG!\n");
            tkptr->ResponseExpiresBinaryTime[0] =
               tkptr->ResponseExpiresBinaryTime[1] = 0;
            tkptr->ResponseExpires[0] = '\0';
         }
      }
      if (toupper(*cptr) == 'L' &&
          strsame (cptr, "Last-Modified:", 14))
      {
         cptr += 14;
         while (cptr < hzptr && ISLWS(*cptr)) cptr++;
         zptr = (sptr = tkptr->ResponseLastModified) +
            sizeof(tkptr->ResponseLastModified);
         while (cptr < hzptr && sptr < zptr) *sptr++ = *cptr++;
         if (sptr >= zptr) sptr = tkptr->ResponseLastModified;
         *sptr = '\0';
         if (Debug)
            fprintf (stdout, "Last-Modified: |%s|\n",
                     tkptr->ResponseLastModified);
         if (VMSnok (HttpGmTime (tkptr->ResponseLastModified,
                                 &tkptr->ResponseLastModifiedBinaryTime)))
         {
            if (Debug) fprintf (stdout, "If-Modified-Since: NBG!\n");
            tkptr->ResponseLastModifiedBinaryTime[0] =
               tkptr->ResponseLastModifiedBinaryTime[1] = 0;
            tkptr->ResponseLastModified[0] = '\0';
         }
      }
      else
      if (toupper(*cptr) == 'P' &&
          strsame (cptr, "Pragma:", 7))
      {
         cptr += 7;
         while (cptr < hzptr && ISLWS(*cptr)) cptr++;
         if (strsame (cptr, "no-cache", 8)) tkptr->ResponsePragmaNoCache = true;
         if (Debug)
            fprintf (stdout, "Pragma: %d\n", tkptr->ResponsePragmaNoCache);
      }
      else
      if (toupper(*cptr) == 'S' &&
          strsame (cptr, "Set-Cookie:", 11))
      {
         /* just note that the response contains a cookie */
         tkptr->ResponseSetCookie = true;
      }

      /* scan over the carriage-control of the field line */
      while (hzptr < czptr && EOL(*hzptr)) hzptr++;
      cptr = hzptr;
   }

   return (SS$_NORMAL);
}

/****************************************************************************/
/*
************
*** NOTE ***  This function takes a pointer to a request!!!
************

Using the request header fields rebuild a request header suitable for use by
the proxy server.
*/ 

int ProxyRebuildRequest (struct RequestStruct *rqptr)

{
#define STRCAT(string) \
   for (cptr = string; *cptr && sptr < zptr; *sptr++ = *cptr++);
#define CHRCAT(character) \
   if (sptr < zptr) *sptr++ = character;
#define CRLFCAT \
   if (sptr < zptr) *sptr++ = '\r'; \
   if (sptr < zptr) *sptr++ = '\n';

   static char  Number [16];
   static $DESCRIPTOR (NumberDsc, Number);
   static $DESCRIPTOR (NumberFaoDsc, "!UL\0");

   int  Length;
   char  *cptr, *sptr, *zptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyRebuildRequest()\n");

   rqptr->ProxyTaskPtr->RebuiltRequestPtr = sptr =
      VmGetHeap (rqptr, NetReadBufferSize);
   zptr = sptr + NetReadBufferSize;

   STRCAT (rqptr->rqHeader.MethodName)
   CHRCAT (' ')
   if (rqptr->ServicePtr->ProxyChainIpAddress)
   {
      STRCAT ("http://")
      STRCAT (rqptr->ProxyTaskPtr->RequestHostNamePort)
   }
   STRCAT (rqptr->ProxyTaskPtr->RequestUriPtr)

   if (rqptr->ProxyTaskPtr->RequestHttpVersion == HTTP_VERSION_0_9)
   {
      /*******************/
      /* HTTP/0.9 header */
      /*******************/

      /* just end the line (and header) without an HTTP protocol version */
      CRLFCAT
   }
   else
   {
      /*******************/
      /* HTTP/1.n header */
      /*******************/

      CHRCAT (' ')
      STRCAT (HttpProtocol)
      CRLFCAT

      if (rqptr->rqHeader.AcceptPtr != NULL)
      {
         STRCAT ("Accept: ")
         STRCAT (rqptr->rqHeader.AcceptPtr)
         CRLFCAT
      }

      if (rqptr->rqHeader.AcceptCharsetPtr != NULL)
      {
         STRCAT ("Accept-Charset: ")
         STRCAT (rqptr->rqHeader.AcceptCharsetPtr)
         CRLFCAT
      }

      if (rqptr->rqHeader.AcceptEncodingPtr != NULL)
      {
         STRCAT ("Accept-Encoding: ")
         STRCAT (rqptr->rqHeader.AcceptEncodingPtr)
         CRLFCAT
      }

      if (rqptr->rqHeader.AcceptLangPtr != NULL)
      {
         STRCAT ("Accept-Language: ")
         STRCAT (rqptr->rqHeader.AcceptLangPtr)
         CRLFCAT
      }

      if (rqptr->rqHeader.UserAgentPtr != NULL)
      {
         STRCAT ("User-Agent: ")
         STRCAT (rqptr->rqHeader.UserAgentPtr)
         CRLFCAT
      }

      if (rqptr->rqHeader.RefererPtr != NULL)
      {
         STRCAT ("Referer: ")
         STRCAT (rqptr->rqHeader.RefererPtr)
         CRLFCAT
      }

      if (rqptr->rqHeader.HostPtr != NULL)
      {
         STRCAT ("Host: ")
         STRCAT (rqptr->rqHeader.HostPtr)
         CRLFCAT
      }

      /* only included if not used to authorize this proxy access */
      if (rqptr->rqHeader.ProxyAuthorizationPtr != NULL &&
          !rqptr->ServicePtr->ProxyAuthRequired)
      {
         STRCAT ("Proxy-Authorization: ")
         STRCAT (rqptr->rqHeader.ProxyAuthorizationPtr)
         CRLFCAT
      }

      if (rqptr->rqHeader.AuthorizationPtr != NULL)
      {
         STRCAT ("Authorization: ")
         STRCAT (rqptr->rqHeader.AuthorizationPtr)
         CRLFCAT
      }

      if (rqptr->rqHeader.PragmaPtr != NULL)
      {
         STRCAT ("Pragma: ")
         STRCAT (rqptr->rqHeader.PragmaPtr)
         CRLFCAT
      }

      if (rqptr->rqHeader.IfModifiedSincePtr != NULL)
      {
         STRCAT ("If-Modified-Since: ")
         STRCAT (rqptr->rqHeader.IfModifiedSincePtr)
         CRLFCAT
      }

#ifdef HTTP_PROXY_CONNECTION
      if (rqptr->rqHeader.ProxyConnectionPtr != NULL)
      {
         STRCAT ("Proxy-Connection: ")
         STRCAT (rqptr->rqHeader.ProxyConnectionPtr)
         CRLFCAT
      }
#endif /* HTTP_PROXY_CONNECTION */

      if (rqptr->rqHeader.CookiePtr != NULL)
      {
         STRCAT ("Cookie: ")
         STRCAT (rqptr->rqHeader.CookiePtr)
         CRLFCAT
      }

      if (rqptr->rqHeader.ContentTypePtr != NULL)
      {
         STRCAT ("Content-Type: ")
         STRCAT (rqptr->rqHeader.ContentTypePtr)
         CRLFCAT
      }

      if (rqptr->rqHeader.ContentLength)
      {
         sys$fao (&NumberFaoDsc, 0, &NumberDsc, rqptr->rqHeader.ContentLength);
         STRCAT ("Content-Length: ")
         STRCAT (Number)
         CRLFCAT
      }

      if (rqptr->rqHeader.ETagPtr != NULL)
      {
         STRCAT ("ETag: ")
         STRCAT (rqptr->rqHeader.ETagPtr)
         CRLFCAT
      }

#ifdef HTTP_PROXY_CONNECTION
      if (rqptr->KeepAliveRequest)
         STRCAT ("Connection: Keep-Alive\r\n")
#else /* HTTP_PROXY_CONNECTION */
         STRCAT ("Connection: close\r\n")
#endif /* HTTP_PROXY_CONNECTION */

      if (ProxyAddForwardedByEnabled ||
          rqptr->rqHeader.ForwardedPtr != NULL)
      {
         STRCAT ("Forwarded: ")
         if (ProxyAddForwardedByEnabled)
         {
            STRCAT ("by http://")
            if (rqptr->ServicePtr->ServerPort == 80)
               STRCAT (rqptr->ServicePtr->ServerHostName)
            else
               STRCAT (rqptr->ServicePtr->ServerHostPort)
            STRCAT (" (")
            STRCAT (SoftwareID)
            CHRCAT (')')
         }
         if (rqptr->rqHeader.ForwardedPtr != NULL)
         {
            if (ProxyAddForwardedByEnabled) STRCAT (",")
            STRCAT (rqptr->rqHeader.ForwardedPtr)
         }
         CRLFCAT
      }

      /* end-of-header blank line */
      CRLFCAT

      /**************************/
      /* end of HTTP/1.n header */
      /**************************/
   }

   if (sptr >= zptr)
   {
      rqptr->rqResponse.HttpStatus = 500;
      ErrorGeneralOverflow (rqptr, FI_LI);
      return (STS$K_ERROR);
   }
   *sptr = '\0';
   rqptr->ProxyTaskPtr->RebuiltRequestLength = Length =
      sptr - rqptr->ProxyTaskPtr->RebuiltRequestPtr;
   if (Debug)
      fprintf (stdout, "%d |%s|\n",
               Length, rqptr->ProxyTaskPtr->RebuiltRequestPtr);

   return (SS$_NORMAL);
}

/*****************************************************************************/
/*
Write data to the proxied server. Explicitly declares any AST routine if an
error occurs. The calling function must not do any error recovery if an AST
routine has been supplied but the associated AST routine must! If an AST was
not supplied then the return status can be checked.  AST calls
ProxyWriteRawAST() which will then call the supplied AST function.
*/

int ProxyWriteRaw
(
struct ProxyTaskStruct *tkptr,
void *AstFunctionPtr,
char *DataPtr,
int DataLength
)

{
   register struct RequestStruct *rqptr;

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug)
   {
      fprintf (stdout, "ProxyWriteRaw() %d %d %d\n",
              tkptr, DataPtr, DataLength);
      /** fprintf (stdout, "|%*.*s|\n", DataLength, DataLength, DataPtr); **/
   }

   /* get associated request (if any) */
   rqptr = tkptr->RequestPtr;

   if (tkptr->ProxyWriteRawAstFunctionPtr != NULL ||
       !DataLength)
   {
      tkptr->ProxyWriteIOsb.Status = SS$_BUGCHECK;
      tkptr->ProxyWriteIOsb.Count = 0;
      if (AstFunctionPtr != NULL) SysDclAst (AstFunctionPtr, tkptr);
      return (tkptr->ProxyWriteIOsb.Status);
   }
   tkptr->ProxyWriteRawAstFunctionPtr = AstFunctionPtr;
   tkptr->ProxyWriteRawDataPtr = DataPtr;
   tkptr->ProxyWriteRawDataLength = DataLength;

   if (rqptr->WatchItem &&
       (WatchEnabled & WATCH_NETWORK_OCTETS))
   {
      WatchThis (rqptr, FI_LI, WATCH_NETWORK,
                 "WRITE !UL bytes", DataLength);
      WatchDataDump (DataPtr, DataLength);
   }

   if (AstFunctionPtr == NULL)
   {
      /***************/
      /* blocking IO */
      /***************/

      status = sys$qiow (0, tkptr->ProxyChannel,
                         IO$_WRITEVBLK, &tkptr->ProxyWriteIOsb, 0, 0,
                         DataPtr, DataLength, 0, 0, 0, 0);
      if (Debug)
         fprintf (stdout, "sys$qiow() %%X%08.08X %%X%08.08X %d\n",
                  status, tkptr->ProxyWriteIOsb.Status,
                  tkptr->ProxyWriteIOsb.Count);
   }
   else
   {
      /*******************/
      /* non-blocking IO */
      /*******************/

      status = sys$qio (0, tkptr->ProxyChannel,
                        IO$_WRITEVBLK, &tkptr->ProxyWriteIOsb,
                        &ProxyWriteRawAst, tkptr,
                        DataPtr, DataLength, 0, 0, 0, 0);
      if (Debug) fprintf (stdout, "sys$qio() %%%08.08X\n", status);
   }

   /****************/
   /* check status */
   /****************/

   if (VMSok (status)) return (status);

   /* if resource wait enabled the only quota not waited for is ASTLM */
   if (status == SS$_EXQUOTA)
      ErrorExitVmsStatus (status, "sys$qio()", FI_LI);

   /* write failed, call AST explicitly, status in the IOsb */
   tkptr->ProxyWriteIOsb.Status = status;
   tkptr->ProxyWriteIOsb.Count = 0;
   SysDclAst (ProxyWriteRawAst, tkptr);
   return (status);
}

/*****************************************************************************/
/*
AST from ProxyWriteRaw().  Call the AST function.
*/ 

ProxyWriteRawAst (struct ProxyTaskStruct *tkptr)

{
   register struct RequestStruct *rqptr;

   int  status;
   void (*AstFunctionPtr)(struct ProxyTaskStruct*);

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "ProxyWriteRawAst() %%X%08.08X %d\n",
               tkptr->ProxyWriteIOsb.Status, tkptr->ProxyWriteIOsb.Count);

   /* get associated request (if any) */
   rqptr = tkptr->RequestPtr;

   if (tkptr->WatchItem &&
       (WatchEnabled & WATCH_NETWORK))
   {
      if (VMSnok(tkptr->ProxyWriteIOsb.Status))
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_NETWORK,
                    "WRITE %X!8XL %!%M",
                    tkptr->ProxyWriteIOsb.Status,
                    tkptr->ProxyWriteIOsb.Status);
      else
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_NETWORK,
                    "WRITE %X!8XL !UL bytes",
                    tkptr->ProxyWriteIOsb.Status,
                    tkptr->ProxyWriteIOsb.Count);
   }

   if (VMSok (tkptr->ProxyWriteIOsb.Status))
      tkptr->BytesRawTx += tkptr->ProxyWriteIOsb.Count;

   tkptr->ProxyWriteRawDataPtr = tkptr->ProxyWriteRawDataLength = 0;
   if (tkptr->ProxyWriteRawAstFunctionPtr == NULL) return;
   AstFunctionPtr = tkptr->ProxyWriteRawAstFunctionPtr;
   tkptr->ProxyWriteRawAstFunctionPtr = NULL;
   (*AstFunctionPtr)(tkptr);
}

/*****************************************************************************/
/*
Queue up a read from the proxied server over the network. If 'AstFunctionPtr' 
is zero then no I/O completion AST routine is called.  If it is non-zero then 
the function pointed to by the parameter is called when the network write 
completes.

Explicitly declares any AST routine if an error occurs. The calling function
must not do any error recovery if an AST routine has been supplied but the
associated AST routine must!  If an AST was not supplied then the return
status can be checked.
*/ 

int ProxyReadRaw
(
struct ProxyTaskStruct *tkptr,
void *AstFunctionPtr,
char *DataPtr,
int DataSize
)
{
   register struct RequestStruct *rqptr;

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "ProxyReadRaw() %d %d %d\n", tkptr, DataPtr, DataSize);

   /* get associated request (if any) */
   rqptr = tkptr->RequestPtr;

   if (tkptr->ProxyReadRawAstFunctionPtr != NULL)
   {
      tkptr->ProxyReadIOsb.Status = SS$_BUGCHECK;
      tkptr->ProxyReadIOsb.Count = 0;
      if (AstFunctionPtr != NULL) SysDclAst (AstFunctionPtr, tkptr);
      return (tkptr->ProxyReadIOsb.Status);
   }
   tkptr->ProxyReadRawAstFunctionPtr = AstFunctionPtr;
   tkptr->ProxyReadRawDataPtr = DataPtr;
   tkptr->ProxyReadRawDataSize = DataSize;

   if (rqptr->WatchItem &&
       (WatchEnabled & WATCH_NETWORK_OCTETS))
      WatchThis (rqptr, FI_LI, WATCH_NETWORK,
                 "READ !UL bytes max", DataSize);

   if (AstFunctionPtr == NULL)
   {
      /***************/
      /* blocking IO */
      /***************/

      status = sys$qiow (0, tkptr->ProxyChannel,
                         IO$_READVBLK, &tkptr->ProxyReadIOsb, 0, 0,
                         DataPtr, DataSize, 0, 0, 0, 0);
      if (Debug)
         fprintf (stdout, "sys$qiow() %%X%08.08X %%X%08.08X %d\n",
                  status, tkptr->ProxyReadIOsb.Status,
                  tkptr->ProxyReadIOsb.Count);
   }
   else
   {
      /*******************/
      /* non-blocking IO */
      /*******************/

      status = sys$qio (0, tkptr->ProxyChannel,
                        IO$_READVBLK, &tkptr->ProxyReadIOsb,
                        &ProxyReadRawAst, tkptr,
                        DataPtr, DataSize, 0, 0, 0, 0);
      if (Debug) fprintf (stdout, "sys$qio() %%X%08.08X\n", status);
   }

   /****************/
   /* check status */
   /****************/

   if (VMSok (status)) return (status);

   /* with resource wait enabled the only quota not waited for is ASTLM */
   if (status == SS$_EXQUOTA)
      ErrorExitVmsStatus (status, "sys$qio()", FI_LI);

   /* queuing of read failed, call AST explicitly, status in the IOsb */
   tkptr->ProxyReadIOsb.Status = status;
   tkptr->ProxyReadIOsb.Count = 0;
   SysDclAst (ProxyReadRawAst, tkptr);
   return (status);
}

/*****************************************************************************/
/*
AST from ProxyReadRaw().  Call the AST function.
*/ 

ProxyReadRawAst (struct ProxyTaskStruct *tkptr)

{
   register struct RequestStruct *rqptr;

   int  status;
   void (*AstFunctionPtr)(struct ProxyTaskStruct*);

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "ProxyReadRawAst() %%X%08.08X %d\n",
               tkptr->ProxyReadIOsb.Status, tkptr->ProxyReadIOsb.Count);

   /* get associated request (if any) */
   rqptr = tkptr->RequestPtr;

   if (tkptr->WatchItem)
   {
      if ((WatchEnabled & WATCH_NETWORK) ||
          (WatchEnabled & WATCH_NETWORK_OCTETS))
      {
         if (VMSok(tkptr->ProxyReadIOsb.Status))
         {
            WatchThis (tkptr->RequestPtr, FI_LI, WATCH_NETWORK,
                       "READ %X!8XL !UL bytes",
                       tkptr->ProxyReadIOsb.Status,
                       tkptr->ProxyReadIOsb.Count);

            if (WatchEnabled & WATCH_NETWORK_OCTETS)
               WatchDataDump (tkptr->ProxyReadRawDataPtr,
                              tkptr->ProxyReadIOsb.Count);
         }
         else
            WatchThis (tkptr->RequestPtr, FI_LI, WATCH_NETWORK,
                       "READ %X!8XL %!%M",
                       tkptr->ProxyReadIOsb.Status,
                       tkptr->ProxyReadIOsb.Status);
      }
   }

   if (VMSok (tkptr->ProxyReadIOsb.Status))
   {
      tkptr->BytesRawRx += tkptr->ProxyReadIOsb.Count;
      /* zero bytes with a normal status is a definite no-no (TGV-Multinet) */
      if (!tkptr->ProxyReadIOsb.Count) tkptr->ProxyReadIOsb.Status = SS$_ABORT;
   }

   tkptr->ProxyReadRawDataPtr = tkptr->ProxyReadRawDataSize = 0;
   if (tkptr->ProxyReadRawAstFunctionPtr == NULL) return;
   AstFunctionPtr = tkptr->ProxyReadRawAstFunctionPtr;
   tkptr->ProxyReadRawAstFunctionPtr = NULL;
   (*AstFunctionPtr)(tkptr);
}

/****************************************************************************/
/*
Just shut the socket down, bang!
*/

int ProxyCloseSocket (struct ProxyTaskStruct *tkptr)

{
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyCloseSocket() %d\n", tkptr);

   if (!tkptr->ProxyChannel) return (SS$_NORMAL);

   status = sys$dassgn (tkptr->ProxyChannel);
   if (Debug) fprintf (stdout, "sys$dassgn() %%X%08.08X\n", status);
   tkptr->ProxyChannel = 0;

   if (tkptr->WatchItem &&
       (WatchEnabled & WATCH_PROXY))
   {
      if (VMSok(status))
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY,
                    "CLOSE !AZ:!UL",
                    tkptr->RequestHostName, tkptr->RequestPort); 
      else
         WatchThis (tkptr->RequestPtr, FI_LI, WATCH_PROXY,
                    "CLOSE !AZ:!UL %X!8XL %!%M",
                    tkptr->RequestHostName, tkptr->RequestPort,
                    status, status);
   }

   return (status);
}

/****************************************************************************/

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                