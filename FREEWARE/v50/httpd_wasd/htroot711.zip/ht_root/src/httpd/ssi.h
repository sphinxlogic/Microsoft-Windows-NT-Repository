/*****************************************************************************/
/*
                                  SSI.h
*/
/*****************************************************************************/

#ifndef SSI_H_LOADED
#define SSI_H_LOADED 1

#include "wasd.h"

/* essentially depth of if-else-endif nesting */
#define SSI_MAX_FLOW_CONTROL 8

/* default size of sys$get() buffer for SSI files (if xab$w_lrl == 0) */
#define SSI_DEFAULT_USZ 1024

/* processing buffer limits (this is not the sys$get() buffer!) */
#define SSI_DEFAULT_STATEMENT_SIZE   1024
#define SSI_MAX_STATEMENT_SIZE      32767  /* somewhat arbitrary! */

#define SSI_INCLUDE_PART_MAX 63

/**************/
/* structures */
/**************/

struct SsiVarStruct
{
   struct  ListEntryStruct  SsiVarList;
   int  NameLength,
        Size,
        ValueLength;
   char  *NamePtr,
         *ValuePtr;
   char  Data[1];
};

struct SsiTaskStruct
{
   struct ListEntryStruct  SsiTaskList;

   struct SsiTaskStruct  *ParentDocumentTaskPtr,
                         *RootDocumentTaskPtr;

   boolean  /* access to be expressed at "1st", "2nd", etc. */
            AccessOrdinal,
            /* SYSUAF authenticated user has been checked to have access */
            AuthVmsUserHasAccess,
            /* each SSI directive is in a single record */
            FileScrunched,
            /* indexed by 'FlowControlIndex', flow has executed */
            FlowControlHasExecuted [SSI_MAX_FLOW_CONTROL],
            /* indexed by 'FlowControlIndex', flow is executing */
            FlowControlIsExecuting [SSI_MAX_FLOW_CONTROL],
            /* currently inside an "<--#ssi" statement */
            InsideSsiStatement,
            /* OSU SSI? (detected via "OSU" in content description) */
            OsuCompliant,
            /* record format is fixed or undefined (don't add newlines) */
            RecordFormatFixed,
            /* output occured in flow control (for carriage-control) */
            PageHasBeenOutput,
            /* stop processing the virtual document */
            StopProcessing,
            /* suppress blank lines result of flow control directive lines */
            SuppressLine,
            /* OSU-specific, tag verification */
            TagVerify,
            /* a variable has been output (for carriage-control) */
            TraceHasBeenOutput,
            /* trace on or off */
            TraceState,
            /* for SYSUAF-authenticated user */
            VmsUserHasAccess;

   int  /* number of time file accessed */
        AccessCount,
        /* status returned from sys$create() */
        AccessCreateStatus,
        /* attempt to make behaviour backward compatible */
        ComplianceLevel,
        /* */
        FileDetailsItem,
        /* */
        FileNameLength,
        /* line number currently being parsed (for error information) */
        LineNumber,
        /* index into flow-control nesting arrays */
        FlowControlIndex,
        /* buffer for logical value */
        OutputBufferEscapeHtml,
        /* note when a search-list has been searched for the file */
        SearchListCount,
        /* size of SSI statement buffer :^) */
        StatementBufferSize,
        /* line number where current directive began */
        StatementLineNumber,
        /* length of SSI statement ;^) */
        StatementLength,
        /* buffer for most recent task status */
        TaskStatusBuffer;
        
   int  /* indexed by 'FlowControlIndex', series of flow control states */
        FlowControlState [SSI_MAX_FLOW_CONTROL];

   unsigned long  /* stores the latest RDT of files during "#modified" */
                  LastModifiedBinaryTime [2];

   char  /* scratch space */
         AccessSinceText [128],
         /* OSU-compliant #include part for current document */
         CurrentPart [SSI_INCLUDE_PART_MAX+1],
         /* SSI file name ;^) */
         FileName [ODS_MAX_FILE_NAME_LENGTH+1],
         /* OSU-compliant #include part for about-to-be included document */
         IncludePart [SSI_INCLUDE_PART_MAX+1],
         /* for #include, etc., file names */
         ScratchFileName [ODS_MAX_FILE_NAME_LENGTH+1],
         /* scratch space to hold a format string */
         FormatString [64],
         /* result of sys$parse(), values from, #include, #created, etc. */
         TheFileNameVar [ODS_MAX_FILE_NAME_LENGTH+1];

   char  /* points to the list of CGI variables */
         *CgiBufferPtr,
         /* string containing document depth number */
         *DocumentDepthPtr,
         /* root of document URI */
         *DocumentRootPtr,
         /* message string when generating an SSI error */
         *ErrMsgPtr,
         /* current character position when parsing lines */
         *LineParsePtr,
         /* pointer to storage allocated for size format string */
         *SizeFmtPtr,
         /* dynamically allocated buffer for SSI statements */
         *StatementBuffer,
         /* current character position in SSI statement buffer */
         *StatementPtr,
         /* pointer to storage allocated for time format string */
         *TimeFmtPtr;
                                    
   /* structure for ACP info */
   struct FileAcpStruct  FileAcpData;

   /* structures for file access */
   struct OdsStruct  FileOds,
                     DetailsOds,
                     AccessOds;

   /* access counter does not need to be ODS-5 aware (no NAM block) */
   struct FAB  AccessFab;
   struct RAB  AccessRab;
   struct XABDAT  AccessXabDat;
   struct XABPRO  AccessXabPro;

   /* pointer to function, used for specifying the next task */
   void (*AccessAstFunctionPtr)(struct RequestStruct*);
   void (*NextTaskFunction)(struct RequestStruct*);
   void (*FileOpenErrorFunction)(struct RequestStruct*);

   /* user variable list */
   struct ListHeadStruct  SsiVarList;
};

/***********************/
/* function prototypes */
/***********************/

SsiAccessesConnectAst (struct RAB*);
SsiAccessesFileClosed (struct FAB*);
SsiAccessesGetAst (struct RAB*);
SsiAccessesOpen (struct RequestStruct*);
SsiAccessesOutput (struct RequestStruct*);
SsiAccessesParseAst (struct FAB*);
SsiAccessesUpdateAst (struct RAB*);
SsiAuthorizationAst (struct RequestStruct*);
SsiBegin (struct RequestStruct*, void*, void*, char*, boolean);
SsiClosed (struct FAB*);
SsiConnectAst (struct RAB*);
SsiDoAccesses (struct RequestStruct*);
SsiDoDcl (struct RequestStruct*);
SsiDoDir (struct RequestStruct*);
SsiDoEcho (struct RequestStruct*);
SsiDoElif (struct RequestStruct*);
SsiDoElse (struct RequestStruct*);
SsiDoEnd (struct RequestStruct*);
SsiDoEndif (struct RequestStruct*);
SsiDoIf (struct RequestStruct*);
SsiDoInclude (struct RequestStruct*);
SsiDoPrintEnv (struct RequestStruct*);
SsiDoSet (struct RequestStruct*);
SsiDoTrace (struct RequestStruct*);
SsiFileDetails (struct RequestStruct*, int);
SsiFileDetailsParseAst (struct FAB*);
SsiFileDetailsAcpInfoAst (struct RequestStruct*);
SsiGetFileSpec (struct RequestStruct*, char*, char*, int);
SsiIncludeError (struct RequestStruct*);
SsiNextRecord (struct RequestStruct*);
SsiNextRecordAst (struct RAB*);
SsiOpenAst (struct FAB*);
SsiParse (struct RequestStruct*);
SsiParseLine (struct RequestStruct*);
SsiProblem (struct RequestStruct*, ...);
SsiStatement (struct RequestStruct*);
SsiTraceGetVar (struct RequestStruct*, char*, char*);
SsiTraceLine (struct RequestStruct*);
SsiTraceSetVar (struct RequestStruct*, char*, char*);
char* SsiGetVar (struct RequestStruct*, char*, char*, boolean);
char* SsiGetCgiVar (struct RequestStruct*, char*);
char* SsiGetServerVar (struct RequestStruct*, char*, char*);
char* SsiGetUserVar (struct RequestStruct*, char*);
int SsiTimeString (struct RequestStruct*, unsigned long*, char*, char*, int);

#endif /* SSI_H_LOADED */

/*****************************************************************************/
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  