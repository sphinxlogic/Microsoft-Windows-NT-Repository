/*****************************************************************************/
/*
                                Config.c

This module performs three functions.

  1.  It reads the HTTPD configuration file, converting the directives
      into internal representations.

  2.  Provides functions, accessed by other modules, returning the
      original directive information as appropriate.

  3.  Provides HTML form-based configuration and reports.

Configuration can only be performed at server startup.  To reset the 
configuration the server must be restarted.

WASD HTTPd Configuration is a relevant subset of the CERN configuration 
directives (sort-of, well it started that way anyhow!)  Although there are
some  differences (beware!) the CERN documentation can be consulted for a
general discussion of the purpose and functioning some of these directives. 

The file formats may be IN ONE OF TWO possible formats (not mixed).  The
older format contains one directive at the start of a line, followed by a
mandatory parameter.  The newer format (in part to support forms-based
configuration) has the directive contained within square brackets (e.g.
"[accept]") followed on the same line, or by one or more lines containing
comments, containing parameter information, or empty.  The directive applies
to all lines following up until another directive (square bracket in column
one) is encountered.

DIRECTIVES
----------

  o  Accept             <host/domain>
  o  ActivityDays       <integer>
  o  AddType            <suffix> <content-type> -|</script> [<description>]
  o  AddIcon            <URL> <alternative-text> <content-type-template>
  o  AddDirIcon         <URL> <alternative-text>
  o  AddBlankIcon       <URL> <alternative-text>
  o  AddUnknownIcon     <URL> <alternative-text>
  o  AddParentIcon      <URL> <alternative-text>
  o  AuthBasic          DISABLED | ENABLED
  o  AuthCacheMinutes   <integer>
  o  AuthDigest         DISABLED | ENABLED
  o  AuthDigestGetLife  <integer>
  o  AuthDigestPutLife  <integer>
  o  AuthFailureLimit   <integer>
  o  AuthRevalidateUserMinutes   <integer>
  o  AuthRevalidateLoginCookie   DISABLED | ENABLED
  o  BufferSizeDclCgiPlusIn      <integer>
  o  BufferSizeDclCommand        <integer>
  o  BufferSizeDclOutput         <integer>
  o  BufferSizeNetRead           <integer>
  o  BufferSizeNetWrite          <integer>
  o  Busy               <integer>
  o  Cache              DISABLED | ENABLED
  o  CacheChunkKBytes   <integer>
  o  CacheEntriesMax    <integer>
  o  CacheFileKBytesMax <integer>
  o  CacheFrequentHits      <integer>
  o  CacheFrequentSeconds   <integer>
  o  CacheHashTableEntries  <integer>
  o  CacheTotalKBytesMax    <integer>
  o  CacheValidateSeconds   <integer>
  o  CgiStrictOutput    DISABLED | ENABLED
  o  CharsetDefault     <string>
  o  DclCgiPlusLifeTime <integer>
  o  DclCleanupScratchMinutesMax      <integer>
  o  DclCleanupScratchMinutesOld      <integer>
  o  DclDetachProcess   DISABLED | ENABLED
  o  DclDetachProcessPriority         <string>
  o  DclGatewayBg       DISABLED | ENABLED
  o  DclHardLimit       <integer>
  o  DclScriptRunTime   <string>
  o  DclSoftLimit       <integer>
  o  DclSpawnAuthPriv   DISABLED | ENABLED
  o  DclZombieLifeTime  <integer>
  o  DECnetReuseLifeTime    <integer>
  o  DECnetConnectListMax   <integer>
  o  DirAccess          DISABLED | ENABLED | SELECTIVE
  o  DirBodyTag         <string>
  o  DirDescription     <integer>
  o  DirLayout          <string>
  o  DirMetaInfo        DISABLED | ENABLED
  o  DirOwner           DISABLED | ENABLED
  o  DirPreExpired      DISABLED | ENABLED
  o  DirReadMe          DISABLED | TOP | BOTTOM
  o  DirReadMeFile      <file.suffix>
  o  DirNoImpliedWildcard   DISABLED | ENABLED
  o  DirNoPrivIgnore    DISABLED | ENABLED
  o  DirWildcard        DISABLED | ENABLED
  o  DNSLookup          DISABLED | ENABLED
  o  ErrorRecommend     DISABLED | ENABLED
  o  ErrorReportPath    <path-to-report>
  o  Logging            DISABLED | ENABLED
  o  LogExcludeHosts    <string>
  o  LogFile            <string>
  o  LogFormat          <string>
  o  LogNaming          <string>
  o  LogPeriod          <string>
  o  LogPerService                    DISABLED | ENABLED
  o  LogPerServiceHostOnly            DISABLED | ENABLED
  o  MapUserNameCacheEntries          <integer>
  o  Monitor            DISABLED | ENABLED
  o  OpcomAdmin         DISABLED | ENABLED
  o  OpcomAuthorization DISABLED | ENABLED
  o  OpcomControl       DISABLED | ENABLED
  o  OpcomProxyMaint    DISABLED | ENABLED
  o  OpcomTarget        <string>
  o  PersonaCacheEntries              <integer>
  o  Port               <integer>
  o  ProxyAddForwardedBy              DISABLED | ENABLED
  o  ProxyCache                       DISABLED | ENABLED
  o  ProxyCacheDeviceCheckMinutes     <integer>
  o  ProxyCacheDeviceDirOrg           flat256 | 64x64
  o  ProxyCacheFileKBytesMax          <integer>
  o  ProxyCacheMaxPercent             <integer>
  o  ProxyCachePurgeList              <string>
  o  ProxyCacheReducePercent          <integer>
  o  ProxyCacheReloadList             <string>
  o  ProxyCacheRoutineHourOfDay       <integer>
  o  ProxyHostCachePurgeHours         <integer>
  o  ProxyHostLookupRetryCount        <integer>
  o  ProxyReportCacheLog              DISABLED | ENABLED
  o  ProxyReportLog                   DISABLED | ENABLED
  o  ProxyServing                     DISABLED | ENABLED
  o  PutMaxKbytes       <integer>
  o  Reject             <host/domain>
  o  ReportBasicOnly    DISABLED | ENABLED
  o  ReportMetaInfo     DISABLED | ENABLED
  o  RequestHistory     <integer>
  o  Scripting          DISABLED | ENABLED
  o  SearchScript       <path-to-search-script>
  o  SearchScriptExclude              <string>
  o  ServerAdmin        <string>
  o  ServerAdminBodyTag               <string>
  o  ServerReportBodyTag              <string>
  o  ServerSignature    DISABLED | ENABLED
  o  Service            <string>
  o  ServiceListenBacklog             <integer>
  o  ServiceNotFoundURL <string>
  o  Ssi | Shtml                      DISABLED | ENABLED
  o  SsiAccesses | ShtmlAccesses      DISABLED | ENABLED
  o  SsiExec | ShtmlExec              DISABLED | ENABLED
  o  StreamLf           <integer>
  o  TimeoutInput       <integer>
  o  TimeoutKeepAlive   <integer>
  o  TimeoutNoProgress  <integer>
  o  TimeoutOutput      <integer>
  o  Track              DISABLED | ENABLED
  o  TrackMultiSession  DISABLED | ENABLED
  o  TrackDomain        <string>
  o  Welcome            <file.suffix>


VERSION HISTORY
---------------
06-DEC-2000  MGD  [DclCleanupScratchMinutes...]
01-NOV-2000  MGD  [DclDetachProcessPriority]
02-OCT-2000  MGD  [DclDetachProcess], [PersonaCacheEntries]
01-SEP-2000  MGD  [AuthRequestPath] (pre-7.1 compatibility)
19-AUG-2000  MGD  [DclGatewayBg] to enable raw socket,
                  [DclFullRequest] removed (HTTPD_DCL_FULL_REQUEST environment
                  variable can be defined for backward compatbility)
15-JUN-2000  MGD  [ServiceListenBacklog] for TCP/IP v5.0 or greater
06-MAY-2000  MGD  reorganise configuration data structures,
                  allow continuation lines ('\') in comma lists,
                  [AuthRevalidateLoginCookie],
                  [Track...]
07-APR-2000  MGD  [ServerAdmin], [ServerSignature], [CgiStrictOutput],
                  [DirMetaInfo], [Scripting], [ReportBasicOnly] and
                  [ReportMetaInfo] (which replaces [IncludedCommentedInfo]
                  and [ErrorSourceInfo]).
04-MAR-2000  MGD  use NetWriteFaol(), et.al.
16-FEB-2000  MGD  [SearchScriptExclude] directive,
                  [LogPerServiceHostOnly] directive,
                  allow wildcards in content-type file suffix specifications
02-JAN-2000  MGD  [Opcom...] directives,
                  config file opened via ODS module
30-OCT-1999  MGD  include IP address for services in ConfigReportNow(),
                  'Buffer...', 'MapUserNameCacheEntries', 'ServiceNotFoundURL',
                  'Timeout...' directives (with backward compatibility),
                  increase buffer space for ConfigCommaList()
03-MAR-1999  MGD  improve [AddType] and [AddIcon] directive checking
18-JAN-1999  MGD  [Proxy...] configuration parameters
                  bugfix; ignore empty lines (even with spaces in them!)
17-OCT-1998  MGD  [ErrorReportPath] added,
                  [Search] changed to [SearchScript],
                  [StreamLfPaths] obsoleted in favour of SET mapping rule
29-SEP-1998  MGD  [AddType] now allows "text/html; charset=ISO8859-5",
                  [CharsetDefault] text and server character set
27-AUG-1998  MGD  generic ConfigSetCommaList(),
                  add [AuthRevalidateUserMinutes], [LogExcludeHosts],
                      [DECnetReuseLifeTime], [DECnetConnectListMax],
                      [StreamLfPaths]
08-AUG-1998  MGD  add [DirNoImpliedWildcard]
17-JUN-1998  MGD  add [LogNaming], [LogPerService]
28-FEB-1998  MGD  improved icon handling efficiency
07-FEB-1998  MGD  v5.0 hash table for content-type suffix and icon searches,
                  default content type (for unknowns) configurable,
                  HTTP protocol name in [service] (for SSL),
                  [DirDescription] changed from boolean to integer
05-OCT-1997  MGD  cache parameters,
                  DCL script run-time parameter,
                  additional logging parameters
09-AUG-1997  MGD  v4.4 retired "ErrorInfo", "ErrorSysAdmin" (now in messages)
                  and AuthVMS (now /SYSUAF qualifier);  introduced
                  "DirDescription", "DirNoPrivIgnore", "ErrorSourceInfo",
                  bugfix; memory leak in file-based report and revise
01-AUG-1997  MGD  v4.3 activity number of days, DCL supply full request,
                  bugfix; annoying repeated instances of "unknown" content type
01-JUN-1997  MGD  v4.2 required additional DCL/scripting parameters
01-FEB-1997  MGD  HTTPd version 4;
                  major changes for form-based config;
                  added error message URLs
01-OCT-1996  MGD  HTML configuration report
01-AUG-1996  MGD  StreamLF conversion directive;
                  AuthBasic and AuthDigest directives;
12-APR-1996  MGD  file record/binary now determined by record format
                  (has removed the need of the text/binary, etc., in "AddType")
01-DEC-1995  MGD  HTTPd version 3
27-SEP-1995  MGD  added auto-scripting funtionality
07-AUG-1995  MGD  added support for VMS-style directory listing
16-JUN-1995  MGD  file contents description in 'AddType' (also see DIR.C)
20-DEC-1994  MGD  developed for multi-threaded HTTP daemon
*/
/*****************************************************************************/

/* standard C header files */
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* VMS related header files */
#include <opcdef.h>
#include <rmsdef.h>
#include <ssdef.h>
#include <stsdef.h>

/* application related header */
#include "wasd.h"

#define WASD_MODULE "CONFIG"

/******************/
/* global storage */
/******************/

struct ConfigStruct  Config;

struct OpcomStruct {
   int  Number;
   char  *Name;
} ConfigOpcomTarget [] = {
   0, "none",
   OPC$M_NM_CARDS, "CARDS",
   OPC$M_NM_CENTRL, "CENTRAL",
   OPC$M_NM_CLUSTER, "CLUSTER",
   OPC$M_NM_DEVICE, "DEVICE",
   OPC$M_NM_DISKS, "DISKS",
   OPC$M_NM_NTWORK, "NETWORK",
   OPC$M_NM_PRINT, "PRINT",
   OPC$M_NM_SECURITY, "SECURITY",
   OPC$M_NM_TAPES, "TAPES",
   OPC$M_NM_OPER1, "OPER1",
   OPC$M_NM_OPER2, "OPER2",
   OPC$M_NM_OPER3, "OPER3",
   OPC$M_NM_OPER4, "OPER4",
   OPC$M_NM_OPER5, "OPER5",
   OPC$M_NM_OPER6, "OPER6",
   OPC$M_NM_OPER7, "OPER7",
   OPC$M_NM_OPER8, "OPER8",
   OPC$M_NM_OPER9, "OPER9",
   OPC$M_NM_OPER10, "OPER10",
   OPC$M_NM_OPER11, "OPER11",
   OPC$M_NM_OPER12, "OPER12",
   -1, NULL
};

char  ConfigContentTypeBlank [] = "x-internal/blank",
      ConfigContentTypeDir [] = "x-internal/directory",
      ConfigContentTypeIsMap [] = "text/x-ismap",
      ConfigContentTypeMenu [] = "text/x-menu",
      ConfigContentTypeParent [] = "x-internal/parent",
      ConfigContentTypeSsi [] = "text/x-shtml",
      ConfigContentTypeUnknown [] = "x-internal/unknown",
      ConfigDefaultFileContentType [] = "application/octet-stream",
      ConfigStringOverflow [] = "*ERROR* string overflow";

char  *ConfigBlankIconPtr,
      *ConfigDirIconPtr,
      *ConfigParentIconPtr,
      *ConfigUnknownIconPtr;

/********************/
/* external storage */
/********************/

#ifdef DBUG
extern boolean Debug;
#else
#define Debug 0 
#endif

extern int  DclCgiPlusInSize,
            DclSysCommandSize,
            DclSysOutputSize,
            MapUrlUserNameCacheEntries,
            NetReadBufferSize,
            OpcomMessages,
            OpcomTarget,
            OutputBufferSize,
            PersonaCacheEntries,
            ServiceCount,
            ServiceLoadFromConfigFile;

extern char  *CliAcceptHostsPtr,
             *CliRejectHostsPtr;

extern char  ServerHostPort[],
             SoftwareID[],
             TimeGmtString[],
             Utility[];

extern struct MsgStruct  Msgs;
extern struct ServiceLoadStruct  ServiceLoad;

/*****************************************************************************/
/*
Open the configuration file defined by the logical name HTTPD$CONFIG.  Read 
each line, passing to the appropriate interpretation function according to the 
directive on the line.  Close the file.  Function is either called before
AST-driven  processing or called at AST delivery level which makes processing
atomic.  Allow 32 extra characters on line buffer and parameter allocated
memory for concatenating additional string.
*/

Configure (struct ConfigStruct *cfptr)

{
#  define PARAMETER_ELBOW_ROOM 32

   register char  *cptr, *sptr, *zptr;

   boolean  DebugBuffer,
            BracketDirectives,
            EquateDirectives;
   int  status,
        LineLength;
   void  *RequestPtrBuffer;
   char  Line [512 + PARAMETER_ELBOW_ROOM];
   struct OdsStruct  ConfigFileOds;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "Configure()\n");

   RequestPtrBuffer = cfptr->RequestPtr;
   memset (cfptr, 0, sizeof(struct ConfigStruct));
   cfptr->RequestPtr = RequestPtrBuffer;

   /* scripting is by default *enabled*! (for backward compatibility) */
   cfptr->cfScript.Enabled = true;
   cfptr->cfAuth.CacheMinutes =
      cfptr->cfAuth.RevalidateUserMinutes = 60;
   cfptr->cfAuth.FailureLimit = 10;
   cfptr->cfDir.PreExpired = PRE_EXPIRE_INDEX_OF;
   strcpy (cfptr->cfDir.DefaultLayout, DEFAULT_DIR_LAYOUT);
   cfptr->cfServer.AcceptHostsPtr =
      cfptr->cfContent.ContentInfoListHeadPtr =
      cfptr->cfContent.IconListHeadPtr =
      cfptr->cfLog.ExcludeHostsPtr =
      cfptr->cfServer.RejectHostsPtr = NULL;
   cfptr->cfContent.ContentInfoStructOverhead = sizeof(struct ContentInfoStruct);
   cfptr->cfContent.IconStructOverhead = sizeof(struct IconStruct);
   cfptr->cfContent.ContentTypeDefaultPtr = "";
   sys$gettim (&cfptr->LoadBinTime);

   BracketDirectives = EquateDirectives = false;

   /************************/
   /* open the config file */
   /************************/

   /* use SYSPRV to allow access to possibly protected file */
   EnableSysPrv();
   status = OdsOpenReadOnly (&ConfigFileOds, CONFIG_FILE_NAME);
   DisableSysPrv();
   if (VMSnok (status))
   {
      if (cfptr->RequestPtr)
      {
         ConfigReportProblem (cfptr, NULL, status);
         return;
      }
      else
         ErrorExitVmsStatus (status, CONFIG_FILE_NAME, FI_LI);
   }

   /* get the configuration file name and revision date and time */
   strcpy (cfptr->LoadFileName, ConfigFileOds.ResFileName);
   memcpy (&cfptr->RevBinTime,
           &ConfigFileOds.XabDat.xab$q_rdt,
           sizeof(cfptr->RevBinTime));

   /************************/
   /* read the config file */
   /************************/

#ifdef DBUG
   /* not interested anymore in seeing debug information for config load! */
   DebugBuffer = Debug;
   Debug = false;
#endif

   /* set up RAB buffers */
   ConfigFileOds.Rab.rab$l_ubf = Line;
   ConfigFileOds.Rab.rab$w_usz = sizeof(Line)-PARAMETER_ELBOW_ROOM-1;

   while (VMSok (status = sys$get (&ConfigFileOds.Rab, 0, 0)))
   {
      cfptr->LineNumber++;
      Line[LineLength = ConfigFileOds.Rab.rab$w_rsz] = '\0';
      if (Debug) fprintf (stdout, "Line %d |%s|\n", cfptr->LineNumber, Line);

      for (cptr = Line; ISLWS(*cptr); cptr++);

      /* if a blank or comment line, then ignore */
      if (!*cptr || *cptr == '!' || *cptr == '#') continue;

      if (Line[0] == '[')
      {
         if (EquateDirectives)
         {
            ConfigReportProblem (cfptr, "mixed directive formats", 0);
            break;
         }
         BracketDirectives = true;
         cptr++;
         zptr = (sptr = cfptr->DirectiveName) + sizeof(cfptr->DirectiveName);
         while (*cptr && *cptr != ']' && sptr < zptr) *sptr++ = *cptr++;
         if (sptr >= zptr)
         {
            ConfigReportProblem (cfptr, "missing closing bracket?", 0);
            continue;
         }
         *sptr = '\0';
         if (Debug)
            fprintf (stdout, "DirectiveName |%s|\n", cfptr->DirectiveName);
         if (*cptr) cptr++;
         while (*cptr && ISLWS(*cptr)) cptr++;
      }
      else
      if (!BracketDirectives)
      {
         EquateDirectives = true;
         zptr = (sptr = cfptr->DirectiveName) + sizeof(cfptr->DirectiveName);
         while (*cptr && !ISLWS(*cptr) && *cptr != '=' && sptr < zptr)
             *sptr++ = *cptr++;
         if (sptr >= zptr)
         {
            ConfigReportProblem (cfptr, "missing parameter");
            continue;
         }
         *sptr = '\0';
         while (*cptr && ISLWS(*cptr)) cptr++;
         if (!*cptr)
         {
            ConfigReportProblem (cfptr, "missing parameter", 0);
            continue;
         }
      }

      if (BracketDirectives && !*cptr) continue;

      if (strsame (cfptr->DirectiveName, "Accept", -1))
         ConfigSetCommaList (cfptr, cptr, &cfptr->cfServer.AcceptHostsPtr,
                                          &cfptr->cfServer.AcceptHostsLength);
      else
      if (strsame (cfptr->DirectiveName, "ActivityDays", -1))
         cfptr->cfMisc.ActivityNumberOfDays = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "AddType", -1))
         ConfigAddType (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "AddIcon", -1))
         ConfigAddIcon (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "AddBlankIcon", -1))
      {
         /* use up the PARAMETER_ELBOW_ROOM :^) */
         for (sptr = cptr; *sptr; sptr++);
         *sptr++ = ' ';
         strcpy (sptr, ConfigContentTypeBlank);
         ConfigAddIcon (cfptr, cptr);
      }
      else
      if (strsame (cfptr->DirectiveName, "AddDirIcon", -1))
      {
         /* use up the PARAMETER_ELBOW_ROOM :^) */
         for (sptr = cptr; *sptr; sptr++);
         *sptr++ = ' ';
         strcpy (sptr, ConfigContentTypeDir);
         ConfigAddIcon (cfptr, cptr);
      }
      else
      if (strsame (cfptr->DirectiveName, "AddParentIcon", -1))
      {
         /* use up the PARAMETER_ELBOW_ROOM :^) */
         for (sptr = cptr; *sptr; sptr++);
         *sptr++ = ' ';
         strcpy (sptr, ConfigContentTypeParent);
         ConfigAddIcon (cfptr, cptr);
      }
      else
      if (strsame (cfptr->DirectiveName, "AddUnknownIcon", -1))
      {
         /* use up the PARAMETER_ELBOW_ROOM :^) */
         for (sptr = cptr; *sptr; sptr++);
         *sptr++ = ' ';
         strcpy (sptr, ConfigContentTypeUnknown);
         ConfigAddIcon (cfptr, cptr);
      }
      else
      if (strsame (cfptr->DirectiveName, "AuthBasic", -1))
         cfptr->cfAuth.BasicEnabled = ConfigSetBoolean (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "AuthCacheMinutes", -1))
         cfptr->cfAuth.CacheMinutes = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "AuthDigestGetLife", -1))
         cfptr->cfAuth.DigestNonceGetLifeTime = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "AuthDigestPutLife", -1))
         cfptr->cfAuth.DigestNoncePutLifeTime = ConfigSetInteger (cfptr, cptr);
      else
      /* "AuthDigest" MUST come after other AuthDigests for obvious reasons */
      if (strsame (cfptr->DirectiveName, "AuthDigest", -1))
         cfptr->cfAuth.DigestEnabled = ConfigSetBoolean (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "AuthFailureLimit", -1))
         cfptr->cfAuth.FailureLimit = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "AuthRevalidateUserMinutes", -1))
         cfptr->cfAuth.RevalidateUserMinutes = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "AuthRevalidateLoginCookie", -1))
         cfptr->cfAuth.RevalidateLoginCookie = ConfigSetBoolean (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "BufferSizeDclCommand", -1))
         cfptr->cfBuffer.SizeDclCommand = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "BufferSizeDclOutput", -1))
         cfptr->cfBuffer.SizeDclOutput = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "BufferSizeDclCgiPlusIn", -1))
         cfptr->cfBuffer.SizeDclCgiPlusIn = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "BufferSizeNetRead", -1))
         cfptr->cfBuffer.SizeNetRead = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "BufferSizeNetWrite", -1))
         cfptr->cfBuffer.SizeNetWrite = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "Busy", -1))
         cfptr->cfServer.BusyLimit = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "CacheChunkKBytes", -1))
         cfptr->cfCache.ChunkKBytes = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "CacheEntriesMax", -1))
         cfptr->cfCache.EntriesMax = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "CacheFileKBytesMax", -1))
         cfptr->cfCache.FileKBytesMax = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "CacheFrequentHits", -1))
         cfptr->cfCache.FrequentHits = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "CacheFrequentSeconds", -1))
         cfptr->cfCache.FrequentSeconds = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "CacheHashTableEntries", -1))
         cfptr->cfCache.HashTableEntries = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "CacheTotalKBytesMax", -1))
         cfptr->cfCache.TotalKBytesMax = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "CacheValidateSeconds", -1))
         cfptr->cfCache.ValidateSeconds = ConfigSetInteger (cfptr, cptr);
      else
      /* "cache" must follow all the others for the obvious reason */
      if (strsame (cfptr->DirectiveName, "Cache", -1))
         cfptr->cfCache.Enabled = ConfigSetBoolean (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "CgiStrictOutput", -1))
         cfptr->cfScript.CgiStrictOutput = ConfigSetBoolean (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "CharsetDefault", -1))
         ConfigSetString (cfptr, cptr, cfptr->cfContent.CharsetDefault,
                                       sizeof(cfptr->cfContent.CharsetDefault));
      else
      if (strsame (cfptr->DirectiveName, "DclDetachProcess", -1))
         cfptr->cfScript.DetachProcess = ConfigSetBoolean (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "DclDetachProcessPriority", -1))
         ConfigSetString (cfptr, cptr, cfptr->cfScript.DetachProcessPriority,
                                 sizeof(cfptr->cfScript.DetachProcessPriority));
      else
      if (strsame (cfptr->DirectiveName, "DclGatewayBg", -1))
         cfptr->cfScript.GatewayBg = ConfigSetBoolean (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "DclHardLimit", -1))
         cfptr->cfScript.ScriptProcessHardLimit =
            ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "DclScriptRunTime", -1))
         ConfigSetScriptRunTime (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "DclSoftLimit", -1))
         cfptr->cfScript.ScriptProcessSoftLimit =
            ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "DclCgiPlusLifeTime", -1))
         cfptr->cfScript.CgiPlusLifeTime = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "DclCleanupScratchMinutesMax", -1))
         cfptr->cfScript.CleanupScratchMinutesMax =
            ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "DclCleanupScratchMinutesOld", -1))
         cfptr->cfScript.CleanupScratchMinutesOld =
            ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "DclZombieLifeTime", -1))
         cfptr->cfScript.ZombieLifeTime = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "DclSpawnAuthPriv", -1))
         cfptr->cfScript.SpawnAuthPriv = ConfigSetBoolean (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "DECnetReuseLifeTime", -1))
         cfptr->cfScript.DECnetReuseLifeTime = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "DECnetConnectListMax", -1))
         cfptr->cfScript.DECnetConnectListMax = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "DirAccess", -1))
         ConfigSetDirAccess (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "DirBodyTag", -1))
         ConfigSetString (cfptr, cptr,
                          cfptr->cfDir.BodyTag, sizeof(cfptr->cfDir.BodyTag));
      else
      if (strsame (cfptr->DirectiveName, "DirDescription", -1))
      {
         /*
            [DirDescription] boolean deprecated in v5.0, noow using
            integer [DirDescriptionLines], provide fallback behaviour.
         */
         if (ConfigSetBoolean (cfptr, cptr))
            cfptr->cfDir.DescriptionLines = 30;
         else
            cfptr->cfDir.DescriptionLines = 0;
      }
      else
      if (strsame (cfptr->DirectiveName, "DirDescriptionLines", -1))
         cfptr->cfDir.DescriptionLines = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "DirLayout", -1))
         ConfigSetString (cfptr, cptr,
                          cfptr->cfDir.DefaultLayout,
                          sizeof(cfptr->cfDir.DefaultLayout));
      else
      if (strsame (cfptr->DirectiveName, "DirMetaInfo", -1))
         cfptr->cfDir.MetaInfoEnabled = ConfigSetBoolean (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "DirOwner", -1))
         cfptr->cfDir.OwnerEnabled = ConfigSetBoolean (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "DirPreExpired", -1))
         cfptr->cfDir.PreExpired = ConfigSetBoolean (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "DirNoImpliedWildcard", -1))
         cfptr->cfDir.NoImpliedWildcard = ConfigSetBoolean (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "DirNoPrivIgnore", -1))
         cfptr->cfDir.NoPrivIgnore = ConfigSetBoolean (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "DirReadMeFile", -1))
         ConfigSetDirReadMeFile (cfptr, cptr);
      else
      /* "ReadMe" MUST come after the other ReadMes for obvious reasons */
      if (strsame (cfptr->DirectiveName, "DirReadMe", -1))
         ConfigSetDirReadMe (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "DirWildcard", -1))
         cfptr->cfDir.WildcardEnabled = ConfigSetBoolean (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "DNSLookup", -1))
         cfptr->cfMisc.DnsLookup = ConfigSetBoolean (cfptr, cptr);
      else
      /* "Recommend" for backward compatibility */
      if (strsame (cfptr->DirectiveName, "ErrorRecommend", -1) ||
          strsame (cfptr->DirectiveName, "Recommend", -1))
         cfptr->cfReport.ErrorRecommend = ConfigSetBoolean (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "ErrorReportPath", -1))
      {
         ConfigSetString (cfptr, cptr,
                          cfptr->cfReport.ErrorReportPath,
                          sizeof(cfptr->cfReport.ErrorReportPath));
         cfptr->cfReport.ErrorReportPathLength =
            strlen(cfptr->cfReport.ErrorReportPath);
      }
      else
      if (strsame (cfptr->DirectiveName, "Logging", -1))
         cfptr->cfLog.Enabled = ConfigSetBoolean (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "LogExcludeHosts", -1))
         ConfigSetCommaList (cfptr, cptr, &cfptr->cfLog.ExcludeHostsPtr,
                                          &cfptr->cfLog.ExcludeHostsLength);
      else
      if (strsame (cfptr->DirectiveName, "LogFile", -1))
         ConfigSetString (cfptr, cptr,
                          cfptr->cfLog.FileName, sizeof(cfptr->cfLog.FileName));
      else
      if (strsame (cfptr->DirectiveName, "LogFormat", -1))
         ConfigSetString (cfptr, cptr,
                          cfptr->cfLog.Format, sizeof(cfptr->cfLog.Format));
      else
      if (strsame (cfptr->DirectiveName, "LogNaming", -1))
         ConfigSetString (cfptr, cptr,
                          cfptr->cfLog.Naming, sizeof(cfptr->cfLog.Naming));
      else
      if (strsame (cfptr->DirectiveName, "LogPeriod", -1))
         ConfigSetString (cfptr, cptr,
                          cfptr->cfLog.Period, sizeof(cfptr->cfLog.Period));
      else
      if (strsame (cfptr->DirectiveName, "LogPerService", -1))
         cfptr->cfLog.PerService = ConfigSetBoolean (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "LogPerServiceHostOnly", -1))
         cfptr->cfLog.PerServiceHostOnly = ConfigSetBoolean (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "MapUserNameCacheEntries", -1))
         cfptr->cfMisc.MapUserNameCacheEntries = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "Monitor", -1))
         cfptr->cfMisc.MonitorEnabled = ConfigSetBoolean (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "OpcomTarget", -1) ||
          strsame (cfptr->DirectiveName, "OpcomAdmin", -1) ||
          strsame (cfptr->DirectiveName, "OpcomAuthorization", -1) ||
          strsame (cfptr->DirectiveName, "OpcomControl", -1) ||
          strsame (cfptr->DirectiveName, "OpcomHTTPd", -1) ||
          strsame (cfptr->DirectiveName, "OpcomProxyMaint", -1))
         ConfigSetOpcom (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "PersonaCacheEntries", -1))
         cfptr->cfMisc.PersonaCacheEntries = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "ProxyAddForwardedBy", -1))
         cfptr->cfProxy.AddForwardedByEnabled = ConfigSetBoolean (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "ProxyCache", -1))
         cfptr->cfProxy.CacheEnabled = ConfigSetBoolean (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "ProxyCacheDeviceCheckMinutes", -1))
         cfptr->cfProxy.CacheDeviceCheckMinutes = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "ProxyCacheDeviceDirOrg", -1))
      {
         if (strsame (cptr, "flat256", -1))
            cfptr->cfProxy.CacheDeviceDirOrg = PROXY_CACHE_DIR_ORG_FLAT256;
         else
         if (strsame (cptr, "64x64", -1))
            cfptr->cfProxy.CacheDeviceDirOrg = PROXY_CACHE_DIR_ORG_64X64;
         else
         {
            cfptr->cfProxy.CacheDeviceDirOrg = 0;
            ConfigReportProblem (cfptr, NULL, 0);
         }
      }
      else
      if (strsame (cfptr->DirectiveName, "ProxyCacheDeviceMaxPercent", -1))
         cfptr->cfProxy.CacheDeviceMaxPercent = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "ProxyCacheDevicePurgePercent", -1))
         cfptr->cfProxy.CacheDevicePurgePercent = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "ProxyCacheFileKBytesMax", -1))
         cfptr->cfProxy.CacheFileKBytesMax = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "ProxyCacheRoutineHourOfDay", -1))
         cfptr->cfProxy.CacheRoutineHourOfDay = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "ProxyCachePurgeList", -1))
         ConfigSetString (cfptr, cptr,
                          cfptr->cfProxy.CachePurgeList,
                          sizeof(cfptr->cfProxy.CachePurgeList));
      else
      if (strsame (cfptr->DirectiveName, "ProxyCacheReloadList", -1))
         ConfigSetString (cfptr, cptr,
                          cfptr->cfProxy.CacheReloadList,
                          sizeof(cfptr->cfProxy.CacheReloadList));
      else
      if (strsame (cfptr->DirectiveName, "ProxyHostCachePurgeHours", -1))
         cfptr->cfProxy.HostCachePurgeHours = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "ProxyHostLookupRetryCount", -1))
         cfptr->cfProxy.HostLookupRetryCount = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "ProxyReportCacheLog", -1))
         cfptr->cfProxy.ReportCacheLog = ConfigSetBoolean (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "ProxyReportLog", -1))
         cfptr->cfProxy.ReportLog = ConfigSetBoolean (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "ProxyServing", -1))
         cfptr->cfProxy.ServingEnabled = ConfigSetBoolean (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "Port", -1))
         cfptr->cfServer.DefaultPort = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "PutMaxKbytes", -1))
         cfptr->cfMisc.PutMaxKbytes = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "PutVersionLimit", -1))
         cfptr->cfMisc.PutVersionLimit = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "Reject", -1))
         ConfigSetCommaList (cfptr, cptr, &cfptr->cfServer.RejectHostsPtr,
                                          &cfptr->cfServer.RejectHostsLength);
      else
      if (strsame (cfptr->DirectiveName, "ReportBasicOnly", -1))
         cfptr->cfReport.BasicOnly = ConfigSetBoolean (cfptr, cptr);
      else
      /* "CommentedInfo" & "ErrorSourceInfo" for backward compatibility */
      if (strsame (cfptr->DirectiveName, "ReportMetaInfo", -1) ||
          strsame (cfptr->DirectiveName, "CommentedInfo", -1) ||
          strsame (cfptr->DirectiveName, "ErrorSourceInfo", -1))
         cfptr->cfReport.MetaInfoEnabled = ConfigSetBoolean (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "RequestHistory", -1))
         cfptr->cfMisc.RequestHistory = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "Scripting", -1))
         cfptr->cfScript.Enabled = ConfigSetBoolean (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "Search", -1) ||
          strsame (cfptr->DirectiveName, "SearchScript", -1))
      {
         ConfigSetString (cfptr, cptr,
                          cfptr->cfScript.DefaultSearch,
                          sizeof(cfptr->cfScript.DefaultSearch));
         cfptr->cfScript.DefaultSearchLength =
            strlen(cfptr->cfScript.DefaultSearch);
      }
      else
      if (strsame (cfptr->DirectiveName, "SearchScriptExclude", -1))
         ConfigSetCommaList (cfptr, cptr,
            &cfptr->cfScript.DefaultSearchExcludePtr,
            &cfptr->cfScript.DefaultSearchExcludeLength);
      else
      if (strsame (cfptr->DirectiveName, "ServerAdmin", -1))
         ConfigSetString (cfptr, cptr,
                          cfptr->cfServer.AdminEmail,
                          sizeof(cfptr->cfServer.AdminEmail));
      else
      if (strsame (cfptr->DirectiveName, "ServerAdminBodyTag", -1))
         ConfigSetString (cfptr, cptr,
                          cfptr->cfServer.AdminBodyTag,
                          sizeof(cfptr->cfServer.AdminBodyTag));
      else
      if (strsame (cfptr->DirectiveName, "ServerReportBodyTag", -1))
         ConfigSetString (cfptr, cptr,
                          cfptr->cfServer.ReportBodyTag,
                          sizeof(cfptr->cfServer.ReportBodyTag));
      else
      if (strsame (cfptr->DirectiveName, "ServerSignature", -1))
         cfptr->cfProxy.ServingEnabled = ConfigSetServerSignature (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "Service", -1))
         ConfigSetCommaList (cfptr, cptr, &cfptr->cfServer.ServicePtr,
                                          &cfptr->cfServer.ServiceLength);
      else
      if (strsame (cfptr->DirectiveName, "ServiceListenBacklog", -1))
         cfptr->cfServer.ListenBacklog = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "ServiceNotFoundURL", -1))
         ConfigSetString (cfptr, cptr,
                          cfptr->cfServer.ServiceNotFoundUrl,
                          sizeof(cfptr->cfServer.ServiceNotFoundUrl));
      else
      /* "ShtmlAccesses" for backward compatibility */
      if (strsame (cfptr->DirectiveName, "SSIAccesses", -1) ||
          strsame (cfptr->DirectiveName, "ShtmlAccesses", -1))
         cfptr->cfSsi.AccessesEnabled = ConfigSetBoolean (cfptr, cptr);
      else
      /* "ShtmlExec" for backward compatibility */
      if (strsame (cfptr->DirectiveName, "SSIExec", -1) ||
          strsame (cfptr->DirectiveName, "ShtmlExec", -1))
         cfptr->cfSsi.ExecEnabled = ConfigSetBoolean (cfptr, cptr);
      else
      /* "SSI" MUST come after the other SSIs for obvious reasons */
      /* "Shtml" for backward compatibility */
      if (strsame (cfptr->DirectiveName, "SSI", -1) ||
          strsame (cfptr->DirectiveName, "Shtml", -1))
         cfptr->cfSsi.Enabled = ConfigSetBoolean (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "StreamLF", -1))
         cfptr->cfMisc.StreamLfConversionMaxKbytes =
            ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "TimeoutInput", -1) ||
          strsame (cfptr->DirectiveName, "InputTimeout", -1))
         cfptr->cfTimeout.MinutesInput = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "TimeoutKeepAlive", -1) ||
          strsame (cfptr->DirectiveName, "KeepAliveTimeout", -1))
         cfptr->cfTimeout.SecondsKeepAlive = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "TimeoutNoProgress", -1))
         cfptr->cfTimeout.MinutesNoProgress = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "TimeoutOutput", -1) ||
          strsame (cfptr->DirectiveName, "OutputTimeout", -1))
         cfptr->cfTimeout.MinutesOutput = ConfigSetInteger (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "Track", -1))
         cfptr->cfTrack.Enabled = ConfigSetBoolean (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "TrackDomain", -1))
         ConfigSetString (cfptr, cptr,
                          cfptr->cfTrack.Domain, sizeof(cfptr->cfTrack.Domain));
      else
      if (strsame (cfptr->DirectiveName, "TrackMultiSession", -1))
         cfptr->cfTrack.MultiSession = ConfigSetBoolean (cfptr, cptr);
      else
      if (strsame (cfptr->DirectiveName, "Welcome", -1))
         ConfigSetWelcome (cfptr, cptr);
      else
         ConfigReportProblem (cfptr, "?", 0);
   }

   if (status == RMS$_EOF) status = SS$_NORMAL;

   /*************************/
   /* close the config file */
   /*************************/

   sys$close (&ConfigFileOds.Fab, 0, 0); 

   if (!cfptr->cfMisc.PutMaxKbytes)
      cfptr->cfMisc.PutMaxKbytes = PUT_DEFAULT_KBYTES_MAX;
   if (!cfptr->cfMisc.PutVersionLimit)
      cfptr->cfMisc.PutVersionLimit = PUT_DEFAULT_VERSION_LIMIT;

   if (cfptr->cfAuth.CacheMinutes > CONFIG_REVALIDATE_MINUTES_MAX)
      cfptr->cfAuth.CacheMinutes = CONFIG_REVALIDATE_MINUTES_MAX;

   if (cfptr->cfAuth.RevalidateUserMinutes > CONFIG_REVALIDATE_MINUTES_MAX)
       cfptr->cfAuth.RevalidateUserMinutes = CONFIG_REVALIDATE_MINUTES_MAX;

   if (CliAcceptHostsPtr != NULL)
      Config.cfServer.AcceptHostsPtr = CliAcceptHostsPtr;

   if (CliRejectHostsPtr != NULL)
      Config.cfServer.RejectHostsPtr = CliRejectHostsPtr;

   /* push these to all upper case (just cause it looks uniform) */
   if (cfptr->cfScript.DefaultSearchExcludePtr != NULL)
      for (cptr = cfptr->cfScript.DefaultSearchExcludePtr; *cptr; cptr++)
         *cptr = toupper(*cptr);

   ConfigContentTypeIcon (cfptr);

   if (!cfptr->cfDir.BodyTag[0])
      strcpy (cfptr->cfDir.BodyTag, CONFIG_DEFAULT_DIR_BODY_TAG);
   if (!cfptr->cfServer.AdminBodyTag[0])
      strcpy (cfptr->cfServer.AdminBodyTag, CONFIG_DEFAULT_ADMIN_BODY_TAG);
   if (!cfptr->cfServer.ReportBodyTag[0])
      strcpy (cfptr->cfServer.ReportBodyTag, CONFIG_DEFAULT_REPORT_BODY_TAG);

   if (cfptr == &Config)
   {
      /* configuring at server startup */
      if (OpcomTarget = Config.cfOpcom.Target)
         OpcomMessages = Config.cfOpcom.Messages;
      else
         OpcomMessages = 0;

      /* command line overrides configuration, default fallbacks */
      if (!NetReadBufferSize) NetReadBufferSize = Config.cfBuffer.SizeNetRead;
      if (!NetReadBufferSize) NetReadBufferSize = DEFAULT_NET_READ_BUFFER_SIZE;
      if (!OutputBufferSize) OutputBufferSize = Config.cfBuffer.SizeNetWrite;
      if (!OutputBufferSize) OutputBufferSize = DEFAULT_OUTPUT_BUFFER_SIZE;

      if (cfptr->cfServer.ListenBacklog <= 0 ||
          cfptr->cfServer.ListenBacklog > 999)
         cfptr->cfServer.ListenBacklog = DEFAULT_LISTEN_BACKLOG;
   }

   /* for backward compatibility with pre-v4.3 behaviour (see DCL.C) */
   if (getenv ("HTTPD_DCL_FULL_REQUEST") != NULL)
      cfptr->cfScript.FullRequest = true;

#ifdef DBUG
   Debug = DebugBuffer;
#endif

   if (VMSnok (status))
   {
      if (cfptr->RequestPtr)
      {
         ConfigReportProblem (cfptr, NULL, status);
         return;
      }
      else
         ErrorExitVmsStatus (status, CONFIG_FILE_NAME, FI_LI);
   }

   return (status);
}

/*****************************************************************************/
/*
Return true or false values equivalent to the string pointed to by 'pptr'.
*/

boolean ConfigSetBoolean
(
struct ConfigStruct *cfptr,
char *pptr
)
{
   /*********/
   /* begin */
   /*********/

   if (strsame (pptr, "YES", 3) ||
       strsame (pptr, "ON", 2) ||
       strsame (pptr, "ENABLED", 7))
      return (true);

   if (strsame (pptr, "NO", 2) ||
       strsame (pptr, "OFF", 3) ||
       strsame (pptr, "DISABLED", 8))
      return (false);

   ConfigReportProblem (cfptr, NULL, 0);
   return (false);
}

/*****************************************************************************/
/*
Free all memory allocated for a configuration.  Only used after file-based
configuration report or revision.
*/

ConfigFree (struct ConfigStruct *cfptr)

{
   int  Count;
   char  *cptr;
   struct ContentInfoStruct  *clptr;
   struct IconStruct  *ilptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ConfigFree()\n");

   clptr = cfptr->cfContent.ContentInfoListHeadPtr;
   while (clptr != NULL)
   {
      cptr = (char*)clptr;
      clptr = clptr->NextPtr;
      VmFree (cptr, FI_LI);
   }

   ilptr = cfptr->cfContent.IconListHeadPtr;
   while (ilptr != NULL)
   {
      cptr = (char*)ilptr;
      ilptr = ilptr->NextPtr;
      VmFree (cptr, FI_LI);
   }

   for (Count = 0; Count < cfptr->cfContent.HomePageCount; Count++)
      if (cfptr->cfContent.HomePageArray[Count] != NULL)
         VmFree (cfptr->cfContent.HomePageArray[Count], FI_LI);

   if (cfptr->cfServer.AcceptHostsPtr != NULL)
      VmFree (cfptr->cfServer.AcceptHostsPtr, FI_LI);
   if (cfptr->cfLog.ExcludeHostsPtr != NULL)
      VmFree (cfptr->cfLog.ExcludeHostsPtr, FI_LI);
   if (cfptr->cfServer.RejectHostsPtr != NULL)
      VmFree (cfptr->cfServer.RejectHostsPtr, FI_LI);
   if (cfptr->cfScript.DefaultSearchExcludePtr != NULL)
      VmFree (cfptr->cfScript.DefaultSearchExcludePtr, FI_LI);
   if (cfptr->cfServer.ServicePtr != NULL)
      VmFree (cfptr->cfServer.ServicePtr, FI_LI);
   if (cfptr->ProblemReportPtr != NULL)
      VmFree (cfptr->ProblemReportPtr, FI_LI);
}

/*****************************************************************************/
/*
Return an integer equivalent to the numeric string pointed to by 'pptr'.
*/

int ConfigSetInteger
(
struct ConfigStruct *cfptr,
char *pptr
)
{
   /*********/
   /* begin */
   /*********/

   if (isdigit(*pptr)) return (atoi(pptr));
   ConfigReportProblem (cfptr, NULL, 0);
   return (-1);
}

/*****************************************************************************/
/*
Copy a simple string configuration parameter trimming leadin and trailing
white-space.
*/

ConfigSetString
(
struct ConfigStruct *cfptr,
char *pptr,
char *String,
int SizeOfString
)
{
   register char  *sptr, *zptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ConfigSetString()\n");

   zptr = (sptr = String) + SizeOfString;
   while (*pptr && ISLWS(*pptr)) pptr++;
   while (*pptr && sptr < zptr) *sptr++ = *pptr++;
   if (sptr >= zptr)
   {
      *String = '\0';
      ConfigReportProblem (cfptr, NULL, 0);
      return;
   }
   *sptr = '\0';
   if (sptr > String)
   {
      sptr--;
      while (*sptr && ISLWS(*sptr) && sptr > String) sptr--;
      *++sptr = '\0';
   }
}

/*****************************************************************************/
/*
This function formats an error report.  All lines are concatenated onto a
single string of dynamically allocated memory that (obviously) grows as
reports are added to it.  This string is then output if loading the server
configuration or is available for inclusion in an HTML page.
*/

ConfigReportProblem
(
struct ConfigStruct *cfptr,
char *Explanation,
int StatusValue
)
{
   static $DESCRIPTOR (DirectiveFaoDsc,
                       "%HTTPD-W-CONFIG, \"!AZ\" directive !AZ at line !UL\n");
   static $DESCRIPTOR (ExplanationFaoDsc,
                       "%HTTPD-W-CONFIG, \"!AZ\" !AZ at line !UL\n");

   int  status;
   unsigned short  Length;
   char  Buffer [256];
   $DESCRIPTOR (BufferDsc, Buffer);

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ConfigReportProblem()\n");

   cfptr->ProblemCount++;

   if (StatusValue)
   {
      if (VMSok (status = sys$getmsg (StatusValue, &Length, &BufferDsc, 0, 0)))
         Buffer[Length++] = '\n';
   }
   if (Explanation == NULL)
      status = sys$fao (&DirectiveFaoDsc, &Length, &BufferDsc,
                        cfptr->DirectiveName, "problem", cfptr->LineNumber);
   else
   if (Explanation[0] == '?')
      status = sys$fao (&DirectiveFaoDsc, &Length, &BufferDsc,
                        cfptr->DirectiveName, "unknown", cfptr->LineNumber);
   else
      status = sys$fao (&ExplanationFaoDsc, &Length, &BufferDsc,
                        cfptr->DirectiveName, Explanation, cfptr->LineNumber);
   if (VMSnok (status) || status == SS$_BUFFEROVF)
      ErrorExitVmsStatus (status, "sys$fao()", FI_LI);
   else
      Buffer[Length] = '\0';
   if (Debug) fprintf (stdout, "|%s|\n", Buffer);

   if (cfptr->RequestPtr == NULL) fputs (Buffer, stdout);

   cfptr->ProblemReportPtr =
      VmRealloc (cfptr->ProblemReportPtr,
                 cfptr->ProblemReportLength+Length+1, FI_LI);

   /* include the terminating null */
   memcpy (cfptr->ProblemReportPtr+cfptr->ProblemReportLength,
           Buffer, Length+1);
   cfptr->ProblemReportLength += Length;
}

/*****************************************************************************/
/*
*/

ConfigSetCommaList
(
struct ConfigStruct *cfptr,
char *pptr,
char **ListPtrPtr,
int *ListLengthPtr
)
{
   register char  *cptr, *sptr;
   int  NewLength,
        ListLength;
   char  *ListPtr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ConfigSetCommaList()\n");

   if (!*pptr)
   {
      ConfigReportProblem (cfptr, NULL, 0);
      return;
   }

   ListPtr = *ListPtrPtr;
   if (ListLength = *ListLengthPtr) ListLength--;
   for (sptr = pptr; *sptr; sptr++);
   NewLength = ListLength + (sptr - pptr) + 2;
   ListPtr = VmRealloc (ListPtr, NewLength, FI_LI);
   sptr = ListPtr + ListLength;
   /* if it's a continuation line then add no comma */
   if (ListLength && sptr[-1] == '\\')
   {
      sptr--;
      /* just remove one character - and there's no comma */
      NewLength -= 2;
   }
   else
   if (ListLength)
      *sptr++ = ',';
   else
      NewLength--;
   while (*pptr) if (ISLWS(*pptr)) pptr++; else *sptr++ = *pptr++;
   *sptr = '\0';
   *ListPtrPtr = ListPtr;
   *ListLengthPtr = NewLength;
   if (Debug)
      fprintf (stdout, "ListPtr %d |%s|\n", *ListLengthPtr, *ListPtrPtr);
}

/*****************************************************************************/
/*
Add a mime content type corresponding to the file suffix (extension, type). 
The file suffix can contain the asterisk wildcard character, matching zero or
more characters.  The content-type can be quoted and can include additional
characteristics.

Format: "AddType <suffix> <type[;charset=]> <-|/script> [<description>]"

Examples: "AddType .html text/html - HTML"
          "AddType .html text/html;charset=ISO8859-5 - HTML"
          "AddType .html "text/html; charset=ISO8859-5" - HTML"
          "AddType .txt text/plain - plain text"
          "AddType .read* text/plain - plain text"
          "AddType .hlb text/x-script /conan VMS help library"
          "AddType .gif image/gif - GIF image"

The directive is stored as a linked list of structures of dynamically
allocated memory containing a reformatted version of the directive string.
Function ConfigContentType() searches this list to get pointers to the content
type, any auto-script, and description, into the client request data
structure. A hash table is used to more rapidy index into the list.
*/ 

ConfigAddType
(
struct ConfigStruct *cfptr,
char *pptr
)
{
   register char  *cptr, *sptr;
   register unsigned long  HashValue;
   register struct ContentInfoStruct  *clptr, *hclptr;

   boolean  ContainsWildcard = false;
   int  status,
        Count = 0;
   char  *DescriptionPtr = "",
         *ContentTypePtr = "",
         *AutoScriptNamePtr = "",
         *SuffixPtr = "";
   char  HtmlDescription [256];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ConfigAddType() |%s|\n", pptr);

   /* suffix (file type/extension) */
   SuffixPtr = pptr;
   /* ensure suffix is in upper-case so we don't have to do it matching */
   for ( /* above */ ; *pptr && !ISLWS(*pptr); pptr++)
   {
      if (*pptr == '*') ContainsWildcard = true;
      *pptr = toupper(*pptr);
   }
   Count += pptr - SuffixPtr;
   if (*pptr) *pptr++ = '\0';

   /* content type (can include quotes, e.g. "text/html; charset=ISO-8859-5" */
   while (*pptr && ISLWS(*pptr)) pptr++;
   if (*pptr == '\"')
   {
      pptr++;
      ContentTypePtr = pptr;
      while (*pptr && *pptr != '\"') pptr++;
   }
   else
   {
      ContentTypePtr = pptr;
      while (*pptr && !ISLWS(*pptr)) pptr++;
   }
   Count += pptr - ContentTypePtr;
   if (*pptr) *pptr++ = '\0';

   /* (optional) script activation */
   while (*pptr && ISLWS(*pptr)) pptr++;
   AutoScriptNamePtr = pptr;
   while (*pptr && !ISLWS(*pptr)) pptr++;
   Count += pptr - AutoScriptNamePtr;
   if (*pptr) *pptr++ = '\0';

   /* (optional) description, to end of line */
   while (*pptr && ISLWS(*pptr)) pptr++;
   DescriptionPtr = pptr;
   /* find the end-of-line */
   while (*pptr) pptr++;
   if (*pptr) *pptr++ = '\0';
   /* escape any HTML-forbidden characters */
   status = WriteFao (HtmlDescription, sizeof(HtmlDescription), NULL,
                      "!HZ", DescriptionPtr);
   if (VMSnok (status) || status == SS$_BUFFEROVF)
      ErrorNoticed (status, "WriteFao()", FI_LI);
   Count += strlen(HtmlDescription);

   if ((*SuffixPtr != '.' && *SuffixPtr != '*') ||
       !*ContentTypePtr || strchr(ContentTypePtr, '/') == NULL ||
       (*AutoScriptNamePtr != '-' &&
        (AutoScriptNamePtr[0] != '/' || !isalpha(AutoScriptNamePtr[1]))))
   {
      ConfigReportProblem (cfptr, NULL, 0);
      return;
   }

   /* plus structure overhead, plus 4 x null terminators */
   Count += cfptr->cfContent.ContentInfoStructOverhead + 4;
   clptr = (struct ContentInfoStruct*)VmGet (Count);

   sptr = (char*)clptr + cfptr->cfContent.ContentInfoStructOverhead;

   clptr->SuffixPtr = sptr;
   cptr = SuffixPtr;
   while (*cptr) *sptr++ = *cptr++;
   *sptr++ = '\0';

   clptr->ContentTypePtr = sptr;
   cptr = ContentTypePtr;
   while (*cptr) *sptr++ = *cptr++;
   *sptr++ = '\0';

   clptr->AutoScriptNamePtr = sptr;
   cptr = AutoScriptNamePtr;
   while (*cptr) *sptr++ = *cptr++;
   *sptr++ = '\0';

   clptr->DescriptionPtr = sptr;
   cptr = HtmlDescription;
   while (*cptr) *sptr++ = *cptr++;
   *sptr = '\0';

   /* add to list */
   if (cfptr->cfContent.ContentInfoListHeadPtr == NULL)
      cfptr->cfContent.ContentInfoListHeadPtr = clptr; 
   else
      cfptr->cfContent.ContentInfoListTailPtr->NextPtr = clptr; 
   cfptr->cfContent.ContentInfoListTailPtr = clptr;
   clptr->NextPtr = NULL;

   if (ContainsWildcard)
   {
      /* all wildcarded types are listed from hash value 0 */
      HashValue = 0;
   }
   else
   {
      /* generates an upper-case hash */
      HashValue = 1;
      for (cptr = SuffixPtr; *cptr && *cptr != ';'; cptr++)
         HashValue = (((*cptr)*541)^(HashValue*3)) &
                     CONTENT_TYPE_HASH_TABLE_MASK;
      if (Debug)
         fprintf (stdout, "HashValue: %d %d\n",
                  HashValue, cfptr->cfContent.ContentInfoHashTable [HashValue]);
   }
   if (cfptr->cfContent.ContentInfoHashTable [HashValue])
   {
      /* add to the hash-collision list */
      for (hclptr = cfptr->cfContent.ContentInfoHashTable [HashValue];
           hclptr->HashCollisionPtr != NULL;
           hclptr = hclptr->HashCollisionPtr);
      hclptr->HashCollisionPtr = clptr;
   }
   else
      cfptr->cfContent.ContentInfoHashTable [HashValue] = clptr;

   /* special case, default content-type for unknown suffixes */
   if (*(unsigned short*)clptr->SuffixPtr == '*\0')
   {
      cfptr->cfContent.ContentTypeDefaultPtr = VmGet (strlen(DescriptionPtr+1));
      strcpy (cfptr->cfContent.ContentTypeDefaultPtr, DescriptionPtr);
      clptr->TypeUnknown = true;
      /* cancel type description */
      *clptr->DescriptionPtr = '\0';
   }
   else
      clptr->TypeUnknown = false;
}

/*****************************************************************************/
/*
After loading all content-types (i.e. after configuration) this function sets
the corresponding icon for each type.
*/ 

ConfigContentTypeIcon (struct ConfigStruct *cfptr)

{
   register struct ContentInfoStruct  *clptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ConfigContentTypeIcon()\n");

   for (clptr = cfptr->cfContent.ContentInfoListHeadPtr;
        clptr != NULL;
        clptr = clptr->NextPtr)
   {
      if (Debug) fprintf (stdout, "clptr: %d\n", clptr);
      if (clptr->TypeUnknown)
         clptr->IconPtr = ConfigIconFor (ConfigContentTypeUnknown);
      else
         clptr->IconPtr = ConfigIconFor (clptr->ContentTypePtr);
   }

   ConfigBlankIconPtr = ConfigIconFor (ConfigContentTypeBlank);
   ConfigDirIconPtr = ConfigIconFor (ConfigContentTypeDir);
   ConfigParentIconPtr = ConfigIconFor (ConfigContentTypeParent);
   ConfigUnknownIconPtr = ConfigIconFor (ConfigContentTypeUnknown);
}

/*****************************************************************************/
/*
Using the hash table this function searches the list of file suffixes (types,
extensions) and content-types, returning a pointer to the content-type string
and if supplied with a content-type structure fills out the appropriate
fields.  Wildcarded file types are always stored in the list beginning with
hash table zero (i.e. [0]).
*/ 

char* ConfigContentType
(
struct ContentInfoStruct *ciptr,
char *SuffixPtr
)
{
   register char  *cptr, *sptr;
   register unsigned long  HashValue;
   register struct ContentInfoStruct  *clptr;

   boolean  CheckedForWildcards;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ConfigContentType() |%s|\n", SuffixPtr);

   /* generate an upper-case hash */
   if (*SuffixPtr != '.') SuffixPtr = ".";
   HashValue = 1;
   for (cptr = SuffixPtr; *cptr && *cptr != ';'; cptr++)
      HashValue = ((toupper(*cptr)*541)^(HashValue*3)) &
                  CONTENT_TYPE_HASH_TABLE_MASK;
   if (Debug)
      fprintf (stdout, "HashValue: %d %d\n",
               HashValue, Config.cfContent.ContentInfoHashTable[HashValue]);

   CheckedForWildcards = false;

   if ((clptr = Config.cfContent.ContentInfoHashTable[HashValue]) == NULL)
      clptr = Config.cfContent.ContentInfoHashTable[0];
   while (clptr != NULL)
   {
      if (Debug) fprintf (stdout, "clptr: %d\n", clptr);

      /* 'clptr->SuffixPtr' has already been converted to upper case! */
      cptr = clptr->SuffixPtr;
      if (Debug) fprintf (stdout, "|%s|\n", cptr);
      sptr = SuffixPtr;
      while (*cptr && *sptr && *sptr != ';' && *cptr == toupper(*sptr))
      {
         if (*cptr != '*')
         {
            /* not a wildcard */
            cptr++;
            sptr++;
            if (*cptr != '*') continue;
         }
         /* consecutive wildcards are the same as a single wildcard */
         while (*cptr && *cptr == '*') cptr++;
         if (*cptr)
         {
            /* find first matching the character following the wildcard */
            while (*sptr && *sptr != ';' && toupper(*sptr) != *cptr) sptr++;
            continue;
         }
         /* wildcard at end of list file type, matches all following */
         while (*sptr && *sptr != ';') sptr++;
      }

      if (*cptr || (*sptr && *sptr != ';'))
      {
         /* didn't match, traversing the hash-collision list */
         if ((clptr = clptr->HashCollisionPtr) != NULL) continue;

         /* end of collision list, check for wildcarded file types */
         if (!CheckedForWildcards)
         {
            CheckedForWildcards = true;
            clptr = Config.cfContent.ContentInfoHashTable[0];
         }
         continue;
      }

      /**********/
      /* match! */
      /**********/

      /* if just getting a pointer to a content type then just return that */
      if (ciptr == NULL) return (clptr->ContentTypePtr);

      ciptr->TypeUnknown = false;
      ciptr->IconPtr = clptr->IconPtr;
      ciptr->ContentTypePtr = clptr->ContentTypePtr;
      ciptr->AutoScriptNamePtr = clptr->AutoScriptNamePtr;
      ciptr->DescriptionPtr = clptr->DescriptionPtr;

      if (Debug)
         fprintf (stdout, "|%s|%s|%s|\n",
                  ciptr->ContentTypePtr, ciptr->AutoScriptNamePtr,
                  ciptr->DescriptionPtr);

      return (clptr->ContentTypePtr);
   }

   /*************/
   /* no match! */
   /*************/

   /* if just getting a pointer to a content type then just return that */
   if (ciptr == NULL) return (ConfigContentTypeUnknown);

   ciptr->TypeUnknown = true;
   ciptr->IconPtr = ConfigUnknownIconPtr;
   ciptr->ContentTypePtr = ConfigContentTypeUnknown;
   ciptr->AutoScriptNamePtr = ciptr->DescriptionPtr = "";
   return (ConfigContentTypeUnknown);
}

/****************************************************************************/
/*
Compare two MIME content-types where only the type is compared (i.e. only the
"text/html" from something like "text/html;charset=ISO8859-5").  It works much
the same as strsame(), except a semi-colon or white-space in either string will
terminate a comparison, as will an exhausted count value.
*/ 
 
boolean ConfigSameContentType
(
register char *sptr1,
register char *sptr2,
register int  count
)
{
   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "ConfigSameContentType() |%s|%s| %d\n",
               sptr1, sptr2, count);

   while (*sptr1 && *sptr1 != ';' && !ISLWS(*sptr1) &&
          *sptr2 && *sptr2 != ';' && !ISLWS(*sptr2))
   {
      if (toupper (*sptr1++) != toupper (*sptr2++)) return (false);
      if (count)
         if (!--count) return (true);
   }
   if ((!*sptr1 && (!*sptr2 || *sptr2 == ';')) ||
       (!*sptr2 && (!*sptr1 || *sptr1 == ';')))
      return (true);
   else
      return (false);
}
 
/*****************************************************************************/
/*
Add a URL for an icon corresponding to the mime content type.

Format:   "AddIcon <URL> <alternative-text> <content-type-template>"

Examples: "AddIcon /icon/httpd/text.xbm [TXT] text/plain"
          "AddIcon /icon/httpd/doc.xbm [HTM] text/html"
          "AddIcon /icon/httpd/image.xbm [IMG] image/jpeg"

The template can contain a wildcard in place of a string in either side of the 
template slash.  In this case the wildcard matches any string on that side.

The directive is stored as a linked-list of structures of dynamically
allocated memory containing a reformatted version of the directive string,
including a complete HTML anchor for the URL. Function ConfigIconFor()
searches this list to return a pointer to the anchor. A hash table is used to
more rapidy index into the list.
*/ 

ConfigAddIcon
(
struct ConfigStruct *cfptr,
char *pptr
)
{
   register unsigned long  HashValue;
   register char  *cptr;
   register struct IconStruct  *ilptr, *hilptr;

   int  Count = 0;
   char  *AltTextPtr,
         *IconUrlPtr,
         *ContentTypePtr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ConfigAddIcon()\n");

   IconUrlPtr = pptr;
   while (*pptr && !ISLWS(*pptr)) pptr++;
   Count = pptr - IconUrlPtr;
   if (*pptr) *pptr++ = '\0';

   /* alternative text */
   while (*pptr && ISLWS(*pptr)) pptr++;
   AltTextPtr = pptr;
   while (*pptr && !ISLWS(*pptr))
   {
      /* underscores represent spaces! (especially for the "blank" icon) */
      if (*pptr == '_') *pptr = ' ';
      pptr++;
   }
   Count += pptr - AltTextPtr;
   if (*pptr) *pptr++ = '\0';

   /* template */
   while (*pptr && ISLWS(*pptr)) pptr++;
   ContentTypePtr = pptr;
   /* force to lower case to save a tolower() in ConfigIconFor() */
   for ( /* above */ ; *pptr && !ISLWS(*pptr); pptr++)
      *pptr = tolower(*pptr);
   Count += pptr - ContentTypePtr;
   if (*pptr) *pptr++ = '\0';

   if (!*IconUrlPtr && *IconUrlPtr != '/' ||
       !*AltTextPtr ||
       !*ContentTypePtr || strchr(ContentTypePtr, '/') == NULL)
   {
      ConfigReportProblem (cfptr, NULL, 0);
      return;
   }

   /* plus structure overhead, plus the HTML IMG element used below */
   Count += cfptr->cfContent.IconStructOverhead + 32;
   ilptr = (struct IconStruct*)VmGet (Count);

   sprintf ((char*)ilptr + cfptr->cfContent.IconStructOverhead,
            "%s <IMG ALIGN=top SRC=\"%s\" ALT=\"%s\">",
            ContentTypePtr, IconUrlPtr, AltTextPtr);
   if (Debug)
      fprintf (stdout, "|%s|%s|%s|%s|\n",
               ContentTypePtr, IconUrlPtr, AltTextPtr,
               (char*)ilptr + cfptr->cfContent.IconStructOverhead);

   /* add to list */
   if (cfptr->cfContent.IconListHeadPtr == NULL)
      cfptr->cfContent.IconListHeadPtr = ilptr; 
   else
      cfptr->cfContent.IconListTailPtr->NextPtr = ilptr; 
   cfptr->cfContent.IconListTailPtr = ilptr;
   ilptr->NextPtr = NULL;

   /* generates a lower-case hash */
   HashValue = 1;
   for (cptr = ContentTypePtr; *cptr; cptr++)
      HashValue = (((*cptr)*541)^(HashValue*3)) &
                  ICON_HASH_TABLE_MASK;
   if (Debug)
      fprintf (stdout, "HashValue: %d %d\n",
               HashValue, cfptr->cfContent.ContentInfoHashTable [HashValue]);
   if (cfptr->cfContent.IconHashTable[HashValue])
   {
      /* add to the hash-collision list */
      for (hilptr = cfptr->cfContent.IconHashTable[HashValue];
           hilptr->HashCollisionPtr != NULL;
           hilptr = hilptr->HashCollisionPtr);
      hilptr->HashCollisionPtr = ilptr;
   }
   else
      cfptr->cfContent.IconHashTable[HashValue] = ilptr;
}

/*****************************************************************************/
/*
Using the hash table this function searches the icons for one corresponding to
the supplied mime content type. The directive content type and associated HTML
anchor (containing the original configuration-supplied URL) is stored as an
list of structures dynamically allocated memory containing a string.
*/

char* ConfigIconFor (char *ContentType)

{
   static char  IconNotFound [] = "<FONT COLOR=\"#ff0000\"><B>[?]</B></FONT>";

   register char  *cptr, *sptr;
   register unsigned long  HashValue;
   register struct IconStruct  *ilptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ConfigIconFor() |%s|\n", ContentType);

   /* generates a lower-case hash */
   HashValue = 1;
   for (cptr = ContentType; *cptr && *cptr != ';' && !ISLWS(*cptr); cptr++)
      HashValue = ((tolower(*cptr)*541)^(HashValue*3)) &
                  ICON_HASH_TABLE_MASK;
   if (Debug)
      fprintf (stdout, "HashValue: %d %d\n",
               HashValue, Config.cfContent.IconHashTable[HashValue]);

   ilptr = Config.cfContent.IconHashTable[HashValue];
   while (ilptr != NULL)
   {
      if (Debug) fprintf (stdout, "ilptr: %d\n", ilptr);

      cptr = (char*)ilptr + Config.cfContent.IconStructOverhead;
      if (Debug) fprintf (stdout, "|%s|\n", cptr);
      sptr = ContentType;
      if (*cptr == '*')
      {
         /* template contained a wildcard on the left side of the slash */
         while (*cptr && *cptr != '/' && !ISLWS(*cptr)) cptr++;
         if (*cptr == '/') cptr++;
         if (*cptr == '*')
         {
            /* return a pointer to the HTML IMG element for the icon */
            cptr++;
            return (cptr);
         }
         /* scan to subtype */
         while (*sptr && *sptr != '/' && *sptr != ';' && !ISLWS(*sptr)) sptr++;
      }
      else
      {
         /* match main type */
         while (*cptr == tolower(*sptr) &&
                *cptr && *cptr != '/' &&
                *sptr && *sptr != '/' && *sptr != ';' && !ISLWS(*sptr))
         {
            cptr++;
            sptr++;
         }
         if (*cptr != '/' && *sptr != '/')
         {
            /* didn't match, traversing the hash-collision list */
            ilptr = ilptr->HashCollisionPtr;
            continue;
         }
         /* step across the '/' to the subtype */
         cptr++;
         sptr++;
      }

      if (*cptr == '*')
      {
         /* wildcard subtype, return pointer to the IMG element for the icon */
         cptr++;
         return (cptr);
      }
      else
      {
         /* match subtype */
         while (*cptr == tolower(*sptr) &&
                *cptr && !ISLWS(*cptr) &&
                *sptr && *sptr != ';' && !ISLWS(*sptr))
         {
            cptr++;
            sptr++;
         }
         if (!ISLWS(*cptr) || (*sptr && *sptr != ';' && !ISLWS(*sptr)))
         {
            /* didn't match, traversing the hash-collision list */
            ilptr = ilptr->HashCollisionPtr;
            continue;
         }
         /* return pointer to the IMG element for the icon */
         cptr++;
         return (cptr);
      }
   }

   return (IconNotFound);
}

/*****************************************************************************/
/*
Accept or reject the client connection.  Lists of hosts must be a comma-
separated string.  A wildcard '*' in a domain specification matches any string 
that occurs between the dots.
Example: "host1.network1.domain1,*.network2.domain1,*.*.domain2". 
*/ 

boolean ConfigAcceptClientHostName
(
char *ClientIpAddressString,
char *ClientHostName
)
{
   register char  *cptr, *sptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "ConfigAcceptConnection() |%s|\n", ClientHostName);

   if (Config.cfServer.AcceptHostsPtr == NULL && Config.cfServer.RejectHostsPtr == NULL)
      return (true);

   if (!ClientHostName[0] || ClientHostName[0] == '?') return (false);

   /******************/
   /* hosts accepted */
   /******************/

   if (Config.cfServer.AcceptHostsPtr != NULL)
   {
      sptr = Config.cfServer.AcceptHostsPtr;
      while (*sptr)
      {
         /** if (Debug) fprintf (stdout, "sptr |%s|\n", sptr); **/
         if (isdigit(*sptr))
            cptr = ClientIpAddressString;
         else
            cptr = ClientHostName;
         while (*cptr)
         {
            if (*sptr == ',') break;
            if (*sptr == '*')
            {
               while (*sptr && *sptr == '*' && *sptr != ',') sptr++;
               while (*cptr && *cptr != *sptr) cptr++;
            }
            if (tolower(*cptr) != tolower(*sptr)) break;
            if (*cptr) cptr++;
            if (*sptr) sptr++;
         }
         if (!*cptr && (!*sptr || *sptr == ',')) break;
         while (*sptr && *sptr != ',') sptr++;
         if (*sptr) sptr++;
      }
      /* if it was NOT found then reject the connection request */
      if (!(!*cptr && (!*sptr || *sptr == ',')))
         return (false);
   }

   /******************/
   /* hosts rejected */
   /******************/

   if (Config.cfServer.RejectHostsPtr != NULL)
   {
      sptr = Config.cfServer.RejectHostsPtr;
      while (*sptr)
      {
         /** if (Debug) fprintf (stdout, "sptr |%s|\n", sptr); **/
         cptr = ClientHostName;
         while (*cptr)
         {
            if (*sptr == ',') break;
            if (*sptr == '*')
            {
               while (*sptr && *sptr == '*' && *sptr != ',') sptr++;
               while (*cptr && *cptr != *sptr) cptr++;
            }
            if (tolower(*cptr) != tolower(*sptr)) break;
            if (*cptr) cptr++;
            if (*sptr) sptr++;
         }
         if (!*cptr && (!*sptr || *sptr == ',')) break;
         while (*sptr && *sptr != ',') sptr++;
         if (*sptr) sptr++;
      }
      /* if it WAS found then reject the connection request */
      if (!*cptr && (!*sptr || *sptr == ','))
         return (false);
   }

   /* accept the connection */
   return (true);
}

/*****************************************************************************/
/*
Set directory access booleans.  Allowed values OFF, ON, SELECTIVE.
*/

ConfigSetDirAccess
(
struct ConfigStruct *cfptr,
char *pptr
)
{
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ConfigSetDirAccess()\n");

   if (strsame (pptr, "YES", 3) ||
       strsame (pptr, "ON", 2) ||
       strsame (pptr, "ENABLED", 7))
   {
      cfptr->cfDir.Access = true;
      cfptr->cfDir.AccessSelective = false;
   }
   else
   if (strsame (pptr, "NO", 2) ||
       strsame (pptr, "OFF", 3) ||
       strsame (pptr, "DISABLED", 8))
      cfptr->cfDir.Access = cfptr->cfDir.AccessSelective = false;
   else
   if (strsame (pptr, "SELECTIVE", 9))
      cfptr->cfDir.Access = cfptr->cfDir.AccessSelective = true;
   else
      ConfigReportProblem (cfptr, NULL, 0);
}

/*****************************************************************************/
/*
Set directory README file booleans.  Allowed values OFF, TOP, BOTTOM.
*/

ConfigSetDirReadMe
(
struct ConfigStruct *cfptr,
char *pptr
)
{
   if (Debug) fprintf (stdout, "ConfigSetDirReadMe()\n");

   if (strsame (pptr, "NO", 2) ||
       strsame (pptr, "OFF", 3) ||
       strsame (pptr, "DISABLED", 8))
      cfptr->cfDir.ReadMeBottom = cfptr->cfDir.ReadMeTop = false;
   else
   if (strsame (pptr, "BOTTOM", 6))
   {
      cfptr->cfDir.ReadMeTop = false;
      cfptr->cfDir.ReadMeBottom = true;
   }
   else
   if (strsame (pptr, "TOP", 3))
   {
      cfptr->cfDir.ReadMeTop = true;
      cfptr->cfDir.ReadMeBottom = false;
   }
   else
      ConfigReportProblem (cfptr, NULL, 0);
}

/*****************************************************************************/
/*
Add a "read-me" file name.

Format:   "ReadMeFile file.suffix"

Examples: "ReadMeFile README.HTML"
          "ReadMeFile README.TXT"
          "ReadMeFile README."

The directive is stored as an array of pointers to dynamically allocated 
memory containing the "read-me" file name.  Function ConfigReadMeFile() gets 
these by index number.
*/

ConfigSetDirReadMeFile
(
struct ConfigStruct *cfptr,
char *pptr
)
{
   int  status,
        Count;
   char  *NamePtr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ConfigSetDirReadMeFile()\n");

   if (cfptr->cfDir.ReadMeFileCount >= CONFIG_README_FILES_MAX)
   {
      ConfigReportProblem (cfptr, "maximum read-me files", 0);
      return;
   }

   NamePtr = pptr;
   while (*pptr && !ISLWS(*pptr))
   {
      *pptr = toupper(*pptr);
      pptr++;
   }
   Count = pptr - NamePtr;
   *pptr = '\0';

   if (!*NamePtr)
   {
      ConfigReportProblem (cfptr, NULL, 0);
      return;
   }

   if (Debug) fprintf (stdout, "VmGet()ing %d bytes\n", Count+1);
   cfptr->cfDir.ReadMeFileArray[cfptr->cfDir.ReadMeFileCount] = VmGet(Count+1);

   strcpy (cfptr->cfDir.ReadMeFileArray[cfptr->cfDir.ReadMeFileCount], NamePtr);
   if (Debug)
      fprintf (stdout, "|%s|\n",
               cfptr->cfDir.ReadMeFileArray[cfptr->cfDir.ReadMeFileCount]);
   cfptr->cfDir.ReadMeFileCount++;
}

/*****************************************************************************/
/*
Return a pointer to the "read-me" file name stored against the index number of 
the array.  If none exists return a null string.  The calling function would 
use this by stepping through the index numbers 0 to n, until the null string 
was returned indicating the possible "read-me" file names were exhausted.
*/

char* ConfigReadMeFile (int Number)

{
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ConfigReadMeFile |%d|\n", Number);

   if (Number >= 0 && Number < Config.cfDir.ReadMeFileCount)
      return (Config.cfDir.ReadMeFileArray[Number]);
   else
      return ("");
}

/*****************************************************************************/
/*
Set OPCOM target and message categories.
*/

ConfigSetOpcom
(
struct ConfigStruct *cfptr,
char *pptr
)
{
   int  idx;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ConfigSetOpcom()\n");

   if (strsame (cfptr->DirectiveName, "OpcomTarget", -1))
   {
      for (idx = 0; ConfigOpcomTarget[idx].Number >= 0; idx++)
         if (strsame (ConfigOpcomTarget[idx].Name, pptr, -1)) break;
      if (ConfigOpcomTarget[idx].Number >= 0)
      {
         cfptr->cfOpcom.Target = ConfigOpcomTarget[cfptr->cfOpcom.Index = idx].Number;
         return;
      }
      ConfigReportProblem (cfptr, NULL, 0);
      return;
   }

   if (strsame (cfptr->DirectiveName, "OpcomAdmin", -1))
   {
      if (ConfigSetBoolean (cfptr, pptr))
         cfptr->cfOpcom.Messages |= OPCOM_ADMIN;
      return;
   }
   else
   if (strsame (cfptr->DirectiveName, "OpcomAuthorization", -1))
   {
      if (ConfigSetBoolean (cfptr, pptr))
         cfptr->cfOpcom.Messages |= OPCOM_AUTHORIZATION;
      return;
   }
   else
   if (strsame (cfptr->DirectiveName, "OpcomControl", -1))
   {
      if (ConfigSetBoolean (cfptr, pptr))
         cfptr->cfOpcom.Messages |= OPCOM_CONTROL;
      return;
   }
   else
   if (strsame (cfptr->DirectiveName, "OpcomHTTPd", -1))
   {
      if (ConfigSetBoolean (cfptr, pptr))
         cfptr->cfOpcom.Messages |= OPCOM_HTTPD;
      return;
   }
   else
   if (strsame (cfptr->DirectiveName, "OpcomProxyMaint", -1))
   {
      if (ConfigSetBoolean (cfptr, pptr))
         cfptr->cfOpcom.Messages |= OPCOM_PROXY_MAINT;
      return;
   }
   else
      ConfigReportProblem (cfptr, NULL, 0);
}

/*****************************************************************************/
/*
Add a script type.

Format:   "file-type verb"

Examples: ".PL PERL"
          ".PL $PERL_EXE:PERL.EXE"
          ".CGI $HT_EXE:CGIPERLUS.EXE"

The directive is stored as an array of pointers to dynamically allocated 
memory containing definition.  Function DclFindScript() uses this information.
The array entries comprise a reconstructed string from the directive.  The
verb part of the directive can have a leading '@' or '$' indicating that the
verb should be create before invoking the script.  If not having these leading
characters the verb is considered to be globally available.  The leading '@'
and '$' verbs are reconstructed from "$perl_exe:perl.exe" into
"PERL=\"$perl_exe:perl.exe\"".  From this the DCL module creates an
excecutable DCL command sequence.
*/ 

ConfigSetScriptRunTime
(
struct ConfigStruct *cfptr,
char *pptr
)
{
   int  status,
        Count,
        RunTimeCount;
   char  *cptr, *sptr, *zptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ConfigSetScriptRunTime()\n");

   if ((RunTimeCount = cfptr->cfScript.RunTimeCount) >=
       CONFIG_SCRIPT_RUNTIME_MAX)
   {
      ConfigReportProblem (cfptr, "maximum script types", 0);
      return;
   }

   zptr = (sptr = cfptr->cfScript.RunTime[RunTimeCount].String) +
          sizeof(cfptr->cfScript.RunTime[RunTimeCount].String)-1;
   if (*pptr != '.' && sptr < zptr) *sptr++ = '.';
   while (*pptr && !ISLWS(*pptr) && *pptr != ';' && sptr < zptr)
      *sptr++ = toupper(*pptr++);
   if (sptr < zptr) *sptr++ = ';';
   cfptr->cfScript.RunTime[RunTimeCount].FileTypeLength =
      sptr - cfptr->cfScript.RunTime[RunTimeCount].String;
   while (*pptr && (ISLWS(*pptr) || *pptr == ';')) pptr++;
   if (!*pptr)
   {
      ConfigReportProblem (cfptr, NULL, 0);
      return;
   }
   if (sptr < zptr) *sptr++ = ' ';
   while (*pptr && sptr < zptr) *sptr++ = *pptr++;
   if (sptr >= zptr)
   {
      ConfigReportProblem (cfptr, "runtime too long", 0);
      return;
   }
   *sptr = '\0';

   if (Debug)
      fprintf (stdout, "%d |%s|\n",
               cfptr->cfScript.RunTime[RunTimeCount].FileTypeLength,
               cfptr->cfScript.RunTime[RunTimeCount].String);

   cfptr->cfScript.RunTimeCount++;
}

/*****************************************************************************/
/*
Set directory access booleans.  Allowed values OFF, ON, EMAIL.
*/

ConfigSetServerSignature
(
struct ConfigStruct *cfptr,
char *pptr
)
{
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ConfigSetServerSignature()\n");

   if (strsame (pptr, "YES", 3) ||
       strsame (pptr, "ON", 2) ||
       strsame (pptr, "ENABLED", 7))
      cfptr->cfServer.Signature = CONFIG_SERVER_SIGNATURE_ON;
   else
   if (strsame (pptr, "NO", 2) ||
       strsame (pptr, "OFF", 3) ||
       strsame (pptr, "DISABLED", 8))
      cfptr->cfServer.Signature = CONFIG_SERVER_SIGNATURE_OFF;
   else
   if (strsame (pptr, "EMAIL", 5))
      cfptr->cfServer.Signature = CONFIG_SERVER_SIGNATURE_EMAIL;
   else
      ConfigReportProblem (cfptr, NULL, 0);
}

/*****************************************************************************/
/*
Add a welcome (home) page file name.

Format:   "Welcome file.suffix"

Examples: "Welcome HOME.HTML"
          "Welcome HOME.HTM"
          "Welcome HOME.MENU"

The directive is stored as an array of pointers to dynamically allocated 
memory containing the home page file name.  Function ConfigHomePage() gets 
these by index number.
*/ 

ConfigSetWelcome
(
struct ConfigStruct *cfptr,
char *pptr
)
{
   int  status,
        Count;
   char  *WelcomePtr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ConfigSetWelcome()\n");

   if (cfptr->cfContent.HomePageCount >= CONFIG_HOME_PAGES_MAX)
   {
      ConfigReportProblem (cfptr, "maximum welcome files", 0);
      return;
   }

   WelcomePtr = pptr;
   while (*pptr && !ISLWS(*pptr))
   {
      *pptr = toupper(*pptr);
      pptr++;
   }
   Count = pptr - WelcomePtr;
   *pptr = '\0';

   if (!*WelcomePtr)
   {
      ConfigReportProblem (cfptr, NULL, 0);
      return;
   }

   if (Debug) fprintf (stdout, "VmGet()ing %d bytes\n", Count+1);
   cfptr->cfContent.HomePageArray[cfptr->cfContent.HomePageCount] = VmGet (Count+1);

   strcpy (cfptr->cfContent.HomePageArray[cfptr->cfContent.HomePageCount], WelcomePtr);
   if (Debug)
      fprintf (stdout, "|%s|\n", cfptr->cfContent.HomePageArray[cfptr->cfContent.HomePageCount]);
   cfptr->cfContent.HomePageCount++;
}

/*****************************************************************************/
/*
Return a pointer to the home page (welcome) file name stored against the index 
number of the array.  If none exists return a null string.  The calling 
function would use this by stepping through the index numbers 0 to n, until 
the null string was returned indicating the possible home page file names were 
exhausted.
*/

char* ConfigHomePage (int Number)

{
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ConfigHomePage |%d|\n", Number);

   if (Number >= 0 && Number < Config.cfContent.HomePageCount)
      return (Config.cfContent.HomePageArray[Number]);
   else
      return ("");
}

/*****************************************************************************/
/*
A server administration report on the server's configuration. This function
just wraps the reporting function, loading a temporary database if necessary
for reporting from the configuration file.
*/ 

ConfigReport
(
struct RequestStruct *rqptr,
void *NextTaskFunction,
boolean  UseServerDatabase
)
{
   int  status;
   struct ConfigStruct  LocalConfig;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ConfigReport()\n");

   if (UseServerDatabase)
      ConfigReportNow (rqptr, &Config);
   else
   {
      memset (&LocalConfig, 0, sizeof(struct ConfigStruct));
      /* indicate it's being used for a report */
      Config.RequestPtr = rqptr;
      Configure (&LocalConfig);
      ConfigReportNow (rqptr, &LocalConfig);
      ConfigFree (&LocalConfig);
   }

   SysDclAst (NextTaskFunction, rqptr);
}

/*****************************************************************************/
/*
Return a report on the HTTPd server's configuration ... now!  This function
blocks while executing.
*/ 

ConfigReportNow
(
struct RequestStruct *rqptr,
struct ConfigStruct *cfptr
)
{
/* macro to push booleans onto the parameter list */
#define REPBOOL_ENDIS(b) \
if (b) *vecptr++ = "[enabled]"; else *vecptr++ = "[disabled]";

   static char  ResponseFao [] =
"<HTML>\n\
<HEAD>\n\
!AZ\
<TITLE>HTTPd !AZ ... Server Configuration</TITLE>\n\
</HEAD>\n\
!AZ\n\
<H2><NOBR>HTTPd !AZ</NOBR></H2>\n\
<H3>Server Configuration</H3>\n\
!20%W\n";

   static char  ProblemReportFao [] =
"<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH><FONT COLOR=\"#ff0000\">!UL Report!%s \
!%?At Startup\rDuring Load\r</FONT></TH></TR>\n\
<TR><TD><PRE>!AZ</PRE></TD></TR>\n\
</TABLE>\n";

   static char  ReportSourceFao [] =
"<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Source: &quot;!%?Server\rFile\r&quot;</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right>File:</TH>\
<TD ALIGN=left>!AZ</TD>\
<TD>&nbsp;</TD><TH>[<A HREF=\"!AZ\">View</A>]</TH>\
<TH>[<A HREF=\"!AZ!AZ\">Edit</A>]</TH>\
</TR>\n\
<TR><TH ALIGN=right>!AZ</TH>\
<TD ALIGN=left>!20%W</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n";

   static char
      NotNone [] = "<FONT SIZE=-1><I>(none)</I></FONT>\n",
      NoRestriction [] = "<FONT SIZE=-1><I>(no restriction)</I></FONT>\n",
      ServerOnly [] = "<FONT SIZE=-1><I>(this server only)</I></FONT>\n";

   static char ReportGeneralFao [] =
"<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>GMT</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right>Offset:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Current:</TH><TD>!AZ</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>General</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right>Busy:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>connections</I></FONT></TR>\
<TR><TH ALIGN=right>Listen Backlog:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>connections</I></FONT></TR>\
<TR><TH ALIGN=right>Request History:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>requests</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>Activity History:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>days</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>Charset Default:</TH><TD COLSPAN=2>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>DNS Lookup:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Monitor:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>IP Port:</TH><TD>!UL</TD></TR>\n\
<TR><TH ALIGN=right>StreamLF:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>kBytes</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>Search Script:</TH><TD COLSPAN=2>!AZ</TD></TR>\n\
<TR><TH ALIGN=right VALIGN=top>Search Script Exclude:</TH><TD>!AZ</TD>\n\
<TD VALIGN=top><FONT SIZE=-1><I>file type</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right><FONT SIZE=-1>PUT/POST</FONT> Max Length:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>kBytes</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right><FONT SIZE=-1>PUT/POST</FONT> Files:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>version limit</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>/~username/ Cache Entries:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>user names</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>Persona Cache Entries:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>users</I></FONT></TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Log</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right>Logging:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Format:</TH><TD>!AZ</TD>\
<TR><TH ALIGN=right>Naming:</TH><TD>!AZ</TD>\
<TR><TH ALIGN=right>Period:</TH><TD>!AZ</TD>\
<TR><TH ALIGN=right>Per-Service:</TH><TD>!AZ</TD>\
<TR><TH ALIGN=right>Per-Service Host Only:</TH><TD>!AZ</TD>\
<TR><TH ALIGN=right>File:</TH><TD>!AZ</TD>\
<TR><TH ALIGN=right VALIGN=top>Exclude Hosts:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Track:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Track Multi-Session:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Track Domain:</TH><TD>!AZ</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>OPCOM</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right>Target:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Admin:</TH><TD>!AZ</TD></TR>\
<TR><TH ALIGN=right>Authorization:</TH><TD>!AZ</TD></TR>\
<TR><TH ALIGN=right>Control:</TH><TD>!AZ</TD></TR>\
<TR><TH ALIGN=right>HTTPd:</TH><TD>!AZ</TD></TR>\
<TR><TH ALIGN=right>ProxyMaint:</TH><TD>!AZ</TD></TR>\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>File Cache</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right>Caching:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Hash Table</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>entries</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>Max Entries:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>files</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>Max Cache Size:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>kBytes</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>Max File Size:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>kBytes</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>Chunk Size:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>kBytes</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>Validate:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>seconds</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>Frequent:</TH><TD COLSPAN=2>\
!UL &nbsp;<FONT SIZE=-1><I>hits, last within</I></FONT>&nbsp; \
!UL &nbsp;<FONT SIZE=-1><I>seconds</I></FONT></TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Timeouts</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right>Input:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>minutes</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>Output:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>minutes</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>No-Progress:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>minutes</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>Keep-Alive:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>seconds</I></FONT></TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Buffer Sizes</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right>DCL <FONT SIZE=-1>SYS$COMMAND</FONT>:</TH>\
<TD>!UL</TD></TR>\n\
<TR><TH ALIGN=right>DCL <FONT SIZE=-1>SYS$OUTPUT</FONT>:</TH>\
<TD>!UL</TD></TR>\n\
<TR><TH ALIGN=right>DCL <FONT SIZE=-1>CGIPLUSIN</FONT>:</TH>\
<TD>!UL</TD></TR>\n\
<TR><TH ALIGN=right>Network Read:</TH><TD>!UL</TD></TR>\n\
<TR><TH ALIGN=right>Network Write:</TH><TD>!UL</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Welcome (Home) Pages</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n";

   static char ReportHostsFao [] =
"</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Hosts</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right>Accept:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Reject:</TH><TD>!AZ</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Server Generated Reports</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right>Server Admin Email:</TH>\
<TD COLSPAN=2>!%%</TD></TD></TR>\n\
<TR><TH ALIGN=right>Server Signature:</TH><TD>!HZ</TD></TR>\n\
<TR><TH ALIGN=right VALIGN=top>Server Report &lt;BODY&gt;:</TH>\
<TD COLSPAN=2><TT>!HZ</TT></TD></TR>\n\
<TR><TH ALIGN=right VALIGN=top>Admin Menu &lt;BODY&gt;:</TH>\
<TD COLSPAN=2><TT>!HZ</TT></TD></TR>\n\
<TR><TH ALIGN=right>Basic Info Only:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>&lt;META&gt; Info:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Error Report Path:</TH><TD COLSPAN=2>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Error Recommend:</TH><TD>!AZ</TD></TR>\n\
</TD></TR>\n\
</TABLE>\n\
</TABLE>\n\
</TD></TR>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Authorization</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right>Cache Valid:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>minutes</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>Revalidate User:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>minutes</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>Revalidate Cookie:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Failure Limit:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>attempts</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>Basic</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Digest:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Digest GET lifetime:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>minutes</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>Digest PUT lifetime:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>minutes</I></FONT></TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Proxy Serving</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right>Proxy Serving:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Cache:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Add &quot;Forwarded: by&quot;:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Report Events To Log:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Report Cache Events To Log:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Host Name Lookup Retry:</TH><TD>!UL</TD>\
<TR><TH ALIGN=right>Host Name Cache Purge:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>hours</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right><U>Cache</U></TH></TR>\n\
<TR><TH ALIGN=right>Max Load:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>kBytes</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>Reload List:</TH><TD>!AZ</TD>\
<TD><FONT SIZE=-1><I>hours</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>Routine Check:</TH><TD>!2ZL</TD>\
<TD><FONT SIZE=-1><I>hour-of-day</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>Purge List:</TH><TD>!AZ</TD>\
<TD><FONT SIZE=-1><I>hours</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right><U>Cache Device</U></TH></TR>\n\
<TR><TH ALIGN=right>Directory Organization:</TH><TD>!AZ</TD>\
<TR><TH ALIGN=right>Usage Check:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>minutes</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>Usage Max:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>percent</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>Reduce By:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>percent</I></FONT></TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Scripting &nbsp;(CGI, DCL & DECnet)</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right>Scripting:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Detach Process:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Process Priority:</TH><TD>!AZ</TD>\
<TD><FONT SIZE=-1><I>server,user</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>Strict CGI Output:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Spawn Authorized Privileges:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Gateway BG:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Soft Limit:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>script processes</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>Hard Limit:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>script processes</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>Zombie Life-Time:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>minutes</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>CGIplus Life-Time:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>minutes</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>DECnet Reuse Life-Time:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>minutes</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>DECnet Connect List Max:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>connections</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>Cleanup HTTPD$SCRATCH Max:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>minutes</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>Cleanup Older-than:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>minutes</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>Script Run-Time:</TH>\
<TD ALIGN=left><U>file-type</U></TD><TD ALIGN=left><U>verb</U></TD></TR>\n";

   static char ReportSsiFao [] =
"</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
</TABLE>\n\
</TD></TR>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Server-Side Includes</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right>SSI:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Exec:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Accesses:</TH><TD>!AZ</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Directory</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right>Access:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Layout:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right VALIGN=top>Listing &lt;BODY&gt;:</TH>\
<TD><NOBR><TT>!HZ</TT></NOBR></TD></TR>\n\
<TR><TH ALIGN=right>HTML Description:</TH><TD>!UL</TD>\
<TD><FONT SIZE=-1><I>lines</I></FONT></TD></TR>\n\
<TR><TH ALIGN=right>&lt;META&gt; Info:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Owner:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Pre-Expired:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Wildcard:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>No Implied Wildcard:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Prot Violations Ignored:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Readme:</TH><TD>!AZ &nbsp;!AZ</TD></TR>\n\
<TR><TH ALIGN=right>Readme Files:</TH>\n";

   static char  ReportIconsFao [] =
"</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH COLSPAN=4>Directory Icons</TH></TR>\n\
<TR><TH>content-type</TH><TH>icon</TH><TH>path</TH>\
<TH>alternate text</TH></TR>\n";

   static char  ReportContentTypeFao [] =
"</TABLE>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH COLSPAN=4>Content-Type</TH></TR>\n\
<TR><TH>suffix</TH><TH>content-type</TH><TH>icon</TH>\
<TH>auto-script</TH><TH>description</TH></TR>\n";

   static char  ContentTypeFao [] =
"<TR><TD>!AZ</TD><TD>!AZ</TD><TD>!AZ</TD><TD>!AZ</TD><TD>!AZ</TD></TR>\n";

   static char  EndPageFao [] =
"</TABLE>\n\
\
</BODY>\n\
</HTML>\n";

   register int  idx;
   register unsigned long  *vecptr;
   register char  *cptr, *sptr, *zptr;
   register struct ContentInfoStruct  *clptr;
   register struct IconStruct  *ilptr;

   int  status,
        ServiceListCount;
   unsigned long  FaoVector [128];
   char  HtmlIconAltText [256],
         IconAltText [256],
         IconPath [256];
   char  *AutoScriptNamePtr,
         *ContentDescriptionPtr;
   struct ContentInfoStruct  ContentType;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ConfigReportNow()\n");

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_ADMIN;
   HTTP_HEADER_200_HTML (rqptr);

   vecptr = FaoVector;
   *vecptr++ = HtmlMetaInfo (rqptr, NULL);
   *vecptr++ = ServerHostPort;
   *vecptr++ = Config.cfServer.AdminBodyTag;
   *vecptr++ = ServerHostPort;
   *vecptr++ = &rqptr->rqTime.Vms64bit;

   status = NetWriteFaol (rqptr, ResponseFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   if (cfptr->ProblemReportLength)
   {
      vecptr = FaoVector;
      *vecptr++ = cfptr->ProblemCount;
      *vecptr++ = (cfptr == &Config);
      *vecptr++ = cfptr->ProblemReportPtr;

      status = NetWriteFaol (rqptr, ProblemReportFao, &FaoVector);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
   }

   cptr = MapVmsPath (cfptr->LoadFileName, rqptr);

   vecptr = FaoVector;

   /* source file */
   *vecptr++ = (cfptr == &Config);
   *vecptr++ = cfptr->LoadFileName;
   *vecptr++ = cptr;
   *vecptr++ = ADMIN_SCRIPT_UPD;
   *vecptr++ = cptr;
   if (cfptr == &Config)
   {
      *vecptr++ = "Loaded:";
      *vecptr++ = &cfptr->LoadBinTime;
   }
   else
   {
      *vecptr++ = "Revised:";
      *vecptr++ = &cfptr->RevBinTime;
   }

   status = NetWriteFaol (rqptr, ReportSourceFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   /************/
   /* services */
   /************/

   if (VMSnok (ServiceReportConfigFromString (rqptr, cfptr)))
      return;

   /***********/
   /* general */
   /***********/

   vecptr = FaoVector;

   /* GMT */
   *vecptr++ = TimeGmtString;
   *vecptr++ = rqptr->rqTime.GmDateTime;

   /* general */
   *vecptr++ = cfptr->cfServer.BusyLimit;
   if (cfptr->cfServer.ListenBacklog)
      *vecptr++ = cfptr->cfServer.ListenBacklog;
   else
      *vecptr++ = DEFAULT_LISTEN_BACKLOG;
   *vecptr++ = cfptr->cfMisc.RequestHistory;
   *vecptr++ = cfptr->cfMisc.ActivityNumberOfDays;
   if (cfptr->cfContent.CharsetDefault[0])
      *vecptr++ = cfptr->cfContent.CharsetDefault;
   else
      *vecptr++ = NotNone;
   REPBOOL_ENDIS (cfptr->cfMisc.DnsLookup)
   REPBOOL_ENDIS (cfptr->cfMisc.MonitorEnabled)
   *vecptr++ = cfptr->cfServer.DefaultPort;
   *vecptr++ = cfptr->cfMisc.StreamLfConversionMaxKbytes;
   *vecptr++ = cfptr->cfScript.DefaultSearch;
   if (cfptr->cfScript.DefaultSearchExcludePtr == NULL)
      *vecptr++ = NotNone;
   else
      *vecptr++ = ConfigCommaList (rqptr,
                     cfptr->cfScript.DefaultSearchExcludePtr, '\r');
   *vecptr++ = cfptr->cfMisc.PutMaxKbytes;
   *vecptr++ = cfptr->cfMisc.PutVersionLimit;
   if (cfptr == &Config)
      *vecptr++ = MapUrlUserNameCacheEntries;
   else
      *vecptr++ = cfptr->cfMisc.MapUserNameCacheEntries;
   if (cfptr == &Config)
      *vecptr++ = PersonaCacheEntries;
   else
      *vecptr++ = cfptr->cfMisc.PersonaCacheEntries;

   /* logging */
   REPBOOL_ENDIS (cfptr->cfLog.Enabled)
   if (cfptr->cfLog.Format[0])
      *vecptr++ = cfptr->cfLog.Format;
   else
      *vecptr++ = NotNone;
   if (cfptr->cfLog.Naming[0])
      *vecptr++ = cfptr->cfLog.Naming;
   else
      *vecptr++ = NotNone;
   if (cfptr->cfLog.Period[0])
      *vecptr++ = cfptr->cfLog.Period;
   else
      *vecptr++ = NotNone;
   REPBOOL_ENDIS (cfptr->cfLog.PerService)
   REPBOOL_ENDIS (cfptr->cfLog.PerServiceHostOnly)
   if (cfptr->cfLog.FileName[0])
      *vecptr++ = cfptr->cfLog.FileName;
   else
      *vecptr++ = NotNone;
   if (cfptr->cfLog.ExcludeHostsPtr == NULL)
      *vecptr++ = NotNone;
   else
      *vecptr++ = ConfigCommaList (rqptr, cfptr->cfLog.ExcludeHostsPtr, '\n');
   REPBOOL_ENDIS (cfptr->cfTrack.Enabled)
   REPBOOL_ENDIS (cfptr->cfTrack.MultiSession)
   if (cfptr->cfTrack.Domain[0])
      *vecptr++ = cfptr->cfTrack.Domain;
   else
      *vecptr++ = ServerOnly;

   /* OPCOM messages */
   *vecptr++ = ConfigOpcomTarget[cfptr->cfOpcom.Index].Name;
   REPBOOL_ENDIS (cfptr->cfOpcom.Messages & OPCOM_ADMIN)
   REPBOOL_ENDIS (cfptr->cfOpcom.Messages & OPCOM_AUTHORIZATION)
   REPBOOL_ENDIS (cfptr->cfOpcom.Messages & OPCOM_CONTROL)
   REPBOOL_ENDIS (cfptr->cfOpcom.Messages & OPCOM_HTTPD)
   REPBOOL_ENDIS (cfptr->cfOpcom.Messages & OPCOM_PROXY_MAINT)

   /* cache */
   REPBOOL_ENDIS (cfptr->cfCache.Enabled)
   *vecptr++ = cfptr->cfCache.HashTableEntries;
   *vecptr++ = cfptr->cfCache.EntriesMax;
   *vecptr++ = cfptr->cfCache.TotalKBytesMax;
   *vecptr++ = cfptr->cfCache.FileKBytesMax;
   *vecptr++ = cfptr->cfCache.ChunkKBytes;
   *vecptr++ = cfptr->cfCache.ValidateSeconds;
   *vecptr++ = cfptr->cfCache.FrequentHits;
   *vecptr++ = cfptr->cfCache.FrequentSeconds;

   /* timeouts */
   *vecptr++ = cfptr->cfTimeout.MinutesInput;
   *vecptr++ = cfptr->cfTimeout.MinutesOutput;
   *vecptr++ = cfptr->cfTimeout.MinutesNoProgress;
   *vecptr++ = cfptr->cfTimeout.SecondsKeepAlive;

   /* buffer sizes */
   if (cfptr == &Config)
   {
      /* in-use values */
      *vecptr++ = DclSysCommandSize;
      *vecptr++ = DclSysOutputSize;
      *vecptr++ = DclCgiPlusInSize;
      *vecptr++ = NetReadBufferSize;
      *vecptr++ = OutputBufferSize;
   }
   else
   {
      /* file values */
      *vecptr++ = cfptr->cfBuffer.SizeDclCommand;
      *vecptr++ = cfptr->cfBuffer.SizeDclOutput;
      *vecptr++ = cfptr->cfBuffer.SizeDclCgiPlusIn;
      *vecptr++ = cfptr->cfBuffer.SizeNetRead;
      *vecptr++ = cfptr->cfBuffer.SizeNetWrite;
   }

   status = NetWriteFaol (rqptr, ReportGeneralFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   /*****************************/
   /* welcome (home page) files */
   /*****************************/

   for (idx = 0; idx < cfptr->cfContent.HomePageCount; idx++)
   {
      status = NetWriteFao (rqptr, "<TR><TD><TT>!HZ</TT></TD></TR>\n",
                            cfptr->cfContent.HomePageArray[idx]);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
   }

   /*********************/
   /* host access, etc. */
   /*********************/

   vecptr = FaoVector;

   if (cfptr->cfServer.AcceptHostsPtr == NULL)
      *vecptr++ = NotNone;
   else
      *vecptr++ = ConfigCommaList (rqptr, cfptr->cfServer.AcceptHostsPtr, ',');

   if (cfptr->cfServer.RejectHostsPtr == NULL)
      *vecptr++ = NotNone;
   else
      *vecptr++ = ConfigCommaList (rqptr, cfptr->cfServer.RejectHostsPtr, ',');

   /* reports */
   if (cfptr->cfServer.AdminEmail[0])
   {
      *vecptr++ = "!HZ";
      *vecptr++ = cfptr->cfServer.AdminEmail;
   }
   else
   {
      *vecptr++ = "!AZ";
      *vecptr++ = NotNone;
   }
   if (cfptr->cfServer.Signature == CONFIG_SERVER_SIGNATURE_ON)
      *vecptr++ = "[enabled]";
   else
   if (cfptr->cfServer.Signature == CONFIG_SERVER_SIGNATURE_EMAIL)
      *vecptr++ = "[enabled] [email]";
   else
      *vecptr++ = "[disabled]";
   *vecptr++ = cfptr->cfServer.ReportBodyTag;
   *vecptr++ = cfptr->cfServer.AdminBodyTag;
   REPBOOL_ENDIS (cfptr->cfReport.BasicOnly)
   REPBOOL_ENDIS (cfptr->cfReport.MetaInfoEnabled)
   if (cfptr->cfReport.ErrorReportPath[0])
      *vecptr++ = cfptr->cfReport.ErrorReportPath;
   else
      *vecptr++ = NotNone;
   REPBOOL_ENDIS (cfptr->cfReport.ErrorRecommend)

   /* authentication */
   *vecptr++ = cfptr->cfAuth.CacheMinutes;
   *vecptr++ = cfptr->cfAuth.RevalidateUserMinutes;
   REPBOOL_ENDIS (cfptr->cfAuth.RevalidateLoginCookie)
   *vecptr++ = cfptr->cfAuth.FailureLimit;
   REPBOOL_ENDIS (cfptr->cfAuth.BasicEnabled)
   REPBOOL_ENDIS (cfptr->cfAuth.DigestEnabled)
   *vecptr++ = cfptr->cfAuth.DigestNonceGetLifeTime;
   *vecptr++ = cfptr->cfAuth.DigestNonceGetLifeTime;

   /* proxy serving */
   REPBOOL_ENDIS (cfptr->cfProxy.ServingEnabled)
   REPBOOL_ENDIS (cfptr->cfProxy.CacheEnabled)
   REPBOOL_ENDIS (cfptr->cfProxy.AddForwardedByEnabled)
   REPBOOL_ENDIS (cfptr->cfProxy.ReportLog)
   REPBOOL_ENDIS (cfptr->cfProxy.ReportCacheLog)
   *vecptr++ = cfptr->cfProxy.HostLookupRetryCount;
   *vecptr++ = cfptr->cfProxy.HostCachePurgeHours;
   *vecptr++ = cfptr->cfProxy.CacheFileKBytesMax;
   if (cfptr->cfProxy.CacheReloadList[0])
      *vecptr++ = cfptr->cfProxy.CacheReloadList;
   else
      *vecptr++ = NotNone;
   *vecptr++ = cfptr->cfProxy.CacheRoutineHourOfDay;
   if (cfptr->cfProxy.CachePurgeList[0])
      *vecptr++ = cfptr->cfProxy.CachePurgeList;
   else
      *vecptr++ = NotNone;
   if (cfptr->cfProxy.CacheDeviceDirOrg == PROXY_CACHE_DIR_ORG_FLAT256)
      *vecptr++ = "flat256";
   else
   if (cfptr->cfProxy.CacheDeviceDirOrg == PROXY_CACHE_DIR_ORG_64X64)
      *vecptr++ = "64x64";
   else
      *vecptr++ = "";
   *vecptr++ = cfptr->cfProxy.CacheDeviceCheckMinutes;
   *vecptr++ = cfptr->cfProxy.CacheDeviceMaxPercent;
   *vecptr++ = cfptr->cfProxy.CacheDevicePurgePercent;

   /* scripting */
   REPBOOL_ENDIS (cfptr->cfScript.Enabled)
   REPBOOL_ENDIS (cfptr->cfScript.DetachProcess)
   *vecptr++ = cfptr->cfScript.DetachProcessPriority;
   REPBOOL_ENDIS (cfptr->cfScript.CgiStrictOutput)
   REPBOOL_ENDIS (cfptr->cfScript.SpawnAuthPriv)
   REPBOOL_ENDIS (cfptr->cfScript.GatewayBg)
   *vecptr++ = cfptr->cfScript.ScriptProcessSoftLimit;
   *vecptr++ = cfptr->cfScript.ScriptProcessHardLimit;
   *vecptr++ = cfptr->cfScript.ZombieLifeTime;
   *vecptr++ = cfptr->cfScript.CgiPlusLifeTime;
   *vecptr++ = cfptr->cfScript.DECnetReuseLifeTime;
   *vecptr++ = cfptr->cfScript.DECnetConnectListMax;
   *vecptr++ = cfptr->cfScript.CleanupScratchMinutesMax;
   *vecptr++ = cfptr->cfScript.CleanupScratchMinutesOld;

   status = NetWriteFaol (rqptr, ReportHostsFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   /****************/
   /* script types */
   /****************/

   if (cfptr->cfScript.RunTimeCount)
   {
      for (idx = 0; idx < cfptr->cfScript.RunTimeCount; idx++)
      {
         vecptr = FaoVector;

         cptr = sptr = cfptr->cfScript.RunTime[idx].String;
         /* length of and location of the file type */
         while (*cptr && *cptr != ';') cptr++;
         *vecptr++ = cptr - sptr;
         *vecptr++ = sptr;
         /*  location of verb */
         cptr += 2;
         *vecptr++ = cptr;

         status = NetWriteFaol (rqptr,
"<TR><TD></TD><TD>!#HF</TD><TD><TT>!HZ</TT></TD><TD></TR>\n",
                     &FaoVector);
         if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
      }
   }
   else
   {
      static char  NotNone [] =
"<TR><TD COLSPAN=2><FONT SIZE=-1><I>(none)</I></FONT></TD></TR>\n";

      status = NetWriteFaol (rqptr, NotNone, NULL);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
   }

   /**********************/
   /* Reports, SSI, etc. */
   /**********************/

   vecptr = FaoVector;

   /* SSI (.shtml) */
   REPBOOL_ENDIS (cfptr->cfSsi.Enabled)
   REPBOOL_ENDIS (cfptr->cfSsi.ExecEnabled)
   REPBOOL_ENDIS (cfptr->cfSsi.AccessesEnabled)

   REPBOOL_ENDIS (cfptr->cfDir.Access)
   if (cfptr->cfDir.DefaultLayout[0])
      *vecptr++ = cfptr->cfDir.DefaultLayout;
   else
      *vecptr++ = NotNone;
   *vecptr++ = cfptr->cfDir.BodyTag;
   *vecptr++ = cfptr->cfDir.DescriptionLines;
   REPBOOL_ENDIS (cfptr->cfDir.MetaInfoEnabled)
   REPBOOL_ENDIS (cfptr->cfDir.OwnerEnabled)
   REPBOOL_ENDIS (cfptr->cfDir.PreExpired)
   REPBOOL_ENDIS (cfptr->cfDir.WildcardEnabled)
   REPBOOL_ENDIS (cfptr->cfDir.NoImpliedWildcard)
   REPBOOL_ENDIS (cfptr->cfDir.NoPrivIgnore)
   REPBOOL_ENDIS (cfptr->cfDir.ReadMeTop | cfptr->cfDir.ReadMeBottom)
   if (cfptr->cfDir.ReadMeTop)
      *vecptr++ = "[top]";
   else
   if (cfptr->cfDir.ReadMeBottom)
      *vecptr++ = "[bottom]";
   else
      *vecptr++ = "";

   status = NetWriteFaol (rqptr, ReportSsiFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   /*********************/
   /* directory (contd) */
   /*********************/

   for (idx = 0; idx < cfptr->cfDir.ReadMeFileCount; idx++)
   {
      status = NetWriteFao (rqptr, "!%%<TD><TT>!AZ</TT></TD></TR>\n",
                            idx ? "<TR><TD></TD>" : "",
                            cfptr->cfDir.ReadMeFileArray[idx]);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFao()", FI_LI);
   }

   /*********/
   /* icons */
   /*********/

   status = NetWriteFaol (rqptr, ReportIconsFao, NULL);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   ilptr = cfptr->cfContent.IconListHeadPtr;
   while (ilptr != NULL)
   {
      vecptr = FaoVector;

      /* first, content type */
      cptr = sptr = (char*)ilptr + cfptr->cfContent.IconStructOverhead;
      while (*cptr && !ISLWS(*cptr)) cptr++;
      /* length of and location of this string */
      *vecptr++ = cptr - sptr;
      *vecptr++ = sptr;

      /* next, image path */
      while (*cptr && ISLWS(*cptr)) cptr++;
      while (*cptr && *cptr != '\"') cptr++;
      if (*cptr) cptr++;
      sptr = cptr;
      while (*cptr && *cptr != '\"') cptr++;
      /* length of and location of this string */
      *vecptr++ = cptr - sptr;
      *vecptr++ = sptr;
      *vecptr++ = cptr - sptr;
      *vecptr++ = sptr;
      if (*cptr) cptr++;

      /* next, the ALT text */
      while (*cptr && ISLWS(*cptr)) cptr++;
      while (*cptr && *cptr != '\"') cptr++;
      if (*cptr) cptr++;
      sptr = cptr;
      while (*cptr && *cptr != '\"') cptr++;
      /* length of and location of this string */
      *vecptr++ = cptr - sptr;
      *vecptr++ = sptr;

      status = NetWriteFaol (rqptr,
"<TR><TD>!#UF</TD><TD ALIGN=center><IMG SRC=\"!#UF\"></TD>\
<TD>!#UF</TD><TD>!#HZ</TD></TR>\n",
                  &FaoVector);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

      ilptr = ilptr->NextPtr;
   }

   /*****************/
   /* content-types */
   /*****************/

   status = NetWriteFaol (rqptr, ReportContentTypeFao, NULL);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   clptr = cfptr->cfContent.ContentInfoListHeadPtr;
   for (;;)
   {
      if (clptr == NULL) break;

      if (clptr->AutoScriptNamePtr[0] == '/')
         AutoScriptNamePtr = clptr->AutoScriptNamePtr;
      else
         AutoScriptNamePtr = "";

      if (clptr->TypeUnknown)
         ContentDescriptionPtr = cfptr->cfContent.ContentTypeDefaultPtr;
      else
         ContentDescriptionPtr = clptr->DescriptionPtr;

      vecptr = &FaoVector;
      *vecptr++ = clptr->SuffixPtr;
      *vecptr++ = clptr->ContentTypePtr;
      *vecptr++ = clptr->IconPtr;
      *vecptr++ = AutoScriptNamePtr;
      *vecptr++ = ContentDescriptionPtr;

      status = NetWriteFaol (rqptr, ContentTypeFao, &FaoVector);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

      clptr = clptr->NextPtr;
   }

   /**************/
   /* end report */
   /**************/

   status = NetWriteFaol (rqptr, EndPageFao, NULL);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
}

/*****************************************************************************/
/*
This function just wraps the revision function, loading a temporary database
if necessary for reporting from the configuration file.
*/ 

ConfigRevise
(
struct RequestStruct *rqptr,
void *NextTaskFunction,
boolean  UseServerDatabase
)
{
   int  status;
   struct ConfigStruct  LocalConfig;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ConfigRevise()\n");

   if (UseServerDatabase)
      ConfigReviseNow (rqptr, &Config);
   else
   {
      memset (&LocalConfig, 0, sizeof(struct ConfigStruct));
      /* indicate it's being used for a report */
      Config.RequestPtr = rqptr;
      Configure (&LocalConfig);
      ConfigReviseNow (rqptr, &LocalConfig);
      ConfigFree (&LocalConfig);
   }

   SysDclAst (NextTaskFunction, rqptr);
}

/*****************************************************************************/
/*
Return a form for the HTTPd server's configuration.  POSTing the form to the
server results in the URL-decoded form as a configuration file.  This function
blocks while executing.
*/ 

ConfigReviseNow
(
struct RequestStruct *rqptr,
struct ConfigStruct *cfptr
)
{
#define SIZEOF_SPECIAL_ICON 256

#define REPBOOL_RADIO(b)\
if (b)\
{\
   *vecptr++ = RadioButtonChecked;\
   *vecptr++ = RadioButtonUnchecked;\
}\
else\
{\
   *vecptr++ = RadioButtonUnchecked;\
   *vecptr++ = RadioButtonChecked;\
}

   static char  ResponseFao [] =
"<HTML>\n\
<HEAD>\n\
!AZ\
<TITLE>HTTPd !AZ ... Configuration</TITLE>\n\
</HEAD>\n\
!AZ\n\
<H2><NOBR>HTTPd !AZ</NOBR></H2>\n\
<H3>Revise Configuration</H3>\n";

   static char  ProblemReportFao [] =
"<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH><FONT COLOR=\"#ff0000\">!UL Report!%s \
!%?At Startup\rDuring Load\r</FONT></TH></TR>\n\
<TR><TD><PRE>!AZ</PRE></TD></TR>\n\
</TABLE>\n";

   static char  ConfigGeneralFao [] =
"<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Source: &quot;!%?Server\rFile\r&quot;</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=0>\n\
<TR>\
<TH ALIGN=right>File:</TH>\
<TD ALIGN=left>!AZ</TD>\
<TD>&nbsp;</TD><TH>[<A HREF=\"!AZ\">View</A>]</TH>\
<TH>[<A HREF=\"!AZ!AZ\">Edit</A>]</TH>\
</TR>\n\
<TR><TH ALIGN=right>!AZ</TH>\
<TD ALIGN=left>!20%W</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
<FORM METHOD=POST ACTION=\"!AZ\">\n\
\
<INPUT TYPE=hidden NAME=x VALUE=\"\
# Configuration:  !AZ&#10;\
#                 !AZ&#10;\
# Last Modified:  !20%W&#10;\
#                 !AZ.\'!AZ\'@!AZ&#10;\
\">\n\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Service</TH></TR>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;# -SERVICE-&#10;\">\n\
<TR><TD>\n\
!%%\
<BR><NOBR><B>Service Not Found URL:</NOBR></B>&nbsp;\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ServiceNotFoundURL]  \">\n\
<INPUT TYPE=text SIZE=40 NAME=ServiceNotFoundURL VALUE=!AZ>\n\
</TD></TR>\n\
</TABLE>\n\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>General</TH></TR>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;&#10;# -GENERAL-&#10;\">\n\
<TR><TD>\n\
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=0>\n\
<TR><TH ALIGN=right>Busy:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[Busy]  \">\n\
<INPUT TYPE=text SIZE=4 NAME=Busy VALUE=!UL>\n\
<FONT SIZE=-1>connections</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Listen Backlog:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ServiceListenBacklog]  \">\n\
<INPUT TYPE=text SIZE=3 NAME=ServiceListenBacklog VALUE=!UL>\n\
<FONT SIZE=-1>connections</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Request History:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[RequestHistory]  \">\n\
<INPUT TYPE=text SIZE=3 NAME=RequestHistory VALUE=!UL>\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Activity History:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ActivityDays]  \">\n\
<INPUT TYPE=text SIZE=3 NAME=ActivityDays VALUE=!UL>\n\
<FONT SIZE=-1>days</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Charset Default:</TH><TD COLSPAN=2>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[CharsetDefault]  \">\n\
<INPUT TYPE=text size=40 NAME=CharsetDefault VALUE=\"!AZ\">\n\
</TD></TR>\n\
<TR><TH ALIGN=right>DNS Lookup:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[DNSLookup]  \">\n\
<INPUT TYPE=radio NAME=DNSLookup VALUE=enabled!AZ>yes\n\
<INPUT TYPE=radio NAME=DNSLookup VALUE=disabled!AZ>no\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Monitor:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[Monitor]  \">\n\
<INPUT TYPE=radio NAME=Monitor VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=Monitor VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
<TR><TH ALIGN=right>IP Port:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[Port]  \">\n\
<INPUT TYPE=text SIZE=5 NAME=Port VALUE=!UL>\n\
<FONT SIZE=-1>(overridden by <I>service</I> directive)</FONT></TD></TR>\n\
<TR><TH ALIGN=right>StreamLF:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[StreamLF]  \">\n\
<INPUT TYPE=text SIZE=3 NAME=StreamLF VALUE=!UL>\n\
<FONT SIZE=-1>kBytes</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Search Script:</TH><TD COLSPAN=2>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[SearchScript]  \">\n\
<INPUT TYPE=text size=40 NAME=SearchScript VALUE=\"!AZ\">\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Search Script Exclude:</TH></TR>\n\
<TR><TD COLSPAN=2>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[SearchScriptExclude]&#10;\">\n\
<TEXTAREA NAME=SearchScriptExclude ROWS=4 COLS=40 NOWRAP>\
!AZ\
</TEXTAREA>\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Put/Post Max Length:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[PutMaxKbytes]  \">\n\
<INPUT TYPE=text SIZE=5 NAME=PutMaxKbytes VALUE=!UL>\n\
<FONT SIZE=-1>kBytes</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Put/Post Files:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[PutVersionLimit]  \">\n\
<INPUT TYPE=text SIZE=5 NAME=PutVersionLimit VALUE=!UL>\n\
<FONT SIZE=-1>version limit</FONT></TD></TR>\n\
</TD></TR>\n\
<TR><TH ALIGN=right>/~username/ Cache Entries:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[MapUserNameCacheEntries]  \">\n\
<INPUT TYPE=text SIZE=3 NAME=MapUserNameCacheEntries VALUE=!UL>\n\
<FONT SIZE=-1>user names</FONT>\
</TD></TR>\n\
<TR><TH ALIGN=right>Persona Cache Entries:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[PersonaCacheEntries]  \">\n\
<INPUT TYPE=text SIZE=3 NAME=PersonaCacheEntries VALUE=!UL>\n\
<FONT SIZE=-1>users</FONT>\
</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Log</TH></TR>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;&#10;# -LOGGING-&#10;\">\n\
<TR><TD>\n\
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=0>\n\
<TR><TH ALIGN=right>Logging:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[Logging]  \">\n\
<INPUT TYPE=radio NAME=Logging VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=Logging VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Format:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[LogFormat]  \">\n\
<INPUT TYPE=text SIZE=10 NAME=LogFormat VALUE=!AZ></TD></TR>\n\
<TR><TH ALIGN=right>Naming:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[LogNaming]  \">\n\
<INPUT TYPE=text SIZE=10 NAME=LogNaming VALUE=!AZ></TD></TR>\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Period:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[LogPeriod]  \">\n\
<INPUT TYPE=text SIZE=10 NAME=LogPeriod VALUE=!AZ></TD></TR>\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Per-Service:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[LogPerService]  \">\n\
<INPUT TYPE=radio NAME=LogPerService VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=LogPerService VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Per-Service Host Only:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[LogPerServiceHostOnly]  \">\n\
<INPUT TYPE=radio NAME=LogPerServiceHostOnly VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=LogPerServiceHostOnly VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
<TR><TH ALIGN=right>File:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[LogFile]  \">\n\
<INPUT TYPE=text SIZE=40 NAME=LogFile VALUE=!AZ></TD></TR>\n\
<TR><TH ALIGN=right>Exclude Hosts:</TH></TR>\n\
<TR><TD COLSPAN=2>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[LogExcludeHosts]&#10;\">\n\
<TEXTAREA NAME=LogExcludeHosts ROWS=4 COLS=40 NOWRAP>\
!AZ\
</TEXTAREA>\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Track:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[Track]  \">\n\
<INPUT TYPE=radio NAME=Track VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=Track VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Track Multi-Session:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[TrackMultiSession]  \">\n\
<INPUT TYPE=radio NAME=TrackMultiSession VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=TrackMultiSession VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Track Domain:</TH><TD COLSPAN=2>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[TrackDomain]  \">\n\
<INPUT TYPE=text size=30 NAME=TrackDomain VALUE=\"!AZ\">\n\
</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>OPCOM</TH></TR>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;&#10;# -OPCOM-&#10;\">\n\
<TR><TD>\n\
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=0>\n\
<TR><TH ALIGN=right>Target:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[OpcomTarget]  \">\n\
<SELECT NAME=OpcomTarget>\n";

   static char  ConfigOpcomTargetFao [] =
"<OPTION VALUE=\"!AZ\"!%? SELECTED\r\r>!AZ\n";

   static char  ConfigOpcomFao [] =
"</SELECT>\n\
<TR><TH ALIGN=right>Admin:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[OpcomAdmin]  \">\n\
<INPUT TYPE=radio NAME=OpcomAdmin VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=OpcomAdmin VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Authorization:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[OpcomAuthorization]  \">\n\
<INPUT TYPE=radio NAME=OpcomAuthorization VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=OpcomAuthorization VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Control:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[OpcomControl]  \">\n\
<INPUT TYPE=radio NAME=OpcomControl VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=OpcomControl VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
<TR><TH ALIGN=right>HTTPd:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[OpcomHTTPd]  \">\n\
<INPUT TYPE=radio NAME=OpcomHTTPd VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=OpcomHTTPd VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
<TR><TH ALIGN=right>ProxyMaint:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[OpcomProxyMaint]  \">\n\
<INPUT TYPE=radio NAME=OpcomProxyMaint VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=OpcomProxyMaint VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Cache</TH></TR>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;&#10;# -CACHE-&#10;\">\n\
<TR><TD>\n\
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=0>\n\
<TR><TH ALIGN=right>Caching:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[Cache]  \">\n\
<INPUT TYPE=radio NAME=Cache VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=Cache VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Hash Table:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[CacheHashTableEntries]  \">\n\
<INPUT TYPE=text SIZE=4 NAME=CacheHashTableEntries VALUE=!UL>\n\
<FONT SIZE=-1>entries</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Max Entries:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[CacheEntriesMax]  \">\n\
<INPUT TYPE=text SIZE=4 NAME=CacheEntriesMax VALUE=!UL>\n\
<FONT SIZE=-1>files</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Max Cache Size:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[CacheTotalKBytesMax]  \">\n\
<INPUT TYPE=text SIZE=4 NAME=CacheTotalKBytesMax VALUE=!UL>\n\
<FONT SIZE=-1>kBytes</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Max File Size:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[CacheFileKBytesMax]  \">\n\
<INPUT TYPE=text SIZE=3 NAME=CacheFileKBytesMax VALUE=!UL>\n\
<FONT SIZE=-1>kBytes</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Chunk Size:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[CacheChunkKBytes]  \">\n\
<INPUT TYPE=text SIZE=3 NAME=CacheChunkKBytes VALUE=!UL>\n\
<FONT SIZE=-1>kBytes</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Validate:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[CacheValidateSeconds]  \">\n\
<INPUT TYPE=text SIZE=3 NAME=CacheValidateSeconds VALUE=!UL>\n\
<FONT SIZE=-1>seconds</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Frequent After:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[CacheFrequentHits]  \">\n\
<INPUT TYPE=text SIZE=3 NAME=CacheFrequentHits VALUE=!UL> \
<FONT SIZE=-1>hits, last within</FONT>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[CacheFrequentSeconds]  \">\n\
<INPUT TYPE=text SIZE=3 NAME=CacheFrequentSeconds VALUE=!UL>\n\
<FONT SIZE=-1>seconds</FONT></TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Timeouts</TH></TR>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;&#10;# -TIMEOUTS-&#10;\">\n\
<TR><TD>\n\
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=0>\n\
<TR><TH ALIGN=right>Input:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[TimeoutInput]  \">\n\
<INPUT TYPE=text SIZE=3 NAME=TimeoutInput VALUE=!UL>\n\
<FONT SIZE=-1>minutes</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Output:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[TimeoutOutput]  \">\n\
<INPUT TYPE=text SIZE=3 NAME=TimeoutOutput VALUE=!UL>\n\
<FONT SIZE=-1>minutes</FONT></TD></TR>\n\
<TR><TH ALIGN=right>No-Progress:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[TimeoutNoProgress]  \">\n\
<INPUT TYPE=text SIZE=3 NAME=TimeoutNoProgress VALUE=!UL>\n\
<FONT SIZE=-1>minutes</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Keep-Alive:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[TimeoutKeepAlive]  \">\n\
<INPUT TYPE=text SIZE=3 NAME=TimeoutKeepAlive VALUE=!UL>\n\
<FONT SIZE=-1>seconds</FONT></TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Buffer Sizes</TH></TR>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;&#10;# -BUFFER SIZES-&#10;\">\n\
<TR><TD>\n\
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=0>\n\
<TR><TH ALIGN=right>DCL <FONT SIZE=-1>SYS$COMMAND</FONT>:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[BufferSizeDclCommand]  \">\n\
<INPUT TYPE=text SIZE=4 NAME=BufferSizeDclCommand VALUE=!UL>\n\
</TD></TR>\n\
<TR><TH ALIGN=right>DCL <FONT SIZE=-1>SYS$OUTPUT</FONT>:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[BufferSizeDclOutput]  \">\n\
<INPUT TYPE=text SIZE=4 NAME=BufferSizeDclOutput VALUE=!UL>\n\
</TD></TR>\n\
<TR><TH ALIGN=right>DCL <FONT SIZE=-1>CGIPLUSIN</FONT>:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[BufferSizeDclCgiPlusIn]  \">\n\
<INPUT TYPE=text SIZE=4 NAME=BufferSizeDclCgiPlusIn VALUE=!UL>\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Network Read:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[BufferSizeNetRead]  \">\n\
<INPUT TYPE=text SIZE=4 NAME=BufferSizeNetRead VALUE=!UL>\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Network Write:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[BufferSizeNetWrite]  \">\n\
<INPUT TYPE=text SIZE=4 NAME=BufferSizeNetWrite VALUE=!UL>\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Note ...</A></TH>\
<TD>adjust with caution!!</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Welcome (index/home pages)</TH></TR>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;&#10;# -INDEX PAGES-&#10;\">\n\
<TR><TD>\n\
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=0>\n\
<TR><TD COLSPAN=2><FONT SIZE=-1>Format: \"file-name.file-type\" \
(e.g. HOME.HTML)</FONT></TD></TR>\n\
<TR><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[Welcome]&#10;\">\n\
<TEXTAREA NAME=Welcome ROWS=5 COLS=40 NOWRAP>";

   static char  ConfigAcceptFao [] = 
"</TEXTAREA>\n\
</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Host Access Control</TH></TR>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;&#10;# -HOST ACCESS-&#10;\">\n\
<TR><TD>\n\
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=0>\n\
<TR><TH>Accept</TH></TR>\n\
<TR><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[Accept]&#10;\">\n\
<TEXTAREA NAME=Accept ROWS=4 COLS=40 NOWRAP>\
!AZ\
</TEXTAREA>\n\
</TD></TR>\n\
<TR><TH>Reject</TH></TR>\n\
<TR><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[Reject]&#10;\">\n\
<TEXTAREA NAME=Reject ROWS=4 COLS=40 NOWRAP>\
!AZ\
</TEXTAREA>\n\
</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Server Generated Reports</TH></TR>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;&#10;# -REPORTS-&#10;\">\n\
<TR><TD>\n\
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=0>\n\
<TR><TH ALIGN=right>Server Admin:</TH><TD COLSPAN=2>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ServerAdmin]  \">\n\
<INPUT TYPE=text size=40 NAME=ServerAdmin VALUE=\"!HZ\">\n\
<FONT SIZE=-1>email</FONT></TD></TR>\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Server Signature:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ServerSignature]  \">\n\
<INPUT TYPE=radio NAME=ServerSignature VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=ServerSignature VALUE=email!AZ>enabled-email\n\
<INPUT TYPE=radio NAME=ServerSignature VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Server Report &lt;BODY&gt;:</TH><TD COLSPAN=2>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ServerReportBodyTag]  \">\n\
<INPUT TYPE=text size=40 NAME=ServerReportBodyTag VALUE=\"!HZ\">\n\
<FONT SIZE=-1>HTML tag</FONT></TD></TR>\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Admin Menu &lt;BODY&gt;:</TH><TD COLSPAN=2>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ServerAdminBodyTag]  \">\n\
<INPUT TYPE=text size=40 NAME=ServerAdminBodyTag VALUE=\"!HZ\">\n\
<FONT SIZE=-1>HTML tag</FONT></TD></TR>\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Basic Info Only:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ReportBasicOnly]  \">\n\
<INPUT TYPE=radio NAME=ReportBasicOnly VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=ReportBasicOnly VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
<TR><TH ALIGN=right>&lt;META&gt; Info:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ReportMetaInfo]  \">\n\
<INPUT TYPE=radio NAME=ReportMetaInfo VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=ReportMetaInfo VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Error Report Path:</TH><TD COLSPAN=2>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ErrorReportPath]  \">\n\
<INPUT TYPE=text size=40 NAME=ErrorReportPath VALUE=\"!AZ\">\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Error Recommend:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ErrorRecommend]  \">\n\
<INPUT TYPE=radio NAME=ErrorRecommend VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=ErrorRecommend VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Authorization</TH></TR>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;&#10;# -AUTHORIZATION-&#10;\">\n\
<TR><TD>\n\
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=0>\n\
<TR><TH ALIGN=right>Cache Valid:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[AuthCacheMinutes]  \">\n\
<INPUT TYPE=text SIZE=3 NAME=AuthCacheMinutes VALUE=!UL>\n\
<FONT SIZE=-1>minutes</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Revalidate User:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[AuthRevalidateUserMinutes]  \">\n\
<INPUT TYPE=text SIZE=3 NAME=AuthRevalidateUserMinutes VALUE=!UL>\n\
<FONT SIZE=-1>minutes</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Revalidate Cookie:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[AuthRevalidateLoginCookie]  \">\n\
<INPUT TYPE=radio NAME=AuthRevalidateLoginCookie VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=AuthRevalidateLoginCookie VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Failure Limit:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[AuthFailureLimit]  \">\n\
<INPUT TYPE=text SIZE=3 NAME=AuthFailureLimit VALUE=!UL>\n\
<FONT SIZE=-1>attempts</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Basic Authorization:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[AuthBasic]  \">\n\
<INPUT TYPE=radio NAME=AuthBasic VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=AuthBasic VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Digest Authorization:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[AuthDigest]  \">\n\
<INPUT TYPE=radio NAME=AuthDigest VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=AuthDigest VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
<TR><TH ALIGN=right>GET nonce lifetime:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[AuthDigestGetLife]  \">\n\
<INPUT TYPE=text SIZE=3 NAME=AuthDigestGetLife VALUE=!UL>\n\
<FONT SIZE=-1>minutes</FONT></TD>\n\
</TD></TR>\n\
<TR><TH ALIGN=right>PUT nonce lifetime:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[AuthDigestPutLife]  \">\n\
<INPUT TYPE=text SIZE=3 NAME=AuthDigestPutLife VALUE=!UL>\n\
<FONT SIZE=-1>minutes</FONT></TD></TR>\n\
</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Proxy Serving</TH></TR>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;&#10;# -PROXY SERVING-&#10;\">\n\
<TR><TD>\n\
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=0>\n\
<TR><TH ALIGN=right>Serving:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ProxyServing]  \">\n\
<INPUT TYPE=radio NAME=ProxyServing VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=ProxyServing VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Cache:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ProxyCache]  \">\n\
<INPUT TYPE=radio NAME=ProxyCache VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=ProxyCache VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Add &quot;Forwarded: by&quot;:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ProxyAddForwardedBy]  \">\n\
<INPUT TYPE=radio NAME=ProxyAddForwardedBy VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=ProxyAddForwardedBy VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Report Events To Log:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ProxyReportLog]  \">\n\
<INPUT TYPE=radio NAME=ProxyReportLog VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=ProxyReportLog VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Report Cache Events To Log:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ProxyReportCacheLog]  \">\n\
<INPUT TYPE=radio NAME=ProxyReportCacheLog VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=ProxyReportCacheLog VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Host Name Lookup Retry:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ProxyHostLookupRetryCount]  \">\n\
<INPUT TYPE=text SIZE=3 NAME=ProxyHostLookupRetryCount VALUE=!UL>\n\
<FONT SIZE=-1>count</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Host Name Cache Purge:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ProxyHostCachePurgeHours]  \">\n\
<INPUT TYPE=text SIZE=3 NAME=ProxyHostCachePurgeHours VALUE=!UL>\n\
<FONT SIZE=-1>hours</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Maximum Load Size:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ProxyCacheFileKBytesMax]  \">\n\
<INPUT TYPE=text SIZE=3 NAME=ProxyCacheFileKBytesMax VALUE=!UL>\n\
<FONT SIZE=-1>kBytes</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Reload List:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ProxyCacheReloadList]  \">\n\
<INPUT TYPE=text SIZE=30 NAME=ProxyCacheReloadList VALUE=\"!AZ\">\n\
<FONT SIZE=-1>hours</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Routine Check:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ProxyCacheRoutineHourOfDay]  \">\n\
<INPUT TYPE=text SIZE=3 NAME=ProxyCacheRoutineHourOfDay VALUE=!2ZL>\n\
<FONT SIZE=-1>hour-of-day (00-23)</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Purge List:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ProxyCachePurgeList]  \">\n\
<INPUT TYPE=text SIZE=30 NAME=ProxyCachePurgeList VALUE=\"!AZ\">\n\
<FONT SIZE=-1>hours</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Device Directory Organization:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ProxyCacheDeviceDirOrg]  \">\n\
<INPUT TYPE=text SIZE=5 NAME=ProxyCacheDeviceDirOrg VALUE=!AZ>\n\
<FONT SIZE=-1>flat256 or 64x64</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Device Usage Check:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ProxyCacheDeviceCheckMinutes]  \">\n\
<INPUT TYPE=text SIZE=3 NAME=ProxyCacheDeviceCheckMinutes VALUE=!UL>\n\
<FONT SIZE=-1>minutes</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Device Usage Max:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ProxyCacheDeviceMaxPercent]  \">\n\
<INPUT TYPE=text SIZE=3 NAME=ProxyCacheDeviceMaxPercent VALUE=!UL>\n\
<FONT SIZE=-1>percent</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Device Reduce By:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[ProxyCacheDevicePurgePercent]  \">\n\
<INPUT TYPE=text SIZE=3 NAME=ProxyCacheDevicePurgePercent VALUE=!UL>\n\
<FONT SIZE=-1>percent</FONT></TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Scripting &nbsp;(CGI, DCL & DECnet)</TH></TR>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;&#10;# -SCRIPTING-&#10;\">\n\
<TR><TD>\n\
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=0>\n\
<TR><TH ALIGN=right>Scripting:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[Scripting]  \">\n\
<INPUT TYPE=radio NAME=Scripting VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=Scripting VALUE=disabled!AZ>disabled\n\
</TD><TD></TD></TR>\n\
<TR><TH ALIGN=right>Detach Process:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[DclDetachProcess]  \">\n\
<INPUT TYPE=radio NAME=DclDetachProcess VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=DclDetachProcess VALUE=disabled!AZ>disabled\n\
</TD><TD></TD></TR>\n\
<TR><TH ALIGN=right>Process Priority:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[DclDetachProcessPriority]  \">\n\
<INPUT TYPE=text SIZE=6 NAME=DclDetachProcessPriority VALUE=\"!AZ\">\n\
<FONT SIZE=-1>server,user</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Strict CGI Output:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[CgiStrictOutput]  \">\n\
<INPUT TYPE=radio NAME=CgiStrictOutput VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=CgiStrictOutput VALUE=disabled!AZ>disabled\n\
</TD><TD></TD></TR>\n\
<TR><TH ALIGN=right>Spawn Authorized Privileges:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[DclSpawnAuthPriv]  \">\n\
<INPUT TYPE=radio NAME=DclSpawnAuthPriv VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=DclSpawnAuthPriv VALUE=disabled!AZ>disabled\n\
</TD><TD></TD></TR>\n\
<TR><TH ALIGN=right>Gateway BG:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[DclGatewayBg]  \">\n\
<INPUT TYPE=radio NAME=DclGatewayBg VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=DclGatewayBg VALUE=disabled!AZ>disabled\n\
</TD><TD></TD></TR>\n\
<TR><TH ALIGN=right>Soft Limit:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[DclSoftLimit]  \">\n\
<INPUT TYPE=text SIZE=3 NAME=DclSoftLimit VALUE=!UL>\n\
<FONT SIZE=-1>script processes</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Hard Limit:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[DclHardLimit]  \">\n\
<INPUT TYPE=text SIZE=3 NAME=DclHardLimit VALUE=!UL>\n\
<FONT SIZE=-1>script processes</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Zombie Life-Time:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[DclZombieLifeTime]  \">\n\
<INPUT TYPE=text SIZE=4 NAME=DclZombieLifeTime VALUE=!UL>\n\
<FONT SIZE=-1>minutes</FONT></TD></TR>\n\
<TR><TH ALIGN=right>CGIplus Lifetime:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[DclCgiPlusLifeTime]  \">\n\
<INPUT TYPE=text SIZE=4 NAME=DclCgiPlusLifeTime VALUE=!UL>\n\
<FONT SIZE=-1>minutes</FONT></TD></TR>\n\
<TR><TH ALIGN=right>DECnet Reuse Life-Time:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[DECnetReuseLifeTime]  \">\n\
<INPUT TYPE=text SIZE=4 NAME=DECnetReuseLifeTime VALUE=!UL>\n\
<FONT SIZE=-1>minutes</FONT></TD></TR>\n\
<TR><TH ALIGN=right>DECnet Connect List Limit:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[DECnetConnectListMax]  \">\n\
<INPUT TYPE=text SIZE=4 NAME=DECnetConnectListMax VALUE=!UL>\n\
<FONT SIZE=-1>connections</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Cleanup HTTPD$SCRATCH Max:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[DclCleanupScratchMinutesMax]  \">\n\
<INPUT TYPE=text SIZE=4 NAME=DclCleanupScratchMinutesMax VALUE=!UL>\n\
<FONT SIZE=-1>minutes</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Cleanup Older-than:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[DclCleanupScratchMinutesOld]  \">\n\
<INPUT TYPE=text SIZE=4 NAME=DclCleanupScratchMinutesOld VALUE=!UL>\n\
<FONT SIZE=-1>minutes</FONT></TD></TR>\n\
<TR><TH ALIGN=left>Script Run-Time:</TH></TR>\n\
<TR><TD COLSPAN=2><FONT SIZE=-1>\
Format: &quot;file-type [SPACE] verb&quot;<BR>\
(e.g. &quot;.PL [SPACE] PERL&quot; or &quot;.PL [SPACE] $PERL_EXE:PERL&quot;)\
</FONT>\
</TD></TR>\n\
<TR><TD COLSPAN=2>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[DclScriptRunTime]&#10;\">\n\
<TEXTAREA NAME=DclScriptRunTime ROWS=5 COLS=60 NOWRAP>";

   static char  ConfigSsiFao [] =
"</TEXTAREA>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Server-Side Includes</TH></TR>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;&#10;# -SSI-&#10;\">\n\
<TR><TD>\n\
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=0>\n\
<TR><TH ALIGN=right>SSI:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[SSI]  \">\n\
<INPUT TYPE=radio NAME=SSI VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=SSI VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Exec:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[SSIexec]  \">\n\
<INPUT TYPE=radio NAME=SSIexec VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=SSIexec VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Access Counting:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[SSIaccesses]  \">\n\
<INPUT TYPE=radio NAME=SSIaccesses VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=SSIaccesses VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Directory (Index of...)</TH></TR>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;&#10;# -DIRECTORY-&#10;\">\n\
<TR><TD>\n\
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=0>\n\
<TR><TH ALIGN=right>Access:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[DirAccess]  \">\n\
<INPUT TYPE=radio NAME=DirAccess VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=DirAccess VALUE=selective!AZ>selective\n\
<INPUT TYPE=radio NAME=DirAccess VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Layout:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[DirLayout]  \">\n\
<INPUT TYPE=text size=30 NAME=DirLayout VALUE=\"!AZ\">\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Listing &lt;BODY&gt;:</TH><TD COLSPAN=2>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[DirBodyTag]  \">\n\
<INPUT TYPE=text size=40 NAME=DirBodyTag VALUE=\"!HZ\">\n\
<FONT SIZE=-1>HTML tag</FONT></TD></TR>\n\
</TD></TR>\n\
<TR><TH ALIGN=right>HTML Description:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[DirDescriptionLines]  \">\n\
<INPUT TYPE=text SIZE=6 NAME=DirDescriptionLines VALUE=!UL>\n\
<FONT SIZE=-1>lines</FONT></TD></TR>\n\
</TD></TR>\n\
<TR><TH ALIGN=right>&lt;META&gt; Info:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[DirMetaInfo]  \">\n\
<INPUT TYPE=radio NAME=DirMetaInfo VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=DirMetaInfo VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Owner:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[DirOwner]  \">\n\
<INPUT TYPE=radio NAME=DirOwner VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=DirOwner VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Pre-Expired:</TH><TD>\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[DirPreExpired]  \">\n\
<INPUT TYPE=radio NAME=DirPreExpired VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=DirPreExpired VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Wildcard:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[DirWildcard]  \">\n\
<INPUT TYPE=radio NAME=DirWildcard VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=DirWildcard VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
<TR><TH ALIGN=right>No Implied Wildcard:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[DirNoImpliedWildcard]  \">\n\
<INPUT TYPE=radio NAME=DirNoImpliedWildcard VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=DirNoImpliedWildcard VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Prot Violations Ignored:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[DirNoPrivIgnore]  \">\n\
<INPUT TYPE=radio NAME=DirNoPrivIgnore VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=DirNoPrivIgnore VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Readme:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[DirReadme]  \">\n\
<INPUT TYPE=radio NAME=DirReadme VALUE=top!AZ>top\n\
<INPUT TYPE=radio NAME=DirReadme VALUE=bottom!AZ>bottom\n\
<INPUT TYPE=radio NAME=DirReadme VALUE=disabled!AZ>none\n\
</TD></TR>\n\
<TR><TH ALIGN=left>Readme Files:</TH></TR>\n\
<TR><TD COLSPAN=2><FONT SIZE=-1>Format: &quot;file-name.file-type&quot; \
(e.g. README.HTML)</FONT></TD></TR>\n\
<TR><TD COLSPAN=2>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[DirReadmeFile]&#10;\">\n\
<TEXTAREA NAME=DirReadmeFile ROWS=5 COLS=40 NOWRAP>";

   static char  ConfigIconsFao [] =
"</TEXTAREA>\n\
</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Icons</TH></TR>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;&#10;# -ICONS-&#10;\">\n\
<TR><TD>\n\
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=0>\n\
<TR><TD COLSPAN=2><FONT SIZE=-1>Format: &quot;icon-path [SPACE] \
alternative-text [SPACE] content-type&quot;</FONT></TD></TR>\n\
<TR><TD COLSPAN=2>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[AddIcon]&#10;\">\n\
<TEXTAREA NAME=AddIcon ROWS=7 COLS=60 NOWRAP>";

   static char  ConfigSpecialIconsFao [] =
"</TEXTAREA>\n\
</TD></TR>\n\
<TR><TH COLSPAN=2>Special Icons</TH></TR>\n\
<TR><TD COLSPAN=2><FONT SIZE=-1>Format: &quot;icon-path [SPACE] \
alternative-text&quot;</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Blank:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[AddBlankIcon]  \">\n\
<INPUT TYPE=text SIZE=40 NAME=AddBlankIcon VALUE=\"!HZ\">\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Directory:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[AddDirIcon]  \">\n\
<INPUT TYPE=text SIZE=40 NAME=AddDirIcon VALUE=\"!HZ\">\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Parent Directory:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[AddParentIcon]  \">\n\
<INPUT TYPE=text SIZE=40 NAME=AddParentIcon VALUE=\"!HZ\">\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Unknown:</TH><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[AddUnknownIcon]  \">\n\
<INPUT TYPE=text SIZE=40 NAME=AddUnknownIcon VALUE=\"!HZ\">\n\
</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n";

   static char  ConfigContentTypesFao [] =
"<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Content Types</TH></TR>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;&#10;# -CONTENT TYPES-&#10;\">\n\
<TR><TD>\n\
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=0>\n\
<TR><TD COLSPAN=2><FONT SIZE=-1>Format: &quot;file-suffix [SPACE] \
content-type[;charset=] [SPACE] auto-script-path <B>or</B> a hyphen [SPACE] \
description (to-end-of-line)&quot;</FONT></TD></TR>\n\
<TR><TD>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[AddType]&#10;\">\n\
<TEXTAREA NAME=AddType ROWS=7 COLS=60 NOWRAP>";

   static char  EndPageFao [] =
"</TEXTAREA>\n\
</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;# End!!&#10;\">\n\
<P><INPUT TYPE=submit VALUE=\" Commit Changes \">\n\
<INPUT TYPE=reset VALUE=\" Reset \">\n\
</FORM>\n\
</BODY>\n\
</HTML>\n";

   static char  RadioButtonChecked [] = " CHECKED",
                RadioButtonUnchecked [] = "";

   register int  idx;
   register unsigned long  *vecptr;
   register char  *cptr, *sptr, *zptr;
   register struct ContentInfoStruct  *clptr;
   register struct IconStruct  *ilptr;

   int  status;
   unsigned short  Length;
   unsigned long  FaoVector [128];
   char  *AutoScriptNamePtr,
         *ContentDescriptionPtr,
         *IconAltPtr,
         *IconAltEndPositionPtr,
         *IconAltStartPositionPtr,
         *IconUrlPtr,
         *IconTypePtr,
         *IconTypePositionPtr,
         *SpecialIconPtr;
   char  Buffer [16384],
         HtmlIconUrl [256],
         Scratch [256],
         SpecialIconBlank [SIZEOF_SPECIAL_ICON],
         SpecialIconDir [SIZEOF_SPECIAL_ICON],
         SpecialIconParent [SIZEOF_SPECIAL_ICON],
         SpecialIconUnknown [SIZEOF_SPECIAL_ICON],
         TimeCurrent [32];
   struct ContentInfoStruct  ContentType;
   struct ConfigStruct  LocalConfig;
   $DESCRIPTOR (BufferDsc, Buffer);
   $DESCRIPTOR (ScratchDsc, Scratch);

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ConfigReviseNow()\n");

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_ADMIN;
   HTTP_HEADER_200_HTML (rqptr);

   vecptr = FaoVector;
   *vecptr++ = HtmlMetaInfo (rqptr, NULL);
   *vecptr++ = ServerHostPort;
   *vecptr++ = Config.cfServer.AdminBodyTag;
   *vecptr++ = ServerHostPort;

   status = NetWriteFaol (rqptr, ResponseFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   if (cfptr->ProblemReportLength)
   {
      vecptr = FaoVector;
      *vecptr++ = cfptr->ProblemCount;
      *vecptr++ = (cfptr == &Config);
      *vecptr++ = cfptr->ProblemReportPtr;

      status = NetWriteFaol (rqptr, ProblemReportFao, &FaoVector);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
   }

   cptr = MapVmsPath (cfptr->LoadFileName, rqptr);

   vecptr = FaoVector;

   /* source information (i.e. from executing server or static file) */
   *vecptr++ = (cfptr == &Config);
   *vecptr++ = cfptr->LoadFileName;
   *vecptr++ = cptr;
   *vecptr++ = ADMIN_SCRIPT_UPD;
   *vecptr++ = cptr;

   if (cfptr == &Config)
   {
      *vecptr++ = "Loaded:";
      *vecptr++ = &cfptr->LoadBinTime;
   }
   else
   {
      *vecptr++ = "Revised:";
      *vecptr++ = &cfptr->RevBinTime;
   }

   /* form action */
   *vecptr++ = cptr;

   /* comments */
   *vecptr++ = ServerHostPort;
   *vecptr++ = SoftwareID;
   *vecptr++ = &rqptr->rqTime.Vms64bit;
   *vecptr++ = rqptr->RemoteUser;
   *vecptr++ = rqptr->rqAuth.RealmDescrPtr;
   *vecptr++ = rqptr->rqNet.ClientHostName;

   /* services */
   if (ServiceLoadFromConfigFile)
   {
      *vecptr++ =
"<CENTER><B>(See &quot;Services&quot; Configuration)</B></CENTER>\n\
<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[Service]&#10;!AZ\">\n";
   }
   else
   {
      *vecptr++ =
"<INPUT TYPE=hidden NAME=x VALUE=\"&#10;[Service]&#10;\">\n\
<TEXTAREA NAME=Service ROWS=5 COLS=60 NOWRAP>\
!AZ\
</TEXTAREA>\n";
   }
   *vecptr++ = ConfigCommaList (rqptr, cfptr->cfServer.ServicePtr, '\n');
   *vecptr++ = cfptr->cfServer.ServiceNotFoundUrl;

   /* general */
   if (cfptr->cfServer.BusyLimit)
      *vecptr++ = cfptr->cfServer.BusyLimit;
   else
      *vecptr++ = DEFAULT_CONCURRENT_CONNECT_MAX;
   if (cfptr->cfServer.ListenBacklog)
      *vecptr++ = cfptr->cfServer.ListenBacklog;
   else
      *vecptr++ = DEFAULT_LISTEN_BACKLOG;
   *vecptr++ = cfptr->cfMisc.RequestHistory;
   *vecptr++ = cfptr->cfMisc.ActivityNumberOfDays;
   *vecptr++ = cfptr->cfContent.CharsetDefault;
   REPBOOL_RADIO (cfptr->cfMisc.DnsLookup)
   REPBOOL_RADIO (cfptr->cfMisc.MonitorEnabled)
   *vecptr++ = cfptr->cfServer.DefaultPort;
   *vecptr++ = cfptr->cfMisc.StreamLfConversionMaxKbytes;
   *vecptr++ = cfptr->cfScript.DefaultSearch;
   *vecptr++ = ConfigCommaList (rqptr,
                  cfptr->cfScript.DefaultSearchExcludePtr, '\n');
   *vecptr++ = cfptr->cfMisc.PutMaxKbytes;
   *vecptr++ = cfptr->cfMisc.PutVersionLimit;
   if (cfptr == &Config)
      *vecptr++ = MapUrlUserNameCacheEntries;
   else
      *vecptr++ = cfptr->cfMisc.MapUserNameCacheEntries;
   if (cfptr == &Config)
      *vecptr++ = PersonaCacheEntries;
   else
      *vecptr++ = cfptr->cfMisc.PersonaCacheEntries;

   /* logging */
   REPBOOL_RADIO (cfptr->cfLog.Enabled)
   *vecptr++ = cfptr->cfLog.Format;
   *vecptr++ = cfptr->cfLog.Naming;
   *vecptr++ = cfptr->cfLog.Period;
   REPBOOL_RADIO (cfptr->cfLog.PerService)
   REPBOOL_RADIO (cfptr->cfLog.PerServiceHostOnly)
   *vecptr++ = cfptr->cfLog.FileName;
   *vecptr++ = ConfigCommaList (rqptr, cfptr->cfLog.ExcludeHostsPtr, '\n');
   REPBOOL_RADIO (cfptr->cfTrack.Enabled)
   REPBOOL_RADIO (cfptr->cfTrack.MultiSession)
   *vecptr++ = cfptr->cfTrack.Domain;

   status = NetWriteFaol (rqptr, ConfigGeneralFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   /* OPCOM messages */
   for (idx = 0; ConfigOpcomTarget[idx].Number >= 0; idx++)
   {
      vecptr = FaoVector;
      *vecptr++ = ConfigOpcomTarget[idx].Name;
      *vecptr++ = (OpcomTarget == ConfigOpcomTarget[idx].Number);
      *vecptr++ = ConfigOpcomTarget[idx].Name;

      status = NetWriteFaol (rqptr, ConfigOpcomTargetFao, &FaoVector);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
   }

   vecptr = FaoVector;

   REPBOOL_RADIO (cfptr->cfOpcom.Messages & OPCOM_ADMIN)
   REPBOOL_RADIO (cfptr->cfOpcom.Messages & OPCOM_AUTHORIZATION)
   REPBOOL_RADIO (cfptr->cfOpcom.Messages & OPCOM_CONTROL)
   REPBOOL_RADIO (cfptr->cfOpcom.Messages & OPCOM_HTTPD)
   REPBOOL_RADIO (cfptr->cfOpcom.Messages & OPCOM_PROXY_MAINT)

   /* cache */
   REPBOOL_RADIO (cfptr->cfCache.Enabled)
   *vecptr++ = cfptr->cfCache.HashTableEntries;
   *vecptr++ = cfptr->cfCache.EntriesMax;
   *vecptr++ = cfptr->cfCache.TotalKBytesMax;
   *vecptr++ = cfptr->cfCache.FileKBytesMax;
   *vecptr++ = cfptr->cfCache.ChunkKBytes;
   *vecptr++ = cfptr->cfCache.ValidateSeconds;
   *vecptr++ = cfptr->cfCache.FrequentHits;
   *vecptr++ = cfptr->cfCache.FrequentSeconds;

   /* timeouts */
   *vecptr++ = cfptr->cfTimeout.MinutesInput;
   *vecptr++ = cfptr->cfTimeout.MinutesOutput;
   *vecptr++ = cfptr->cfTimeout.MinutesNoProgress;
   *vecptr++ = cfptr->cfTimeout.SecondsKeepAlive;

   /* buffer sizes */
   if (cfptr == &Config)
   {
      /* in-use values */
      *vecptr++ = DclSysCommandSize;
      *vecptr++ = DclSysOutputSize;
      *vecptr++ = DclCgiPlusInSize;
      *vecptr++ = NetReadBufferSize;
      *vecptr++ = OutputBufferSize;
   }
   else
   {
      /* file values */
      *vecptr++ = cfptr->cfBuffer.SizeDclCommand;
      *vecptr++ = cfptr->cfBuffer.SizeDclOutput;
      *vecptr++ = cfptr->cfBuffer.SizeDclCgiPlusIn;
      *vecptr++ = cfptr->cfBuffer.SizeNetRead;
      *vecptr++ = cfptr->cfBuffer.SizeNetWrite;
   }

   status = NetWriteFaol (rqptr, ConfigOpcomFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   /*****************************/
   /* welcome (home page) files */
   /*****************************/

   for (idx = 0; idx < cfptr->cfContent.HomePageCount; idx++)
   {
      status = NetWriteFao (rqptr, "!HZ\n", cfptr->cfContent.HomePageArray[idx]);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFao()", FI_LI);
   }

   /********/
   /* more */
   /********/

   vecptr = FaoVector;

   /* accept and reject hosts */
   *vecptr++ = ConfigCommaList (rqptr, cfptr->cfServer.AcceptHostsPtr, '\n');
   *vecptr++ = ConfigCommaList (rqptr, cfptr->cfServer.RejectHostsPtr, '\n');

   *vecptr++ = cfptr->cfServer.AdminEmail;
   if (cfptr->cfServer.Signature == CONFIG_SERVER_SIGNATURE_ON)
      *vecptr++ = " CHECKED";
   else
      *vecptr++ = "";
   if (cfptr->cfServer.Signature == CONFIG_SERVER_SIGNATURE_EMAIL)
      *vecptr++ = " CHECKED";
   else
      *vecptr++ = "";
   if (cfptr->cfServer.Signature == CONFIG_SERVER_SIGNATURE_OFF)
      *vecptr++ = " CHECKED";
   else
      *vecptr++ = "";
   *vecptr++ = cfptr->cfServer.ReportBodyTag;
   *vecptr++ = cfptr->cfServer.AdminBodyTag;
   REPBOOL_RADIO (cfptr->cfReport.BasicOnly)
   REPBOOL_RADIO (cfptr->cfReport.MetaInfoEnabled)
   *vecptr++ = cfptr->cfReport.ErrorReportPath;
   REPBOOL_RADIO (cfptr->cfReport.ErrorRecommend)

   /* authorization */
   *vecptr++ = cfptr->cfAuth.CacheMinutes;
   *vecptr++ = cfptr->cfAuth.RevalidateUserMinutes;
   REPBOOL_RADIO (cfptr->cfAuth.RevalidateLoginCookie)
   *vecptr++ = cfptr->cfAuth.FailureLimit;
   REPBOOL_RADIO (cfptr->cfAuth.BasicEnabled)
   REPBOOL_RADIO (cfptr->cfAuth.DigestEnabled)
   *vecptr++ = cfptr->cfAuth.DigestNonceGetLifeTime;
   *vecptr++ = cfptr->cfAuth.DigestNonceGetLifeTime;

   /* proxy serving */
   REPBOOL_RADIO (cfptr->cfProxy.ServingEnabled)
   REPBOOL_RADIO (cfptr->cfProxy.CacheEnabled)
   REPBOOL_RADIO (cfptr->cfProxy.AddForwardedByEnabled)
   REPBOOL_RADIO (cfptr->cfProxy.ReportLog)
   REPBOOL_RADIO (cfptr->cfProxy.ReportCacheLog)
   *vecptr++ = cfptr->cfProxy.HostLookupRetryCount;
   *vecptr++ = cfptr->cfProxy.HostCachePurgeHours;
   *vecptr++ = cfptr->cfProxy.CacheFileKBytesMax;
   *vecptr++ = cfptr->cfProxy.CacheReloadList;
   *vecptr++ = cfptr->cfProxy.CacheRoutineHourOfDay;
   *vecptr++ = cfptr->cfProxy.CachePurgeList;
   if (cfptr->cfProxy.CacheDeviceDirOrg == PROXY_CACHE_DIR_ORG_FLAT256)
      *vecptr++ = "flat256";
   else
   if (cfptr->cfProxy.CacheDeviceDirOrg == PROXY_CACHE_DIR_ORG_64X64)
      *vecptr++ = "64x64";
   else
      *vecptr++ = "";
   *vecptr++ = cfptr->cfProxy.CacheDeviceCheckMinutes;
   *vecptr++ = cfptr->cfProxy.CacheDeviceMaxPercent;
   *vecptr++ = cfptr->cfProxy.CacheDevicePurgePercent;

   /* scripting */
   REPBOOL_RADIO (cfptr->cfScript.Enabled)
   REPBOOL_RADIO (cfptr->cfScript.DetachProcess)
   *vecptr++ = cfptr->cfScript.DetachProcessPriority;
   REPBOOL_RADIO (cfptr->cfScript.CgiStrictOutput)
   REPBOOL_RADIO (cfptr->cfScript.SpawnAuthPriv)
   REPBOOL_RADIO (cfptr->cfScript.GatewayBg)
   *vecptr++ = cfptr->cfScript.ScriptProcessSoftLimit;
   *vecptr++ = cfptr->cfScript.ScriptProcessHardLimit;
   *vecptr++ = cfptr->cfScript.ZombieLifeTime;
   *vecptr++ = cfptr->cfScript.CgiPlusLifeTime;
   *vecptr++ = cfptr->cfScript.DECnetReuseLifeTime;
   *vecptr++ = cfptr->cfScript.DECnetConnectListMax;
   *vecptr++ = cfptr->cfScript.CleanupScratchMinutesMax;
   *vecptr++ = cfptr->cfScript.CleanupScratchMinutesOld;

   status = NetWriteFaol (rqptr, ConfigAcceptFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   /****************/
   /* script types */
   /****************/

   for (idx = 0; idx < cfptr->cfScript.RunTimeCount; idx++)
   {
      vecptr = FaoVector;

      cptr = sptr = cfptr->cfScript.RunTime[idx].String;
      /* length of and location of the file type */
      while (*cptr && *cptr != ';') cptr++;
      *vecptr++ = cptr - sptr;
      *vecptr++ = sptr;
      /*  location of verb */
      cptr += 2;
      *vecptr++ = cptr;

      status = NetWriteFaol (rqptr, "!#HF !HZ\n", &FaoVector);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
   }

   /********/
   /* more */
   /********/

   vecptr = FaoVector;

   /* SSI (.shtml) */
   REPBOOL_RADIO (cfptr->cfSsi.Enabled)
   REPBOOL_RADIO (cfptr->cfSsi.ExecEnabled)
   REPBOOL_RADIO (cfptr->cfSsi.AccessesEnabled)

   /* directory */
   if (cfptr->cfDir.Access)
   {
      *vecptr++ = " CHECKED";
      *vecptr++ = "";
      *vecptr++ = "";
   }
   else
   if (cfptr->cfDir.AccessSelective)
   {
      *vecptr++ = "";
      *vecptr++ = " CHECKED";
      *vecptr++ = "";
   }
   else
   {
      *vecptr++ = "";
      *vecptr++ = "";
      *vecptr++ = " CHECKED";
   }
   *vecptr++ = cfptr->cfDir.DefaultLayout;
   *vecptr++ = cfptr->cfDir.BodyTag;
   *vecptr++ = cfptr->cfDir.DescriptionLines;
   REPBOOL_RADIO (cfptr->cfDir.MetaInfoEnabled)
   REPBOOL_RADIO (cfptr->cfDir.OwnerEnabled)
   REPBOOL_RADIO (cfptr->cfDir.PreExpired)
   REPBOOL_RADIO (cfptr->cfDir.WildcardEnabled)
   REPBOOL_RADIO (cfptr->cfDir.NoImpliedWildcard)
   REPBOOL_RADIO (cfptr->cfDir.NoPrivIgnore)
   if (cfptr->cfDir.ReadMeTop)
   {
      *vecptr++ = " CHECKED";
      *vecptr++ = "";
      *vecptr++ = "";
   }
   else
   if (cfptr->cfDir.ReadMeBottom)
   {
      *vecptr++ = "";
      *vecptr++ = " CHECKED";
      *vecptr++ = "";
   }
   else
   {
      *vecptr++ = "";
      *vecptr++ = "";
      *vecptr++ = " CHECKED";
   }
   REPBOOL_RADIO (cfptr->cfDir.WildcardEnabled)

   status = NetWriteFaol (rqptr, ConfigSsiFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   /****************/
   /* readme files */
   /****************/

   for (idx = 0; idx < cfptr->cfDir.ReadMeFileCount; idx++)
   {
      status = NetWriteFao (rqptr, "!%%!HZ",
                            idx ? "\n" : "", cfptr->cfDir.ReadMeFileArray[idx]);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFao()", FI_LI);
   }

   /*********/
   /* icons */
   /*********/

   status = NetWriteFaol (rqptr, ConfigIconsFao, NULL);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   SpecialIconBlank[0] = SpecialIconDir[0] = SpecialIconParent[0] =
      SpecialIconUnknown[0] = '\n';
   SpecialIconBlank[1] = SpecialIconDir[1] = SpecialIconParent[1] =
      SpecialIconUnknown[1] = '\0';

   ilptr = cfptr->cfContent.IconListHeadPtr;
   while (ilptr != NULL)
   {
      /*
         Convert from 1 back to 2.

         1.  sprintf ((char*)ilptr + cfptr->cfContent.IconStructOverhead,
                      "%s <IMG ALIGN=top SRC=\"%s\" ALT=\"%s\">",
                      ContentTypePtr, IconUrlPtr, AltTextPtr);

         2.  <URL>[SPACE]<alternative-text>[SPACE]<content-type>
      */

      IconTypePtr = cptr = (char*)ilptr + cfptr->cfContent.IconStructOverhead;
      while (*cptr && !ISLWS(*cptr)) cptr++;
      if (*cptr) cptr++;
      while (*cptr)
      {
         if (*cptr == 'S' && !memcmp (cptr, "SRC=\"", 5))
         {
            cptr += 5;
            IconUrlPtr = cptr;
            while (*cptr && *cptr != '\"') cptr++;
            if (*cptr) cptr++;
         }
         else
         if (*cptr == 'A' && !memcmp (cptr, "ALT=\"", 5))
         {
            cptr += 5;
            IconAltPtr = cptr;
            while (*cptr && *cptr != '\"') cptr++;
            if (*cptr) cptr++;
         }
         else
            cptr++;
      }
      zptr = (sptr = Scratch) + sizeof(Scratch);
      if (ilptr == cfptr->cfContent.IconListHeadPtr) *sptr++ = '\n';
      /* icon URL */
      for (cptr = IconUrlPtr;
           *cptr && *cptr != '\"' && sptr < zptr;
           *sptr++ = *cptr++);
      if (sptr < zptr) *sptr++ = ' ';
      if (sptr < zptr) *sptr++ = ' ';
      /* note the start of alternative text */
      IconAltStartPositionPtr = sptr;
      /* alternative text */
      for (cptr = IconAltPtr; *cptr && *cptr != '\"' && sptr < zptr; cptr++)
      {
         if (*cptr == ' ')
            *sptr++ = '_';
         else
            *sptr++ = *cptr;
      }
      IconAltEndPositionPtr = sptr;
      if (sptr < zptr) *sptr++ = ' ';
      if (sptr < zptr) *sptr++ = ' ';
      /* note position of null-terminated content type in the scratch string */
      IconTypePositionPtr = sptr;
      /* get the content type */
      for (cptr = IconTypePtr;
           *cptr && *cptr != ' ' && sptr < zptr;
           *sptr++ = tolower(*cptr++));
      if (sptr >= zptr)
         Scratch[0] = '\0';
      else
         *sptr = '\0';

      SpecialIconPtr = NULL;
      if (strsame (IconTypePositionPtr, ConfigContentTypeBlank, -1))
      {
         /* replace the blanks with equivalent underscores */
         while (IconAltStartPositionPtr < IconAltEndPositionPtr)
            *IconAltStartPositionPtr++ = '_';
         SpecialIconPtr = SpecialIconBlank;
      }
      else
      if (strsame (IconTypePositionPtr, ConfigContentTypeDir, -1))
         SpecialIconPtr = SpecialIconDir;
      else
      if (strsame (IconTypePositionPtr, ConfigContentTypeParent, -1))
         SpecialIconPtr = SpecialIconParent;
      else
      if (strsame (IconTypePositionPtr, ConfigContentTypeUnknown, -1))
         SpecialIconPtr = SpecialIconUnknown;
      /* do not include content-type in special icon strings */
      if (SpecialIconPtr != NULL) *IconAltEndPositionPtr = '\0';

      if (sptr < zptr) *sptr++ = '\n';
      if (sptr >= zptr)
         strcpy (Scratch, ConfigStringOverflow);
      else
         *sptr = '\0';

      if (SpecialIconPtr == NULL)
      {
         status = NetWriteFao (rqptr, "!HZ", Scratch);
         if (VMSnok (status)) ErrorNoticed (status, "NetWriteFao()", FI_LI);
      }
      else
      {
         zptr = (sptr = SpecialIconPtr) + SIZEOF_SPECIAL_ICON;
         for (cptr = Scratch; *cptr && sptr < zptr; *sptr++ = *cptr++);
         if (sptr >= zptr)
            strcpy (SpecialIconPtr, ConfigStringOverflow);
         else
            *sptr = '\0';
      }

      ilptr = ilptr->NextPtr;
   }

   vecptr = FaoVector;
   *vecptr++ = SpecialIconBlank;
   *vecptr++ = SpecialIconDir;
   *vecptr++ = SpecialIconParent;
   *vecptr++ = SpecialIconUnknown;

   status = NetWriteFaol (rqptr, ConfigSpecialIconsFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   /*****************/
   /* content types */
   /*****************/

   status = NetWriteFaol (rqptr, ConfigContentTypesFao, NULL);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   clptr = cfptr->cfContent.ContentInfoListHeadPtr;
   for (;;)
   {
      if (clptr == NULL) break;

      if (clptr->AutoScriptNamePtr[0] == '/')
         AutoScriptNamePtr = clptr->AutoScriptNamePtr;
      else
         AutoScriptNamePtr = "-";

      if (clptr->TypeUnknown)
         ContentDescriptionPtr = cfptr->cfContent.ContentTypeDefaultPtr;
      else
         ContentDescriptionPtr = clptr->DescriptionPtr;

      zptr = (sptr = Scratch) + sizeof(Scratch);
      if (clptr == cfptr->cfContent.ContentInfoListHeadPtr) *sptr++ = '\n';
      for (cptr = clptr->SuffixPtr;
           *cptr && sptr < zptr;
           *sptr++ = *cptr++);
      if (sptr < zptr) *sptr++ = ' ';
      if (sptr < zptr) *sptr++ = ' ';
      if (strchr (clptr->ContentTypePtr, ';') == NULL)
      {
         for (cptr = clptr->ContentTypePtr;
              *cptr && sptr < zptr;
              *sptr++ = *cptr++);
      }
      else
      {
         if (sptr < zptr) *sptr++ = '\"';
         for (cptr = clptr->ContentTypePtr;
              *cptr && sptr < zptr;
              *sptr++ = *cptr++);
         if (sptr < zptr) *sptr++ = '\"';
      }
      if (sptr < zptr) *sptr++ = ' ';
      if (sptr < zptr) *sptr++ = ' ';
      for (cptr = AutoScriptNamePtr;
           *cptr && sptr < zptr;
           *sptr++ = *cptr++);
      if (sptr < zptr) *sptr++ = ' ';
      if (sptr < zptr) *sptr++ = ' ';
      for (cptr = ContentDescriptionPtr;
           *cptr && sptr < zptr;
           *sptr++ = *cptr++);
      if (sptr < zptr) *sptr++ = '\n';
      if (sptr >= zptr)
         strcpy (Scratch, ConfigStringOverflow);
      else
         *sptr = '\0';

      status = NetWriteFao (rqptr, "!HZ", Scratch);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFao()", FI_LI);

      clptr = clptr->NextPtr;
   }

   /************/
   /* end form */
   /************/

   status = NetWriteFaol (rqptr, EndPageFao, NULL);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
}

/*****************************************************************************/
/*
Takes a comma-separated list of elements and returns a pointer to a dynamically
allocated string with that list reformated for inclusion in HTML.  The
separator is intended to be either a newline or comma character.  If a comma an
extra space is added after each (so that when displayed in HTML it will be
wrapped).  If a carriage-return ('\r'), it is converted into an HTML <BR> (new
line) tag so that each appears on a new line in areas where '\n' doesn't behave
that way.
*/

char* ConfigCommaList
(
struct RequestStruct *rqptr,
char *ListPtr,
char Separator
)
{
   register char  *cptr, *sptr, *zptr;

   int  Length;
   char  ListBuffer [8192],
         HtmlListBuffer [8192];

   /*********/
   /* begin */
   /*********/
   
   if (Debug) fprintf (stdout, "ConfigCommaList() |%s|\n", ListPtr);

   if (ListPtr == NULL) return ("");

   zptr = (sptr = ListBuffer) + sizeof(ListBuffer);
   for (cptr = ListPtr; *cptr && sptr < zptr; cptr++)
   {
      if (*cptr == ',')
         *sptr++ = Separator;
      else
         *sptr++ = *cptr;
      if (Separator == ',' && *cptr == ',' && sptr < zptr) *sptr++ = ' ';
   }
   if (sptr >= zptr) return (ConfigStringOverflow);
   *sptr = '\0';

   /* now HTML-escape */
   zptr = (sptr = HtmlListBuffer) + sizeof(HtmlListBuffer);
   for (cptr = ListBuffer; *cptr && sptr < zptr; cptr++)
   {
      if (*cptr == '\r')
      {
         *sptr++ = '<';
         if (sptr < zptr) *sptr++ = 'B';
         if (sptr < zptr) *sptr++ = 'R';
         if (sptr < zptr) *sptr++ = '>';
      }
      else
      {
         switch (*cptr)
         {
            case '<' :
               if (sptr+4 >= zptr) return (ConfigStringOverflow);
               memcpy (sptr, "&lt;", 4); sptr += 4; break;
            case '>' :
               if (sptr+4 >= zptr) return (ConfigStringOverflow);
               memcpy (sptr, "&gt;", 4); sptr += 4; break;
            case '&' :
               if (sptr+5 >= zptr) return (ConfigStringOverflow);
               memcpy (sptr, "&amp;", 5); sptr += 5; break;
            case '\"' :
               if (sptr+6 >= zptr) return (ConfigStringOverflow);
               memcpy (sptr, "&quot;", 6); sptr += 6; break;
            default :
               *sptr++ = *cptr;
         }
      }

      if (Separator == ',' && *cptr == ',' && sptr < zptr) *sptr++ = ' ';
   }
   if (sptr >= zptr) return (ConfigStringOverflow);
   *sptr = '\0';
   Length = sptr - HtmlListBuffer; 

   sptr = VmGetHeap (rqptr, Length+1);
   memcpy (sptr, HtmlListBuffer, Length+1);
   if (Debug) fprintf (stdout, "|%s|\n", sptr);

   return (sptr);
}

/*****************************************************************************/
