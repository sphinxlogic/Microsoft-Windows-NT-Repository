/*****************************************************************************/
/*
                                 Watch.c

The WATCH facility is a powerful adjunct in server administration.  From the
administration menu it provides an online, real-time, in-browser-window view of
request processing in the running server.   The ability to observe live request
processing on an ad hoc basis, without changing server configuration or
shutting-down/restarting the server process, makes this facility a great
configuration and problem resolution tool.  It allows (amongst other uses)

  o  assessment of mapping rules
  o  assessment of authorization rules
  o  investigation of request processing problems
  o  general observation of server behaviour

A single client per server process can access the WATCH facility at any one
time. The report can be generated for a user-specified number of seconds or
aborted at any time using the browser's stop button.

An event is considered any significant point for which the server code has a
reporting call provided. These have been selected to provide maximum
information with minimum clutter and impact on server performance. Obvious
examples are connection acceptance and closure, request path resolution, error
report generation, network reads and writes, etc.

This module also provides functions to display a process using SHOW PROCESS
/ALL via the DCL.C module, and to delete a process, as well as a function to
"peek" at selected fields in the data structures of any request during
processing (intended more as a diagnosis and development tool).


VERSION HISTORY
---------------
01-OCT-2000  MGD  DCL task changes
26-AUG-2000  MGD  integrate WATCH peek and processing into WatchBegin()
17-JUN-2000  MGD  add "quotas" as a WATCH item,
                  bugfix; WatchCliSettings() storage
28-MAY-2000  MGD  add process quotas, using $getjpi ...lm values from startup
08-MAY-2000  MGD  make path filter a path/track filter
04-MAR-2000  MGD  use NetWriteFaol(), et.al.
02-JAN-2000  MGD  add ODS to WatchPackageInfo()
10-NOV-1999  MGD  use decc$match_wild() for the WatchFilter()
30-OCT-1999  MGD  dignified with a module of it's own (unbundled from ADMIN.C)
*/
/*****************************************************************************/

/* standard C header files */
#include <ctype.h>
#include <errno.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

/* VMS related header files */
#include <descrip.h>
#include <dvidef.h>
#include <jpidef.h>
#include <libdef.h>
#include <libdtdef.h>
#include <prvdef.h>
#include <ssdef.h>
#include <stsdef.h>
#include <syidef.h>

/* application related header files */
#include "wasd.h"

#define WASD_MODULE "WATCH"

/******************/
/* global storage */
/******************/

#define WATCH_FILTER_SIZE 128

int  WatchDisabled,
     WatchEnabled,
     WatchOneShotEnabled,
     WatchItem;

char  WatchClientFilter [WATCH_FILTER_SIZE],
      WatchPathFilter [WATCH_FILTER_SIZE],
      WatchServiceFilter [WATCH_FILTER_SIZE];

struct RequestStruct  *WatchRequestPtr;

char  ErrorWatchAuthNeeded [] =
         "Authorization must be enabled to access WATCH!",
      ErrorWatchBufferOvf [] = "*ERROR* sys$fao() BUFFEROVF",
      ErrorWatchNumber [] = "Not found in current request list.",
      ErrorWatchSelf [] = "Cannot WATCH yourself!",
      ErrorWatchQueryString [] = "WATCH query string problem.",
      ErrorWatchSysFao [] = "*ERROR* sys$fao()";

/********************/
/* external storage */
/********************/

#ifdef DBUG
extern boolean Debug;
#else
#define Debug 0 
#endif

extern boolean  DclPersonaServicesAvailable,
                DclScriptDetachProcess,
                LoggingEnabled,
                OdsExtended,
                OperateWithSysPrv,
                ProtocolHttpsConfigured,
                ProxyCacheEnabled,
                ProxyServingEnabled;

extern int  DclMailboxBytLmRequired,
            HttpdBytLmAvailable,
            HttpdJpiAstLm,
            HttpdJpiBioLm,
            HttpdJpiBytLm,
            HttpdJpiDioLm,
            HttpdJpiEnqLm,
            HttpdJpiFilLm,
            HttpdJpiPgFlQuo,
            HttpdJpiPrcLm,
            HttpdJpiTqLm,
            NetAcceptBytLmRequired,
            NetListenBytLmRequired,
            VmsVersion;

extern unsigned long HttpdProcessId;

extern unsigned long  WorldMask[];

extern char  BuildInfo[],
             CommandLine[],
             ErrorSanityCheck[],
             HttpdUserName[],
             ServerHostPort[],
             SoftwareID[],
             SyiHwName[],
             SyiVersion[],
             TimeGmtString[],
             Utility[];

extern struct ConfigStruct  Config;
extern struct MsgStruct  Msgs;
extern struct ListHeadStruct  RequestList;

/*****************************************************************************/
/*
Return a multi-line string of package identification information including some
quick-and-dirty image analysis.  Open the UCX$IPC_SHR shareable image and read
selected fields to get the image name, identification, and linking date.  Don't
quite know how to get this information using header structures, etc., too busy
to investigate (that's my excuse) ... hence this quick mangle.  Also try to
establish which package is involved by checking for likely logical names.
*/ 

char* WatchPackageInfo (struct RequestStruct *rqptr)

{
   static char  ErrorInfo [32],
                ImageInfoDateString [32];
   static char  *PackageInfoPtr = NULL;

   static $DESCRIPTOR (PackageFaoDsc,
"!AZ (!AZ)\n\
!AZ-TCP/IP !AC !AC (!AZ)\n\
!AZ\
!AZ VMS !AZ (!AZ, !AZ, !AZ!AZ)\n\
$ HTTPD !AZ\n");

   static $DESCRIPTOR (BufferDsc, "");
   static $DESCRIPTOR (DateFaoDsc, "!%D\0");
   static $DESCRIPTOR (ImageInfoDateStringDsc, ImageInfoDateString);
   static $DESCRIPTOR (LnmSystemDsc, "LNM$SYSTEM");
   static $DESCRIPTOR (MultinetDsc, "MULTINET");
   static $DESCRIPTOR (TcpWareDsc, "TCPWARE");
   static $DESCRIPTOR (TcpIpExamplesDsc, "TCPIP$EXAMPLES");
   static $DESCRIPTOR (UcxExamplesDsc, "UCX$EXAMPLES");

   int  status;
   unsigned short  Length;
   unsigned long  *vecptr;
   unsigned long  FaoVector [16];
   char  *PackagePtr,
         *ImageIdentPtr,
         *ImageNamePtr;
   char  Buffer [1024],
         ImageInfo [512];
   FILE  *ImageFile;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "WatchPackageInfo()\n");

   if (PackageInfoPtr != NULL) return (PackageInfoPtr);

   if ((ImageFile =
       fopen ("UCX$IPC_SHR", "r", "shr=get", "dna=SYS$LIBRARY:.EXE"))
       == NULL)
   {
      sprintf (ErrorInfo+1, "%%X%08.08X", vaxc$errno);
      ErrorInfo[0] = strlen(ErrorInfo+1);
      ImageNamePtr = ImageIdentPtr = ErrorInfo;
      memset (&ImageInfo, 0, sizeof(ImageInfo));
   }
   else
   if (!fread (&ImageInfo, sizeof(ImageInfo), 1, ImageFile))
   {
      sprintf (ErrorInfo+1, "%%X%08.08X", vaxc$errno);
      ErrorInfo[0] = strlen(ErrorInfo+1);
      ImageNamePtr = ImageIdentPtr = ErrorInfo;
      memset (&ImageInfo, 0, sizeof(ImageInfo));
   }
   else
   {
#ifdef __ALPHA
      ImageNamePtr = &ImageInfo[0xc8];
      ImageIdentPtr = &ImageInfo[0xf0];
      sys$fao (&DateFaoDsc, 0, &ImageInfoDateStringDsc,
               &ImageInfo[0xc0]);
#else
      Length = *(unsigned short*)ImageInfo;
      ImageNamePtr = &ImageInfo[Length-0x50];
      ImageIdentPtr = &ImageInfo[Length-0x28];
      sys$fao (&DateFaoDsc, 0, &ImageInfoDateStringDsc,
               &ImageInfo[Length-0x18]);
#endif
      if (ImageInfoDateString[0] == ' ') ImageInfoDateString[0] = '0';
   }

   fclose (ImageFile);

   PackagePtr = "TCPware";
   status = sys$trnlnm (0, &LnmSystemDsc, &TcpWareDsc, 0, 0);
   if (Debug) fprintf (stdout, "sys$trnlnm() %%X%08.08X\n", status);
   if (status == SS$_NOLOGNAM)
   {
      PackagePtr = "Multinet";
      status = sys$trnlnm (0, &LnmSystemDsc, &MultinetDsc, 0, 0);
      if (Debug) fprintf (stdout, "sys$trnlnm() %%X%08.08X\n", status);
   }
   if (status == SS$_NOLOGNAM)
   {
      /* Compaq TCP/IP (UC) v5.n-> */
      PackagePtr = "Compaq";
      status = sys$trnlnm (0, &LnmSystemDsc, &TcpIpExamplesDsc, 0, 0);
      if (Debug) fprintf (stdout, "sys$trnlnm() %%X%08.08X\n", status);
   }
   if (status == SS$_NOLOGNAM)
   {
      PackagePtr = "UCX";
      status = sys$trnlnm (0, &LnmSystemDsc, &UcxExamplesDsc, 0, 0);
      if (Debug) fprintf (stdout, "sys$trnlnm() %%X%08.08X\n", status);
   }
   if (status == SS$_NOLOGNAM)
      PackagePtr = "unknown";
   else
   if (VMSnok (status))
      PackagePtr = "sys$trnlnm()_error";

   vecptr = &FaoVector;
   *vecptr++ = SoftwareID;
   *vecptr++ = BuildInfo;
   *vecptr++ = PackagePtr;
   *vecptr++ = ImageNamePtr;
   *vecptr++ = ImageIdentPtr;
   *vecptr++ = ImageInfoDateString;
   *vecptr++ = SesolaVersion();
   *vecptr++ = SyiHwName;
   *vecptr++ = SyiVersion;
#ifdef ODS_EXTENDED
   if (OdsExtended)
      *vecptr++ = "ODS-5 enabled";
   else
   if (VmsVersion >= 72)
      *vecptr++ = "ODS-5 disabled";
   else
      *vecptr++ = "ODS-5 unavailable";
#else /* ODS_EXTENDED */
   *vecptr++ = "ODS-5 unavailable";
#endif /* ODS_EXTENDED */
   *vecptr++ = ENAMEL_NAML_USED;
   *vecptr++ = ENAMEL_FIB_USED;
   if (OperateWithSysPrv)
      *vecptr++ = ", SYSPRV";
   else
      *vecptr++ = "";
   *vecptr++ = CommandLine;

   BufferDsc.dsc$a_pointer = Buffer;
   BufferDsc.dsc$w_length = sizeof(Buffer)-1;

   sys$faol (&PackageFaoDsc, &Length, &BufferDsc, &FaoVector);
   if (VMSnok (status) || status == SS$_BUFFEROVF)
   {
      rqptr->rqResponse.ErrorTextPtr = "sys$faol()";
      ErrorVmsStatus (rqptr, status, FI_LI);
      return ("");
   }
   Buffer[Length] = '\0';

   PackageInfoPtr = VmGet(Length+1);
   strcpy (PackageInfoPtr, Buffer);

   return (PackageInfoPtr);
}                                   

/*****************************************************************************/
/*
Check if the watch facility is already in use, report error if it is.  Provide
form for selection of WATCH parameters.
*/ 

WatchReport
(
struct RequestStruct *rqptr,
void *NextTaskFunction
)
{
   static char  ResponseFao [] =
"<HTML>\n\
<HEAD>\n\
!AZ\
<TITLE>HTTPd !AZ ... WATCH Report</TITLE>\n\
</HEAD>\n\
!AZ\n\
<H2><NOBR>HTTPd !AZ</NOBR></H2>\n\
<H3>WATCH Report</H3>\n\
!20%W\n\
\
<FORM ACTION=\"!AZ\">\n\
<P><TABLE BORDER=1 CELLSPACING=0 CELLPADDING=5>\n\
<TR><TH>Select WATCH Criteria</TH></TR>\n\
<TR><TD>\n\
<TABLE BORDER=0 CELLSPACING=0 CELLPADDING=5>\n\
<TR><TD VALIGN=top><NOBR>\n\
<B><U>Request</U></B>\n\
<BR><INPUT TYPE=checkbox NAME=rqp VALUE=1 CHECKED> Processing\n\
<BR><INPUT TYPE=checkbox NAME=rqh VALUE=1> Header\n\
<BR><INPUT TYPE=checkbox NAME=rqb VALUE=1> Body\n\
<BR><B><U>Response</U></B>\n\
<BR><INPUT TYPE=checkbox NAME=rsp VALUE=1 CHECKED> Processing\n\
<BR><INPUT TYPE=checkbox NAME=rsh VALUE=1> Header\n\
<BR><INPUT TYPE=checkbox NAME=rsb VALUE=1> Body\n\
</NOBR></TD><TD VALIGN=top><NOBR>\n\
<B><U>General</U></B>\n\
<BR><INPUT TYPE=checkbox NAME=con VALUE=1 CHECKED> Connection\n\
<BR><INPUT TYPE=checkbox NAME=map VALUE=1> Mapping\n\
<BR><INPUT TYPE=checkbox NAME=aut VALUE=1> Authorization\n\
<BR><INPUT TYPE=checkbox NAME=err VALUE=1> Error\n\
<BR><INPUT TYPE=checkbox NAME=cgi VALUE=1> CGI\n\
<BR><INPUT TYPE=checkbox NAME=dcl VALUE=1> DCL\n\
<BR><INPUT TYPE=checkbox NAME=dnt VALUE=1> DECnet\n\
</NOBR></TD><TD VALIGN=top><NOBR>\n\
<B><U>Network</U></B>\n\
<BR><INPUT TYPE=checkbox NAME=net VALUE=1> Activity\n\
<BR><INPUT TYPE=checkbox NAME=oct VALUE=1> Data\n\
<BR><B><U>Other</U></B>\n\
<BR><INPUT TYPE=checkbox NAME=tmr VALUE=1> Timer\n\
<BR><INPUT TYPE=checkbox NAME=log VALUE=1> !AZLogging!AZ\n\
<BR><INPUT TYPE=checkbox NAME=ssl VALUE=1> !AZSSL!AZ\n\
<BR><INPUT TYPE=checkbox NAME=quo VALUE=1> Quotas\n\
</NOBR></TD><TD VALIGN=top><NOBR>\n\
<B><U>Proxy</U></B>\n\
!AZ\
<BR><INPUT TYPE=checkbox NAME=pxy VALUE=1> Processing\n\
<BR><INPUT TYPE=checkbox NAME=prh VALUE=1> Request Header\n\
<BR><INPUT TYPE=checkbox NAME=prb VALUE=1> Request Body\n\
<BR><INPUT TYPE=checkbox NAME=psh VALUE=1> Response Header\n\
<BR><INPUT TYPE=checkbox NAME=psb VALUE=1> Response Body\n\
!AZ\
!AZ\
<BR><INPUT TYPE=checkbox NAME=pca VALUE=1> Cache\n\
<BR><INPUT TYPE=checkbox NAME=pcm VALUE=1> Cache Maintenance\n\
!AZ\
</NOBR></TD></TR>\n\
<TR><TD COLSPAN=4>\n\
<INPUT TYPE=text NAME=clf SIZE=40 VALUE=\"*\"> Client Filter\n\
<BR><INPUT TYPE=text NAME=sef SIZE=40 VALUE=\"*\"> Service Filter\n\
<BR><INPUT TYPE=text NAME=paf SIZE=40 VALUE=\"*\"> Path/Track Filter\n\
<BR><SELECT NAME=dul>\n\
<OPTION> 30\n\
<OPTION SELECTED> 60\n\
<OPTION> 120\n\
<OPTION> 300\n\
<OPTION> 600\n\
</SELECT> or\n\
<INPUT TYPE=text NAME=dut SIZE=5 VALUE=\"\"> Seconds Duration\n\
<P><INPUT TYPE=submit VALUE=\" WATCH \">\n\
<INPUT TYPE=reset VALUE=\" reset \">\n\
</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
</FORM>\n\
\
</BODY>\n\
</HTML>\n";

   int  status;
   unsigned long  FaoVector [16];
   unsigned long  *vecptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "WatchReport()\n");

   if (WatchDisabled)
   {
      rqptr->rqResponse.HttpStatus = 403;
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_GENERAL_DISABLED), FI_LI);
      SysDclAst (NextTaskFunction, rqptr);
      return;
   }

   if (!rqptr->RemoteUser[0])
   {
      rqptr->rqResponse.HttpStatus = 403;
      ErrorGeneral (rqptr, ErrorWatchAuthNeeded, FI_LI);
      SysDclAst (NextTaskFunction, rqptr);
      return;
   }

   if (WatchInUse (rqptr))
   {
      SysDclAst (NextTaskFunction, rqptr);
      return;
   }

   HTTP_HEADER_200_HTML (rqptr);

   vecptr = FaoVector;
   *vecptr++ = HtmlMetaInfo (rqptr, NULL);
   *vecptr++ = ServerHostPort;
   *vecptr++ = Config.cfServer.AdminBodyTag;
   *vecptr++ = ServerHostPort;
   *vecptr++ = &rqptr->rqTime.Vms64bit;
   *vecptr++ = ADMIN_REPORT_WATCH;
   if (LoggingEnabled)
   {
      *vecptr++ = "";
      *vecptr++ = "";
   }
   else
   {
      *vecptr++ = "<I>";
      *vecptr++ = "</I>";
   }
   if (ProtocolHttpsConfigured)
   {
      *vecptr++ = "";
      *vecptr++ = "";
   }
   else
   {
      *vecptr++ = "<I>";
      *vecptr++ = "</I>";
   }
   if (ProxyServingEnabled)
   {
      *vecptr++ = "";
      *vecptr++ = "";
   }
   else
   {
      *vecptr++ = "<I>\n";
      *vecptr++ = "</I>\n";
   }
   if (ProxyCacheEnabled)
   {
      *vecptr++ = "";
      *vecptr++ = "";
   }
   else
   {
      *vecptr++ = "<I>\n";
      *vecptr++ = "</I>\n";
   }

   status = NetWriteFaol (rqptr, ResponseFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   SysDclAst (NextTaskFunction, rqptr);
}

/*****************************************************************************/
/*
This function provides both a WATCH-processing report, and a WATCH-peek report.
This can be a WATCH-only report, peek-only, or peek-then-WATCH. If we're going
to use the WATCH-processing report then we have to do it exclusively, check if
the WATCH facility is already in use, report error if it is.  Parse the query
string WATCH parameters.  Report any errors.  Place the parameters into the
WATCH global storage.  This reserves the WATCH facility for this client via the
'WatchRequestPtr' (and indicate this with a flag in the request structure,
which will be detected as the request concludes and the WATCH facility released
for reuse).  Generate a plain-text HTTP header and output a WATCH report
heading.  If a WATCH-peek report is requested call WatchPeek() to generate it. 
For a peek-only report we declarse the next function AST there.  If
WATCH-processing was only/also requested generate a WATCH-processing header
then return BUT do not declare any AST to continue processing.  The client will
just "hang" there receiving output from WatchThis() via the structure pointed
to by 'WatchRequestPtr'.  Can be used to WATCH all new requests (matching any
filter criteria of course) or in a "one-shot" mode where a single request is
selected to display all categories at any point during it's processing.
*/ 

WatchBegin
(
struct RequestStruct *rqptr,
void *NextTaskFunction
)
{
   static char  ResponseFao [] =
"!20%D  WATCH REPORT  !AZ\n\
!#*-\n\
!AZ\
!AZ\n\
!%%\
!%%";

   static char  ResponseWatchingFao [] =
"|Time_______|Module__|Line|Item|Category|Event...|\n";

   static char  DummyReadBuffer [32];

   boolean  DoPeek,
            DoWatch;
   int  status,
        ConnectNumber,
        DurationSeconds,
        WatchCategories;
   char  *cptr, *qptr, *sptr, *zptr;
   char  Buffer [2048],
         CategoryList [512],
         ClientFilter [WATCH_FILTER_SIZE],
         FieldName [256],
         FieldValue [WATCH_FILTER_SIZE],
         PathFilter [WATCH_FILTER_SIZE],
         ServiceFilter [WATCH_FILTER_SIZE];
   unsigned short  Length;
   unsigned long  Category;
   unsigned long  *vecptr;
   unsigned long  FaoVector [64];
   struct ListEntryStruct  *leptr;
   struct RequestStruct  *rqeptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "WatchBegin()\n");

   if (WatchDisabled)
   {
      rqptr->rqResponse.HttpStatus = 403;
      ErrorGeneral (rqptr, MsgFor(rqptr,MSG_GENERAL_DISABLED), FI_LI);
      SysDclAst (NextTaskFunction, rqptr);
      return;
   }

   if (!rqptr->RemoteUser[0])
   {
      rqptr->rqResponse.HttpStatus = 403;
      ErrorGeneral (rqptr, ErrorWatchAuthNeeded, FI_LI);
      SysDclAst (NextTaskFunction, rqptr);
      return;
   }

   if (WatchInUse (rqptr))
   {
      SysDclAst (NextTaskFunction, rqptr);
      return;
   }

   ConnectNumber = DurationSeconds = WatchCategories = 0;
   ClientFilter[0] = PathFilter[0] = ServiceFilter[0] = '\0';
   DoPeek = DoWatch = false;
   if (rqptr->rqHeader.QueryStringLength)
   {
      qptr = rqptr->rqHeader.QueryStringPtr;
      while (*qptr)
      {
         qptr = ParseQueryField (rqptr, qptr,
                                 FieldName, sizeof(FieldName),
                                 FieldValue, sizeof(FieldValue),
                                 FI_LI);
         if (strsame (FieldName, "at", -1) && FieldValue[0])
         {
            DoPeek = true;
            ConnectNumber = strtol (FieldValue, NULL, 10);
            if (Debug) fprintf (stdout, "ConnectNumber: %d\n", ConnectNumber);
         }
         else
         if (strsame (FieldName, "this", -1) && FieldValue[0])
         {
            WatchCategories = WATCH_ONE_SHOT;
            ConnectNumber = strtol (FieldValue, NULL, 10);
            if (Debug) fprintf (stdout, "ConnectNumber: %d\n", ConnectNumber);
         }
         else
         if (strsame (FieldName, "aut", -1) && FieldValue[0])
            WatchCategories |= WATCH_AUTH;
         else
         if (strsame (FieldName, "cgi", -1) && FieldValue[0])
            WatchCategories |= WATCH_CGI;
         else
         if (strsame (FieldName, "con", -1) && FieldValue[0])
            WatchCategories |= WATCH_CONNECT;
         else
         if (strsame (FieldName, "dcl", -1) && FieldValue[0])
            WatchCategories |= WATCH_DCL;
         else
         if (strsame (FieldName, "dnt", -1) && FieldValue[0])
            WatchCategories |= WATCH_DECNET;
         else
         if (strsame (FieldName, "err", -1) && FieldValue[0])
            WatchCategories |= WATCH_ERROR;
         else
         if (strsame (FieldName, "log", -1) && FieldValue[0])
            WatchCategories |= WATCH_LOG;
         else
         if (strsame (FieldName, "map", -1) && FieldValue[0])
            WatchCategories |= WATCH_MAPPING;
         else
         if (strsame (FieldName, "net", -1) && FieldValue[0])
            WatchCategories |= WATCH_NETWORK;
         else
         if (strsame (FieldName, "oct", -1) && FieldValue[0])
            WatchCategories |= WATCH_NETWORK_OCTETS;
         else
         if (strsame (FieldName, "pxy", -1) && FieldValue[0])
            WatchCategories |= WATCH_PROXY;
         else
         if (strsame (FieldName, "pca", -1) && FieldValue[0])
            WatchCategories |= WATCH_PROXY_CACHE;
         else
         if (strsame (FieldName, "pcm", -1) && FieldValue[0])
            WatchCategories |= WATCH_PROXY_CACHE_MNT;
         else
         if (strsame (FieldName, "prh", -1) && FieldValue[0])
            WatchCategories |= WATCH_PROXY_REQU_HDR;
         else
         if (strsame (FieldName, "prb", -1) && FieldValue[0])
            WatchCategories |= WATCH_PROXY_REQU_BDY;
         else
         if (strsame (FieldName, "psh", -1) && FieldValue[0])
            WatchCategories |= WATCH_PROXY_RESP_HDR;
         else
         if (strsame (FieldName, "psb", -1) && FieldValue[0])
            WatchCategories |= WATCH_PROXY_RESP_BDY;
         else
         if (strsame (FieldName, "quo", -1) && FieldValue[0])
            WatchCategories |= WATCH_QUOTAS;
         else
         if (strsame (FieldName, "rqp", -1) && FieldValue[0])
            WatchCategories |= WATCH_REQUEST;
         else
         if (strsame (FieldName, "rqb", -1) && FieldValue[0])
            WatchCategories |= WATCH_REQUEST_BODY;
         else
         if (strsame (FieldName, "rqh", -1) && FieldValue[0])
            WatchCategories |= WATCH_REQUEST_HEADER;
         else
         if (strsame (FieldName, "rsp", -1) && FieldValue[0])
            WatchCategories |= WATCH_RESPONSE;
         else
         if (strsame (FieldName, "rsb", -1) && FieldValue[0])
            WatchCategories |= WATCH_RESPONSE_BODY;
         else
         if (strsame (FieldName, "rsh", -1) && FieldValue[0])
            WatchCategories |= WATCH_RESPONSE_HEADER;
         else
         if (strsame (FieldName, "ssl", -1) && FieldValue[0])
            WatchCategories |= WATCH_SESOLA;
         else
         if (strsame (FieldName, "tmr", -1) && FieldValue[0])
            WatchCategories |= WATCH_TIMER;
         else
         if (strsame (FieldName, "clf", -1))
            strcpy (ClientFilter, FieldValue);
         else
         if (strsame (FieldName, "paf", -1))
            strcpy (PathFilter, FieldValue);
         else
         if (strsame (FieldName, "sef", -1))
            strcpy (ServiceFilter, FieldValue);
         else
         if (strsame (FieldName, "dul", -1) ||
             strsame (FieldName, "dut", -1) ||
             strsame (FieldName, "sec", -1) ||
             strsame (FieldName, "seconds", -1))
         {
            for (cptr = FieldValue; *cptr && !isdigit(*cptr); cptr++);
            if (*cptr) DurationSeconds = atoi (cptr);
         }
         else
         {
            rqptr->rqResponse.HttpStatus = 403;
            ErrorGeneral (rqptr, ErrorWatchQueryString, FI_LI);
            SysDclAst (NextTaskFunction, rqptr);
            return;
         }
      }
   }
   if (WatchCategories) DoWatch = true;

   if (!DurationSeconds) DurationSeconds = WATCH_ONE_SHOT_DEFAULT_SECONDS;

   if (!DoPeek && !DoWatch)
   {
      rqptr->rqResponse.HttpStatus = 403;
      ErrorGeneral (rqptr, ErrorWatchQueryString, FI_LI);
      SysDclAst (NextTaskFunction, rqptr);
      return;
   }

   if (ConnectNumber)
   {
      /* find this connection number in the current request list */
      for (leptr = RequestList.HeadPtr; leptr != NULL; leptr = leptr->NextPtr)
      {
         rqeptr = (struct RequestStruct*)leptr;
         if (Debug)
            fprintf (stdout, "ConnectNumber: %d\n", rqeptr->ConnectNumber);
         if (rqeptr->ConnectNumber == ConnectNumber) break;
      }
      if (leptr == NULL)
      {
         rqptr->rqResponse.HttpStatus = 400;
         ErrorGeneral (rqptr, ErrorWatchNumber, FI_LI);
         SysDclAst (NextTaskFunction, rqptr);
         return;
      }
      if (rqeptr == rqptr)
      {
         rqptr->rqResponse.HttpStatus = 400;
         ErrorGeneral (rqptr, ErrorWatchSelf, FI_LI);
         SysDclAst (NextTaskFunction, rqptr);
         return;
      }
      if (WatchCategories == WATCH_ONE_SHOT)
      {
         rqeptr->WatchItem = WATCH_ONE_SHOT_ITEM;
         if (rqeptr->DclTaskPtr != NULL)
            rqeptr->DclTaskPtr->WatchItem = WATCH_ONE_SHOT_ITEM;
         if (rqeptr->ProxyTaskPtr != NULL)
            rqeptr->ProxyTaskPtr->WatchItem = WATCH_ONE_SHOT_ITEM;
      }
   }

   if (!ClientFilter[0]) strcpy (ClientFilter, "*");
   if (!PathFilter[0]) strcpy (PathFilter, "*");
   if (!ServiceFilter[0]) strcpy (ServiceFilter, "*");

   if (WatchCategories == WATCH_ONE_SHOT)
      strcpy (CategoryList, "ALL");
   else
   {
      zptr = (sptr = CategoryList) + 80;
      for (Category = 1; Category; Category = Category << 1)
      {
         if ((cptr = WatchCategory (WatchCategories & Category)) != NULL)
         {
            if (sptr > CategoryList)
            {
               *sptr++ = ',';
               if (sptr > zptr)
               {
                  zptr = sptr + 80;
                  *sptr++ = '\n';
               }
               else
                  *sptr++ = ' ';
            }
            while (*cptr) *sptr++ = tolower(*cptr++);
         }
      }
      *sptr = '\0';
   }
   if (Debug)
      fprintf (stdout, "%08.08X |%s| %d |%s|%s|%s|\n",
               WatchCategories, CategoryList, DurationSeconds,
               ClientFilter, PathFilter, ServiceFilter);

   if (DoWatch)
   {
      /* now we grab the WATCH facility */
      WatchRequestPtr = rqptr;
      WatchEnabled = WatchCategories;
      WatchItem = 0;
      strcpy (WatchClientFilter, ClientFilter);
      strcpy (WatchPathFilter, PathFilter);
      strcpy (WatchServiceFilter, ServiceFilter);

      /* make sure we get the duration we asked for! */
      rqptr->rqTmr.OutputCount =
         rqptr->rqTmr.NoProgressCount =
         rqptr->rqTmr.NoProgressSeconds = DurationSeconds;
   }

   /* generate a WATCH report header */
   rqptr->rqResponse.PreExpired = PRE_EXPIRE_WATCH;
   HTTP_HEADER_200_PLAIN (rqptr);

   vecptr = FaoVector;
   *vecptr++ = 0;
   *vecptr++ = ServerHostPort;
   *vecptr++ = 36 + strlen(ServerHostPort);
   *vecptr++ = WatchPackageInfo(rqptr);
   *vecptr++ = WatchServerQuotas(rqptr);

   if (DclScriptDetachProcess)
      *vecptr++ = "";
   else
   {
      *vecptr++ =
"BYTLM-available:!UL BYTLM-per-subproc:!%% (approx !%% subprocesses) \
BYTLM-net-accept:!UL BYTLM-net-listen:!UL\n";
      *vecptr++ = HttpdBytLmAvailable;
      if (DclMailboxBytLmRequired)
      {
         *vecptr++ = "!UL";
         *vecptr++ = DclMailboxBytLmRequired;
         *vecptr++ = "!UL";
         *vecptr++ = (HttpdBytLmAvailable -
                        (NetAcceptBytLmRequired * Config.cfServer.BusyLimit)) /
                     DclMailboxBytLmRequired;
      }
      else
      {
         *vecptr++ = "?";
         *vecptr++ = "?";
      }
      *vecptr++ = NetAcceptBytLmRequired;
      *vecptr++ = NetListenBytLmRequired;
   }

   if (DoWatch && !DoPeek)
   {
      *vecptr++ =
"Watching: !AZ (!SL)\n\
Client: \"!AZ\" Service: \"!AZ\" Path: \"!AZ\"\n";
      *vecptr++ = CategoryList;
      *vecptr++ = WatchCategories;
      *vecptr++ = WatchClientFilter;
      *vecptr++ = WatchServiceFilter;
      *vecptr++ = WatchPathFilter;
   }
   else
      *vecptr++ = "";

   status = WriteFaol (Buffer, sizeof(Buffer), &Length, ResponseFao,
                       &FaoVector);
   if (VMSnok (status) || status == SS$_BUFFEROVF)
      ErrorNoticed (status, "WriteFaol()", FI_LI);
   NetWrite (rqptr, 0, Buffer, Length);

   if (DoPeek) WatchPeek (rqptr, rqeptr);

   if (!DoWatch)
   {
      SysDclAst (NextTaskFunction, rqptr);
      return;
   }

   /* go on to generate a WATCH processing report */
   NetWrite (rqptr, 0, ResponseWatchingFao, sizeof(ResponseWatchingFao)-1);

   NetRead (rqptr, &WatchDummyReadAst,
            DummyReadBuffer, sizeof(DummyReadBuffer));

   /* the request now just "hangs", reading WATCH plain-text output! */
}

/*****************************************************************************/
/*
Check and report if the WATCH facility is already being used.
*/ 

boolean WatchInUse (struct RequestStruct *rqptr)

{
   int  status;
   unsigned short  Length;
   unsigned long  *vecptr;
   unsigned long  FaoVector [8];
   char  Buffer [256];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "WatchInUse()\n");

   if (WatchRequestPtr == NULL && !WatchEnabled) return (false);

   vecptr = FaoVector;
   if (WatchRequestPtr == NULL)
      *vecptr++ = "/WATCH";
   else
   {
      *vecptr++ = "!AZ@!AZ";
      *vecptr++ = WatchRequestPtr->RemoteUser;
      *vecptr++ = WatchRequestPtr->ServicePtr->ClientHostName;
   }

   status = WriteFaol (Buffer, sizeof(Buffer), &Length,
                       "WATCH is currently in use by !%%", &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "WriteFaol()", FI_LI);

   Buffer[Length] = '\0';
   rqptr->rqResponse.HttpStatus = 403;
   ErrorGeneral (rqptr, Buffer, FI_LI);
   return (true);
}                                   

/*****************************************************************************/
/*
Request using the WATCH facility drops the connection.  Release WATCH.
*/ 

WatchEnd (struct RequestStruct *rqptr)

{

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "WatchEnd()\n");

   if (WatchRequestPtr != rqptr)
      ErrorExitVmsStatus (SS$_BUGCHECK, ErrorSanityCheck, FI_LI);

   WatchRequestPtr = NULL;
   WatchEnabled = WatchItem = 0;
   WatchClientFilter[0] =
      WatchPathFilter[0] =
      WatchServiceFilter[0] = '\0';
}                                   

/*****************************************************************************/
/*
The WATCH client concluding the watching can only be detected via a break in
connection which in a quiescent system (no requests being processed) can in
turn only be detected by a broken network read I/O.  This dummy read ASTs to
here where the status can be checked and appropriate action taken.
*/ 

WatchDummyReadAst (struct RequestStruct *rqptr)

{
   static char  DummyReadBuffer [32];

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout,
         "WatchDummyReadAst() NetReadIOsb.Status %%X%08.08X .Count %d\n",
         rqptr->rqNet.ReadIOsb.Status, rqptr->rqNet.ReadIOsb.Count);

   if (VMSnok (rqptr->rqNet.ReadIOsb.Status))
   {
      RequestEnd (rqptr);
      return;
   }

   /* just in case it wasn't an error! */
   NetRead (rqptr, &WatchDummyReadAst,
            DummyReadBuffer, sizeof(DummyReadBuffer));
}                                   

/*****************************************************************************/
/*
Filter requests WATCHed on the basis of originating client and/or request
contents (service connected, request path).  Return true if the request should
be WATCHed, false if not.
*/ 

boolean WatchFilter
(
char *ClientHostName,
char *ClientHostAddress,
char *RequestSchemeName,
char *ServerHostPort,
char *PathInfo,
char *TrackId
)
{
   char  *cptr, *sptr;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "WatchFilter() |%s|%s|%s|\n",
               WatchClientFilter, WatchServiceFilter,
               WatchPathFilter);

   /* this can occur if ASTs are delivered after WATCH use is discontinued */
   if (!WatchEnabled) return (false);

   if (ClientHostName != NULL || ClientHostAddress != NULL)
   {
      /* filter on client host name/address */
      if (*(unsigned short*)WatchClientFilter != '*\0')
      {
         if (isdigit(*(sptr = WatchClientFilter)))
            cptr = ClientHostAddress;
         else
            cptr = ClientHostName;
         if (Debug) fprintf (stdout, "cptr |%s|\n", cptr);
         if (cptr == NULL) return (true);
         if (Debug) fprintf (stdout, "cptr |%s| sptr |%s|\n", cptr, sptr);
         if (!decc$match_wild (cptr, sptr)) return (false);
      }
   }

   if (ServerHostPort != NULL)
   {
      /* filter on service */
      if (Debug)
         fprintf (stdout, "ServerHostPort |%s|%s|\n",
                  RequestSchemeName, ServerHostPort);
      if (*(unsigned short*)WatchServiceFilter != '*\0')
      {
         sptr = WatchServiceFilter;
         if (!memcmp (sptr, "http:", 5))
         {
            if (strcmp (RequestSchemeName, "http:")) return (false);
            sptr += 5;
            while (*sptr == '/') sptr++;
         }
         else
         if (!memcmp (sptr, "https:", 6))
         {
            if (strcmp (RequestSchemeName, "https:")) return (false);
            sptr += 6;
            while (*sptr == '/') sptr++;
         }
         cptr = ServerHostPort;
         if (Debug) fprintf (stdout, "cptr |%s| sptr |%s|\n", cptr, sptr);
         if (!decc$match_wild (cptr, sptr)) return (false);
      }
   }

   if (PathInfo != NULL)
   {
      /* filter on path */
      if (Debug) fprintf (stdout, "PathInfo |%s|\n", PathInfo);
      if (*(unsigned short*)(sptr = WatchPathFilter) != '*\0')
      {
         if (Config.cfTrack.Enabled)
         {
            if (*sptr != '/' && *sptr != '*' &&
                !isalpha(*sptr) && TrackId != NULL)
            {
               sptr++;
               cptr = TrackId;
            }
            else
               cptr = PathInfo;
         }
         else
            cptr = PathInfo;
         if (Debug) fprintf (stdout, "cptr |%s| sptr |%s|\n", cptr, sptr);
         if (!decc$match_wild (cptr, sptr)) return (false);
      }
   }

   return (true);
}                                   

/*****************************************************************************/
/*
VARIABLE LENGTH ARGUMENT LIST. Function to provide a formatted WATCH entry,
with trailing information from the caller. 'ReportFormat' parameter must be in
a sys$fao() acceptable format and sufficient variable number parameters be
supplied to satisfy any FAO directives in that format string. The report line
is then generated and output to either 'stdout' (the server process log if
/WATCH= qualifier was used) or to the request structure pointed to by the
gloabl storage 'WatchRequestPtr' (if a request-based WATCH is in use).
*/ 

WatchThis
(
struct RequestStruct *rqptr,
char *SourceModuleName,
int SourceLineNumber,
int Category,
char *ReportFormat,
...
)
{

   static char  BufferFao [] = "|!%T !8AZ !4ZL !4ZL !8AZ !%%|\n";
   static boolean  WatchedQuotas;

   int  status,
        argcnt;
   unsigned short  Length;
   unsigned long  *vecptr;
   unsigned long  FaoVector [64];
   char  *cptr, *sptr;
   char  Buffer [2048],
         CategoryString [128];
   va_list  argptr;

   /*********/
   /* begin */
   /*********/

   va_count (argcnt);

   if (Debug)
      fprintf (stdout, "WatchThis() %s %d |%s| %d\n",
               SourceModuleName, SourceLineNumber, ReportFormat, argcnt);

   /* this can occur if ASTs are delivered after WATCH use is discontinued */
   if (!WatchEnabled) return;

   if ((WatchEnabled & WATCH_QUOTAS) && 
       ((WatchEnabled & WATCH_ONE_SHOT) != WATCH_ONE_SHOT) &&
       (Category & (WATCH_CONNECT | WATCH_REQUEST |
                    WATCH_RESPONSE | WATCH_PROXY)) &&
       !WatchedQuotas)
   {
      WatchedQuotas = true;
      WatchThis (rqptr, FI_LI, WATCH_QUOTAS, 
                 "!AZ", WatchServerQuotas (rqptr));
      WatchedQuotas = false;
   }

   if ((cptr = WatchCategory (Category)) == NULL) cptr = "????????";
   sptr = CategoryString;
   while (*cptr && *cptr != ' ') *sptr++ = *cptr++;
   *sptr = '\0';

   vecptr = FaoVector;
   *vecptr++ = 0;
   *vecptr++ = SourceModuleName;
   *vecptr++ = SourceLineNumber;
   if (rqptr == NULL)
      *vecptr++ = -1;
   else
   if (!rqptr->WatchItem)
      *vecptr++ = -1;
   else
      *vecptr++ = rqptr->WatchItem % 10000;
   *vecptr++ = CategoryString;

   /* append the report format string and it's parameters */
   *vecptr++ = ReportFormat;
   va_start (argptr, ReportFormat);
   for (argcnt -= 4; argcnt; argcnt--)
      *vecptr++ = va_arg (argptr, unsigned long);
   va_end (argptr);

   status = WriteFaol (Buffer, sizeof(Buffer), &Length, BufferFao, &FaoVector);
   if (VMSnok (status) || status == SS$_BUFFEROVF)
      ErrorNoticed (status, "WriteFaol()", FI_LI);
   Buffer[Length] = '\0';
   if (Debug) fprintf (stdout, "|%s|\n", Buffer);

   if (WatchRequestPtr == NULL)
      fputs (Buffer, stdout);
   else
      NetWrite (WatchRequestPtr, 0, Buffer, Length);
}

/*****************************************************************************/
/*
VARIABLE LENGTH ARGUMENT LIST.  Function to provide a formatted data WATCH entry,
with trailing information from the caller.  'DataFormat' parameter must be
in a sys$fao() acceptable format and sufficient variable number parameters be
supplied to satisfy any FAO directives in that format string.  Should include
appropriate carriage-control.
*/ 

WatchDataFormatted
(
char *DataFormat,
...
)
{
   int  status,
        argcnt;
   unsigned short  Length;
   unsigned long  *vecptr;
   unsigned long  FaoVector [64];
   char  Buffer [2048];
   va_list  argptr;

   /*********/
   /* begin */
   /*********/

   va_count (argcnt);

   if (Debug)
      fprintf (stdout, "WatchDataFormatted() |%s| %d\n",
               DataFormat, argcnt);

   /* this can occur if ASTs are delivered after WATCH use is discontinued */
   if (!WatchEnabled) return;

   vecptr = FaoVector;
   va_start (argptr, DataFormat);
   for (argcnt -= 1; argcnt; argcnt--)
      *vecptr++ = va_arg (argptr, unsigned long);
   va_end (argptr);

   status = WriteFaol (Buffer, sizeof(Buffer), &Length, DataFormat, &FaoVector);
   if (VMSnok (status) || status == SS$_BUFFEROVF)
      ErrorNoticed (status, "WriteFaol()", FI_LI);
   Buffer[Length] = '\0';
   if (Debug) fprintf (stdout, "|%s|\n", Buffer);

   if (WatchRequestPtr == NULL)
      fputs (Buffer, stdout);
   else
      NetWrite (WatchRequestPtr, 0, Buffer, Length);
}

/*****************************************************************************/
/*
Output the supplied, non-formatted data in the WATCH report.  Allows any
printable output to be included as a block in the WATCH output.
*/ 

WatchData
(
char *DataPtr,
int DataLength
)
{
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "WatchData()\n");

   /* this can occur if ASTs are delivered after WATCH use is discontinued */
   if (!WatchEnabled) return;

   if (WatchRequestPtr == NULL)
      fputs (DataPtr, stdout);
   else
      NetWrite (WatchRequestPtr, 0, DataPtr, DataLength);

   if (DataLength && DataPtr[DataLength-1] == '\n') return;

   if (WatchRequestPtr == NULL)
      fputs ("\n", stdout);
   else
      NetWrite (WatchRequestPtr, 0, "\n", 1);
}

/*****************************************************************************/
/*
Ouput the supplied data using WATCH as a hex and printable character dump.
*/ 

WatchDataDump
(
char *DataPtr,
int DataLength
)
{
/* 32 bytes by 128 lines comes out to 4096 bytes, the default buffer-full */
#define MAX_LINES 128
#define BYTES_PER_LINE 32
#define BYTES_PER_GROUP 4
#define GROUPS_PER_LINE (BYTES_PER_LINE / BYTES_PER_GROUP)
#define CHARS_PER_LINE ((BYTES_PER_LINE * 3) + GROUPS_PER_LINE + 1)

   static char  HexDigits [] = "0123456789ABCDEF";

   int  ByteCount,
        CurrentDataCount,
        DataCount;
   char  *cptr, *sptr, *zptr,
         *CurrentDataPtr,
         *CurrentDumpPtr;
   char  DumpBuffer [(CHARS_PER_LINE * MAX_LINES)+1];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "WatchDataDump() %d\n", DataLength);

   /* this can occur if ASTs are delivered after WATCH use is discontinued */
   if (!WatchEnabled) return;

   zptr = (sptr = DumpBuffer) + sizeof(DumpBuffer)-1;
   cptr = DataPtr;
   DataCount = DataLength;

   while (DataCount)
   {
      CurrentDumpPtr = sptr;
      CurrentDataPtr = cptr;
      CurrentDataCount = DataCount;

      ByteCount = BYTES_PER_LINE;
      while (ByteCount && DataCount)
      {
         *sptr++ = HexDigits[*(unsigned char*)cptr >> 4];
         *sptr++ = HexDigits[*(unsigned char*)cptr & 0xf];
         cptr++;
         DataCount--;
         ByteCount--;
         if (!(ByteCount % BYTES_PER_GROUP)) *sptr++ = ' ';
      }
      while (ByteCount)
      {
         *sptr++ = ' ';
         *sptr++ = ' ';
         ByteCount--;
         if (!(ByteCount % BYTES_PER_GROUP)) *sptr++ = ' ';
      }

      cptr = CurrentDataPtr;
      DataCount = CurrentDataCount;

      ByteCount = BYTES_PER_LINE;
      while (ByteCount && DataCount)
      {
         if (isalnum(*cptr) || ispunct(*cptr) || *cptr == ' ')
            *sptr++ = *cptr++;
         else
         {
            *sptr++ = '.';
            cptr++;
         }
         DataCount--;
         ByteCount--;
      }
      *sptr++ = '\n';

      if (Debug)
      {
         *sptr = '\0';
         /** fprintf (stdout, "|%s|\n", CurrentDumpPtr); **/
      }

      if (!DataCount || sptr >= zptr)
      {
         *sptr = '\0';
         WatchData (DumpBuffer, sptr - DumpBuffer);
         zptr = (sptr = DumpBuffer) + sizeof(DumpBuffer)-1;
      }
   }
}

/*****************************************************************************/
/*
Return a pointer to a static string containing current server process quotas
compared to what the server originally started with.
*/ 

char* WatchServerQuotas (struct RequestStruct *rqptr)

{
   static $DESCRIPTOR (QuotasFaoDsc,
"AST:!UL/!UL BIO:!UL/!UL BYT:!UL/!UL DIO:!UL/!UL ENQ:!UL/!UL \
FIL:!UL/!UL PGFL:!UL/!UL PRC:!UL/!UL TQ:!UL/!UL");
   static char  Buffer [256];
   static $DESCRIPTOR (BufferDsc, Buffer);

   static int  JpiAstCnt,
               JpiBioCnt,
               JpiBytCnt,
               JpiDioCnt,
               JpiEnqCnt,
               JpiFilCnt,
               JpiPagFilCnt,
               JpiPrcCnt,
               JpiTqCnt;

   static struct {
      unsigned short  BufferLength;
      unsigned short  ItemCode;
      unsigned long  BufferAddress;
      unsigned long  ReturnLengthAddress;
   }
      JpiItem [] =
   { { sizeof(JpiAstCnt), JPI$_ASTCNT, &JpiAstCnt, 0 },
     { sizeof(JpiBioCnt), JPI$_BIOCNT, &JpiBioCnt, 0 },
     { sizeof(JpiBytCnt), JPI$_BYTCNT, &JpiBytCnt, 0 },
     { sizeof(JpiDioCnt), JPI$_DIOCNT, &JpiDioCnt, 0 },
     { sizeof(JpiEnqCnt), JPI$_ENQCNT, &JpiEnqCnt, 0 },
     { sizeof(JpiFilCnt), JPI$_FILCNT, &JpiFilCnt, 0 },
     { sizeof(JpiPagFilCnt), JPI$_PAGFILCNT, &JpiPagFilCnt, 0 },
     { sizeof(JpiPrcCnt), JPI$_PRCCNT, &JpiPrcCnt, 0 },
     { sizeof(JpiTqCnt), JPI$_TQCNT, &JpiTqCnt, 0 },
     { 0,0,0,0 }
   };

   int  status;
   unsigned short  Length;
   unsigned long  *vecptr;
   unsigned long  FaoVector [32];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "WatchServerQuotas()\n");

   if (VMSnok (status = sys$getjpiw (0, 0, 0, &JpiItem, 0, 0, 0)))
   {
      ErrorNoticed (status, "sys$getjpiw()", FI_LI);
      return ("sys$getjpiw() failed!");
   }

   vecptr = &FaoVector;

   *vecptr++ = JpiAstCnt;
   *vecptr++ = HttpdJpiAstLm;
   *vecptr++ = JpiBioCnt;
   *vecptr++ = HttpdJpiBioLm;
   *vecptr++ = JpiBytCnt;
   *vecptr++ = HttpdJpiBytLm;
   *vecptr++ = JpiDioCnt;
   *vecptr++ = HttpdJpiDioLm;
   *vecptr++ = JpiEnqCnt;
   *vecptr++ = HttpdJpiEnqLm;
   *vecptr++ = JpiFilCnt;
   *vecptr++ = HttpdJpiFilLm;
   *vecptr++ = JpiPagFilCnt;
   *vecptr++ = HttpdJpiPgFlQuo;
   *vecptr++ = JpiPrcCnt;
   *vecptr++ = HttpdJpiPrcLm;
   *vecptr++ = JpiTqCnt;
   *vecptr++ = HttpdJpiTqLm;

   status = sys$faol (&QuotasFaoDsc, &Length, &BufferDsc, &FaoVector);
   if (VMSnok (status) || status == SS$_BUFFEROVF)
      ErrorNoticed (status, "sys$faol()", FI_LI);
   Buffer[Length] = '\0';

   return (Buffer);
}

/*****************************************************************************/
/*
*/ 

char* WatchCategory (int Category)

{
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "WatchCategory() %d\n", Category);

   switch (Category)
   {
      case WATCH_AUTH             : return ("AUTHORIZE");
      case WATCH_CONNECT          : return ("CONNECT");
      case WATCH_CGI              : return ("CGI");
      case WATCH_DCL              : return ("DCL");
      case WATCH_DECNET           : return ("DECNET");
      case WATCH_ERROR            : return ("ERROR");
      case WATCH_FILTER           : return ("FILTER");
      case WATCH_LOG              : return ("LOG");
      case WATCH_MAPPING          : return ("MAPPING");
      case WATCH_NETWORK          : return ("NETWORK");
      case WATCH_NETWORK_OCTETS   : return ("NETWORK-OCTETS");
      case WATCH_NOTICED          : return ("NOTICED");
      case WATCH_PROXY            : return ("PROXY");
      case WATCH_PROXY_CACHE      : return ("PROXY-CACHE");
      case WATCH_PROXY_CACHE_MNT  : return ("PROXY-CACHE-MAINTENANCE");
      case WATCH_PROXY_REQU_HDR   : return ("PROXY-REQUEST-HEADER");
      case WATCH_PROXY_REQU_BDY   : return ("PROXY-REQUEST-BODY");
      case WATCH_PROXY_RESP_HDR   : return ("PROXY-RESPONSE-HEADER");
      case WATCH_PROXY_RESP_BDY   : return ("PROXY-RESPONSE-BODY");
      case WATCH_QUOTAS           : return ("QUOTAS");
      case WATCH_REQUEST          : return ("REQUEST");
      case WATCH_REQUEST_BODY     : return ("REQUEST-BODY");
      case WATCH_REQUEST_HEADER   : return ("REQUEST-HEADER");
      case WATCH_RESPONSE         : return ("RESPONSE");
      case WATCH_RESPONSE_BODY    : return ("RESPONSE-BODY");
      case WATCH_RESPONSE_HEADER  : return ("RESPONSE-HEADER");
      case WATCH_SESOLA           : return ("SSL");
      case WATCH_TIMER            : return ("TIMER");
      default : return (NULL);
   }
}

/*****************************************************************************/
/*
Parse the /WATCH= qualifier string for command-line startup control.
*/ 

boolean WatchCli (char *String)

{
   char  *cptr, *sptr, *zptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "WatchCli() |%s|\n", String);

   if (strsame (String, "/NOWATCH", 6))
   {
      WatchDisabled = -1;
      return (true);
   }

   cptr = String;
   while (*cptr && *cptr != '=') cptr++;
   while (*cptr == '=' || *cptr == '\"') cptr++;
   if (!*cptr) return (true);
   if (Debug) fprintf (stdout, "cptr |%s|\n", cptr);
   if (!(WatchEnabled = atoi(cptr)))
   {
      fprintf (stdout, "%%%s-E-WATCH, invalid category number", Utility);
      return (false);
   }
   while (*cptr && (*cptr == '-' || isdigit(*cptr))) cptr++;
   if (*cptr == ',') cptr++;
   if (Debug) fprintf (stdout, "cptr |%s|\n", cptr);
   zptr = (sptr = WatchClientFilter) + sizeof(WatchClientFilter);
   while (*cptr && *cptr != ',' && *cptr != '\"' && sptr < zptr)
      *sptr++ = *cptr++;
   if (sptr >= zptr)
   {
      fprintf (stdout, "%%%s-E-WATCH, invalid client filter", Utility);
      return (false);
   }
   *sptr = '\0';
   if (*cptr == ',') cptr++;
   if (Debug) fprintf (stdout, "cptr |%s|\n", cptr);
   zptr = (sptr = WatchServiceFilter) + sizeof(WatchServiceFilter);
   while (*cptr && *cptr != ',' && *cptr != '\"' && sptr < zptr)
      *sptr++ = *cptr++;
   if (sptr >= zptr)
   {
      fprintf (stdout, "%%%s-E-WATCH, invalid service filter", Utility);
      return (false);
   }
   *sptr = '\0';
   if (*cptr == ',') cptr++;
   if (Debug) fprintf (stdout, "cptr |%s|\n", cptr);
   zptr = (sptr = WatchPathFilter) + sizeof(WatchPathFilter);
   while (*cptr && *cptr != ',' && *cptr != '\"' && sptr < zptr)
      *sptr++ = *cptr++;
   if (sptr >= zptr)
   {
      fprintf (stdout, "%%%s-E-WATCH, invalid path/track filter", Utility);
      return (false);
   }
   *sptr = '\0';

   if (!WatchClientFilter[0]) strcpy (WatchClientFilter, "*");
   if (!WatchPathFilter[0]) strcpy (WatchPathFilter, "*");
   if (!WatchServiceFilter[0]) strcpy (WatchServiceFilter, "*");

   return (true);
}

/*****************************************************************************/
/*
Just print out the WATCH CLI settings.
*/ 

WatchCliSettings ()

{
   unsigned long  Category;
   char  *cptr, *sptr;
   char  CategoryList [512];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "WatchCliSettings()\n");

   if (WatchDisabled)
      fprintf (stdout, "%%%s-I-WATCH, disabled\n", Utility);

   if (!WatchEnabled) return;

   sptr = CategoryList;
   for (Category = 1; Category; Category = Category << 1)
   {
      if ((cptr = WatchCategory (WatchEnabled & Category)) != NULL)
      {
         if (sptr > CategoryList)
         {
            *sptr++ = ',';
            *sptr++ = ' ';
         }
         while (*cptr) *sptr++ = tolower(*cptr++);
      }
   }
   *sptr = '\0';

   fprintf (stdout,
"%%%s-I-WATCH, (%d) %s\n\
-%s-I-WATCH, client filter \"%s\"\n\
-%s-I-WATCH, service filter \"%s\"\n\
-%s-I-WATCH, path/track filter \"%s\"\n",
            Utility, WatchEnabled, CategoryList,
            Utility, WatchClientFilter,
            Utility, WatchServiceFilter,
            Utility, WatchPathFilter);
}

/*****************************************************************************/
/*
Generate a report page listing all of the processes belonging to the server
process.
*/

#define PSCAN$_GETJPI_BUFFER_SIZE 24

WatchProcessReport
(
struct RequestStruct *rqptr,
void *NextTaskFunction
)
{
   static char  ResponseFao [] =
"<HTML>\n\
<HEAD>\n\
!AZ\
<TITLE>HTTPd !AZ ... Process Report</TITLE>\n\
</HEAD>\n\
!AZ\n\
<H2><NOBR>HTTPd !AZ</NOBR></H2>\n\
<H3>Process Report</H3>\n\
!20%W\n\
\
<P><TABLE BORDER=1 CELLSPACING=0 CELLPADDING=5>\n\
<TR><TD>\n\
<TABLE BORDER=0 CELLSPACING=0 CELLPADDING=5>\n\
<TR><TH></TH><TH ALIGN=left><U>PID<U></TH>\
<TH ALIGN=left><U>User</U>&nbsp;</TH>\
<TH ALIGN=left><U>Process Name</U>&nbsp;</TH>\
<TH ALIGN=left><U>Image</U></TH>\
<TH ALIGN=left><U>State</U></TH>\
<TH ALIGN=left><U>Priority</U></TH>\
</TR>\n";

   static char  ProcessFao [] =
"<TR><TH ALIGN=right>!UL.&nbsp;</TH>\
<TD><A HREF=\"!AZ?pid=!8XL!%%\">!8XL</A>&nbsp;</TD>\
<TD>!AZ&nbsp;</TD><TD>!AZ&nbsp;</TD><TD>!AZ&nbsp;</TD>\
<TD>!AZ</TD><TD ALIGN=right>!UL / !UL</TD></TR>\n";

   static char  EndPageFao [] =
"</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
</BODY>\n\
</HTML>\n";

   static char  *StateNameArray [] = {
                "1234","COLPG","MWAIT","CEF","PFW","LEF","LEFO",
                "HIB","HIBO","SUSP","SUSPO","FPG","COM","COMO","CUR" };

   static unsigned long  GetJpiControlFlags = JPI$M_IGNORE_TARGET_STATUS;
   static unsigned long  MailboxMask [2] = { PRV$M_WORLD | PRV$M_SYSPRV, 0 };

   static unsigned long  JpiPid,
                         JpiPri,
                         JpiPrib,
                         JpiState;
   static char  JpiImagName [256],
                JpiNodeName [32],
                JpiPrcNam [16],
                JpiTerminal [9],
                JpiUserName [13];

   static struct
   {
      unsigned short  buf_len;
      unsigned short  item;
      unsigned char   *buf_addr;
      unsigned short  *short_ret_len;
   }
      JpiItems [] =
   {
      { sizeof(GetJpiControlFlags), JPI$_GETJPI_CONTROL_FLAGS,
        &GetJpiControlFlags, 0 },
      { sizeof(JpiPid), JPI$_PID, &JpiPid, 0 },
      { sizeof(JpiPri), JPI$_PRI, &JpiPri, 0 },
      { sizeof(JpiPrib), JPI$_PRIB, &JpiPrib, 0 },
      { sizeof(JpiImagName), JPI$_IMAGNAME, &JpiImagName, 0 },
      { sizeof(JpiPrcNam), JPI$_PRCNAM, &JpiPrcNam, 0 },
      { sizeof(JpiUserName), JPI$_USERNAME, &JpiUserName, 0 },
      { sizeof(JpiState), JPI$_STATE, &JpiState, 0 },
      { sizeof(JpiTerminal), JPI$_TERMINAL, &JpiTerminal, 0 },
      { 0,0,0,0 }
   },
      ScanItems [] =
   {
      { 0, PSCAN$_GETJPI_BUFFER_SIZE, 2048, 0},
      { 0,0,0,0 }
   };

   int  status,
        ProcessCount,
        SetPrvStatus;
   unsigned long  *vecptr;
   unsigned long  ProcessContext;
   unsigned long  FaoVector [32];
   char  *cptr,
         *StateNamePtr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "WatchProcessReport()\n");

   ProcessContext = 0;
   status = sys$process_scan (&ProcessContext, &ScanItems);
   if (Debug) fprintf (stdout, "sys$process_scan() %%X%08.08X\n", status);
   if (VMSnok (status))
   {
      rqptr->rqResponse.ErrorTextPtr = "sys$getjpiw()";
      ErrorVmsStatus (rqptr, status, FI_LI);
      SysDclAst (NextTaskFunction, rqptr);
      return;
   }

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_ADMIN;
   HTTP_HEADER_200_HTML (rqptr);

   vecptr = FaoVector;
   *vecptr++ = HtmlMetaInfo (rqptr, NULL);
   *vecptr++ = ServerHostPort;
   *vecptr++ = Config.cfServer.AdminBodyTag;
   *vecptr++ = ServerHostPort;
   *vecptr++ = &rqptr->rqTime.Vms64bit;

   status = NetWriteFaol (rqptr, ResponseFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   /* detached scripts (possibly executing as a non-server username) */
   if (DclScriptDetachProcess)
      if (VMSnok (SetPrvStatus = sys$setprv (1, &MailboxMask, 0, 0)))
         ErrorExitVmsStatus (SetPrvStatus, "sys$setprv()", FI_LI);

   ProcessCount = 0;

   for (;;)
   {
      status = sys$getjpiw (0, &ProcessContext, 0, &JpiItems, 0, 0, 0);
      if (Debug) fprintf (stdout, "sys$getjpiw() %%X%08.08X\n", status);
      if (VMSnok (status)) break;

      JpiPrcNam[15] = '\0';
      for (cptr = JpiPrcNam; *cptr && *cptr != ' '; cptr++);
      *cptr = '\0';
      if (Debug) fprintf (stdout, "JpiPrcNam |%s|\n", JpiPrcNam);

      if (DclScriptDetachProcess)
      {
         if (Debug) fprintf (stdout, "JpiTerminal |%s|\n", JpiTerminal);
         if (JpiPid != HttpdProcessId)
         {
            /* determine associated script processes by the 'terminal' */
            if (strncmp (JpiTerminal, "MBA", 3)) continue;
            status = DclMailboxAcl (JpiTerminal, NULL);
            if (Debug) fprintf (stdout, "DclMailBoxAcl() %%X%08.08X\n", status);
            /* the STS$K_ERROR indicates the 'terminal' ACE was not detected */
            if (status == STS$K_ERROR) continue;
            if (VMSnok (status))
            {
               ErrorNoticed (status, "DclMailboxAcl()", FI_LI);
               continue;
            }
         }
      }

      ProcessCount++;

      JpiUserName[12] = '\0';
      for (cptr = JpiUserName; *cptr && *cptr != ' '; cptr++);
      *cptr = '\0';
      if (Debug) fprintf (stdout, "JpiUserName |%s|\n", JpiUserName);

      for (cptr = JpiImagName; *cptr && *cptr != ';'; cptr++);
      if (*cptr == ';') *cptr-- = '\0';
      while (cptr > JpiImagName && *cptr != ']') cptr--;
      if (*cptr == ']') cptr++;

      if (JpiState > 0 && JpiState <= 14)
         StateNamePtr = StateNameArray[JpiState];
      else
         sprintf (StateNamePtr = StateNameArray[0], "%04.04X", JpiState);

      vecptr = FaoVector;
      *vecptr++ = ProcessCount;
      *vecptr++ = ADMIN_REPORT_SHOW_PROCESS;
      *vecptr++ = JpiPid;
      if (DclPersonaServicesAvailable)
      {
         *vecptr++ = "&puser=!AZ";
         *vecptr++ = JpiUserName;
      }
      else
         *vecptr++ = "";
      *vecptr++ = JpiPid;
      *vecptr++ = JpiUserName;
      *vecptr++ = JpiPrcNam;
      if (*cptr)
         *vecptr++ = cptr;
      else
         *vecptr++ = "[<FONT SIZE=-1>DCL</FONT>]";
      *vecptr++ = StateNamePtr;
      *vecptr++ = JpiPri;
      *vecptr++ = JpiPrib;

      status = NetWriteFaol (rqptr, ProcessFao, &FaoVector);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
   }

   if (DclScriptDetachProcess)
      if (VMSnok (SetPrvStatus = sys$setprv (0, &MailboxMask, 0, 0)))
         ErrorExitVmsStatus (SetPrvStatus, "sys$setprv()", FI_LI);

   if (status != SS$_NOMOREPROC)
   {
      rqptr->rqResponse.ErrorTextPtr = "sys$getjpiw()";
      ErrorVmsStatus (rqptr, status, FI_LI);
   }

   status = NetWriteFaol (rqptr, EndPageFao, NULL);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   SysDclAst (NextTaskFunction, rqptr);
}

/*****************************************************************************/
/*
Using a scripting script process do a SHOW PROCESS /ALL on the specified
process.  Used from the DclReport() but actually could be used on any process
the server  has access to, including the server!
*/

WatchShowProcess
(
struct RequestStruct *rqptr,
void *NextTaskFunction,
char *ProcessIdString,
char *ProcessIdUserName
)
{
   static char  DclCommand [512];
   static unsigned long  JpiServerPid;
   static $DESCRIPTOR (DclCommandDsc, DclCommand);
   static $DESCRIPTOR (DclCommandFaoDsc,
"SHOW PROCESS /ALL /IDENT=!AZ\n\
SV=$SEVERITY\n\
IF SV THEN MO=\"Mode: \"+F$GETJPI(\"!AZ\",\"MODE\")\n\
JO=\"\"\n\
IF SV THEN IF F$GETJPI(\"!AZ\",\"PID\").NES.F$GETJPI(\"!AZ\",\"MASTER_PID\") \
THEN JO=\" (subprocess)\"\n\
IF SV THEN IF JO.EQS.\"\".AND.F$GETJPI(\"!AZ\",\"JOBTYPE\").EQ.0 \
THEN JO=\" (detached)\"\n\
IF SV THEN IM=\"Image: \"+F$GETJPI(\"!AZ\",\"IMAGNAME\")\n\
IF SV THEN IF F$GETJPI(\"!AZ\",\"IMAGNAME\").EQS.\"\" \
THEN IM=IM+\"[DCL]\"\n\
LF[0,8]=10\n\
IF SV THEN WRITE SYS$OUTPUT LF+MO+JO+LF+LF+IM\n\
\0");

   static char  ResponseFao [] =
"<HTML>\n\
<HEAD>\n\
!AZ\
<TITLE>HTTPd !AZ ... Show Process</TITLE>\n\
</HEAD>\n\
!AZ\n\
<H2><NOBR>HTTPd !AZ</NOBR></H2>\n\
<H3>Show Process</H3>\n\
!20%W\n\
\
<P><TABLE CELLSPACING=0 CELLPADDING=5 BORDER=1>\n\
<TR><TH>PID &nbsp;!AZ</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLSPACING=0 CELLPADDING=5 BORDER=0>\n\
<TR><TD><PRE>";

   int  status;
   unsigned long  *vecptr;
   unsigned long  ProcessId;
   unsigned long  FaoVector [32];
   char  *cptr;
   void  *EndPageFunctionPtr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "WatchShowProcess() %s\n", ProcessIdString);

   ProcessId = strtol (ProcessIdString, NULL, 16);
   if (Debug) fprintf (stdout, "ProcessId: %X08.08X\n", ProcessId);

   /* suppress the [delete] button for the main server process!! */
   if (ProcessId == HttpdProcessId)
      EndPageFunctionPtr = &WatchShowProcessEnd;
   else
      EndPageFunctionPtr = &WatchShowProcessDeleteEnd;

   rqptr->WatchShowProcessNextTaskFunction = NextTaskFunction;

   vecptr = FaoVector;
   *vecptr++ = ProcessIdString;
   *vecptr++ = ProcessIdString;
   *vecptr++ = ProcessIdString;
   *vecptr++ = ProcessIdString;
   *vecptr++ = ProcessIdString;
   *vecptr++ = ProcessIdString;
   *vecptr++ = ProcessIdString;

   status = sys$faol (&DclCommandFaoDsc, 0, &DclCommandDsc, &FaoVector);
   if (VMSnok (status) || status == SS$_BUFFEROVF)
   {
      rqptr->rqResponse.ErrorTextPtr = "sys$faol()";
      ErrorVmsStatus (rqptr, status, FI_LI);
      SysDclAst (NextTaskFunction, rqptr);
      return;
   }
   if (Debug) fprintf (stdout, "|%s|\n", DclCommand);

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_ADMIN;
   HTTP_HEADER_200_HTML (rqptr);

   vecptr = FaoVector;
   *vecptr++ = HtmlMetaInfo (rqptr, NULL);
   *vecptr++ = ServerHostPort;
   *vecptr++ = Config.cfServer.AdminBodyTag;
   *vecptr++ = ServerHostPort;
   *vecptr++ = &rqptr->rqTime.Vms64bit;
   *vecptr++ = ProcessIdString;

   status = NetWriteFaol (rqptr, ResponseFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   rqptr->rqOutput.BufferEscapeHtml = true;

   if (ProcessIdUserName[0])
   {
      rqptr->rqPathSet.ScriptAsPtr = cptr =
         VmGetHeap (rqptr, strlen(ProcessIdUserName)+2);
      if (!strsame (ProcessIdUserName, HttpdUserName, -1)) *cptr++ = '~';
      strcpy (cptr, ProcessIdUserName);
   }

   DclBegin (rqptr, EndPageFunctionPtr, DclCommand,
             NULL, NULL, NULL, NULL, NULL);
}

/*****************************************************************************/
/*
Called when the scripting script process is complete.  Output the last portion
of the report page and AST to wherever was the buffered end-of-report function.
*/

WatchShowProcessEnd (struct RequestStruct *rqptr)

{
   static char  EndPageFao [] =
"</PRE></TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
</BODY>\n\
</HTML>\n";

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "WatchShowProcessEnd()\n");

   rqptr->rqOutput.BufferEscapeHtml = false;

   status = NetWriteFaol (rqptr, EndPageFao, NULL);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   SysDclAst (rqptr->WatchShowProcessNextTaskFunction, rqptr);
}

/*****************************************************************************/
/*
Called when the scripting script process is complete.  Output the last portion
of the report page and AST to wherever was the buffered end-of-report function.
*/

WatchShowProcessDeleteEnd (struct RequestStruct *rqptr)

{
   static char  EndPageFao [] =
"</PRE></TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
<P><FORM METHOD=GET ACTION=\"!AZ\">\n\
<INPUT TYPE=hidden NAME=pid VALUE=\"!AZ\">\n\
<INPUT TYPE=submit VALUE=\" Force Delete \">\n\
</FORM>\n\
</BODY>\n\
</HTML>\n";

   int  status;
   unsigned long  *vecptr;
   unsigned long  FaoVector [8];
   char  ProcessIdString [32];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "WatchShowProcessDeleteEnd()\n");

   rqptr->rqOutput.BufferEscapeHtml = false;

   if (!strsame (rqptr->rqHeader.QueryStringPtr, "pid=", 4))
   {
      WatchShowProcessEnd (rqptr);
      return;
   }
   strzcpy (ProcessIdString, rqptr->rqHeader.QueryStringPtr+4, sizeof(ProcessIdString));

   vecptr = FaoVector;
   *vecptr++ = ADMIN_CONTROL_DELETE_PROCESS;
   *vecptr++ = ProcessIdString;

   status = NetWriteFaol (rqptr, EndPageFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   SysDclAst (rqptr->WatchShowProcessNextTaskFunction, rqptr);
}

/*****************************************************************************/
/*
Just delete the process specified by 'ProcessIdString'.
*/

WatchDeleteProcess
(
struct RequestStruct *rqptr,
void *NextTaskFunction
)
{
   int  status,
        SetPrvStatus;
   unsigned long  ProcessId;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "WatchDeleteProcess() |%s|\n",
               rqptr->rqHeader.QueryStringPtr);

   if (strsame (rqptr->rqHeader.QueryStringPtr, "pid=", 4))
   {
      ProcessId = strtol (rqptr->rqHeader.QueryStringPtr+4, NULL, 16);
      if (Debug) fprintf (stdout, "ProcessID: %08.08X\n", ProcessId);
   }
   else
      ProcessId  = 0;

   if (ProcessId)
   {
      if (DclScriptDetachProcess)
      {
         /* detached scripts, possibly executing as a non-server username */
         if (VMSnok (SetPrvStatus = sys$setprv (1, &WorldMask, 0, 0)))
            ErrorExitVmsStatus (SetPrvStatus, "sys$setprv()", FI_LI);
         status = sys$delprc (&ProcessId, 0);
         if (VMSnok (SetPrvStatus = sys$setprv (0, &WorldMask, 0, 0)))
            ErrorExitVmsStatus (SetPrvStatus, "sys$setprv()", FI_LI);
      }
      else
         status = sys$delprc (&ProcessId, 0);
      if (Debug) fprintf (stdout, "sys$dlprc %%X%08.08X\n", status);
   }
   else
      status = SS$_BUGCHECK;

   if (VMSnok (status))
   {
      rqptr->rqResponse.HttpStatus = 409;
      rqptr->rqResponse.ErrorTextPtr = "when deleting";
      ErrorVmsStatus (rqptr, status, FI_LI);
      SysDclAst (NextTaskFunction, rqptr);
      return;
   }

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_ADMIN;
   ReportSuccess (rqptr, "Server !AZ deleted process !8XL.",
                  ServerHostPort, ProcessId);

   SysDclAst (NextTaskFunction, rqptr);
}

/*****************************************************************************/
/*
Called from WatchBegin().  Provide a plain-text report displaying some of the
essential fields from various data structures in an executing request. 
Intended as a diagnosis and development tool.
*/

WatchPeek
(
struct RequestStruct *rqptr,
struct RequestStruct *rqeptr
)
{
#define WATCH_NULL_STRING "(null)"
#define WATCH_NULL(string) (string == NULL ? WATCH_NULL_STRING : string)

   static long  Subx2 = 2,
                EdivTen = 10;

   static unsigned long  DevNamItem = DVI$_DEVNAM;

   static char  ServiceFao [] =
"\n\
!33<ServicePtr!> 0x!8XL\n\
!33<->ServerChannel!> !UL (!AZ)\n\
!33<->ServerHostPort!> |!AZ|\n\
!33<->ServerIpAddressString!> |!AZ|\n\
!33<->RequestSchemeNamePtr!> |!AZ|\n\
\n\
!33<rqNet.ClientChannel!> !UL (!AZ)\n\
!33<rqNet.ClientHostName!> |!AZ|\n\
!33<rqNet.ClientIpAddressString!> |!AZ|\n\
!33<rqNet.ClientPort!> !UL\n\
!33<rqNet.ReadRawAstFunctionPtr!> 0x!8XL\n\
!33<rqNet.ReadIOsb!> %X!8XL !UL\n\
!33<rqNet.WriteRawAstFunctionPtr!> 0x!8XL\n\
!33<rqNet.WriteIOsb!> %X!8XL !UL\n\
!33<SeSoLaPtr!> 0x!8XL\n";

   static char  TimerFao [] =
"!33<BytesRawRx!> !UL\n\
!33<BytesRawTx!> !UL\n\
!33<rqNet.KeepAliveCount!> !UL\n\
!33<KeepAliveRequest!> !UL\n\
!33<KeepAliveResponse!> !UL\n\
!33<KeepAliveTimeout!> !UL\n\
!33<rqTmr.InputCount!> !UL\n\
!33<rqTmr.KeepAliveCount!> !UL\n\
!33<rqTmr.NoProgressBytesTx!> !UL\n\
!33<rqTmr.NoProgressCount!> !UL\n\
!33<rqTmr.NoProgressSeconds!> !UL\n\
!33<rqTmr.OutputCount!> !UL\n\
!33<rqTmr.TerminatedCount!> !UL\n\
\n\
!33<rqTime.Vms64bit!> !%D (!UL.!#ZL seconds ago)\n\
!33<rqTime.GmDateTime!> |!AZ|\n\
!33<rqHeader.RequestHeaderPtr!> |!#AZ|\n\
!33<rqHeader.MethodName!> |!AZ|\n\
!33<rqHeader.RequestUriPtr!> |!AZ|\n\
!33<rqHeader.HttpVersion!> !UL.!UL\n\
!33<rqHeader.AcceptPtr!> |!AZ|\n\
!33<rqHeader.AcceptCharsetPtr!> |!AZ|\n\
!33<rqHeader.AcceptEncodingPtr!> |!AZ|\n\
!33<rqHeader.AcceptLangPtr!> |!AZ|\n\
!33<rqHeader.AuthorizationPtr!> |!AZ|\n\
!33<rqHeader.ContentLength!> !UL\n\
!33<rqHeader.ContentTypePtr!> |!AZ|\n\
!33<rqHeader.CookiePtr!> |!AZ|\n\
!33<rqHeader.ETagPtr!> |!AZ|\n\
!33<rqHeader.ForwardedPtr!> |!AZ|\n\
!33<rqHeader.HostPtr!> |!AZ|\n\
!33<rqHeader.IfModifiedSincePtr!> |!AZ| (!%W)\n\
!33<rqHeader.PragmaPtr!> |!AZ|\n\
!33<rqHeader.ProxyAuthorizationPtr!> |!AZ|\n\
!33<rqHeader.ProxyConnectionPtr!> |!AZ|\n\
!33<rqHeader.RefererPtr!> |!AZ|\n\
!33<rqHeader.UserAgentPtr!> |!AZ|\n\
!33<rqBody.CurrentCount!> !UL\n\
!33<rqBody.BufferPtr!> 0x!XL\n\
\n\
!33<rqHeader.PathInfoPtr!> |!AZ|\n\
!33<rqHeader.QueryStringPtr!> |!AZ|\n\
!33<MappedPathPtr!> |!AZ|\n\
!33<RequestMappedFile!> |!AZ|\n\
!33<ParseOds.ParseFileName!> |!AZ|\n\
!33<ScriptName!> |!AZ|\n\
!33<RequestMappedScript!> |!AZ|\n\
!33<RequestMappedRunTime!> |!AZ|\n\
!33<IsCgiPlusScript!> !UL\n\
\n\
!33<rqResponse.HeaderPtr!> |!#AZ|\n\
!33<rqResponse.HeaderSent!> !UL\n\
!33<rqResponse.ErrorReportPtr!> |!AZ|\n\
!33<rqResponse.LocationPtr!> |!AZ|\n\
\n\
!33<RemoteUser!> |!AZ|\n\
!33<RemoteUserPassword!> |!#**|\n\
!33<rqAuth.FinalStatus!> %X!8XL\n\
!33<rqAuth.RequestCan!> 0x!4XL (!AZ)\n\
!33<rqAuth.UserCan!> 0x!4XL (!AZ)\n\
!33<rqAuth.GroupCan!> 0x!4XL (!AZ)\n\
!33<rqAuth.WorldCan!> 0x!4XL (!AZ)\n\
!33<rqAuth.Type!> |!AZ|\n\
!33<rqAuth.UserDetailsPtr!> |!AZ|\n\
!33<rqAuth.HttpsOnly!> !UL\n\
!33<rqAuth.SysUafAuthenticated!> !UL\n\
!33<rqAuth.VmsIdentifiersCount!> !UL\n\
!33<rqAuth.VmsIdentifiersPtr!> 0x!XL\n\
!33<rqAuth.VmsUserProfileLength!> !UL\n\
!33<rqAuth.VmsUserProfilePtr!> 0x!XL\n\
!33<rqAuth.RealmPtr!> |!AZ| (!AZ)\n\
!33<rqAuth.RealmDescrPtr!> |!AZ|\n\
!33<rqAuth.AgentParameterPtr!> |!AZ|\n\
!33<rqAuth.GroupWritePtr!> |!AZ| (!AZ)\n\
!33<rqAuth.GroupReadPtr!> |!AZ| (!AZ)\n\
!33<rqAuth.GroupRestrictListPtr!> |!AZ|\n\
!33<rqAuth.WorldRestrictListPtr!> |!AZ|\n\
\n\
!33<rqCgi.BufferLength!> !UL\n\
!33<rqCgi.BufferRemaining!> !UL\n\
!33<rqCgi.BufferPtr!> 0x!XL\n\
!33<rqCgi.BufferCurrentPtr!> 0x!XL\n\
!33<rqCgi.CalloutInProgress!> !UL\n\
!33<rqCgi.CalloutOutputCount!> !UL \n\
!33<rqCgi.CalloutOutputPtr!> 0x!XL |!AZ|\n\
!33<rqCgi.ContentTypeText!> !UL\n\
!33<rqCgi.EofPtr!> !AZ\n\
!33<rqCgi.EotPtr!> !AZ\n\
!33<rqCgi.EscPtr!> !AZ\n\
!33<rqCgi.HeaderLineCount!> !UL\n\
!33<rqCgi.IsCliDcl!> !UL\n\
!33<rqCgi.OutputMode!> !UL (!AZ)\n\
!33<rqCgi.ProcessingBody!> !UL\n\
!33<rqCgi.RecordCount!> !UL\n\
!33<rqCgi.ScriptRetryCount!> !UL\n\
!33<rqCgi.XVMSRecordMode!> !UL\n\
";

   static char  CacheFao [] =
"\n\
!33<rqCache.EntryPtr!> 0x!XL\n\
!33<DclTaskPtr!> 0x!XL\n\
";

   static char  DclTaskFao [] =
"!33<->TaskType!> !UL (!AZ)\n\
!33<->ScriptProcessPid!> !8XL\n\
!33<->CrePrcTermMbxChannel!> !UL (!AZ)\n\
!33<->CrePrcDetachProcess!> !UL\n\
!33<->CrePrcDetachStarting!> !UL\n\
!33<->CrePrcUserName!> !AZ\n\
!33<->CgiPlusInChannel!> !UL (!AZ)\n\
!33<->CgiPlusInIOsb!> %X!8XL !UL\n\
!33<->QueuedCgiPlusIn!> !UL\n\
!33<->HttpInputChannel!> !UL (!AZ)\n\
!33<->HttpInputIOsb!> %X!8XL !UL\n\
!33<->QueuedHttpInput!> !UL\n\
!33<->QueuedClientRead!> !UL\n\
!33<->SysCommandChannel!> !UL (!AZ)\n\
!33<->SysCommandIOsb!> %X!8XL !UL\n\
!33<->QueuedSysCommand!> !UL\n\
!33<->QueuedSysCommandAllowed!> !UL\n\
!33<->SysOutputChannel!> !UL (!AZ)\n\
!33<->SysOutputIOsb!> %X!8XL !UL\n\
!33<->QueuedSysOutput!> !UL\n\
!33<->ScriptProcessPid!> !8XL\n\
!33<->ScriptProcessActivated!> !UL\n\
!33<->ScriptProcessResponded!> !UL\n\
!33<->CrePrcTermRecord.acc$l_finalsts!> %X!8XL\n\
!33<->MarkedForDelete!> !UL\n\
!33<->CalloutFunction!> 0x!8XL\n\
!33<->DclCommand!> |!AZ|\n\
!33<->ScriptName!> |!AZ|\n\
!33<->ScriptFileName!> |!AZ|\n\
\n";

   static char  DECnetFao [] = "!33<DECnetTaskPtr!> 0x!8XL\n";

   static char  DECnetTaskFao [] =
"!33<->DECnetChannel!> !UL\n\
!33<->DECnetConnectIOsb!> %X!8XL !UL\n\
!33<->DECnetReadIOsb!> %X!8XL !UL\n\
!33<->DECnetWriteIOsb!> %X!8XL !UL\n\
!33<->QueuedDECnetIO!> !UL\n\
!33<->ScriptResponded!> !UL\n\
!33<->CgiDialogState!> !UL\n\
!33<->OsuDialogState!> !UL\n\
\n";

   static char  DescrFao [] =
"!33<DescrTaskPtr!> 0x!8XL\n\
!33<DirTaskPtr!> 0x!8XL\n\
!33<FileTaskPtr!> 0x!8XL\n\
!33<GraphTaskPtr!> 0x!8XL\n\
!33<HTAdminTaskPtr!> 0x!8XL\n\
!33<IsMapTaskPtr!> 0x!8XL\n\
!33<MenuTaskPtr!> 0x!8XL\n\
!33<ProxyTaskPtr!> 0x!8XL\n\
";

   static char  ProxyTaskFao [] =
"!33<->ProxyChannel!> !UL (!AZ)\n\
!33<->RequestHostNamePort!> |!AZ|\n\
!33<->RequestSchemeName!> |!AZ|\n\
!33<->ProxyLookupIOsb!> %X!8XL !UL\n\
!33<->ProxyLookupRetryCount!> !UL\n\
!33<->ProxyConnectIOsb!> %X!8XL !UL\n\
!33<->ProxyReadIOsb!> %X!8XL !UL\n\
!33<->ProxyReadRawAstFunctionPtr!> 0x!8XL\n\
!33<->ProxyWriteIOsb!> %X!8XL !UL\n\
!33<->ProxyWriteRawAstFunctionPtr!> 0x!8XL\n\
!33<->BytesRawRx!> !UL\n\
!33<->BytesRawTx!> !UL\n\
!33<->RebuiltRequestPtr!> |!AZ|\n\
!33<->ResponseConsecutiveNewLineCount!> !UL\n\
!33<->ResponseHeaderLength!> !UL\n\
!33<->ResponseHeaderPtr!> |!#AZ|\n\
!33<->ResponseContentLength!> !UL\n\
!33<->ResponseBodyLength!> !UL\n\
!33<->ResponseBufferNetCount!> !UL\n\
!33<->ResponseBufferNetPtr!> 0x!8XL\n\
!33<->ResponseBufferCacheCount!> !UL\n\
!33<->ResponseBufferCachePtr!> 0x!8XL\n\
!33<->NotCacheable!> !UL\n\
!33<->ProxyCacheFileName!> |!AZ|\n\
!33<->ProxyCacheSuitable!> !UL\n\
!33<->ProxyCacheFileSizeInBytes!> !UL\n\
!33<->ProxyCacheLastModifiedHours!> !UL\n\
!33<->ProxyCacheReadBytes!> !UL\n\
!33<->ProxyCacheFileCdt!> !%D\n\
";

   static char  PutFao [] =
"!33<PutTaskPtr!> 0x!8XL\n\
!33<SsiTaskPtr!> 0x!8XL\n\
!33<UpdTaskPtr!> 0x!8XL\n\
\n";

   int  status,
        ConnectNumber;
   unsigned short  Length;
   unsigned long  Remainder,
                  ResponseDuration,
                  Seconds,
                  SubSeconds;
   unsigned long  BinaryTime [2],
                  FaoVector [128],
                  ResultTime [2];
   unsigned long  *vecptr;
   char  *cptr;
   char  Buffer [8192],
         ClientDevName [64],
         ProxyDevName [64],
         ServerDevName [64];
   $DESCRIPTOR (ClientDevNameDsc, ClientDevName);
   $DESCRIPTOR (ProxyDevNameDsc, ProxyDevName);
   $DESCRIPTOR (ServerDevNameDsc, ServerDevName);

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "WatchPeek()\n");

   if (VMSnok (status =
       lib$getdvi (&DevNamItem, &rqeptr->ServicePtr->ServerChannel,
                   0, 0, &ServerDevNameDsc, &Length)))
      WriteFao (ServerDevName, sizeof(ServerDevName), NULL, "%!%M", status);
   else
      ServerDevName[Length] = '\0';

   if (VMSnok (status =
       lib$getdvi (&DevNamItem, &rqeptr->rqNet.ClientChannel,
                   0, 0, &ClientDevNameDsc, &Length)))
      WriteFao (ClientDevName, sizeof(ClientDevName), NULL, "%!%M", status);
   else
      ClientDevName[Length] = '\0';

   sys$gettim (&BinaryTime);
   status = lib$subx (&BinaryTime, &rqeptr->rqTime.Vms64bit, 
                      &ResultTime, &Subx2);
   /* convert to microseconds (longword becomes 71 minutes max) */
   if (VMSok (status))
      status = lib$ediv (&EdivTen, &ResultTime,
                         &ResponseDuration, &Remainder);
   if (Debug) fprintf (stdout, "elapsed: %%X%08.08X\n", status);
   if (VMSnok (status)) ResponseDuration = 0;

   vecptr = FaoVector;

   *vecptr++ = rqeptr->ServicePtr;
   *vecptr++ = rqeptr->ServicePtr->ServerChannel;
   *vecptr++ = ServerDevName+1;
   *vecptr++ = rqeptr->ServicePtr->ServerHostPort;
   *vecptr++ = rqeptr->ServicePtr->ServerIpAddressString;
   *vecptr++ = rqeptr->ServicePtr->RequestSchemeNamePtr;

   *vecptr++ = rqeptr->rqNet.ClientChannel;
   *vecptr++ = ClientDevName+1;
   *vecptr++ = rqeptr->rqNet.ClientHostName;
   *vecptr++ = rqeptr->rqNet.ClientIpAddressString;
   *vecptr++ = rqeptr->rqNet.ClientPort;
   *vecptr++ = rqeptr->rqNet.ReadRawAstFunctionPtr;
   *vecptr++ = rqeptr->rqNet.ReadIOsb.Status;
   *vecptr++ = rqeptr->rqNet.ReadIOsb.Count;
   *vecptr++ = rqeptr->rqNet.WriteRawAstFunctionPtr;
   *vecptr++ = rqeptr->rqNet.WriteIOsb.Status;
   *vecptr++ = rqeptr->rqNet.WriteIOsb.Count;
   *vecptr++ = rqeptr->SeSoLaPtr;

   status = WriteFaol (Buffer, sizeof(Buffer), &Length, ServiceFao, &FaoVector);
   if (VMSnok (status) || status == SS$_BUFFEROVF)
      ErrorNoticed (status, "WriteFaol()", FI_LI);
   NetWrite (rqptr, 0, Buffer, Length);

   SeSoLaWatchPeek (rqptr, rqeptr);

   vecptr = FaoVector;

   *vecptr++ = rqeptr->BytesRawRx;
   *vecptr++ = rqeptr->BytesRawTx;
   *vecptr++ = rqeptr->rqNet.KeepAliveCount;
   *vecptr++ = rqeptr->KeepAliveRequest;
   *vecptr++ = rqeptr->KeepAliveResponse;
   *vecptr++ = rqeptr->KeepAliveTimeout;
   *vecptr++ = rqeptr->rqTmr.InputCount;
   *vecptr++ = rqeptr->rqTmr.KeepAliveCount;
   *vecptr++ = rqeptr->rqTmr.NoProgressBytesTx;
   *vecptr++ = rqeptr->rqTmr.NoProgressCount;
   *vecptr++ = rqeptr->rqTmr.NoProgressSeconds;
   *vecptr++ = rqeptr->rqTmr.OutputCount;
   *vecptr++ = rqeptr->rqTmr.TerminatedCount;

   *vecptr++ = rqeptr->rqTime.Vms64bit;

   Seconds = ResponseDuration / USECS_IN_A_SECOND;
   SubSeconds = (ResponseDuration % USECS_IN_A_SECOND) / DURATION_UNITS_USECS;
   *vecptr++ = Seconds;
   *vecptr++ = DURATION_DECIMAL_PLACES;
   *vecptr++ = SubSeconds;

   *vecptr++ = rqeptr->rqTime.GmDateTime;
   if (rqeptr->rqHeader.RequestHeaderPtr == NULL)
      *vecptr++ = sizeof(WATCH_NULL_STRING)-1;
   else
      *vecptr++ = rqeptr->rqHeader.RequestHeaderLength;
   *vecptr++ = WATCH_NULL(rqeptr->rqHeader.RequestHeaderPtr);
   *vecptr++ = rqeptr->rqHeader.MethodName;
   *vecptr++ = WATCH_NULL(rqeptr->rqHeader.RequestUriPtr);
   *vecptr++ = rqeptr->rqHeader.HttpVersion / 10;
   *vecptr++ = rqeptr->rqHeader.HttpVersion % 10;
   *vecptr++ = WATCH_NULL(rqeptr->rqHeader.AcceptPtr);
   *vecptr++ = WATCH_NULL(rqeptr->rqHeader.AcceptCharsetPtr);
   *vecptr++ = WATCH_NULL(rqeptr->rqHeader.AcceptEncodingPtr);
   *vecptr++ = WATCH_NULL(rqeptr->rqHeader.AcceptLangPtr);
   *vecptr++ = WATCH_NULL(rqeptr->rqHeader.AuthorizationPtr);
   *vecptr++ = rqeptr->rqHeader.ContentLength;
   *vecptr++ = WATCH_NULL(rqeptr->rqHeader.ContentTypePtr);
   *vecptr++ = WATCH_NULL(rqeptr->rqHeader.CookiePtr);
   *vecptr++ = WATCH_NULL(rqeptr->rqHeader.ETagPtr);
   *vecptr++ = WATCH_NULL(rqeptr->rqHeader.ForwardedPtr);
   *vecptr++ = WATCH_NULL(rqeptr->rqHeader.HostPtr);
   *vecptr++ = WATCH_NULL(rqeptr->rqHeader.IfModifiedSincePtr);
   *vecptr++ = rqeptr->rqTime.IfModifiedSinceVMS64bit;
   *vecptr++ = WATCH_NULL(rqeptr->rqHeader.PragmaPtr);
   *vecptr++ = WATCH_NULL(rqeptr->rqHeader.ProxyAuthorizationPtr);
   *vecptr++ = WATCH_NULL(rqeptr->rqHeader.ProxyConnectionPtr);
   *vecptr++ = WATCH_NULL(rqeptr->rqHeader.RefererPtr);
   *vecptr++ = WATCH_NULL(rqeptr->rqHeader.UserAgentPtr);
   *vecptr++ = rqeptr->rqBody.CurrentCount;
   *vecptr++ = rqeptr->rqBody.BufferPtr;

   *vecptr++ = WATCH_NULL(rqeptr->rqHeader.PathInfoPtr);
   *vecptr++ = WATCH_NULL(rqeptr->rqHeader.QueryStringPtr);
   *vecptr++ = WATCH_NULL(rqeptr->MappedPathPtr);
   *vecptr++ = rqeptr->RequestMappedFile;
   *vecptr++ = rqeptr->ParseOds.ExpFileName;
   *vecptr++ = rqeptr->ScriptName;
   *vecptr++ = rqeptr->RequestMappedScript;
   *vecptr++ = rqeptr->RequestMappedRunTime;
   *vecptr++ = rqeptr->IsCgiPlusScript;

   if (rqeptr->rqResponse.HeaderPtr == NULL)
      *vecptr++ = sizeof(WATCH_NULL_STRING)-1;
   else
      *vecptr++ = rqeptr->rqResponse.HeaderLength;
   *vecptr++ = WATCH_NULL(rqeptr->rqResponse.HeaderPtr);
   *vecptr++ = rqeptr->rqResponse.HeaderSent;
   *vecptr++ = WATCH_NULL(rqeptr->rqResponse.ErrorReportPtr);
   *vecptr++ = WATCH_NULL(rqeptr->rqResponse.LocationPtr);

   *vecptr++ = rqeptr->RemoteUser;
   *vecptr++ = strlen(rqeptr->RemoteUserPassword);
   *vecptr++ = rqeptr->rqAuth.FinalStatus;
   *vecptr++ = rqeptr->rqAuth.RequestCan;
   *vecptr++ = AuthCanString (rqeptr->rqAuth.RequestCan, AUTH_CAN_FORMAT_LONG);
   *vecptr++ = rqeptr->rqAuth.UserCan;
   *vecptr++ = AuthCanString (rqeptr->rqAuth.UserCan, AUTH_CAN_FORMAT_LONG);
   *vecptr++ = rqeptr->rqAuth.GroupCan;
   *vecptr++ = AuthCanString (rqeptr->rqAuth.GroupCan, AUTH_CAN_FORMAT_LONG);
   *vecptr++ = rqeptr->rqAuth.WorldCan;
   *vecptr++ = AuthCanString (rqeptr->rqAuth.WorldCan, AUTH_CAN_FORMAT_LONG);
   *vecptr++ = rqeptr->rqAuth.Type;
   *vecptr++ = WATCH_NULL(rqeptr->rqAuth.UserDetailsPtr);
   *vecptr++ = rqeptr->rqAuth.HttpsOnly;
   *vecptr++ = rqeptr->rqAuth.SysUafAuthenticated;
   *vecptr++ = rqeptr->rqAuth.VmsIdentifiersCount;
   *vecptr++ = rqeptr->rqAuth.VmsIdentifiersPtr;
   *vecptr++ = rqeptr->rqAuth.VmsUserProfileLength;
   *vecptr++ = rqeptr->rqAuth.VmsUserProfilePtr;
   *vecptr++ = WATCH_NULL(rqeptr->rqAuth.RealmPtr);
   *vecptr++ = AuthSourceString (rqeptr->rqAuth.RealmPtr,
                                 rqeptr->rqAuth.SourceRealm);
   *vecptr++ = WATCH_NULL(rqeptr->rqAuth.RealmDescrPtr);
   *vecptr++ = WATCH_NULL(rqeptr->rqAuth.AgentParameterPtr);
   *vecptr++ = WATCH_NULL(rqeptr->rqAuth.GroupWritePtr);
   *vecptr++ = AuthSourceString (rqeptr->rqAuth.GroupWritePtr,
                                 rqeptr->rqAuth.SourceGroupWrite);
   *vecptr++ = WATCH_NULL(rqeptr->rqAuth.GroupReadPtr);
   *vecptr++ = AuthSourceString (rqeptr->rqAuth.GroupReadPtr,
                                 rqeptr->rqAuth.SourceGroupRead);
   *vecptr++ = WATCH_NULL(rqeptr->rqAuth.GroupRestrictListPtr);
   *vecptr++ = WATCH_NULL(rqeptr->rqAuth.WorldRestrictListPtr);

   *vecptr++ = rqeptr->rqCgi.BufferLength;
   *vecptr++ = rqeptr->rqCgi.BufferRemaining;
   *vecptr++ = rqeptr->rqCgi.BufferPtr;
   *vecptr++ = rqeptr->rqCgi.BufferCurrentPtr;
   *vecptr++ = rqeptr->rqCgi.CalloutInProgress;
   *vecptr++ = rqeptr->rqCgi.CalloutOutputCount;
   *vecptr++ = rqeptr->rqCgi.CalloutOutputPtr;
   *vecptr++ = WATCH_NULL(rqeptr->rqCgi.CalloutOutputPtr);
   *vecptr++ = rqeptr->rqCgi.ContentTypeText;
   *vecptr++ = WATCH_NULL(rqeptr->rqCgi.EofPtr);
   *vecptr++ = WATCH_NULL(rqeptr->rqCgi.EotPtr);
   *vecptr++ = WATCH_NULL(rqeptr->rqCgi.EscPtr);
   *vecptr++ = rqeptr->rqCgi.HeaderLineCount;
   *vecptr++ = rqeptr->rqCgi.IsCliDcl;
   *vecptr++ = rqeptr->rqCgi.OutputMode;
   switch (rqeptr->rqCgi.OutputMode)
   {
      case CGI_OUTPUT_MODE_STREAM : *vecptr++ = "stream"; break;
      case CGI_OUTPUT_MODE_RECORD : *vecptr++ = "record"; break;
      case CGI_OUTPUT_MODE_CRLF : *vecptr++ = "crlf"; break;
      default : *vecptr++ = "?";
   }
   *vecptr++ = rqeptr->rqCgi.ProcessingBody;
   *vecptr++ = rqeptr->rqCgi.RecordCount;
   *vecptr++ = rqeptr->rqCgi.ScriptRetryCount;
   *vecptr++ = rqeptr->rqCgi.XVMSRecordMode;

   status = WriteFaol (Buffer, sizeof(Buffer), &Length, TimerFao, &FaoVector);
   if (VMSnok (status) || status == SS$_BUFFEROVF)
      ErrorNoticed (status, "WriteFaol()", FI_LI);
   NetWrite (rqptr, 0, Buffer, Length);

   if ((cptr = rqeptr->rqCgi.BufferPtr) != NULL)
   {
      /*****************/
      /* CGI variables */
      /*****************/

      for (;;)
      {
         if (!(Length = *(short*)cptr)) break;
         status = WriteFao (Buffer, sizeof(Buffer), &Length, "|!AZ|\n",
                            cptr + sizeof(short));
         if (VMSnok (status) || status == SS$_BUFFEROVF)
            ErrorNoticed (status, "WriteFaol()", FI_LI);
         NetWrite (rqptr, 0, Buffer, Length);
         cptr += Length;
      }
   }

   vecptr = FaoVector;
   *vecptr++ = rqeptr->rqCache.EntryPtr;
   *vecptr++ = rqeptr->DclTaskPtr;

   status = WriteFaol (Buffer, sizeof(Buffer), &Length, CacheFao, &FaoVector);
   if (VMSnok (status) || status == SS$_BUFFEROVF)
      ErrorNoticed (status, "WriteFaol()", FI_LI);
   NetWrite (rqptr, 0, Buffer, Length);

   if (rqeptr->DclTaskPtr != NULL)
   {
      /************/
      /* DCL task */
      /************/

      vecptr = FaoVector;
      *vecptr++ = rqeptr->DclTaskPtr->TaskType;
      switch (rqeptr->DclTaskPtr->TaskType)
      {
         case DCL_TASK_TYPE_NONE : *vecptr++ = "none"; break;
         case DCL_TASK_TYPE_CLI : *vecptr++ = "CLI"; break;
         case DCL_TASK_TYPE_CGI_SCRIPT : *vecptr++ = "CGI"; break;
         case DCL_TASK_TYPE_CGIPLUS_SCRIPT : *vecptr++ = "CGIplus"; break;
         case DCL_TASK_TYPE_RTE_SCRIPT : *vecptr++ = "RTE"; break;
         default : *vecptr++ = "?";
      }
      *vecptr++ = rqeptr->DclTaskPtr->ScriptProcessPid;
      *vecptr++ = rqeptr->DclTaskPtr->CrePrcTermMbxChannel;
      *vecptr++ = rqeptr->DclTaskPtr->CrePrcTermMbxDevName+1;
      *vecptr++ = rqeptr->DclTaskPtr->CrePrcDetachProcess;
      *vecptr++ = rqeptr->DclTaskPtr->CrePrcDetachStarting;
      *vecptr++ = rqeptr->DclTaskPtr->CrePrcUserName;
      *vecptr++ = rqeptr->DclTaskPtr->CgiPlusInChannel;
      *vecptr++ = rqeptr->DclTaskPtr->CgiPlusInDevName+1;
      *vecptr++ = rqeptr->DclTaskPtr->CgiPlusInIOsb.Status;
      *vecptr++ = rqeptr->DclTaskPtr->CgiPlusInIOsb.Count;
      *vecptr++ = rqeptr->DclTaskPtr->QueuedCgiPlusIn;
      *vecptr++ = rqeptr->DclTaskPtr->HttpInputChannel;
      *vecptr++ = rqeptr->DclTaskPtr->HttpInputDevName+1;
      *vecptr++ = rqeptr->DclTaskPtr->HttpInputIOsb.Status;
      *vecptr++ = rqeptr->DclTaskPtr->HttpInputIOsb.Count;
      *vecptr++ = rqeptr->DclTaskPtr->QueuedHttpInput;
      *vecptr++ = rqeptr->DclTaskPtr->QueuedClientRead;
      *vecptr++ = rqeptr->DclTaskPtr->SysCommandChannel;
      *vecptr++ = rqeptr->DclTaskPtr->SysCommandDevName+1;
      *vecptr++ = rqeptr->DclTaskPtr->SysCommandIOsb.Status;
      *vecptr++ = rqeptr->DclTaskPtr->SysCommandIOsb.Count;
      *vecptr++ = rqeptr->DclTaskPtr->QueuedSysCommand;
      *vecptr++ = rqeptr->DclTaskPtr->QueuedSysCommandAllowed;
      *vecptr++ = rqeptr->DclTaskPtr->SysOutputChannel;
      *vecptr++ = rqeptr->DclTaskPtr->SysOutputDevName+1;
      *vecptr++ = rqeptr->DclTaskPtr->SysOutputIOsb.Status;
      *vecptr++ = rqeptr->DclTaskPtr->SysOutputIOsb.Count;
      *vecptr++ = rqeptr->DclTaskPtr->QueuedSysOutput;
      *vecptr++ = rqeptr->DclTaskPtr->ScriptProcessPid;
      *vecptr++ = rqeptr->DclTaskPtr->ScriptProcessActivated;
      *vecptr++ = rqeptr->DclTaskPtr->ScriptProcessResponded;
      *vecptr++ = rqeptr->DclTaskPtr->CrePrcTermRecord.acc$l_finalsts;
      *vecptr++ = rqeptr->DclTaskPtr->MarkedForDelete;
      *vecptr++ = rqeptr->DclTaskPtr->CalloutFunction;
      *vecptr++ = rqeptr->DclTaskPtr->DclCommand;
      *vecptr++ = rqeptr->DclTaskPtr->ScriptName;
      *vecptr++ = rqeptr->DclTaskPtr->ScriptFileName;

      status = WriteFaol (Buffer, sizeof(Buffer), &Length,
                          DclTaskFao, &FaoVector);
      if (VMSnok (status) || status == SS$_BUFFEROVF)
         ErrorNoticed (status, "WriteFaol()", FI_LI);
      NetWrite (rqptr, 0, Buffer, Length);
   }

   vecptr = FaoVector;
   *vecptr++ = rqeptr->DECnetTaskPtr;

   status = WriteFaol (Buffer, sizeof(Buffer), &Length, DECnetFao, &FaoVector);
   if (VMSnok (status) || status == SS$_BUFFEROVF)
      ErrorNoticed (status, "WriteFaol()", FI_LI);
   NetWrite (rqptr, 0, Buffer, Length);

   if (rqeptr->DECnetTaskPtr != NULL)
   {
      /***************/
      /* DECnet task */
      /***************/

      vecptr = FaoVector;
      *vecptr++ = rqeptr->DECnetTaskPtr->DECnetChannel;
      *vecptr++ = rqeptr->DECnetTaskPtr->DECnetConnectIOsb.Status;
      *vecptr++ = rqeptr->DECnetTaskPtr->DECnetConnectIOsb.Count;
      *vecptr++ = rqeptr->DECnetTaskPtr->DECnetReadIOsb.Status;
      *vecptr++ = rqeptr->DECnetTaskPtr->DECnetReadIOsb.Count;
      *vecptr++ = rqeptr->DECnetTaskPtr->DECnetWriteIOsb.Status;
      *vecptr++ = rqeptr->DECnetTaskPtr->DECnetWriteIOsb.Count;
      *vecptr++ = rqeptr->DECnetTaskPtr->QueuedDECnetIO;
      *vecptr++ = rqeptr->DECnetTaskPtr->ScriptResponded;
      *vecptr++ = rqeptr->DECnetTaskPtr->CgiDialogState;
      *vecptr++ = rqeptr->DECnetTaskPtr->OsuDialogState;

      status = WriteFaol (Buffer, sizeof(Buffer), &Length,
                          DECnetTaskFao, &FaoVector);
      if (VMSnok (status) || status == SS$_BUFFEROVF)
         ErrorNoticed (status, "WriteFaol()", FI_LI);
      NetWrite (rqptr, 0, Buffer, Length);
   }

   vecptr = FaoVector;
   *vecptr++ = rqeptr->DescrTaskPtr;
   *vecptr++ = rqeptr->DirTaskPtr;
   *vecptr++ = rqeptr->FileTaskPtr;
   *vecptr++ = rqeptr->GraphTaskPtr;
   *vecptr++ = rqeptr->HTAdminTaskPtr;
   *vecptr++ = rqeptr->IsMapTaskPtr;
   *vecptr++ = rqeptr->MenuTaskPtr;
   *vecptr++ = rqeptr->ProxyTaskPtr;

   status = WriteFaol (Buffer, sizeof(Buffer), &Length, DescrFao, &FaoVector);
   if (VMSnok (status) || status == SS$_BUFFEROVF)
      ErrorNoticed (status, "WriteFaol()", FI_LI);
   NetWrite (rqptr, 0, Buffer, Length);

   if (rqeptr->ProxyTaskPtr != NULL)
   {
      /**************/
      /* proxy task */
      /**************/

      if (VMSnok (status =
          lib$getdvi (&DevNamItem, &rqeptr->ProxyTaskPtr->ProxyChannel,
                      0, 0, &ProxyDevNameDsc, &Length)))
         WriteFao (ProxyDevName, sizeof(ProxyDevName), NULL, "%!%M", status);
      else
         ProxyDevName[Length] = '\0';

      vecptr = FaoVector;
      *vecptr++ = rqeptr->ProxyTaskPtr->ProxyChannel;
      *vecptr++ = ProxyDevName+1;
      *vecptr++ = rqeptr->ProxyTaskPtr->RequestHostNamePort;
      *vecptr++ = rqeptr->ProxyTaskPtr->RequestSchemeName;
      *vecptr++ = rqeptr->ProxyTaskPtr->ProxyLookupIOsb.Status;
      *vecptr++ = rqeptr->ProxyTaskPtr->ProxyLookupIOsb.Count;
      *vecptr++ = rqeptr->ProxyTaskPtr->ProxyLookupRetryCount;
      *vecptr++ = rqeptr->ProxyTaskPtr->ProxyConnectIOsb.Status;
      *vecptr++ = rqeptr->ProxyTaskPtr->ProxyConnectIOsb.Count;
      *vecptr++ = rqeptr->ProxyTaskPtr->ProxyReadIOsb.Status;
      *vecptr++ = rqeptr->ProxyTaskPtr->ProxyReadIOsb.Count;
      *vecptr++ = rqeptr->ProxyTaskPtr->ProxyReadRawAstFunctionPtr;
      *vecptr++ = rqeptr->ProxyTaskPtr->ProxyWriteIOsb.Status;
      *vecptr++ = rqeptr->ProxyTaskPtr->ProxyWriteIOsb.Count;
      *vecptr++ = rqeptr->ProxyTaskPtr->ProxyWriteRawAstFunctionPtr;
      *vecptr++ = rqeptr->ProxyTaskPtr->BytesRawRx;
      *vecptr++ = rqeptr->ProxyTaskPtr->BytesRawTx;
      *vecptr++ = WATCH_NULL(rqeptr->ProxyTaskPtr->RebuiltRequestPtr);
      *vecptr++ = rqeptr->ProxyTaskPtr->ResponseConsecutiveNewLineCount;
      *vecptr++ = rqeptr->ProxyTaskPtr->ResponseHeaderLength;
      if (rqeptr->ProxyTaskPtr->ResponseHeaderPtr == NULL)
      {
         *vecptr++ = sizeof(WATCH_NULL_STRING)-1;
         *vecptr++ = WATCH_NULL_STRING;
      }
      else
      if (rqeptr->ProxyTaskPtr->ResponseConsecutiveNewLineCount < 2)
      {
         *vecptr++ = rqeptr->ProxyTaskPtr->ResponseHeaderLength;
         *vecptr++ = WATCH_NULL(rqeptr->ProxyTaskPtr->ResponseHeaderPtr);
      }
      else
      {
         *vecptr++ = sizeof(WATCH_NULL_STRING)-1;
         *vecptr++ = WATCH_NULL_STRING;
      }
      *vecptr++ = rqeptr->ProxyTaskPtr->ResponseContentLength;
      *vecptr++ = rqeptr->ProxyTaskPtr->ResponseBodyLength;
      *vecptr++ = rqeptr->ProxyTaskPtr->ResponseBufferNetCount;
      *vecptr++ = rqeptr->ProxyTaskPtr->ResponseBufferNetPtr;
      *vecptr++ = rqeptr->ProxyTaskPtr->ResponseBufferCacheCount;
      *vecptr++ = rqeptr->ProxyTaskPtr->ResponseBufferCachePtr;
      *vecptr++ = rqeptr->ProxyTaskPtr->NotCacheable;
      *vecptr++ = rqeptr->ProxyTaskPtr->ProxyCacheFileName;
      *vecptr++ = rqeptr->ProxyTaskPtr->ProxyCacheSuitable;
      *vecptr++ = rqeptr->ProxyTaskPtr->ProxyCacheFileSizeInBytes;
      *vecptr++ = rqeptr->ProxyTaskPtr->ProxyCacheLastModifiedHours;
      *vecptr++ = rqeptr->ProxyTaskPtr->ProxyCacheReadBytes;
      *vecptr++ = rqeptr->ProxyTaskPtr->ProxyRequestNumber;
      *vecptr++ = rqeptr->ProxyTaskPtr->ProxyCacheFileCdt;

      status = WriteFaol (Buffer, sizeof(Buffer), &Length,
                          ProxyTaskFao, &FaoVector);
      if (VMSnok (status) || status == SS$_BUFFEROVF)
         ErrorNoticed (status, "WriteFaol()", FI_LI);
      NetWrite (rqptr, 0, Buffer, Length);
   }

   vecptr = FaoVector;
   *vecptr++ = rqeptr->PutTaskPtr;
   *vecptr++ = rqeptr->SsiTaskPtr;
   *vecptr++ = rqeptr->UpdTaskPtr;

   status = WriteFaol (Buffer, sizeof(Buffer), &Length, PutFao, &FaoVector);
   if (VMSnok (status) || status == SS$_BUFFEROVF)
      ErrorNoticed (status, "WriteFaol()", FI_LI);
   NetWrite (rqptr, 0, Buffer, Length);
}

/****************************************************************************/

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    