/*****************************************************************************/
/*
                               ProxyMaint.c

See PROXYCACHE.C for commentary.  This module implements both the ROUTINE and
REACTIVE purge maintenance for the proxy file cache.  See PROXYCACHE.C module
for information on cache management strategy.


VERSION HISTORY
---------------
13-SEP-2000  MGD  ProxyMainReport() call refined to optionally provide
                  host name cache entries
08-JUL-2000  MGD  add VMS locking around cache scan (for clusters)
04-MAR-2000  MGD  use WriteFaol(), et.al.
03-JAN-2000  MGD  no changes required for ODS-5 compliance ... it's not
                  (see note in PROXYCACHE.C)
30-DEC-1999  MGD  change getdvi() to getdviw() (potential bugfix)
04-DEC-1999  MGD  rework startup cache device and report details
22-OCT-1999  MGD  inaccessable cache device non-fatal during startup
20-JUN-1999  MGD  allow for cache devices >9GB in space calculations,
                  some refinement to statistics report
19-AUG-1998  MGD  initial development (recommenced DEC 1998)
*/
/*****************************************************************************/

/* standard C header files */
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>

/* VMS related header files */
#include <atrdef.h>
#include <descrip.h>
#include <dvidef.h>
#include <fibdef.h>
#include <iodef.h>
#include <lkidef.h>
#include <lckdef.h>
#include <prvdef.h>
#include <rmsdef.h>
#include <ssdef.h>
#include <stsdef.h>

/* application-related header files */
#include "wasd.h"

#define WASD_MODULE "PROXYMAINT"

/******************/
/* global storage */
/******************/

char ErrorProxyMaintTooManyDevices [] = "Volume set has too many members.";

/* i.e. [000000...]*.HTC;* */
char  ProxyMaintScanFileSpec [] = PROXY_CACHE_SPEC;
int ProxyMaintScanFileSpecLength = sizeof(ProxyMaintScanFileSpec)-1;

int  ProxyMaintAllocBlocks,
     ProxyMaintDeletedAllocBlocks,
     ProxyMaintDeletedCount,
     ProxyMaintDeletedUsedBlocks,
     ProxyMaintFileAllocBlocks,
     ProxyMaintFileCount,
     ProxyMaintFileUsedBlocks,
     ProxyMaintPurgeAtHour,
     ProxyMaintPurgeHoursIndex,
     ProxyMaintReactivePurgeCount,
     ProxyMaintResultFileNameLength,
     ProxyMaintRoutinePurgeCount,
     ProxyMaintRoutineHoursIndex,
     ProxyMaintScanType,
     ProxyMaintStatScanCount,
     ProxyMaintTargetPercent;
     ProxyMaintUsedBlocks;

char  ProxyMaintEraseFileName [256],
      ProxyMaintExpandedFileName [256],
      ProxyMaintStatusStringReactive [128] = "<I>none</I>",
      ProxyMaintStatusStringRoutine [128] = "<I>none</I>",
      ProxyMaintStatusStringRoutNext [32] = "<I>none</I>",
      ProxyMaintStatusStringStatScan [128] = "<I>none</I>",
      ProxyMaintResultFileName [256];

struct FAB  ProxyMaintFab;
struct NAM  ProxyMaintNam;
struct FAB  ProxyMaintEraseFab;
struct NAM  ProxyMaintEraseNam;

struct  ProxyCacheFileAcpStruct  ProxyMaintFileAcpData;

/********************/
/* external storage */
/********************/

#ifdef DBUG
extern boolean Debug;
#else
#define Debug 0 
#endif

extern boolean  WatchEnabled,
                MonitorEnabled,
                ProxyCacheEnabled,
                ProxyCacheFreeSpaceAvailable,
                ProxyAddForwardedByEnabled,
                ProxyReportLog,
                ProxyReportCacheLog,
                ProxyServingEnabled;

extern int  OpcomMessages,
            ProxyCacheDeviceCheckMinutes,
            ProxyCacheDeviceMaxPercent,
            ProxyCacheDevicePurgePercent,
            ProxyCacheDeviceTargetPercent,
            ProxyCacheFileKBytesMax,
            ProxyCachePurgeList[],
            ProxyCachePurgeListCount,
            ProxyCacheReloadList[],
            ProxyCacheRoutineHourOfDay,
            ProxyHostCachePurgeHours,
            ProxyHostLookupRetryCount;

extern char  ErrorSanityCheck[],
             ServerGroupResName [],
             ServerHostPort[],
             Utility[];

extern char  *ProxyCacheReloadListPtr,
             *ProxyCachePurgeListPtr;

extern struct AccountingStruct  Accounting;
extern struct ConfigStruct  Config;
extern struct MsgStruct  Msgs;
extern struct ProxyAccountingStruct  ProxyAccounting;

/****************************************************************************/
/*
*/

ProxyMaintInit ()

{
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyMaintInit()\n");

   if (!ProxyServingEnabled) 
   {
      ProxyCacheEnabled = false;
      return;
   }

   /* check if the absolute maximum is being exceeded */
   ProxyCacheFreeSpaceAvailable = ProxyAccounting.FreeSpaceAvailable =
      ProxyMaintDeviceFreeSpace (ProxyCacheDeviceMaxPercent);

   /* if there is a problem with the cache device just forget it */
   if (!ProxyCacheEnabled) return;

   /* if space available schedule a purge, else if exceeded begin a purge */
   if (ProxyCacheFreeSpaceAvailable)
   {
      ProxyMaintPrintDeviceStats (true);
      ProxyMaintReactiveTimer (0);
   }
   else
      ProxyMaintScanBegin (PROXY_MAINT_SCAN_REACTIVE);

   /* schedule a routine purge */
   ProxyMaintRoutineTimer (0);
}

/****************************************************************************/
/*
Print cache device statistics to stdout.
*/

ProxyMaintPrintDeviceStats (boolean PrintToLog)

{
   int  status,
        FreeBlocks,
        FreeMBytes,
        FreePercent,
        TotalMBytes,
        TotalBlocks,
        UsedBlocks,
        UsedMBytes,
        UsedPercent;
   char  *DevNamePtr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyMaintPrintDeviceStats()\n");

   status = ProxyMaintDeviceStats (&DevNamePtr, &TotalBlocks,
                                   &UsedBlocks, &FreeBlocks);
   if (VMSok (status))
   {
      TotalMBytes = PROXY_MAINT_DEVICE_MBYTES(TotalBlocks);
      UsedMBytes = PROXY_MAINT_DEVICE_MBYTES(UsedBlocks);
      FreeMBytes = PROXY_MAINT_DEVICE_MBYTES(FreeBlocks);
      UsedPercent = PROXY_MAINT_DEVICE_PERCENT_USED(TotalBlocks,FreeBlocks);
      FreePercent = PROXY_MAINT_DEVICE_PERCENT_FREE(TotalBlocks,FreeBlocks);
   }
   else
      TotalBlocks = TotalMBytes = UsedBlocks = UsedMBytes =
         UsedPercent = FreeBlocks = FreeMBytes = FreePercent = 0;
      
   if (PrintToLog || ProxyReportLog)
      WriteFaoStdout (
"%!AZ-I-PROXYMAINT, cache device !AZ, %X!8XL\n\
!UL blocks (!ULMB), !UL used (!ULMB !UL%), !UL free (!ULMB !UL%)\n",
         Utility, DevNamePtr, status,
         TotalBlocks, TotalMBytes,
         UsedBlocks, UsedMBytes, UsedPercent,
         FreeBlocks, FreeMBytes, FreePercent);

   if (OpcomMessages & OPCOM_PROXY_MAINT)
      WriteFaoOpcom (
"%!AZ-I-PROXYMAINT, cache device !AZ, %X!8XL\r\n\
!UL blocks (!ULMB), !UL used (!ULMB !UL%), !UL free (!ULMB !UL%)",
         Utility, DevNamePtr, status,
         TotalBlocks, TotalMBytes,
         UsedBlocks, UsedMBytes, UsedPercent,
         FreeBlocks, FreeMBytes, FreePercent);
}

/****************************************************************************/
/*
Include cache device statistics in WATCH report.
*/

ProxyMaintWatchDeviceStats ()

{
   int  status,
        FreeBlocks,
        FreeMBytes,
        FreePercent,
        TotalMBytes,
        TotalBlocks,
        UsedBlocks,
        UsedMBytes,
        UsedPercent;
   char  *DevNamePtr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyMaintWatchDeviceStats()\n");

   status = ProxyMaintDeviceStats (&DevNamePtr, &TotalBlocks,
                                   &UsedBlocks, &FreeBlocks);
   if (VMSok (status))
   {
      TotalMBytes = PROXY_MAINT_DEVICE_MBYTES(TotalBlocks);
      UsedMBytes = PROXY_MAINT_DEVICE_MBYTES(UsedBlocks);
      FreeMBytes = PROXY_MAINT_DEVICE_MBYTES(FreeBlocks);
      UsedPercent = PROXY_MAINT_DEVICE_PERCENT_USED(TotalBlocks,FreeBlocks);
      FreePercent = PROXY_MAINT_DEVICE_PERCENT_FREE(TotalBlocks,FreeBlocks);
   }
   else
      TotalBlocks = TotalMBytes = UsedBlocks = UsedMBytes =
         UsedPercent = FreeBlocks = FreeMBytes = FreePercent = 0;

   WatchDataFormatted (
"!AZ %X!8XL !UL blocks (!ULMB), !UL used (!ULMB !UL%), !UL free (!ULMB !UL%)\n", 
      DevNamePtr, status, TotalBlocks, TotalMBytes,
      UsedBlocks, UsedMBytes, UsedPercent,
      FreeBlocks, FreeMBytes, FreePercent);
}

/****************************************************************************/
/*
Return information about file system space on the proxy cache device.  Will
function correctly with volume sets of up to eight members.  Returns a VMS
status code that should be checked for success.
*/

int ProxyMaintDeviceStats
(
char **DevNamePtrPtr,
int *TotalBlocksPtr,
int *UsedBlocksPtr,
int *FreeBlocksPtr
)
{
#define PROXY_MAINT_CACHE_DEVICE_MAX 8

   static int  DeviceCount,
               FreeBlocks,
               MaxBlock;
   static unsigned short  Length;
   static short  DevChannel [PROXY_MAINT_CACHE_DEVICE_MAX];
   static char  CacheDevName [65],
                DevName [65] = PROXY_CACHE_DEVICE;
   static $DESCRIPTOR (DevNameDsc, "");
   static struct {
      short BufferLength;
      short ItemCode;
      void  *BufferPtr;
      void  *LengthPtr;
   }
   DevNamItemList [] = 
   {
      { sizeof(CacheDevName), DVI$_DEVNAM, &CacheDevName, &Length },
      { 0, 0, 0, 0 }
   },
   NextDevNamItemList [] = 
   {
      { sizeof(DevName), DVI$_NEXTDEVNAM, &DevName, &Length },
      { 0, 0, 0, 0 }
   },
   BlocksItemList [] = 
   {
      { sizeof(MaxBlock), DVI$_MAXBLOCK, &MaxBlock, 0 },
      { sizeof(FreeBlocks), DVI$_FREEBLOCKS, &FreeBlocks, 0 },
      { 0, 0, 0, 0 }
   };

   int  idx,
        status,
        TotalBlocks,
        TotalFreeBlocks,
        TotalUsedBlocks;
   struct AnIOsb  IOsb;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyMaintDeviceStats()\n");

   if (DevNamePtrPtr != NULL) *DevNamePtrPtr = DevName;
   if (TotalBlocksPtr != NULL) *TotalBlocksPtr = 0;
   if (UsedBlocksPtr != NULL) *UsedBlocksPtr = 0;
   if (FreeBlocksPtr != NULL) *FreeBlocksPtr = 0;

   if (!DeviceCount)
   {
      /**************/
      /* initialize */
      /**************/

      DevNameDsc.dsc$w_length = strlen(PROXY_CACHE_ROOT);
      DevNameDsc.dsc$a_pointer = PROXY_CACHE_ROOT;

      /* assign a channel to the cache device (or primary if a volume set) */
      if (VMSnok (status =
          sys$assign (&DevNameDsc, &DevChannel[DeviceCount], 0, 0)))
         return (status);

      DeviceCount++;

      status = sys$getdviw (0, DevChannel[0], 0,
                            &DevNamItemList, &IOsb, 0, 0, 0);
      if (Debug)
         fprintf (stdout, "sys$getdviw() %%X%08.08X IOsb: %%X%08.08X\n",
                  status, IOsb.Status);

      if (VMSok (status)) status = IOsb.Status;
      if (VMSnok (status)) return (status);

      CacheDevName[Length] = '\0';
      if (CacheDevName[0] == '_')
         memmove (CacheDevName, CacheDevName+1, Length);
      if (Debug) fprintf (stdout, "|%s|\n", CacheDevName);

      /* loop assigning a channel to all devices in volume set (if it is!) */
      for (;;)
      {
         if (DeviceCount >= PROXY_MAINT_CACHE_DEVICE_MAX)
            ErrorExitVmsStatus (0, ErrorProxyMaintTooManyDevices, FI_LI);

         status = sys$getdviw (0, DevChannel[0], 0,
                               &NextDevNamItemList, &IOsb, 0, 0, 0);
         if (Debug)
            fprintf (stdout, "sys$getdviw() %%X%08.08X IOsb: %%X%08.08X\n",
                     status, IOsb.Status);

         if (VMSok (status)) status = IOsb.Status;
         if (VMSnok (status)) return (status);

         DevName[Length] = '\0';
         if (Debug) fprintf (stdout, "|%s|\n", DevName);

         if (!Length) break;

         DevNameDsc.dsc$w_length = Length;
         DevNameDsc.dsc$a_pointer = DevName;

         if (VMSnok (status =
             sys$assign (&DevNameDsc, &DevChannel[DeviceCount++], 0, 0)))
            return (status);
      }

      if (Debug) fprintf (stdout, "DeviceCount: %d\n", DeviceCount);
   }

   /***********/
   /* process */
   /***********/

   TotalBlocks = TotalFreeBlocks = 0;

   for (idx = 0; idx < DeviceCount; idx++)
   {
      status = sys$getdviw (0, DevChannel[idx], 0,
                            &BlocksItemList, &IOsb, 0, 0, 0);
      if (Debug)
         fprintf (stdout, "sys$getdviw() %%X%08.08X IOsb: %%X%08.08X\n",
                  status, IOsb.Status);
      if (VMSok (status)) status = IOsb.Status;
      if (VMSnok (status)) return (status);

      if (Debug) fprintf (stdout, "%d %d\n", MaxBlock, FreeBlocks);

      TotalBlocks += MaxBlock;
      TotalFreeBlocks += FreeBlocks;
   }

   TotalUsedBlocks = TotalBlocks - TotalFreeBlocks;

   if (Debug)
      fprintf (stdout, "%d %d %d %dMB %dMB %dMB %d%% %d%%\n",
               TotalBlocks, TotalFreeBlocks, TotalUsedBlocks,
               TotalBlocks >> 11, TotalFreeBlocks >> 11, TotalUsedBlocks >> 11,
               TotalFreeBlocks*100/TotalBlocks, 
               TotalUsedBlocks*100/TotalBlocks);

   if (DevNamePtrPtr != NULL) *DevNamePtrPtr = CacheDevName;
   if (TotalBlocksPtr != NULL) *TotalBlocksPtr = TotalBlocks;
   if (UsedBlocksPtr != NULL) *UsedBlocksPtr = TotalUsedBlocks;
   if (FreeBlocksPtr != NULL) *FreeBlocksPtr = TotalFreeBlocks;

   return (SS$_NORMAL);
}

/****************************************************************************/
/*
If the percentage of used space on the cache device is greater than or equal to
the specified percentage then return true, otherwise return false.
*/

boolean ProxyMaintDeviceFreeSpace (int LimitPercent)

{
   int  status,
        FreeBlocks,
        UsedPercent,
        TotalBlocks;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "ProxyMaintDeviceFreeSpace() %d\n", LimitPercent);

   if (VMSok (status =
       ProxyMaintDeviceStats (NULL, &TotalBlocks, NULL, &FreeBlocks)))
   {
      UsedPercent = PROXY_MAINT_DEVICE_PERCENT_USED(TotalBlocks,FreeBlocks);
      if (Debug) fprintf (stdout, "UsedPercent: %d\n", UsedPercent);

      if (UsedPercent > LimitPercent)
         return (false);
      else
         return (true);
   }
   else
   {
      WriteFaoStdout (
"%!AZ-W-PROXYMAINT, !20%D, cache device problem - PROXY CACHING DISABLED\n\
-!%M\n",
         Utility, 0, status);

      if (OpcomMessages & OPCOM_PROXY_MAINT)
         WriteFaoOpcom (
"%!AZ-W-PROXYMAINT, cache device problem - PROXY CACHING DISABLED\r\n\
-!%M",
            Utility, status);

      ProxyCacheEnabled = false;
      /* fudge ... indicate sufficient space, suppresses any purging */
      return (true);
   }
}

/*****************************************************************************/
/*
Attempts to enqueue an EX (exclusive) lock on a resource name for controlling
cache scanning (e.g. routine purge) in clusters.  If 'ObtainLock' is true the
lock is obtained, if false then it's released.  Returns true if the lock was
obtained, false if another server process already has it.  If the server is
executing with SYSLCK then this is made a system lock, if not it only applies
to servers executing with the same UIC group.
*/

int ProxyMaintCacheLock (int ObtainLock)

{
   unsigned long  SysLckMask [2] = { PRV$M_SYSLCK, 0 };
   static struct lksb  LockLksb;
   static char  LockName [32];
   static $DESCRIPTOR (LockNameDsc, LockName);

   boolean  ok;
   int  status,
        prvsts,
        LockFlags;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyMaintCacheLock() %d\n", ObtainLock);

   if (!LockName[0])
   {
      /* create resource name from the cluster/group name plus unique-ifier */ 
      strncpy (LockName, ServerGroupResName, 24);
      LockName[24] = '\0';
      strcat (LockName, "_PMAINT");
      LockNameDsc.dsc$w_length = strlen(LockName);
      if (Debug) fprintf (stdout, "|%s|\n", LockName);
   }

   prvsts = sys$setprv (1, &SysLckMask, 0, 0);
   if (Debug) fprintf (stdout, "sys$setprv() %%X%08.08X\n", prvsts);
   if (prvsts == SS$_NOTALLPRIV)
      LockFlags = LCK$M_NOQUEUE;
   else
      LockFlags = LCK$M_NOQUEUE | LCK$M_SYSTEM;

   if (ObtainLock)
   {
      status = sys$enqw (0, LCK$K_EXMODE, &LockLksb, LockFlags, &LockNameDsc,
                         0, 0, 0, 0, 0, 2, 0);
      if (Debug) fprintf (stdout, "sys$enqw() %%X%08.08X\n", status);
      if (VMSnok (status) && status != SS$_NOTQUEUED)
         ErrorNoticed (status, "sys$enqw()", FI_LI);
   }
   else
   {
      status = sys$deq (LockLksb.lksb$l_lkid, 0, 0, 0);
      if (Debug) fprintf (stdout, "sys$deq() %%X%08.08X\n", status);
      if (VMSnok (status)) ErrorNoticed (status, "sys$deq()", FI_LI);
   }

   prvsts = sys$setprv (0, &SysLckMask, 0, 0);
   if (Debug) fprintf (stdout, "sys$setprv() %%X%08.08X\n", prvsts);
   if (VMSnok (prvsts)) ErrorExitVmsStatus (prvsts, "sys$setprv()", FI_LI);

   if (VMSok (status)) return (true);
   return (false);
}

/*****************************************************************************/
/*
Schedules a timer event for every 'configuration parameter' minutes.  When
timer AST is delivered to this function the cache device free space is checked
against the 'configuration parameter' maximum percentage.  If less a purge
cycle is initiated.  If acceptable another timer event is queued.  This
function is also called from ProxyMaintInit() to initiate, and from
ProxyMaintScanEnd() to schedule another free space check.
*/

ProxyMaintReactiveTimer (int RequestId)

{
   int  status;
   unsigned long  PurgeDelta [2];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyMaintReactiveTimer() %d\n", RequestId);

   /* in case there's an outstanding timer */
   status = sys$cantim (&ProxyMaintReactiveTimer, 0);
   if (Debug) fprintf (stdout, "sys$cantim() %%X%08.08X\n", status);

   if (RequestId)
   {
      ProxyCacheFreeSpaceAvailable = ProxyAccounting.FreeSpaceAvailable =
         ProxyMaintDeviceFreeSpace (ProxyCacheDeviceMaxPercent);

      /* insufficient free space, there used to be, no other purge underway */
      if (!ProxyCacheFreeSpaceAvailable &&
          ProxyMaintScanType == PROXY_MAINT_SCAN_NONE)
      {
         /*********/
         /* purge */
         /*********/

         ProxyMaintScanBegin (PROXY_MAINT_SCAN_REACTIVE);
         return;
      }

      if (WatchEnabled & WATCH_PROXY_CACHE_MNT)
      {
         if (ProxyCacheFreeSpaceAvailable)
            WatchThis (NULL, FI_LI, WATCH_PROXY_CACHE_MNT,
                       "MAINT sufficient free SPACE !UL% max",
                       ProxyCacheDeviceMaxPercent);
         else
            WatchThis (NULL, FI_LI, WATCH_PROXY_CACHE_MNT,
                       "MAINT INSUFFICIENT free SPACE !UL% max",
                       ProxyCacheDeviceMaxPercent);
         ProxyMaintWatchDeviceStats ();
      }

      /* drop though to set a timer for the next check */
   }

   /* this is one minute delta */
   PurgeDelta[0] = -600000000;
   PurgeDelta[1] = -1;
   /* multiply by the number of minutes between free space checks */
   if (VMSnok (status =
       lib$mult_delta_time (&ProxyCacheDeviceCheckMinutes, &PurgeDelta)))
      ErrorExitVmsStatus (status, "lib$mult_delta_time()", FI_LI);

   /* queue up a timer event scheduling the next free space check */
   if (VMSnok (status =
       sys$setimr (0, &PurgeDelta, &ProxyMaintReactiveTimer,
                   &ProxyMaintReactiveTimer, 0)))
      ErrorExitVmsStatus (status, "sys$setimr()", FI_LI);
}

/*****************************************************************************/
/*
Schedule a routine purge for the configuration hour of today (if before that
hour) or tomorrow.
*/

ProxyMaintRoutineTimer (boolean RequestId)

{
   static unsigned short  NumTime [7];
   static unsigned long  BinTime [2],
                         DeltaTime [2],
                         NextTime [2];
   static char  String [32];
   static $DESCRIPTOR (StringDsc, String);
   static $DESCRIPTOR (TodayFaoDsc, "0 !UL:00:00.00");
   static $DESCRIPTOR (TomorrowFaoDsc, "1 !UL:00:00.00");

   int  status;
   unsigned short  Length;
   char  *cptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyMaintRoutineTimer() %d\n", RequestId);

   /* in case there's an outstanding timer */
   status = sys$cantim (&ProxyMaintRoutineTimer, 0);
   if (Debug) fprintf (stdout, "sys$cantim() %%X%08.08X\n", status);

   /* no other purge is underway, start a routine one */
   if (RequestId && ProxyMaintScanType == PROXY_MAINT_SCAN_NONE)
   {
      /*********/
      /* purge */
      /*********/

      ProxyMaintScanBegin (PROXY_MAINT_SCAN_ROUTINE);
   }

   sys$gettim (&BinTime);
   sys$numtim (&NumTime, &BinTime);

   /* either today (if soon enough) or tomorrow */
   StringDsc.dsc$w_length = sizeof(String)-1;
   if (NumTime[3] < ProxyCacheRoutineHourOfDay)
      status = sys$fao (&TodayFaoDsc, &Length, &StringDsc,
                        ProxyCacheRoutineHourOfDay);
   else
      status = sys$fao (&TomorrowFaoDsc, &Length, &StringDsc,
                        ProxyCacheRoutineHourOfDay);
   if (Debug) fprintf (stdout, "sys$fao() %%X%08.08X\n", status);
   String[StringDsc.dsc$w_length = Length] = '\0';
   if (Debug) fprintf (stdout, "|%s|\n", String);
      
   /* back to midnight this same day */
   NumTime[3] = NumTime[4] = NumTime[5] = NumTime[6] = 0;
   status = lib$cvt_vectim (&NumTime, &DeltaTime);
   if (Debug) fprintf (stdout, "lib$cvt_vectim() %%X%08.08X\n", status);

   /* add the midnight and the generated today/tomorrow delta time */
   status = sys$bintim (&StringDsc, &BinTime);
   if (Debug) fprintf (stdout, "sys$bintim() %%X%08.08X\n", status);
   status = lib$add_times(&BinTime, &DeltaTime, &NextTime);
   if (Debug) fprintf (stdout, "lib$add_times() %%X%08.08X\n", status);

   /* convert it to ASCII */
   StringDsc.dsc$w_length = sizeof(String)-1;
   status = sys$asctim (&Length, &StringDsc, &NextTime, 0);
   if (Debug) fprintf (stdout, "sys$asctim() %%X%08.08X\n", status);
   String[17] = '\0';
   strcpy (ProxyMaintStatusStringRoutNext, String);
   if (String[0] == ' ') String[0] = '0';

   if (ProxyReportLog)
      WriteFaoStdout ("%!AZ-I-PROXYMAINT, next routine purge begins !AZ\n",
                      Utility, String);
   if (OpcomMessages & OPCOM_PROXY_MAINT)
      WriteFaoOpcom ("%!AZ-I-PROXYMAINT, next routine purge begins !AZ",
                     Utility, String);

   if (VMSnok (status =
       sys$setimr (0, &NextTime, &ProxyMaintRoutineTimer,
                   &ProxyMaintRoutineTimer, 0)))
      ErrorExitVmsStatus (status, "sys$setimr()", FI_LI);
}

/****************************************************************************/
/*
Initialize ready to begin a routine or purge pass.
*/

char* ProxyMaintScanBegin (int ScanType)

{
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyMaintScanBegin()\n");

   /* attempt to obtain the cache scan lock */
   if (!ProxyMaintCacheLock (1))
   {
      if (ProxyReportLog)
         WriteFaoStdout ("%!AZ-W-PROXYMAINT, !20%D, cache already locked\n",
                         Utility, 0);
      if (OpcomMessages & OPCOM_PROXY_MAINT)
         WriteFaoOpcom ("%!AZ-W-PROXYMAINT, cache already locked",
                        Utility);
      return ("Proxy cache locked (another scan must be in-progress).");
   }

   ProxyMaintScanType = ScanType;
   ProxyMaintTargetPercent = ProxyCacheDeviceTargetPercent;
   ProxyMaintPurgeAtHour = ProxyCachePurgeList[ProxyMaintPurgeHoursIndex = 0];

   ProxyMaintDeletedCount =
      ProxyMaintDeletedAllocBlocks =
      ProxyMaintDeletedUsedBlocks =
      ProxyMaintAllocBlocks =
      ProxyMaintUsedBlocks = 0;

   switch (ProxyMaintScanType)
   {
      case PROXY_MAINT_SCAN_STATISTICS :

         /****************************/
         /* getting cache statistics */
         /****************************/

         if (WatchEnabled & WATCH_PROXY_CACHE_MNT)
         {
            WatchThis (NULL, FI_LI, WATCH_PROXY_CACHE_MNT,
                       "MAINT begin STATISTICS SCAN");
            ProxyMaintWatchDeviceStats ();
         }

         if (ProxyReportLog)
            WriteFaoStdout ("%!AZ-I-PROXYMAINT, !20%D, begin statistics scan\n",
                            Utility, 0);
         if (OpcomMessages & OPCOM_PROXY_MAINT)
            WriteFaoOpcom ("%!AZ-I-PROXYMAINT, begin statistics scan",
                           Utility);
         ProxyMaintPrintDeviceStats (false);

         ProxyMaintStatScanCount++;

         WriteFao (ProxyMaintStatusStringStatScan,
                   sizeof(ProxyMaintStatusStringStatScan),
                   NULL, "!UL, !20%D<BR><I>in-progress</I>",
                   ProxyMaintStatScanCount, 0);

         WriteFao (ProxyAccounting.StatusString,
                   sizeof(ProxyAccounting.StatusString),
                   NULL, "!AZ, STATSCAN in-progress", DigitDayTime(0));

         ProxyMaintScanNow ();
         return (NULL);

      case PROXY_MAINT_SCAN_REACTIVE :

         /********************************/
         /* purging to create free space */
         /********************************/

         if (WatchEnabled & WATCH_PROXY_CACHE_MNT)
         {
            WatchThis (NULL, FI_LI, WATCH_PROXY_CACHE_MNT,
               "MAINT begin REACTIVE PURGE >!UL hours !UL% max !UL% target",
                      ProxyMaintPurgeAtHour, ProxyCacheDeviceMaxPercent,
                      ProxyMaintTargetPercent);
            ProxyMaintWatchDeviceStats ();
         }

         if (ProxyReportLog)
            WriteFaoStdout (
"%!AZ-I-PROXYMAINT, !20%D, begin reactive purge\n\
(>!UL hours, !UL% max, !UL% target)\n",
               Utility, 0,
               ProxyMaintPurgeAtHour,  ProxyCacheDeviceMaxPercent,
               ProxyMaintTargetPercent);
         if (OpcomMessages & OPCOM_PROXY_MAINT)
            WriteFaoOpcom (
"%!AZ-I-PROXYMAINT, begin reactive purge\r\n\
(>!UL hours, !UL% max, !UL% target)",
                Utility,
                ProxyMaintPurgeAtHour,  ProxyCacheDeviceMaxPercent,
                ProxyMaintTargetPercent);
         ProxyMaintPrintDeviceStats (false);

         ProxyMaintReactivePurgeCount++;

         WriteFao (ProxyMaintStatusStringReactive,
                   sizeof(ProxyMaintStatusStringReactive),
                   NULL, "!UL, !20%D<BR><I>in-progress</I>",
                   ProxyMaintReactivePurgeCount, 0);

         WriteFao (ProxyAccounting.StatusString,
                   sizeof(ProxyAccounting.StatusString), NULL,
"!AZ, REACTIVE purge, >!UL hours, !UL% max, !UL% target",
                   DigitDayTime(0), ProxyMaintPurgeAtHour,
                   ProxyCacheDeviceMaxPercent, ProxyMaintTargetPercent);

         ProxyMaintScanNow ();
         return (NULL);

      case PROXY_MAINT_SCAN_ROUTINE :

         /*******************/
         /* routine cleanup */
         /*******************/

         if (WatchEnabled & WATCH_PROXY_CACHE_MNT)
         {
            WatchThis (NULL, FI_LI, WATCH_PROXY_CACHE_MNT,
                       "MAINT begin ROUTINE PURGE >!UL hours",
                       ProxyMaintPurgeAtHour);
            ProxyMaintWatchDeviceStats ();
         }

         if (ProxyReportLog)
            WriteFaoStdout (
"%!AZ-I-PROXYMAINT, !20%D, begin routine purge (>!UL hours)\n",
               Utility, 0, ProxyMaintPurgeAtHour);
         if (OpcomMessages & OPCOM_PROXY_MAINT)
            WriteFaoOpcom (
"%!AZ-I-PROXYMAINT, begin routine purge (>!UL hours)",
               Utility, ProxyMaintPurgeAtHour);
         ProxyMaintPrintDeviceStats (false);

         ProxyMaintRoutinePurgeCount++;

         WriteFao (ProxyMaintStatusStringRoutine,
                   sizeof(ProxyMaintStatusStringRoutine),
                   NULL, "!UL, !20%D<BR><I>in-progress</I>",
                   ProxyMaintRoutinePurgeCount, 0);

         WriteFao (ProxyAccounting.StatusString,
                   sizeof(ProxyAccounting.StatusString),
                   NULL, "!AZ, ROUTINE in-progress", DigitDayTime(0));

         ProxyMaintScanNow ();
         return (NULL);
   }

   ErrorExitVmsStatus (SS$_BUGCHECK, ErrorSanityCheck, FI_LI);
}

/****************************************************************************/
/*
End of a single pass through the entire cache directory tree.  A PURGE will be
made up of multiple passes, each using the next access hours found in the
'ProxyCachePurgeList' array.  A ROUTINE purge will only make the one pass
though the tree using only the hours in the zero element.
*/

ProxyMaintScanEnd ()

{
   int  status,
        FreeBlocks,
        FreePercent,
        TotalBlocks;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyMaintScanEnd()\n");

   /* release the cache lock */
   ProxyMaintCacheLock (0);

   ProxyCacheFreeSpaceAvailable = ProxyAccounting.FreeSpaceAvailable =
      ProxyMaintDeviceFreeSpace (ProxyMaintTargetPercent);

   switch (ProxyMaintScanType)
   {
      case PROXY_MAINT_SCAN_STATISTICS :

         /*******************/
         /* cach statistics */
         /*******************/

         if (WatchEnabled & WATCH_PROXY_CACHE_MNT)
         {
            WatchThis (NULL, FI_LI, WATCH_PROXY_CACHE_MNT,
               "MAINT end STATISTICS SCAN !UL files (!UL/!UL blocks)",
               ProxyMaintFileCount, ProxyMaintUsedBlocks,
               ProxyMaintAllocBlocks);
            ProxyMaintWatchDeviceStats ();
         }

         if (ProxyReportLog)
            WriteFaoStdout (
"%!AZ-I-PROXYMAINT, !20%D, end statistics scan\n\
!UL files (!UL/!UL)\n",
               Utility, 0,
               ProxyMaintFileCount, ProxyMaintUsedBlocks,
               ProxyMaintAllocBlocks);
         if (OpcomMessages & OPCOM_PROXY_MAINT)
            WriteFaoOpcom (
"%!AZ-I-PROXYMAINT, end statistics scan\r\n\
!UL files (!UL/!UL)",
               Utility,
               ProxyMaintFileCount, ProxyMaintUsedBlocks,
               ProxyMaintAllocBlocks);
         ProxyMaintPrintDeviceStats (false);

         WriteFao (ProxyMaintStatusStringStatScan,
                   sizeof(ProxyMaintStatusStringStatScan), NULL,
                   "!UL, !20%D<BR>!UL files (!UL/!UL)",
                   ProxyMaintStatScanCount, 0,
                   ProxyMaintFileCount, ProxyMaintUsedBlocks,
                   ProxyMaintAllocBlocks);

         WriteFao (ProxyAccounting.StatusString,
                   sizeof(ProxyAccounting.StatusString), NULL,
                   "!AZ, !UL files (!UL/!UL)",
                   DigitDayTime(0), ProxyMaintFileCount,
                   ProxyMaintUsedBlocks, ProxyMaintAllocBlocks);

         ProxyMaintScanType = PROXY_MAINT_SCAN_NONE;
         break;

      case PROXY_MAINT_SCAN_REACTIVE :

         /********************************/
         /* purging to create free space */
         /********************************/

         /* if reached desired percent, or one complete purge, or no files */
         if (ProxyCacheFreeSpaceAvailable ||
             ProxyMaintPurgeHoursIndex >= ProxyCachePurgeListCount ||
             !ProxyMaintFileCount)
         {
            /*****************/
            /* cease purging */
            /*****************/

            if (WatchEnabled & WATCH_PROXY_CACHE_MNT)
               WatchThis (NULL, FI_LI, WATCH_PROXY_CACHE_MNT,
"MAINT end REACTIVE PURGE \
!UL files (!UL/!UL blocks) !UL deleted (!UL/!UL blocks)",
                  ProxyMaintFileCount, ProxyMaintUsedBlocks,
                  ProxyMaintAllocBlocks, ProxyMaintDeletedCount,
                  ProxyMaintDeletedUsedBlocks, ProxyMaintDeletedAllocBlocks);

            if (ProxyReportLog)
               WriteFaoStdout (
"%!AZ-I-PROXYMAINT, !20%D, end reactive purge\n\
!UL files (!UL/!UL), !UL deleted (!UL/!UL)\n",
                  Utility, 0,
                  ProxyMaintFileCount, ProxyMaintUsedBlocks,
                  ProxyMaintAllocBlocks, ProxyMaintDeletedCount,
                  ProxyMaintDeletedUsedBlocks,
                  ProxyMaintDeletedAllocBlocks);
            if (OpcomMessages & OPCOM_PROXY_MAINT)
               WriteFaoOpcom (
"%!AZ-I-PROXYMAINT, end reactive purge\r\n\
!UL files (!UL/!UL), !UL deleted (!UL/!UL)",
                  Utility,
                  ProxyMaintFileCount, ProxyMaintUsedBlocks,
                  ProxyMaintAllocBlocks, ProxyMaintDeletedCount,
                  ProxyMaintDeletedUsedBlocks,
                  ProxyMaintDeletedAllocBlocks);
            ProxyMaintPrintDeviceStats (false);

            WriteFao (ProxyMaintStatusStringReactive,
                      sizeof(ProxyMaintStatusStringReactive), NULL, 
"!UL, !20%D<BR>!UL files (!UL/!UL), !UL deleted (!UL/!UL)",
                      ProxyMaintReactivePurgeCount, 0,
                      ProxyMaintFileCount, ProxyMaintUsedBlocks,
                      ProxyMaintAllocBlocks, ProxyMaintDeletedCount,
                      ProxyMaintDeletedUsedBlocks,
                      ProxyMaintDeletedAllocBlocks);

            WriteFao (ProxyAccounting.StatusString,
                      sizeof(ProxyAccounting.StatusString), NULL,
"!AZ, !UL files (!UL/!UL), !UL deleted (!UL/!UL)",
                      DigitDayTime(0), ProxyMaintFileCount,
                      ProxyMaintUsedBlocks, ProxyMaintAllocBlocks,
                      ProxyMaintDeletedCount, ProxyMaintDeletedUsedBlocks,
                      ProxyMaintDeletedAllocBlocks);

            /* set the timer for the next purge check */
            ProxyMaintReactiveTimer (false);

            ProxyMaintScanType = PROXY_MAINT_SCAN_NONE;
            break;
         }

         /**********************/
         /* next pass of purge */
         /**********************/

         ProxyMaintPurgeAtHour =
            ProxyCachePurgeList[++ProxyMaintPurgeHoursIndex];

         if (WatchEnabled & WATCH_PROXY_CACHE_MNT)
         {
            WatchThis (NULL, FI_LI, WATCH_PROXY_CACHE_MNT,
"MAINT end pass REACTIVE PURGE \
!UL files (!UL/!UL blocks) !UL deleted (!UL/!UL blocks)",
               ProxyMaintFileCount, ProxyMaintUsedBlocks,
               ProxyMaintAllocBlocks, ProxyMaintDeletedCount,
               ProxyMaintDeletedUsedBlocks, ProxyMaintDeletedAllocBlocks);

            WatchThis (NULL, FI_LI, WATCH_PROXY_CACHE_MNT,
               "MAINT next REACTIVE PURGE >!UL hours !UL% max !UL% target",
               ProxyMaintPurgeAtHour, ProxyCacheDeviceMaxPercent,
               ProxyMaintTargetPercent);

            ProxyMaintWatchDeviceStats ();
         }

         if (ProxyReportLog)
            WriteFaoStdout (
"%!AZ-I-PROXYMAINT, !20%D, end reactive pass\n\
!UL files (!UL/!UL), !UL deleted (!UL/!UL)\n\
next pass >!UL hours !UL% max !UL% target\n",
               Utility, 0,
               ProxyMaintFileCount, ProxyMaintUsedBlocks,
               ProxyMaintAllocBlocks, ProxyMaintDeletedCount,
               ProxyMaintDeletedUsedBlocks,
               ProxyMaintDeletedAllocBlocks,
               ProxyMaintPurgeAtHour,  ProxyCacheDeviceMaxPercent,
               ProxyMaintTargetPercent);
         if (OpcomMessages & OPCOM_PROXY_MAINT)
            WriteFaoOpcom (
"%!AZ-I-PROXYMAINT, end reactive pass\r\n\
!UL files (!UL/!UL), !UL deleted (!UL/!UL)\r\n\
next pass >!UL hours !UL% max !UL% target",
               Utility,
               ProxyMaintFileCount, ProxyMaintUsedBlocks,
               ProxyMaintAllocBlocks, ProxyMaintDeletedCount,
               ProxyMaintDeletedUsedBlocks,
               ProxyMaintDeletedAllocBlocks,
               ProxyMaintPurgeAtHour,  ProxyCacheDeviceMaxPercent,
               ProxyMaintTargetPercent);
         ProxyMaintPrintDeviceStats (false);

         WriteFao (ProxyAccounting.StatusString,
                   sizeof(ProxyAccounting.StatusString), NULL,
"!AZ, REACTIVE purge, >!UL hours, !UL% max, !UL% target",
                   DigitDayTime(0), ProxyMaintPurgeAtHour,
                   ProxyCacheDeviceMaxPercent, ProxyMaintTargetPercent);

         ProxyMaintScanNow ();
         break;

      case PROXY_MAINT_SCAN_ROUTINE :

         /*******************/
         /* routine cleanup */
         /*******************/

         if (WatchEnabled & WATCH_PROXY_CACHE_MNT)
         {
            WatchThis (NULL, FI_LI, WATCH_PROXY_CACHE_MNT,
"MAINT end ROUTINE PURGE \
!UL files (!UL/!UL blocks) !UL deleted (!UL/!UL blocks)",
               ProxyMaintFileCount, ProxyMaintUsedBlocks,
               ProxyMaintAllocBlocks, ProxyMaintDeletedCount,
               ProxyMaintDeletedUsedBlocks, ProxyMaintDeletedAllocBlocks);
            ProxyMaintWatchDeviceStats ();
         }

         if (ProxyReportLog)
            WriteFaoStdout (
"%!AZ-I-PROXYMAINT, !20%D, end routine purge\n\
!UL files (!UL/!UL), !UL deleted (!UL/!UL)\n",
               Utility, 0,
               ProxyMaintFileCount, ProxyMaintUsedBlocks,
               ProxyMaintAllocBlocks, ProxyMaintDeletedCount,
               ProxyMaintDeletedUsedBlocks,
               ProxyMaintDeletedAllocBlocks);
         if (OpcomMessages & OPCOM_PROXY_MAINT)
            WriteFaoOpcom (
"%!AZ-I-PROXYMAINT, end routine purge\r\n\
!UL files (!UL/!UL), !UL deleted (!UL/!UL)",
               Utility,
               ProxyMaintFileCount, ProxyMaintUsedBlocks,
               ProxyMaintAllocBlocks, ProxyMaintDeletedCount,
               ProxyMaintDeletedUsedBlocks,
               ProxyMaintDeletedAllocBlocks);
         ProxyMaintPrintDeviceStats (false);

         WriteFao (ProxyMaintStatusStringRoutine,
                   sizeof(ProxyMaintStatusStringRoutine), NULL, 
"!UL, !20%D<BR>!UL files (!UL/!UL), !UL deleted (!UL/!UL)",
                   ProxyMaintRoutinePurgeCount, 0,
                   ProxyMaintFileCount, ProxyMaintUsedBlocks,
                   ProxyMaintAllocBlocks, ProxyMaintDeletedCount,
                   ProxyMaintDeletedUsedBlocks,
                   ProxyMaintDeletedAllocBlocks);

         WriteFao (ProxyAccounting.StatusString,
                   sizeof(ProxyAccounting.StatusString), NULL,
"!AZ, !UL files (!UL/!UL), !UL deleted (!UL/!UL)",
                   DigitDayTime(0), ProxyMaintFileCount,
                   ProxyMaintUsedBlocks, ProxyMaintAllocBlocks,
                   ProxyMaintDeletedCount, ProxyMaintDeletedUsedBlocks,
                   ProxyMaintDeletedAllocBlocks);

         ProxyMaintScanType = PROXY_MAINT_SCAN_NONE;
         break;

      default :
         ErrorExitVmsStatus (SS$_BUGCHECK, ErrorSanityCheck, FI_LI);
   }

   /* set logical names used by HTTPd monitor utility */
   if (MonitorEnabled) DefineMonitorLogicals (NULL);
}

/****************************************************************************/
/*
Initialize the RMS structures ready for the file search.
*/

ProxyMaintScanNow ()

{
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "ProxyMaintScanNow() |%s|\n", ProxyMaintScanFileSpec);

   /* set logical names used by HTTPd monitor utility */
   if (MonitorEnabled) DefineMonitorLogicals (NULL);

   ProxyMaintFab = cc$rms_fab;
   ProxyMaintFab.fab$l_fna = ProxyMaintScanFileSpec;
   ProxyMaintFab.fab$b_fns = ProxyMaintScanFileSpecLength;
   ProxyMaintFab.fab$l_nam = &ProxyMaintNam;

   /* initialize the NAM block */
   ProxyMaintNam = cc$rms_nam;
   ProxyMaintNam.nam$l_esa = ProxyMaintExpandedFileName;
   ProxyMaintNam.nam$b_ess = sizeof(ProxyMaintExpandedFileName)-1;
   ProxyMaintNam.nam$l_rsa = ProxyMaintResultFileName;
   ProxyMaintNam.nam$b_rss = sizeof(ProxyMaintResultFileName)-1;

   status = sys$parse (&ProxyMaintFab, 0, 0);
   if (Debug) fprintf (stdout, "sys$parse() %%X%08.08X\n", status);
   if (VMSnok (status))
      ErrorExitVmsStatus (status, "sys$parse()", FI_LI);

   ProxyMaintFileCount = 0;

   /* now we've done the parse do the searching asynchronously */
   ProxyMaintFab.fab$l_fop = FAB$M_ASY;

   ProxyMaintScanSearch ();
}

/****************************************************************************/
/*
Simply queue another asynchronous RMS search.
*/

ProxyMaintScanSearch ()

{
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyMaintScanSearch()\n");

   switch (ProxyMaintScanType)
   {
      case PROXY_MAINT_SCAN_STATISTICS :

         /* just continue through the complete scan */
         break;

      case PROXY_MAINT_SCAN_REACTIVE :

         /* only recheck free space after every ten files deleted */
         if (ProxyMaintFileCount &&
             (!ProxyMaintDeletedCount || ProxyMaintDeletedCount % 10))
            break;

         if (ProxyMaintDeviceFreeSpace (ProxyMaintTargetPercent))
         {
            /* reached our desired limit, cease purging */
            ProxyMaintScanEnd ();
            return;
         }
         break;

      case PROXY_MAINT_SCAN_ROUTINE :

         /* just continue through the complete routine purge */
         break;

      default :
         ErrorExitVmsStatus (SS$_BUGCHECK, ErrorSanityCheck, FI_LI);
   }

   if (WatchEnabled & WATCH_PROXY_CACHE_MNT)
   {
      if (ProxyMaintFileCount &&
          ProxyMaintFileCount % PROXY_MAINT_SCAN_WATCH_FILES == 0)
      {
         /* WATCH status entry every so many files */
         WatchThis (NULL, FI_LI, WATCH_PROXY_CACHE_MNT,
"MAINT purge STATUS !UL files (!UL/!UL blocks) !UL deleted (!UL/!UL blocks)",
            ProxyMaintFileCount, ProxyMaintUsedBlocks,
            ProxyMaintAllocBlocks, ProxyMaintDeletedCount,
            ProxyMaintDeletedUsedBlocks, ProxyMaintDeletedAllocBlocks);
         ProxyMaintWatchDeviceStats ();
      }
   }

   status = sys$search (&ProxyMaintFab, &ProxyMaintScanSearchAst,
                                        &ProxyMaintScanSearchAst);
   if (Debug) fprintf (stdout, "sys$search() %%X%08.08X\n", status);
}

/****************************************************************************/
/*
AST from sys$search().  Check status and report any error.  Otherwise generate
and queue an asynchronous ACP file information QIO.
*/

ProxyMaintScanSearchAst (struct FAB *FabPtr)

{
   static $DESCRIPTOR (DeviceDsc, "");

   register struct ProxyCacheFileAcpStruct  *faptr;

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "ProxyMaintScanSearchAst() %%X%08.08X\n",
               FabPtr->fab$l_sts);

   if (VMSnok (status = FabPtr->fab$l_sts))
   {
      /****************/
      /* search error */
      /****************/

      if (status == RMS$_NMF || (!ProxyMaintFileCount && status == RMS$_FNF))
      {
         /* end of search */
         ProxyMaintScanEnd ();
         return;
      }
      if (status == RMS$_FNF)
      {
         /* file probably deleted during search, just continue searching */
         ProxyMaintScanSearch ();
         return;
      }

      WriteFaoStdout (
"%!AZ-W-PROXYMAINT, !20%D, cache maintenance problem\n\
-!%M\n",
         Utility, 0, status);

      if (OpcomMessages & OPCOM_PROXY_MAINT)
         WriteFaoOpcom (
"%!AZ-W-PROXYMAINT, cache maintenance problem\r\n\
-!%M",
            Utility, status);

      ProxyMaintScanEnd ();
      return;
   }

   ProxyMaintFileCount++;

   ProxyMaintResultFileName[ProxyMaintResultFileNameLength =
                            ProxyMaintNam.nam$b_rsl] = '\0';
   if (Debug) fprintf (stdout, "|%s|\n", ProxyMaintResultFileName);

   /************/
   /* file ACP */
   /************/

   faptr = &ProxyMaintFileAcpData;

   /* clean the structure out */
   memset (faptr, sizeof(ProxyMaintFileAcpData), 0);

   /* assign a channel to the disk device containing the file */
   DeviceDsc.dsc$a_pointer = ProxyMaintNam.nam$l_dev;
   DeviceDsc.dsc$w_length = ProxyMaintNam.nam$b_dev;

   status = sys$assign (&DeviceDsc, &faptr->Channel, 0, 0, 0);
   if (Debug) fprintf (stdout, "sys$assign() %%X%08.08X\n", status);
   if (VMSnok (status))
      ErrorExitVmsStatus (status, "sys$assign()", FI_LI);

   /* set up the File Information Block for the ACP interface */
   faptr->FileFibAcpDsc.dsc$w_length = sizeof(struct fibdef);
   faptr->FileFibAcpDsc.dsc$a_pointer = &faptr->FileFib;

   memcpy (&faptr->FileFib.fib$w_did, &ProxyMaintNam.nam$w_did, 6);

   faptr->FileNameAcpDsc.dsc$a_pointer = ProxyMaintNam.nam$l_name;
   faptr->FileNameAcpDsc.dsc$w_length = ProxyMaintNam.nam$b_name +
                                        ProxyMaintNam.nam$b_type +
                                        ProxyMaintNam.nam$b_ver;
   if (Debug)
      fprintf (stdout, "name |%*.*s|\n",
               faptr->FileNameAcpDsc.dsc$w_length,
               faptr->FileNameAcpDsc.dsc$w_length,
               faptr->FileNameAcpDsc.dsc$a_pointer);

   faptr->FileAtr[0].atr$w_size = sizeof(faptr->CdtBinTime);
   faptr->FileAtr[0].atr$w_type = ATR$C_CREDATE;
   faptr->FileAtr[0].atr$l_addr = &faptr->CdtBinTime;
   faptr->FileAtr[1].atr$w_size = sizeof(faptr->RdtBinTime);
   faptr->FileAtr[1].atr$w_type = ATR$C_REVDATE;
   faptr->FileAtr[1].atr$l_addr = &faptr->RdtBinTime;
   faptr->FileAtr[2].atr$w_size = sizeof(faptr->EdtBinTime);
   faptr->FileAtr[2].atr$w_type = ATR$C_EXPDATE;
   faptr->FileAtr[2].atr$l_addr = &faptr->EdtBinTime;
   faptr->FileAtr[3].atr$w_size = sizeof(faptr->AscDates);
   faptr->FileAtr[3].atr$w_type = ATR$C_ASCDATES;
   faptr->FileAtr[3].atr$l_addr = &faptr->AscDates;
   faptr->FileAtr[4].atr$w_size = sizeof(faptr->RecAttr);
   faptr->FileAtr[4].atr$w_type = ATR$C_RECATTR;
   faptr->FileAtr[4].atr$l_addr = &faptr->RecAttr;
   faptr->FileAtr[5].atr$w_size =
      faptr->FileAtr[5].atr$w_type =
      faptr->FileAtr[5].atr$l_addr = 0;

   status = sys$qio (0, faptr->Channel, IO$_ACCESS,
                     &faptr->AcpIOsb, &ProxyMaintAcpInfoAst, 0, 
                     &faptr->FileFibAcpDsc, &faptr->FileNameAcpDsc, 0, 0,
                     &faptr->FileAtr, 0);
   if (Debug) fprintf (stdout, "sys$qio() %%X%08.08X\n", status);
}

/****************************************************************************/
/*
AST from ACP QIO. Calculate the relevant file information and determine if it
should be purged (deleted).  If not then just queue another search.  If it
should be then initialize the deletion RMS structures ready for sys$erase().
*/

ProxyMaintAcpInfoAst ()

{
   register struct ProxyCacheFileAcpStruct  *faptr;

   int  status,
        AccessHours;
   unsigned long  AllocatedVbn,
                  EndOfFileVbn;
   unsigned long  CurrentBinTime[2];

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "ProxyMaintAcpInfoAst() %%X%08.08X\n",
               ProxyMaintFileAcpData.AcpIOsb.Status);

   faptr = &ProxyMaintFileAcpData;

   sys$dassgn (faptr->Channel);

   if (VMSnok (status = faptr->AcpIOsb.Status))
   {
      /*************/
      /* ACP error */
      /*************/

      WriteFaoStdout (
         "%!AZ-W-PROXYMAINT, file ACP error (!AZ !UL)\n-!%M\n \\!AZ\\\n",
         Utility, FI_LI, status, ProxyMaintResultFileName);

      /* file probably deleted during search, just continue searching */
      ProxyMaintScanSearch ();
      return;
   }

   /**************/
   /* ACP QIO OK */
   /**************/

   AllocatedVbn = faptr->RecAttr.AllocatedVbnLo +
                  (faptr->RecAttr.AllocatedVbnHi << 16);
   EndOfFileVbn = faptr->RecAttr.EndOfFileVbnLo +
                  (faptr->RecAttr.EndOfFileVbnHi << 16);
   if (Debug)
      fprintf (stdout,
         "AllocatedVbn: %d EndOfFileVbn: %d FirstFreeByte %d\n",
         AllocatedVbn, EndOfFileVbn, faptr->RecAttr.FirstFreeByte);

   ProxyMaintAllocBlocks += ProxyMaintFileAllocBlocks = AllocatedVbn;
   if (EndOfFileVbn >= 1 && faptr->RecAttr.FirstFreeByte)
      ProxyMaintUsedBlocks += ProxyMaintFileUsedBlocks = EndOfFileVbn;
   else
      ProxyMaintFileUsedBlocks = 0;

   switch (ProxyMaintScanType)
   {
      case PROXY_MAINT_SCAN_STATISTICS :

         /***************/
         /* search next */
         /***************/

         ProxyMaintScanSearch ();
         return;

      case PROXY_MAINT_SCAN_REACTIVE :
      case PROXY_MAINT_SCAN_ROUTINE :

         /* check how long ago the file was last accessed */
         sys$gettim (&CurrentBinTime);
         AccessHours = ProxyCacheAgeHours (&CurrentBinTime, &faptr->EdtBinTime);
         if (Debug) fprintf (stdout, "access: %d\n", AccessHours);

         if (AccessHours < ProxyMaintPurgeAtHour)
         {
            /***************/
            /* search next */
            /***************/

            ProxyMaintScanSearch ();
            return;
         }

         /* drop through to delete the file */
         break;

      default :
         ErrorExitVmsStatus (SS$_BUGCHECK, ErrorSanityCheck, FI_LI);
   }

   /**************/
   /* delete file *
   /**************/

   if (Debug)
      fprintf (stdout, "%d %d\n",
         AccessHours, ProxyCachePurgeList[ProxyMaintPurgeHoursIndex]);

   ProxyMaintEraseFab = cc$rms_fab;
   ProxyMaintEraseFab.fab$l_fna = ProxyMaintResultFileName;
   ProxyMaintEraseFab.fab$b_fns = ProxyMaintResultFileNameLength;
   ProxyMaintEraseFab.fab$l_nam = &ProxyMaintEraseNam;

   /* initialize the NAM block */
   ProxyMaintEraseNam = cc$rms_nam;
   ProxyMaintEraseNam.nam$l_esa = ProxyMaintEraseFileName;
   ProxyMaintEraseNam.nam$b_ess = sizeof(ProxyMaintEraseFileName)-1;

   status = sys$parse (&ProxyMaintEraseFab, &ProxyMaintScanParseAst,
                                            &ProxyMaintScanParseAst);
   if (Debug) fprintf (stdout, "sys$parse() %%X%08.08X\n", status);
}

/****************************************************************************/
/*
AST from sys$parse().  Check status and report any error.  Otherwise perform an
asynchronous earse (delete) on the file.
*/

ProxyMaintScanParseAst (struct FAB *FabPtr)

{
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "ProxyMaintScanParseAst() %%X%08.08X\n",
               FabPtr->fab$l_sts);

   if (VMSnok (status = ProxyMaintEraseFab.fab$l_sts))
   {
      /* parse error (serious) */
      ErrorExitVmsStatus (status, "sys$parse()", FI_LI);
   }

   status = sys$erase (&ProxyMaintEraseFab, &ProxyMaintScanEraseAst,
                                            &ProxyMaintScanEraseAst);
   if (Debug) fprintf (stdout, "sys$erase() %%X%08.08X\n", status);
}

/****************************************************************************/
/*
AST from sys$parse().  Check status and report any error. Initiate a search for
the next file.
*/

ProxyMaintScanEraseAst (struct FAB *FabPtr)

{
   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "ProxyMaintScanEraseAst() %%X%08.08X\n",
               FabPtr->fab$l_sts);

   if (VMSok (status = ProxyMaintEraseFab.fab$l_sts))
   {
      ProxyMaintDeletedCount++;
      ProxyMaintDeletedAllocBlocks += ProxyMaintFileAllocBlocks;
      ProxyMaintDeletedUsedBlocks += ProxyMaintFileUsedBlocks;
   }
   else
   {
      WriteFaoStdout (
         "%!AZ-W-PROXYMAINT, file erase error (!AZ !UL)\n-!%M\n \\!AZ\\\n",
         Utility, FI_LI, status, ProxyMaintEraseFileName);
   }

   /* search next */
   ProxyMaintScanSearch ();
}

/*****************************************************************************/
/*
Return a report and control menu related proxy serving.
*/ 

ProxyMaintReport
(
struct RequestStruct *rqptr,
void *NextTaskFunction,
boolean IncludeHostCache
)
{
   static char  ResponseFao [] =
"<HTML>\n\
<HEAD>\n\
!AZ\
<TITLE>HTTPd !AZ ... Proxy Report/Maintenance</TITLE>\n\
</HEAD>\n\
!AZ\n\
<H2><NOBR>HTTPd !AZ</NOBR></H2>\n\
<H3>Proxy Report/Maintenance</H3>\n\
!20%W\n";

   static char  CacheFao [] =
"<FORM METHOD=POST ACTION=\"!AZ\">\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Cache!AZ</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right VALIGN=top>Device:</TH><TD>!AZ!%%\n\
<BR>!UL &nbsp;blocks&nbsp; (!ULMB)\n\
<BR>!UL &nbsp;used&nbsp; (!ULMB !UL%)\n\
<BR>!UL &nbsp;free&nbsp; (!ULMB !UL%)\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Free Space:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right>In-Progress:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right VALIGN=top>Statistics Scan:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right VALIGN=top>Reactive Purge:</TH><TD>!AZ</TD></TR>\n\
<TR><TH ALIGN=right VALIGN=top>Routine Purge:</TH>\
<TD>!AZ<BR>Next: !AZ</TD></TR>\n\
<TR><TD COLSPAN=2><NOBR><BR>\n\
&nbsp;<INPUT TYPE=submit NAME=statistics VALUE=\" Statistics Scan \">\n\
&nbsp;<INPUT TYPE=submit NAME=reactive VALUE=\" Reactive Purge \">\n\
&nbsp;<INPUT TYPE=submit NAME=routine VALUE=\" Routine Purge \">\n\
</NOBR></TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
</FORM>\n\
!%%";

   static char  HostCacheButtonFao [] =
"<P><FONT SIZE=+1>[<A HREF=\"!AZ\">Host-Name-Cache</A>]</FONT>\n\
</BODY>\n\
</HTML>\n";

   static char  HostCacheFao [] =
"<FORM METHOD=POST ACTION=\"!AZ\">\n\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Host Name Cache</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=0>\n\
<TR><TH></TH>\
<TH ALIGN=left><U>Name</U></TH>\
<TH ALIGN=left><U>Address</U></TH>\
<TH ALIGN=right><U>Hit</U></TH></TR>\n";

   static char  EndHostCacheFao [] =
"<TR><TD COLSPAN=4><BR>\n\
&nbsp;<INPUT TYPE=submit NAME=hostname VALUE=\" Purge \">\n\
</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
</FORM>\n\
</BODY>\n\
</HTML>\n";

   register unsigned long  *vecptr;

   int  status,
        FreeBlocks,
        FreeMBytes,
        FreePercent,
        TotalMBytes,
        TotalBlocks,
        UsedBlocks,
        UsedMBytes,
        UsedPercent;
   unsigned short  Length;
   unsigned long  FaoVector [64];
   char  *DevNamePtr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyMaintReport()\n");

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_ADMIN;
   HTTP_HEADER_200_HTML (rqptr);

   vecptr = FaoVector;

   *vecptr++ = HtmlMetaInfo (rqptr, NULL);
   *vecptr++ = ServerHostPort;
   *vecptr++ = Config.cfServer.AdminBodyTag;
   *vecptr++ = ServerHostPort;
   *vecptr++ = &rqptr->rqTime.Vms64bit;

   status = NetWriteFaol (rqptr, ResponseFao, &FaoVector);
   if (VMSnok (status))
   {
      rqptr->rqResponse.ErrorTextPtr = "NetWriteFaol()";
      ErrorVmsStatus (rqptr, status, FI_LI);
      SysDclAst (NextTaskFunction, rqptr);
      return;
   }

   status = ProxyMaintStatisticsReport (rqptr);
   if (VMSnok (status))
   {
      rqptr->rqResponse.ErrorTextPtr = "ProxyMaintStatisticsReport()";
      ErrorVmsStatus (rqptr, status, FI_LI);
      SysDclAst (NextTaskFunction, rqptr);
      return;
   }

   status = ProxyMaintDeviceStats (&DevNamePtr, &TotalBlocks,
                                   &UsedBlocks, &FreeBlocks);
   if (VMSok (status))
   {
      TotalMBytes = PROXY_MAINT_DEVICE_MBYTES(TotalBlocks);
      UsedMBytes = PROXY_MAINT_DEVICE_MBYTES(UsedBlocks);
      FreeMBytes = PROXY_MAINT_DEVICE_MBYTES(FreeBlocks);
      UsedPercent = PROXY_MAINT_DEVICE_PERCENT_USED(TotalBlocks,FreeBlocks);
      FreePercent = PROXY_MAINT_DEVICE_PERCENT_FREE(TotalBlocks,FreeBlocks);
   }
   else
      TotalBlocks = TotalMBytes = UsedBlocks = UsedMBytes =
         UsedPercent = FreeBlocks = FreeMBytes = FreePercent = 0;

   vecptr = FaoVector;

   *vecptr++ = ADMIN_CONTROL_PROXY;

   if (ProxyCacheEnabled)
      *vecptr++ = "";
   else
      *vecptr++ = "<FONT COLOR=\"#ff0000\"> ... DISABLED</FONT>";

   *vecptr++ = DevNamePtr;
   if (VMSok (status))
      *vecptr++ = "";
   else
   {
      *vecptr++ = " %!%M";
      *vecptr++ = status;
   }
   *vecptr++ = TotalBlocks;
   *vecptr++ = TotalMBytes;
   *vecptr++ = UsedBlocks;
   *vecptr++ = UsedMBytes;
   *vecptr++ = UsedPercent;
   *vecptr++ = FreeBlocks;
   *vecptr++ = FreeMBytes;
   *vecptr++ = FreePercent;

   if (ProxyCacheEnabled)
   {
      if (ProxyCacheFreeSpaceAvailable)
         *vecptr++ = "AVAILABLE";
      else
         *vecptr++ = "<FONT COLOR=\"ff0000\"><B>NOT AVAILABLE</B></FONT>";
   }
   else
      *vecptr++ = "<I>n/a</I>";

   switch (ProxyMaintScanType)
   {
      case PROXY_MAINT_SCAN_STATISTICS :
         *vecptr++ = "<FONT COLOR=\"ff0000\"><B>STATISTICS SCAN</B></FONT>";
         break;
      case PROXY_MAINT_SCAN_REACTIVE :
         *vecptr++ = "<FONT COLOR=\"ff0000\"><B>REACTIVE PURGE</B></FONT>";
         break;
      case PROXY_MAINT_SCAN_ROUTINE :
         *vecptr++ = "<FONT COLOR=\"ff0000\"><B>ROUTINE PURGE</B></FONT>";
         break;
      default :
         if (ProxyCacheEnabled)
            *vecptr++ = "<I>none</I>";
         else
            *vecptr++ = "<I>n/a</I>";
   }

   *vecptr++ = ProxyMaintStatusStringStatScan;
   *vecptr++ = ProxyMaintStatusStringReactive;
   *vecptr++ = ProxyMaintStatusStringRoutine;
   *vecptr++ = ProxyMaintStatusStringRoutNext;

   if (IncludeHostCache)
   {
      *vecptr++ = HostCacheFao;
      *vecptr++ = ADMIN_CONTROL_PROXY;
      status = NetWriteFaol (rqptr, CacheFao, &FaoVector);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
      ProxyResolveHostCache (rqptr, NULL, 0);
      status = NetWriteFaol (rqptr, EndHostCacheFao, NULL);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
   }
   else
   {
      *vecptr++ = HostCacheButtonFao;
      *vecptr++ = ADMIN_REPORT_PROXY_HOSTCACHE;
      status = NetWriteFaol (rqptr, CacheFao, &FaoVector);
      if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);
   }

   SysDclAst (NextTaskFunction, rqptr);
}

/*****************************************************************************/
/*
Return a report and control menu related proxy serving.
*/ 

ProxyMaintAdjust
(
struct RequestStruct *rqptr,
void *NextTaskFunction
)
{
   static char  ResponseFao [] =
"<HTML>\n\
<HEAD>\n\
!AZ\
<TITLE>HTTPd !AZ ... Proxy Report/Maintenance</TITLE>\n\
</HEAD>\n\
!AZ\n\
<H2><NOBR>HTTPd !AZ</NOBR></H2>\n\
<H3>Proxy Report/Maintenance</H3>\n\
!20%W\n\
\
<FORM METHOD=POST ACTION=\"!AZ\">\n\
\
<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Adjust Executing Server</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=0>\n\
<TR><TH ALIGN=right>Serving:</TH><TD>\n\
<INPUT TYPE=radio NAME=ProxyServingEnabled VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=ProxyServingEnabled VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Cache:</TH><TD>\n\
<INPUT TYPE=radio NAME=ProxyCacheEnabled VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=ProxyCacheEnabled VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Add &quot;Forwarded: by&quot;:</TH><TD>\n\
<INPUT TYPE=radio NAME=ProxyAddForwardedByEnabled VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=ProxyAddForwardedByEnabled VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Report To Log:</TH><TD>\n\
<INPUT TYPE=radio NAME=ProxyReportLog VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=ProxyReportLog VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Report Cache To Log:</TH><TD>\n\
<INPUT TYPE=radio NAME=ProxyReportCacheLog VALUE=enabled!AZ>enabled\n\
<INPUT TYPE=radio NAME=ProxyReportCacheLog VALUE=disabled!AZ>disabled\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Host Name Lookup Retry:</TH><TD>\n\
<INPUT TYPE=text SIZE=3 NAME=ProxyHostLookupRetryCount VALUE=!UL>\n\
<FONT SIZE=-1>count</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Host Name Cache Purge:</TH><TD>\n\
<INPUT TYPE=text SIZE=3 NAME=ProxyHostCachePurgeHours VALUE=!UL>\n\
<FONT SIZE=-1>hours</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Maximum Load Size:</TH><TD>\n\
<INPUT TYPE=text SIZE=4 NAME=ProxyCacheFileKBytesMax VALUE=!UL>\n\
<FONT SIZE=-1>kBytes</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Reload List:</TH><TD>\n\
<INPUT TYPE=text SIZE=30 NAME=ProxyCacheReloadList VALUE=\"!AZ\">\n\
<FONT SIZE=-1>hours</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Routine Purge:</TH><TD>\n\
<INPUT TYPE=text SIZE=3 NAME=ProxyCacheRoutineHourOfDay VALUE=!UL>\n\
<FONT SIZE=-1>hour-of-day (00-23)</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Purge List:</TH><TD>\n\
<INPUT TYPE=text SIZE=30 NAME=ProxyCachePurgeList VALUE=\"!AZ\">\n\
<FONT SIZE=-1>hours</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Device Usage Check:</TH><TD>\n\
<INPUT TYPE=text SIZE=3 NAME=ProxyCacheDeviceCheckMinutes VALUE=!UL>\n\
<FONT SIZE=-1>minutes</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Device Usage Max:</TH><TD>\n\
<INPUT TYPE=text SIZE=3 NAME=ProxyCacheDeviceMaxPercent VALUE=!UL>\n\
<FONT SIZE=-1>percent</FONT></TD></TR>\n\
<TR><TH ALIGN=right>Device Reduce By:</TH><TD>\n\
<INPUT TYPE=text SIZE=3 NAME=ProxyCacheDevicePurgePercent VALUE=!UL>\n\
<FONT SIZE=-1>percent</FONT></TD></TR>\n\
<TR><TD COLSPAN=3><BR>\n\
<INPUT TYPE=submit NAME=makechanges VALUE=\" Make Changes \">\n\
<INPUT TYPE=reset VALUE=\" Reset \">\n\
</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
\
</FORM>\n\
\
</BODY>\n\
</HTML>\n";

#define REPBOOL(b)\
if (b)\
{\
   *vecptr++ = RadioButtonChecked;\
   *vecptr++ = RadioButtonUnchecked;\
}\
else\
{\
   *vecptr++ = RadioButtonUnchecked;\
   *vecptr++ = RadioButtonChecked;\
}

   static char  RadioButtonChecked [] = " CHECKED",
                RadioButtonUnchecked [] = "";

   register unsigned long  *vecptr;

   int  status;
   unsigned long  FaoVector [64];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyMaintAdjustMenu()\n");

   rqptr->rqResponse.PreExpired = PRE_EXPIRE_ADMIN;
   HTTP_HEADER_200_HTML (rqptr);

   vecptr = FaoVector;

   *vecptr++ = HtmlMetaInfo (rqptr, NULL);
   *vecptr++ = ServerHostPort;
   *vecptr++ = Config.cfServer.AdminBodyTag;
   *vecptr++ = ServerHostPort;
   *vecptr++ = &rqptr->rqTime.Vms64bit;

   *vecptr++ = ADMIN_CONTROL_PROXY;

   REPBOOL (ProxyServingEnabled)
   REPBOOL (ProxyCacheEnabled)
   REPBOOL (ProxyAddForwardedByEnabled)
   REPBOOL (ProxyReportLog)
   REPBOOL (ProxyReportCacheLog)
   *vecptr++ = ProxyHostLookupRetryCount;
   *vecptr++ = ProxyHostCachePurgeHours;
   *vecptr++ = ProxyCacheFileKBytesMax;
   *vecptr++ = ProxyCacheReloadListPtr;
   *vecptr++ = ProxyCacheRoutineHourOfDay;
   *vecptr++ = ProxyCachePurgeListPtr;
   *vecptr++ = ProxyCacheDeviceCheckMinutes;
   *vecptr++ = ProxyCacheDeviceMaxPercent;
   *vecptr++ = ProxyCacheDevicePurgePercent;

   status = NetWriteFaol (rqptr, ResponseFao, &FaoVector);
   if (VMSnok (status)) ErrorNoticed (status, "NetWriteFaol()", FI_LI);

   SysDclAst (NextTaskFunction, rqptr);
}

/*****************************************************************************/
/*
Return a report and control menu related proxy serving.
*/ 

ProxyMaintStatisticsReport (struct RequestStruct *rqptr)

{
   static char  ResponseFao [] =
"<P><TABLE CELLPADDING=3 CELLSPACING=0 BORDER=1>\n\
<TR><TH>Proxy Serving!AZ</TH></TR>\n\
<TR><TD>\n\
<TABLE CELLPADDING=0 CELLSPACING=0 BORDER=0>\n\
<TR><TD VALIGN=top>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right><U>Method</U></TH>\
<TR><TH ALIGN=right>GET:</TH><TD ALIGN=right>!UL</TD></TR>\n\
<TR><TH ALIGN=right>HEAD:</TH><TD ALIGN=right>!UL</TD></TR>\n\
<TR><TH ALIGN=right>POST:</TH><TD ALIGN=right>!UL</TD></TR>\n\
<TR><TH ALIGN=right>PUT:</TH><TD ALIGN=right>!UL</TD></TR>\n\
<TR><TH ALIGN=right>CONNECT:</TH><TD ALIGN=right>!UL</TD></TR>\n\
<TR><TH ALIGN=right>Total:</TH><TD ALIGN=right>!UL</TD></TR>\n\
</TABLE>\n\
</TD><TD VALIGN=top>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right><U>Traffic</U></TH></TR>\n\
<TR><TH ALIGN=right>&nbsp;Network&nbsp;Rx:</TH><TD ALIGN=right>!,@SQ</TD></TR>\n\
<TR><TH ALIGN=right>Tx:</TH><TD ALIGN=right>!,@SQ</TD></TR>\n\
<TR><TH ALIGN=right></TH><TD ALIGN=right>!UL%</TD></TR>\n\
<TR><TH ALIGN=right>Cache&nbsp;Rx:</TH><TD ALIGN=right>!,@SQ</TD></TR>\n\
<TR><TH ALIGN=right>Tx:</TH><TD ALIGN=right>!,@SQ</TD></TR>\n\
<TR><TH ALIGN=right></TH><TD ALIGN=right>!UL%</TD></TR>\n\
<TR><TH ALIGN=right>Total:</TH><TD ALIGN=right>!,@SQ</TD></TR>\n\
</TABLE>\n\
</TD><TD VALIGN=top>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right><U>Request&nbsp;Cache</U></TH>\
<TR><TH ALIGN=right>Read:</TH><TD ALIGN=right>!UL/!UL</TD><TD>(!UL%)</TD></TR>\n\
<TR><TH ALIGN=right>Write:</TH><TD ALIGN=right>!UL</TD><TD>(!UL%)</TD></TR>\n\
<TR><TD>&nbsp;</TD></TR>\n\
<TR><TH ALIGN=right>&nbsp;<U>Not&nbsp;Cacheable</U></TH>\
<TR><TH ALIGN=right>Request:</TH><TD ALIGN=right>!UL</TD><TD>(!UL%)</TD></TR>\n\
<TR><TH ALIGN=right>Response:</TH><TD ALIGN=right>!UL</TD><TD>(!UL%)</TD></TR>\n\
<TR><TH ALIGN=right>Rx/Tx:</TH><TD ALIGN=right>!UL%</TD></TR>\n\
</TABLE>\n\
</TD><TD VALIGN=top>\n\
<TABLE CELLPADDING=0 CELLSPACING=5 BORDER=0>\n\
<TR><TH ALIGN=right><U>Network</U></TH></TR>\n\
<TR><TH ALIGN=right>Requested:</TH><TD ALIGN=right>!UL</TD><TD>(!UL%)</TD></TR>\n\
<TR><TD>&nbsp;</TD></TR>\n\
<TR><TH ALIGN=right>&nbsp;<U>Host&nbsp;Lookup</U></TH>\
<TR><TH ALIGN=right>Numeric:</TH><TD ALIGN=right>!UL</TD></TR>\n\
<TR><TH ALIGN=right>DNS:</TH><TD ALIGN=right>!UL</TD></TR>\n\
<TR><TH ALIGN=right>Cache:</TH><TD ALIGN=right>!UL</TD></TR>\n\
<TR><TH ALIGN=right>Error:</TH><TD ALIGN=right>!UL</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n\
</TD></TR>\n\
</TABLE>\n";

   static long  Addx2 = 2;

   register unsigned long  *vecptr;

   int  status,
        PercentBytesCache,
        PercentBytesNetwork,
        PercentBytesNotCacheable,
        PercentCountCacheRead,
        PercentCountCacheWrite,
        PercentCountRequestNotCacheable,
        PercentCountResponseNotCacheable,
        PercentCountNetwork;
   unsigned short  Length;
   unsigned long  FaoVector [64],
                  QuadBytesCache [2],
                  QuadBytesNotCacheable [2],
                  QuadBytesRaw [2],
                  QuadBytesTotal [2];
   float  FloatBytesCache,
          FloatBytesNotCacheable,
          FloatBytesNetwork,
          FloatBytesTotal,
          FloatCountCacheRead,
          FloatCountCacheWrite,
          FloatCountRequestNotCacheable,
          FloatCountResponseNotCacheable,
          FloatCountNetwork,
          FloatCountTotal,
          FloatNetworkCount,
          FloatPercent;
   char  Buffer [4096];
   $DESCRIPTOR (BufferDsc, Buffer);

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyMaintStatisticsReport()\n");

   /*********/
   /* bytes */
   /*********/

   status = lib$addx (&ProxyAccounting.QuadBytesCacheRx,
                      &ProxyAccounting.QuadBytesCacheTx,
                      &QuadBytesCache, &Addx2);
   if (Debug) fprintf (stdout, "lib$addx() %%X%08.08X\n", status);

   status = lib$addx (&ProxyAccounting.QuadBytesNotCacheableRx,
                      &ProxyAccounting.QuadBytesNotCacheableTx,
                      &QuadBytesNotCacheable, &Addx2);
   if (Debug) fprintf (stdout, "lib$addx() %%X%08.08X\n", status);

   status = lib$addx (&ProxyAccounting.QuadBytesRawRx,
                      &ProxyAccounting.QuadBytesRawTx,
                      &QuadBytesRaw, &Addx2);
   if (Debug) fprintf (stdout, "lib$addx() %%X%08.08X\n", status);

   status = lib$addx (&QuadBytesCache,
                      &QuadBytesRaw,
                      &QuadBytesTotal, &Addx2);
   if (Debug) fprintf (stdout, "lib$addx() %%X%08.08X\n", status);

   FloatBytesCache = (float)QuadBytesCache[0] +
                     (float)QuadBytesCache[1] * (float)0xffffffff;
   if (Debug) fprintf (stdout, "FloatBytesCache: %f\n", FloatBytesCache);

   /********************/
   /* bytes percentage */
   /********************/

   FloatBytesNotCacheable = (float)QuadBytesNotCacheable[0] +
                            (float)QuadBytesNotCacheable[1] * (float)0xffffffff;
   if (Debug)
      fprintf (stdout, "FloatBytesNotCacheable: %f\n", FloatBytesNotCacheable);

   FloatBytesNetwork = (float)QuadBytesRaw[0] +
                   (float)QuadBytesRaw[1] * (float)0xffffffff;
   if (Debug) fprintf (stdout, "FloatBytesNetwork: %f\n", FloatBytesNetwork);

   FloatBytesTotal = (float)QuadBytesTotal[0] +
                     (float)QuadBytesTotal[1] * (float)0xffffffff;
   if (Debug) fprintf (stdout, "FloatBytesTotal: %f\n", FloatBytesTotal);

   if (FloatBytesTotal > 0.0)
   {
      PercentBytesCache = (int)(FloatPercent =
                          FloatBytesCache * 100.0 / FloatBytesTotal);
      if (FloatPercent - (float)PercentBytesCache >= 0.5) PercentBytesCache++;

      PercentBytesNotCacheable =
         (int)(FloatPercent = FloatBytesNotCacheable * 100.0 / FloatBytesTotal);
      if (FloatPercent - (float)PercentBytesNotCacheable >= 0.5)
         PercentBytesNotCacheable++;

      PercentBytesNetwork =
         (int)(FloatPercent = FloatBytesNetwork * 100.0 / FloatBytesTotal);
      if (FloatPercent - (float)PercentBytesNetwork >= 0.5)
         PercentBytesNetwork++;
   }
   else
      PercentBytesCache = PercentBytesNotCacheable = PercentBytesNetwork = 0;

   /*********************/
   /* counts percentage */
   /*********************/

   FloatCountRequestNotCacheable = ProxyAccounting.RequestNotCacheableCount;
   FloatCountResponseNotCacheable = ProxyAccounting.ResponseNotCacheableCount;
   FloatCountNetwork = ProxyAccounting.NetworkCount;
   FloatCountCacheRead = ProxyAccounting.CacheReadCount;
   FloatCountCacheWrite = ProxyAccounting.CacheWriteCount;
   FloatCountTotal = FloatCountNetwork + FloatCountCacheRead;

   if (FloatCountTotal > 0.0)
   {
      PercentCountNetwork = 
         (int)(FloatPercent = FloatCountNetwork * 100.0 / FloatCountTotal);
      if (FloatPercent - (float)PercentCountNetwork >= 0.5)
         PercentCountNetwork++;

      PercentCountCacheRead = (int)(FloatPercent =
                          FloatCountCacheRead * 100.0 / FloatCountTotal);
      if (FloatPercent - (float)PercentCountCacheRead >= 0.5)
         PercentCountCacheRead++;

      PercentCountRequestNotCacheable =
         (int)(FloatPercent =
               FloatCountRequestNotCacheable * 100.0 / FloatCountTotal);
      if (FloatPercent - (float)PercentCountRequestNotCacheable >= 0.5)
         PercentCountRequestNotCacheable++;
   }
   else
      PercentCountCacheRead = PercentCountRequestNotCacheable =
         PercentCountNetwork = 0;

   if (FloatCountNetwork > 0.0)
   {
      PercentCountCacheWrite = 
         (int)(FloatPercent = FloatCountCacheWrite * 100.0 / FloatCountNetwork);
      if (FloatPercent - (float)PercentCountCacheWrite >= 0.5)
         PercentCountCacheWrite++;

      PercentCountResponseNotCacheable =
         (int)(FloatPercent =
               FloatCountResponseNotCacheable * 100.0 / FloatCountNetwork);
      if (FloatPercent - (float)PercentCountResponseNotCacheable >= 0.5)
         PercentCountResponseNotCacheable++;
   }
   else
      PercentCountCacheWrite = PercentCountResponseNotCacheable = 0;

   /***********/
   /* display */
   /***********/

   vecptr = FaoVector;

   if (ProxyServingEnabled)
      *vecptr++ = "";
   else
      *vecptr++ = "<FONT COLOR=\"#ff0000\"> ... DISABLED</FONT>";

   *vecptr++ = ProxyAccounting.MethodGetCount;
   *vecptr++ = ProxyAccounting.MethodHeadCount;
   *vecptr++ = ProxyAccounting.MethodPostCount;
   *vecptr++ = ProxyAccounting.MethodPutCount;
   *vecptr++ = ProxyAccounting.MethodConnectCount;
   *vecptr++ = ProxyAccounting.MethodGetCount +
               ProxyAccounting.MethodHeadCount +
               ProxyAccounting.MethodPostCount +
               ProxyAccounting.MethodPutCount +
               ProxyAccounting.MethodConnectCount;
   *vecptr++ = &ProxyAccounting.QuadBytesRawRx;
   *vecptr++ = &ProxyAccounting.QuadBytesRawTx;
   *vecptr++ = PercentBytesNetwork;
   *vecptr++ = &ProxyAccounting.QuadBytesCacheRx;
   *vecptr++ = &ProxyAccounting.QuadBytesCacheTx;
   *vecptr++ = PercentBytesCache;
   *vecptr++ = &QuadBytesRaw;
   *vecptr++ = ProxyAccounting.CacheReadCount;
   *vecptr++ = ProxyAccounting.CacheRead304Count;
   *vecptr++ = PercentCountCacheRead;
   *vecptr++ = ProxyAccounting.CacheWriteCount;
   *vecptr++ = PercentCountCacheWrite;
   *vecptr++ = ProxyAccounting.RequestNotCacheableCount;
   *vecptr++ = PercentCountRequestNotCacheable;
   *vecptr++ = ProxyAccounting.ResponseNotCacheableCount;
   *vecptr++ = PercentCountResponseNotCacheable;
   *vecptr++ = PercentBytesNotCacheable;
   *vecptr++ = ProxyAccounting.NetworkCount;
   *vecptr++ = PercentCountNetwork;
   *vecptr++ = ProxyAccounting.LookupNoneCount;
   *vecptr++ = ProxyAccounting.LookupDnsCount;
   *vecptr++ = ProxyAccounting.LookupCacheCount;
   *vecptr++ = ProxyAccounting.LookupErrorCount;

   status = NetWriteFaol (rqptr, ResponseFao, &FaoVector);
   if (Debug) fprintf (stdout, "NetWriteFaol() %%X%08.08X\n", status);

   return (status);
}

/*****************************************************************************/
/*
*/ 

ProxyMaintControl (struct RequestStruct *rqptr)

{
   boolean  MakeChanges;
   int  status;
   unsigned short  Length;
   char  *cptr, *qptr, *sptr, *zptr;
   char  FieldName [128],
         FieldValue [256],
         ProxyCachePurgeList [64],
         ProxyCacheReloadList [64];


   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyMaintControl()\n");

   MakeChanges = false;

   /**********************/
   /* parse content body */
   /**********************/

   qptr = rqptr->rqBody.BufferPtr;
   while (*qptr)
   {
      qptr = ParseQueryField (rqptr, qptr,
                              FieldName, sizeof(FieldName),
                              FieldValue, sizeof(FieldValue),
                              FI_LI);
      if (qptr == NULL)
      {
         /* error occured */
         ErrorGeneral (rqptr, "Query field problem.", FI_LI);
         return;
      }

      /************************/
      /* action button fields */
      /************************/

      if (strsame (FieldName, "hostname", -1))
      {
         ProxyResolveHostCache (NULL, NULL, 0);
         ReportSuccess (rqptr, "Server !AZ host name cache purged.",
                        ServerHostPort);
      }
      else
      if (strsame (FieldName, "statistics", -1))
      {
         if (ProxyCacheEnabled)
            cptr = ProxyMaintScanBegin (PROXY_MAINT_SCAN_STATISTICS);
         if (cptr == NULL)
            ReportSuccess (rqptr,
"Server !AZ beginning statistics scan \
(results may take some time to be delivered).",
               ServerHostPort);
         else
            ErrorGeneral (rqptr, cptr, FI_LI);
         return;
      }
      else
      if (strsame (FieldName, "routine", -1))
      {
         if (ProxyCacheEnabled)
            cptr = ProxyMaintScanBegin (PROXY_MAINT_SCAN_ROUTINE);
         if (cptr == NULL)
            ReportSuccess (rqptr, "Server !AZ begining routine purge.",
                           ServerHostPort);
         else
            ErrorGeneral (rqptr, cptr, FI_LI);
         return;
      }
      else
      if (strsame (FieldName, "reactive", -1))
      {
         if (ProxyCacheEnabled)
            cptr = ProxyMaintScanBegin (PROXY_MAINT_SCAN_REACTIVE);
         if (cptr == NULL)
            ReportSuccess (rqptr, "Server !AZ begining reactive purge.",
                           ServerHostPort);
         else
            ErrorGeneral (rqptr, cptr, FI_LI);
         return;
      }
      else
      if (strsame (FieldName, "makechanges", -1))
         MakeChanges = true;
      else

      /************************/
      /* "makechanges" fields */
      /************************/

      if (strsame (FieldName, "ProxyAddForwardedByEnabled", -1))
      {
          if (toupper(FieldValue[0]) == 'E')
            ProxyAddForwardedByEnabled = true;
         else
         if (toupper(FieldValue[0]) == 'D')
            ProxyAddForwardedByEnabled = false;
      }
      else
      if (strsame (FieldName, "ProxyServingEnabled", -1))
      {
          if (toupper(FieldValue[0]) == 'E')
            ProxyServingEnabled = ProxyAccounting.ServingEnabled = true;
         else
         if (toupper(FieldValue[0]) == 'D')
            ProxyServingEnabled = ProxyAccounting.ServingEnabled = false;
      }
      else
      if (strsame (FieldName, "ProxyCacheEnabled", -1))
      {
          if (toupper(FieldValue[0]) == 'E')
            ProxyCacheEnabled = ProxyAccounting.CacheEnabled = true;
         else
         if (toupper(FieldValue[0]) == 'D')
            ProxyCacheEnabled = ProxyAccounting.CacheEnabled = false;
      }
      else
      if (strsame (FieldName, "ProxyHostLookupRetryCount", -1))
      {
         ProxyHostLookupRetryCount = atoi(FieldValue);
         if (ProxyHostLookupRetryCount < 0 || ProxyHostLookupRetryCount > 100)
            ProxyHostLookupRetryCount = 0;
      }
      else
      if (strsame (FieldName, "ProxyHostCachePurgeHours", -1))
      {
         ProxyHostCachePurgeHours = atoi(FieldValue);
         if (ProxyHostCachePurgeHours < 1 || ProxyHostCachePurgeHours > 168)
            ProxyHostCachePurgeHours = PROXY_HOST_CACHE_PURGE_DEFAULT;
      }
      else
      if (strsame (FieldName, "ProxyCacheFileKBytesMax", -1))
         ProxyCacheFileKBytesMax = atoi(FieldValue);
      else
      if (strsame (FieldName, "ProxyCacheReloadList", -1))
      {
         zptr = (sptr = ProxyCacheReloadList) + sizeof(ProxyCacheReloadList);
         for (cptr = FieldValue; *cptr && sptr < zptr; *sptr++ = *cptr++);
         if (sptr >= zptr)
         {
            ErrorGeneralOverflow (rqptr, FI_LI);
            return;
         }
         *sptr = '\0';
         ProxyCacheReloadListPtr = ProxyCacheReloadList;
      }
      else
      if (strsame (FieldName, "ProxyCacheRoutineHourOfDay", -1))
         ProxyCacheRoutineHourOfDay = atoi(FieldValue);
      else
      if (strsame (FieldName, "ProxyCacheDeviceCheckMinutes", -1))
         ProxyCacheDeviceCheckMinutes = atoi(FieldValue);
      else
      if (strsame (FieldName, "ProxyCacheDeviceMaxPercent", -1))
         ProxyCacheDeviceMaxPercent = atoi(FieldValue);
      else
      if (strsame (FieldName, "ProxyCacheDevicePurgePercent", -1))
         ProxyCacheDevicePurgePercent = atoi(FieldValue);
      else
      if (strsame (FieldName, "ProxyCachePurgeList", -1))
      {
         zptr = (sptr = ProxyCachePurgeList) + sizeof(ProxyCachePurgeList);
         for (cptr = FieldValue; *cptr && sptr < zptr; *sptr++ = *cptr++);
         if (sptr >= zptr)
         {
            ErrorGeneralOverflow (rqptr, FI_LI);
            return;
         }
         *sptr = '\0';
         ProxyCachePurgeListPtr = ProxyCachePurgeList;
      }
      else
      if (strsame (FieldName, "ProxyReportLog", -1))
      {
          if (toupper(FieldValue[0]) == 'E')
            ProxyReportLog = true;
         else
         if (toupper(FieldValue[0]) == 'D')
            ProxyReportLog = false;
      }
      else
      if (strsame (FieldName, "ProxyReportCacheLog", -1))
      {
          if (toupper(FieldValue[0]) == 'E')
            ProxyReportCacheLog = true;
         else
         if (toupper(FieldValue[0]) == 'D')
            ProxyReportCacheLog = false;
      }
      else
      {
         /***********/
         /* unknown */
         /***********/

         ErrorGeneral (rqptr, "Unknown query field.", FI_LI);
         return;
      }
   }

   if (MakeChanges)
   {
      ProxyCacheInitValues ();
      ProxyMaintInit ();
      /* set logical names used by HTTPd monitor utility */
      if (MonitorEnabled) DefineMonitorLogicals (NULL);
      ReportSuccess (rqptr, "Server !AZ new proxy values loaded.",
                     ServerHostPort);
   }
}

/****************************************************************************/
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    