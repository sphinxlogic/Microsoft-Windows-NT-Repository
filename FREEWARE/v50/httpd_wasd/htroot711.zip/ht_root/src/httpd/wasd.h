/*****************************************************************************
/*
                                  WASD.h

Main header file for WASD VMS HTTP daemon.


VERSION HISTORY
---------------
06-MAY-2000  MGD  v7.0.0, reorganise data structures
23-DEC-1999  MGD  v6.1.2, DECC v6.2 warning control
31-OCT-1999  MGD  v6.1.0, CGIplus "agents"
16-OCT-1999  MGD  v6.0.3, DEC TCP/IP v5.n compatibility definitions
10-JAN-1999  MGD  v6.0.0, proxy serving
19-SEP-1998  MGD  v5.3.0, disperse to module headers :^)
14-APR-1998  MGD  v5.0.1, XSSI extensions
07-JAN-1998  MGD  v5.0.0, HTTPd version 5 (Secure Sockets Layer, using SSLeay)
05-OCT-1997  MGD  v4.5.0, file cache
06-SEP-1997  MGD  v4.4.0, multiple server host names and ports
08-JUN-1997  MGD  v4.2.0, CGIplus
01-FEB-1997  MGD  v4.0.0, HTTPd version 4
01-AUG-1996  MGD  v3.3.0, quite a few changes since 3.0.n
01-DEC-1995  MGD  v3.0.0, HTTPd version 3
20-DEC-1994  MGD  v2.0.0, multi-threaded version
20-JUN-1994  MGD  v1.0.0, single-threaded version
*/
/*****************************************************************************/

#ifndef WASD_H_LOADED
#define WASD_H_LOADED 1

#ifdef DBUG
#  ifdef __ALPHA
#     if (__DECC_VER > 60000000)
#        pragma message enable (ALL)
#        pragma message disable (CVTDIFTYPES,MAYLOSEDATA)
#        pragma message disable (PTRMISMATCH,PTRMISMATCH1)
#        pragma message disable (NORETURNVAL1,NOTYPES,NONEWTYPE)
#     else
#        pragma message disable (ALL)
#     endif
#  endif
#else
#  pragma message disable (ALL)
#endif

#include <descrip.h>
#include <rms.h>
#include <ssdef.h>
#include <stsdef.h>
#include <rmsdef.h>

/* Internet-related header files */
#include <socket.h>
#include <in.h>
#include <netdb.h>
#include <inet.h>

/* define required values from UCX$INETDEF.H (Multinet does not supply one) */
#define INET_PROTYP$C_STREAM 1
#define INETACP$C_TRANS 2
#define INETACP_FUNC$C_GETHOSTBYNAME 1
#define INETACP_FUNC$C_GETHOSTBYADDR 2
#define UCX$C_AF_INET 2
#define UCX$C_DSC_ALL 2
#define UCX$C_FULL_DUPLEX_CLOSE 8192
#define UCX$C_REUSEADDR 4
#define UCX$C_SHARE 4105
#define UCX$C_SOCK_NAME 4
#define UCX$C_SOCKOPT 1
#define UCX$C_TCP 6

/* Alpha NO MEMBER ALIGNMENT unless otherwise specified */
#ifdef __ALPHA
#   pragma nomember_alignment
#endif

#ifndef VERSION_H_LOADED
#   include "version.h"
#endif

/**********/
/* macros */
/**********/

#define boolean int
#define true 1
#define false 0

#define FI_LI WASD_MODULE, __LINE__

#define DEFAULT_SERVER_GROUP_RESNAME "WASD_MATTHEW_J_2000-06-17"

#define CONFIG_AUTH_FILE_NAME      "HTTPD$AUTH"
#define CONFIG_FILE_NAME           "HTTPD$CONFIG"
#define CONFIG_MAP_FILE_NAME       "HTTPD$MAP"
#define CONFIG_MSG_FILE_NAME       "HTTPD$MSG"
#define CONFIG_SERVICE_FILE_NAME   "HTTPD$SERVICE"
#define CONFIG_SITELOG_FILE_NAME   "HTTPD$SITELOG"
#define DEFAULT_SITELOG_FILE_NAME  "HT_ROOT:[LOCAL]SITE.LOG"

/* allows the HTTPd to be operated with SYSPRV permanently enabled */
#define OPERATE_WITH_SYSPRV 0

#define DEFAULT_HTTP_PORT          80
#define DEFAULT_HTTPS_PORT        443
#define DEFAULT_HTTP_PROXY_PORT  8080
#define DEFAULT_CONNECT_PORT     4443
#define DEFAULT_LISTEN_BACKLOG      5

/* this value must also include connections in a "keep-alive" state */
#define DEFAULT_CONCURRENT_CONNECT_MAX    50

#define DEFAULT_TIMEOUT_INPUT_MINUTES       1
#define DEFAULT_TIMEOUT_OUTPUT_MINUTES     10
#define DEFAULT_TIMEOUT_NOPROGRESS_MINUTES  3
#define DEFAULT_TIMEOUT_KEEPALIVE_SECONDS   0

/* helps ensure a client doesn't get into an infinite loop */
#define KEEPALIVE_MAX 100

#define DEFAULT_DCL_CGIPLUSIN_SIZE    3072
#define DEFAULT_DCL_SYSCOMMAND_SIZE   4096
#define DEFAULT_DCL_SYSOUTPUT_SIZE    4096
#define DEFAULT_FILE_BUFFER_SIZE      1024
#define DEFAULT_NET_READ_BUFFER_SIZE  2048
#define DEFAULT_OUTPUT_BUFFER_SIZE    4096
#define MAX_REQUEST_HEADER            8192

/* control pre-expired responses */
#define PRE_EXPIRE_ADMIN            1
#define PRE_EXPIRE_DELETE_ON_CLOSE  1
#define PRE_EXPIRE_INDEX_OF         0
#define PRE_EXPIRE_MAPPING_RULES    0
#define PRE_EXPIRE_MENU             1
#define PRE_EXPIRE_PUT              1
#define PRE_EXPIRE_SSI              0
#define PRE_EXPIRE_UPD              1
#define PRE_EXPIRE_UPD_TREE_OF      1
#define PRE_EXPIRE_WATCH            0

/* versions of the HTTP protocol */
#define HTTP_VERSION_NOT_SET   0
#define HTTP_VERSION_0_9       9
#define HTTP_VERSION_1_0      10
#define HTTP_VERSION_1_1      11
#define HTTP_VERSION_UNKNOWN  -1

/* constants used to identify HTTP methods */
#define HTTP_METHOD_DELETE   0x01
#define HTTP_METHOD_GET      0x02
#define HTTP_METHOD_HEAD     0x04
#define HTTP_METHOD_POST     0x08
#define HTTP_METHOD_PUT      0x10
#define HTTP_METHOD_CONNECT  0x20

/* constants for controlling logging */
#define LOGGING_BEGIN  1
#define LOGGING_END    2
#define LOGGING_OPEN   3
#define LOGGING_CLOSE  4
#define LOGGING_FLUSH  5
#define LOGGING_ENTRY  6

/* constants for OPCOM messages */
#define OPCOM_HTTPD          0x01
#define OPCOM_CONTROL        0x02
#define OPCOM_ADMIN          0x04
#define OPCOM_AUTHORIZATION  0x08
#define OPCOM_PROXY_MAINT    0x10

/* constants used by HTTPd supervisor timer */
#define TIMER_INPUT             1
#define TIMER_OUTPUT            2
#define TIMER_NOPROGRESS        3
#define TIMER_KEEPALIVE         4

/* constants used by the description module */
#define DESCRIPTION_ALL         0x01
#define DESCRIPTION_TEXT_PLAIN  0x02
#define DESCRIPTION_TEXT_HTML   0x04
/* this is returned in the first character the file type contains none */
#define DESCRIPTION_IMPOSSIBLE  0xff

/* default directory listing layout */
#define DEFAULT_DIR_LAYOUT "I__L__R__S:b__D"

/* "http:", "https:" or "connect:" service and request */
#define SCHEME_HTTP     1
#define SCHEME_HTTPS    2
#define SCHEME_CONNECT  3

/* header fields for HTTP/1.0 keep alive response */
#define DEFAULT_KEEPALIVE_HTTP_HEADER \
        "Connection: Keep-Alive\r\nKeep-Alive:\r\n"

/* if true, stops HTTPd server account with SYSPRV PUT(etc)ing - DANGEROUS */
#define PUT_DISALLOW_SYSPRV 0

#define CONFIG_HOME_PAGES_MAX      16
#define CONFIG_README_FILES_MAX    16
#define CONFIG_SCRIPT_RUNTIME_MAX  16
#define CONFIG_REVALIDATE_MINUTES_MAX  1440

#define CONFIG_SERVER_SIGNATURE_OFF    0
#define CONFIG_SERVER_SIGNATURE_ON     1
#define CONFIG_SERVER_SIGNATURE_EMAIL  2

#define SCRIPT_NAME_SIZE  128
#define METHOD_NAME_SIZE   16

#define CONFIG_DEFAULT_DIR_BODY_TAG "<BODY>"
#define CONFIG_DEFAULT_ADMIN_BODY_TAG \
        "<BODY LINK=\"#0000cc\" VLINK=\"#0000cc\">"
#define CONFIG_DEFAULT_REPORT_BODY_TAG \
        "<BODY LINK=\"#0000cc\" VLINK=\"#0000cc\">"

/* maximum Kbytes (1024) that can be in a body to be POSTed or PUTted */
#define PUT_DEFAULT_KBYTES_MAX 250
/* number of versions retained for files POSTed or PUTed */
#define PUT_DEFAULT_VERSION_LIMIT 3
/* W:RE,G:RE,O:RWED,S:RWED */
#define PUT_DEFAULT_FILE_PROTECTION 0xaa00

/* number of times a request can internally redirect */
#define REQUEST_REDIRECTION_MAX 5

/* number of pointers available for adding server-generated cookies */
#define RESPONSE_COOKIE_MAX 3

/* internal "scripts" */
#define ADMIN_SCRIPT_ECHO   "/echo"
#define ADMIN_SCRIPT_TREE   "/tree"
#define ADMIN_SCRIPT_UPD    "/upd"
#define ADMIN_SCRIPT_WHERE  "/where"
#define ADMIN_SCRIPT_XRAY   "/xray"

/*************/
/* durations */
/*************/

/* 1000 = 1mS, 100 = 100uS, 10 = 10Us, 1 = 1uS (for really fast systems :^) */
/** #define DURATION_UNITS_USECS 1000 **/

/* durations are to be in units of 0.1 milliseconds */
#define DURATION_UNITS_USECS 100

#if DURATION_UNITS_USECS == 1
#  define DURATION_SUBSEC_MAX 999999
#  define DURATION_DECIMAL_PLACES 6
#elif DURATION_UNITS_USECS == 10
#  define DURATION_SUBSEC_MAX 99999
#  define DURATION_DECIMAL_PLACES 5
#elif DURATION_UNITS_USECS == 100
#  define DURATION_SUBSEC_MAX 9999
#  define DURATION_DECIMAL_PLACES 4
#else
   /* defaults to milliseconds */
#  undef DURATION_UNITS_USECS
#  define DURATION_UNITS_USECS 1000
#  define DURATION_SUBSEC_MAX 999
#  define DURATION_DECIMAL_PLACES 3
#endif

#define USECS_IN_A_SECOND 1000000

/*********************/
/* functional macros */
/*********************/

#define VMSok(x) ((x) & STS$M_SUCCESS)
#define VMSnok(x) (!((x) & STS$M_SUCCESS))

/* is it linear-white-space? (avoids the call overhead of an isspace()) */
#define ISLWS(c) (c == ' ' || c == '\t')

/* end of CR or LF terminated line? */
#define EOL(c) (c == '\r' || c == '\n' || !*cptr)
#define NOTEOL(c) (c != '\r' && c != '\n' && *cptr)

/*************************************************/
/* macros for development timing in microseconds */
/*************************************************/

/* 0..9 timers available */

#define USEC_TIMER_STORAGE \
   unsigned long  uSecSubx2 = 2, \
                  uSecEdiv10 = 10; \
   unsigned long  uSecResult, \
                  uSecDuration, \
                  uSecRemainder; \
   unsigned long  uSecBeginQuad [10][2], \
                  uSecEndQuad [10][2];

#define USEC_TIMER_STORAGE_EXTERN \
   extern unsigned long  uSecSubx2, \
                         uSecEdiv10; \
   extern unsigned long  uSecResult, \
                         uSecDuration, \
                         uSecRemainder; \
   extern unsigned long  uSecBeginQuad [10][2], \
                         uSecEndQuad [10][2];

#define USEC_TIMER_BEGIN(IDX) \
{ \
   sys$gettim (&uSecBeginQuad[IDX]); \
}

#define USEC_TIMER_END(IDX,WHERE) \
{ \
   sys$gettim (&uSecEndQuad[IDX]); \
   lib$subx (&uSecEndQuad[IDX], &uSecBeginQuad[IDX], &uSecResult, &uSecSubx2); \
   lib$ediv (&uSecEdiv10, &uSecResult, &uSecDuration, &uSecRemainder); \
   fprintf (stdout, "%s uS: %d\n", WHERE, uSecDuration); \
}


/*******************/
/* data structures */
/*******************/

struct AnExitHandler
{
   unsigned long  Flink;
   unsigned long  HandlerAddress;
   unsigned long  ArgCount;
   unsigned long  ExitStatusPtr;
};

struct AnIOsb
{
   unsigned short  Status;
   unsigned short  Count;
   variant_union {
      unsigned long  Unused;
      unsigned long  MbxPid;
   } Overlay1;
};

struct MbxSenseIOsb
{
   unsigned short  Status;
   unsigned short  MessageCount;
   unsigned long  MessageBytes;
};

#undef lksb
typedef struct lksb
{
   unsigned short int lksb$w_status;
   unsigned short int lksb$w_reserved;
   unsigned int lksb$l_lkid;
   unsigned char lksb$b_valblk [16];
};

/*
   Store these structures naturally-aligned on AXP.
   Uses a bit more storage but makes access as efficient as possible.
*/

#ifdef __ALPHA
#   pragma member_alignment __save
#   pragma member_alignment
#endif

struct NetMaskStruct
{
   int  BitsNetwork;
   int  BitsMask;
};

/*
This structure is used to both store and to point at the various components
depending on the context.
*/

struct ContentInfoStruct
{
   struct ContentInfoStruct  *NextPtr,
                             *HashCollisionPtr;
   boolean  TypeUnknown;
   char  *SuffixPtr;
   char  *ContentTypePtr;
   char  *AutoScriptNamePtr;
   char  *DescriptionPtr;
   char  *IconPtr;
   /* string data is stored here */
};

/*
This structure is used to both store and to point at the various components
depending on the context.
*/

struct IconStruct
{
   struct IconStruct  *NextPtr,
                      *HashCollisionPtr;
   /* string data is stored here */
};

struct  ListEntryStruct
{
   struct ListEntryStruct  *PrevPtr;
   struct ListEntryStruct  *NextPtr;
};

struct  ListHeadStruct
{
   struct ListEntryStruct  *HeadPtr;
   struct ListEntryStruct  *TailPtr;
   int  EntryCount;
};

/* these macros operate on the list head */
#define LIST_HEAD(lp) ((char*)((struct ListHeadStruct*)lp)->HeadPtr)
#define LIST_TAIL(lp) ((char*)((struct ListHeadStruct*)lp)->TailPtr)
#define LIST_COUNT(lp) (((struct ListHeadStruct*)lp)->EntryCount)
#define LIST_EMPTY(lp) (!((struct ListHeadStruct*)lp)->EntryCount)

/* these macros operate on list entries */
#define LIST_DATA(lp) ((char*)((char*)lp+sizeof(struct ListEntryStruct)))
#define LIST_PREV(lp) (((struct ListEntryStruct*)lp)->PrevPtr)
#define LIST_NEXT(lp) (((struct ListEntryStruct*)lp)->NextPtr)
#define LIST_HAS_PREV(lp) ((((struct ListEntryStruct*)lp)->PrevPtr) != NULL)
#define LIST_HAS_NEXT(lp) ((((struct ListEntryStruct*)lp)->NextPtr) != NULL)

/*******************************************/
/* header files we need early in the piece */
/*******************************************/

#ifndef ENAMEL_H_LOADED
#   include "enamel.h"
#endif

#ifndef ODSSTRUCT_H_LOADED
#   include "odsstruct.h"
#endif

#ifndef PROXYSTRUCT_H_LOADED
#   include "proxystruct.h"
#endif

/**********************************/
/* request history data structure */
/**********************************/

/* 256 bytes (a somewhat arbitrary quantity) */
struct  RequestHistoryStruct
{
   struct  ListEntryStruct  HistoryListEntry;
   struct  ServiceStruct  *ServicePtr;
   unsigned long  BinaryTime [2];
   unsigned long  BytesRawRx,
                  BytesRawTx,
                  ConnectNumber,
                  ResponseDuration;
   int  ResponseStatusCode;
   char  *RequestPtr;
   boolean  Truncated;
   char  ClientAndRequest [256-12-8-4-4-4-4-4-4-4];
};

/*************************/
/* per-server accounting */
/*************************/

/* as of v4.4 this structure is now > 255 bytes requiring two logicals */

struct AccountingStruct
{
   /* this is used to check for changes in HTTPd version requiring zeroing */
   unsigned long  AccountingVersion;
   /* this MUST be the first member (or so) to allow zeroing of the rest */
   unsigned long  ZeroedCount;

   unsigned long  AuthBasicCount,
                  AuthAgentCount,
                  AuthAuthorizedCount,
                  AuthDigestCount,
                  AuthHtDatabaseCount,
                  AuthSimpleListCount,
                  AuthNotAuthenticatedCount,
                  AuthNotAuthorizedCount,
                  AuthVmsCount,
                  CacheHitCount,
                  CacheHitNotModifiedCount,
                  CacheLoadCount,
                  ConnectAcceptedCount,
                  ConnectCount,
                  ConnectSslCount,
                  ConnectCurrent,
                  ConnectPeak,
                  ConnectRejectedCount,
                  ConnectTooBusyCount,
                  DclCgiPlusReusedCount,
                  DclCrePrcCount,
                  DclCrePrcDetachCount,
                  DclCrePrcPersonaCount,
                  DclCrePrcSubprocessCount,
                  DclRteReusedCount,
                  DoAutoScriptCount,
                  DoCgiPlusScriptCount,
                  DoDclCommandCount,
                  DoDECnetCount,
                  DoDECnetReuseCount,
                  DoDECnetCgiCount,
                  DoDECnetCgiReuseCount,
                  DoDECnetOsuCount,
                  DoDECnetOsuReuseCount,
                  DoDirectoryCount,
                  DoIsMapCount,
                  DoRteScriptCount,
                  DoScriptCount,
                  DoFileCount,
                  DoFileNotModifiedCount,
                  DoMenuCount,
                  DoPutCount,
                  DoServerAdminCount,
                  DoSsiCount,
                  DoUpdateCount,
                  LastExitStatus,
                  MethodDeleteCount,
                  MethodGetCount,
                  MethodHeadCount,
                  MethodPostCount,
                  MethodPutCount,
                  MethodTraceCount,
                  RedirectLocalCount,
                  RedirectRemoteCount,
                  RequestTotalCount,
                  RequestErrorCount,
                  RequestForbiddenCount,
                  RequestKeepAliveCount,
                  RequestKeepAliveMax,
                  RequestParseCount,
                  RequestPragmaNoCacheCount,
                  RequestProxyCount,
                  ResponseDurationCount,
                  ResponseDurationMax,
                  ResponseDurationMin,
                  StartupCount,
                  StreamLfConversionCount;

   unsigned long  QuadBytesRawRx [2],
                  QuadBytesRawTx [2],
                  QuadResponseDuration [2];

   unsigned long  ResponseStatusCodeCountArray [6];
};

#ifdef __ALPHA
#   pragma member_alignment __restore
#endif

/************************/
/* module include files */
/************************/

#ifndef ADMIN_H_LOADED
#   include "admin.h"
#endif
#ifndef AUTH_H_LOADED
#   include "auth.h"
#endif
#ifndef BASIC_H_LOADED
#   include "basic.h"
#endif
#ifndef CACHE_H_LOADED
#   include "cache.h"
#endif
#ifndef CGI_H_LOADED
#   include "cgi.h"
#endif
#ifndef CONFIG_H_LOADED
#   include "config.h"
#endif
#ifndef CONTROL_H_LOADED
#   include "control.h"
#endif
#ifndef DESCR_H_LOADED
#   include "descr.h"
#endif
#ifndef DCL_H_LOADED
#   include "dcl.h"
#endif
#ifndef DIR_H_LOADED
#   include "dir.h"
#endif
#ifndef DECNET_H_LOADED
#   include "decnet.h"
#endif
#ifndef ERROR_H_LOADED
#   include "error.h"
#endif
#ifndef FILE_H_LOADED
#   include "file.h"
#endif
#ifndef GRAPH_H_LOADED
#   include "graph.h"
#endif
#ifndef HTADMIN_H_LOADED
#   include "htadmin.h"
#endif
#ifndef HTTPD_H_LOADED
#   include "httpd.h"
#endif
#ifndef ISMAP_H_LOADED
#   include "ismap.h"
#endif
#ifndef MAPURL_H_LOADED
#   include "mapurl.h"
#endif
#ifndef MENU_H_LOADED
#   include "menu.h"
#endif
#ifndef MSG_H_LOADED
#   include "msg.h"
#endif
#ifndef NET_H_LOADED
#   include "net.h"
#endif
#ifndef ODS_H_LOADED
#   include "ods.h"
#endif
#ifndef PERSONA_H_LOADED
#   include "persona.h"
#endif
#ifndef PROXY_H_LOADED
#   include "proxy.h"
#endif
#ifndef PROXYCACHE_H_LOADED
#   include "proxycache.h"
#endif
#ifndef PROXYMAINT_H_LOADED
#   include "proxymaint.h"
#endif
#ifndef PUT_H_LOADED
#   include "put.h"
#endif
#ifndef REQUEST_H_LOADED
#   include "request.h"
#endif
#ifndef SSI_H_LOADED
#   include "ssi.h"
#endif
#ifndef SERVICE_H_LOADED
#   include "service.h"
#endif
#ifndef SESOLA_H_LOADED
#   include "sesola.h"
#endif
#ifndef STMLF_H_LOADED
#   include "stmlf.h"
#endif
#ifndef SUPPORT_H_LOADED
#   include "support.h"
#endif
#ifndef TRACK_H_LOADED
#   include "track.h"
#endif
#ifndef UPD_H_LOADED
#   include "upd.h"
#endif
#ifndef VM_H_LOADED
#   include "vm.h"
#endif
#ifndef WATCH_H_LOADED
#   include "watch.h"
#endif

/*
   Store the following structures naturally-aligned on AXP.
   Uses a bit more storage but makes access as efficient as possible.
*/

#ifdef __ALPHA
#   pragma member_alignment __save
#   pragma member_alignment
#endif

/****************************************/
/* request authentication/authorization */
/****************************************/

struct RequestAuthorizationStruct
{
   boolean  /* a case-less username and password was performed */
            CaseLess,
            /* authenticated user may only access via https: (SSL) */
            HttpsOnly,
            /* do not cache authentication information, revalidate each time */
            NoCache,
            /* the authentication realm name is a synonym for the SYSUAF */
            RealmIsVmsSynonym,
            /* the user was authenticated from the SYSUAF */
            SysUafAuthenticated,
            /* user may change SYSUAF password */
            SysUafCanChangePwd,
            /* user can authenticate even if hours seem to prohibit */
            SysUafNilAccess;

   int  /* only when script is authentication agent */
        AgentParameterLength,
        /* VMS status result of authentication/authorization */
        FinalStatus,
        /* length of string */
        GroupReadLength,
        /* length of string */
        GroupWriteLength,
        /* length of path being authorized :^) */
        PathBeingAuthorizedLength,
        /* length of string */
        RealmLength,
        /* authenticated user details length */
        UserDetailsLength,
        /* number of identifiers loaded into array */
        VmsIdentifiersCount;

   unsigned short  /* length of the user profile pointed to */
                   VmsUserProfileLength;

   unsigned long  /* value representation of scheme being used for challenge */
                  ChallengeScheme,
                  /* the capability flags of the authorization path */
                  GroupCan,
                  /* VMS identifier value controlling read access */
                  GroupReadVmsIdentifier,
                  /* VMS identifier value controlling write access */
                  GroupWriteVmsIdentifier,
                  /* VMS identifier value controlling authentication */
                  RealmVmsIdentifier,
                  /* the capability flags of the request (ACT ON THESE!) */
                  RequestCan,
                  /* value representation of scheme being used for request */
                  Scheme,
                  /* source of read-only group information */
                  SourceGroupRead,
                  /* source of full-access group information */
                  SourceGroupWrite,
                  /* source of realm information */
                  SourceRealm,
                  /* the capability flags of the remote user */
                  UserCan,
                  /* what everybody else can do on that path */
                  WorldCan;

   unsigned long  /* pointer to array of VMS identifiers (zero-terminated) */
                  *VmsIdentifiersPtr;

   char  /* only when script is authentication agent */
         *AgentParameterPtr,
         /* BASIC challenge response header field */
         *BasicChallengePtr,
         /* DIGEST challenge response header field */
         *DigestChallengePtr,
         /* when digest authenticating, the client-supplied nonce */
         *DigestNoncePtr,
         /* when digest authenticating, the client-supplied digest */
         *DigestResponsePtr,
         /* when digest authenticating, the client-supplied URI */
         *DigestUriPtr,
         /* pointer to authorization group name */
         *GroupReadPtr,
         /* pointer to string of IP-address/username masks */
         *GroupRestrictListPtr,
         /* pointer to authorization group name */
         *GroupWritePtr,
         /* pointer to the path being authorized :^) */
         *PathBeingAuthorizedPtr,
         /* pointer to authorization realm name */
         *RealmPtr,
         /* pointer to authorization realm synonym string */
         *RealmDescrPtr,
         /* points to either "Authorization:" or "Proxy-Authorization:" field */
         *RequestAuthorizationPtr,
         /* authenticated user details */
         *UserDetailsPtr,
         /* user profile is used by sys$check_access() */
         *VmsUserProfilePtr,
         /* pointer to string of IP-address/username masks */
         *WorldRestrictListPtr;

   char  /* basic, digest, etc. */
         Type [16];

   /* a pointer to the actual record in the cache itself */
   struct AuthCacheRecordStruct  *CacheRecordPtr;
   /* a pointer to a template used when searching the cache */
   struct AuthCacheRecordStruct  *CacheSearchRecordPtr;

   /* AST function pointers */
   void (*AstFunctionBuffer)(struct RequestStruct*);
   void (*AstFunction)(struct RequestStruct*);
   void (*AgentCalloutFunction)(struct RequestStruct*);
};

/**************************/
/* request content (body) */
/**************************/

struct  RequestBodyStruct
{
   int  /* count of bytes received so far in a POSTed or PUTed body */
        CurrentCount;

   char  /* points to dynamic buffer for body POSTed, PUT, etc. */
         *BufferPtr,
         /* used as pointer into above buffer */
         *CurrentPtr;
};

/*************************/
/* request cache storage */
/*************************/

struct  RequestCacheStruct
{
   boolean  /* cache is currently being loaded for this path/file */
            Loading;

   int  /* could not have come from cache, could have but didn't, did! */
        Involvement,
        /* multi-purpose, when loading and reading cache */
        ContentCount;

   unsigned long  /* buffer for hash value used when caching */
                  HashValue;

   char  /* multi-purpose, when loading and reading cache */
         *ContentPtr,
         /* points into cache buffer when loading via record IO */
         *ContentCurrentPtr;

   /* request is being used to fill a cache entry */
   struct CacheStruct  *EntryPtr;

   /* pointer to an AST/funtion if the cache is unusable for some reason */
   void (*NotUsableFunctionPtr)(struct RequestStruct*);
};

/***************************/
/* request CGI environment */
/***************************/

struct  RequestCgiStruct
{
   boolean  /* do not output to client record-by-record, buffer */
            BufferRecords,
            /* script output escape is being processed */
            CalloutInProgress,
            /* the response is encode in some way, force stream mode */
            ContentEncoding,
            /* the MIME type is "text/..." */
            ContentTypeText,
            /* is NOT a script, just the CLI being used to execute some DCL */
            IsCliDcl,
            /* in the body of the response  */
            ProcessingBody;

   int  /* length of heap memory pointed to by BufferPtr */
        BufferLength,
        /* remaining space in heap memory pointed to by BufferPtr */
        BufferRemaining,
        /* count of characters pointed to by 'CalloutOutputPtr' */
        CalloutOutputCount,
        /* length of "end-of-file" (output) sequence */
        EofLength,
        /* length of "end-of-text" sequence */
        EotLength,
        /* length of "escape" sequence */
        EscLength,
        /* CGI header lines so far */
        HeaderLineCount,
        /* stream, record, crlf modes */
        OutputMode,
        /* number of records (may have multiple lines) received from a script */
        RecordCount,
        /* how many attempts have been made to restart a CGI script */
        ScriptRetryCount,
        /* for VMS Apache compatibility (1.3.9 at least!) */
        XVMSRecordMode;

   char  /* heap memory in which the CGI variables are generated */
         *BufferPtr,
         /* current position in CGI variable buffer */
         *BufferCurrentPtr,
         /* pointer to a record output by a callout sequence */
         *CalloutOutputPtr,
         /* "end-of-file" (output) sequence */
         *EofPtr,
         /* "end-of-text" sequence */
         *EotPtr,
         /* "escape" sequence */
         *EscPtr,
         /* VMS syntax script file name */
         *ScriptFileNamePtr;
};

/******************************/
/* request header information */
/******************************/

struct  RequestHeaderStruct
{
   int  /* "Accept:" length */
        AcceptLength,
        /* "Accept-Charset:" length */
        AcceptCharsetLength,
        /* "Accept-Encoding:" length */
        AcceptEncodingLength,
        /* "Accept-Language:" length */
        AcceptLangLength,
        /* length of request header field */
        AuthorizationLength,
        /* when processing request header, count to find first blank line */
        ConsecutiveNewLineCount,
        /* "Content-Length:" value */
        ContentLength,
        /* "Content-Type:" length */
        ContentTypeLength,
        /* "Forwarded:" line(s) length */
        ForwardedLength,
        /* value representation of HTTP protocol version number */
        HttpVersion,
        /* length paramater from "If-Modified-Since:" header */
        IfModifiedSinceLength,
        /* value representation of request HTTP method */
        Method,
        /* length of request header field */
        RefererLength,
        /* lenth of URI (path plus query string) from HTTP header */
        RequestUriLength,
        /* length of path from HTTP header */
        PathInfoLength,
        /* length of request header field */
        ProxyAuthorizationLength,
        /* length of query string from HTTP header */
        QueryStringLength,
        /* number of characters up until the blank line */
        RequestHeaderLength,
        /* characters in the request line (e.g. "GET /path HTTP/1.0\n") */
        RequestLineLength,
        /* length of request header field */
        UserAgentLength;

   char  /* "Accept:" header lines */
         *AcceptPtr,
         /* "Accept-Charset:" header lines */
         *AcceptCharsetPtr,
         /* "Accept-Encoding:" header lines */
         *AcceptEncodingPtr,
         /* "Accept-Language:" header lines */
         *AcceptLangPtr,
         /* pointer to heap storage of "Authorization:" field */
         *AuthorizationPtr,
         /* stream's MIME content type */
         *ContentTypePtr,
         /* "Cookie:" request header encountered */
         *CookiePtr,
         /* "ETag:" header line (only for proxy use) */
         *ETagPtr,
         /* "Forwarded:" header line */
         *ForwardedPtr,
         /* "Host:" header line */
         *HostPtr,
         /* pointer to heap storage of "If-Modified-Since:" field */
         *IfModifiedSincePtr,
         /* pointer to heap storage of request path */
         *PathInfoPtr,
         /* "Pragma:" request header encountered */
         *PragmaPtr,
         /* pointer to heap storage of request query string */
         *QueryStringPtr,
         /* pointer to request header */
         *RequestHeaderPtr,
         /* pointer to requested resource (path and any query string) */
         *RequestUriPtr,
         /* pointer to heap storage of "Proxy-Authorization:" field */
         *ProxyAuthorizationPtr,
         /* "Proxy-Connection:" request header encountered */
         *ProxyConnectionPtr,
         /* pointer to heap storage of "Referer:" field */
         *RefererPtr,
         /* pointer to heap storage of "User-Agent:" field */
         *UserAgentPtr;

   char  /* string reqpresenting the request's HTTP method */
         MethodName [METHOD_NAME_SIZE];
};

/***********************************/
/* request network-related storage */
/***********************************/

/* must be located in the non-zeroed portion of the request stucture! */
struct  RequestNetStruct
{
   int  /* count of how many times the TCP/IP connection is reused */
        KeepAliveCount,
        /* size of network read */
        ReadRawDataSize,
        /* size of network read buffer */
        ReadBufferSize,
        /* size of network write */
        WriteRawDataLength;

   unsigned short  /* channel to client's TCP/IP device */
                   ClientChannel,
                   /* client's port ;^) */
                   ClientPort;

   unsigned long  /* client's binary IP address */
                  ClientIpAddress;

   char  /* pointer to network reads */
         *ReadRawDataPtr,
         /* pointer to heap storage client-read network buffering */
         *ReadBufferPtr,
         /* pointer to network writes */
         *WriteRawDataPtr;

   char  /* internet host/domain name of client */
         ClientHostName [128],
         /* numeric host/domain address of client */
         ClientIpAddressString [32];

   /* I/O status blocks */
   struct AnIOsb  ReadIOsb,
                  WriteIOsb;

   /* network read and write AST function pointers */
   void (*ReadRawAstFunctionPtr)(struct RequestStruct*);
   void (*WriteRawAstFunctionPtr)(struct RequestStruct*);
};

/*************************/
/* request path settings */
/*************************/

struct RequestPathSetStruct
{
   boolean  /* only authorize the mapped path, rather than the request path */
            AuthorizeMapped,
            /* only authorize the full path (not as script then path) */
            AuthorizeOnce,
            /* rule mapping, SET the path to be pre-expired */
            Expired,
            /* apply mapping rules to empty paths */
            MapEmpty,
            /* if a script is mapped, DO NOT map the derived path portion */
            MapOnce,
            /* rule mapping, SET the path not-to-be-cached */
            NoCache,
            /* rule mapping, SET the path not-to-be-logged */
            NoLog,
            /* VMS user profile does not apply to this path */
            NoProfile,
            /* path may contain SSI documents with privileged directives */
            PrivSsi,
            /* provide a basic, lightly detailed error/other report */
            ReportBasic,
            /* do not search for the script file (for RTE use) */
            ScriptNoFind,
            /* rule mapping, SET the path allowing stream-LF conversion */
            StmLF;

   int  /* SSL CGI variables */
        SSLCGIvar;

   char  /* rule mapping SET the path with a CGI variable prefix */
         *CgiPrefixPtr,
         /* rule mapping SET the path with a specific charset */
         *CharsetPtr,
         /* rule mapping SET the path with a specific content-type */
         *ContentTypePtr,
         /* rule mapping SET the path with a "Index of" format */
         *IndexPtr,
         /* the username the script should execute under */
         *ScriptAsPtr;
};

/********************/
/* request response */
/********************/

struct  RequestResponseStruct
{
   boolean  /* response header has been sent to client */
            HeaderSent,
            /* response include an "Expires:" the same as "Last-Modified:" */
            PreExpired,
            /* report any errors using the error report script */
            ErrorReportByRedirect;

   int  /* "Cookie:" response header */
        *CookieLength,
        /* used during HEAD method to determine when header ends */
        HeaderNewlineCount,
        /* buffer for data length */
        HeaderDataLength,
        /* length of reponse header */
        HeaderLength,
        /* numeric equivalent of the "200", "302", etc., HTTP status code */
        HttpStatus,
        /* length of error report text/query-string */
        ErrorReportLength;

   unsigned long  /* response duration */
                  Duration;

   char  /* from CGI responses */
         *ContentTypePtr,
         /* "Cookie:" response header array */
         *CookiePtr [RESPONSE_COOKIE_MAX],
         /* pointer to response header */
         *HeaderPtr,
         /* buffer for data pointer */
         *HeaderDataPtr,
         /* pointer to heap storage of redirection location path */
         *LocationPtr,
         /* pointer to other info when generating error report */
         *ErrorOtherTextPtr,
         /* pointer to error text/query-string */
         *ErrorReportPtr,
         /* pointer to explanation when generating error report */
         *ErrorTextPtr;

   /* AST function pointers */
   void (*HeaderAstFunctionPtr)(struct RequestStruct*);
};

/************************/
/* request time storage */
/************************/

struct  RequestTimeStruct
{
   unsigned long  /* start of request processing */
                  Vms64bit [2],
                  /* time from "If-Modified-Since:" header */
                  IfModifiedSinceVMS64bit [2];

   unsigned short  /* component equivalent of 'Vms64bit' */
                   VmsVector [7];

   char  /* GMT-adjusted string equivalent of 'Vms64bit' */
         GmDateTime [32];
};

/******************/
/* request timers */
/******************/

/* must be located in the non-zeroed portion of the request stucture! */
struct  RequestTmrStruct
{
   int  /* counter for input timeout */
        InputCount,
        /* counter for keep-alive timeout */
        KeepAliveCount,
        /* previous Rx bytes for output no-progress checking */
        NoProgressBytesRx,
        /* previous Tx bytes for output no-progress checking */
        NoProgressBytesTx,
        /* counter for output no-progress */
        NoProgressCount,
        /* storage for server value (WATCH must be able to manipulate this) */
        NoProgressSeconds,
        /* counter for output timeout */
        OutputCount,
        /* supervisor timer has expired */
        TerminatedCount;
};

/****************************/
/* request output buffering */
/****************************/

struct  RequestOutputStruct
{
   /* the head of the output buffer list */
   struct ListHeadStruct  BufferList;

   /* pointer to heap storage structure for output buffering */
   struct ListEntryStruct  *BufferStructPtr,
                           *BufferNowStructPtr;

   /* pointer to any AST function */
   void  *BufferAstFunctionPtr;

   boolean  /* escapes HTML-forbidden characters as sent to client */
            BufferEscapeHtml,
            /* all output buffers must be written to network */
            BufferFlush;

   int  /* count of all data in all output buffers */
        BufferCount,
        /* bytes still available in the current output buffer */
        BufferRemaining;

   char  /* pointer to the start of the current buffer */
         *BufferPtr,
         /* pointer used to point into 'Buffer' storage */
         *BufferCurrentPtr;
};

/******************************/
/* per-request data structure */
/******************************/

struct RequestStruct
{
   /***************************/
   /* general purpose storage */
   /***************************/

   /*
      Storage areas at the beginning of this structure, specifically
      above the field 'RetainAboveZeroBelow', are retained between
      successive requests during persistent connections.
      When a "keep-alive" connection is reinitialized ready for a
      potential new request all of this structure below (and including)
      that field are zeroed, effectively allowing a new request.
   */

   /* for maintaining the list of request structures */
   struct  ListEntryStruct  RequestListEntry;

   /* zone ID for request heap's virtual memory management */
   unsigned long  VmHeapZoneId;

   /* pointer to service structure of host/port etc of service connected to */
   struct ServiceStruct  *ServicePtr;

   /* structures containing specific, non-to-be-zeroed request storage */
   struct RequestNetStruct  rqNet;
   struct RequestTmrStruct  rqTmr;

   int  /* server number of IP accept() and request creation */
        ConnectNumber,
        /* avoid redirection loops by keeping track of the number */
        RedirectCount,
        /* an error is being reported from a redirect path */
        RedirectErrorStatusCode,
        /* rquest is being WATCHed */
        WatchItem;

   /* when redirecting this points to any current authentication realm */
   char  *RedirectErrorAuthRealmDescrPtr;

   /* make it easy on ourselves, make the SSL structure pointer typeless! */
   void  *SeSoLaPtr;

   /* the rest of this structure will be zeroed with a persistent connection */
   /***************************/
    unsigned long  ZeroedBegin;
   /***************************/

   boolean  /* "temporary" file, delete it on close */
            DeleteOnClose,
            /* true if a mapping rule identifies this as a "CGIplus" script */
            IsCgiPlusScript,
            /* this request has a "Connection: Keep-Alive" token */
            KeepAliveRequest,
            /* the server has responded with "keep-alive" */
            KeepAliveResponse,
            /* this persistent connection has timed out */
            KeepAliveTimeout,
            /* extended file specifications to be used on this path */
            PathOdsExtended,
            /* "Pragma: no-cache" HTTP request header line encountered */
            PragmaNoCache,
            /* proxy request (e.g. "http://...", "ftp://...") */
            ProxyRequest,
            /* an "Xray" returns full response as plain-text (diagnostic) */
            XrayRequest;

   int  /* counter representing request activity has be incremented */
        AccountingDone,
        /* size of buffer space for sys$output from DCL subprocess */
        *DclSysOutputSize,
        /* when trying home pages this returns the VMS status */
        HomePageStatus,
        /* length of mapped path */
        MappedPathLength,
        /* interge representing prefered message language */
        MsgLanguage,
        /* on-disk specification; 0 = not determined, 2 = ODS-2, 5 = ODS-5 */
        PathOds,
        /* length of remote user name */
        RemoteUserLength,
        /* count of home page file names tried */
        RequestHomePageIndex;

   unsigned long  /* count of REQUEST-RELATED bytes received from the client */
                  BytesRx,
                  /* count of REQUEST-RELATED bytes sent to the client */
                  BytesTx,
                  /* count of TOTAL bytes received from the client */
                  BytesRawRx,
                  /* count of TOTAL bytes sent to the client */
                  BytesRawTx;

   char  /* buffer space for sys$output from DCL subprocess */
         *DclSysOutputPtr,
         /* pointer to mapped path */
         *MappedPathPtr;

   char  /* authenticated user name from "Authorization:" */
         RemoteUser [AUTH_MAX_USERNAME_LENGTH+1],
         /* storage when authenticating remote user */
         RemoteUserPassword [AUTH_MAX_PASSWORD_LENGTH+1],
         /* file mapped from path to specification */
         RequestMappedFile [ODS_MAX_FILE_NAME_LENGTH+1],
         /* run-time mapped from rules */
         RequestMappedRunTime [ODS_MAX_FILE_NAME_LENGTH+1],
         /* script mapped from path to specification */
         RequestMappedScript [ODS_MAX_FILE_NAME_LENGTH+1],
         /* mapped script name */
         ScriptName [SCRIPT_NAME_SIZE+1],
         /* unique ID used for tracking */
         TrackId [TRACK_ID_SIZE+1];

   /* structures containing specific request storage */
   struct  RequestHeaderStruct  rqHeader;
   struct  RequestBodyStruct  rqBody;
   struct  RequestAuthorizationStruct  rqAuth;
   struct  RequestCacheStruct  rqCache;
   struct  RequestCgiStruct  rqCgi;
   struct  RequestOutputStruct  rqOutput;
   struct  RequestPathSetStruct  rqPathSet;
   struct  RequestResponseStruct  rqResponse;
   struct  RequestTimeStruct  rqTime;
   struct  ContentInfoStruct  rqContentInfo;
   struct  OdsStruct  ParseOds;

   /* AST function pointers */
   void (*WatchShowProcessNextTaskFunction)(struct RequestStruct*);

   /**************/
   /* task lists */
   /**************/

   /* these two modules can have multiple, concurrent instances */
   struct  ListHeadStruct  DirTaskList,
                           SsiTaskList;

   /* these modules/tasks can only have one total or multiple serially */
   struct  DclTaskStruct      *DclTaskPtr;
   struct  DECnetTaskStruct   *DECnetTaskPtr;
   struct  DescrTaskStruct    *DescrTaskPtr;
   struct  DirTaskStruct      *DirTaskPtr;
   struct  FileTaskStruct     *FileTaskPtr;
   struct  GraphTaskStruct    *GraphTaskPtr;
   struct  HTAdminTaskStruct  *HTAdminTaskPtr;
   struct  IsMapTaskStruct    *IsMapTaskPtr;
   struct  MenuTaskStruct     *MenuTaskPtr;
   struct  ProxyTaskStruct    *ProxyTaskPtr;
   struct  PutTaskStruct      *PutTaskPtr;
   struct  SsiTaskStruct      *SsiTaskPtr;
   struct  UpdTaskStruct      *UpdTaskPtr;

   /*************************/
    unsigned long  ZeroedEnd;
   /*************************/

};

#ifdef __ALPHA
#   pragma member_alignment __restore
#endif

#endif /* WASD_H_LOADED */

/*****************************************************************************/
o                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    