/*****************************************************************************/
/*
                                 StreamLF.c

A utility to copy files, converting to/from STREAM_LF record format.  Primary
use will be for NFS-accessable files where VMS by default creates and uses
VARIABLE format but to be updateable (writeable) via NFS they need to be
STREAM_LF.  This utility provides a next-highest version in the required
format.

The default behaviour is to convert all files to stream-LF with confirmation
and logging.


QUALIFIERS
----------
/[NO]CONFIRM    confirm any copy before commencing
/FROM           convert from STREAM_LF to VARIABLE
/HELP           display a screen of information
/IDENTIFY       list all the files with non-stream formats
/[NO]LOG        log all decisions/copies
/[NO]ODS5       control extended file specification (basically for testing)
/PURGE          delete previous (original record format) version ... CAUTION!
/TO             convert from <format> (usually VARIABLE) to STREAM_LF


VERSION HISTORY
---------------
29-JAN-2000  MGD  v1.1.0, support extended file specifications (ODS-5)
03-MAY-1996  MGD  v1.0.0, initial development
*/
/*****************************************************************************/

#ifdef __ALPHA
   char SoftwareID [] = "STREAMLF AXP-1.1.0";
#else
   char SoftwareID [] = "STREAMLF VAX-1.1.0";
#endif

#ifdef __ALPHA
#  ifndef NO_ODS_EXTENDED
#     define ODS_EXTENDED 1
      /* this is smaller than the technical maximum, but still quite large! */
#     define ODS_MAX_FILE_NAME_LENGTH 511
#     define ODS_MAX_FILESYS_NAME_LENGTH 264
#  endif
#endif
#define ODS2_MAX_FILE_NAME_LENGTH 255
#ifndef ODS_MAX_FILE_NAME_LENGTH
#  define ODS_MAX_FILE_NAME_LENGTH ODS2_MAX_FILE_NAME_LENGTH
#endif
#if ODS_MAX_FILE_NAME_LENGTH < ODS2_MAX_FILE_NAME_LENGTH
#  define ODS_MAX_FILE_NAME_LENGTH ODS2_MAX_FILE_NAME_LENGTH
#endif

/* standard C header files */
#include <stdio.h>
#include <ctype.h>
#include <errno.h>

/* VMS related header files */
#include <atrdef.h>
#include <descrip.h>
#include <fibdef.h>
#include <iodef.h>
#include <rms.h>
#include <rmsdef.h>
#include <ssdef.h>
#include <stsdef.h>
#include <syidef.h>

/* extracted from FATDEF.H */
#define FAT$C_UNDEFINED 0               /* undefined record type */
#define FAT$C_FIXED 1                   /* fixed record type */
#define FAT$C_VARIABLE 2                /* variable length */
#define FAT$C_VFC 3                     /* variable + fixed control */
#define FAT$C_STREAM 4                  /* RMS-11 stream format  */
#define FAT$C_STREAMLF 5                /* LF-terminated stream format */
#define FAT$C_STREAMCR 6                /* CR-terminated stream format */
#define FAT$C_SEQUENTIAL 0              /* sequential organization */
#define FAT$C_RELATIVE 1                /* relative organization */
#define FAT$C_INDEXED 2                 /* indexed organization */
#define FAT$C_DIRECT 3                  /* direct organization */
#define FAT$M_FORTRANCC 0x1
#define FAT$M_IMPLIEDCC 0x2
#define FAT$M_PRINTCC 0x4
#define FAT$M_NOSPAN 0x8
#define FAT$M_MSBRCW 0x10

/* application header files */
#include "enamel.h"

#define boolean int
#define true 1
#define false 0

#define VMSok(x) ((x) & STS$M_SUCCESS)
#define VMSnok(x) !(((x) & STS$M_SUCCESS))

char  Utility [] = "STREAMLF";

boolean  Debug,
         DoConfirm,
         DoFromStreamLF,
         DoHelp,
         DoIdentify,
         DoLog,
         DoPurge,
         DoToStreamLF,
         OdsExtended;

char  CommandLine [256],
      FileSpec [256];

/*****************************************************************************/
/*
*/

main
(
int argc,
char *argv[]
)
{
   int  acnt,
        status;

   /*********/
   /* begin */
   /*********/
   if (getenv ("STREAMLF$DBUG") != NULL) Debug = true;

#ifdef ODS_EXTENDED
   OdsExtended = (GetVmsVersion() >= 72);
   ENAMEL_NAML_SANITY_CHECK
   ENAMEL_FIBDEF_SANITY_CHECK
#endif /* ODS_EXTENDED */

   GetParameters ();

   if (DoHelp)
   {
      ShowHelp ();
      exit (SS$_NORMAL);
   }

   SearchFileSpec (FileSpec);

   exit (SS$_NORMAL);
}

/****************************************************************************/
/*
*/ 

SearchFileSpec (char *FileSpec)

{
   int  status,
        FileCount,
        FileNameLength,
        Length;
   unsigned char  RecordType;
   char  ExpFileSpec [ODS_MAX_FILE_NAME_LENGTH],
         FileName [ODS_MAX_FILE_NAME_LENGTH];
   struct FAB  SearchFab;
   struct NAM  SearchNam;

#ifdef ODS_EXTENDED
   char  FileSysName [ODS_MAX_FILESYS_NAME_LENGTH+1];
   struct NAML  SearchNaml;
#endif /* ODS_EXTENDED */

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "SearchFileSpec() |%s|\n", FileSpec);

   /* initialize the file access block */
   SearchFab = cc$rms_fab;

#ifdef ODS_EXTENDED
   if (OdsExtended)
   {
      SearchFab.fab$l_dna = SearchFab.fab$l_fna = -1;
      SearchFab.fab$b_dns = SearchFab.fab$b_fns = 0;
      SearchFab.fab$l_nam = &SearchNaml;

      ENAMEL_RMS_NAML(SearchNaml)
      SearchNaml.naml$l_long_defname = "*.TXT";
      SearchNaml.naml$l_long_defname_size = 5;
      SearchNaml.naml$l_long_filename = FileSpec;
      SearchNaml.naml$l_long_filename_size = strlen(FileSpec);
      SearchNaml.naml$l_long_expand = ExpFileSpec;
      SearchNaml.naml$l_long_expand_alloc = sizeof(ExpFileSpec)-1;
      SearchNaml.naml$l_long_result = FileName;
      SearchNaml.naml$l_long_result_alloc = sizeof(FileName)-1;
      SearchNaml.naml$l_filesys_name = FileSysName;
      SearchNaml.naml$l_filesys_name_alloc = sizeof(FileSysName)-1;
   }
   else
#endif /* ODS_EXTENDED */
   {
      SearchFab.fab$l_dna = "*.TXT";
      SearchFab.fab$b_dns = 5;
      SearchFab.fab$l_fna = FileSpec;
      SearchFab.fab$b_fns = strlen(FileSpec);
      SearchFab.fab$l_nam = &SearchNam;

      SearchNam = cc$rms_nam;
      SearchNam.nam$l_esa = ExpFileSpec;
      SearchNam.nam$b_ess = ODS2_MAX_FILE_NAME_LENGTH;
      SearchNam.nam$l_rsa = FileName;
      SearchNam.nam$b_rss = ODS2_MAX_FILE_NAME_LENGTH;
   }

   if (VMSnok (status = sys$parse (&SearchFab, 0, 0)))
      exit (status);

   while (VMSok (status = sys$search (&SearchFab, 0, 0)))
   {
#ifdef ODS_EXTENDED
      if (OdsExtended)
      {
         SearchNaml.naml$l_long_ver[SearchNaml.naml$l_long_ver_size] = '\0';
         FileNameLength = (SearchNaml.naml$l_long_ver - FileName) +
                          SearchNaml.naml$l_long_ver_size;
      }
      else
#endif /* ODS_EXTENDED */
      {
         SearchNam.nam$l_ver[SearchNam.nam$b_ver] = '\0';
         FileNameLength = (SearchNam.nam$l_ver - FileName) +
                          SearchNam.nam$b_ver;
      }
      if (Debug)
         fprintf (stdout, "FileName %d |%s|\n", FileNameLength, FileName);

#ifdef ODS_EXTENDED
      if (OdsExtended)
         FileRecordType (NULL, &SearchNaml, &RecordType);
      else
         FileRecordType (&SearchNam, NULL, &RecordType);
#else /* ODS_EXTENDED */
      FileRecordType (&SearchNam, &RecordType);
#endif /* ODS_EXTENDED */

      if (DoIdentify)
      {
         if ((RecordType == FAT$C_STREAMLF) ||
             (RecordType == FAT$C_STREAM) ||
             (RecordType == FAT$C_STREAMCR)) continue;

         if (RecordType == FAT$C_VARIABLE)
            fprintf (stdout, "%%%s-I-VARIABLE, %s\n", Utility, FileName);
         else
         if (RecordType == FAT$C_VFC)
            fprintf (stdout, "%%%s-I-VFC, %s\n", Utility, FileName);
         else
         if (RecordType == FAT$C_FIXED)
            fprintf (stdout, "%%%s-W-FIXED, %s\n", Utility, FileName);
         else
         if (RecordType == FAT$C_UNDEFINED)
            fprintf (stdout, "%%%s-W-UNDEFINED, %s\n", Utility, FileName);
         else
         {
            fprintf (stdout, "%%%s-E-INTERNAL, error\n", Utility);
            exit (STS$K_ERROR | STS$M_INHIB_MSG);
         }
      }
      else
      if (DoToStreamLF)
      {
         if ((RecordType == FAT$C_STREAMLF) ||
             (RecordType == FAT$C_STREAM) ||
             (RecordType == FAT$C_STREAMCR))
         {
            if (DoLog)
               fprintf (stdout, "%%%s-I-ISSTREAM, %s\n",
                        Utility, FileName);
         }
         else
         if (RecordType == FAT$C_VARIABLE)
         {
            if (DoLog)
               fprintf (stdout, "%%%s-I-VARIABLE, %s\n", Utility, FileName);
            CopyFile (FileName, FileNameLength, FAB$C_STMLF);
         }
         else
         if (RecordType == FAT$C_VFC)
         {
            if (DoLog)
               fprintf (stdout, "%%%s-I-VFC, %s\n", Utility, FileName);
            CopyFile (FileName, FileNameLength, FAB$C_STMLF);
         }
         else
         if (RecordType == FAT$C_FIXED)
         {
            if (DoLog)
               fprintf (stdout, "%%%s-W-FIXED, %s\n", Utility, FileName);
         }
         else
         if (RecordType == FAT$C_UNDEFINED)
         {
            if (DoLog)
               fprintf (stdout, "%%%s-W-UNDEFINED, %s\n", Utility, FileName);
         }
         else
         {
            fprintf (stdout, "%%%s-E-INTERNAL, error\n", Utility);
            exit (STS$K_ERROR | STS$M_INHIB_MSG);
         }
      }
      else
      if (DoFromStreamLF)
      {
         if (RecordType == FAT$C_STREAMLF)
            CopyFile (FileName, FileNameLength, FAB$C_VAR);
         else
            if (DoLog)
               fprintf (stdout, "%%%s-W-NOTSTREAMLF, %s\n", Utility, FileName);
      }

      FileCount++;
   }

   if (VMSnok (status) && status != RMS$_NMF) exit (status);
}

/*****************************************************************************/
/*
*/ 

CopyFile
(
char *FileName,
int FileNameLength,
int DstRecordFormat
)
{
   register char  *cptr;

   int  status;
   char  Buffer [32768],
         Confirmation [32],
         DstExpFileName [ODS_MAX_FILE_NAME_LENGTH],
         DstResFileName [ODS_MAX_FILE_NAME_LENGTH],
         SrcExpFileName [ODS_MAX_FILE_NAME_LENGTH];
   struct FAB  SrcFab;
   struct FAB  DstFab;
   struct NAM  SrcNam;
   struct NAM  DstNam;
#ifdef ODS_EXTENDED
   struct NAML  SrcNaml;
   struct NAML  DstNaml;
#endif /* ODS_EXTENDED */
   struct RAB  SrcRab;
   struct RAB  DstRab;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "CopyFile() |%s|\n", FileName);

   if (DoConfirm)
   {
      if (DoToStreamLF)
         fprintf (stdout, "%s\nCopy with conversion to STREAM_LF? [N]: ",
                  FileName);
      else
         fprintf (stdout, "%s\nCopy with conversion to VARIABLE? [N]: ",
                  FileName);
      fgets (Confirmation, sizeof(Confirmation), stdin);
      if (toupper(Confirmation[0]) != 'Y') return;
   }

   SrcFab = cc$rms_fab;

#ifdef ODS_EXTENDED
   if (OdsExtended)
   {
      SrcFab.fab$l_dna = SrcFab.fab$l_fna = -1;
      SrcFab.fab$b_dns = SrcFab.fab$b_fns = 0;
      SrcFab.fab$l_nam = &SrcNaml;

      ENAMEL_RMS_NAML(SrcNaml)
      SrcNaml.naml$l_long_defname = "*.TXT";
      SrcNaml.naml$l_long_defname_size = 5;
      SrcNaml.naml$l_long_filename = FileName;
      SrcNaml.naml$l_long_filename_size = FileNameLength;
      SrcNaml.naml$l_long_expand = SrcExpFileName;
      SrcNaml.naml$l_long_expand_alloc = sizeof(SrcExpFileName)-1;
   }
   else
#endif /* ODS_EXTENDED */
   {
      SrcFab.fab$l_dna = "*.TXT";
      SrcFab.fab$b_dns = 5;
      SrcFab.fab$l_fna = FileName;
      SrcFab.fab$b_fns = FileNameLength;
      SrcFab.fab$l_nam = &SrcNam;

      SrcNam = cc$rms_nam;
      SrcNam.nam$l_esa = SrcExpFileName;
      SrcNam.nam$b_ess = ODS2_MAX_FILE_NAME_LENGTH;
   }

   status = sys$open (&SrcFab, 0, 0);
   if (Debug) fprintf (stdout, "sys$open() %%X%08.08X\n", status);
   if (VMSnok (status)) exit (status);

#ifdef ODS_EXTENDED
   if (OdsExtended)
      SrcNaml.naml$l_long_ver[SrcNaml.naml$l_long_ver_size] = '\0';
   else
#endif /* ODS_EXTENDED */
      SrcNam.nam$l_ver[SrcNam.nam$b_ver] = '\0';

   SrcRab = cc$rms_rab;
   SrcRab.rab$l_fab = &SrcFab;
   SrcRab.rab$l_ubf = Buffer;
   SrcRab.rab$w_usz = sizeof(Buffer);

   status = sys$connect (&SrcRab, 0, 0);
   if (Debug) fprintf (stdout, "sys$connect() %%X%08.08X\n", status);
   if (VMSnok (status)) exit (status);

   DstFab = cc$rms_fab;
   DstFab.fab$l_fop = FAB$M_SQO;
   DstFab.fab$b_rfm = DstRecordFormat;

#ifdef ODS_EXTENDED
   if (OdsExtended)
   {
      DstFab.fab$l_fna = -1;
      DstFab.fab$b_fns = 0;
      DstFab.fab$l_nam = &DstNaml;

      ENAMEL_RMS_NAML(DstNaml)
      DstNaml.naml$l_long_filename = FileName;
      for (cptr = FileName; *cptr && *cptr != ';'; cptr++);
      DstNaml.naml$l_long_filename_size = cptr - FileName;
      DstNaml.naml$l_long_expand = DstExpFileName;
      DstNaml.naml$l_long_expand_alloc = sizeof(DstExpFileName)-1;
      DstNaml.naml$l_long_result = DstResFileName;
      DstNaml.naml$l_long_result_alloc = sizeof(DstResFileName)-1;
   }
   else
#endif /* ODS_EXTENDED */
   {
      DstFab.fab$l_fna = FileName;
      for (cptr = FileName; *cptr && *cptr != ';'; cptr++);
      DstFab.fab$b_fns = cptr - FileName;
      DstFab.fab$l_nam = &DstNam;

      DstNam = cc$rms_nam;
      DstNam.nam$l_esa = DstExpFileName;
      DstNam.nam$b_ess = ODS2_MAX_FILE_NAME_LENGTH;
      DstNam.nam$l_rsa = DstResFileName;
      DstNam.nam$b_rss = ODS2_MAX_FILE_NAME_LENGTH;
   }

   status = sys$create (&DstFab, 0, 0);
   if (Debug) fprintf (stdout, "sys$create() %%X%08.08X\n", status);
   if (VMSnok (status)) exit (status);

#ifdef ODS_EXTENDED
   if (OdsExtended)
      DstNaml.naml$l_long_ver[DstNaml.naml$l_long_ver_size] = '\0';
   else
#endif /* ODS_EXTENDED */
      DstNam.nam$l_ver[DstNam.nam$b_ver] = '\0';

   DstRab = cc$rms_rab;
   DstRab.rab$l_fab = &DstFab;
   DstRab.rab$l_rbf = Buffer;

   status = sys$connect (&DstRab, 0, 0);
   if (Debug) fprintf (stdout, "sys$connect() %%X%08.08X\n", status);
   if (VMSnok (status)) exit (status);

   while (VMSok (status = sys$get (&SrcRab , 0, 0)))
   {
      /** if (Debug) fprintf (stdout, "sys$get() %%X%08.08X\n", status); **/
      DstRab.rab$w_rsz = SrcRab.rab$w_rsz;
      if (VMSnok (status = sys$put (&DstRab, 0, 0)))
         exit (status);
      /** if (Debug) fprintf (stdout, "sys$put() %%X%08.08X\n", status); **/
   }

   if (status != RMS$_EOF) exit (status);

   sys$close (&DstFab, 0, 0);
   sys$close (&SrcFab, 0, 0);

   if (DoLog)
   {
      if (DoToStreamLF)
         fprintf (stdout, "%%%s-I-STREAMLF, %s\n", Utility, DstResFileName);
      else
         fprintf (stdout, "%%%s-I-VARIABLE, %s\n", Utility, DstResFileName);
   }

   if (DoPurge)
   {
      if (VMSnok (status = sys$erase (&SrcFab, 0, 0)))
         exit (status);
      if (DoLog) fprintf (stdout, "%%%s-I-PURGE, %s\n", Utility, FileName);
   }
}

/*****************************************************************************/
/*
This function uses the ACP-QIO interface detailed in the "OpenVMS I/O User's 
Reference Manual".
*/ 

int FileRecordType
(
struct NAM *SearchNamPtr,
#ifdef ODS_EXTENDED
   struct NAML *SearchNamlPtr,
#endif /* ODS_EXTENDED */
unsigned char *RecordTypePtr
)
{
   static $DESCRIPTOR (DeviceDsc, "");

   static struct {
      unsigned char  RecordType;
      unsigned char  RecordAttributes;
      unsigned char  OfNoInterest1 [30];
   } AtrRecord;

#ifdef ODS_EXTENDED
   /* only use the local ENAMEL.H FIB definition when necessary */
#  ifdef ENAMEL_FIBDEF
      static struct enamel_fibdef  FileFib;
#  else
      static struct fibdef  FileFib;
#  endif
#else /* ODS_EXTENDED */
   static struct fibdef  FileFib;
#endif /* ODS_EXTENDED */

   static struct atrdef  FileAtr [] =
   {
      { sizeof(AtrRecord), ATR$C_RECATTR, &AtrRecord },
      { 0, 0, 0 }
   };

   static struct {
      unsigned short  Length;
      unsigned short  Unused;
      unsigned long  Address;
   } FileNameAcpDsc,
     FileFibAcpDsc,
     FileAtrAcpDsc;

   static struct {
      unsigned short  Status;
      unsigned short  Unused1;
      unsigned long  Unused2;
   } AcpIOsb;

   int  status;
   unsigned short  AcpChannel;
   unsigned long  AllocatedVbn,
                  EndOfFileVbn;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "FileRecordType()\n");

   /* assign a channel to the disk device containing the file */
#ifdef ODS_EXTENDED
   if (SearchNamPtr != NULL)
   {
      DeviceDsc.dsc$a_pointer = SearchNamPtr->nam$l_dev;
      DeviceDsc.dsc$w_length = SearchNamPtr->nam$b_dev;
   }
   else
   if (SearchNamlPtr != NULL)
   {
      DeviceDsc.dsc$a_pointer = SearchNamlPtr->naml$l_long_dev;
      DeviceDsc.dsc$w_length = SearchNamlPtr->naml$l_long_dev_size;
   }
#else /* ODS_EXTENDED */
   DeviceDsc.dsc$w_length = SearchNamPtr->nam$b_dev;
   DeviceDsc.dsc$a_pointer = SearchNamPtr->nam$l_dev;
#endif /* ODS_EXTENDED */

   if (Debug)
      fprintf (stdout, "|%*.*s|\n",
               DeviceDsc.dsc$w_length, DeviceDsc.dsc$w_length,
               DeviceDsc.dsc$a_pointer);

   status = sys$assign (&DeviceDsc, &AcpChannel, 0, 0, 0);
   if (Debug) fprintf (stdout, "sys$assign() %%X%08.08X\n", status);
   if (VMSnok (status)) return (status);

   /* set up the File Information Block for the ACP interface */
   memset (&FileFib, 0, sizeof(struct fibdef));
   FileFibAcpDsc.Length = sizeof(FileFib);
   FileFibAcpDsc.Address = &FileFib;

#ifdef ODS_EXTENDED
   if (SearchNamPtr != NULL)
   {
      if (Debug) fprintf (stdout, "EXTENDED NAM\n");
      FileFib.fib$w_did[0] = SearchNamPtr->nam$w_did[0];
      FileFib.fib$w_did[1] = SearchNamPtr->nam$w_did[1];
      FileFib.fib$w_did[2] = SearchNamPtr->nam$w_did[2];

      FileNameAcpDsc.Address = SearchNamPtr->nam$l_name;
      FileNameAcpDsc.Length = SearchNamPtr->nam$b_name +
                              SearchNamPtr->nam$b_type +
                              SearchNamPtr->nam$b_ver;
   }
   else
   if (SearchNamlPtr != NULL)
   {
      if (Debug) fprintf (stdout, "EXTENDED NAML\n");
      FileFib.fib$w_did[0] = SearchNamlPtr->naml$w_did[0];
      FileFib.fib$w_did[1] = SearchNamlPtr->naml$w_did[1];
      FileFib.fib$w_did[2] = SearchNamlPtr->naml$w_did[2];

      FileNameAcpDsc.Address = SearchNamlPtr->naml$l_filesys_name;
      FileNameAcpDsc.Length = SearchNamlPtr->naml$l_filesys_name_size;

      FileFib.fib$b_name_format_in = FIB$C_ISO_LATIN;
      FileFib.fib$b_name_format_out = FIB$C_ISO_LATIN;
      FileFib.fib$w_nmctl = FIB$M_NAMES_8BIT;
   }
#else /* ODS_EXTENDED */
   if (Debug) fprintf (stdout, "NAM\n");
   FileFib.fib$w_did[0] = SearchNamPtr->nam$w_did[0];
   FileFib.fib$w_did[1] = SearchNamPtr->nam$w_did[1];
   FileFib.fib$w_did[2] = SearchNamPtr->nam$w_did[2];

   FileNameAcpDsc.Address = SearchNamPtr->nam$l_name;
   FileNameAcpDsc.Length = SearchNamPtr->nam$b_name +
                           SearchNamPtr->nam$b_type +
                           SearchNamPtr->nam$b_ver;
#endif /* ODS_EXTENDED */

   if (Debug)
      fprintf (stdout, "|%*.*s|\n",
               FileNameAcpDsc.Length, FileNameAcpDsc.Length,
               FileNameAcpDsc.Address);

   status = sys$qiow (0, AcpChannel, IO$_ACCESS, &AcpIOsb, 0, 0, 
                      &FileFibAcpDsc, &FileNameAcpDsc, 0, 0,
                      &FileAtr, 0);

   /* immediately deassign the channel in case we return on an error */
   sys$dassgn (AcpChannel);

   if (Debug)
      fprintf (stdout, "sys$qio() %%X%08.08X IOsb: %%X%08.08X\n",
              status, AcpIOsb.Status);

   if (VMSok (status)) status = AcpIOsb.Status;
   if (VMSnok (status)) return (status);

   if (Debug)
      fprintf (stdout, "Type: %02.02X Attributes: %02.02X\n",
               AtrRecord.RecordType, AtrRecord.RecordAttributes);

   *RecordTypePtr = AtrRecord.RecordType;

   return (status);
}

/*****************************************************************************/
/*
*/

ShowHelp ()

{
   fprintf (stdout,
"%%%s-I-HELP, usage for StreamLF Utility (%s)\n\
\n\
A utility to copy files, converting to/from STREAM_LF record format.\n\
\n\
$ STREAMLF [file-specification] [qualifier...]\n\
\n\
/[NO]CONFIRM /FROM /HELP /IDENTIFY /[NO]LOG /PURGE /TO\n\
\n\
Usage examples:\n\
\n\
$ STREAMLF *.TXT                !prompts to convert any non-stream-LF\n\
$ STREAMLF *.TXT /NOCONFIRM     !converts any non-stream-LF (caution)!\n\
$ STREAMLF *.TXT /IDENTIFY      !identifies the current format\n\
$ STREAMLF *.TXT /TO            !converts any non-stream-LF (caution)!\n\
$ STREAMLF *.TXT /FROM          !converts from stream-LF to variable\n\
$ STREAMLF *.TXT /PURGE         !converts, deletes original (caution)!\n\
\n",
   Utility, SoftwareID);
}

/*****************************************************************************/
/*
Get "command-line" parameters, whether from the command-line or from a
configuration symbol or logical containing the equivalent.
*/

GetParameters ()

{
   static char  CommandLine [256];
   static unsigned long  Flags = 0;

   register char  *aptr, *cptr, *clptr, *sptr;

   int  status;
   unsigned short  Length;
   char  ch;
   $DESCRIPTOR (CommandLineDsc, CommandLine);

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "GetParameters()\n");

   if ((clptr = getenv ("STREAMLF$PARAM")) == NULL)
   {
      /* get the entire command line following the verb */
      if (VMSnok (status =
          lib$get_foreign (&CommandLineDsc, 0, &Length, &Flags)))
         exit (status);
      (clptr = CommandLine)[Length] = '\0';
   }

   aptr = NULL;
   ch = *clptr;
   for (;;)
   {
      if (aptr != NULL && *aptr == '/') *aptr = '\0';
      if (!ch) break;

      *clptr = ch;
      if (Debug) fprintf (stdout, "clptr |%s|\n", clptr);
      while (*clptr && isspace(*clptr)) *clptr++ = '\0';
      aptr = clptr;
      if (*clptr == '/') clptr++;
      while (*clptr && !isspace (*clptr) && *clptr != '/')
      {
         if (*clptr != '\"')
         {
            clptr++;
            continue;
         }
         cptr = clptr;
         clptr++;
         while (*clptr)
         {
            if (*clptr == '\"')
               if (*(clptr+1) == '\"')
                  clptr++;
               else
                  break;
            *cptr++ = *clptr++;
         }
         *cptr = '\0';
         if (*clptr) clptr++;
      }
      ch = *clptr;
      if (*clptr) *clptr = '\0';
      if (Debug) fprintf (stdout, "aptr |%s|\n", aptr);
      if (!*aptr) continue;

      if (strsame (aptr, "/DBUG", -1))
      {
         Debug = true;
         continue;
      }

      if (strsame (aptr, "/CONFIRM", 4))
      {
         DoConfirm = true;
         continue;
      }
      if (strsame (aptr, "/NOCONFIRM", 6))
      {
         DoConfirm = false;
         continue;
      }

      if (strsame (aptr, "/FROM", 5))
      {
         DoIdentify = DoToStreamLF = false;
         DoFromStreamLF = true;
         continue;
      }

      if (strsame (aptr, "/HELP", 4))
      {
         DoHelp = true;
         continue;
      }

      if (strsame (aptr, "/IDENTIFY", 3))
      {
         DoFromStreamLF = DoToStreamLF = false;
         DoIdentify = true;
         continue;
      }

      if (strsame (aptr, "/ODS5", 5))
      {
         OdsExtended = true;
         continue;
      }
      if (strsame (aptr, "/NOODS5", 7))
      {
         OdsExtended = false;
         continue;
      }
      if (strsame (aptr, "/PURGE", 4))
      {
         DoPurge = true;
         continue;
      }

      if (strsame (aptr, "/TO", 3))
      {
         DoIdentify = DoFromStreamLF = DoConfirm = false;
         DoToStreamLF = true;
         continue;
      }

      if (strsame (aptr, "/LOG", 4))
      {
         DoLog = true;
         continue;
      }
      if (strsame (aptr, "/NOLOG", 6))
      {
         DoLog = false;
         continue;
      }

      if (*aptr == '/')
      {
         fprintf (stdout, "%%%s-E-IVQUAL, unrecognized qualifier\n \\%s\\\n",
                  Utility, aptr+1);
         exit (STS$K_ERROR | STS$M_INHIB_MSG);
      }

      if (!FileSpec[0])
      {
         sptr = FileSpec;
         for (cptr = aptr; *cptr; *sptr++ = toupper(*cptr++));
         *sptr = '\0';
         continue;
      }

      fprintf (stdout, "%%%s-E-MAXPARM, too many parameters\n \\%s\\\n",
               Utility, aptr);
      exit (STS$K_ERROR | STS$M_INHIB_MSG);
   }
}

/****************************************************************************/
/*
Return an integer reflecting the major and minor version of VMS (e.g. 60, 61,
62, 70, 71, 72, etc.)
*/ 

#ifdef ODS_EXTENDED

int GetVmsVersion ()

{
   static char  SyiVersion [16];

   static struct {
      short int  buf_len;
      short int  item;
      unsigned char   *buf_addr;
      unsigned short  *ret_len;
   }
   SyiItems [] =
   {
      { 8, SYI$_VERSION, &SyiVersion, 0 },
      { 0,0,0,0 }
   };

   int  status,
        version;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "GetVmsVersion()\n");

   if (VMSnok (status = sys$getsyiw (0, 0, 0, &SyiItems, 0, 0, 0)))
      exit (status);
   SyiVersion[8] = '\0';
   version = ((SyiVersion[1]-48) * 10) + (SyiVersion[3]-48);
   if (Debug) fprintf (stdout, "|%s| %d\n", SyiVersion, version);
   return (version);
}

#endif /* ODS_EXTENDED */

/****************************************************************************/
/*
Does a case-insensitive, character-by-character string compare and returns 
true if two strings are the same, or false if not.  If a maximum number of 
characters are specified only those will be compared, if the entire strings 
should be compared then specify the number of characters as 0.
*/ 
 
boolean strsame
(
register char *sptr1,
register char *sptr2,
register int  count
)
{
   while (*sptr1 && *sptr2)
   {
      if (toupper (*sptr1++) != toupper (*sptr2++)) return (false);
      if (count)
         if (!--count) return (true);
   }
   if (*sptr1 || *sptr2)
      return (false);
   else
      return (true);
}
 
/****************************************************************************/
