/*****************************************************************************/
/*
                                Scrunch.c

Utility to "scrunch" Server Side Include (SSI) files.

A "scrunched" SSI file is a variable length record file, where each record
either comprises a single SSI directive, with the "<!--#" beginning on the
record boundary, or a record of other text to be output (i.e. not beginning
with "<!--#").

Why do this?  Well, if all SSI directives begin on a record boundary you only
have to check the first five characters of each record to establish whether it
should be interpreted or directly output!  This saves checking every character
of every record for the opening '<' and the following "!--#".  This can be a
not inconsiderable saving in processing overhead if a largish file only
contains a few SSI directives (like many).  This will not only reduce latency
but significantly reduce processing on more heavily loaded systems.  Tests
indicate anything from 25% to 50% reduction in request duration, with CPU time
consumed showing a similar reduction (depending on the proportion of plain-text
and SSI directives in the file, the less SSI the greater the improvement).

The HTTPd SSI.C module will detect a <!--#SCRUNCH ... --> directive (which
should be at the start of the first record of the file, but actually can occur
anywhere).  If this exists it assumes the file has been legitimately scrunched
and processes the records in an appropriate manner.  This module also checks
for this string to ascertain whether it's dealing with a previously scrunched
file or not.  The HTTPd processes both formats in the same basic manner and so
files may scrunched and unscrunched at anytime without affecting availability
(except perhaps for a brief period of locking).

Files that have been scrunched are basically unsuitable for editing (only due
to the often inappropriately sized records).  Previously scrunched files may be
returned to something (often exactly) resembling their original condition using
the /UNSCRUNCH qualifier.


UASGE
-----
$ SCRUNCH == "$HT_EXE:SCRUNCH"
$ SCRUNCH unscrunched-file.SHTML 
$ SCRUNCH *.SHTML 
$ SCRUNCH [...]*.SHTML 
$ SCRUNCH /UNSCRUNCH *.SHTML
$ SCRUNCH /UNSCRUNCH [...]*.SHTML


QUALIFIERS
----------
/DBUG           turns on all "if (Debug)" statements
/[NO]ODS5       control extended file specification (basically for testing)
/SCRUNCH        (default)
/UNSCRUNCH      convert scrunched file back to editable format
/VERBOSE        additional, per-file information


BUILD DETAILS
-------------
See BUILD_SCRUNCH.COM procedure.


COPYRIGHT
---------
Copyright (c) 1999 Mark G.Daniel
This program, comes with ABSOLUTELY NO WARRANTY.
This is free software, and you are welcome to redistribute it
under the conditions of the GNU GENERAL PUBLIC LICENSE, version 2.


VERSION HISTORY (update SoftwareID as well!)
---------------
29-JAN-2000  MGD  v1.1.0, support extended file specifications (ODS-5)
12-SEP-1999  MGD  v1.0.0, initial development
*/
/*****************************************************************************/

#ifdef __ALPHA
   char SoftwareID [] = "SCRUNCH AXP-1.1.0";
#else
   char SoftwareID [] = "SCRUNCH VAX-1.1.0";
#endif

/* standard C header files */
#include <stdio.h>
#include <ctype.h>
#include <errno.h>
#include <stat.h>
#include <unixio.h>

/* VMS-related header files */
#include <descrip.h>
#include <rms.h>
#include <ssdef.h>
#include <stsdef.h>
#include <syidef.h>

/* application header files */
#include "enamel.h"

#ifdef __ALPHA
#  ifndef NO_ODS_EXTENDED
#     define ODS_EXTENDED 1
      /* this is smaller than the technical maximum, but still quite large! */
#     define ODS_MAX_FILE_NAME_LENGTH 511
#     define ODS_MAX_FILESYS_NAME_LENGTH 264
#  endif
#endif
#define ODS2_MAX_FILE_NAME_LENGTH 255
#ifndef ODS_MAX_FILE_NAME_LENGTH
#  define ODS_MAX_FILE_NAME_LENGTH ODS2_MAX_FILE_NAME_LENGTH
#endif
#if ODS_MAX_FILE_NAME_LENGTH < ODS2_MAX_FILE_NAME_LENGTH
#  define ODS_MAX_FILE_NAME_LENGTH ODS2_MAX_FILE_NAME_LENGTH
#endif

#define boolean int
#define true 1
#define false 0

#define VMSok(x) ((x) & STS$M_SUCCESS)
#define VMSnok(x) (!((x) & STS$M_SUCCESS))
 
char  Utility [] = "SCRUNCH";

boolean  Debug,
         DoScrunch,
         DoUnScrunch,
         DoVerbose,
         OdsExtended;

char  FileSpec [ODS_MAX_FILE_NAME_LENGTH];

/* required function prototypes */
char* SysGetMsg (int);

/*****************************************************************************/
/*
*/

main ()

{
   /*********/
   /* begin */
   /*********/

   DoScrunch = true;

#ifdef ODS_EXTENDED
   OdsExtended = (GetVmsVersion() >= 72);
   ENAMEL_NAML_SANITY_CHECK
#endif /* ODS_EXTENDED */

   GetParameters ();

   if (!FileSpec[0])
   {
      fprintf (stdout, "%%%s-E-INSFARG, requires file specification\n",
               Utility);
      exit (STS$K_ERROR | STS$M_INHIB_MSG);
   }
   if (strchr (FileSpec, ';') != NULL)
   {
      fprintf (stdout, "%%%s-E-SCRUCHVER, version numbers not permitted\n",
               Utility);
      exit (STS$K_ERROR | STS$M_INHIB_MSG);
   }

   SearchFileSpec (FileSpec);

   exit (SS$_NORMAL);
}

/****************************************************************************/
/*
*/ 

SearchFileSpec (char *FileSpec)

{
   int  status,
        FileCount,
        FileNameLength,
        Length;
   char  FileName [ODS_MAX_FILE_NAME_LENGTH],
         ExpFileName [ODS_MAX_FILE_NAME_LENGTH];
   struct FAB  SearchFab;
   struct NAM  SearchNam;
#ifdef ODS_EXTENDED
   struct NAML  SearchNaml;
#endif /* ODS_EXTENDED */

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "SearchFileSpec() |%s|\n", FileSpec);

   FileCount = 0;

   /* initialize the file access block */
   SearchFab = cc$rms_fab;

#ifdef ODS_EXTENDED
   if (OdsExtended)
   {
      SearchFab.fab$l_dna = SearchFab.fab$l_fna = -1;
      SearchFab.fab$b_dns = SearchFab.fab$b_fns = 0;
      SearchFab.fab$l_nam = &SearchNaml;

      ENAMEL_RMS_NAML(SearchNaml)
      SearchNaml.naml$l_long_defname = "*.SHTML;0";
      SearchNaml.naml$l_long_defname_size = 8;
      SearchNaml.naml$l_long_filename = FileSpec;
      SearchNaml.naml$l_long_filename_size = strlen(FileSpec);
      SearchNaml.naml$l_long_expand = ExpFileName;
      SearchNaml.naml$l_long_expand_alloc = sizeof(ExpFileName)-1;
      SearchNaml.naml$l_long_result = FileName;
      SearchNaml.naml$l_long_result_alloc = sizeof(FileName)-1;
   }
   else
#endif /* ODS_EXTENDED */
   {
      SearchFab.fab$l_dna = "*.SHTML;0";
      SearchFab.fab$b_dns = 8;
      SearchFab.fab$l_fna = FileSpec;
      SearchFab.fab$b_fns = strlen(FileSpec);
      SearchFab.fab$l_nam = &SearchNam;

      SearchNam = cc$rms_nam;
      SearchNam.nam$l_esa = ExpFileName;
      SearchNam.nam$b_ess = ODS2_MAX_FILE_NAME_LENGTH;
      SearchNam.nam$l_rsa = FileName;
      SearchNam.nam$b_rss = ODS2_MAX_FILE_NAME_LENGTH;
   }

   if (VMSnok (status = sys$parse (&SearchFab, 0, 0)))
      exit (status);

   while (VMSok (status = sys$search (&SearchFab, 0, 0)))
   {
#ifdef ODS_EXTENDED
      if (OdsExtended)
         *SearchNaml.naml$l_long_ver = '\0';
      else
#endif /* ODS_EXTENDED */
         *SearchNam.nam$l_ver = '\0';
      if (Debug) fprintf (stdout, "FileName |%s|\n", FileName);

      if (DoVerbose)
         fprintf (stdout, "%%%s-I-%sSCRUNCHING, %s\n",
                  Utility, DoScrunch ? "" : "UN", FileName);

      if (DoScrunch)
         ScrunchFile (FileName);
      else
         UnScrunchFile (FileName);

      FileCount++;
#ifdef ODS_EXTENDED
      if (OdsExtended)
         *SearchNaml.naml$l_long_ver = ';';
      else
#endif /* ODS_EXTENDED */
         *SearchNam.nam$l_ver = ';';
   }

   if (VMSnok (status) && status != RMS$_NMF) exit (status);

   if (DoVerbose)
      if (FileCount)
         fprintf (stdout, "%%%s-I-%sSCRUNCHED, %d files\n",
               Utility, DoScrunch ? "" : "UN", FileCount);
      else
         fprintf (stdout, "%%%s-I-%sSCRUNCHED, no files\n",
               Utility, DoScrunch ? "" : "UN");
}

/*****************************************************************************/
/*
*/

ScrunchFile (char *FileName)

{
   register char  *cptr, *sptr;

   int  status,
        TextLength;
   char  *TextPtr;
   FILE  *OutFilePtr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ScrunchFile() |%s|\n", FileName);

   status = ReadFileIntoMemory (FileName, &TextPtr, &TextLength, "ctx=rec");
   if (Debug) fprintf (stdout, "%%X%08.08X\n", status);
   if (VMSnok (status))
   {
      fprintf (stdout, "%%%s-E-READING, %s\n",
               Utility, FileName, SysGetMsg(status));
      return;
   }

   if (strsame (TextPtr, "<!--#SCRUNCH", 12))
   {
      fprintf (stdout, "%%%s-E-ALREADY, %s has <!--#scrunch -->\n",
               Utility, FileName);
      free (TextPtr);
      return;
   }

   OutFilePtr = fopen (FileName, "w",
                       "rfm=var", "ctx=bin", "rat=cr", "shr=nil");
   if (OutFilePtr == NULL)
   {
      free (TextPtr);
      return;
   }

   fprintf (OutFilePtr, "<!--#%s -->\n", SoftwareID);
   fflush (OutFilePtr);

   cptr = sptr = TextPtr;
   while (*cptr)
   {
      /* scan looking for the opening "<!--#" of an SSI directive */
      while (*cptr && *cptr != '<' && *(unsigned long*)cptr != '<!--') cptr++;
      if (!*cptr) break;
      if (*(unsigned long*)(cptr+1) != '!--#')
      {
         cptr++;
         continue;
      }

      /* write any non-SSI content up until this SSI directive */
      if (cptr > sptr)
      {
         if (Debug) fprintf (stdout, "|%*.*s|\n", cptr-sptr, cptr-sptr, sptr);
         if (!fwrite (sptr, cptr-sptr, 1, OutFilePtr))
         {
            status = vaxc$errno;
            fprintf (stdout, "%%%s-E-WRITING, %s\n",
                     Utility, FileName, SysGetMsg(status));
            fclose (OutFilePtr);
            free (TextPtr);
            return;
         }
      }

      /* scan looking for the closing " -->" of the preceding SSI directive */
      sptr = cptr;
      cptr += 5;
      while (*cptr && !(isspace(cptr[0]) && cptr[1] == '-' &&
                        cptr[2] == '-' && cptr[3] == '>')) cptr++;
      if (!*cptr) break;
      cptr += 4;
      if (Debug) fprintf (stdout, "|%*.*s|\n", cptr-sptr, cptr-sptr, sptr);
      if (!fwrite (sptr, cptr-sptr, 1, OutFilePtr))
      {
         status = vaxc$errno;
         fprintf (stdout, "%%%s-E-WRITING, %s\n",
                  Utility, FileName, SysGetMsg(status));
         fclose (OutFilePtr);
         free (TextPtr);
         return;
      }

      /* start again from the end of the last directive */
      sptr = cptr;
   }

   if (cptr > sptr)
   {
      if (Debug) fprintf (stdout, "|%*.*s|\n", cptr-sptr, cptr-sptr, sptr);
      if (!fwrite (sptr, cptr-sptr, 1, OutFilePtr))
      {
         status = vaxc$errno;
         fprintf (stdout, "%%%s-E-WRITING, %s\n",
                  Utility, FileName, SysGetMsg(status));
         fclose (OutFilePtr);
         free (TextPtr);
         return;
      }
   }

   free (TextPtr);
   fclose (OutFilePtr);
}

/*****************************************************************************/
/*
*/

UnScrunchFile (char *FileName)

{
   register char  *cptr;

   int  status,
        TextLength;
   char  *TextPtr;
   FILE  *OutFilePtr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "UnScrunchFile() |%s|\n", FileName);

   status = ReadFileIntoMemory (FileName, &TextPtr, &TextLength, "ctx=bin");
   if (Debug) fprintf (stdout, "%%X%08.08X\n", status);
   if (VMSnok (status)) 
   {
      fprintf (stdout, "%%%s-E-READING, %s\n",
               Utility, FileName, SysGetMsg(status));
      return;
   }

   if (strsame (TextPtr, "<!--#SCRUNCH", 12))
   {
      cptr = TextPtr + 12;
      while (*cptr &&
             !(isspace(cptr[0]) && cptr[1] == '-' &&
               cptr[2] == '-' && cptr[3] == '>')) cptr++;
      if (*cptr) cptr += 4;
      while (*cptr && *cptr != '\n') cptr++;
      if (*cptr) cptr++;
      TextLength -= cptr - TextPtr;
      TextPtr = cptr;
   }
   else
   {
      fprintf (stdout, "%%%s-E-NOSCRUNCH, %s has no <!--#scrunch -->\n",
               Utility, FileName);
      free (TextPtr);
      return;
   }

   /* only need one newline at the end of this file */
   if (TextPtr[TextLength-1] == '\n') TextLength--;

   OutFilePtr = fopen (FileName, "w", "rfm=stmlf", "ctx=bin", "shr=nil");
   if (OutFilePtr == NULL) exit (status);

   if (!fwrite (TextPtr, TextLength, 1, OutFilePtr))
   {
      fprintf (stdout, "%%%s-E-WRITING, %s\n",
               Utility, FileName, SysGetMsg(status));
      fclose (OutFilePtr);
      free (TextPtr);
      return;
   }

   free (TextPtr);
   fclose (OutFilePtr);
}

/****************************************************************************/
/*
Read the file contents specified by 'FileName' into memory, set the pointer
at 'FileTextPtr' to the contents and the file size at 'FileSizePtr'.  Returns a
VMS status value that should be checked.
*/ 

int ReadFileIntoMemory
(
char *FileName,
char **FileTextPtr,
int *FileSizePtr,
char *FopenCtx
)
{
   int  status,
        Bytes,
        BytesRemaining,
        BufferCount,
        Length;
   char  *BufferPtr,
         *LinePtr;
   FILE  *FilePtr;
   stat_t  FstatBuffer;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ReadFileIntoMemory() |%s|\n", FileName);

   if (FileTextPtr != NULL) *FileTextPtr = NULL;
   if (FileSizePtr != NULL) *FileSizePtr = 0;

   if (FopenCtx == NULL || !FopenCtx[0]) FopenCtx = "ctx=rec";

   FilePtr = fopen (FileName, "r", FopenCtx, "shr=get");
   if (FilePtr == NULL)
   {
      status = vaxc$errno;
      if (Debug) fprintf (stdout, "fopen() %%X%08.08X\n", status);
      return (status);
   }

   if (fstat (fileno(FilePtr), &FstatBuffer) < 0)
   {
      status = vaxc$errno;
      if (Debug) fprintf (stdout, "fstat() %%X%08.08X\n", status);
      fclose (FilePtr);
      return (status);
   }

   Bytes = FstatBuffer.st_size;
   if (Debug) fprintf (stdout, "%d bytes\n", Bytes);
   /* a little margin for error ;^) */
   Bytes += 32;

   BufferPtr = calloc (Bytes, 1);
   if (BufferPtr == NULL) exit (vaxc$errno);
   BytesRemaining = Bytes;
   LinePtr = BufferPtr;

   BufferCount = 0;
   while (fgets (LinePtr, BytesRemaining, FilePtr) != NULL)
   {
      /** if (Debug) fprintf (stdout, "|%s|\n", LinePtr); **/
      Length = strlen(LinePtr);
      LinePtr += Length;
      BufferCount += Length;
      BytesRemaining -= Length;
   }
   fclose (FilePtr);

   if (Debug) fprintf (stdout, "%d |%s|\n", BufferCount, BufferPtr);

   if (FileTextPtr != NULL) *FileTextPtr = BufferPtr;
   if (FileSizePtr != NULL) *FileSizePtr = BufferCount;

   return (SS$_NORMAL);
}

/*****************************************************************************/
/*
Get "command-line" parameters, whether from the command-line or from a
configuration symbol or logical containing the equivalent.
*/

GetParameters ()

{
   static char  CommandLine [256];
   static unsigned long  Flags = 0;

   register char  *aptr, *cptr, *clptr, *sptr;

   int  status;
   unsigned short  Length;
   char  ch;
   $DESCRIPTOR (CommandLineDsc, CommandLine);

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "GetParameters()\n");

   if ((clptr = getenv ("SCRUNCH$PARAM")) == NULL)
   {
      /* get the entire command line following the verb */
      if (VMSnok (status =
          lib$get_foreign (&CommandLineDsc, 0, &Length, &Flags)))
         exit (status);
      (clptr = CommandLine)[Length] = '\0';
   }

   aptr = NULL;
   ch = *clptr;
   for (;;)
   {
      if (aptr != NULL && *aptr == '/') *aptr = '\0';
      if (!ch) break;

      *clptr = ch;
      if (Debug) fprintf (stdout, "clptr |%s|\n", clptr);
      while (*clptr && isspace(*clptr)) *clptr++ = '\0';
      aptr = clptr;
      if (*clptr == '/') clptr++;
      while (*clptr && !isspace (*clptr) && *clptr != '/')
      {
         if (*clptr != '\"')
         {
            clptr++;
            continue;
         }
         cptr = clptr;
         clptr++;
         while (*clptr)
         {
            if (*clptr == '\"')
               if (*(clptr+1) == '\"')
                  clptr++;
               else
                  break;
            *cptr++ = *clptr++;
         }
         *cptr = '\0';
         if (*clptr) clptr++;
      }
      ch = *clptr;
      if (*clptr) *clptr = '\0';
      if (Debug) fprintf (stdout, "aptr |%s|\n", aptr);
      if (!*aptr) continue;

      if (strsame (aptr, "/DBUG", -1))
      {
         Debug = true;
         continue;
      }
      if (strsame (aptr, "/ODS5", 5))
      {
         OdsExtended = true;
         continue;
      }
      if (strsame (aptr, "/NOODS5", 7))
      {
         OdsExtended = false;
         continue;
      }
      if (strsame (aptr, "/SCRUNCH", 4))
      {
         DoScrunch = true;
         DoUnScrunch = false;
         continue;
      }
      if (strsame (aptr, "/UNSCRUNCH", 4))
      {
         DoScrunch = false;
         DoUnScrunch = true;
         continue;
      }
      if (strsame (aptr, "/VERBOSE", 4))
      {
         DoVerbose = true;
         continue;
      }

      if (*aptr == '/')
      {
         fprintf (stdout, "%%%s-E-IVQUAL, unrecognized qualifier\n \\%s\\\n",
                  Utility, aptr+1);
         exit (STS$K_ERROR | STS$M_INHIB_MSG);
      }

      if (!FileSpec[0])
      {
         sptr = FileSpec;
         for (cptr = aptr; *cptr; *sptr++ = toupper(*cptr++));
         *sptr = '\0';
         continue;
      }

      fprintf (stdout, "%%%s-E-MAXPARM, too many parameters\n \\%s\\\n",
               Utility, aptr);
      exit (STS$K_ERROR | STS$M_INHIB_MSG);
   }
}

/*****************************************************************************/
/*
*/
 
char* SysGetMsg (int StatusValue)
 
{
   static char  Message [256];
   static $DESCRIPTOR (MessageDsc, Message);

   short int  Length;
 
   sys$getmsg (StatusValue, &Length, &MessageDsc, 0, 0);
   Message[Length] = '\0';
   if (Debug) fprintf (stdout, "SysGetMsg() |%s|\n", Message);
   return (Message);
}
 
/****************************************************************************/
/*
Return an integer reflecting the major and minor version of VMS (e.g. 60, 61,
62, 70, 71, 72, etc.)
*/ 

#ifdef ODS_EXTENDED

int GetVmsVersion ()

{
   static char  SyiVersion [16];

   static struct {
      short int  buf_len;
      short int  item;
      unsigned char   *buf_addr;
      unsigned short  *ret_len;
   }
   SyiItems [] =
   {
      { 8, SYI$_VERSION, &SyiVersion, 0 },
      { 0,0,0,0 }
   };

   int  status,
        version;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "GetVmsVersion()\n");

   if (VMSnok (status = sys$getsyiw (0, 0, 0, &SyiItems, 0, 0, 0)))
      exit (status);
   SyiVersion[8] = '\0';
   version = ((SyiVersion[1]-48) * 10) + (SyiVersion[3]-48);
   if (Debug) fprintf (stdout, "|%s| %d\n", SyiVersion, version);
   return (version);
}

#endif /* ODS_EXTENDED */

/****************************************************************************/
/*
Does a case-insensitive, character-by-character string compare and returns 
true if two strings are the same, or false if not.  If a maximum number of 
characters are specified only those will be compared, if the entire strings 
should be compared then specify the number of characters as 0.
*/ 

boolean strsame
(
register char *sptr1,
register char *sptr2,
register int  count
)
{
   while (*sptr1 && *sptr2)
   {
      if (toupper (*sptr1++) != toupper (*sptr2++)) return (false);
      if (count)
         if (!--count) return (true);
   }
   if (*sptr1 || *sptr2)
      return (false);
   else
      return (true);
}

/*****************************************************************************/

*                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  