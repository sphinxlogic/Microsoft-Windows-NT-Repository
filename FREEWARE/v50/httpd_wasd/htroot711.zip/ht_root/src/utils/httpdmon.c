/*****************************************************************************/
/*
                                HTTPdMon.c

This utility displays information about a WASD HTTPd server.  The information 
is derived from JPI data about the process, and interpreted from four logicals
defined and refreshed by the HTTPd server. 

   HTTPDnn$COUNT1     and
   HTTPDnn$COUNT2     (binary) server accumulators for various events, etc. 
   HTTPDnn$COUNT3     (binary) proxy server accumulators and information
   HTTPDnn$PID        (binary) process ID of the HTTPd server
   HTTPDnn$REQUEST    summary of the most recently completed request

The /ALERT and /ALERT=ALL parameters ring the bell every time a new request is
reported (the connect count increases).  The /ALERT=HOST rings the bell
every time the host name in the request changes.  The /LOOKUP qualifier
(default) attempts to resolve a dotted-decimal host address in the request (if
the server's [DNSlookup] configuration directive is disabled).  This operation
can introduce some latency as name resolution occurs.  A trailing "#" indicates
this is an address that has been resolved this way.  If it cannot be resolved a
"?" is appended to the numeric address.

The "Servers:" field keeps track of multiple servers on a node or cluster. 
When there is a change in the number the previous value is displayed in
parentheses after the current and the terminal bell is rung (this can be
suppressed with "/ALERT=NOSERVERS").  Of course servers coming and going are
only detected if it happens at a frequency greater than the current display
interval.


QUALIFIERS
----------
/ALERT[=ALL|HOST|[NO]SERVERS]   ring bell for all accesses or
                                just a change in host and/or
                                suppress bell if server count changes
/ALL=string             set the server-group name (up to 8 characters)
/DBUG                   turns on all "if (Debug)" statements
/[NO]GENERAL            display general HTTP serving information
/HELP                   display brief usage information
/INTERVAL=              number of seconds between display refresh
/[NO]LOOKUP             resolve dotted-decimal host addresses to names
/PORT=                  the IP port number of the server to monitor
/[NO]PROCESS            display HTTPd process information
/[NO]PROXY              display proxy serving information
/[NO]REQUEST            display request information
/REFRESH=               synonym for /INTERVAL


BUILD DETAILS
-------------
See BUILD_HTTPDMON.COM


VERSION HISTORY (update SoftwareID as well!)
---------------
15-OCT-2000  MGD  v1.13.0, HTTPd v7.1, DLM server-group "aware", /ALL=,
                           no current process count if $creprc() detached
20-MAY-2000  MGD  v1.12.0, HTTPd v7.0, (no real changes)
30-OCT-1999  MGD  v1.11.0, HTTPd v6.1,
                           remove NETLIB support
20-JUN-1999  MGD  v1.10.0, add proxy percentage based on counts,
                           allow for disks >9GB in space calculations
25-JAN-1999  MGD  v1.9.0, HTTPd v6.0, proxy serving
27-OCT-1998  MGD  v1.8.0, HTTPd v5.3, (no real changes)
27-AUG-1998  MGD  v1.7.0, HTTPd v5.2, (no real changes)
21-JUN-1998  MGD  v1.6.0, HTTPd v5.1, alert, and lookup host address to name
14-FEB-1998  MGD  v1.5.0, HTTPd v5.0, DECnet, SSL and minor changes
15-OCT-1997  MGD  v1.4.0, HTTPd v4.5, cache
21-AUG-1997  MGD  v1.3.0, HTTPd v4.4, accounting structure > 255 bytes, duration
23-JUL-1997  MGD  v1.2.1, HTTPd v4.3, (no real changes)
14-JUN-1997  MGD  v1.2.0, HTTPd v4.2, CGIplus,
                          bugfix; arithmetic trap on AXP systems
01-FEB-1997  MGD  v1.1.0, HTTPd v4.0, (no real changes)
01-DEC-1995  MGD  v1.0.0, HTTPd v3.0, initial development
*/
/*****************************************************************************/

#ifdef __ALPHA
   char SoftwareID [] = "HTTPDMON v1.13.0 AXP";
#else
   char SoftwareID [] = "HTTPDMON v1.13.0 VAX";
#endif

char  ForHTTPdVersion [] = "(HTTPd v7.1)";

/* standard C header files */
#include <stdio.h>
#include <ctype.h>

/* VMS related header files */
#include <ssdef.h>
#include <stsdef.h>
#include <descrip.h>
#include <dvidef.h>
#include <iodef.h>
#include <jpidef.h>
#include <lckdef.h>
#include <libclidef.h>
#include <libdtdef.h>
#include <lkidef.h>
#include <lnmdef.h>
#include <psldef.h>
#include <prvdef.h>

/* this header file contains the accounting structure definition */
#include "../httpd/wasd.h"
#include "../httpd/proxystruct.h"

/* Internet-related header files */

/*
#define IP_NONE 1 
*/

#include <socket.h>
#include <in.h>
#include <netdb.h>
#include <inet.h>

#define boolean int
#define true 1
#define false 0
 
#define FI_LI  __FILE__, __LINE__

/* drag these over from proxymaint.h */
#define PROXY_MAINT_DEVICE_MBYTES(Blocks) (Blocks >> 11)
#define PROXY_MAINT_DEVICE_MBYTES(Blocks) (Blocks >> 11)
#define PROXY_MAINT_DEVICE_PERCENT_FREE(Total,Free) \
        ((int)((float)Free*100.0/(float)Total))
#define PROXY_MAINT_DEVICE_PERCENT_USED(Total,Free) \
        (100-(int)((float)Free*100.0/(float)Total))

/* so that we can just transplant ProxyMaintDeviceStats() */
#define ErrorExitVmsStatus(status,string,fili) (exit(status))

#define VMSok(x) ((x) & STS$M_SUCCESS)
#define VMSnok(x) !(((x) & STS$M_SUCCESS))

#define DEFAULT_INTERVAL_SECONDS 2

#define DEFAULT_SERVER_GROUP_RESNAME "WASD_MATTHEW_J_2000-06-17"

char  ErrorProxyMaintTooManyDevices [] = "Volume set has too many members.",
      Utility [] = "HTTPDMON";

#define ControlZ '\x1a'

boolean  ControlY,
         Debug,
         DoAlertAll,
         DoAlertHost,
         DoAlertServers = true,
         DoGeneralInfo,
         DoNoGeneralInfo,
         DoLookupHost,
         DoProcessInfo,
         DoNoProcessInfo,
         DoProxyInfo,
         DoNoProxyInfo,
         DoRequestInfo,
         DoNoRequestInfo,
         DoShowHelp;

int  CurrentProcessCount,
     IntervalSeconds = DEFAULT_INTERVAL_SECONDS,
     PrevConnectCount,
     ServerPort = 80;

char  CommandLine [256],
      PrevHostName [256],
      ServerGroupResName [64] = DEFAULT_SERVER_GROUP_RESNAME,
      ServerProcessName [16],
      Screen [8192];

char  *ScrPtr;

struct AccountingStruct  Accounting;
struct ProxyAccountingStruct  ProxyAccounting;

/* ANSI terminal control sequences */
char ANSIcls [] = "\x1b[0;0H\x1b[J",
     ANSIhome [] = "\x1b[0;0H",
     ANSIceol [] = "\x1b[K",
     ANSIceos [] = "\x1b[J",
     ANSInormal [] = "\x1b[0m",
     ANSIbold [] = "\x1b[1m",
     ANSIblink [] = "\x1b[5m",
     ANSIreverse [] = "\x1b[7m";

/* required prototypes */
ControlY_AST ();
char *LookupHostName (char*);
char* TimeString (); 
char* ServerCount (); 
 
/*****************************************************************************/
/*
*/

int main ()

{
   int  status,
        MonitorStatus;

   /*********/
   /* begin */
   /*********/

#ifndef IP_NONE
   DoLookupHost = true;
#endif

   GetParameters ();

   if (Debug)
      ANSIcls [0] = ANSIhome [0] = ANSIceol [0] = ANSIceos [0] = '\0';

   if (!DoGeneralInfo  && !DoProcessInfo && !DoRequestInfo && !DoProxyInfo)
   {
      if (!DoNoProcessInfo) DoProcessInfo = true;
      if (!DoNoGeneralInfo) DoGeneralInfo = true;
      if (!DoNoRequestInfo) DoRequestInfo = true;
   }

   if (DoProxyInfo)
   {
      if (!DoNoProcessInfo) DoProcessInfo = true;
      if (!DoGeneralInfo) DoGeneralInfo = false;
      if (!DoNoRequestInfo) DoRequestInfo = true;
   }

   if (DoShowHelp) exit (ShowHelp ());

#ifdef IP_NONE
   if (DoLookupHost)
   {
      fprintf (stdout, "%%%s-E-RESOLVE, host resolution not compiled in!\n",
               Utility);
      exit (STS$K_ERROR | STS$M_INHIB_MSG);
   }
#endif

   if (VMSnok (status = OnControlY (&ControlY_AST)))
      exit (status);

   MonitorStatus = MonitorHttpd ();

   if (VMSnok (status = OnControlY (0)))
      exit (status);

   exit (MonitorStatus);
}

/*****************************************************************************/
/*
Get "command-line" parameters, whether from the command-line or from a
configuration logical containing the equivalent.
*/

GetParameters ()

{
   static char  CommandLine [256];
   static unsigned long  Flags = 0;

   register char  *aptr, *cptr, *clptr, *sptr;

   int  status;
   unsigned short  Length;
   char  ch;
   $DESCRIPTOR (CommandLineDsc, CommandLine);

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "GetParameters()\n");

   if ((clptr = getenv ("HTTPDMON$PARAM")) == NULL)
   {
      /* get the entire command line following the verb */
      if (VMSnok (status =
          lib$get_foreign (&CommandLineDsc, 0, &Length, &Flags)))
         exit (status);
      (clptr = CommandLine)[Length] = '\0';
   }

   aptr = NULL;
   ch = *clptr;
   for (;;)
   {
      if (aptr != NULL && *aptr == '/') *aptr = '\0';
      if (!ch) break;

      *clptr = ch;
      if (Debug) fprintf (stdout, "clptr |%s|\n", clptr);
      while (*clptr && isspace(*clptr)) *clptr++ = '\0';
      aptr = clptr;
      if (*clptr == '/') clptr++;
      while (*clptr && !isspace (*clptr) && *clptr != '/')
      {
         if (*clptr != '\"')
         {
            clptr++;
            continue;
         }
         cptr = clptr;
         clptr++;
         while (*clptr)
         {
            if (*clptr == '\"')
               if (*(clptr+1) == '\"')
                  clptr++;
               else
                  break;
            *cptr++ = *clptr++;
         }
         *cptr = '\0';
         if (*clptr) clptr++;
      }
      ch = *clptr;
      if (*clptr) *clptr = '\0';
      if (Debug) fprintf (stdout, "aptr |%s|\n", aptr);
      if (!*aptr) continue;

      if (strsame (aptr, "/ALERT=", 4))
      {
         sptr = aptr;
         while (*aptr && *aptr != '=') aptr++;
         if (*aptr) aptr++;
         while (*aptr)
         {
            if (!*aptr || strsame (aptr, "ALL", 3))
            {
               DoAlertAll = true;
               DoAlertHost = false;
            }
            else
            if (strsame (aptr, "HOST", 4))
            {
               DoAlertAll = false;
               DoAlertHost = true;
            }
            else
            if (strsame (aptr, "NOSERVERS", 9))
               DoAlertServers = false;
            else
            if (strsame (aptr, "SERVERS", 7))
               DoAlertServers = true;
            else
            {
               fprintf (stdout, "%%%s-E-INVPARM, invalid parameter\n \\%s\\\n",
                        Utility, sptr);
               exit (STS$K_ERROR | STS$M_INHIB_MSG);
            }
            while (*aptr && *aptr != ',') aptr++;
            if (*aptr) aptr++;
         }
         continue;
      }
      if (strsame (aptr, "/ALL=", 4))
      {
         /* force server-group name to begin with a set string */
         sptr = aptr;
         while (*aptr && *aptr != '=') aptr++;
         if (*aptr) aptr++;
         if (!*aptr)
         {
            fprintf (stdout, "%%%s-E-INVPARM, invalid parameter\n \\%s\\\n",
                     Utility, sptr);
            exit (STS$K_ERROR | STS$M_INHIB_MSG);
         }
         /* ensure no longer than 24 characters (+7 == lock resname limit) */
         strncpy (ServerGroupResName+16, aptr, 8);
         ServerGroupResName[24] = '\0';
         continue;
      }
      if (strsame (aptr, "/DBUG", -1))
      {
         Debug = true;
         continue;
      }
      if (strsame (aptr, "/GENERAL", 4))
      {
         DoGeneralInfo = true;
         DoNoGeneralInfo = false;
         continue;
      }
      if (strsame (aptr, "/NOGENERAL", 6))
      {
         DoGeneralInfo = false;
         DoNoGeneralInfo = true;
         continue;
      }
      if (strsame (aptr, "/HELP", 4))
      {
         DoShowHelp = true;
         continue;
      }
      if (strsame (aptr, "/INTERVAL=", 4) ||
          strsame (aptr, "/REFRESH=", 4))
      {
         sptr = aptr;
         while (*aptr && *aptr != '=') aptr++;
         if (*aptr) aptr++;
         if (!isdigit(*aptr))
         {
            fprintf (stdout, "%%%s-E-INVPARM, invalid parameter\n \\%s\\\n",
                     Utility, sptr);
            exit (STS$K_ERROR | STS$M_INHIB_MSG);
         }
         IntervalSeconds = atoi(aptr);
         continue;
      }
      if (strsame (aptr, "/LOOKUP", 4))
      {
         DoLookupHost = true;
         continue;
      }
      if (strsame (aptr, "/NOLOOKUP", 6))
      {
         DoLookupHost = false;
         continue;
      }
      if (strsame (aptr, "/PORT=", 4))
      {
         sptr = aptr;
         while (*aptr && *aptr != '=') aptr++;
         if (*aptr) aptr++;
         if (!isdigit(*aptr))
         {
            fprintf (stdout, "%%%s-E-INVPARM, invalid parameter\n \\%s\\\n",
                     Utility, sptr);
            exit (STS$K_ERROR | STS$M_INHIB_MSG);
         }
         ServerPort = atoi(aptr);
         continue;
      }
      if (strsame (aptr, "/PROCESS", 5))
      {
         DoProcessInfo = true;
         DoNoProcessInfo = false;
         continue;
      }
      if (strsame (aptr, "/NOPROCESS", 7))
      {
         DoProcessInfo = false;
         DoNoProcessInfo = true;
         continue;
      }
      if (strsame (aptr, "/PROXY", 5))
      {
         DoProxyInfo = true;
         DoNoProxyInfo = false;
         continue;
      }
      if (strsame (aptr, "/NOPROXY", 7))
      {
         DoProxyInfo = false;
         DoNoProxyInfo = true;
         continue;
      }
      if (strsame (aptr, "/REQUEST", 4))
      {
         DoRequestInfo = true;
         DoNoRequestInfo = false;
         continue;
      }
      if (strsame (aptr, "/NOREQUEST", 6))
      {
         DoRequestInfo = false;
         DoNoRequestInfo = true;
         continue;
      }

      if (*aptr != '/')
      {
         fprintf (stdout, "%%%s-E-MAXPARM, too many parameters\n \\%s\\\n",
                  Utility, aptr);
         exit (STS$K_ERROR | STS$M_INHIB_MSG);
      }
      else
      {
         fprintf (stdout, "%%%s-E-IVQUAL, unrecognized qualifier\n \\%s\\\n",
                  Utility, aptr+1);
         exit (STS$K_ERROR | STS$M_INHIB_MSG);
      }
   }
}

/*****************************************************************************/
/*
Assign a channel to the terminal device.  Create a buffered screenful of 
information about the HTTPd server and output it in one IO.
*/

int MonitorHttpd ()

{
   int  status,
        PortLength;
   unsigned short  TTChannel;
   char  ReadBuffer;
   char  Line [128],
         Port [16];
   char  *TimeStringPtr;
   
   $DESCRIPTOR (TTDsc, "TT:");
   struct {
      unsigned short  Status;
      unsigned short  Offset;
      unsigned short  Terminator;
      unsigned short  TerminatorSize;
   } IOsb;

   /*********/
   /* begin */
   /*********/

   if (VMSnok (status = sys$assign (&TTDsc, &TTChannel, 0, 0, 0)))
      return (status);

   if (VMSnok (status =
       sys$qiow (0, TTChannel, IO$_WRITELBLK, 0, 0, 0,
                 ANSIcls, sizeof(ANSIcls)-1, 0, 0, 0, 0)))
      return (status);

   sprintf (ServerProcessName, "HTTPd:%d", ServerPort);
   PortLength = sprintf (Port, " Port: %d", ServerPort);

   for (;;)
   {
      if (ControlY) break;

      TimeStringPtr = TimeString ();

      ScrPtr = Screen;
      ScrPtr += sprintf (ScrPtr,
         "%s%s%s%s%*s %s %s %*s%s%s%s%s\r\n",
         ANSIhome,
         ANSIbold, Port, ANSInormal,
         (80 - PortLength - sizeof(SoftwareID)-1 -
               sizeof(ForHTTPdVersion)-1 - strlen(TimeStringPtr)) / 2, "",
         SoftwareID, ForHTTPdVersion,
         (80 - PortLength - sizeof(SoftwareID)-1 -
               sizeof(ForHTTPdVersion)-1 - strlen(TimeStringPtr)) / 2, "",
         ANSIbold, TimeStringPtr, ANSInormal,
         ANSIceol);

      /* we need the startup count and last exit status from count date */
      if (VMSnok (status = GetAccounting ()))
         return (status);

      if (DoProcessInfo)
         if (VMSnok (status = AddProcessInfo ()))
            return (status);

      if (DoGeneralInfo)
         if (VMSnok (status = AddGeneralInfo ()))
            return (status);

      if (DoProxyInfo)
         if (VMSnok (status = AddProxyInfo ()))
            return (status);

      if (DoRequestInfo)
         if (VMSnok (status = AddRequest ()))
            return (status);

      strcpy (ScrPtr, ANSIceos);
      ScrPtr += sizeof(ANSIceos)-1;

      if (VMSnok (status =
          sys$qiow (0, TTChannel, IO$_WRITELBLK, 0, 0, 0,
                    Screen, ScrPtr-Screen, 0, 0, 0, 0)))
         return (status);

      status = sys$qiow (0, TTChannel, IO$_READLBLK | IO$M_TIMED,
                         &IOsb, 0, 0,
                         &ReadBuffer, 1, IntervalSeconds, 0, 0, 0);

      if (status == SS$_TIMEOUT) continue;
      if (VMSnok (status)) return (status);
      if (IOsb.Terminator == ControlZ) return (SS$_NORMAL);
   }

   if (VMSnok (status =
       sys$qiow (0, TTChannel, IO$_WRITELBLK, 0, 0, 0,
                 Screen, ScrPtr-Screen, 0, 0, 0, 0)))
      return (status);

   return (status);
}

/*****************************************************************************/
/*
Add the HTTPd server process information to the screen buffer using the 
process ID from the PID logical and a a sys$getjpi() call.  The PID logical 
contains binary data in the form of a longword process ID.
*/ 

int AddProcessInfo ()

{
   static char  JpiPrcNam [16],
                JpiUserName [13],
                LogicalName [32],
                UpTime [32];
   static unsigned long  JpiAstCnt,
                         JpiAstLm,
                         JpiBioCnt,
                         JpiBytLm,
                         JpiBytCnt,
                         JpiBioLm,
                         JpiCpuTime,
                         JpiDioCnt,
                         JpiDioLm,
                         JpiEnqCnt,
                         JpiEnqLm,
                         JpiFilCnt,
                         JpiFilLm,
                         JpiPageFlts,
                         JpiPagFilCnt,
                         JpiPgFlQuota,
                         JpiPid,
                         JpiPrcCnt,
                         JpiPrcLm,
                         JpiTqCnt,
                         JpiTqLm,
                         JpiVirtPeak,
                         JpiWsSize,
                         JpiWsPeak,
                         PageFileUsedPercent,
                         Pid;
   static unsigned long  ConnectTime [2],
                         CurrentTime [2],
                         JpiLoginTime [2];
   static char  LastExitStatus [48] = "";
   static $DESCRIPTOR (LnmSystemDsc, "LNM$SYSTEM");
   static $DESCRIPTOR (LogicalNameDsc, LogicalName);
   static $DESCRIPTOR (UpTimeFaoDsc, "!%D");
   static $DESCRIPTOR (UpTimeDsc, UpTime);
   static struct
   {
      unsigned short  buf_len;
      unsigned short  item;
      unsigned char   *buf_addr;
      unsigned short  *ret_len;
   }
      JpiItems [] =
   {
      { sizeof(JpiAstCnt), JPI$_ASTCNT, &JpiAstCnt, 0 },
      { sizeof(JpiAstLm), JPI$_ASTLM, &JpiAstLm, 0 },
      { sizeof(JpiBioCnt), JPI$_BIOCNT, &JpiBioCnt, 0 },
      { sizeof(JpiBioLm), JPI$_BIOLM, &JpiBioLm, 0 },
      { sizeof(JpiBytCnt), JPI$_BYTCNT, &JpiBytCnt, 0 },
      { sizeof(JpiBytLm), JPI$_BYTLM, &JpiBytLm, 0 },
      { sizeof(JpiCpuTime), JPI$_CPUTIM, &JpiCpuTime, 0 },
      { sizeof(JpiDioCnt), JPI$_DIOCNT, &JpiDioCnt, 0 },
      { sizeof(JpiDioLm), JPI$_DIOLM, &JpiDioLm, 0 },
      { sizeof(JpiEnqCnt), JPI$_ENQCNT, &JpiEnqCnt, 0 },
      { sizeof(JpiEnqLm), JPI$_ENQLM, &JpiEnqLm, 0 },
      { sizeof(JpiFilCnt), JPI$_FILCNT, &JpiFilCnt, 0 },
      { sizeof(JpiFilLm), JPI$_FILLM, &JpiFilLm, 0 },
      { sizeof(JpiLoginTime), JPI$_LOGINTIM, &JpiLoginTime, 0 },
      { sizeof(JpiPageFlts), JPI$_PAGEFLTS, &JpiPageFlts, 0 },
      { sizeof(JpiPagFilCnt), JPI$_PAGFILCNT, &JpiPagFilCnt, 0 },
      { sizeof(JpiPgFlQuota), JPI$_PGFLQUOTA, &JpiPgFlQuota, 0 },
      { sizeof(JpiPid), JPI$_PID, &JpiPid, 0 },
      { sizeof(JpiPrcCnt), JPI$_PRCCNT, &JpiPrcCnt, 0 },
      { sizeof(JpiPrcLm), JPI$_PRCLM, &JpiPrcLm, 0 },
      { sizeof(JpiPrcNam), JPI$_PRCNAM, &JpiPrcNam, 0 },
      { sizeof(JpiTqCnt), JPI$_TQCNT, &JpiTqCnt, 0 },
      { sizeof(JpiTqLm), JPI$_TQLM, &JpiTqLm, 0 },
      { sizeof(JpiUserName), JPI$_USERNAME, &JpiUserName, 0 },
      { sizeof(JpiVirtPeak), JPI$_VIRTPEAK, &JpiVirtPeak, 0 },
      { sizeof(JpiWsSize), JPI$_WSSIZE, &JpiWsSize, 0 },
      { sizeof(JpiWsPeak), JPI$_WSPEAK, &JpiWsPeak, 0 },
      {0,0,0,0}
   },
      LnmItem [] =
   {
      { sizeof(Pid), LNM$_STRING, &Pid, 0 },
      {0,0,0,0}
   };

   register char  *cptr;

   int  status;
   unsigned short  Length;
   char  *StatePtr,
         *UpTimePtr;
   char  AstString [32],
         BioString [32],
         BytString [32],
         DioString [32],
         EnqString [32],
         FilString [32],
         PrcString [32],
         TqString [32];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AddProcessInfo()\n");

   if (!LogicalName[0])
      LogicalNameDsc.dsc$w_length =
         sprintf (LogicalName, "HTTPD%d$PID", ServerPort);

   Pid = 0;
   status = sys$trnlnm (0, &LnmSystemDsc, &LogicalNameDsc, 0, &LnmItem);
   if (Debug) fprintf (stdout, "sys$trnlnm() %%X%08.08X\n", status);
   if (VMSnok (status) && status != SS$_NOLOGNAM) return (status);
   if (Debug) fprintf (stdout, "Pid: %08.08X\n", Pid);

   if (Pid)
      status = sys$getjpiw (0, &Pid, 0, &JpiItems, 0, 0, 0);
   else
      status = SS$_NONEXPR;
   if (Debug) fprintf (stdout, "sys$getjpi() %%X%08.08X\n", status);
   if (VMSnok (status) || status == SS$_NONEXPR)
   {
      if (status == SS$_NONEXPR)
         StatePtr = " -NONEXPRC-";
      else
      if (status == SS$_SUSPENDED)
         StatePtr = " -MWAIT-";
      else
         return (status);

      /* we divide by this so it can't be zero, make it very small! */
      JpiPgFlQuota = 1;
   }
   else
      StatePtr = "";

   CurrentProcessCount = JpiPrcCnt;

   JpiUserName[12] = '\0';
   for (cptr = JpiUserName; *cptr && *cptr != ' '; cptr++);
   *cptr = '\0';
   if (Debug) fprintf (stdout, "JpiUserName |%s|\n", JpiUserName);

   JpiPrcNam[15] = '\0';
   for (cptr = JpiPrcNam; *cptr && *cptr != ' '; cptr++);
   *cptr = '\0';
   if (Debug) fprintf (stdout, "JpiPrcNam |%s|\n", JpiPrcNam);

   sys$gettim (&CurrentTime);
   lib$sub_times (&CurrentTime, &JpiLoginTime, &ConnectTime);
   sys$fao (&UpTimeFaoDsc, &Length, &UpTimeDsc, &ConnectTime);
   UpTime[Length] = '\0';
   for (UpTimePtr = UpTime; isspace(*UpTimePtr); UpTimePtr++);

   if (Accounting.LastExitStatus)
      sprintf (LastExitStatus, "  %sExit:%s %%X%08.08X",
               ANSIbold, ANSInormal, Accounting.LastExitStatus);

   sprintf (AstString, "%4d/%-4d", JpiAstCnt, JpiAstLm);
   sprintf (BioString, "%4d/%-4d", JpiBioCnt, JpiBioLm);
   sprintf (BytString, "%6d/%-6d", JpiBytCnt, JpiBytLm);
   sprintf (DioString, "%4d/%-4d", JpiDioCnt, JpiDioLm);
   sprintf (EnqString, "%4d/%-4d", JpiEnqCnt, JpiEnqLm);
   sprintf (FilString, "%4d/%-4d", JpiFilCnt, JpiFilLm);
   sprintf (PrcString, "%6d/%-6d", JpiPrcCnt, JpiPrcLm);
   sprintf (TqString, "%4d/%-4d", JpiTqCnt, JpiTqLm);

   if (status != SS$_SUSPENDED)
      if (JpiPagFilCnt)
         PageFileUsedPercent = 100 - ((JpiPagFilCnt * 100) / JpiPgFlQuota);
      else
         PageFileUsedPercent = 0;

   ScrPtr += sprintf (ScrPtr,
"%s\r\n\
 %sProcess:%s %s%s%s%s  %sPID:%s %08.08X  %sUser:%s %s  %sServers:%s %s\
%s\r\n\
      %sUp:%s %s  %sCPU:%s %d %02.02d:%02.02d:%02.02d.%02.02d\
  %sRestart:%s %d%s\
%s\r\n\
 %sPg.Flts:%s %d  %sPg.Used:%s %d%%  %sWsSize:%s %d  %sWsPeak:%s %d\
%s\r\n\
     %sAST:%s %9.9s  %sBIO:%s %9.9s  %sBYT:%s %13.13s  %sDIO:%s %9.9s\
%s\r\n\
     %sENQ:%s %9.9s  %sFIL:%s %9.9s  %sPRC:%s %13.13s   %sTQ:%s %9.9s\
%s\r\n",
      ANSIceol,
      ANSIbold, ANSInormal,
      JpiPrcNam,
      ANSIbold, StatePtr, ANSInormal,
      ANSIbold, ANSInormal,
      Pid,
      ANSIbold, ANSInormal,
      JpiUserName,
      ANSIbold, ANSInormal,
      ServerCount(),
      ANSIceol,
      ANSIbold, ANSInormal,
      UpTimePtr,
      ANSIbold, ANSInormal,
      JpiCpuTime / 8640000,                     /* CPU day */
      (JpiCpuTime % 8640000) / 360000,          /* CPU hour */
      (JpiCpuTime % 360000) / 6000,             /* CPU minute */
      (JpiCpuTime % 6000 ) / 100,               /* CPU second */
      JpiCpuTime % 100,                         /* CPU 10mS */
      ANSIbold, ANSInormal,
      Accounting.StartupCount,
      LastExitStatus,
      ANSIceol,
      ANSIbold, ANSInormal,
      JpiPageFlts,
      ANSIbold, ANSInormal,
      PageFileUsedPercent,
      ANSIbold, ANSInormal,
      JpiWsSize,
      ANSIbold, ANSInormal,
      JpiWsPeak,
      ANSIceol,
      ANSIbold, ANSInormal,
      AstString,
      ANSIbold, ANSInormal,
      BioString,
      ANSIbold, ANSInormal,
      BytString,
      ANSIbold, ANSInormal,
      DioString,
      ANSIceol,
      ANSIbold, ANSInormal,
      EnqString,
      ANSIbold, ANSInormal,
      FilString,
      ANSIbold, ANSInormal,
      PrcString,
      ANSIbold, ANSInormal,
      TqString,
      ANSIceol);

   return (SS$_NORMAL);
}

/*****************************************************************************/
/*
Get the HTTPd server counter information from its logical definition.
*/

int GetAccounting ()

{
   static unsigned short  Length;
   static char  LogicalName1 [32],
                LogicalName2 [32],
                LogicalName3 [32];
   static $DESCRIPTOR (LnmSystemDsc, "LNM$SYSTEM");
   static $DESCRIPTOR (LogicalName1Dsc, LogicalName1);
   static $DESCRIPTOR (LogicalName2Dsc, LogicalName2);
   static $DESCRIPTOR (LogicalName3Dsc, LogicalName3);

   static struct {
      short BufferLength;
      short ItemCode;
      void  *BufferPtr;
      void  *LengthPtr;
   }
     LnmItem1 [] =
   {
      { 255, LNM$_STRING, &Accounting, 0 },
      {0,0,0,0}
   },
     LnmItem2 [] =
   {
      { sizeof(Accounting)-255, LNM$_STRING, ((char*)&Accounting)+255, 0 },
      {0,0,0,0}
   },
     LnmItem3 [] =
   {
      { sizeof(ProxyAccounting), LNM$_STRING, &ProxyAccounting, 0 },
      {0,0,0,0}
   };

   int  status;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "GetAccounting()\n");

   if (!LogicalName1[0])
   {
      LogicalName1Dsc.dsc$w_length =
         sprintf (LogicalName1, "HTTPD%d$COUNT1", ServerPort);
      LogicalName2Dsc.dsc$w_length =
         sprintf (LogicalName2, "HTTPD%d$COUNT2", ServerPort);
      LogicalName3Dsc.dsc$w_length =
         sprintf (LogicalName3, "HTTPD%d$COUNT3", ServerPort);
      if (Debug)
         fprintf (stdout, "%s %s %s\n",
                  LogicalName1, LogicalName2, LogicalName3);
   }

   status = sys$trnlnm (0, &LnmSystemDsc, &LogicalName1Dsc, 0, &LnmItem1);
   if (Debug) fprintf (stdout, "sys$trnlnm() %%X%08.08X\n", status);
   if (VMSnok (status) && status != SS$_NOLOGNAM) return (status);

   status = sys$trnlnm (0, &LnmSystemDsc, &LogicalName2Dsc, 0, &LnmItem2);
   if (Debug) fprintf (stdout, "sys$trnlnm() %%X%08.08X\n", status);
   if (VMSnok (status) && status != SS$_NOLOGNAM) return (status);

   status = sys$trnlnm (0, &LnmSystemDsc, &LogicalName3Dsc, 0, &LnmItem3);
   if (Debug) fprintf (stdout, "sys$trnlnm() %%X%08.08X\n", status);
   if (VMSnok (status) && status != SS$_NOLOGNAM) return (status);

   return (SS$_NORMAL);
}

/*****************************************************************************/
/*
Add the HTTPd server counter information to the screen buffer from the count 
logical.  The information in this logical is binary data in the form of the 
HTTPd count data structure.  This is used to extract each field member from 
the data.
*/

int AddGeneralInfo ()

{
   int  status;
   char  BytesRawRx [32],
         BytesRawTx [32],
         CurrentProcessCountString [16];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AddGeneralInfo()\n");

   if (DoAlertAll)
      if (PrevConnectCount && Accounting.ConnectCount > PrevConnectCount)
         fputs ("\x07", stdout);
   PrevConnectCount = Accounting.ConnectCount;

   CommaNumber (64, &Accounting.QuadBytesRawRx[0], BytesRawRx); 
   CommaNumber (64, &Accounting.QuadBytesRawTx[0], BytesRawTx); 

   if (Accounting.DclCrePrcDetachCount)
      strcpy (CurrentProcessCountString, " (det)");
   else
      sprintf (CurrentProcessCountString, "/%d", CurrentProcessCount);

   ScrPtr += sprintf (ScrPtr,
"%s\r\n\
 %sConnect:%s Accept:%d Reject:%d Busy:%d Current:%d Peak:%d  %sSSL:%s %d\
%s\r\n\
   %sParse:%s %d  %sForbidden:%s %d  %sRedirect:%s Remote:%d Local:%d\
%s\r\n\
 %sCONNECT:%s %d  %sGET:%s %d  %sHEAD:%s %d  %sPOST:%s %d  %sPUT:%s %d\
%s\r\n\
   %sAdmin:%s %d  %sCache:%s %d/%d/%d  %sDECnet:%s CGI:%d OSU:%d  \
%sDir:%s %d%s\r\n\
     %sDCL:%s CLI:%d CGI:%d CGIplus:%d/%d RTE:%d/%d Processes: %d%s\
%s\r\n\
    %sFile:%s %d/%d  %sIsMap:%s %d  %sProxy:%s %d\
  %sPut:%s %d  %sSSI:%s %d  %sUpd:%s %d\
%s\r\n\
%s\r\n\
     %s1xx:%s %d  %s2xx:%s %d  %s3xx:%s %d  %s4xx:%s %d  %s5xx:%s %d\
  (none:%d)\
%s\r\n\
      %sRx:%s %s  %sTx:%s %s  (bytes)\
%s\r\n",
      ANSIceol,
      ANSIbold, ANSInormal,
      Accounting.ConnectAcceptedCount,
      Accounting.ConnectRejectedCount,
      Accounting.ConnectTooBusyCount,
      Accounting.ConnectCurrent,
      Accounting.ConnectPeak,
      ANSIbold, ANSInormal,
      Accounting.ConnectSslCount,
      ANSIceol,
      ANSIbold, ANSInormal,
      Accounting.RequestParseCount,
      ANSIbold, ANSInormal,
      Accounting.RequestForbiddenCount,
      ANSIbold, ANSInormal,
      Accounting.RedirectRemoteCount,
      Accounting.RedirectLocalCount,
      ANSIceol,
      ANSIbold, ANSInormal,
      ProxyAccounting.MethodConnectCount,
      ANSIbold, ANSInormal,
      Accounting.MethodGetCount,
      ANSIbold, ANSInormal,
      Accounting.MethodHeadCount,
      ANSIbold, ANSInormal,
      Accounting.MethodPostCount,
      ANSIbold, ANSInormal,
      Accounting.MethodPutCount,
      ANSIceol,
      ANSIbold, ANSInormal,
      Accounting.DoServerAdminCount,
      ANSIbold, ANSInormal,
      Accounting.CacheLoadCount,
      Accounting.CacheHitCount,
      Accounting.CacheHitNotModifiedCount,
      ANSIbold, ANSInormal,
      Accounting.DoDECnetCgiCount,
      Accounting.DoDECnetOsuCount,
      ANSIbold, ANSInormal,
      Accounting.DoDirectoryCount,
      ANSIceol,
      ANSIbold, ANSInormal,
      Accounting.DoDclCommandCount,
      Accounting.DoScriptCount,
      Accounting.DoCgiPlusScriptCount,
      Accounting.DclCgiPlusReusedCount,
      Accounting.DoRteScriptCount,
      Accounting.DclRteReusedCount,
      Accounting.DclCrePrcCount,
      CurrentProcessCountString,
      ANSIceol,
      ANSIbold, ANSInormal,
      Accounting.DoFileCount,
      Accounting.DoFileNotModifiedCount,
      ANSIbold, ANSInormal,
      Accounting.DoIsMapCount,
      ANSIbold, ANSInormal,
      ProxyAccounting.MethodConnectCount +
         ProxyAccounting.MethodGetCount +
         ProxyAccounting.MethodHeadCount +
         ProxyAccounting.MethodPostCount +
         ProxyAccounting.MethodPutCount,
      ANSIbold, ANSInormal,
      Accounting.DoPutCount,
      ANSIbold, ANSInormal,
      Accounting.DoSsiCount,
      ANSIbold, ANSInormal,
      Accounting.DoUpdateCount,
      ANSIceol,
      ANSIceol,
      ANSIbold, ANSInormal,
      Accounting.ResponseStatusCodeCountArray[1],
      ANSIbold, ANSInormal,
      Accounting.ResponseStatusCodeCountArray[2],
      ANSIbold, ANSInormal,
      Accounting.ResponseStatusCodeCountArray[3],
      ANSIbold, ANSInormal,
      Accounting.ResponseStatusCodeCountArray[4],
      ANSIbold, ANSInormal,
      Accounting.ResponseStatusCodeCountArray[5],
      Accounting.ResponseStatusCodeCountArray[0],
      ANSIceol,
      ANSIbold, ANSInormal,
      BytesRawRx,
      ANSIbold, ANSInormal,
      BytesRawTx,
      ANSIceol);

   return (SS$_NORMAL);
}

/*****************************************************************************/
/*
Add the HTTPd server counter information to the screen buffer from the count 
logical.  The information in this logical is binary data in the form of the 
HTTPd count data structure.  This is used to extract each field member from 
the data.
*/

int AddProxyInfo ()

{
   static int  FreeSpaceAlertCount;
   static long  Addx2 = 2;

   int  status,
        FreeBlocks,
        FreeMBytes,
        PercentBytesCache,
        PercentBytesNetwork,
        PercentBytesNotCacheable,
        PercentCountCacheRead,
        PercentCountCacheWrite,
        PercentCountRequestNotCacheable,
        PercentCountResponseNotCacheable,
        PercentCountNetwork,
        FreePercent,
        TotalMBytes,
        TotalBlocks,
        UsedBlocks,
        UsedMBytes,
        UsedPercent;
   unsigned long  QuadBytesCache [2],
                  QuadBytesNotCacheable [2],
                  QuadBytesRaw [2],
                  QuadBytesTotal [2];
   float  FloatBytesCache,
          FloatBytesNotCacheable,
          FloatBytesNetwork,
          FloatBytesTotal,
          FloatCountCacheRead,
          FloatCountCacheWrite,
          FloatCountRequestNotCacheable,
          FloatCountResponseNotCacheable,
          FloatCountNetwork,
          FloatCountTotal,
          FloatNetworkCount,
          FloatPercent;
   char  BytesCacheRx [32],
         BytesCacheTx [32],
         BytesNotCacheableRx [32],
         BytesNotCacheableTx [32],
         BytesRawRx [32],
         BytesRawTx [32],
         BytesTotal [32],
         ConnectString [128];
   char  *DevNamePtr,
         *EnabledPtr,
         *SpaceAvailablePtr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AddProxyInfo()\n");

   if (!DoGeneralInfo)
   {
      if (DoAlertAll)
         if (PrevConnectCount && Accounting.ConnectCount > PrevConnectCount)
            fputs ("\x07", stdout);
      PrevConnectCount = Accounting.ConnectCount;
   }

   if (ProxyAccounting.ServingEnabled)
      EnabledPtr = "enabled";
   else
      EnabledPtr = "DISABLED";

   if (ProxyAccounting.FreeSpaceAvailable)
   {
      SpaceAvailablePtr = "available";
      FreeSpaceAlertCount = 0;
   }
   else
   {
      SpaceAvailablePtr = "\x1b[1mUNAVAILABLE\x1b[0m";
      if (!FreeSpaceAlertCount--)
      {
         /* alert no free space every minute or so */
         if (IntervalSeconds >= 60)
            FreeSpaceAlertCount = 1;
         else 
            FreeSpaceAlertCount = 60 / IntervalSeconds;
      }
   }

   ProxyMaintDeviceStats (&DevNamePtr, &TotalBlocks, &UsedBlocks, &FreeBlocks);
   TotalMBytes = PROXY_MAINT_DEVICE_MBYTES(TotalBlocks);
   UsedMBytes = PROXY_MAINT_DEVICE_MBYTES(UsedBlocks);
   FreeMBytes = PROXY_MAINT_DEVICE_MBYTES(FreeBlocks);
   UsedPercent = PROXY_MAINT_DEVICE_PERCENT_USED(TotalBlocks,FreeBlocks);
   FreePercent = PROXY_MAINT_DEVICE_PERCENT_FREE(TotalBlocks,FreeBlocks);

   /*********/
   /* bytes */
   /*********/

   status = lib$addx (&ProxyAccounting.QuadBytesCacheRx,
                      &ProxyAccounting.QuadBytesCacheTx,
                      &QuadBytesCache, &Addx2);
   if (Debug) fprintf (stdout, "lib$addx() %%X%08.08X\n", status);

   status = lib$addx (&ProxyAccounting.QuadBytesNotCacheableRx,
                      &ProxyAccounting.QuadBytesNotCacheableTx,
                      &QuadBytesNotCacheable, &Addx2);
   if (Debug) fprintf (stdout, "lib$addx() %%X%08.08X\n", status);

   status = lib$addx (&ProxyAccounting.QuadBytesRawRx,
                      &ProxyAccounting.QuadBytesRawTx,
                      &QuadBytesRaw, &Addx2);
   if (Debug) fprintf (stdout, "lib$addx() %%X%08.08X\n", status);

   status = lib$addx (&QuadBytesCache,
                      &QuadBytesRaw,
                      &QuadBytesTotal, &Addx2);
   if (Debug) fprintf (stdout, "lib$addx() %%X%08.08X\n", status);

   FloatBytesCache = (float)QuadBytesCache[0] +
                     (float)QuadBytesCache[1] * (float)0xffffffff;
   if (Debug) fprintf (stdout, "FloatBytesCache: %f\n", FloatBytesCache);

   CommaNumber (64, &ProxyAccounting.QuadBytesCacheRx[0], BytesCacheRx); 
   CommaNumber (64, &ProxyAccounting.QuadBytesCacheTx[0], BytesCacheTx); 
   CommaNumber (64, &ProxyAccounting.QuadBytesRawRx[0], BytesRawRx); 
   CommaNumber (64, &ProxyAccounting.QuadBytesRawTx[0], BytesRawTx); 
   CommaNumber (64, &QuadBytesRaw[0], BytesTotal); 

   /********************/
   /* bytes percentage */
   /********************/

   FloatBytesNotCacheable = (float)QuadBytesNotCacheable[0] +
                            (float)QuadBytesNotCacheable[1] * (float)0xffffffff;
   if (Debug)
      fprintf (stdout, "FloatBytesNotCacheable: %f\n", FloatBytesNotCacheable);

   FloatBytesNetwork = (float)QuadBytesRaw[0] +
                   (float)QuadBytesRaw[1] * (float)0xffffffff;
   if (Debug) fprintf (stdout, "FloatBytesNetwork: %f\n", FloatBytesNetwork);

   FloatBytesTotal = (float)QuadBytesTotal[0] +
                     (float)QuadBytesTotal[1] * (float)0xffffffff;
   if (Debug) fprintf (stdout, "FloatBytesTotal: %f\n", FloatBytesTotal);

   if (FloatBytesTotal > 0.0)
   {
      PercentBytesCache = (int)(FloatPercent =
                          FloatBytesCache * 100.0 / FloatBytesTotal);
      if (FloatPercent - (float)PercentBytesCache >= 0.5) PercentBytesCache++;

      PercentBytesNotCacheable =
         (int)(FloatPercent = FloatBytesNotCacheable * 100.0 / FloatBytesTotal);
      if (FloatPercent - (float)PercentBytesNotCacheable >= 0.5)
         PercentBytesNotCacheable++;

      PercentBytesNetwork =
         (int)(FloatPercent = FloatBytesNetwork * 100.0 / FloatBytesTotal);
      if (FloatPercent - (float)PercentBytesNetwork >= 0.5)
         PercentBytesNetwork++;
   }
   else
      PercentBytesCache = PercentBytesNotCacheable = PercentBytesNetwork = 0;

   /*********************/
   /* counts percentage */
   /*********************/

   FloatCountRequestNotCacheable = ProxyAccounting.RequestNotCacheableCount;
   FloatCountResponseNotCacheable = ProxyAccounting.ResponseNotCacheableCount;
   FloatCountNetwork = ProxyAccounting.NetworkCount;
   FloatCountCacheRead = ProxyAccounting.CacheReadCount;
   FloatCountCacheWrite = ProxyAccounting.CacheWriteCount;
   FloatCountTotal = FloatCountNetwork + FloatCountCacheRead;

   if (FloatCountTotal > 0.0)
   {
      PercentCountCacheRead = (int)(FloatPercent =
                          FloatCountCacheRead * 100.0 / FloatCountTotal);
      if (FloatPercent - (float)PercentCountCacheRead >= 0.5)
         PercentCountCacheRead++;

      PercentCountRequestNotCacheable =
         (int)(FloatPercent =
               FloatCountRequestNotCacheable * 100.0 / FloatCountTotal);
      if (FloatPercent - (float)PercentCountRequestNotCacheable >= 0.5)
         PercentCountRequestNotCacheable++;

      PercentCountNetwork = 
         (int)(FloatPercent = FloatCountNetwork * 100.0 / FloatCountTotal);
      if (FloatPercent - (float)PercentCountNetwork >= 0.5)
         PercentCountNetwork++;
   }
   else
      PercentCountCacheRead =
         PercentCountRequestNotCacheable =
         PercentCountNetwork = 0;

   if (FloatCountNetwork > 0.0)
   {
      PercentCountCacheWrite = 
         (int)(FloatPercent = FloatCountCacheWrite * 100.0 / FloatCountNetwork);
      if (FloatPercent - (float)PercentCountCacheWrite >= 0.5)
         PercentCountCacheWrite++;

      PercentCountResponseNotCacheable =
         (int)(FloatPercent =
               FloatCountResponseNotCacheable * 100.0 / FloatCountNetwork);
      if (FloatPercent - (float)PercentCountResponseNotCacheable >= 0.5)
         PercentCountResponseNotCacheable++;
   }
   else
      PercentCountCacheWrite = PercentCountResponseNotCacheable = 0;

   /***********/
   /* display */
   /***********/

   if (DoGeneralInfo)
      ConnectString[0] = '\0';
   else
      sprintf (ConnectString, "  %sConnect:%s Current:%d Peak:%d",
               ANSIbold, ANSInormal,
               Accounting.ConnectCurrent,
               Accounting.ConnectPeak);

   ScrPtr += sprintf (ScrPtr,
"%s\r\n\
   %sProxy:%s %s%s\
%s\r\n\
 %sCONNECT:%s %d  %sGET:%s %d  %sHEAD:%s %d  %sPOST:%s %d  %sPUT:%s %d\
%s\r\n\
     %sNot:%s cacheable  Rx/Tx: %d%%  Request:%d (%d%%) Response:%d (%d%%)\
%s\r\n\
 %sNetwork:%s Rx:%s Tx:%s (%d%%)  Requested:%d (%d%%)\
%s\r\n\
  %sLookup:%s Numeric:%d DNS:%d Cache:%d Error:%d\
%s\r\n\
   %sCache:%s Rx:%s Tx:%s (%d%%)  Rd:%d/%d (%d%%) Wr:%d (%d%%)\
%s\r\n\
  %sDevice:%s %s %d blocks (%dMB)  %sSpace:%s %s\
%s\r\n\
          %d used (%dMB %d%%), %d free (%dMB %d%%)\
%s\r\n\
   %sPurge:%s %s\
%s\r\n",
      ANSIceol,
      ANSIbold, ANSInormal,
      EnabledPtr,
      ConnectString,
      ANSIceol,
      ANSIbold, ANSInormal,
      ProxyAccounting.MethodConnectCount,
      ANSIbold, ANSInormal,
      ProxyAccounting.MethodGetCount,
      ANSIbold, ANSInormal,
      ProxyAccounting.MethodHeadCount,
      ANSIbold, ANSInormal,
      ProxyAccounting.MethodPostCount,
      ANSIbold, ANSInormal,
      ProxyAccounting.MethodPutCount,
      ANSIceol,
      ANSIbold, ANSInormal,
      PercentBytesNotCacheable,
      ProxyAccounting.RequestNotCacheableCount,
      PercentCountRequestNotCacheable,
      ProxyAccounting.ResponseNotCacheableCount,
      PercentCountResponseNotCacheable,
      ANSIceol,
      ANSIbold, ANSInormal,
      BytesRawRx,
      BytesRawTx,
      PercentBytesNetwork,
      ProxyAccounting.NetworkCount,
      PercentCountNetwork,
      ANSIceol,
      ANSIbold, ANSInormal,
      ProxyAccounting.LookupNoneCount,
      ProxyAccounting.LookupDnsCount,
      ProxyAccounting.LookupCacheCount,
      ProxyAccounting.LookupErrorCount,
      ANSIceol,
      ANSIbold, ANSInormal,
      BytesCacheRx,
      BytesCacheTx,
      PercentBytesCache,
      ProxyAccounting.CacheReadCount,
      ProxyAccounting.CacheRead304Count,
      PercentCountCacheRead,
      ProxyAccounting.CacheWriteCount,
      PercentCountCacheWrite,
      ANSIceol,
      ANSIbold, ANSInormal,
      DevNamePtr, 
      TotalBlocks, TotalMBytes,
      ANSIbold, ANSInormal,
      SpaceAvailablePtr,
      ANSIceol,
      UsedBlocks, UsedMBytes, UsedPercent,
      FreeBlocks, FreeMBytes, FreePercent,
      ANSIceol,
      ANSIbold, ANSInormal,
      ProxyAccounting.StatusString,
      ANSIceol);

   return (SS$_NORMAL);
}

/****************************************************************************/
/*
Return information about file system space on the proxy cache device.  Will
function correctly with volume sets of up to eight members.
*/

ProxyMaintDeviceStats
(
char **DevNamePtrPtr,
int *TotalBlocksPtr,
int *UsedBlocksPtr,
int *FreeBlocksPtr
)
{
#define PROXY_MAINT_CACHE_DEVICE_MAX 8

   static int  DeviceCount,
               FreeBlocks,
               MaxBlock;
   static unsigned short  Length;
   static short  DevChannel [PROXY_MAINT_CACHE_DEVICE_MAX];
   static char  CacheDevName [65],
                DevName [65];
   static $DESCRIPTOR (DevNameDsc, "");
   static struct {
      short BufferLength;
      short ItemCode;
      void  *BufferPtr;
      void  *LengthPtr;
   }
   DevNamItemList [] = 
   {
      { sizeof(CacheDevName), DVI$_DEVNAM, &CacheDevName, &Length },
      { 0, 0, 0, 0 }
   },
   NextDevNamItemList [] = 
   {
      { sizeof(DevName), DVI$_NEXTDEVNAM, &DevName, &Length },
      { 0, 0, 0, 0 }
   },
   BlocksItemList [] = 
   {
      { sizeof(MaxBlock), DVI$_MAXBLOCK, &MaxBlock, 0 },
      { sizeof(FreeBlocks), DVI$_FREEBLOCKS, &FreeBlocks, 0 },
      { 0, 0, 0, 0 }
   };

   int  idx,
        status,
        TotalBlocks,
        TotalFreeBlocks,
        TotalUsedBlocks;
   struct AnIOsb  IOsb;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProxyMaintDeviceStats()\n");

   if (!DeviceCount)
   {
      /**************/
      /* initialize */
      /**************/

      DevNameDsc.dsc$w_length = strlen(PROXY_CACHE_ROOT);
      DevNameDsc.dsc$a_pointer = PROXY_CACHE_ROOT;

      /* assign a channel to the cache device (or primary if a volument set) */
      if (VMSnok (status =
          sys$assign (&DevNameDsc, &DevChannel[DeviceCount++], 0, 0)))
         ErrorExitVmsStatus (status, "sys$assign()", FI_LI);

      status = sys$getdvi (0, DevChannel[0], 0,
                           &DevNamItemList, &IOsb, 0, 0, 0);
      if (Debug)
         fprintf (stdout, "sys$getdvi() %%X%08.08X IOsb: %%X%08.08X\n",
                  status, IOsb.Status);

      if (VMSok (status)) status = IOsb.Status;
      if (VMSnok (status))
         ErrorExitVmsStatus (status, "sys$getdvi()", FI_LI);

      CacheDevName[Length] = '\0';
      if (CacheDevName[0] == '_')
         memmove (CacheDevName, CacheDevName+1, Length);
      if (Debug) fprintf (stdout, "|%s|\n", CacheDevName);

      /* loop assigning a channel to all devices in volume set (if it is!) */
      for (;;)
      {
         if (DeviceCount >= PROXY_MAINT_CACHE_DEVICE_MAX)
            ErrorExitVmsStatus (0, ErrorProxyMaintTooManyDevices, FI_LI);

         status = sys$getdvi (0, DevChannel[0], 0,
                              &NextDevNamItemList, &IOsb, 0, 0, 0);
         if (Debug)
            fprintf (stdout, "sys$getdvi() %%X%08.08X IOsb: %%X%08.08X\n",
                     status, IOsb.Status);

         if (VMSok (status)) status = IOsb.Status;
         if (VMSnok (status))
            ErrorExitVmsStatus (status, "sys$getdvi()", FI_LI);

         DevName[Length] = '\0';
         if (Debug) fprintf (stdout, "|%s|\n", DevName);

         if (!Length) break;

         DevNameDsc.dsc$w_length = Length;
         DevNameDsc.dsc$a_pointer = DevName;

         if (VMSnok (status =
             sys$assign (&DevNameDsc, &DevChannel[DeviceCount++], 0, 0)))
            ErrorExitVmsStatus (status, DevName, FI_LI);
      }

      if (Debug) fprintf (stdout, "DeviceCount: %d\n", DeviceCount);
   }

   /***********/
   /* process */
   /***********/

   TotalBlocks = TotalFreeBlocks = 0;

   for (idx = 0; idx < DeviceCount; idx++)
   {
      status = sys$getdvi (0, DevChannel[idx], 0,
                           &BlocksItemList, &IOsb, 0, 0, 0);
      if (Debug)
         fprintf (stdout, "sys$getdvi() %%X%08.08X IOsb: %%X%08.08X\n",
                  status, IOsb.Status);
      if (VMSok (status)) status = IOsb.Status;
      if (VMSnok (status))
         ErrorExitVmsStatus (status, "sys$getdvi()", FI_LI);

      if (Debug) fprintf (stdout, "%d %d\n", MaxBlock, FreeBlocks);

      TotalBlocks += MaxBlock;
      TotalFreeBlocks += FreeBlocks;
   }

   TotalUsedBlocks = TotalBlocks - TotalFreeBlocks;

   if (Debug)
      fprintf (stdout, "%d %d %d %dMB %dMB %dMB %d%% %d%%\n",
               TotalBlocks, TotalFreeBlocks, TotalUsedBlocks,
               TotalBlocks >> 11, TotalFreeBlocks >> 11, TotalUsedBlocks >> 11,
               TotalFreeBlocks*100/TotalBlocks, 
               TotalUsedBlocks*100/TotalBlocks);

   if (DevNamePtrPtr != NULL) *DevNamePtrPtr = CacheDevName;
   if (TotalBlocksPtr != NULL) *TotalBlocksPtr = TotalBlocks;
   if (UsedBlocksPtr != NULL) *UsedBlocksPtr = TotalUsedBlocks;
   if (FreeBlocksPtr != NULL) *FreeBlocksPtr = TotalFreeBlocks;
}

/*****************************************************************************/
/*
Add the information about the latest request to the screen buffer from the 
request logical.  Each plain-text string in this logical is terminated by a 
null character.
*/ 

int AddRequest ()

{
   static unsigned short  Length;
   static char  LogicalName [32],
                LogicalValue [256];
   static $DESCRIPTOR (LnmSystemDsc, "LNM$SYSTEM");
   static $DESCRIPTOR (LogicalNameDsc, LogicalName);
   struct {
      short BufferLength;
      short ItemCode;
      void  *BufferPtr;
      void  *LengthPtr;
   } LnmItem [] =
   {
      { sizeof(LogicalValue)-1, LNM$_STRING, LogicalValue, &Length },
      {0,0,0,0}
   };

   register int  cnt;
   register char  *cptr, *hptr, *sptr;

   int  status;
   char  HostName [256];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "AddRequest()\n");

   if (!LogicalName[0])
      LogicalNameDsc.dsc$w_length =
         sprintf (LogicalName, "HTTPD%d$REQUEST", ServerPort);

   Length = 0;
   status = sys$trnlnm (0, &LnmSystemDsc, &LogicalNameDsc, 0, &LnmItem);
   if (Debug) fprintf (stdout, "sys$trnlnm() %%X%08.08X\n", status);
   if (VMSnok (status) && status != SS$_NOLOGNAM) return (status);
   LogicalValue[Length] = '\0';
   if (Debug) fprintf (stdout, "|%s|\n", LogicalValue);

   sptr = ScrPtr;
   cptr = LogicalValue;
   cnt = Length;

   sptr += sprintf (sptr, "%s\r\n    %sTime:%s ",
                    ANSIceol, ANSIbold, ANSInormal);
   while (*cptr && cnt--) *sptr++ = *cptr++;
   if (cnt) { cnt--; cptr++; }

   sptr += sprintf (sptr, "  %sStatus:%s ", ANSIbold, ANSInormal);
   while (*cptr && cnt--) *sptr++ = *cptr++;
   if (cnt) { cnt--; cptr++; }

   sptr += sprintf (sptr, "  %sRx:%s ", ANSIbold, ANSInormal);
   while (*cptr && cnt--) *sptr++ = *cptr++;
   if (cnt) { cnt--; cptr++; }

   sptr += sprintf (sptr, "  %sTx:%s ", ANSIbold, ANSInormal);
   while (*cptr && cnt--) *sptr++ = *cptr++;
   if (cnt) { cnt--; cptr++; }

   sptr += sprintf (sptr, "  %sDuration:%s ", ANSIbold, ANSInormal);
   while (*cptr && cnt--) *sptr++ = *cptr++;
   if (cnt) { cnt--; cptr++; }

   sptr += sprintf (sptr, "%s\r\n %sService:%s ",
                    ANSIceol, ANSIbold, ANSInormal);
   while (*cptr && cnt--) *sptr++ = *cptr++;
   if (cnt) { cnt--; cptr++; }

   if (DoAlertHost)
   {
      if (PrevHostName[0])
      {
         if (strcmp (cptr, PrevHostName))
         {
            fputs ("\x07", stdout);
            strcpy (PrevHostName, cptr);
         }
      }
      else
         strcpy (PrevHostName, cptr);
   }

   sptr += sprintf (sptr, "%s\r\n    %sHost:%s ",
                    ANSIceol, ANSIbold, ANSInormal);
#ifdef IP_NONE
   while (*cptr && cnt--) *sptr++ = *cptr++;
   if (cnt) { cnt--; cptr++; }
#else
   if (DoLookupHost && isdigit(*cptr))
   {
      hptr = HostName;
      while (*cptr && cnt--) *hptr++ = *cptr++;
      *hptr = '\0';
      if (cnt) { cnt--; cptr++; }
      hptr = LookupHostName (HostName);
      if (*hptr)
      {
         while (*hptr) *sptr++ = *hptr++;
         *sptr++ = ' ';
         *sptr++ = '(';
         for (hptr = HostName; *hptr; *sptr++ = *hptr++);
         *sptr++ = ')';
      }
      else
         for (hptr = HostName; *hptr; *sptr++ = *hptr++);
   }
   else
   {
      while (*cptr && cnt--) *sptr++ = *cptr++;
      if (cnt) { cnt--; cptr++; }
   }
#endif

   sptr += sprintf (sptr, "%s\r\n %sRequest:%s ",
                    ANSIceol, ANSIbold, ANSInormal);
   while (*cptr && cnt--) *sptr++ = *cptr++;
   if (cnt) { cnt--; cptr++; }
   if (Length == 255)
      sptr += sprintf (sptr, "%s...%s", ANSIbold, ANSInormal);

   sptr += sprintf (sptr, "%s", ANSIceol);

   ScrPtr = sptr;

   return (SS$_NORMAL);
}

/*****************************************************************************/
/*
Host name lookup.
*/

char* LookupHostName (char *HostDotDecimal)

{
   static char  HostName [256],
                PrevHostDotDecimal [256];

   register char  *cptr, *sptr;

   int  HostIpNumber;
   struct hostent  *HostEntryPtr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "LookupHostName() |%s|\n", HostDotDecimal);

   /* no need to look it up again if it's the same one! */
   if (!strcmp (HostDotDecimal, PrevHostDotDecimal)) return (HostName);
   strcpy (PrevHostDotDecimal, HostDotDecimal);

   /* get the host address details */
   if ((HostIpNumber = inet_addr (HostDotDecimal)) == -1)
   {
      sptr = HostName;
      for (cptr = HostDotDecimal; *cptr; *sptr++ = *cptr++);
      strcpy (sptr, " [error]");
      return (HostName);
   }
   if (Debug) fprintf (stdout, "%08.08X\n", HostIpNumber);

   if (Debug) fprintf (stdout, "gethostbyaddr()\n");
   if ((HostEntryPtr = gethostbyaddr (&HostIpNumber, 4, AF_INET)) == NULL)
   {
      HostName[0] = '\0';
      return (HostName);
   }

   sptr = HostName;
   /* looks better if its all in lower case (host name is sometimes upper) */
   for (cptr = HostEntryPtr->h_name; *cptr; cptr++) *sptr++ = tolower(*cptr);
   *sptr = '\0';
   if (Debug) fprintf (stdout, "HostName |%s|\n", HostName);
   return (HostName);
}

/*****************************************************************************/
/*
See [SRC.HTTPD]CONTROL.C for other information.  Uses the VMS Distributed Lock
Manager to keep track of how many servers are currently executing on the
node/cluster.  NL locks indicate interest (used by this utility), CR locks
indicate a server waiting for a group directive.  This function enqueues a
single NL lock, then periodically get all the locks associated with that
resource and counts up the number of CR locks - giving the number of servers!
If the number of servers varies then (by default) sound the bell!!
*/

char* ServerCount ()

{
   static SysLckMask [2] = { PRV$M_SYSLCK, 0 };
   static int  PrevCrLockCount = -1;
   static char  LockInfo [2048],  /* at 56 bytes per lock is ~35 servers */
                String [32];
   static $DESCRIPTOR (LockNameDsc, "");
   static struct lksb  LockLksb;

   static struct
   {
      unsigned short  TotalLength,  /* bits 0..15 */
                      LockLength;  /* bits 16..30 */
   } ReturnLength;

   static struct
   {
      unsigned short  buf_len;
      unsigned short  item;
      unsigned char   *buf_addr;
      unsigned long  *long_ret_len;
   }
   LkiItems [] =
   {
      { sizeof(LockInfo), LKI$_LOCKS, &LockInfo, &ReturnLength },
      {0,0,0,0}
   };

   int  status,
        CrLockCount,
        LockCount,
        RqMode;
   char  *cptr, *liptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ServerCount()\n");

   /* turn on SYSLCK to allow SYSTEM locks to be enqueued */
   status = sys$setprv (1, &SysLckMask, 0, 0);
   if (Debug) fprintf (stdout, "sys$setprv() %%X%08.08X\n", status);
   if (status == SS$_NOTALLPRIV) exit (SS$_NOPRIV);
   
   if (!LockLksb.lksb$l_lkid)
   {
      /* remember, a specific resource name can also be set using /ALL= */
      LockNameDsc.dsc$a_pointer = ServerGroupResName;
      LockNameDsc.dsc$w_length = strlen(ServerGroupResName);
      if (Debug)
         fprintf (stdout, "%d |%s|\n",
                  LockNameDsc.dsc$w_length, LockNameDsc.dsc$a_pointer);
   
      /* enqueue a just-interested NL lock */
      status = sys$enqw (0, LCK$K_NLMODE, &LockLksb,
                         LCK$M_SYSTEM, &LockNameDsc, 0, 0, 0, 0, 0, 2, 0);
      if (Debug) fprintf (stdout, "NL sys$enqw() %%X%08.08X\n", status);
      if (VMSnok (status)) exit (status);
   }

   status = sys$getlkiw (0, &LockLksb.lksb$l_lkid, &LkiItems, 0, 0, 0, 0);
   if (Debug) fprintf (stdout, "sys$getlkiw() %%X%08.08X\n", status);
   if (VMSnok (status)) exit (status);

   /* turn off SYSLCK */
   sys$setprv (0, &SysLckMask, 0, 0);

   if (ReturnLength.LockLength)
   {
      /* if insufficient buffer space */
      if (ReturnLength.LockLength & 0x8000) exit (SS$_BADPARAM);
      LockCount = ReturnLength.TotalLength / ReturnLength.LockLength;
   }
   else
      LockCount = 0;

   if (Debug)
      fprintf (stdout, "LockLength: %d TotalLength: %d count:%d\n",
               ReturnLength.LockLength, ReturnLength.TotalLength, LockCount);

   CrLockCount = 0;
   liptr = &LockInfo;
   while (LockCount--)
   {
      RqMode = ((unsigned char*)liptr)[12];
      if (Debug) fprintf (stdout, "RqMode: %d\n", RqMode);
      if (RqMode == LCK$K_CRMODE) CrLockCount++;
      liptr += ReturnLength.LockLength;
   }

   if (PrevCrLockCount < 0)
   {
      /* initial */
      sprintf (String, "%d", CrLockCount);
      PrevCrLockCount = CrLockCount;
   }
   else
   if (PrevCrLockCount && PrevCrLockCount != CrLockCount)
   {
      /* subsequent */
      sprintf (String, "%d(%d)", CrLockCount, PrevCrLockCount);
      if (DoAlertServers) fputs ("\x07\x07\x07", stdout);
      PrevCrLockCount = CrLockCount;
   }
   if (Debug) fprintf (stdout, "|%s|\n", String);

   return (String);
}

/*****************************************************************************/
/*
*/

int OnControlY (void *FunctionAddress)

{
   static boolean  Disabled = false;
   static unsigned long  Mask = LIB$M_CLI_CTRLY,
                         OldMask;
   static unsigned short  TTChannel = 0;

   int  status;
   $DESCRIPTOR (TTDsc, "TT:");

   /*********/
   /* begin */
   /*********/

   if (FunctionAddress)
   {
      if (!TTChannel)
         if (VMSnok (status = sys$assign (&TTDsc, &TTChannel, 0, 0, 0)))
            return (status);

      if (VMSnok (status =
          sys$qiow (0, TTChannel, IO$_SETMODE | IO$M_CTRLYAST, 0, 0, 0,
                    FunctionAddress, 0, PSL$C_USER, 0, 0, 0)))
         return (status);

      if (VMSnok (status =
          sys$qiow (0, TTChannel, IO$_SETMODE | IO$M_CTRLCAST, 0, 0, 0,
                    FunctionAddress, 0, PSL$C_USER, 0, 0, 0)))
         return (status);

      if (!Disabled)
      {
         Disabled = true;
         return (lib$disable_ctrl (&Mask, &OldMask));
      }
      else
         return (status);
   }
   else
   {
      sys$cancel (TTChannel);
      return (lib$enable_ctrl (&OldMask, 0));
   }
}

/*****************************************************************************/
/*
*/

ControlY_AST ()

{
   ControlY = true;
   sys$wake (0, 0);
}

/*****************************************************************************/
/*
*/

char* TimeString ()

{
   static int  LibDayOfWeek = LIB$K_DAY_OF_WEEK;
   static char  *WeekDays [] =
   {"","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};
   static char  TimeString [35];
   static $DESCRIPTOR (DayDateTimeDsc, "!AZ, !%D");
   static $DESCRIPTOR (TimeStringDsc, TimeString);

   unsigned long  BinTime [2];
   int  status,
        DayOfWeek;
   unsigned short  Length;

   /*********/
   /* begin */
   /*********/

   sys$gettim (&BinTime);
   lib$cvt_from_internal_time (&LibDayOfWeek, &DayOfWeek, &BinTime);
   sys$fao (&DayDateTimeDsc, &Length, &TimeStringDsc,
            WeekDays[DayOfWeek], &BinTime);
   TimeString[Length-3] = '\0';
   return (TimeString);
}

/*****************************************************************************/
/*
Convert the 32/64 bit integer (depending on architecture) pointed to into an
ASCII number string containing commas.  The destination string should contain
capacity of a minimum 16 characters for 32 bits, or 32 characters for 64 bits.
*/

CommaNumber
(
int Bits,
unsigned long Value,
char *String
)
{
   static $DESCRIPTOR (Value32FaoDsc, "!UL");
   static $DESCRIPTOR (Value64FaoDsc, "!@UJ");

   register int  cnt;
   register char  *cptr, *sptr;

   int  status;
   char  Scratch [32];
   unsigned short  Length;
   $DESCRIPTOR (ScratchDsc, Scratch);

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "CommaNumber()\n");

   if (Bits > 32)
      status = sys$fao (&Value64FaoDsc, &Length, &ScratchDsc, Value);
   else
      status = sys$fao (&Value32FaoDsc, &Length, &ScratchDsc, Value);
   if (VMSnok (status))
   {
      strcpy (String, "*ERROR*");
      return;
   }
   Scratch[Length] = '\0';
   if (((Length-1) / 3) < 1)
   {
      strcpy (String, Scratch);
      return;
   }
   else
   if (!(cnt = Length % 3))
      cnt = 3;
   
   cptr = Scratch;
   sptr = String;
   while (*cptr)
   {
      if (!cnt--)
      {
         *sptr++ = ',';
         cnt = 2;
      }
      *sptr++ = *cptr++;
   }
   *sptr = '\0';
}

/****************************************************************************/
/*
*/
 
int ShowHelp ()
 
{
   fprintf (stdout,
"%%%s-I-HELP, usage for the WASD HTTPd Monitor (%s)\n\
\n\
Continuously displays the status of an HTTPd process (must be executed on the\n\
system that has the process running on it, defaulting to port 80).  Provides\n\
process information, server counters, latest request information, with proxy\n\
processing statistics optionally available.  By default attempts to resolve\n\
request dotted-decimal host address to host name.  The alert qualifier\n\
activates the terminal bell for either an increase in server connect count\n\
(=ALL) or change in requesting host (=HOST).\n\
\n\
$ HTTPDMON [qualifiers...]\n\
\n\
/ALERT[=ALL|HOST] /[NO]GENERAL /HELP /INTERVAL=integer /[NO]LOOKUP\n\
/PORT=integer /[NO]PROCESS /[NO]PROXY /REFRESH=integer /[NO]REQUEST\n\
\n\
Usage examples:\n\
\n\
$ HTTPDMON\n\
$ HTTPDMON /PORT=8080\n\
$ HTTPDMON /INTERVAL=60 /PROXY\n\
$ HTTPDMON /PORT=8080 /ALERT\n\
$ HTTPDMON /NOLOOKUP\n\
\n",
   Utility, SoftwareID);
 
   return (SS$_NORMAL);
}
 
/****************************************************************************/
/*
Does a case-insensitive, character-by-character string compare and returns 
true if two strings are the same, or false if not.  If a maximum number of 
characters are specified only those will be compared, if the entire strings 
should be compared then specify the number of characters as 0.
*/ 
 
boolean strsame
(
register char *sptr1,
register char *sptr2,
register int  count
)
{
   while (*sptr1 && *sptr2)
   {
      if (toupper (*sptr1++) != toupper (*sptr2++)) return (false);
      if (count)
         if (!--count) return (true);
   }
   if (*sptr1 || *sptr2)
      return (false);
   else
      return (true);
}
 
/*****************************************************************************/

