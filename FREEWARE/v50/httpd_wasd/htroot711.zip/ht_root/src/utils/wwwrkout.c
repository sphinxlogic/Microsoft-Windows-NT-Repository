/*****************************************************************************/
/*
                                WWWrkout.c

"Workout" utility for a WWW server.  Stresses a server both in number of 
simultaneous connections maintained and in the number of back-to-back 
sequential connection requests and data transfers.  This is probably not the
best test tool but it's better than nothing.  To really exercise a server it
should be used from multiple systems simultaneously.

Sets up and maintains a specified number of simultaneous connections (or until 
server limit is reached).  Is AST-driven, so it will generally push throughput
to whatever the server can supply. When the transfer is complete it closes that
connection at this end and uses the closed socket to initiate  another.  If
enabled (it is by default), the utility attempts to reflect the  real-world by
varying the data transfer rate for each connection, through  setting the number
of bytes read during each read loop differently for each  connection.  All data
transfered is discarded. If enabled will occasionally break a connection at
random times during transfer to exercise server recovery, etc.

The data transfer rate for each connection is displayed at connection close.  
It is by default the effective transfer rate, that is the rate from opening 
the connection to closing it, and so includes request processing time, etc., 
or if the /NOEFFECTIVE qualifier is emplaoyed measure the document data 
transfer rate only.

The document paths should be specified one per line in a plain text file.  
Preferably each document path and/or type specified should be different to the 
others, to exercise the server and file system cache.  Any number of paths may 
be specified in the file.  If the file is exhausted before the specified 
number of connections have been established the file contents are recycled 
from the first path.  If path or a file of paths is not specified the utility 
just continually requests the welcome document. 


METRIC REPORT
-------------
This functionality has been added to ease the generation of performance
information on a server or servers.  It takes directives from a plain text file
and generates requests to specified paths, recording the number of requests and
bytes transfered per second.  It has a very simple syntax (the mods were made
in a couple of hours) for the directives file (specified using /METRIC=).
Essentially it contains WWWRKOUT directives (minus the WWWRKOUT verb) and some
other keywords to allow repeating of groups of directives and for reporting
output.  Very crude, but I was sick of collating this information manually!

The following is an example /METRIC= file (see below for a very brief
explanation):


  ##########################################################################
  { 10
  
    "
    "WASD server - zero length file
    /server=beta:7080 /path="/ht_root/exercise/0k.txt" \
    /simul=1 /count=200
  
    "
    "OSU server - zero length file
    /server=beta:7777 /path="/ht_root/exercise/0k.txt" \
    /simul=1 /count=200
  }
  
  # provide the average of the total in the above repeat grouping
  "
  "WASD server - zero length file
  "------------------------------
  $1
  "
  "OSU server - zero length file
  "-----------------------------
  $2
  "
  
  ~30

  { 10
  
    "
    "WASD server - 64kB length file
    /server=beta:7080 /path="/ht_root/exercise/64k.txt" \
    /simul=1 /count=200
  
    "
    "OSU server - 64kB length file
    /server=beta:7777 /path="/ht_root/exercise/64k.txt" \
    /simul=1 /count=200
  }
  
  # provide the average of the total in the above repeat grouping
  "
  "WASD server - 64kB length file
  "------------------------------
  $1
  "
  "OSU server - 64kB length file
  "-----------------------------
  $2
  "
  ##########################################################################


explanation
~~~~~~~~~~~

  o  '#' indicates a comment line (leading character)

  o  '{' indicates the beginning of group of lines to be repeated,
         the number following the '{' sets the number of repeats

  o  '}' indicates the end of a repeat structure

  o  '"' a string literal to be output (the quote is suppressed)

  o  '$' output the averaged requests and bytes transfered of the
         total of each individual directive within a repeat group,
         number indicates the WWWRKOUT directive in the order
         in which they occured inside the repeat grouping

  o  '/' qualifiers that WWWRKOUT expects for the batch of requests
         for that particular test       

  o  '~' sleep for the number of seconds indicated


DCL SYMBOLS
-----------
The following local DCL symbols are created at the end of each pass.

  WWWRKOUT_MILLISECONDS          number of milliseconds the pass took
  WWWRKOUT_CONNECTIONS           number of connections made
  WWWRKOUT_REQUESTS_PER_SECOND   requests (connections) per second
  WWWRKOUT_BYTES_PER_SECOND      bytes transfered (tx & rx) per second
  WWWRKOUT_000                   non-understandable responses
  WWWRKOUT_100                   number of 1xx responses
  WWWRKOUT_200                             2xx
  WWWRKOUT_300                             3xx
  WWWRKOUT_400                             4xx
  WWWRKOUT_500                             5xx


QUALIFIERS
----------
/[NO]BREAK              break a connection occasionally (test server recovery)
/BUFFER=                maximum number bytes to be read from server each time
/COUNT=                 total number of connections and requests to be done
/DBUG                   turns on all "if (Debug)" statements
/[NO]EFFECTIVE          measures data transfer rate from request to close
/FILEOF=                file name containing paths to documents
/[NO]HEAD               mix HEAD and GET methods at pseudo-random
/HELP                   display brief usage information
/LIST=                  output <stdout> to this file
/METRIC=                file containing ",etric" directives (see above)
/NOREAD                 do not read anything at all back from the server
/[NO]OUTPUT=            file name for output, no output suppresses only the
                        report for each connection, totals and errors still
/PATH=                  path to document to be retrieved
/PORT=                  IP port number of HTTP server
/PROXY=                 server name and port for proxy access/workout
/SERVER=                HTTP server host name
/SIMULTANEOUS=          number of simultaneous connections at any one time
/[NO]VARY               varies the size of the read buffer for each connection


BUILD DETAILS
-------------
See BUILD_WWWRKOUT.COM


VERSION HISTORY (update SoftwareID as well!)
---------------
30-OCT-99  MGD  v1.7.0, remove NETLIB support,
                        add "Host:" to requests
27-JAN-99  MGD  v1.6.0, proxy workout,
                        add metric reporting functionality
                        add some DCL symbols to export selected information
15-FEB-98  MGD  v1.5.1, allow comments in source files
29-NOV-97  MGD  v1.5.0, add HEAD method
08-OCT-97  MGD  v1.4.1, float time now 0.000001 not 0.0
11-SEP-97  MGD  v1.4.0, quit after a maximum connection errors
04-AUG-97  MGD  v1.3.1, bugfix; UCX gethostname() error detection
29-JUL-97  MGD  v1.3.0, redesign for being AST-driven and with NETLIB support
25-JUN-97  MGD  v1.2.0, broken connections to test server recovery
06-JAN-96  MGD  v1.1.0, Multinet compatibility
05-MAY-95  MGD  v1.0.0, initial development
*/
/*****************************************************************************/

#ifdef __ALPHA
   char SoftwareID [] = "WWWRKOUT v1.7.0 AXP";
#else
   char SoftwareID [] = "WWWRKOUT v1.7.0 VAX";
#endif

/* standard C header files */
#include <stdio.h>
#include <ctype.h>
#include <errno.h>

/* VMS related header files */
#include <descrip.h>
#include <iodef.h>
#include <libclidef.h>
#include <libdef.h>
#include <libdtdef.h>
#include <ssdef.h>
#include <stsdef.h>

/* Internet-related header files */
#include <socket.h>
#include <in.h>
#include <netdb.h>
#include <inet.h>

/* define required values from UCX$INETDEF.H (Multinet does not supply one) */
#define INET_PROTYP$C_STREAM 1
#define INETACP$C_TRANS 2
#define INETACP_FUNC$C_GETHOSTBYNAME 1
#define INETACP_FUNC$C_GETHOSTBYADDR 2
#define UCX$C_AF_INET 2
#define UCX$C_DSC_ALL 2
#define UCX$C_FULL_DUPLEX_CLOSE 8192
#define UCX$C_REUSEADDR 4
#define UCX$C_SOCK_NAME 4
#define UCX$C_SOCKOPT 1
#define UCX$C_TCP 6

#define boolean int
#define true 1
#define false 0
 
#define VMSok(x) ((x) & STS$M_SUCCESS)
#define VMSnok(x) !(((x) & STS$M_SUCCESS))

#define MaxConnections 256
#define MaxReadBufferSize 8192
#define DefaultServerPort 80
#define DefaultSpecifiedCount 100
#define DefaultSpecifiedSimultaneous 10
#define DefaultReadBufferSize 1024

/* lib$cvtf_from_internal_time() complains about about a zero elapsed time! */
#define LIB$_DELTIMREQ 1410052

struct AnIOsb
{
   unsigned short  Status;
   unsigned short  Count;
   unsigned long  Unused;
};

struct ConnectionStruct
{
   struct ConnectionStruct  *NextPtr;
   unsigned short  Channel;
   int  ByteCount,
        ConnectionNumber,
        ReadBufferSize;
   unsigned long  StatTimerContext;
   char  *MethodPtr;
   char  Path [256],
         ReadBuffer [MaxReadBufferSize],
         Request [512];
   struct AnIOsb  IOsb;
};

struct MetricStruct
{
   float  TotalElapsedTimeFloat,
          TotalConnectionsFloat,
          TotalBytesFloat;
};

#define MAX_CONNECTION_ERROR_COUNT 20

char  Utility [] = "WWWRKOUT";

unsigned long  StatTimerElapsedTime = 1,
               CvtTimeFloatSeconds = LIB$K_DELTA_SECONDS_F;

boolean  DoBrokenConnections,
         Debug,
         DoNoRead,
         DoShowHelp,
         DoVerbose,
         DoHeadMethod,
         EffectiveTransferRate,
         NoOutput,
         VaryBufferSize;

int  DoBrokenConnectionCount,
     ConnectionErrorCount,
     ConnectionCount,
     ReadBufferSize,
     GetMethodCount,
     HeadMethodCount,
     HttpReadErrorCount,
     HttpRequestErrorCount,
     MetricIndex,
     OutstandingConnections,
     ProxyServerPort,
     ServerPort,
     SpecifiedCount,
     SpecifiedSimultaneous,
     StatusCodeErrorCount,
     TotalBytesReceived,
     TotalBytesSent;

int  StatusCodeCount [10];

FILE  *Output;

unsigned long  TotalStatTimerContext;

char  *CliProxyServerHostPtr,
      *CliServerHostPtr,
      *ListFileNamePtr,
      *MetricFileNamePtr,
      *OutFileNamePtr,
      *PathFileNamePtr,
      *SpecifiedPathPtr;

char  CommandLine [256],
      HttpProxyServer [256],
      ProxyServerHost [256],
      ServerHost [256];

#define MAX_METRIC 10
struct MetricStruct  MetricArray [MAX_METRIC];

struct ConnectionStruct  *ConnectionListPtr,
                         *LastConnectionPtr;

$DESCRIPTOR (InetDeviceDsc, "UCX$DEVICE");

int  OptionEnabled = 1;

struct hostent  *ServerHostEntryPtr;
struct sockaddr_in  ServerSocketName;

struct {
   unsigned int  Length;
   char  *Address;
} ServerSocketNameItem =
   { sizeof(ServerSocketName), &ServerSocketName };

struct {
   unsigned short  Length;
   unsigned short  Parameter;
   char  *Address;
} ReuseAddress =
   { sizeof(OptionEnabled), UCX$C_REUSEADDR, &OptionEnabled },
  ReuseAddressSocketOption =
   { sizeof(ReuseAddress), UCX$C_SOCKOPT, &ReuseAddress };

struct {
   unsigned short  Protocol;
   unsigned char  Type;
   unsigned char  Family;
} TcpSocket = { UCX$C_TCP, INET_PROTYP$C_STREAM, UCX$C_AF_INET };

/* required function prototypes */
ConnectToServer (struct ConnectionStruct*);
ConnectToServerAst (struct ConnectionStruct*);
ReadResponseAst (struct ConnectionStruct*);
WriteRequestAst (struct ConnectionStruct*);
char* ErrorMessage (int);

/*****************************************************************************/
/*
*/

int main ()

{
   /*********/
   /* begin */
   /*********/

   GetParameters (NULL);

   if (DoShowHelp) exit (ShowHelp ());

   if (ListFileNamePtr[0])
      if ((stdout = freopen (ListFileNamePtr, "w", stdout)) == NULL)
         exit (vaxc$errno);

   if (MetricFileNamePtr[0])
      MetricReport ();
   else   
   {
      MetricIndex = 0;
      OneRun ();
   }

   exit (SS$_NORMAL);
}

/*****************************************************************************/
/*
Get "command-line" parameters, whether from the command-line or from a
configuration symbol or logical containing the equivalent.  This function has
been customized for this utility to allow it to be called multiple times during
the one use.
*/

GetParameters (char *String)

{
   static char  CommandLine [256];
   static unsigned long  Flags = 0;

   register char  *aptr, *cptr, *clptr, *sptr;

   int  status;
   unsigned short  Length;
   char  ch;
   $DESCRIPTOR (CommandLineDsc, CommandLine);

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "GetParameters()\n");

   /**************/
   /* initialize */
   /**************/

   DoShowHelp = false;
   DoBrokenConnections =
      EffectiveTransferRate =
      DoHeadMethod =
      NoOutput =
      VaryBufferSize = true;

   ReadBufferSize = DefaultReadBufferSize;
   SpecifiedCount = DefaultSpecifiedCount;
   ServerPort = DefaultServerPort;
   SpecifiedSimultaneous = DefaultSpecifiedSimultaneous;

   CliProxyServerHostPtr =
      CliServerHostPtr = 
      ListFileNamePtr = 
      MetricFileNamePtr =
      PathFileNamePtr =
      OutFileNamePtr = 
      SpecifiedPathPtr = "";
   
   /**************/
   /* get source */
   /**************/

   if (String == NULL)
   {
      if ((clptr = getenv ("PCACHE$PARAM")) == NULL)
      {
         /* get the entire command line following the verb */
         if (VMSnok (status =
             lib$get_foreign (&CommandLineDsc, 0, &Length, &Flags)))
            exit (status);
         (clptr = CommandLine)[Length] = '\0';
      }
   }
   else
      clptr = String;

   if (Debug) fprintf (stdout, "clptr |%s|\n", clptr);

   aptr = NULL;
   ch = *clptr;
   for (;;)
   {
      if (aptr != NULL && *aptr == '/') *aptr = '\0';
      if (!ch) break;

      *clptr = ch;
      if (Debug) fprintf (stdout, "clptr |%s|\n", clptr);
      while (*clptr && isspace(*clptr)) *clptr++ = '\0';
      aptr = clptr;
      if (*clptr == '/') clptr++;
      while (*clptr && !isspace (*clptr) && *clptr != '/')
      {
         if (*clptr != '\"')
         {
            clptr++;
            continue;
         }
         cptr = clptr;
         clptr++;
         while (*clptr)
         {
            if (*clptr == '\"')
               if (*(clptr+1) == '\"')
                  clptr++;
               else
                  break;
            *cptr++ = *clptr++;
         }
         *cptr = '\0';
         if (*clptr) clptr++;
      }
      ch = *clptr;
      if (*clptr) *clptr = '\0';
      if (Debug) fprintf (stdout, "aptr |%s|\n", aptr);
      if (!*aptr) continue;

      /**************/
      /* parameters */
      /**************/

      if (strsame (aptr, "/BREAK", 4))
      {
         DoBrokenConnections = true;
         continue;
      }
      if (strsame (aptr, "/NOBREAK", 6))
      {
         DoBrokenConnections = false;
         continue;
      }

      if (strsame (aptr, "/BUFFER=", 4))
      {
         for (cptr = aptr; *cptr && *cptr != '='; cptr++);
         if (*cptr) cptr++;
         ReadBufferSize = atoi(cptr);
         continue;
      }

      if (strsame (aptr, "/COUNT=", 4))
      {
         for (cptr = aptr; *cptr && *cptr != '='; cptr++);
         if (*cptr) cptr++;
         SpecifiedCount = atoi(cptr);
         continue;
      }

      if (strsame (aptr, "/DBUG", -1))
      {
         Debug = true;
         continue;
      }

      if (strsame (aptr, "/EFFECTIVE", 4))
      {
         EffectiveTransferRate = true;
         continue;
      }
      if (strsame (aptr, "/NOEFFECTIVE", 6))
      {
         EffectiveTransferRate = false;
         continue;
      }

      if (strsame (aptr, "/FILEOF=", 4))
      {
         for (cptr = aptr; *cptr && *cptr != '='; cptr++);
         if (*cptr) cptr++;
         PathFileNamePtr = cptr;
         continue;
      }

      if (strsame (aptr, "/HEAD", 4))
      {
         DoHeadMethod = true;
         continue;
      }
      if (strsame (aptr, "/NOHEAD", 6))
      {
         DoHeadMethod = false;
         continue;
      }

      if (strsame (aptr, "/HELP", 4))
      {
         DoShowHelp = true;
         continue;
      }

      if (strsame (aptr, "/METRIC=", 4))
      {
         for (cptr = aptr; *cptr && *cptr != '='; cptr++);
         if (*cptr) cptr++;
         MetricFileNamePtr = cptr;
         continue;
      }

      if (strsame (aptr, "/PATH=", 4))
      {
         for (cptr = aptr; *cptr && *cptr != '='; cptr++);
         if (*cptr) cptr++;
         SpecifiedPathPtr  = cptr;
         continue;
      }

      if (strsame (aptr, "/PORT=", 4))
      {
         for (cptr = aptr; *cptr && *cptr != '='; cptr++);
         if (*cptr) cptr++;
         ServerPort = atoi(cptr);
         continue;
      }

      if (strsame (aptr, "/PROXY=", 4))
      {
         for (cptr = aptr; *cptr && *cptr != '='; cptr++);
         if (*cptr) cptr++;
         CliProxyServerHostPtr  = cptr;
         continue;
      }

      if (strsame (aptr, "/LIST=", 4))
      {
         for (cptr = aptr; *cptr && *cptr != '='; cptr++);
         if (*cptr) cptr++;
         ListFileNamePtr  = cptr;
         continue;
      }

      if (strsame (aptr, "/NOREAD", 6))
      {
         DoNoRead = true;
         continue;
      }

      if (strsame (aptr, "/SERVER=", 4))
      {
         for (cptr = aptr; *cptr && *cptr != '='; cptr++);
         if (*cptr) cptr++;
         CliServerHostPtr = cptr;
         continue;
      }

      if (strsame (aptr, "/SIMULTANEOUS=", 4))
      {
         for (cptr = aptr; *cptr && *cptr != '='; cptr++);
         if (*cptr) cptr++;
         SpecifiedSimultaneous = atoi(cptr);
         continue;
      }

      if (strsame (aptr, "/OUTPUT=", 4))
      {
         NoOutput = false;
         for (cptr = aptr; *cptr && *cptr != '='; cptr++);
         if (*cptr) cptr++;
         OutFileNamePtr = cptr;
         continue;
      }
      if (strsame (aptr, "/NOOUTPUT", 6))
      {
         NoOutput = true;
         continue;
      }

      if (strsame (aptr, "/VARY", 4))
      {
         VaryBufferSize = true;
         continue;
      }
      if (strsame (aptr, "/NOVARY", 6))
      {
         VaryBufferSize = false;
         continue;
      }

      if (strsame (aptr, "/VERBOSE", 4))
      {
         DoVerbose = true;
         continue;
      }
      if (strsame (aptr, "/NOVERBOSE", 6))
      {
         DoVerbose = false;
         continue;
      }

      if (*aptr == '/')
      {
         fprintf (stdout, "%%%s-E-IVQUAL, unrecognized qualifier\n \\%s\\\n",
                  Utility, aptr+1);
         exit (STS$K_ERROR | STS$M_INHIB_MSG);
      }

      if (!SpecifiedPathPtr[0])
      {
         SpecifiedPathPtr = aptr;
         continue;
      }

      fprintf (stdout, "%%%s-E-MAXPARM, too many parameters\n \\%s\\\n",
               Utility, aptr);
      exit (STS$K_ERROR | STS$M_INHIB_MSG);
   }
}

/*****************************************************************************/
/*
Generate a report basically used for comparing multiple servers.
*/

MetricReport ()

{

   register char  *cptr;

   int  BytesPerSecond,
        ContinuedLineNumber,
        LineNumber,
        LineRemaining,
        RepeatCount,
        RepeatFromLine,
        RepeatSeek,
        RequestsPerSecond,
        ServerNumber,
        SleepSeconds,
        ThisLineNumber;
   float  FloatRate;
   char  Line [256];
   FILE  *MetricFile;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "MetricReport()\n");

   if ((MetricFile = fopen (MetricFileNamePtr, "r")) == NULL)
      exit (vaxc$errno);

   ContinuedLineNumber = LineNumber = LineRemaining =
       MetricIndex = RepeatCount = RepeatFromLine =
       RepeatSeek = ServerNumber = 0;

   for (;;)
   {
      /************/
      /* get line */
      /************/

      if (!LineRemaining)
      {
         LineRemaining = sizeof(Line)-1;
         cptr = Line;
      }

      if (fgets (cptr, LineRemaining, MetricFile) == NULL) break;
      if (Debug) fprintf (stdout, "cptr |%s|\n", cptr);
      LineNumber++;

      for (cptr = Line; *cptr && *cptr != '\n'; cptr++);
      *cptr = '\0';
      if (cptr > Line)
      {
         if (*(cptr-1) == '\\')
         {
            /* continued line */
            if (!ContinuedLineNumber) ContinuedLineNumber = LineNumber;
            if (cptr - Line < sizeof(Line)-1)
            {
               *(cptr-1) = ' ';
               LineRemaining =  sizeof(Line) - (int)(cptr - Line - 1);
               if (!LineRemaining) exit (SS$_BUFFEROVF & 2);
               continue;
            }
         }
      }
      LineRemaining = 0;
      if (ContinuedLineNumber)
      {
         ThisLineNumber = ContinuedLineNumber;
         ContinuedLineNumber = 0;
      }
      else
         ThisLineNumber = LineNumber;

      if (DoVerbose)
         fprintf (stdout, "%%%s-I-METRIC, line %d\n \\%s\\\n",
                  Utility, ThisLineNumber, Line);

      /*****************/
      /*  process line */
      /*****************/

      for (cptr = Line; *cptr && isspace(*cptr); cptr++);
      if (!*cptr || *cptr == '#') continue;

      if (*cptr == '{')
      {
         /****************/
         /* begin repeat */
         /****************/

         cptr++;
         while (*cptr && isspace(*cptr)) cptr++;
         RepeatCount = 0;
         if (isdigit(*cptr)) RepeatCount = atoi(cptr);
         if (!RepeatCount) RepeatCount = 1;

         if ((RepeatSeek = ftell (MetricFile)) == EOF)
            exit (vaxc$errno);

         memset (&MetricArray, 0, sizeof(MetricArray));
         MetricIndex = 0;

         RepeatFromLine = LineNumber;
         continue;
      }

      if (*cptr == '}')
      {
         /**************/
         /* end repeat */
         /**************/

         if (RepeatCount) RepeatCount--;
         if (RepeatCount)
         {
            if (fseek (MetricFile, RepeatSeek, SEEK_SET) == -1)
               exit (vaxc$errno);
            LineNumber = RepeatFromLine;
            MetricIndex = 0;
            continue;
         }
         MetricIndex = RepeatCount = RepeatFromLine = RepeatSeek = 0;
         continue;
      }

      if (*cptr == '$')
      {
         /****************************/
         /* display accumulated data */
         /****************************/

         cptr++;
         while (*cptr && isspace(*cptr)) cptr++;
         ServerNumber = 0;
         if (isdigit(*cptr)) ServerNumber = atoi(cptr);
         if (!ServerNumber) continue;

         if (ServerNumber <= 0 || ServerNumber >= MAX_METRIC)
         {
            fprintf (stdout, "%%%s-E-ENTRY, out-of-range\n", Utility);
            exit (STS$K_ERROR | STS$M_INHIB_MSG);
         }

         if (MetricArray[ServerNumber].TotalElapsedTimeFloat > 0.0)
         {
            BytesPerSecond = (int)
                             (MetricArray[ServerNumber].TotalBytesFloat /
                              MetricArray[ServerNumber].TotalElapsedTimeFloat);

            FloatRate = MetricArray[ServerNumber].TotalConnectionsFloat /
                        MetricArray[ServerNumber].TotalElapsedTimeFloat;
            RequestsPerSecond = (int)FloatRate;
            if (FloatRate - (float)RequestsPerSecond >= 0.5)
               RequestsPerSecond++;
         }
         else
            BytesPerSecond = RequestsPerSecond = 0;

         fprintf (stdout,
"%d requests, %d bytes, %.3f seconds, %d request/S, %d byte/S\n",
                  (int)MetricArray[ServerNumber].TotalConnectionsFloat,
                  (int)MetricArray[ServerNumber].TotalBytesFloat,
                  MetricArray[ServerNumber].TotalElapsedTimeFloat,
                  RequestsPerSecond, BytesPerSecond);

         continue;
      }

      if (*cptr == '~')
      {
         /***************************/
         /* sleep specified seconds */
         /***************************/

         SleepSeconds = atoi(cptr+1)+1;
         if (SleepSeconds) sleep (SleepSeconds);
         continue;
      }

      if (*cptr == '\"')
      {
         /**************************/
         /* display string literal */
         /**************************/

         fprintf (stdout, "%s\n", cptr+1);
         continue;
      }

      if (*cptr != '/')
      {
         fprintf (stdout,
                  "%%%s-E-CONFUSED, should begin with a \"/\"\n \\%s\\\n",
                  Utility, cptr);
         exit (STS$K_ERROR | STS$M_INHIB_MSG);
      }

      if (++MetricIndex >= MAX_METRIC)
      {
         fprintf (stdout,
                  "%%%s-E-ENTRY, too many entries in one repeat block\n",
                  Utility);
         exit (STS$K_ERROR | STS$M_INHIB_MSG);
      } 

      GetParameters (cptr);

      /* being a measurement we don't want too much variation */
      DoBrokenConnections = DoHeadMethod = VaryBufferSize = false;
      NoOutput = true;

      OneRun ();
   }

   fclose (MetricFile);
}

/*****************************************************************************/
/*
Single, command-line specified pass.
*/

OneRun ()

{
   register char  *cptr, *sptr;

   int  status;
   unsigned short  Length;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "OneRun()\n");

   if (ReadBufferSize > MaxReadBufferSize)
   {
      fprintf (stdout, "%%%s-E-BUFFER, maximum buffer size is %d bytes\n",
               Utility, MaxReadBufferSize);
      exit (STS$K_ERROR | STS$M_INHIB_MSG);
   }

   if (SpecifiedPathPtr[0])
   {
      cptr = SpecifiedPathPtr;
      if (strsame (cptr, "http://", 7)) cptr += 7;
      sptr = ServerHost;
      while (*cptr && *cptr != ':' && *cptr != '/') *sptr++ = *cptr++;
      *sptr = '\0';
      if (*cptr == ':')
      {
         cptr++;
         if (isdigit(*cptr)) ServerPort = atoi(cptr);
         while (*cptr && isdigit(*cptr)) cptr++;
      }
      SpecifiedPathPtr = cptr;
   }
   else
   if (CliServerHostPtr[0])
   {
      sptr = ServerHost;
      for (cptr = CliServerHostPtr; *cptr && *cptr != ':'; *sptr++ = *cptr++);
      *sptr = '\0';
      if (*cptr && isdigit(*(cptr+1))) ServerPort = atoi(cptr+1);
   }
   else
   {
      /* assume the local host is the server */
      if (gethostname (ServerHost, sizeof(ServerHost)))
         status = SS$_NOSUCHNODE;
      if (VMSnok (status))
      {
         fprintf (stdout, "%%%s-E-SERVER, \"%s\" %s\n",
                  Utility, ServerHost, ErrorMessage(status));
         exit (STS$K_ERROR | STS$M_INHIB_MSG);
      }
      if (Debug) fprintf (stdout, "ServerHost |%s|\n", ServerHost);
   }
   if (!ServerPort) ServerPort = 80;
   if (Debug) fprintf (stdout, "|%s:%d|\n", ServerHost, ServerPort);

   if (CliProxyServerHostPtr[0])
   {
      sptr = ProxyServerHost;
      for (cptr = CliProxyServerHostPtr;
           *cptr && *cptr != ':';
           *sptr++ = *cptr++);
      *sptr = '\0';
      if (*cptr && isdigit(*(cptr+1))) ProxyServerPort = atoi(cptr+1);
      if (!ProxyServerPort) ProxyServerPort = 8080;
      sprintf (HttpProxyServer, "http://%s:%d", ServerHost, ServerPort);
      if (Debug) fprintf (stdout, "%s\n", HttpProxyServer);
   }

   /* get the server host address details */
   if (ProxyServerHost[0])
      ServerHostEntryPtr = gethostbyname (cptr = ProxyServerHost);
   else
      ServerHostEntryPtr = gethostbyname (cptr = ServerHost);
   if (ServerHostEntryPtr == NULL)
   {
      fprintf (stdout, "%%%s-E-SERVER, \"%s\" %s\n",
               Utility, cptr, ErrorMessage(status = vaxc$errno));
      exit (status | STS$M_INHIB_MSG);
   }
   ServerSocketName.sin_family = ServerHostEntryPtr->h_addrtype;
   if (ProxyServerHost[0])
      ServerSocketName.sin_port = htons (ProxyServerPort);
   else
      ServerSocketName.sin_port = htons (ServerPort);
   ServerSocketName.sin_addr = *((struct in_addr *)ServerHostEntryPtr->h_addr);

   strcpy (cptr, ServerHostEntryPtr->h_name);

   if (Debug) fprintf (stdout, "server/proxy |%s|\n", cptr);

   /* looks better if its all in lower case (host name is sometimes upper) */
   for (/* above */; *cptr; cptr++) *cptr = tolower(*cptr);

   if (OutFileNamePtr[0])
   {
      fclose (stdout);
      if ((stdout = fopen (OutFileNamePtr, "w")) == NULL)
         exit (vaxc$errno);
   }
   else
   if (!NoOutput)
      Output = stdout;

   ReportParameters ();

   ConnectionErrorCount =
      ConnectionCount =
      GetMethodCount =
      HeadMethodCount =
      HttpReadErrorCount,
      HttpRequestErrorCount,
      OutstandingConnections =
      StatusCodeErrorCount =
      TotalBytesReceived =
      TotalBytesSent = 0;

   memset (&StatusCodeCount, 0, sizeof(StatusCodeCount));

   /* initialize statistics timer */
   if (VMSnok (status = lib$init_timer (&TotalStatTimerContext)))
      exit (status);

   GenerateConnections ();

   ReportTotals ();
}

/*****************************************************************************/
/*
*/
 
ReportParameters ()

{
   fprintf (stdout, "\n$ WWWRKOUT \"http://%s:%d%s\"",
            ServerHost, ServerPort, SpecifiedPathPtr);

   if (ProxyServerHost[0])
      fprintf (stdout, " /PROXY=%s:%d", ProxyServerHost, ProxyServerPort);

   fprintf (stdout, " /SIMULTANEOUS=%d /COUNT=%d /BUFFER=%d",
            SpecifiedSimultaneous, SpecifiedCount, ReadBufferSize);

   if (VaryBufferSize)
      fprintf (stdout, " /VARY");
   else
      fprintf (stdout, " /NOVARY");

   if (DoBrokenConnections)
      fprintf (stdout, " /BREAK");
   else
      fprintf (stdout, " /NOBREAK");

   if (EffectiveTransferRate)
      fprintf (stdout, " /EFFECTIVE");
   else
      fprintf (stdout, " /NOEFFECTIVE");

   fprintf (stdout, "\n");
}

/*****************************************************************************/
/*
*/
 
ReportTotals ()

{
   int  status,
        BytesPerSecond,
        Code,
        MilliSeconds,
        RequestsPerSecond;
   unsigned long  ElapsedBinTime [2];
   float  ElapsedTimeFloat,
          FloatRate;

   /*********/
   /* begin */
   /*********/

   if (VMSnok (status =
       lib$stat_timer (&StatTimerElapsedTime,
                       &ElapsedBinTime,
                       &TotalStatTimerContext)))
      exit (status);

   if (VMSnok (status =
       lib$cvtf_from_internal_time (&CvtTimeFloatSeconds,
                                    &ElapsedTimeFloat,
                                    &ElapsedBinTime)))
      exit (status);

   if (ElapsedTimeFloat > 0.0)
   {
      BytesPerSecond = (int)((float)(TotalBytesReceived + TotalBytesSent) /
                             ElapsedTimeFloat);

      FloatRate = (float)ConnectionCount / ElapsedTimeFloat;
      RequestsPerSecond = (int)FloatRate;
      if (FloatRate - (float)RequestsPerSecond >= 0.5) RequestsPerSecond++;
   }
   else
      BytesPerSecond = RequestsPerSecond = 0;

   MilliSeconds = (int)(ElapsedTimeFloat * 1000.0);
   SetLocalSymbol ("WWWRKOUT_MILLISECONDS", NULL, MilliSeconds);
   SetLocalSymbol ("WWWRKOUT_CONNECTIONS", NULL, ConnectionCount);
   SetLocalSymbol ("WWWRKOUT_REQUEST_PER_SECOND", NULL, RequestsPerSecond);
   SetLocalSymbol ("WWWRKOUT_BYTES_PER_SECOND", NULL, BytesPerSecond);
   SetLocalSymbol ("WWWRKOUT_000", NULL, StatusCodeCount[0]);
   SetLocalSymbol ("WWWRKOUT_100", NULL, StatusCodeCount[1]);
   SetLocalSymbol ("WWWRKOUT_200", NULL, StatusCodeCount[2]);
   SetLocalSymbol ("WWWRKOUT_300", NULL, StatusCodeCount[3]);
   SetLocalSymbol ("WWWRKOUT_400", NULL, StatusCodeCount[4]);
   SetLocalSymbol ("WWWRKOUT_500", NULL, StatusCodeCount[5]);

   fprintf (stdout,
"\n\
Elapsed: %.3f  Connections: %d  Deliberately Broken: %d\n\
     Tx: %d  Rx: %d  Rate: %d request/S  %d byte/S\n\
    GET: %d  HEAD: %d\n\
Connect: %d  Request: %d  Read: %d (failures)\n",
   ElapsedTimeFloat, ConnectionCount, DoBrokenConnectionCount,
   TotalBytesSent, TotalBytesReceived, RequestsPerSecond, BytesPerSecond,
   GetMethodCount, HeadMethodCount,
   ConnectionErrorCount, HttpRequestErrorCount, HttpReadErrorCount);

   fprintf (stdout, " Errors: %d", StatusCodeErrorCount);
   for (Code = 0; Code <= 9; Code++)
      if (StatusCodeCount[Code])
         fprintf (stdout, "  %dXX: %d", Code, StatusCodeCount[Code]);
   fprintf (stdout, "\n");

   MetricArray[MetricIndex].TotalElapsedTimeFloat += ElapsedTimeFloat;
   MetricArray[MetricIndex].TotalConnectionsFloat += (float)ConnectionCount;
   MetricArray[MetricIndex].TotalBytesFloat += (float)(TotalBytesReceived +
                                                       TotalBytesSent);
}

/*****************************************************************************/
/*
Loop through the specified number of connections (or attempts thereof).  
Maintain, as best it can be, the specified number of simultaneous connections.  
If a connection attempt fails just quit there for that particular loop, leave 
a bit of time (as reads occur) to allow the server to recover.
*/
 
GenerateConnections ()

{
   register struct ConnectionStruct  *cxptr;

   int  status,
        Count;

   /*********/
   /* begin */
   /*********/

   /* dynamically allocate the specified number of connection structures */
   for (Count = 0; Count < SpecifiedSimultaneous; Count++)
   {
      if ((cxptr = calloc (1, sizeof(struct ConnectionStruct))) == NULL)
         exit (vaxc$errno);
      if (Debug) fprintf (stdout, "cxptr: %d\n", cxptr);
      cxptr->NextPtr = NULL;
      if (ConnectionListPtr == NULL)
         ConnectionListPtr = cxptr;
      else
         LastConnectionPtr->NextPtr = cxptr;
      LastConnectionPtr = cxptr;
   }

   /******************************************************/
   /* loop for the total number of connections specified */
   /******************************************************/

   sys$setast (0);

   for (cxptr = ConnectionListPtr; cxptr != NULL; cxptr = cxptr->NextPtr)
       sys$dclast (ConnectToServer, cxptr, 0);

   sys$setast (1);

   sys$hiber ();

   for (cxptr = ConnectionListPtr; cxptr != NULL; cxptr = cxptr->NextPtr)
      free (cxptr);
   ConnectionListPtr = NULL;
}

/*****************************************************************************/
/*
Loop through the specified number of connections (or attempts thereof).  
Maintain, as best it can be, the specified number of simultaneous connections.  
If a connection attempt fails just quit there for that particular loop, leave 
a bit of time (as reads occur) to allow the server to recover.
*/
 
ConnectToServer (struct ConnectionStruct *cxptr)

{
   int  status;
   unsigned short  NumTime [7];
   unsigned long  BinTime [2];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ConnectToServer() cxptr: %d\n", cxptr);

   if (ConnectionCount >= SpecifiedCount)
   {
      if (!OutstandingConnections) sys$wake (0, 0);
      return;
   }
   ConnectionCount++;
   OutstandingConnections++;

   memset (cxptr, 0, sizeof(struct ConnectionStruct));
   cxptr->ConnectionNumber = ConnectionCount;
   cxptr->ByteCount = 0;

   if (VaryBufferSize)
   {
      /* adjust the buffer size using a pseudo-random value */
      sys$gettim (&BinTime);
      sys$numtim (&NumTime, &BinTime);
      cxptr->ReadBufferSize = ReadBufferSize / ((NumTime[6] & 3) + 1);
   }
   else
      cxptr->ReadBufferSize = ReadBufferSize;

   cxptr->Channel = 0;

   /* initialize timer */
   if (VMSnok (status = lib$init_timer (&cxptr->StatTimerContext)))
      exit (status);

   /* assign a channel to the internet template device */
   if (VMSnok (status = sys$assign (&InetDeviceDsc, &cxptr->Channel, 0, 0)))
   {
      fprintf (stdout, "assign() error; #%d, %s\n",
               ConnectionCount, ErrorMessage(status));
      cxptr->Channel = 0;
      exit (status);
   }

   /* make the channel a TCP, connection-oriented socket */

   if (Debug) fprintf (stdout, "sys$qiow() IO$_SETMODE\n");
   status = sys$qiow (0, cxptr->Channel, IO$_SETMODE, &cxptr->IOsb, 0, 0,
                      &TcpSocket, 0, 0, 0, &ReuseAddressSocketOption, 0);

   if (Debug)
      fprintf (stdout, "sys$qiow() %%X%08.08X IOsb %%X%08.08X\n",
               status, cxptr->IOsb.Status);
   if (VMSok (status) && VMSnok (cxptr->IOsb.Status))
      status = cxptr->IOsb.Status;
   if (VMSnok (status)) exit (status);

   status = sys$qio (0, cxptr->Channel, IO$_ACCESS, &cxptr->IOsb,
                     &ConnectToServerAst, cxptr,
                     0, 0, &ServerSocketNameItem, 0, 0, 0);
   if (Debug)
      fprintf (stdout, "sys$qiow() %%X%08.08X IOsb %%X%08.08X\n",
               status, cxptr->IOsb.Status);
}

/*****************************************************************************/
/*
Connection to server has completed, either successfully or unsuccessfully!
*/
 
ConnectToServerAst (struct ConnectionStruct *cxptr)

{
   int  status,
        RequestLength;
   unsigned short  CurrentNumTime [7];
   unsigned long  CurrentBinTime [2];

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "ConnectToServerAst() IOsb %%X%08.08X\n",
               cxptr->IOsb.Status);

   status = cxptr->IOsb.Status;

   if (VMSnok (status))
   {
      /*****************/
      /* connect error */
      /*****************/

      fprintf (Output, "connect error; #%d %s\n",
               cxptr->ConnectionNumber, ErrorMessage(status));
      HttpRequestErrorCount++;
      if (ConnectionErrorCount++ > MAX_CONNECTION_ERROR_COUNT)
      {
         ReportTotals ();
         exit (SS$_NORMAL);
      }

      /* free timer */
      if (VMSnok (status = lib$free_timer (&cxptr->StatTimerContext)))
         exit (status);

      /* close current then re-initiate a new connection */
      CloseConnection (cxptr);
      ConnectToServer (cxptr);

      return;
   }

   /****************/
   /* send request */
   /****************/

   sys$gettim (&CurrentBinTime);
   sys$numtim (&CurrentNumTime, &CurrentBinTime);

   /* create and send a moderate size HTTP request */
   GetPath (cxptr->Path, sizeof(cxptr->Path));

   if (DoHeadMethod && !(CurrentNumTime[6] % 10))
   {
      HeadMethodCount++;
      cxptr->MethodPtr = "HEAD";
      RequestLength = sprintf (cxptr->Request,
"HEAD %s%s HTTP/1.0\r\n\
User-Agent: %s\r\n\
Host: %s\r\n\
Accept: */*\r\n\
\r\n",
         HttpProxyServer, cxptr->Path, SoftwareID, CliServerHostPtr);
      if (Debug) fprintf (stdout, "cxptr->Request |%s|\n", cxptr->Request);
   }
   else
   {
      GetMethodCount++;
      cxptr->MethodPtr = "GET";
      RequestLength = sprintf (cxptr->Request,
"GET %s%s HTTP/1.0\r\n\
User-Agent: %s\r\n\
Host: %s\r\n\
Accept: */*\r\n\
\r\n",
         HttpProxyServer, cxptr->Path, SoftwareID, CliServerHostPtr);
      if (Debug) fprintf (stdout, "cxptr->Request |%s|\n", cxptr->Request);
   }

   TotalBytesSent += RequestLength;

   status = sys$qio (0, cxptr->Channel,
                     IO$_WRITEVBLK, &cxptr->IOsb, WriteRequestAst, cxptr,
                     cxptr->Request, RequestLength, 0, 0, 0, 0);
   if (Debug)
      fprintf (stdout, "sys$qio() %%X%08.08X IOsb: %%X%08.08X\n",
               status, cxptr->IOsb.Status);
}

/*****************************************************************************/
/*
*/
 
WriteRequestAst (struct ConnectionStruct *cxptr)

{
   int  status,
        BytesPerSecond;
   unsigned short  CurrentNumTime [7];
   unsigned long  CurrentBinTime [2],
                  ElapsedBinTime [2];
   float  ElapsedTimeFloat;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "WriteRequestAst() IOsb: %%X%08.08X\n",
               cxptr->IOsb.Status);

   status = cxptr->IOsb.Status;

   if (VMSnok (status))
   {
      /***************/
      /* write error */
      /***************/

      fprintf (Output, "write error; #%d \"%s\", %s\n",
               cxptr->ConnectionNumber, cxptr->Path, ErrorMessage(status));
      HttpRequestErrorCount++;

      /* free timer */
      if (VMSnok (status = lib$free_timer (&cxptr->StatTimerContext)))
         exit (status);

      /* close current then re-initiate a new connection */
      CloseConnection (cxptr);
      ConnectToServer (cxptr);

      return;
   }

   if (DoNoRead) return;

   /*****************/
   /* read response */
   /*****************/

   status = sys$qio (0, cxptr->Channel,
                      IO$_READVBLK, &cxptr->IOsb,
                      ReadResponseAst, cxptr,
                      cxptr->ReadBuffer, cxptr->ReadBufferSize, 0, 0, 0, 0);

   if (Debug)
      fprintf (stdout, "sys$qio() %%X%08.08X IOsb: %%X%08.08X\n",
               status, cxptr->IOsb.Status);
}

/*****************************************************************************/
/*
A read from the server has completed.  Check it's status.  If complete
(disconnected) then report.  If not complete the queue to read more.
*/
 
ReadResponseAst (struct ConnectionStruct *cxptr)

{
   static boolean  OneConnectionBroken;

   register char  *cptr, *sptr, *zptr;

   int  status,
        BytesPerSecond;
   unsigned short  CurrentNumTime [7];
   unsigned long  CurrentBinTime [2],
                  ElapsedBinTime [2];
   float  ElapsedTimeFloat;

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "ReadResponseAst() IOsb: %%X%08.08X Bytes: %d\n",
               cxptr->IOsb.Status, cxptr->IOsb.Count);

   status = cxptr->IOsb.Status;

   if (VMSnok (status))
   {
      /*********/
      /* error */
      /*********/

      if (status == SS$_LINKDISCON)
      {
         /****************************/
         /* server closed connection */
         /****************************/

         if (VMSnok (status =
             lib$stat_timer (&StatTimerElapsedTime,
                             &ElapsedBinTime,
                             &cxptr->StatTimerContext)))
            exit (status);

         if (VMSnok (status =
             lib$cvtf_from_internal_time (&CvtTimeFloatSeconds,
                                          &ElapsedTimeFloat,
                                          &ElapsedBinTime)))
         {
            if (status == LIB$_DELTIMREQ)
               ElapsedTimeFloat = 0.000001;
            else
               exit (status);
         }

         BytesPerSecond = (int)((float)cxptr->ByteCount / ElapsedTimeFloat);

         fprintf (Output,
         "end;    #%d \"%s %s\", %d bytes in %.1f seconds (%d/S, size: %d)\n",
            cxptr->ConnectionNumber, cxptr->MethodPtr, cxptr->Path,
            cxptr->ByteCount,
            ElapsedTimeFloat, BytesPerSecond, cxptr->ReadBufferSize);
      }
      else
      {
         /**************/
         /* read error */
         /**************/

         fprintf (Output, "read error; #%d \"%s\", after %d bytes, %s\n",
                  cxptr->ConnectionNumber, cxptr->Path,
                  cxptr->ByteCount, ErrorMessage(status));
         HttpReadErrorCount++;
      }

      TotalBytesReceived += cxptr->ByteCount;

      /* free timer */
      if (VMSnok (status = lib$free_timer (&cxptr->StatTimerContext)))
         exit (status);

      /* close current then re-initiate a new connection */
      CloseConnection (cxptr);
      ConnectToServer (cxptr);

      return;
   }

   sys$gettim (&CurrentBinTime);
   sys$numtim (&CurrentNumTime, &CurrentBinTime);

   if (DoBrokenConnections && CurrentNumTime[6] == 5 && !OneConnectionBroken)
   {
      /*********************************/
      /* deliberately break connection */
      /*********************************/

      if (VMSnok (status =
          lib$stat_timer (&StatTimerElapsedTime,
                          &ElapsedBinTime,
                          &cxptr->StatTimerContext)))
         exit (status);

      if (VMSnok (status =
          lib$cvtf_from_internal_time (&CvtTimeFloatSeconds,
                                       &ElapsedTimeFloat,
                                       &ElapsedBinTime)))
      {
         if (status == LIB$_DELTIMREQ)
            ElapsedTimeFloat = 0.000001;
         else
            exit (status);
      }

      fprintf (Output,
"end;    #%d \"%s %s\", DELIBERATELY BROKEN after %.1f seconds and %d bytes\n",
         cxptr->ConnectionNumber, cxptr->MethodPtr, cxptr->Path,
         ElapsedTimeFloat, cxptr->ByteCount);

      OneConnectionBroken = true;
      DoBrokenConnectionCount++;

      /* free timer */
      if (VMSnok (status = lib$free_timer (&cxptr->StatTimerContext)))
         exit (status);

      /* close current then re-initiate a new connection */
      CloseConnection (cxptr);
      ConnectToServer (cxptr);

      return;
   }

   if (DoBrokenConnections && CurrentNumTime[6] && OneConnectionBroken)
      OneConnectionBroken = false;

   if (!cxptr->ByteCount)
   {
      /************************/
      /* HTTP response header */
      /************************/

      if (VMSnok (status =
          lib$stat_timer (&StatTimerElapsedTime,
                          &ElapsedBinTime,
                          &cxptr->StatTimerContext)))
         exit (status);

      if (VMSnok (status =
          lib$cvtf_from_internal_time (&CvtTimeFloatSeconds,
                                       &ElapsedTimeFloat,
                                       &ElapsedBinTime)))
      {
         if (status == LIB$_DELTIMREQ)
            ElapsedTimeFloat = 0.000001;
         else
            exit (status);
      }

      /* (assumes first line is all in buffer!) */
      zptr = (cptr = cxptr->ReadBuffer) + cxptr->IOsb.Count;
      while (cptr < zptr && *cptr != '\r' && *cptr != '\n') cptr++;
      if (cptr < zptr)
      {
         *cptr = '\0';

         /* skip over "HTTP/n.n" and spaces to get 3 digit status code */
         cptr = cxptr->ReadBuffer;
         while (*cptr && !isspace(*cptr)) cptr++;
         while (isspace(*cptr)) cptr++;
         /* increment the counter corresponding to the first digit */
         if (isdigit(*cptr))
            StatusCodeCount[*cptr-'0']++;
         else
            StatusCodeErrorCount++;

         fprintf (Output, "header; #%d \"%s %s\", in %.1f seconds \"%s\"\n",
                  cxptr->ConnectionNumber, cxptr->MethodPtr, cxptr->Path,
                  ElapsedTimeFloat, cxptr->ReadBuffer);
      }
      else
      {
         fprintf (Output,
"header error (buffer too small); #%d \"%s\", in %.1f seconds\n",
         cxptr->ConnectionNumber, cxptr->Path, ElapsedTimeFloat);
      }
   }

   cxptr->ByteCount += cxptr->IOsb.Count;

   /**********************/
   /* read more response */
   /**********************/

   status = sys$qio (0, cxptr->Channel,
                      IO$_READVBLK, &cxptr->IOsb,
                      ReadResponseAst, cxptr,
                      cxptr->ReadBuffer, cxptr->ReadBufferSize, 0, 0, 0, 0);

   if (Debug)
      fprintf (stdout, "sys$qio() %%X%08.08X IOsb: %%X%08.08X\n",
               status, cxptr->IOsb.Status);
}

/****************************************************************************/
/*
*/

CloseConnection (struct ConnectionStruct *cxptr)

{
   int  status;
   struct  AnIOsb  IOsb;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "NetCloseConnection() %d\n", cxptr->Channel);

   status = sys$dassgn (cxptr->Channel);
   if (Debug) fprintf (stdout, "sys$dassgn() %%X%08.08X\n", status);

   cxptr->Channel = 0;
   if (OutstandingConnections) OutstandingConnections--;
}

/*****************************************************************************/
/*
*/
 
GetPath
(
char *PathPtr,
int SizeOfPath
)
{
   static FILE  *PathFile = NULL;

   register char  *cptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "GetPath()\n");

   if (SpecifiedPathPtr[0])
   {
      strcpy (PathPtr, SpecifiedPathPtr);
      return;
   }

   if (!PathFileNamePtr[0])
   {
      /* if no file name has been specified get the server welcome document */
      PathPtr[0] = '/';
      PathPtr[1] = '\0';
      return;
   }

   if (PathFile == NULL)
      if ((PathFile = fopen (PathFileNamePtr, "r")) == NULL)
         exit (vaxc$errno);

   *PathPtr = '\0';
   for (;;)
   {
      if (fgets (PathPtr, 256, PathFile) == NULL)
      {
         rewind (PathFile);
         if (fgets (PathPtr, SizeOfPath, PathFile) == NULL)
         exit (vaxc$errno);
      }
      if (*PathPtr != '#' && *PathPtr != '!') break;
   }

   for (cptr = PathPtr; *cptr && *cptr != '\n'; cptr++);
   *cptr = '\0';
   if (Debug) fprintf (stdout, "PathPtr |%s|\n", PathPtr);
}

/****************************************************************************/
/*
Assign a global symbol.  If the string pointer is null the numeric value is
used.  Symbol values are a maximum of 255 characters.
*/ 

SetLocalSymbol
(
char *Name,
char *String,
int Value
)
{
   static int  LocalSymbol = LIB$K_CLI_LOCAL_SYM;
   static char  ValueString [32];
   static $DESCRIPTOR (SymbolValueDsc, "");
   static $DESCRIPTOR (ValueFaoDsc, "!UL");
   static $DESCRIPTOR (ValueStringDsc, ValueString);

   int  status;
   $DESCRIPTOR (SymbolNameDsc, Name);

   /*********/
   /* begin */
   /*********/

   if (Debug)
      fprintf (stdout, "SetLocalSymbol() |%s|%s| %d\n",
               Name, String, Value);

   SymbolNameDsc.dsc$w_length = strlen(Name);
   if (String == NULL)
   {
      SymbolValueDsc.dsc$a_pointer = ValueString;
      sys$fao (&ValueFaoDsc, &SymbolValueDsc.dsc$w_length, &ValueStringDsc,
               Value);
      ValueString[SymbolValueDsc.dsc$w_length] = '\0';
   }
   else
   {
      SymbolValueDsc.dsc$a_pointer = String;
      SymbolValueDsc.dsc$w_length = strlen(String);
      if (SymbolValueDsc.dsc$w_length > 255)
         SymbolValueDsc.dsc$w_length = 255;
   }

   if (VMSnok (status =
       lib$set_symbol (&SymbolNameDsc, &SymbolValueDsc, &LocalSymbol)))
      exit (status);
}

/*****************************************************************************/
/*
*/
 
int ShowHelp ()
 
{
   fprintf (stdout,
"%%%s-I-HELP, usage for the WWWRKOUT utility (%s)\n\
\n\
Test utility for HTTP server.  Sets up and maintains a specified number of\n\
concurrent connections.  Reads a buffer of data from each connection in\n\
turn until the document requested is exhausted.  Then closes that connection\n\
and initiates another.  The document paths should be specified one per line\n\
in a plain text file, each path and/or type specified should be different to\n\
the others.   Any number of paths may be specified in the file with the\n\
paths continually recycled from the first.  If a file of paths is not\n\
specified the utility just continually requests the welcome document.\n\
\n\
$ WWWRKOUT [server_host_name[:port]] [document_path] [qualifiers ...]\n\
\n\
/[NO]BREAK(d) /BUFFER=integer /COUNT=integer /[NO]EFFECTIVE(d) /[NO]HEAD(d)\n\
/HELP /[NO]OUTPUT=file_name /PATH=document_path /PROXY=host_name:port\n\
/SERVER=host_name:port /SIMULTANEOUS=integer /FILEOF=file_name /[NO]VARY(d)\n\
\n\
Usage examples:\n\
$ WWWRKOUT\n\
$ WWWRKOUT WWW.SERVER.HOST:8080\n\
$ WWWRKOUT /SERVER=WWW.SERVER.HOST:8000 /FILEOF=PATHS.TXT\n\
$ WWWRKOUT WWW.SERVER.HOST /FILEOF=PATHS.TXT /COUNT=500 /SIMUL=20 /BUFFER=512\n\
\n",
   Utility, SoftwareID);
 
   return (SS$_NORMAL);
}
 
/*****************************************************************************/
/*
*/

char* ErrorMessage (int VmsStatus)

{
   static char  Message [256];

   short int  Length;
   $DESCRIPTOR (MessageDsc, Message);

   /*********/
   /* begin */
   /*********/

   Message[0] = '\0';
   if (VmsStatus)
   {
      /* text component only */
      sys$getmsg (VmsStatus, &Length, &MessageDsc, 1, 0);
      Message[Length] = '\0';
   }
   if (Message[0])
      return (Message);
   else
      return ("(internal error)");
}
 
/*****************************************************************************/
/*
*/

char* SysGetMsg (int StatusValue)

{
   static char  Message [256];
   register int  status;
   short int  Length;
   $DESCRIPTOR (MessageDsc, Message);

   if (VMSok (status = sys$getmsg (StatusValue, &Length, &MessageDsc, 0, 0))) 
      Message[Length] = '\0';
   else
      sprintf (Message, "%%sys$getmsg() %%X%08.08X", status);

   return (Message);
}

/****************************************************************************/
/*
Does a case-insensitive, character-by-character string compare and returns 
true if two strings are the same, or false if not.  If a maximum number of 
characters are specified only those will be compared, if the entire strings 
should be compared then specify the number of characters as 0.
*/ 
 
boolean strsame
(
register char *sptr1,
register char *sptr2,
register int  count
)
{
   while (*sptr1 && *sptr2)
   {
      if (toupper (*sptr1++) != toupper (*sptr2++)) return (false);
      if (count)
         if (!--count) return (true);
   }
   if (*sptr1 || *sptr2)
      return (false);
   else
      return (true);
}
 
/****************************************************************************/
