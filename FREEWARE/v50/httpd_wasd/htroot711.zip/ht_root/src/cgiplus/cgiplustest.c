/*****************************************************************************/
/*
                              CGIplusTest.c

Script for testing the relative efficiencies of CGI and CGIplus.
Also for scripting benchmarks between the WASD, OSU and Apache environments!

This script can detect whether it is in a CGI or CGIplus environment and
adjust behaviour accordingly.  Call using the AB (ApcheBench) utility in both
environments to test throughput and response latency performance in both.
For WASD and OSU this script re-opens <stdout> in binary-mode, hence the full
HTTP response.  For Apache it leaves it in record-mode and uses a CGI response. 
Requires the CGI environment variables to be available as symbols.

September 2000 Note: Apache 1.3-12 seems intent on adding a <CR><LF> to each
record received, distorting the content-length and generally causing problems. 
This seems to lead to ApacheBench reporting errors, including length issues.

Can also be used as example code for working in both environments.
Demonstrates the alternative mechanism for accessing CGIplus variable values,
reading from <stdin> and parsing each line for required variables.  Also see
CGIplusSkeleton.c for the more spohisticated, general-purpose function.


VERSION HISTORY (update SoftwareID as well!)
---------------
11-JAN-2001  MGD  v1.3.0, CSWS V1.0-1 (Apache) "fixbg" support
23-SEP-2000  MGD  v1.2,0, minor mods for comparison with VMS Apache
05-MAR-1999  MGD  v1.1.0, minor mods for comparison with OSU
08-JUN-1997  MGD  v1.0.0, initial development
*/
/*****************************************************************************/

#ifdef __ALPHA
   char SoftwareID [] = "CGIPLUSTEST AXP-1.3.0";
#else
   char SoftwareID [] = "CGIPLUSTEST VAX-1.3.0";
#endif

/* standard C headers */
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>

/* VMS headers */
#include <descrip.h>
#include <ssdef.h>

int  ApacheEnvironment,
     Debug,
     IsCgiPlus,
     OsuEnvironment;

char  *CgiPlusEofPtr,
      *CgiServerSoftwarePtr;

char  Utility [] = "CGIPLUSTEST",
      Line80Chars [] =
"ABCDEFGHIJKLMNOPQRSTUVWXYZ\
abcdefghijklmnopqrstuvwxyz\
0123456789\
!@#$%^&*()_+-=<>,\n";

/* function prototypes */
int ApacheFixBgHandler ();
void ApacheFixBg ();
void AtOsuExit ();

/*****************************************************************************/
/*
*/

main ()

{
   register char  *cptr;

   int  RequestedCount;

   /*********/
   /* begin */
   /*********/

   if ((CgiServerSoftwarePtr = getenv ("WWW_SERVER_SOFTWARE")) == NULL)
      if ((CgiServerSoftwarePtr = getenv ("SERVER_SOFTWARE")) == NULL)
         CgiServerSoftwarePtr = "?";

   if (getenv ("WWWEXEC_RUNDOWN_STRING") != NULL)
   {
      OsuEnvironment = 1;
      atexit (&AtOsuExit);
   }
   else
   {
      if (getenv ("APACHE_SHARED_SOCKET") != NULL)
      ApacheEnvironment = 1;
   }
   
   if (getenv ("CGIPLUSTEST$DBUG") != NULL) Debug = 1;

   if (Debug)
   {
      /* won't work for OSU! */
      fprintf (stdout, "Content-Type: text/plain\r\n\r\n");
      system ("show sym *");
   }
   else
   {
      /* OSU spits with output > 4096 */
      if (OsuEnvironment)
      {
         stdout = freopen ("SYS$OUTPUT", "w", stdout, "ctx=bin", "mrs=4096");
         fprintf (stdout, "<DNETCGI>");
         fflush (stdout);
      }
      else
      if (ApacheEnvironment)
      {
         ApacheFixBg ();
         stdout = freopen ("SYS$OUTPUT", "w", stdout, "ctx=bin", "mrs=4096");
      }
      else
         stdout = freopen ("SYS$OUTPUT", "w", stdout, "ctx=bin");
      if (stdout == NULL) exit (vaxc$errno);
   }

   IsCgiPlus = ((CgiPlusEofPtr = getenv("CGIPLUSEOF")) != NULL);

   /* do once for standard CGI, multiple times for CGIplus */

   do {

      if (IsCgiPlus)
      {
         /* called as a CGIplus script */
         RequestedCount = CgiPlusCount ();
      }
      else
      {
         /* called as a standard CGI script */
         if ((cptr = getenv ("WWW_QUERY_STRING")) == NULL)
            if ((cptr = getenv ("QUERY_STRING")) == NULL)
               cptr = "";
         if (isdigit(*cptr))
            RequestedCount = atoi(cptr);
         else
            RequestedCount = -1;
      }

      fprintf (stdout,
"Content-Type: text/plain\r\n\
Content-Length: %d\r\n\
Script-Control: X-stream-mode\r\n\
Expires: Fri, 13 Jan 1978 14:00:00 GMT\r\n\
\r\n",
         RequestedCount * (sizeof(Line80Chars)-1));

      if (RequestedCount < 0)
      {
         fprintf (stdout,
"Usage: Supply a URL with a query string containing \
an integer representing the number of 80 character lines \
to be returned during the test.\n");
      }
      else
      {
         while (RequestedCount--)
            fputs (Line80Chars, stdout);
      }

      if (IsCgiPlus)
      {
         /* the CGIplus EOF must be an independant I/O record */
         fflush (stdout);
         fprintf (stdout, "%s", CgiPlusEofPtr);
         fflush (stdout);
      }

   } while (IsCgiPlus);

   exit (1);
}

/*****************************************************************************/
/*
Script executing in OSU environment exits.
*/

void AtOsuExit ()

{
   if (Debug)
      fprintf (stdout, "</DNETTEXT>\n");
   else
   {
      fflush (stdout);
      fprintf (stdout, "</DNETCGI>");
      fflush (stdout);
   }
}

/*****************************************************************************/
/*
According to "Compaq Secure Web Server Version 1.0-1 for OpenVMS Alpha (based
on Apache) Version 1.0-1 Release Notes" this is required to support the
transfer of any binary content in excess of 32 kbytes.  This is based on a code
snippet in these release notes, but makes the image activation and symbol
resolution dynamic to allow the object module to be linked on systems without
VMS Apache and the APACHE$FIXBG.EXE shareable image available.
*/

void ApacheFixBg ()

{
   $DESCRIPTOR (StdOutputDsc, "SYS$OUTPUT");
   $DESCRIPTOR (ApacheFixBgImageDsc, "APACHE$FIXBG");
   $DESCRIPTOR (ApacheFixBgDsc, "APACHE$FIXBG");

   int  status;
   unsigned short  SysOutputChannel;
   int (*ApacheFixBg)(unsigned short, int);

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ApacheFixBg()\n");

   lib$establish (ApacheFixBgHandler);
   status = lib$find_image_symbol (&ApacheFixBgImageDsc, &ApacheFixBgDsc,
                                   &ApacheFixBg, 0);
   if (Debug)
      fprintf (stdout, "lib$find_image_symbol() %%X%08.08X\n", status);
   lib$revert ();
   if (!(status & 1)) exit (status);

   status = sys$assign (&StdOutputDsc, &SysOutputChannel, 0, 0);
   if (status & 1) status = ApacheFixBg (SysOutputChannel, 1);
   if (!(status & 1)) exit (status);
   sys$dassgn (SysOutputChannel);
}

/*****************************************************************************/
/*
Just continue, to report an error if the image couldn't be activated or the
required symbol not found.
*/

int ApacheFixBgHandler ()

{
   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ApacheFixBgHandler()\n");

   return (SS$_CONTINUE);
}

/*****************************************************************************/
/*
Use a simple loop to read lines from standard input.  Detect specific CGI
variables by checking the leading section of these lines for the required
variable name.  The value may then be extracted from the remaining section.
*/

int CgiPlusCount ()

{
#  define CGIPLUS_LINE_SIZE 1024

   register char  *cptr;

   int  Count;
   char  Line [CGIPLUS_LINE_SIZE];
   FILE  *SysCommand;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "CgiPlusCount()\n");

   Count = -1;

   if ((SysCommand = fopen (getenv("CGIPLUSIN"), "r")) == NULL)
      exit (vaxc$errno);

   for (;;)
   {
      if (fgets (Line, sizeof(Line), SysCommand) == NULL) exit (vaxc$errno);
      if (Debug) fprintf (stdout, "Line |%s|\n", Line);
      /* first empty line signals the end of CGIplus variables */
      if (Line[0] == '\n') break;
      /* remove the trailing newline */
      if ((cptr = strchr(Line, '\n')) != NULL) *cptr = '\0';

      if (!strncmp (Line, "WWW_QUERY_STRING=", 17))
         if (isdigit(Line[17])) Count = atoi(Line+17);
   }

   fclose (SysCommand);

   return (Count);
}

/*****************************************************************************/

