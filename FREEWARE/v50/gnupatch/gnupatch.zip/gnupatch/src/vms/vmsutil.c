/* OpenVMS utility routines for GNU patch
 *
 * my_utime(), my_trnlnm(), do_tovmsspec()
 *
 * Stolen from the VMSperl source by Martin Vorlaender <mv@pdv-systeme.de>
 * Um, that's actually GPB'd (GNU Public Borrowed) under the terms of the
 * GNU Public License.
 *
 *
 * my_rename(), my_creat(), pfatal_with_name(), vms_initialize_main()
 *
 * C RTL and patch utility routines replaced (or wrappered) by
 * Martin Vorlaender.
 *
 *
 * my_chmod(), my_exit(), my_fopen(), my_open(), my_stat(), my_unlink()
 * 
 * Wrapper routines added by Craig Berry based in part on code by Charles
 * Lane.
 *
 *
 * rmdir(), strncasecmp(), truncate()
 * 
 * Added by Charles Lane for older systems that don't have them.
 */

/* older compilers are better off using the OS version */
#if (!defined(__DECC_VER) || __DECC_VER < 50600000)
#   undef __CRTL_VER
#   define __CRTL_VER __VMS_VER
#endif

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <unixio.h>
#if __CRTL_VER < 70000000 || defined (LINK_TARGET_PRE7)
#include <stat.h>
#include <rms.h>
int truncate(const char *path, off_t length);
#endif

#include <atrdef.h>
#include <descrip.h>
#include <fabdef.h>
#include <fibdef.h>
#include <fscndef.h>
#include <iodef.h>
#include <lib$routines.h>
#include <libdef.h>
#include <lnmdef.h>
#include <namdef.h>
#include <rmsdef.h>
#include <ssdef.h>
#include <starlet.h>

/* Suppress compiler warnings from DECC for VMS-specific extensions:
 * ADDRCONSTEXT,NEEDCONSTEXT: initialization of data with non-constant values
 *                            (e.g. pointer fields of descriptors)
 */
#ifdef __DECC
#  pragma message disable (ADDRCONSTEXT,NEEDCONSTEXT)
#endif

/* disable informational message about time_t declarations in C 6.2 and later */
#if __DECC_VER > 60200000
#  pragma message disable (QUESTCOMPARE1)
#endif

/* Macros to set errno using the VAX thread-safe calls, if present */
#if (defined(__DECC) || defined(__DECCXX)) && !defined(__ALPHA)
#  define set_errno(v)      (cma$tis_errno_set_value(v))
   void cma$tis_errno_set_value(int __value);  /* missing in some errno.h */
#  define set_vaxc_errno(v) (vaxc$errno = (v))
#else
#  define set_errno(v)      (errno = (v))
#  define set_vaxc_errno(v) (vaxc$errno = (v))
#endif

/* Handy way to vet calls to VMS system services and RTL routines. */
#define _ckvmssts(call) { \
  register unsigned long int __ckvms_sts; \
  if (!((__ckvms_sts=(call))&1)) { \
    set_errno(EVMSERR); \
    set_vaxc_errno(__ckvms_sts); \
    fprintf(stderr, "Fatal VMS error (status=%d) at %s, line %d", \
            __ckvms_sts,__FILE__,__LINE__); \
  } \
}


#define safemalloc malloc
#define saferealloc realloc

#define New(x,v,n,t)	(v = (t*)safemalloc((n)*sizeof(t)))
#define Renew(v,n,t)    (v = (t*)saferealloc((v),(n)*sizeof(t)))


struct itmlst_3 {
  unsigned short int buflen;
  unsigned short int itmcode;
  void *bufadr;
  unsigned short int *retlen;
};

static int my_trnlnm(char *lnm, char *eqv, unsigned long int idx)
{
    static char __my_trnlnm_eqv[LNM$C_NAMLENGTH+1];
    unsigned short int eqvlen;
    int retsts;
    unsigned int attr = LNM$M_CASE_BLIND;
    $DESCRIPTOR(tabdsc,"LNM$FILE_DEV");
    struct dsc$descriptor_s lnmdsc = {0,DSC$K_DTYPE_T,DSC$K_CLASS_S,0};
    struct itmlst_3 lnmlst[3] = {{sizeof idx,      LNM$_INDEX,  &idx, 0},
                                 {LNM$C_NAMLENGTH, LNM$_STRING, 0,    &eqvlen},
                                 {0, 0, 0, 0}};

    if (!lnm || idx > LNM$_MAX_INDEX) {
      set_errno(EINVAL); set_vaxc_errno(SS$_BADPARAM); return 0;
    }
    if (!eqv) eqv = __my_trnlnm_eqv;
    lnmlst[1].bufadr = (void *)eqv;
    lnmdsc.dsc$a_pointer = lnm;
    lnmdsc.dsc$w_length = strlen(lnm);
    retsts = sys$trnlnm(&attr,&tabdsc,&lnmdsc,0,lnmlst);
    if (retsts == SS$_NOLOGNAM || retsts == SS$_IVLOGNAM) {
      set_vaxc_errno(retsts); set_errno(EINVAL); return 0;
    }
    else if (retsts & 1) {
      eqv[eqvlen] = '\0';
      return eqvlen;
    }
    _ckvmssts(retsts);  /* Must be an error */
    return 0;      /* Not reached, assuming _ckvmssts() bails out */
}


static char *do_tovmsspec(const char *path, char *buf, int ts) {
  static char __tovmsspec_retbuf[NAM$C_MAXRSS+1];
  char *rslt, *dirend;
  register char *cp1;
  register const char *cp2;
  unsigned long int infront = 0, hasdir = 1;

  if (path == NULL) return NULL;
  if (buf) rslt = buf;
  else if (ts) New(1316,rslt,strlen(path)+9,char);
  else rslt = __tovmsspec_retbuf;
  if (strpbrk(path,"]:>") ||
      (dirend = strrchr(path,'/')) == NULL) {
    if (path[0] == '.') {
      if (path[1] == '\0') strcpy(rslt,"[]");
      else if (path[1] == '.' && path[2] == '\0') strcpy(rslt,"[-]");
      else strcpy(rslt,path); /* probably garbage */
    }
    else strcpy(rslt,path);
    return rslt;
  }
  if (*(dirend+1) == '.') {  /* do we have trailing "/." or "/.." or "/..."? */
    if (!*(dirend+2)) dirend +=2;
    if (*(dirend+2) == '.' && !*(dirend+3)) dirend += 3;
    if (*(dirend+2) == '.' && *(dirend+3) == '.' && !*(dirend+4)) dirend += 4;
  }
  cp1 = rslt;
  cp2 = path;
  if (*cp2 == '/') {
    char trndev[NAM$C_MAXRSS+1];
    int islnm, rooted;
    size_t trnend;

    while (*(cp2+1) == '/') cp2++;  /* Skip multiple /s */
    if (!*(cp2+1)) {
      if (!buf & ts) Renew(rslt,18,char);
      strcpy(rslt,"sys$disk:[000000]");
      return rslt;
    }
    while (*(++cp2) != '/' && *cp2) *(cp1++) = *cp2;
    *cp1 = '\0';
    islnm =  my_trnlnm(rslt,trndev,0);
    trnend = islnm ? strlen(trndev) - 1 : 0;
    islnm =  trnend ? (trndev[trnend] == ']' || trndev[trnend] == '>') : 0;
    rooted = islnm ? (trndev[trnend-1] == '.') : 0;
    /* If the first element of the path is a logical name, determine
     * whether it has to be translated so we can add more directories. */
    if (!islnm || rooted) {
      *(cp1++) = ':';
      *(cp1++) = '[';
      if (cp2 == dirend) while (infront++ < 6) *(cp1++) = '0';
      else cp2++;
    }
    else {
      if (cp2 != dirend) {
        if (!buf && ts) Renew(rslt,strlen(path)-strlen(rslt)+trnend+4,char);
        strcpy(rslt,trndev);
        cp1 = rslt + trnend;
        *(cp1++) = '.';
        cp2++;
      }
      else {
        *(cp1++) = ':';
        hasdir = 0;
      }
    }
  }
  else {
    *(cp1++) = '[';
    if (*cp2 == '.') {
      if (*(cp2+1) == '/' || *(cp2+1) == '\0') {
        cp2 += 2;         /* skip over "./" - it's redundant */
        *(cp1++) = '.';   /* but it does indicate a relative dirspec */
      }
      else if (*(cp2+1) == '.' && (*(cp2+2) == '/' || *(cp2+2) == '\0')) {
        *(cp1++) = '-';                                 /* "../" --> "-" */
        cp2 += 3;
      }
      else if (*(cp2+1) == '.' && *(cp2+2) == '.' &&
               (*(cp2+3) == '/' || *(cp2+3) == '\0')) {
        *(cp1++) = '.'; *(cp1++) = '.'; *(cp1++) = '.'; /* ".../" --> "..." */
        if (!*(cp2+4)) *(cp1++) = '.'; /* Simulate trailing '/' for later */
        cp2 += 4;
      }
      if (cp2 > dirend) cp2 = dirend;
    }
    else *(cp1++) = '.';
  }
  for (; cp2 < dirend; cp2++) {
    if (*cp2 == '/') {
      if (*(cp2-1) == '/') continue;
      if (*(cp1-1) != '.') *(cp1++) = '.';
      infront = 0;
    }
    else if (!infront && *cp2 == '.') {
      if (cp2+1 == dirend || *(cp2+1) == '\0') { cp2++; break; }
      else if (*(cp2+1) == '/') cp2++;   /* skip over "./" - it's redundant */
      else if (*(cp2+1) == '.' && (*(cp2+2) == '/' || *(cp2+2) == '\0')) {
        if (*(cp1-1) == '-' || *(cp1-1) == '[') *(cp1++) = '-'; /* handle "../" */
        else if (*(cp1-2) == '[') *(cp1-1) = '-';
        else {  /* back up over previous directory name */
          cp1--;
          while (*(cp1-1) != '.' && *(cp1-1) != '[') cp1--;
          if (*(cp1-1) == '[') {
            memcpy(cp1,"000000.",7);
            cp1 += 7;
          }
        }
        cp2 += 2;
        if (cp2 == dirend) break;
      }
      else if ( *(cp2+1) == '.' && *(cp2+2) == '.' &&
                (*(cp2+3) == '/' || *(cp2+3) == '\0') ) {
        if (*(cp1-1) != '.') *(cp1++) = '.'; /* May already have 1 from '/' */
        *(cp1++) = '.'; *(cp1++) = '.'; /* ".../" --> "..." */
        if (!*(cp2+3)) {
          *(cp1++) = '.';  /* Simulate trailing '/' */
          cp2 += 2;  /* for loop will incr this to == dirend */
        }
        else cp2 += 3;  /* Trailing '/' was there, so skip it, too */
      }
      else *(cp1++) = '_';  /* fix up syntax - '.' in name not allowed */
    }
    else {
      if (!infront && *(cp1-1) == '-')  *(cp1++) = '.';
      if (*cp2 == '.')      *(cp1++) = '_';
      else                  *(cp1++) =  *cp2;
      infront = 1;
    }
  }
  if (*(cp1-1) == '.') cp1--; /* Unix spec ending in '/' ==> trailing '.' */
  if (hasdir) *(cp1++) = ']';
  if (*cp2) cp2++;  /* check in case we ended with trailing '..' */
  while (*cp2) *(cp1++) = *(cp2++);
  *cp1 = '\0';

  return rslt;
}

/* my_utime - update modification time of a file
 * calling sequence is identical to POSIX utime(), but under
 * VMS only the modification time is changed; ODS-2 does not
 * maintain access times.  Restrictions differ from the POSIX
 * definition in that the time can be changed as long as the
 * caller has permission to execute the necessary IO$_MODIFY $QIO;
 * no separate checks are made to insure that the caller is the
 * owner of the file or has special privs enabled.
 * Code here is based on Joe Meadows' FILE utility.
 */

#define VMSISH_TIME 0  /* Assume times are UTC, not local */

/* method used to handle UTC conversions:
 *   1 == CRTL gmtime();  2 == SYS$TIMEZONE_DIFFERENTIAL;  3 == no correction
 */
static int gmtime_emulation_type;
/* number of secs to add to UTC POSIX-style time to get local time */
static long int utc_offset_secs;

#if defined(__CRTL_VER) && __CRTL_VER >= 70000000 && __DECC_VER >= 50200000
#  define RTL_USES_UTC 1
#endif

static time_t toutc_dst(time_t loc) {
  struct tm *rsltmp;

  if ((rsltmp = localtime(&loc)) == NULL) return -1;
  loc -= utc_offset_secs;
  if (rsltmp->tm_isdst) loc -= 3600;
  return loc;
}
#define _toutc(secs)  ((secs) == -1 ? -1 : \
       ((gmtime_emulation_type || my_time(NULL)), \
       (gmtime_emulation_type == 1 ? toutc_dst(secs) : \
       ((secs) - utc_offset_secs))))

static time_t toloc_dst(time_t utc) {
  struct tm *rsltmp;

  utc += utc_offset_secs;
  if ((rsltmp = localtime(&utc)) == NULL) return -1;
  if (rsltmp->tm_isdst) utc += 3600;
  return utc;
}
#define _toloc(secs)  ((secs) == -1 ? -1 : \
       ((gmtime_emulation_type || my_time(NULL)), \
       (gmtime_emulation_type == 1 ? toloc_dst(secs) : \
       ((secs) + utc_offset_secs))))

static time_t my_time(time_t *timep)
{
  time_t when;
  struct tm *tm_p;

  if (gmtime_emulation_type == 0) {
    int dstnow;
    time_t base = 15 * 86400; /* 15jan71; to avoid month/year ends between    */
                              /* results of calls to gmtime() and localtime() */
                              /* for same &base */

    gmtime_emulation_type++;
    if ((tm_p = gmtime(&base)) == NULL) { /* CRTL gmtime() is a fake */
      char off[LNM$C_NAMLENGTH+1];
      /* char *off; */

      gmtime_emulation_type++;

      if (my_trnlnm("SYS$TIMEZONE_DIFFERENTIAL",off,0) == 0) {
      /* if ((off = my_getenv("SYS$TIMEZONE_DIFFERENTIAL")) == NULL) { */
        gmtime_emulation_type++;
        /* warn("no UTC offset information; assuming local time is UTC"); */
      }
      else { utc_offset_secs = atol(off); }
    }
    else { /* We've got a working gmtime() */
      struct tm gmt, local;

      gmt = *tm_p;
      tm_p = localtime(&base);
      local = *tm_p;
      utc_offset_secs  = (local.tm_mday - gmt.tm_mday) * 86400;
      utc_offset_secs += (local.tm_hour - gmt.tm_hour) * 3600;
      utc_offset_secs += (local.tm_min  - gmt.tm_min)  * 60;
      utc_offset_secs += (local.tm_sec  - gmt.tm_sec);
    }
  }

  when = time(NULL);
# ifdef VMSISH_TIME
# ifdef RTL_USES_UTC
  if (VMSISH_TIME) when = _toloc(when);
# else
  if (!VMSISH_TIME) when = _toutc(when);
# endif
# endif
  if (timep != NULL) *timep = when;
  return when;
}


struct utimbuf
{
  time_t actime;
  time_t modtime;
};

struct vmsdate { long int lo, hi; };

/* Adjustment from Unix epoch (01-JAN-1970 00:00:00.00)
 *              to VMS epoch  (01-JAN-1858 00:00:00.00)
 * in 100 ns intervals.
 */
static const struct vmsdate utime_baseadjust = { 0x4beb4000, 0x7c9567 };

int my_utime(char *file, struct utimbuf *utimes)
{
  register int i;
  struct vmsdate bintime;
  int len = 2, lowbit, unixtime,
           secscale = 10000000; /* seconds --> 100 ns intervals */
  struct io_stat_blk {                      /*  I/O status block */
    short int completion_status;
    short int msg_len;
    int device_specific_info;
  } iosb;
  unsigned short chan;
  int retsts;
  char vmsspec[NAM$C_MAXRSS+1], rsa[NAM$C_MAXRSS], esa[NAM$C_MAXRSS];
  struct FAB myfab = cc$rms_fab;
  struct NAM mynam = cc$rms_nam;
#if defined (__DECC) && defined (__VAX)
  /* VAX DEC C atrdef.h has unsigned type for pointer member atr$l_addr,
   * at least through VMS V6.1, which causes a type-conversion warning.
   */
#  pragma message save
#  pragma message disable cvtdiftypes
#endif
  struct atrdef myatr[] = {{sizeof bintime, ATR$C_CREDATE, &bintime},
                           {sizeof bintime, ATR$C_REVDATE, &bintime},
                           {0,0,0}};
  struct fibdef myfib;
#if defined (__DECC) && defined (__VAX)
  /* This should be right after the declaration of myatr, but due
   * to a bug in VAX DEC C, this takes effect a statement early.
   */
#  pragma message restore
#endif
  struct dsc$descriptor fibdsc = {sizeof(myfib), DSC$K_DTYPE_Z, DSC$K_CLASS_S,(char *) &myfib},
                        devdsc = {0,DSC$K_DTYPE_T, DSC$K_CLASS_S,0},
                        fnmdsc = {0,DSC$K_DTYPE_T, DSC$K_CLASS_S,0};

  if (file == NULL || *file == '\0') {
    set_errno(ENOENT);
    set_vaxc_errno(LIB$_INVARG);
    return -1;
  }
  if (do_tovmsspec(file,vmsspec,0) == NULL) return -1;

  if (utimes != NULL) {
    /* Convert Unix time    (seconds since 01-JAN-1970 00:00:00.00)
     * to VMS quadword time (100 nsec intervals since 01-JAN-1858 00:00:00.00).
     * Since time_t is unsigned long int, and lib$emul takes a signed long int
     * as input, we force the sign bit to be clear by shifting unixtime right
     * one bit, then multiplying by an extra factor of 2 in lib$emul().
     */
    lowbit = (utimes->modtime & 1) ? secscale : 0;
    unixtime = (long int) utimes->modtime;
#   ifdef VMSISH_TIME
    /* If input was UTC; convert to local for sys svc */
    if (!VMSISH_TIME) unixtime = _toloc(unixtime);
#   endif
    unixtime >>= 1;  secscale <<= 1;
    retsts = lib$emul(&secscale, &unixtime, &lowbit, &bintime);
    if (!(retsts & 1)) {
      set_errno(EVMSERR);
      set_vaxc_errno(retsts);
      return -1;
    }
    retsts = lib$addx(&bintime,&utime_baseadjust,&bintime,&len);
    if (!(retsts & 1)) {
      set_errno(EVMSERR);
      set_vaxc_errno(retsts);
      return -1;
    }
  }
  else {
    /* Just get the current time in VMS format directly */
    retsts = sys$gettim(&bintime);
    if (!(retsts & 1)) {
      set_errno(EVMSERR);
      set_vaxc_errno(retsts);
      return -1;
    }
  }

  myfab.fab$l_fna = vmsspec;
  myfab.fab$b_fns = (unsigned char) strlen(vmsspec);
  myfab.fab$l_nam = &mynam;
  mynam.nam$l_esa = esa;
  mynam.nam$b_ess = (unsigned char) sizeof esa;
  mynam.nam$l_rsa = rsa;
  mynam.nam$b_rss = (unsigned char) sizeof rsa;

  /* Look for the file to be affected, letting RMS parse the file
   * specification for us as well.  I have set errno using only
   * values documented in the utime() man page for VMS POSIX.
   */
  retsts = sys$parse(&myfab,0,0);
  if (!(retsts & 1)) {
    set_vaxc_errno(retsts);
    if      (retsts == RMS$_PRV) set_errno(EACCES);
    else if (retsts == RMS$_DIR) set_errno(ENOTDIR);
    else                         set_errno(EVMSERR);
    return -1;
  }
  retsts = sys$search(&myfab,0,0);
  if (!(retsts & 1)) {
    set_vaxc_errno(retsts);
    if      (retsts == RMS$_PRV) set_errno(EACCES);
    else if (retsts == RMS$_FNF) set_errno(ENOENT);
    else                         set_errno(EVMSERR);
    return -1;
  }

  devdsc.dsc$w_length = mynam.nam$b_dev;
  devdsc.dsc$a_pointer = (char *) mynam.nam$l_dev;

  retsts = sys$assign(&devdsc,&chan,0,0);
  if (!(retsts & 1)) {
    set_vaxc_errno(retsts);
    if      (retsts == SS$_IVDEVNAM)   set_errno(ENOTDIR);
    else if (retsts == SS$_NOPRIV)     set_errno(EACCES);
    else if (retsts == SS$_NOSUCHDEV)  set_errno(ENOTDIR);
    else                               set_errno(EVMSERR);
    return -1;
  }

  fnmdsc.dsc$a_pointer = mynam.nam$l_name;
  fnmdsc.dsc$w_length = mynam.nam$b_name + mynam.nam$b_type + mynam.nam$b_ver;

  memset((void *) &myfib, 0, sizeof myfib);
#ifdef __DECC
  for (i=0;i<3;i++) myfib.fib$w_fid[i] = mynam.nam$w_fid[i];
  for (i=0;i<3;i++) myfib.fib$w_did[i] = mynam.nam$w_did[i];
  /* This prevents the revision time of the file being reset to the current
   * time as a result of our IO$_MODIFY $QIO. */
  myfib.fib$l_acctl = FIB$M_NORECORD;
#else
  for (i=0;i<3;i++) myfib.fib$r_fid_overlay.fib$w_fid[i] = mynam.nam$w_fid[i];
  for (i=0;i<3;i++) myfib.fib$r_did_overlay.fib$w_did[i] = mynam.nam$w_did[i];
  myfib.fib$r_acctl_overlay.fib$l_acctl = FIB$M_NORECORD;
#endif
  retsts = sys$qiow(0,chan,IO$_MODIFY,&iosb,0,0,&fibdsc,&fnmdsc,0,0,myatr,0);
  _ckvmssts(sys$dassgn(chan));
  if (retsts & 1) retsts = iosb.completion_status;
  if (!(retsts & 1)) {
    set_vaxc_errno(retsts);
    if (retsts == SS$_NOPRIV) set_errno(EACCES);
    else                      set_errno(EVMSERR);
    return -1;
  }

  return 0;
}


/* my_rename - more Unix-like rename() function
 * Provides the target filespec with an absolute pathspec
 * before renaming, thus not allowing to default parts of
 * it from the source filespec.
 * Also "corrects" some errno values.
 * Written by Martin Vorlaender <mv@pdv-systeme.de>
 */

#ifdef rename
# undef rename
#endif

int my_rename( const char *fromspec, const char *tospec )
{
  int retsts, rc;
  char vmsfromspec[NAM$C_MAXRSS+1], vmstospec[NAM$C_MAXRSS+1], esa[NAM$C_MAXRSS];
  struct FAB myfab = cc$rms_fab;
  struct NAM mynam = cc$rms_nam;

  if (fromspec == NULL || *fromspec == '\0' ||
      tospec   == NULL || *tospec   == '\0') {
    set_errno(ENOENT);
    set_vaxc_errno(SS$_INVARG);
    return -1;
  }

  if (strpbrk(fromspec, "]:>") != NULL || strchr(fromspec, '/') == NULL) {
    /* fromspec already is a VMS filespec */
    strcpy(vmsfromspec, fromspec);
  } else {
    /* Treat fromspec as a Unix filespec */
    if (do_tovmsspec(fromspec,vmsfromspec,0) == NULL) {
      set_errno(ENOENT);
      set_vaxc_errno(SS$_INVARG);
      return -1;
    }
  }

  if (strpbrk(tospec, "]:>") != NULL || strchr(tospec, '/') == NULL) {
    /* tospec already is a VMS filespec */
    strcpy(vmstospec, tospec);
  } else {
    /* Treat tospec as a Unix filespec */
    if (do_tovmsspec(tospec,vmstospec,0) == NULL) {
      set_errno(ENOENT);
      set_vaxc_errno(SS$_INVARG);
      return -1;
    }
  }

  /* Let $PARSE determine the FQFN */
  myfab.fab$l_fna = vmstospec;
  myfab.fab$b_fns = (unsigned char) strlen(vmstospec);
  myfab.fab$l_nam = &mynam;
  mynam.nam$l_esa = esa;
  mynam.nam$b_ess = NAM$C_MAXRSS; /*(unsigned char) sizeof esa;*/
  mynam.nam$l_rsa = NULL; /*rsa;*/
  mynam.nam$b_rss = 0; /*(unsigned char) sizeof rsa;*/

  retsts = sys$parse( &myfab, NULL, NULL);
  if (!(retsts & 1)) {
    set_vaxc_errno(retsts);
    if      (retsts == RMS$_PRV) set_errno(EACCES);
    else if (retsts == RMS$_DIR) set_errno(ENOTDIR);
    else if (retsts == RMS$_DNF) set_errno(ENOENT);
    else                         set_errno(EVMSERR);
    return -1;
  }

  esa[mynam.nam$b_esl] = '\0';
  /* allowing a version on the target spec can cause trouble */
  if (mynam.nam$b_ver != 0) *mynam.nam$l_ver = '\0';
  rc = rename( vmsfromspec, esa );
  if (rc < 0)
  {
  	if (errno == ENXIO) set_errno(EXDEV);
  }
  return rc;
}


/* my_creat() - creat() wrapper
 * to "correct" some values of errno
 * Written by Martin Vorlaender <mv@pdv-systeme.de>
 */

#ifdef creat
#  undef creat
#endif

int my_creat(const char *file_spec, mode_t mode)
{
  /* Trying to creat() a unix file_spec that includes
     a non-existing directory results in errno==EVMSERR
     and vaxc$errno==RMS$_SYN; better change the file_spec
     to VMS syntax first.
     Unix-wise, this should yield errno==ENOENT */

  unsigned long int retsts;
  char vmsspec[NAM$C_MAXRSS+1], rsa[NAM$C_MAXRSS+1], esa[NAM$C_MAXRSS];
  struct FAB myfab = cc$rms_fab;
  struct NAM mynam = cc$rms_nam;

  if (file_spec == NULL || *file_spec == '\0') {
    set_errno(ENOENT);
    set_vaxc_errno(SS$_INVARG);
    return -1;
  }

  if (strpbrk(file_spec, "]:>") != NULL || strchr(file_spec, '/') == NULL) {
    /* file_spec already is a VMS filespec */
    strcpy(vmsspec, file_spec);
  } else {
    /* Treat file_spec as a Unix filespec */
    if (do_tovmsspec(file_spec,vmsspec,0) == NULL) {
      set_errno(ENOENT);
      set_vaxc_errno(SS$_INVARG);
      return -1;
    }
  }

  /* Let $PARSE determine the FQFN */
  myfab.fab$l_fna = vmsspec;
  myfab.fab$b_fns = (unsigned char) strlen(vmsspec);
  myfab.fab$l_nam = &mynam;
  mynam.nam$l_esa = esa;
  mynam.nam$b_ess = NAM$C_MAXRSS; /*(unsigned char) sizeof esa;*/
  mynam.nam$l_rsa = NULL; /*rsa;*/
  mynam.nam$b_rss = 0; /*(unsigned char) sizeof rsa;*/

  retsts = sys$parse( &myfab, NULL, NULL);
  if (!(retsts & 1)) {
    set_vaxc_errno(retsts);
    if      (retsts == RMS$_PRV) set_errno(EACCES);
    else if (retsts == RMS$_DIR) set_errno(ENOTDIR);
    else if (retsts == RMS$_DNF) set_errno(ENOENT);
    else                         set_errno(EVMSERR);
    return -1;
  }

  esa[mynam.nam$b_esl] = '\0';
  return creat(esa, mode);
}

/* The jacket for chmod() accomplishes the following:
 *  -- converts filenames to VMS format before sending them
 *     to the C RTL
 */

#ifdef chmod
#undef chmod
#endif

int my_chmod(const char *file_spec, mode_t mode)
{
  char vmsspec[NAM$C_MAXRSS+1];

  if (do_tovmsspec(file_spec,vmsspec,0) == NULL) return -1;

  return chmod( vmsspec, mode );
}


/*
 * my_exit
 * Replacement for exit() to do something reasonable with exit statuses.
 */

#ifdef exit
#undef exit     /* get the real one back */
#endif

void
my_exit (status)
    int status;
{
    int my_status;

    switch (status)
    {
      case 0:
        my_status = SS$_NORMAL;
        break;

      case 1:                   /* -- this happens when some hunks failed. */
        my_status = 196608;	/* CLI$_NORMAL with severity set to warning */
        break;

      case 2:                   /* error exit */
        my_status = SS$_ABORT;
        break;

      default:                  /* else just pass on what we got */
        my_status = status;
        break;
    }

    exit (my_status);
}


/* The jacket for fopen() accomplishes the following:
 *  -- converts filenames to VMS format before sending them
 *     to the C RTL
 */

#ifdef fopen
#undef fopen
#endif

FILE *my_fopen (const char *file_spec, const char *a_mode)
{
  char vmsspec[NAM$C_MAXRSS+1];

  if (do_tovmsspec(file_spec,vmsspec,0) == NULL) return NULL;

  return fopen( vmsspec, a_mode );
}


/* The jacket for open() accomplishes the following:
 *  -- converts filenames to VMS format before sending them
 *     to the C RTL
 *  -- changes O_TRUNC behavior to be more Unix-like, i.e.,
 *     actually truncates the file rather than creating a new
 *     one
 */

#ifdef open
#undef open
#endif

int my_open (const char *file_spec, int flags, ...)
{
  va_list ap;
  char vmsspec[NAM$C_MAXRSS+1];
  int my_flags = flags;
  mode_t mode;
  int numargs;

  if (do_tovmsspec(file_spec,vmsspec,0) == NULL) return -1;

/* Under VMS, O_TRUNC by default creates a new file, but
 * that's not really what the GNU sources expect.
 */

  if ( my_flags && (O_WRONLY||O_RDWR) && O_TRUNC ) {
    truncate(vmsspec, 0);
    my_flags ^= O_TRUNC;
  }

/* The caller may or may not have passed the mode argument. */

  va_count(numargs);
  if ( numargs > 2 ) {
      va_start( ap, flags );
      mode = va_arg( ap, mode_t );
      va_end( ap );
  } else {
      mode = 0;
  }

/* Some older C RTLs either see line breaks that aren't really 
 * there or double the ones that are there; luckily it only 
 * appears to happen in readonly mode, so we can take care of
 * the problem by forcing record-mode access in that case.
 */

  if ( my_flags && O_RDONLY) {
      return open( vmsspec, my_flags, mode, "ctx=rec" );
  } else {
      return open( vmsspec, my_flags, mode );
  }
}


/* The jacket for stat() accomplishes the following:
 *  -- converts filenames to VMS format before sending them
 *     to the C RTL
 */

#ifdef stat
#undef stat
#endif

int my_stat(const char *file_spec, struct stat *buffer)
{
  char vmsspec[NAM$C_MAXRSS+1];

  if (do_tovmsspec(file_spec,vmsspec,0) == NULL) return -1;

  return stat( vmsspec, buffer );
}


/* The jacket for unlink() accomplishes the following:
 *  -- converts filenames to VMS format before sending them
 *     to the C RTL
 *  -- uses delete() since unlink() is not available on all
 *     VMS systems
 */

int my_unlink (const char *file_spec)
{
  char vmsspec[NAM$C_MAXRSS+1];

  if (do_tovmsspec(file_spec,vmsspec,0) == NULL) return -1;

  return delete( vmsspec );
}


/* initialize_main function for VMS
 * Written by Martin Vorlaender <mv@pdv-systeme.de>
 * Chuck Lane's redirection code integrated by Craig Berry
 */

/* Path of program (copied from argv[0]) */
char program_path[PATH_MAX+1];

/* "Short" program name */
static char short_program_name[NAME_MAX+1];

static void pfatal_with_name(char const *text)
{
  int e = errno;
  fprintf (stderr, "%s: ", short_program_name);
  errno = e;
  perror (text);
  exit (SS$_ABORT);
}


void
vms_initialize_main ( int *argc, char **argv[] )
{
  char *p;
  int i, j, k, cond, new_argc = 0;
  int append;
  char **vms_argv;
  FILE *f;

  struct dsc$descriptor_s prgnam_dsc = {0,DSC$K_DTYPE_T,DSC$K_CLASS_S,NULL};
  struct fscndef fscn_item[] =
  {
    {0, FSCN$_NAME, 0},
    {0, FSCN$_DEVICE, 0},
    {0, FSCN$_ROOT, 0},
    {0, FSCN$_DIRECTORY, 0},
    {0, 0, 0}
  };

  /* Get program name, device and directory from argv[0],
     copy to short_program_name[] and program_path[], respectively */
  prgnam_dsc.dsc$a_pointer = (*argv)[0];
  prgnam_dsc.dsc$w_length  = strlen ((*argv)[0]);
  _ckvmssts( sys$filescan (&prgnam_dsc, fscn_item, NULL, NULL, NULL) );

  if (fscn_item[0].fscn$w_length != 0)
  {
    /* Just to make messages look nicer */
    memcpy (short_program_name, (char*)fscn_item[0].fscn$l_addr, fscn_item[0].fscn$w_length);
    short_program_name[fscn_item[0].fscn$w_length] = '\0';
    (*argv)[0] = short_program_name;
  }

  p = program_path;
  *p = '\0';
  for (i = 1; i <= 3; ++i)
    if (fscn_item[i].fscn$w_length != 0)
    {
    	memcpy (p, (char*)fscn_item[i].fscn$l_addr, fscn_item[i].fscn$w_length);
    	p += fscn_item[i].fscn$w_length;
    }
  *p = '\0';


  vms_argv = (char **) malloc((*argc+1) * sizeof(char*));

  vms_argv[new_argc++] = **argv;

  for (i = 1; i < *argc; i++) {
        if (argv[0][i][0] == '>') {
            k = 1;
            append = 0;
            if (argv[0][i][k] == '>') {
                k++;
                append++;
            }
            if (argv[0][i][k]) {
                f = freopen(argv[0][i]+k,append?"a":"w",stdout);
                if (!f) {
                    perror("stdout redirection");
                    exit(SS$_ABORT);
                }
            } else if (i+1 < *argc && argv[0][i+1] && *argv[0][i+1]) {
                f = freopen(argv[0][i+1],append?"a":"w",stdout);
                if (!f) {
                    perror("stdout redirection");
                    exit(SS$_ABORT);
                }
                i++;
            }
        } else if (argv[0][i][0] == '2' && argv[0][i][1] == '>') {
            k = 2;
            append = 0;
            if (argv[0][i][k] == '>') {
                k++;
                append++;
            }
            if (argv[0][i][k]) {
                if (argv[0][i][k] == '&') {
            	    if (argv[0][i][k+1] != '1') exit(SS$_BADPARAM);
                    stderr = stdout;
            	} else {
                    f = freopen(argv[0][i]+k,append?"a":"w",stderr);
                    if (!f) {
                        perror("stderr redirection");
                        exit(SS$_ABORT);
                    }
                }
            } else if (i+1 < *argc && argv[0][i+1] && *argv[0][i+1]) {
                if (argv[0][i+1][0] == '&') {
            	    if (argv[0][i+1][1] != '1') exit(SS$_BADPARAM);
                    stderr = stdout;
            	} else {
                    f = freopen(argv[0][i+1],append?"a":"w",stderr);
                    if (!f) {
                        perror("stderr redirection");
                        exit(SS$_ABORT);
                    }
                }
                i++;
            }
        } else if (*argv[0][i] == '<') {
            if (argv[0][i][1]) {
                f = freopen(argv[0][i]+1,"r",stdin);
                if (!f) {
                    perror("stdin redirection");
                    exit(SS$_ABORT);
                }
            } else if (i+1 < *argc && argv[0][i+1] && *argv[0][i+1]) {
                f = freopen(argv[0][i+1],"r",stdin);
                if (!f) {
                    perror("stdin redirection");
                    exit(SS$_ABORT);
                }
                i++;
            }
        } else {
            vms_argv[new_argc++] = argv[0][i];
        }
  }

  *argc = new_argc;
  vms_argv[new_argc] = NULL;
  *argv = vms_argv;
}


#if __CRTL_VER < 70000000 || defined (LINK_TARGET_PRE7)

int
strncasecmp(const char *s1, const char *s2, size_t n)
{
    int i;
    char c1, c2;

    for (i=0; i < n; i++) {
        c1 = toupper(s1[i]);
        c2 = toupper(s2[i]);
        if (c1 != c2) return c1 < c2 ? -1 : 1;
        if (c1 == '\0') return  c2 ? 1: 0; /* s2 is longer */
    }
    return 0;
}

int
rmdir(const char *path)
{
    int result=-1;
    char *vpath, *vpath2;
    struct stat sbuf;

    if (!path) return 0;

    vpath = do_tovmsspec(path,0,1);

    vpath2 = (char *) malloc(strlen(vpath)+7);
    strcpy(vpath2,vpath);
    strcat(vpath2,".dir;1");
    free(vpath);

    if (stat(vpath2, &sbuf) != 0) goto done;
    if (chmod(vpath2,0700)  != 0) goto done;
    if (delete(vpath2) == 0) result = 0;

done:
    free(vpath2);
    return result;
}

int
truncate(const char *path, off_t length)
{
    int iss;
    struct FAB fab = cc$rms_fab;
    struct RAB rab = cc$rms_rab;
    char *vpath;

/* This little home-grown version can only start at BOF */

    if (length != 0) {
	set_errno(ENOSYS);
	return -1;
    }

    if (!path) return 0;
    vpath = do_tovmsspec(path,0,1);

    fab.fab$l_fna = vpath;
    fab.fab$b_fns = strlen(vpath);
    fab.fab$b_fac = FAB$M_TRN;

    iss = sys$open(&fab);
    free(vpath);
    if (!(iss&1)) return -1;

    rab.rab$l_fab = &fab;
    iss = sys$connect(&rab);
    if (!(iss&1)) return -1;

    iss = sys$rewind(&rab);
    if (!(iss&1)) return -1;
    iss = sys$find(&rab);
    if (!(iss&1)) return -1;

    iss = sys$truncate(&rab);
    if (!(iss&1)) return -1;

    iss = sys$disconnect(&rab);
    iss = sys$close(&fab);
    return 0;
}

#endif

                                                                                                                                                                                                                                  20000816  �� 8 706C2000080116488 20000816  �� : 706C2000080116533 20000803  �� ; 706C2000080116533 20000803  �� < 706C2000080116533 20000803  H� 0 706C2000080116533 20000810  �  706C2000080116533 20000817  ��  706C2000080116533 20000824  �   706C2000080116667 20000803  � ! 706C2000080116667 20000803  � " 706C2000080116667 20000803  � # 706C2000080116667 20000803  �
 6 706C2000080116667 20000824  � 1 706C2000080116823 20000802  � 2 706C2000080116823 20000802  � 3 706C2000080116823 20000802  �� @ 706C2000080117027 20000808  T� " 706C2000080117050 20000809  T� # 706C2000080117050 20000809  T� $ 706C2000080117050 20000809  T� % 706C2000080117050 20000809  T� & 706C2000080117050 20000809  l� / 706C2000080117050 20000809  ��  706C2000080117145 20000809  ��  706C2000080117145 20000809  �� ? 706C2000080117146 20000809  �� @ 706C2000080117146 20000809    4 706C2000080117146 20000823  D ) 706C2000080117146 20000828  D + 706C2000080117146 20000828  �� . 706C2000080117177 2000