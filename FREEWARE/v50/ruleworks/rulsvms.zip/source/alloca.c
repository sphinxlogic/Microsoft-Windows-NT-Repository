#include <builtins.h>

#define alloca __ALLOCA
