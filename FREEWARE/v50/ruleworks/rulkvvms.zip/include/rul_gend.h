/*
      RuleWorks (tm) -- Version 2.2
      Copyright (c) 1993-1999 Compaq Computer Corporation.  All Rights Reserved.
     RuleWorks comes with ABSOLUTELY NO WARRANTY. This is free software, and you are welcome to redistribute it under certain conditions; see GNU General Public License for details.

*/
#include <stdlib.h> 

#if !defined(__UNIX) && (defined(unix) || defined(__unix) || defined(UNIX))
#define __UNIX 1
#endif
#if !defined(__VMS) && (defined(vms) || defined(__vms) || defined(VMS))
#define __VMS 1
#endif
#if !defined(__MSDOS) && (defined(MSDOS) || defined(__MSDOS__))
#define __MSDOS 1
#endif
#if !defined(WINDOWS)
#if defined(__WINDOWS__) || defined(_Windows) || defined(_WINDOWS)

#define WINDOWS 1 
#endif
#endif

#define List RulList
#define Hash_Table RulHash_Table
#define Dynamic_Array RulDynamic_Array
#define IO_Stream RulIO_Stream
#define Molecule RulMolecule
#define Molecule_Ptr RulMolecule_Ptr
#define Object RulObject
#define Entry_Block RulEntry_Block
#define Entry_Data RulEntry_Data
#define Decl_Block RulDecl_Block
#define Class RulClass
#define Ext_Rt_Decl RulExt_Rt_Decl
#define Ext_Alias_Decl RulExt_Alias_Decl
#define Method RulMethod
#define Method_Func RulMethod_Func
#define Molecule_Type RulMolecule_Type

#define Delta_Token RulDelta_Token
#define Delta_Queue RulDelta_Queue
#define Beta_Token RulBeta_Token
#define Beta_Collection RulBeta_Collection
#define Conflict_Set_Entry RulConflict_Set_Entry
#define Conflict_Subset RulConflict_Subset
#define Refraction_Set RulRefraction_Set
#define Cardinality RulCardinality
#define Token_Sign RulToken_Sign
#define Construct_Type RulConstruct_Type
#define Catcher_Function RulCatcher_Function
#define Matches_Function RulMatches_Function
#define Propagate_Function RulPropagate_Function
#define Class_Member RulClass_Member
#ifdef __VMS
#define String RulString
#else
#define String RulString
#endif
#define Pointer RulPointer
#define Mol_Atom RulMol_Atom
#define Mol_Symbol RulMol_Symbol
#define Mol_Instance_Id RulMol_Instance_Id
#define Mol_Opaque RulMol_Opaque
#define Mol_Number RulMol_Number
#define Mol_Int_Atom RulMol_Int_Atom
#define Mol_Dbl_Atom RulMol_Dbl_Atom
#define Mol_Polyatom RulMol_Polyatom
#define Mol_Compound RulMol_Compound
#define Mol_Table RulMol_Table
#define Decl_Domain RulDecl_Domain
#define Decl_Shape RulDecl_Shape
#define Strategy RulStrategy
#define Boolean RulBoolean

#ifdef __VMS
#include <ssdef.h>
#ifdef VAXC
#undef EXIT_FAILURE
#define EXIT_FAILURE SS$_ABORT
#endif
#endif
#ifndef NULL
#define NULL ((void *) 0)
#endif

#ifdef FALSE
#undef FALSE
#endif
#ifdef TRUE
#undef TRUE
#endif
#ifdef VAXC
#define FALSE (1 == 0)
#define TRUE (0 == 0)
typedef long RulBoolean;
#else
typedef enum Rulboolean {
 FALSE=(1==0),
 TRUE=(0==0)
 } RulBoolean;
#endif

#ifdef VAXC_SHARABLE
#define GLOBAL globaldef
#define EXTERNAL globalref
#else
#define GLOBAL
#define EXTERNAL extern
#endif
#ifndef MIN
#define MIN(a,b) (((a) <= (b)) ? (a) : (b))
#endif
#ifndef MAX
#define MAX(a,b) (((a) > (b)) ? (a) : (b))
#endif

#ifndef OPS_C_MAX_SYMBOL_SIZE
#define OPS_C_MAX_SYMBOL_SIZE RUL_C_MAX_SYMBOL_SIZE
#endif
#define RUL_C_MAX_SYMBOL_SIZE 256 

typedef struct list *RulList;
typedef struct hash_table *RulHash_Table;
typedef struct dynamic_array *RulDynamic_Array;
typedef struct io_stream *RulIO_Stream;
typedef struct molecule *RulMolecule;
typedef RulMolecule *RulMolecule_Ptr;
typedef struct object *RulObject;
typedef struct entry_block *RulEntry_Block;
typedef struct entry_data *RulEntry_Data;
typedef struct decl_block *RulDecl_Block;
typedef struct rclass *RulClass;
typedef struct ext_rt_decl *RulExt_Rt_Decl;
typedef struct ext_alias_decl *RulExt_Alias_Decl;
typedef struct method *RulMethod;

typedef struct delta_token *RulDelta_Token;
typedef struct delta_queue *RulDelta_Queue;
typedef struct beta_token *RulBeta_Token;
typedef struct beta_collection *RulBeta_Collection;
typedef struct conflict_set_entry *RulConflict_Set_Entry;
typedef struct conflict_subset *RulConflict_Subset;
typedef struct refraction_set *RulRefraction_Set;
typedef long RulCardinality;
typedef long RulToken_Sign;
typedef struct class_member *RulClass_Member;
#ifdef __VMS
typedef struct dsc$descriptor RulString;
#else
typedef struct dsc_descriptor RulString;
#endif
typedef void *RulPointer;

typedef RulMolecule
 RulMol_Atom,
 RulMol_Symbol,
 RulMol_Instance_Id,
 RulMol_Opaque,
 RulMol_Number,
 RulMol_Int_Atom,
 RulMol_Dbl_Atom,
 RulMol_Polyatom,
 RulMol_Compound,
 RulMol_Table;

typedef enum {
 RUL__C_NOISE = 0,
 RUL__C_RULE = 2,
 RUL__C_CATCH = 3,
 RUL__C_COMMENT = 8, 
 RUL__C_OBJ_CLASS = 9,
 RUL__C_EXT_ROUTINE = 10,
 RUL__C_DECL_BLOCK = 11,
 RUL__C_ENTRY_BLOCK = 12,
 RUL__C_RULE_BLOCK = 13,
 RUL__C_END_BLOCK = 14,
 RUL__C_RULE_GROUP = 15,
 RUL__C_END_GROUP = 16,
 RUL__C_ON_ENTRY = 17,
 RUL__C_ON_EVERY = 18,
 RUL__C_ON_EMPTY = 19,
 RUL__C_ON_EXIT = 20,
 RUL__C_METHOD = 21
 } RulConstruct_Type;

typedef enum {
 dom_invalid = 0,
 dom_any = 455,
 dom_symbol,
 dom_instance_id,
 dom_opaque,
 dom_number,
 dom_int_atom,
 dom_dbl_atom
} RulDecl_Domain;
typedef enum {
 shape_invalid = 0,
 shape_molecule = 364,
 shape_atom,
 shape_compound,
 shape_table
} RulDecl_Shape;

typedef long RulStrategy;

#ifdef RUL__C_IN_GENERATED_CODE
#define DGC rul__decl_get_class
#define DGB rul__decl_get_block
#endif

void rul__decl_create_decl_block (RulMol_Symbol);
void rul__decl_finish_decl_block (void);
RulDecl_Block rul__decl_get_block (RulMol_Symbol);

void rul__decl_create_class (RulMol_Symbol,
 RulMol_Symbol);
void rul__decl_set_cur_class_parent (RulMol_Symbol);
void rul__decl_set_cur_class_patpart (long,
 long);
void rul__decl_set_cur_class_masklen (long);
void rul__decl_add_attr_cur_class (RulMol_Symbol);
void rul__decl_set_cur_attr_domain (RulDecl_Domain);
void rul__decl_set_cur_attr_compound (void);
void rul__decl_set_cur_attr_class (RulClass);
void rul__decl_set_cur_attr_default (RulMolecule);
void rul__decl_set_cur_attr_fill (RulMolecule);
void rul__decl_set_cur_attr_offset (int);
Class rul__decl_finish_cur_class (void);

RulClass rul__decl_get_class (RulDecl_Block,
 RulMol_Symbol);

RulMolecule rul__decl_get_attr_fill (RulClass,
 RulMol_Symbol);

RulBoolean rul__decl_is_subclass_of (RulClass,
 RulClass);
RulDecl_Domain rul__decl_int_to_domain (long);

typedef RulMolecule (*RulMethod_Func) (long,
 RulMolecule *,
 RulEntry_Data);
RulMethod rul__decl_create_method (RulDecl_Block,
 RulMol_Symbol,
 RulBoolean,
 long);
void rul__decl_set_method_param (long,
 RulDecl_Shape,
 RulDecl_Domain,
 RulClass);
void rul__decl_set_method_func (RulMethod_Func);
void rul__decl_finish_method (void);
void rul__decl_define_sys_methods (RulDecl_Block);
RulMolecule rul__call_method (RulMol_Symbol, long,
 RulMolecule args[], RulClass,
 RulEntry_Data);

#ifdef RUL__C_IN_GENERATED_CODE
#define MDU rul__mol_decr_uses
#define MIU rul__mol_incr_uses
#define MAA rul__mol_arith_add
#define MAS rul__mol_arith_subtract
#define MAM rul__mol_arith_multiply
#define MAO rul__mol_arith_modulo
#define MAN rul__mol_arith_neg
#define MAD rul__mol_arith_divide
#define MMP rul__mol_mark_perm
#define MCA rul__mol_concat_atoms
#define MMC rul__mol_make_comp
#define MMI rul__mol_make_int_atom
#define MMD rul__mol_make_dbl_atom
#define MMS rul__mol_make_symbol
#define MMON rul__mol_opaque_null
#define MMIZ rul__mol_instance_id_zero
#define MGCL rul__mol_get_comp_last
#define MGCN rul__mol_get_comp_nth
#define MGCNM rul__mol_get_comp_nth_mol
#define MGCNR rul__mol_get_comp_nth_rt
#define MGCNMR rul__mol_get_comp_nth_mol_rt
#define MGPC rul__mol_get_poly_count
#define MGPCA rul__mol_get_poly_count_atom
#define MGPCL rul__mol_get_poly_count_last
#define MGPF rul__mol_get_printform
#define MUPF rul__mol_use_printform
#define MSCN rul__mol_set_comp_nth
#define MPEQ rul__mol_eq_pred
#define MPEQL rul__mol_equal_pred
#define MPNEQ rul__mol_not_eq_pred
#define MPNEQL rul__mol_not_equal_pred
#define MPAE rul__mol_approx_eq_pred
#define MPNAE rul__mol_not_approx_eq_pred
#define MPST rul__mol_same_type_pred
#define MPDT rul__mol_diff_type_pred
#define MPLT rul__mol_lt_pred
#define MPLTE rul__mol_lte_pred
#define MPGT rul__mol_gt_pred
#define MPGTE rul__mol_gte_pred
#define MPC rul__mol_contains_pred
#define MPNC rul__mol_not_contains_pred
#define MPLLE rul__mol_len_lte_pred
#define MPLNE rul__mol_len_neq_pred
#define MPLLT rul__mol_len_lt_pred
#define MPLEQ rul__mol_len_eq_pred
#define MPLGE rul__mol_len_gte_pred
#define MPLGT rul__mol_len_gt_pred
#define MPIV rul__mol_index_valid_pred
#endif
typedef enum {
 invalid_molecule_type = 0,
 int_atom, dbl_atom, opaque, symbol, instance_id,
 compound, table
} RulMolecule_Type;

RulMol_Symbol rul__mol_symbol_nil (void);
RulMol_Symbol rul__mol_symbol_root (void);
RulMol_Symbol rul__mol_symbol_crlf (void);
RulMol_Symbol rul__mol_symbol_id (void); 
RulMol_Symbol rul__mol_symbol_instance_of (void); 
RulMol_Int_Atom rul__mol_integer_zero (void); 
RulMol_Dbl_Atom rul__mol_double_zero (void); 
RulMol_Opaque rul__mol_opaque_null (void); 
RulMol_Instance_Id rul__mol_instance_id_zero (void); 
RulMol_Compound rul__mol_compound_empty (void); 

char *rul__mol_get_printform (Molecule);
Boolean rul__mol_use_printform (Molecule,
 char *, long);
long rul__mol_get_printform_length (Molecule);

void rul__mol_incr_uses (RulMolecule);
void rul__mol_decr_uses (RulMolecule);

RulBoolean rul__mol_eq_pred (RulMolecule mol1, RulMolecule mol2);
RulBoolean rul__mol_equal_pred (RulMolecule mol1, RulMolecule mol2);
RulBoolean rul__mol_not_eq_pred (RulMolecule mol1, RulMolecule mol2);
RulBoolean rul__mol_not_equal_pred (RulMolecule mol1, RulMolecule mol2);
RulBoolean rul__mol_lt_pred (RulMolecule mol1, RulMolecule mol2);
RulBoolean rul__mol_lte_pred (RulMolecule mol1, RulMolecule mol2);
RulBoolean rul__mol_gt_pred (RulMolecule mol1, RulMolecule mol2);
RulBoolean rul__mol_gte_pred (RulMolecule mol1, RulMolecule mol2);
RulBoolean rul__mol_same_type_pred (RulMolecule mol1, RulMolecule mol2);
RulBoolean rul__mol_diff_type_pred (RulMolecule mol1, RulMolecule mol2);
RulBoolean rul__mol_approx_eq_pred (RulMolecule mol1, RulMolecule mol2);
RulBoolean rul__mol_not_approx_eq_pred (RulMolecule m1, RulMolecule m2);
RulBoolean rul__mol_len_eq_pred (RulMolecule mol1, RulMolecule mol2);
RulBoolean rul__mol_len_neq_pred (RulMolecule mol1, RulMolecule mol2);
RulBoolean rul__mol_len_lt_pred (RulMolecule mol1, RulMolecule mol2);
RulBoolean rul__mol_len_lte_pred (RulMolecule mol1, RulMolecule mol2);
RulBoolean rul__mol_len_gt_pred (RulMolecule mol1, RulMolecule mol2);
RulBoolean rul__mol_len_gte_pred (RulMolecule mol1, RulMolecule mol2);
RulBoolean rul__mol_index_valid_pred (RulMolecule mol1, RulMolecule mol2);
RulBoolean rul__mol_contains_pred (RulMolecule mol1, RulMolecule mol2,
 Boolean (*pred_func) (Molecule, Molecule));
RulBoolean rul__mol_not_contains_pred (RulMolecule mol1, RulMolecule mol2,
 Boolean (*pred_func) (Molecule, Molecule));

RulMol_Int_Atom rul__mol_make_int_atom (long);
RulMol_Dbl_Atom rul__mol_make_dbl_atom (double);
RulMol_Opaque rul__mol_make_opaque (void *);
RulMol_Symbol rul__mol_make_symbol (char *);
RulMol_Instance_Id rul__mol_make_instance_id (RulObject instance_ptr);
RulMol_Instance_Id rul__mol_make_instance_atom (long);

RulMol_Symbol rul__mol_concat_atoms (long, ...);
RulMol_Symbol rul__mol_gensym (RulMol_Symbol);
RulMol_Int_Atom rul__mol_genint (void);
RulMolecule rul__mol_max_min (RulBoolean, long, ...);
RulMol_Symbol rul__mol_subsymbol (RulMol_Symbol,
 long, long);

void rul__mol_mark_perm (RulMolecule);

RulMol_Number rul__mol_arith_add (RulMol_Number mol1, RulMol_Number mol2);
RulMol_Number rul__mol_arith_neg (RulMol_Number mol1);
RulMol_Number rul__mol_arith_subtract (RulMol_Number mol1, RulMol_Number mol2);
RulMol_Number rul__mol_arith_multiply (RulMol_Number mol1, RulMol_Number mol2);
RulMol_Number rul__mol_arith_divide (RulMol_Number mol1, RulMol_Number mol2);
RulMol_Number rul__mol_arith_modulo (RulMol_Number mol1, RulMol_Number mol2);

long rul__mol_get_poly_count (RulMol_Polyatom);
RulMol_Int_Atom rul__mol_get_poly_count_atom (RulMol_Polyatom);
RulMol_Int_Atom rul__mol_get_poly_count_rt (RulMol_Polyatom);
long rul__mol_get_poly_count_last (RulMol_Polyatom);
RulBoolean rul__mol_poly_has_key (RulMol_Polyatom,
 RulMolecule);
RulBoolean rul__mol_poly_has_no_key (RulMol_Polyatom,
 RulMolecule);
RulBoolean rul__mol_poly_values_are_all (RulMol_Polyatom,
 RulMolecule_Type);

RulMol_Compound rul__mol_make_comp (long, ...);
RulMol_Compound rul__mol_subcomp (RulMol_Compound,
 long,
 long);
RulMol_Compound rul__mol_remove_comp_nth_rt (RulMol_Compound,
 RulMol_Int_Atom);
RulMol_Compound rul__mol_remove_comp_nth (RulMol_Compound,
 long);
RulMol_Compound rul__mol_set_comp_nth (RulMol_Compound,
 long, RulMolecule,
 RulMolecule);

RulMol_Atom rul__mol_get_comp_nth_mol_rt (RulMol_Compound,
 RulMol_Int_Atom);
RulMol_Atom rul__mol_get_comp_nth_mol (RulMol_Compound,
 RulMol_Int_Atom);
RulMol_Atom rul__mol_get_comp_nth_rt (RulMol_Compound,
 long);
RulMol_Atom rul__mol_get_comp_nth (RulMol_Compound,
 long);
RulMol_Atom rul__mol_get_comp_last (RulMol_Compound);
RulMol_Atom rul__mol_get_comp_last_rt (RulMol_Compound);
long rul__mol_position_in_comp (RulMol_Compound,
 Boolean (*pred_func) (Molecule, Molecule),
 RulMolecule);


typedef void (*Matches_Function) (Mol_Symbol);
typedef void (*Propagate_Function) (Delta_Token);
typedef long (*Catcher_Function) (Entry_Data);

void rul__rbs_register_rblock (
 Mol_Symbol block_name,
 Strategy block_strategy,
 Molecule *return_value_loc,
 Conflict_Subset *css_loc,
 Beta_Collection *beta_mem_loc,
 Matches_Function matches_func,
 long retain_memories_on_exit,
 long dblock_count,
 Mol_Symbol *dblock_names,
 Propagate_Function *dblock_prop_funcs,
 long catcher_count,
 Mol_Symbol *catcher_names,
 Catcher_Function *catcher_funcs,
 long cons_count,
 Mol_Symbol *cons_names,
 Construct_Type *cons_types);
void rul__rbs_unregister_rblock (Mol_Symbol);

#ifdef RUL__C_IN_GENERATED_CODE
#define CGCNO rul__cs_get_cse_nth_object
#define CMO rul__cs_modify
#endif

typedef long (*Rule_RHS_Func)(Conflict_Set_Entry, Entry_Data);


void
rul__cs_modify (Conflict_Subset, Token_Sign, Mol_Symbol,
 Mol_Symbol, Rule_RHS_Func,
 long, long,
 long, Mol_Instance_Id inst_id_array []);
Object
rul__cs_get_cse_nth_object (Conflict_Set_Entry, long);

void
rul__rac_cycle (RulMol_Symbol rb_name_array[],
 long rb_name_array_length,
 RulRefraction_Set refraction_set,
 long on_entry_func (RulMolecule *,
 RulEntry_Data),
 long on_every_func (RulMolecule *,
 RulEntry_Data),
 long on_empty_func (RulMolecule *,
 RulEntry_Data),
 long on_exit_func (RulMolecule *,
 RulEntry_Data),
 RulMolecule eb_var_values[],
 long *eb_after_count,
 RulMol_Symbol *eb_catcher_name,
 RulMol_Symbol *eb_catcher_rb_name,
 RulMolecule *eb_return_value_ptr,
 RulBoolean dbg_allowed);
void
rul__rac_after (long, RulMol_Symbol,
 RulMol_Symbol, RulEntry_Data);
void rul__debug (void);
void rul__debug_init (void);
void rul__trace (long, ...);

Refraction_Set
rul__ref_make_refraction_set (void);
void
rul__ref_free_refraction_set (Refraction_Set);

#ifdef RUL__C_IN_GENERATED_CODE
#define BPPM rul__beta_print_partial_matches
#define BGNT rul__beta_get_next_token
#define BMM rul__beta_modify_memory
#define BRFM rul__beta_remove_from_memory
#define BATM rul__beta_add_to_memory
#define BGFT rul__beta_get_first_token
#define BMMC rul__beta_modify_match_count
#endif
#define BETA_MEMBER_HT_SIZE 16
struct beta_token {
 
 Class_Member curr_member;
 unsigned long hash_num; 
 long node_id; 
 Beta_Token hash_next; 
 Beta_Token hash_prev; 
 Class_Member first_member; 
 Class_Member hash_members[BETA_MEMBER_HT_SIZE];
#ifdef DEBUG_BETA
 long verification;
 long hash_val_count; 
 long aux_val_count; 
#endif
 
 long inst_count;
 Mol_Instance_Id *inst_array; 
 Molecule *aux_array; 
 Molecule val_array[1]; 
 
}; 

void rul__beta_modify_memory (
 Beta_Collection, 
 long, 
 unsigned long, 
 Token_Sign, 
 long, 
 Mol_Instance_Id inst_array[],
 
 long, 
 Molecule aux_array[], 
 long, 
 Molecule val_array[]); 
Beta_Token rul__beta_get_first_token (
 Beta_Collection, 
 long, 
 unsigned long, 
 long, 
 Molecule mol_array[]); 
Beta_Token rul__beta_get_next_token (Beta_Token);
void rul__beta_print_partial_matches (
 Beta_Collection, 
 long, 
 ... ); 

long rul__beta_modify_match_count (Beta_Token, long);
 
long rul__beta_remove_from_memory (
 
 Beta_Collection, 
 long, 
 unsigned long, 
 long, 
 Mol_Instance_Id inst_array[],
 
 long, 
 Molecule val_array[]); 
void rul__beta_add_to_memory (
 
 Beta_Collection, 
 long, 
 unsigned long, 
 long, 
 long, 
 Mol_Instance_Id inst_array[],
 
 long, 
 Molecule aux_array[], 
 long, 
 Molecule val_array[]); 


struct delta_token {
 Token_Sign sign;
 Object instance;
 Class instance_class;
 Mol_Instance_Id instance_id;
};

#ifdef RUL__C_IN_GENERATED_CODE
#define WCR rul__wm_create
#define WCRI rul__wm_create_id
#define WCRV rul__wm_create_var
#define WMO rul__wm_modify
#define WMOI rul__wm_modify_id
#define WCO rul__wm_copy
#define WCOI rul__wm_copy_id
#define WSP rul__wm_specialize
#define WSPI rul__wm_specialize_id
#define WSPV rul__wm_specialize_var
#define WSOV rul__wm_set_offset_val
#define WSOVS rul__wm_set_offset_val_simple
#define WSVAV rul__wm_set_var_attr_val
#define WSCAV rul__wm_set_comp_attr_val
#define WSCAL rul__wm_set_comp_attr_last
#define WUN rul__wm_update_and_notify
#define WGOV rul__wm_get_offset_val
#define WGOVI rul__wm_get_offset_val_id
#define WGAVI rul__wm_get_attr_val_id
#define WGAVV rul__wm_get_attr_val_var
#define WGII rul__wm_get_instance_id
#define WGE rul__wm_get_every
#define WDNA rul__wm_destroy_and_notify_all
#define WDNI rul__wm_destroy_and_notify_id
#define WDACV rul__wm_destroy_all_class_var
#endif

Object rul__wm_create_var (Mol_Symbol,
 Entry_Data);
Object rul__wm_create (Class,
 Mol_Instance_Id,
 Entry_Data);
Object rul__wm_copy_id (Mol_Instance_Id,
 Entry_Data);
Object rul__wm_copy (Object,
 Entry_Data);
void rul__wm_destroy_and_notify_id (Mol_Instance_Id,
 Entry_Data);
void rul__wm_destroy_and_notify (Object,
 Entry_Data);
void rul__wm_destroy_all_class_var (Mol_Symbol,
 Entry_Data);
void rul__wm_destroy_and_notify_all (Class,
 Entry_Data);
Object rul__wm_modify_id (Mol_Instance_Id,
 Entry_Data);
void rul__wm_modify (Object,
 Entry_Data);
Object rul__wm_specialize_var (Mol_Instance_Id,
 Mol_Symbol,
 Entry_Data);
Object rul__wm_specialize_id (Mol_Instance_Id,
 Class,
 Entry_Data);
Object rul__wm_specialize (Object,
 Class,
 Entry_Data);
void rul__wm_set_offset_val (Object,
 long,
 Molecule,
 Entry_Data);
void rul__wm_set_offset_val_simple (Object,
 long,
 Molecule,
 Entry_Data);
void rul__wm_set_attr_val (Object,
 Mol_Symbol,
 Molecule,
 Entry_Data);
void rul__wm_set_var_attr_val (Object,
 Mol_Symbol,
 Molecule,
 Entry_Data);
void rul__wm_set_comp_attr_val (Object,
 Mol_Symbol,
 Molecule,
 Molecule,
 Entry_Data);
void rul__wm_set_comp_attr_last (Object,
 Mol_Symbol,
 Molecule,
 Entry_Data);
void rul__wm_update_and_notify (Object,
 Entry_Data);
Mol_Instance_Id rul__wm_get_instance_id (Object);

Molecule rul__wm_get_offset_val (Object,
 long);
Molecule rul__wm_get_offset_val_id (Mol_Instance_Id,
 long);
Molecule rul__wm_get_attr_val (Object,
 Mol_Symbol);
Molecule rul__wm_get_attr_val_id (Mol_Instance_Id,
 Mol_Symbol,
 Entry_Data);
Molecule rul__wm_get_attr_val_var (Mol_Instance_Id,
 Mol_Symbol,
 Entry_Data);
Mol_Compound rul__wm_get_every (Mol_Symbol,
 Entry_Data);

void rul__ios_init (void);
IO_Stream rul__ios_open_file_rt (Mol_Symbol,
 Mol_Symbol,
 Mol_Symbol);
void rul__ios_close_files (long, ...);
void rul__ios_write (long, ...);
void rul__ios_set_default_rt (Mol_Symbol, Mol_Symbol);
Mol_Symbol rul__ios_is_open (Mol_Symbol);
Mol_Atom rul__ios_accept_atom (Mol_Symbol);
Mol_Compound rul__ios_accept_line (Mol_Symbol,
 Mol_Compound);

long rul__cvt_s_in_s_lo (Mol_Int_Atom);
Mol_Int_Atom rul__cvt_s_lo_s_in (long);
short rul__cvt_s_in_s_sh (Mol_Int_Atom);
Mol_Int_Atom rul__cvt_s_sh_s_in (short);
char rul__cvt_s_in_s_by (Mol_Int_Atom);
Mol_Int_Atom rul__cvt_s_by_s_in (char);
unsigned long rul__cvt_s_in_s_ul (Mol_Int_Atom);
Mol_Int_Atom rul__cvt_s_ul_s_in (unsigned long);
unsigned short rul__cvt_s_in_s_us (Mol_Int_Atom);
Mol_Int_Atom rul__cvt_s_us_s_in (unsigned short);
unsigned char rul__cvt_s_in_s_ub (Mol_Int_Atom);
Mol_Int_Atom rul__cvt_s_ub_s_in (unsigned char);
float rul__cvt_s_in_s_sf (Mol_Int_Atom);
Mol_Int_Atom rul__cvt_s_sf_s_in (float);
double rul__cvt_s_in_s_df (Mol_Int_Atom);
Mol_Int_Atom rul__cvt_s_df_s_in (double);
long rul__cvt_s_db_s_lo (Mol_Dbl_Atom);
Mol_Dbl_Atom rul__cvt_s_lo_s_db (long);
short rul__cvt_s_db_s_sh (Mol_Dbl_Atom);
Mol_Dbl_Atom rul__cvt_s_sh_s_db (short);
char rul__cvt_s_db_s_by (Mol_Dbl_Atom);
Mol_Dbl_Atom rul__cvt_s_by_s_db (char);
unsigned long rul__cvt_s_db_s_ul (Mol_Dbl_Atom);
Mol_Dbl_Atom rul__cvt_s_ul_s_db (unsigned long);
unsigned short rul__cvt_s_db_s_us (Mol_Dbl_Atom);
Mol_Dbl_Atom rul__cvt_s_us_s_db (unsigned short);
unsigned char rul__cvt_s_db_s_ub (Mol_Dbl_Atom);
Mol_Dbl_Atom rul__cvt_s_ub_s_db (unsigned char);
float rul__cvt_s_db_s_sf (Mol_Dbl_Atom);
Mol_Dbl_Atom rul__cvt_s_sf_s_db (float);
double rul__cvt_s_db_s_df (Mol_Dbl_Atom);
Mol_Dbl_Atom rul__cvt_s_df_s_db (double);
void *rul__cvt_s_op_s_vd (Mol_Opaque);
Mol_Opaque rul__cvt_s_vd_s_op (void *ext_obj );
char *rul__cvt_s_at_s_az (Mol_Atom, char *);
Mol_Symbol rul__cvt_s_az_s_sy (char *);
Mol_Atom rul__cvt_s_az_s_at (char *);
String *rul__cvt_s_at_s_ad (Mol_Atom, String *);
Mol_Symbol rul__cvt_s_ad_s_sy (String *);
Mol_Atom rul__cvt_s_ad_s_at (String *);
long rul__cvt_s_at_s_lo (Mol_Atom);
short rul__cvt_s_at_s_sh (Mol_Atom);
char rul__cvt_s_at_s_by (Mol_Atom);
unsigned long rul__cvt_s_at_s_ul (Mol_Atom);
unsigned short rul__cvt_s_at_s_us (Mol_Atom);
unsigned char rul__cvt_s_at_s_ub (Mol_Atom);
float rul__cvt_s_at_s_sf (Mol_Atom);
double rul__cvt_s_at_s_df (Mol_Atom);
void *rul__cvt_s_at_s_vd (Mol_Atom);
Molecule rul__cvt_s_at_s_ta (Molecule);
Molecule rul__cvt_s_ta_s_at (Molecule);
Mol_Atom rul__cvt_s_ta_s_na (Mol_Atom);
Mol_Atom rul__cvt_s_ta_s_in (Mol_Atom);
Mol_Atom rul__cvt_s_ta_s_db (Mol_Atom);
Mol_Atom rul__cvt_s_ta_s_sy (Mol_Atom);
Mol_Atom rul__cvt_s_at_s_sy (Mol_Atom);
Mol_Atom rul__cvt_s_ta_s_op (Mol_Atom);
Mol_Atom rul__cvt_s_ta_s_id (Mol_Atom);
Mol_Compound rul__cvt_a_lo_c_in (long *, long);
Mol_Compound rul__cvt_a_sh_c_in (short *, long);
Mol_Compound rul__cvt_a_by_c_in (char *, long);
Mol_Compound rul__cvt_a_ul_c_in (unsigned long *, long);
Mol_Compound rul__cvt_a_us_c_in (unsigned short *, long);
Mol_Compound rul__cvt_a_ub_c_in (unsigned char *, long);
Mol_Compound rul__cvt_a_sf_c_db (float *, long);
Mol_Compound rul__cvt_a_df_c_db (double *, long);
Mol_Compound rul__cvt_a_az_c_sy (char **array, long);
Mol_Compound rul__cvt_a_az_c_at (char **array, long);
Mol_Compound rul__cvt_a_ad_c_sy (String **array, long);
Mol_Compound rul__cvt_a_ad_c_at (String **array, long);
Mol_Compound rul__cvt_a_ta_c_at (Mol_Atom *, long);
Mol_Compound rul__cvt_a_vd_c_op (void **array, long);
long *rul__cvt_c_at_a_lo (Mol_Compound, long, long *);
short *rul__cvt_c_at_a_sh (Mol_Compound, long, short *);
char *rul__cvt_c_at_a_by (Mol_Compound, long, char *);
unsigned long *rul__cvt_c_at_a_ul (Mol_Compound,
 long, unsigned long *);
unsigned short *rul__cvt_c_at_a_us (Mol_Compound,
 long, unsigned short *);
unsigned char *rul__cvt_c_at_a_ub (Mol_Compound,
 long, unsigned char *);
float *rul__cvt_c_at_a_sf (Mol_Compound, long, float *);
double *rul__cvt_c_at_a_df (Mol_Compound, long, double *);
char **rul__cvt_c_at_a_az (Mol_Compound, long, char **optr);
String **rul__cvt_c_at_a_ad (Mol_Compound, long, String **optr);
Mol_Atom *rul__cvt_c_at_a_ta (Mol_Compound, long, Mol_Atom *);
void **rul__cvt_c_at_a_vd (Mol_Compound, long, void **optr);
void rul__cvt_free (void *);

void rul__sql_rse_init (void);
char *rul__sql_rse (void);
void rul__sql_rse_symbol (RulMolecule symbol,
 RulBoolean quoted);
long rul__sql_attach (long filenamep,
 char *schema_source,
 char *dbkey_scope);
long rul__sql_commit (void);
long rul__sql_delete (char *SQL_table_name,
 char *SQL_where_clause,
 RulEntry_Data eb_data);
long rul__sql_detach (void);
long rul__sql_fetch_setup (char *rse);
long rul__sql_fetch_to_wme (RulMolecule **wme_id_array,
 long *num_wmes_fetched,
 RulEntry_Data eb_data);
long rul__sql_fetch_each (RulMolecule **value_array,
 long num_values,
 RulEntry_Data eb_data);
long rul__sql_fetch_cleanup (RulMolecule *array);
long rul__sql_insert (char *SQL_table_name,
 char *SQL_set_expression,
 RulEntry_Data eb_data);
long rul__sql_insert_from_wme (RulMolecule wme_id,
 RulEntry_Data eb_data);
long rul__sql_rollback (void);
long rul__sql_start (char *txn_type);
long rul__sql_update (char *SQL_table_name,
 char *SQL_set_expression,
 RulEntry_Data eb_data);
long rul__sql_update_from_wme (RulMolecule wme_id,
 char *SQL_where_clause,
 RulEntry_Data eb_data);

void rul__at (Mol_Symbol);
void rul__addstate (Mol_Symbol, Entry_Data);
void rul__restorestate (Mol_Symbol, Entry_Data);
void rul__savestate (Mol_Symbol, Entry_Data);
