GhostScript_(GS6.01), Software, PostScript interpreter to wide selection of output formats/printers

                          Overview of Ghostscript

If this is your first contact with Ghostscript, before continuing here you
should read the documentation for new users, where you'll find

   * what Ghostscript does (PostScript and PDF previewing, conversion, and
     printing);
   * its licensing terms (free for ordinary use);
   * what platforms it runs on (every platform you're likely to be
     interested in);
   * where to find some useful programs that enhance Ghostscript (like
     user-friendly previewers for Unix, VMS, MS Windows, DOS, and
     Macintosh); and
   * what to do if you need help.

The rest of this document is a roadmap to the Ghostscript documentation.
After looking through it, if you want to install Ghostscript and not only
use it, we recommend you read how to install Ghostscript, and how to compile
Ghostscript from source code (which is necessary before installing it on
Unix and VMS systems).
  ------------------------------------------------------------------------

Copyright � 1996, 1997, 1998 Aladdin Enterprises. All rights reserved.

This file is part of Aladdin Ghostscript. See the Aladdin Free Public
License (the "License") for full details of the terms of using, copying,
modifying, and redistributing Aladdin Ghostscript.

Ghostscript version 6.0, 3 February 2000
