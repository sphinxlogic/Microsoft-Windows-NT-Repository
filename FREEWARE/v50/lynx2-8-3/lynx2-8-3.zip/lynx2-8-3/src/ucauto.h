#ifndef UCAUTO_H
#define UCAUTO_H

#include <UCDefs.h>

extern void UCChangeTerminalCodepage PARAMS((int newcs, LYUCcharset *p));

#endif /* UCAUTO_H */
