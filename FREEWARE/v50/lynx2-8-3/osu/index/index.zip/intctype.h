#ifdef islower
#undef islower
#endif
#ifdef _islower
#undef _islower
#endif
#ifdef isupper
#undef isupper
#endif
#ifdef _isupper
#undef _isupper
#endif

#define islower(c) inter_islower(c)
#define _islower(c) inter_islower(c)
#define isupper(c) inter_isupper(c)
#define _isupper(c) inter_isupper(c)

#ifdef tolower
#undef tolower
#endif
#ifdef _tolower
#undef _tolower
#endif
#ifdef toupper
#undef toupper
#endif
#ifdef _toupper
#undef _toupper
#endif

#define tolower(c) inter_tolower(c)
#define _tolower(c) inter_tolower(c)
#define toupper(c) inter_toupper(c)
#define _toupper(c) inter_toupper(c)

int inter_islower(int c);
int inter_isupper(int c);
int inter_tolower(int c);
int inter_toupper(int c);
