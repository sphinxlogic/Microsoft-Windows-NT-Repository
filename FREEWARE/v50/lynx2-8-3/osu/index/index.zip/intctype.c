#include <ctype.h>

int inter_islower(int c)
{
   int clow;
   if ( ( (c>=224) && (c<=253) ) ||
        ( (c>=-32) && (c<=-3) ) ) {
      clow=2;
   } else {
      clow=islower(c);
   }
   return clow;
}

int inter_isupper(int c)
{
   int cupp;
   if ( ( (c>=192) && (c<=221) ) ||
        ( (c>=-64) && (c<=-35) ) ) {
      cupp=2;
   } else {
      cupp=isupper(c);
   }
   return cupp;
}

int inter_tolower(int c)
{
   int clow;
   if ( ( (c>=192) && (c<=221) ) ||
        ( (c>=-64) && (c<=-35) ) ) {
      clow=c+32;
   } else {
      clow=tolower(c);
   }
   return clow;
}

int inter_toupper(int c)
{
   int cupp;
   if ( ( (c>=224) && (c<=253) ) ||
        ( (c>=-32) && (c<=-3) ) ) {
      cupp=c-32;
   } else {
      cupp=toupper(c);
   }
   return cupp;
}

