#undef __STDC__
#include <string.h>
#define __STDC__ 1
