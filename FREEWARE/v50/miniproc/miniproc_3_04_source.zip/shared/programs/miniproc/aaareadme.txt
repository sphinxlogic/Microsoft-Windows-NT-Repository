This is the 2-FEB-1998 distribution for miniproc, version 2.00.

Miniproc is a small general purpose text preprocessor.   Miniproc is
intended to be a portable, and much simpler, alternative to perl and M4. 
Miniproc is written in ANSI C. Some possible applications are: 

  1. Preprocessor for languages which do not have their own standard 
  preprocessor (ie, Fortran.)  For use in preparing a single standard 
  presource which is processed through miniproc to result in platform 
  specific final source file(s).

  2. Make-like utility for batches of HTML files. Example, you have many
  documents which all include a standard disclaimer on the bottom.  Change
  the disclaimer, and run a miniproc script to update the final HTML files.
  Or it could be run periodically in a batch queue to update dates within  
  documents.

  3. Mailing lists.  That is, whenever you need to generate
  many similar files which are all variants on a single template.

The miniproc home page is located at:

  http://seqaxp.bio.caltech.edu/www/miniproc.html

Follow the links from there to pick up the source distribution, which 
contains:

  aaareadme.txt     this file
  miniproc.c        source code for miniproc
  miniproc.doc      documentation for miniproc (text)
  miniproc_doc.html documentation for miniproc (html)
  testfile.mpc      example input file
  test.txt          example output files
  test2.txt

If you don't have a compiler, there are also binary distributions for
several different platforms with obvious names.  The current ones are:

  miniproc_2_00_ovms_alpha_7_1.zip
  miniproc_2_00_irix_5_3.gz
  miniproc_2_00_solaris_gcc.gz
  miniproc_2_00_win32_codewarrior.zip  
  miniproc_2_00_d_unix_decc.gz

The program is known to build without warning or error on:

  OpenVMS Alpha, DECC
  Irix, SGI C
  Digital Unix, DECC
  Digital Unix, gnu cc
  Solaris, gnu cc
  Windows32, Metrowerks Codewarrior Pro 2

To build miniproc:

 OpenVMS with DECC

   $ cc/standard=ansi89/prefix=all/warn=(enable=all,disable=TRUNCINTASN) miniproc.c
   $ link miniproc

 Digital Unix with DECC

   % cc -std1 -o miniproc miniproc.c -lm

 Irix

   % cc -ansi -o miniproc miniproc.c -lm

 GCC (any platform)
 
   % gcc -ansi -pedantic -o miniproc miniproc.c -lm

 Windows 32, Codewarrior Pro 2

   Build it as an ANSI C "windows console application"

   (However, stat() is broken on the Codewarrior release that I have, so
   stat() based functions don't work correctly.)

To test miniproc:

 If your operating system overwrites files (most do), do the equivalent of:

 $ rename test.txt   etest.txt
 $ rename test2.txt etest2.txt

 then run it with

 $ miniproc testfile.mpc test1=1 test2=0 test3=0

 and compare the results with

 $ diff test.txt  etest.txt
 $ diff test2.txt etest2.txt

 (Some systems may see slightly different file  structures for the newly
 created test*.txt files and the test*.txt files provided in the distribution.)

 The following files will also be created, but you can ignore them:
  fin_1.mpc
  fin_2.mpc
  fin_3.mpc
  fin_4.mpc
  fin_5.mpc
  altprefix.mpc
  altprefix2.mpc

This software may be used freely, but may not be redistributed.  You may
modify this sofware for your own use, but you may not incorporate any part
of the original code into any other piece of software which will then be
distributed (whether free or commercial) unless prior written consent is
obtained.  For more information, or to report bugs, contact:

David Mathog
mathog@seqaxp.bio.caltech.edu
Manager, sequence analysis facility, biology division, Caltech 
