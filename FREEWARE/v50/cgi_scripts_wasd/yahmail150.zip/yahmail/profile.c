/*****************************************************************************/
/*
                                 Profile.c

This module profides functions related to VMS mail user profiles.


COPYRIGHT
---------
Copyright (c) 1999-2001 Mark G.Daniel
This program, comes with ABSOLUTELY NO WARRANTY.
This is free software, and you are welcome to redistribute it
under the conditions of the GNU GENERAL PUBLIC LICENSE, version 2.


VERSION HISTORY
---------------
19-FEB-2000  MGD  unbundled from YAHMAIL.C for v1.3
*/

/*****************************************************************************/

#ifdef __ALPHA
#   pragma nomember_alignment
#endif

/* standard C header files */
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>

/* VMS related header files */
#include <maildef.h>
#include <mailmsgdef.h>
#include <ssdef.h>
#include <stsdef.h>

/* application header file */
#include "yahmail.h"
#include "externs.h"

#define FI_LI __FILE__, __LINE__

/*****************************************************************************/
/*
Display a form containing configurable elements of a VMS mail user profile
entry.  This form can then be submitted changing the actual entry.
*/

DisplayUserProfile ()

{
   static char  ItemChecked [] = " CHECKED";

   int  status;
   char  *UserNamePtr,
         *EditorPtr,
         *FormPtr,
         *ForwardingPtr,
         *FullDirectoryPtr,
         *PersonalNamePtr,
         *QueuePtr,
         *SigFilePtr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "DisplayUserProfile()\n");

   UserNamePtr = (char*)CgiLibHtmlEscape (MailUserName, -1, NULL, 0);
   EditorPtr = (char*)CgiLibHtmlEscape (VmsMailUserEditor, -1, NULL, 0);
   ForwardingPtr = (char*)CgiLibHtmlEscape (VmsMailUserForwarding, -1, NULL, 0);
   FullDirectoryPtr = (char*)CgiLibHtmlEscape (VmsMailUserFullDirectory, -1, NULL, 0);
   PersonalNamePtr = (char*)CgiLibHtmlEscape (VmsMailUserPersonalName, -1, NULL, 0);
   QueuePtr = (char*)CgiLibHtmlEscape (VmsMailUserQueue, -1, NULL, 0);
   FormPtr = (char*)CgiLibHtmlEscape (VmsMailUserForm, -1, NULL, 0);

   CgiLibResponseHeader (200, "text/html");
   fprintf (stdout,
"<HTML>\n\
<HEAD>\n\
<META NAME=\"generator\" CONTENT=\"%s\">\n\
<META NAME=\"environment\" CONTENT=\"%s\">\n\
<META NAME=\"language\" CONTENT=\"%s %s\">\n\
<TITLE>yahMAIL ... %s: %s</TITLE>\n\
</HEAD>\n\
<BODY %s>\n\
%s\
<B><FONT SIZE=+1><U>%s: %s</FONT></U></B>\n\
<BR>&nbsp;<FONT SIZE=-1>yahMAIL<SUP>*</SUP></FONT>\n\
<FORM ACTION=\"%s\">\n\
<TABLE CELLPADDING=0 CELLSPACING=0 BORDER=0>\n\
<TR><TH ALIGN=right VALIGN=center>%s:&nbsp;&nbsp;</TH>\
<TD><INPUT TYPE=radio NAME=uap VALUE=1%s>&nbsp;<I>enabled</I>&nbsp;&nbsp;\
<INPUT TYPE=radio NAME=uap VALUE=0%s>&nbsp;<I>disabled</I></TD></TR>\n\
<TR><TH ALIGN=right VALIGN=center>%s:&nbsp;&nbsp;</TH>\
<TD><INPUT TYPE=radio NAME=ucp VALUE=1%s>&nbsp;<I>enabled</I>&nbsp;&nbsp;\
<INPUT TYPE=radio NAME=ucp VALUE=0%s>&nbsp;<I>disabled</I></TD></TR>\n\
<TR><TH ALIGN=right VALIGN=center>%s:&nbsp;&nbsp;</TH>\
<TD><INPUT TYPE=radio NAME=ucf VALUE=1%s>&nbsp;<I>enabled</I>&nbsp;&nbsp;\
<INPUT TYPE=radio NAME=ucf VALUE=0%s>&nbsp;<I>disabled</I></TD></TR>\n\
<TR><TH ALIGN=right VALIGN=center>%s:&nbsp;&nbsp;</TH>\
<TD><INPUT TYPE=radio NAME=ucr VALUE=1%s>&nbsp;<I>enabled</I>&nbsp;&nbsp;\
<INPUT TYPE=radio NAME=ucr VALUE=0%s>&nbsp;<I>disabled</I></TD></TR>\n\
<TR><TH ALIGN=right VALIGN=center>%s:&nbsp;&nbsp;</TH>\
<TD><INPUT TYPE=radio NAME=ucs VALUE=1%s>&nbsp;<I>enabled</I>&nbsp;&nbsp;\
<INPUT TYPE=radio NAME=ucs VALUE=0%s>&nbsp;<I>disabled</I></TD></TR>\n\
<TR><TD HEIGHT=10></TD></TR>\n\
<TR><TH ALIGN=right VALIGN=center>%s:&nbsp;&nbsp;</TH>\
<TD><INPUT TYPE=text SIZE=20 NAME=ued VALUE=\"%s\"></TD></TR>\n\
<TR><TH ALIGN=right VALIGN=center>%s:&nbsp;&nbsp;</TH>\
<TD><INPUT TYPE=text SIZE=60 NAME=ufw VALUE=\"%s\"></TD></TR>\n\
<TR><TH ALIGN=right VALIGN=center>%s:&nbsp;&nbsp;</TH>\
<TD><INPUT TYPE=text SIZE=60 NAME=upn VALUE=\"%s\"></TD></TR>\n",
      SoftwareID, CgiEnvironmentPtr, lang_Language, lang_LanguageAuthor,
      lang_ProUserProfile, UserNamePtr,
      ConfigBodyTagPtr, PostMasterWarningPtr,
      lang_ProUserProfile, UserNamePtr,
      ActionPathInfo,
      lang_ProAutoPurge, VmsMailUserAutoPurge ? ItemChecked : "",
                         VmsMailUserAutoPurge ? "" : ItemChecked,
      lang_ProCcPrompt, VmsMailUserCcPrompt ? ItemChecked : "",
                        VmsMailUserCcPrompt ? "" : ItemChecked,
      lang_ProCopyFwd,  VmsMailUserCopyForward ? ItemChecked : "",
                        VmsMailUserCopyForward ? "" : ItemChecked,
      lang_ProCopyReply, VmsMailUserCopyReply ? ItemChecked : "",
                         VmsMailUserCopyReply ? "" : ItemChecked,
      lang_ProCopySend, VmsMailUserCopySend ? ItemChecked : "",
                        VmsMailUserCopySend ? "" : ItemChecked,
      lang_ProEditor, EditorPtr,
      lang_ProForwarding, ForwardingPtr,
      lang_ProPersonalName, PersonalNamePtr);

   if (VmsVersion >= 70)
   {
      SigFilePtr = (char*)CgiLibHtmlEscape (VmsMailUserSigFile, -1, NULL, 0);

      fprintf (stdout,
"<TR><TH ALIGN=right VALIGN=center>%s:&nbsp;&nbsp;</TH>\
<TD><INPUT TYPE=text SIZE=20 NAME=usf VALUE=\"%s\">\
<INPUT TYPE=hidden NAME=wha VALUE=\"sig\">\
&nbsp;&nbsp;<INPUT TYPE=submit NAME=act VALUE=\"%s\"></TD></TR>\n",
         lang_ProSignatureFile, SigFilePtr, lang_BtnAccess);

      free (SigFilePtr);
   }

   fprintf (stdout,
"<TR><TH ALIGN=right VALIGN=center>%s:&nbsp;&nbsp;</TH>\
<TD><INPUT TYPE=text SIZE=20 NAME=upq VALUE=\"%s\"></TD></TR>\n\
<TR><TH ALIGN=right VALIGN=center>%s:&nbsp;&nbsp;</TH>\
<TD><INPUT TYPE=text SIZE=20 NAME=upf VALUE=\"%s\"></TD></TR>\n\
<TR><TH ALIGN=right VALIGN=center>%s:&nbsp;&nbsp;</TH>\
<TD><INPUT TYPE=text SIZE=3 NAME=unm></TD></TR>\n\
</TABLE>\n\
<P><INPUT TYPE=submit NAME=act VALUE=\"%s\">&nbsp;\n\
<INPUT TYPE=reset VALUE=\"%s\">\n",
      lang_ProPrintQueue, QueuePtr,
      lang_ProPrintForm, FormPtr,
      lang_ProNewMessages,
      lang_BtnSet, lang_BtnReset);

   if (PostMasterAuthenticated)
      fprintf (stdout,
"<P><INPUT TYPE=submit NAME=act VALUE=\"%s\"> ... %s\n",
         lang_BtnDeleteUserProfile,
         FullDirectoryPtr[0] ? FullDirectoryPtr : "<I>(no directory set)</I>");

   fprintf (stdout,
"<P><INPUT TYPE=button VALUE=\"%s\" onClick=\"history.go(-1)\">\n\
</FORM>\n\
</BODY>\n\
</HTML>\n",
      lang_BtnGoBack);

   free (UserNamePtr);
   free (EditorPtr);
   free (FormPtr);
   free (ForwardingPtr);
   free (FullDirectoryPtr);
   free (PersonalNamePtr);
   free (QueuePtr);
}

/*****************************************************************************/
/*
Generate an HTML page listing all those in the user profile file.
*/

BrowseUserList ()

{
   register struct UserListStruct  *ulptr;

   char  LastAlphabetic;
   char  HtmlUserName [256],
         UrlUserName [256];

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "BrowseUserList()\n");

   LastAlphabetic = '\0';

   CgiLibResponseHeader (200, "text/html");
   fprintf (stdout,
"<HTML>\n\
<HEAD>\n\
<META NAME=\"generator\" CONTENT=\"%s\">\n\
<META NAME=\"environment\" CONTENT=\"%s\">\n\
<META NAME=\"language\" CONTENT=\"%s %s\">\n\
<TITLE>yahMAIL ... %s</TITLE>\n\
</HEAD>\n\
<BODY %s>\n\
%s\
<B><FONT SIZE=+1><U>%s: &nbsp;%d %s</FONT></U></B>\n\
<BR>&nbsp;<FONT SIZE=-1>yahMAIL<SUP>*</SUP></FONT>\n\
<BLOCKQUOTE>",
      SoftwareID, CgiEnvironmentPtr, lang_Language, lang_LanguageAuthor,
      lang_ProUserProfileList, ConfigBodyTagPtr, PostMasterWarningPtr,
      lang_ProUserProfileList, UserListCount, lang_Entries);

   for (ulptr = UserListHeadPtr; ulptr != NULL; ulptr = ulptr->NextPtr)
   {
      CgiLibHtmlEscape (ulptr->UserNamePtr, -1,
                        HtmlUserName, sizeof(HtmlUserName));
      CgiLibUrlEncode (ulptr->UserNamePtr, -1,
                       UrlUserName, sizeof(UrlUserName));

      if (LastAlphabetic && (ulptr->UserNamePtr[0] == LastAlphabetic))
         fprintf (stdout, ",\n<A HREF=\"%s/%c%s?act=%s\">%s</A>",
                  CgiScriptNamePtr, TildeChar, UrlUserName,
                  lang_ProfileUser, HtmlUserName);
      else
         fprintf (stdout, "\n<P><A HREF=\"%s/%c%s?act=%s\">%s</A>",
                  CgiScriptNamePtr, TildeChar, UrlUserName,
                  lang_ProfileUser, HtmlUserName);
      LastAlphabetic = ulptr->UserNamePtr[0];
   }

   fprintf (stdout,
"\n\
</BLOCKQUOTE>\n\
</BODY>\n\
</HTML>\n");
}

/*****************************************************************************/

