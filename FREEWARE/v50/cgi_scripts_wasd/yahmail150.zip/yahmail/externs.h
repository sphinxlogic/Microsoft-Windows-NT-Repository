/*****************************************************************************/
/*
                               Externs.h

Provides 'extern' declarations of all global storage (which by convention is
declared in YAHMAIL.C) to all other .C modules.


COPYRIGHT
---------
Copyright (c) 1999,2000 Mark G.Daniel
This program, comes with ABSOLUTELY NO WARRANTY.
This is free software, and you are welcome to redistribute it
under the conditions of the GNU GENERAL PUBLIC LICENSE, version 2.


VERSION HISTORY
---------------
17-FEB-2000  MGD  unbundled from YAHMAIL.C for v1.3
*/

/*****************************************************************************/

#ifndef EXTERNS_H_LOADED
#define EXTERNS_H_LOADED

#ifdef __ALPHA
#   pragma nomember_alignment
#endif

extern boolean  CliMimeNoSubjectKludge,
                CliMimeSubjectKludge,
                CliNoPMDF,
                CliPostMasterEnabled,
                ConfigPrivate,
                ConfigPublic,
                ConfigPublicBrowseFolders,
                Debug,
                DoAddrListAccess,
                DoAddrListRemove,
                DoAddrListSelect,
                DoAddrListUpdate,
                DoFolderBrowse,
                DoMessageAttach,
                DoMessageCopy,
                DoMessageCreate,
                DoMessageDelete,
                DoMessageEmptyWasteBasket,
                DoMessageForward,
                DoMessageMove,
                DoMessageRead,
                DoMessageReadMunpack,
                DoMessageReadOctetStream,
                DoMessageReadPlainText,
                DoMessageReply,
                DoMessageSend,
                DoSigFileAccess,
                DoSigFileUpdate,
                DoUserCreate,
                DoUserDelete,
                DoUserList,
                DoUserProfile,
                DoUserSet,
                IsCgiPlus,
                MailProtocolIsPMDF,
                MimeAttachmentSubjectKludge,
                OsuEnvironment,
                PostMasterAuthenticated,
                PrivateSetupHide,
                PrivateSetupShow,
                StdCgiEnvironment;

extern int  BrowsePage,
            BrowseWindow,
            CgiPlusUsageCount,
            CheckNewMailMinutes,
            CurrentMessageCount,
            LongLineWrap,
            MakeAnchors,
            MessageIncrement,
            PublicConfigSubjCount,
            PublicConfigSubjLength,
            VmsVersion,
            WrapAt,
            WrapLongLines;

extern char  TildeChar;

extern char  *CliConfigFilePtr,
             *CgiAuthRealmPtr,
             *CgiEnvironmentPtr,
             *CgiFormActionPtr,
             *CgiFormBwcPtr,
             *CgiFormBwfPtr,
             *CgiFormBwmPtr,
             *CgiFormBwpPtr,
             *CgiFormBwuPtr,
             *CgiFormFolderNamePtr,
             *CgiFormIncludePtr,
             *CgiFormMunpackContentTypePtr,
             *CgiFormMunpackPtr,
             *CgiFormNnnPtr,
             *CgiFormPreEditedMessagePtr,
             *CgiFormQuotePtr,
             *CgiFormRefreshPtr,
             *CgiFormTarPtr,
             *CgiHttpCookiePtr,
             *CgiHttpHostPtr,
             *CgiHttpUserAgentPtr,
             *CgiRemoteUserPtr,
             *CgiRequestSchemePtr,
             *CgiServerNamePtr,
             *CgiServerPortPtr,
             *CgiServerSoftwarePtr,
             *CgiPathInfoPtr,
             *CgiQueryStringPtr,
             *CgiRemoteUserPtr,
             *CgiRequestMethodPtr,
             *CgiScriptNamePtr,
             *CgiTypePtr,
             *CliCharsetPtr,
             *ConfigAddrListPtr,
             *ConfigAddrListFooterPtr,
             *ConfigCreateFooterPtr,
             *ConfigBodyTagPtr,
             *ConfigCharsetPtr,
             *ConfigFolderFooterPtr,
             *ConfigFolderHeaderPtr,
             *ConfigLocalToSmtpPtr,
             *ConfigNewMailPtr,
             *ConfigPublicFooterPtr,
             *ConfigPublicHeaderPtr,
             *ConfigReadFooterPtr,
             *ConfigSmtpTransportPtr,
             *PostMasterWarningPtr,
             *PublicConfigSubjPtr,
             *PublicHeaderPtr,
             *PublicFooterPtr,
             *PublicTitlePtr;

extern char  ActionPathInfo[],
             ActionQueryString[],
             SchemeHostPort[],
             SoftwareID[];

extern char  PathPart [4][64];

extern int  SizeOfHtmlEscapedMailFolderName,
            SizeOfMailFileName,
            SizeOfMailFolderName;

/* extern variables, information to VMS mail */

extern unsigned long  CopyFolderNameLength,
                      MailFileContext,
                      MailFileContext,
                      MailFileMessagesDeleted,
                      MailFileNameLength,
                      MailFolderNameLength,
                      MailSubstringCcLength,
                      MailSubstringFromLength,
                      MailSubstringSubjLength,
                      MailSubstringToLength,
                      MailUserNameLength,
                      UserContext;

extern int  MailMessageIdCount;
extern unsigned long  MailMessageId [];

extern char  CopyFolderName[],
             HtmlEscapedMailFolderName[],
             MailFileName[],
             MailFolderName[],
             MailSubstringCc[],
             MailSubstringFrom[],
             MailSubstringSubj[],
             MailSubstringTo[],
             MailUserName[],
             PublicFileName[],
             PublicFolderName[],
             PublicUserName[];

/* global variables, information from VMS mail */

extern int  VmsMailHeaderLength,
            VmsMailRfc822HeaderLength,
            VmsMailRfc822MimeVersion;

extern unsigned long  VmsMailCcLength,
                      VmsMailDateLength,
                      VmsMailExtIdLength,
                      VmsMailFromLength,
                      VmsMailFolderLength,
                      VmsMailMessageFlags,
                      VmsMailMessageId,
                      VmsMailMessageSize,
                      VmsMailMessageSelectedCount,
                      VmsMailSenderLength,
                      VmsMailSigFileTextLength,
                      VmsMailSubjectLength,
                      VmsMailTextSize,
                      VmsMailTextLength,
                      VmsMailToLength,
                      VmsMailUserEditorLength,
                      VmsMailUserFormLength,
                      VmsMailUserForwardingLength,
                      VmsMailUserFullDirectoryLength,
                      VmsMailUserNewMessages,
                      VmsMailUserPersonalNameLength,
                      VmsMailUserQueueLength,
                      VmsMailUserSigFileLength,
                      VmsMailUserAutoPurge,
                      VmsMailUserCcPrompt,
                      VmsMailUserCopyForward,
                      VmsMailUserCopyReply,
                      VmsMailUserCopySend,
                      VmsMailWasteBasketNameLength;

extern unsigned long  VmsMailBinaryDate [2];

extern char  *VmsMailTextPtr,
             *VmsMailSigFileTextPtr;

extern char  VmsMailTo[],
             VmsMailCc[],
             VmsMailDate[],
             VmsMailExtId[],
             VmsMailFrom[],
             VmsMailFolder[],
             VmsMailRfc822MimeCharset[],
             VmsMailRfc822MimeContTransEnc[],
             VmsMailRfc822MimeContentType[],
             VmsMailSender[],
             VmsMailSubject[],
             VmsMailUserEditor[],
             VmsMailUserForm[],
             VmsMailUserFullDirectory[],
             VmsMailUserForwarding[],
             VmsMailUserPersonalName[],
             VmsMailUserQueue[],
             VmsMailUserSigFile[],
             VmsMailWasteBasketName[];

/* lists, etc. */

extern int  FolderListCount;
extern struct FolderListStruct  *FolderListHeadPtr,
                                *FolderListTailPtr;

extern int  MessageListCount;
extern struct MessageListStruct  *MessageListHeadPtr,
                                 *MessageListTailPtr;

extern int  UserListCount;
extern struct UserListStruct  *UserListHeadPtr,
                              *UserListTailPtr;

extern struct VmsItemStruct  NullItem;

#endif /* EXTERNS_H_LOADED */

/*****************************************************************************/

