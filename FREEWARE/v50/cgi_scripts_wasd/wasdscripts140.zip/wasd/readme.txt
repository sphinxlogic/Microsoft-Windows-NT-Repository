Access  README_APACHE.HTML  for VMS Apache specific information,
        README_OSU.HTML     for OSU (DECthreads) information,
        README_CGI.HTML     for other CGI (e.g. Purveyor) servers.
