/*****************************************************************************/
/*
                              qdLogStats.c

Quick & Dirty Log Statistics.

Utility to extract very elementary statistics from Web server common/combined
format log files.  A number of filters allow subsets of the log contents to be
selected.  These filters are simple sort-of regular expressions, not
case-sensitive (deliberately), can contain wildcards (such as asterisks (*),
question marks (?), and percent signs (%)) as well as sort-of regular
expressions (such as the range [a-z]).  THERE IS NO WAY (that I know of) TO
ESCAPE THESE RESERVED CHARACTERS!  This functionality uses decc$match_wild()
function.  When using filters it is necessary to provide wildcard 'match-alls'
at the start and/or end of the string if the searched-for string does not fall
at the start and/or end of the field.  Hence to find all records having a field
containing "fred" anywhere in the string the following must be used

  "*fred*"

Special constructs allow more complex expressions to be built up.  Combinations
of required and excluded strings may be specified in the one expression.  When
a string begins with a "+{" it *must* be present for the record NOT to be
filtered out.  If it begins "-{" then it must *not* be present.  Such
specifications must be terminated with a matching closure "}".  For example,
with the following expression

  "+{*test*}-{*fred*}"

the record field must contain a string "test" somewhere but cannot contain the
string "fred" anywhere.  The expression

  "+{*one*}+{*two*}"

specifies that the strings "one" and "two" must be present in the field but not
necessarily in any particular order.  An expression

  "-{*three*}-{*four*}"

excludes the field if it contains either of the two fields anywhere in it.

Matching log file records can be viewed as processed using the
/VIEW=[type] qualifier, where <type> is ALL, MATCH (default) or NOMATCH.

A progress indicator can be displayed using the /PROGRESS qualifier.  With this
a "+" is output for each file processed and a "." for each 1000 records in any
file.  An optional integer can be provides as /PROGRESS=integer to change this
record value.

Note that all selections are based on string matching.  Files and/or records
cannot be selected on the basis of being before or after a particular date for
instance.  Also that records are accepted or rejected in the order in which the
results are displayed, that is if a record is rejected against method it will
never be assessed against user-agent ... UNLESS then /ALL qualifier is applied. 
When /ALL is used comparison continues against all filter strings even if one
or more do not match.  This is useful for displaying the totals that match each
of multiple filter critera (not much use against a single one).

If /LOOKUP is enabled then dotted-decimal client host addresses have their
names resolved (if possible).  This name is displayed when log line is output. 
When enabled the resolved name is also used when matching against client hosts.

Although part of the WASD package there is no reason why this shouldn't be of
use with other packages if desired.


EXAMPLES
--------
Requires a foreign verb or such (shorter version might save keystrokes :^)

  $ QDLOG == "$HT_EXE:QDLOGSTATS"
  $ QDLOGSTATS == "$HT_EXE:QDLOGSTATS"

As the character sequences '/' then '*', and '*' then '/' are reserved in C,
the following examples have '@' substituted for '*'.  Please read '*' for all
instances of '@'!

1)  Records from September 1999.

    $ QDLOGSTATS HT_LOGS:@1999@.LOG /DATE="@/SEP/1999@"

2)  Records where the browser was an X-based Netscape Navigator

    $ QDLOGSTATS HT_LOGS:@.LOG /USERAGENT=@MOZILLA@X11@

3)  Records of POST method requests

    $ QDLOGSTATS HT_LOGS:@.LOG /METHOD=POST

4)  Records requesting a particular path

    $ QDLOGSTATS HT_LOGS:@.LOG /PATH="/cgi-bin/@"

5)  Records with a query string (second excludes those containing "grotty")

    $ QDLOGSTATS HT_LOGS:@.LOG /QUERY="%@"
    $ QDLOGSTATS HT_LOGS:@.LOG /QUERY="+{%@}-{@grotty@}"

6)  Records requesting a particular path, excluding the help script

    $ QDLOGSTATS HT_LOGS:@.LOG /PATH="+{/cgi-bin/@}-{/cgi-bin/help/@}"

7)  Select proxy records requesting (a) particular site(s)

    $ QDLOGSTATS HT_LOGS:@8080@.LOG /PATH="http://@.compaq.com@"
    $ QDLOGSTATS HT_LOGS:@8080@.LOG /METHOD=POST /PATH="http://@sex@.@/@"

8)  Records where the request was authenticated

    $ QDLOGSTATS HT_LOGS:@.LOG /AUTHUSER="-{-}"
    $ QDLOGSTATS HT_LOGS:@.LOG /AUTHUSER="DANIEL"

9)  Records where the request was authenticated, excluding DANIEL

    $ QDLOGSTATS HT_LOGS:@.LOG /AUTHUSER="-{-}-{DANIEL}"

10) Records with requests originating from (a) particular host(s)

    $ QDLOGSTATS HT_LOGS:@.LOG /CLIENT=131.185.250.1
    $ QDLOGSTATS HT_LOGS:@.LOG /LOOKUP /CLIENT=@.vsm.com.au


CGI INTERFACE
-------------
A CGI interface is available.  It basically parallels the CLI behaviour
described above. 

  http://the.host.name/cgi-bin/qdlogstats

So that it's not available for uncontrolled use the script *must* be subject to
authorization (i.e. have a non-empty REMOTE_USER).  For the WASD package this
may be enabled using the following HTTPD$AUTH rule.

  [whatever-realm]
  /cgi-bin/qdlogstats r+w

For VMS Apache (CSWS) using SYSUAF authentication this might be configured
using the following entries in [CONF]HTTPD.CONF

  LoadModule auth_openvms_module
  /apache$common/modules/mod_auth_openvms.exe_alpha

  <Location /cgi-bin/qdlogstats>
  AuthType Basic
  AuthName "OpenVMS authentication"
  AuthUserOpenVMS On
  require valid-user
  </Location>

If there seems to be no relevant CGI variables the script displays a request
form that allows the entering of strings against the various fields of the log
file entries.  This form uses the GET method (putting form elements into the
query string) and so searches commonly or periodically made can be saved as
bookmarks if desired.

The account processing the script must have access to the log directory and
files.  This may be provided by the server account itself (i.e. the logs are
normally accessable) or the scripting account itself has access.  For instance,
with WASD on VMS V6.2 or later this could be provided using the /PERSONA
functionality and a HTTPD$MAP rule such as

  set /cgi-bin/qdlogstats script=as=SYSTEM

An alternative is to install the script executable with sufficient privileges
to access the files.  Normally this would only be SYSPRV but as the script
attempts to enable READALL as well so it *could* be installed with that if
necessary.  The following example DCL executed during server startup would
ensure such access.

  $ INSTALL ADD /PRIVILEGE=SYSPRV HT_EXE:QDLOGSTATS.EXE

If this is provided it would also be prudent to control access to the
executable from arbitrary accounts at the CLI, and restricting it to the
scripting account using an ACL.  For example

  $ SET SECURITY HT_EXE:QDLOGSTATS.EXE -
        /ACL=((IDENT=HTTP$SERVER,ACCESS=R+E),(IDENT=*,ACCESS=NONE))


QUALIFIERS
----------
/ALL                  compare all records to all filters
/DBUG                 turns on all "if (Debug)" statements
/AUTHUSER=            pattern (any authenticated username)
/CLIENT=              pattern (client host name or IP address)
/DATETIME=            pattern ("11/Jun/1999:14:08:49 +0930")
/LOOKUP               lookup host name from dotted decimal address
/METHOD=              HTTP method ("GET", "POST", "HEAD", etc.)
/OUTPUT=              file specification
/PATH=                pattern (URL path component only)
/PROGRESS[=integer]   show progress during processing
/QUERY=               pattern (URL query component only)
/REFERER=             pattern (HTTP "Referer:" field, COMBINED only)
/REMOTEID=            pattern (anything in the RFC819 remote ident field)
/USERAGENT=           pattern (HTTP "User-Agent:", COMBINED only)
/VIEW[=type]          display matching records, where <type> can be
                      ALL, MATCH (default) or NOMATCH


BUILD DETAILS
-------------
See BUILD_QDLOGSTATS.COM procedure.


COPYRIGHT
---------
Copyright (c) 2000,2001 Mark G.Daniel
This program, comes with ABSOLUTELY NO WARRANTY.
This is free software, and you are welcome to redistribute it
under the conditions of the GNU GENERAL PUBLIC LICENSE, version 2.


VERSION HISTORY (update SOFTWAREID as well!)
---------------
10-JAN-2001  MGD  v1.2.0, lookup client host name
23-DEC-2000  MGD  v1.1.0, CGI interface (still pretty q&d)
14-NOV-2000  MGD  v1.0.0, initial development
*/
/*****************************************************************************/

#ifdef __ALPHA
#define SOFTWAREID "QDLOGSTATS AXP-1.2.0"
#else
#define SOFTWAREID "QDLOGSTATS VAX-1.2.0"
#endif

/* standard C header files */
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unixio.h>
#include <unixlib.h>

/* VMS-related header files */
#include <descrip.h>
#include <rms.h>
#include <lib$routines.h>
#include <prvdef.h>
#include <ssdef.h>
#include <stsdef.h>
#include <syidef.h>
#include <starlet.h>

/* TCP/IP-related header files */
#include <in.h>
#include <netdb.h>
#include <inet.h>

/* application related header files */
#include <cgilib.h>

#define boolean int
#define true 1
#define false 0

#define VMSok(x) ((x) & STS$M_SUCCESS)
#define VMSnok(x) (!((x) & STS$M_SUCCESS))
 
#define FI_LI "QDLOGSTATS",__LINE__

/* used in modulus for every so many records progress */
#define PROGRESS_RECORDS 1000
/* wrap every so many characters */
#define PROGRESS_WRAP_CLI 80
#define PROGRESS_WRAP_CGI 60

/* maximum log line/record length */
#define MAX_LINE_LENGTH 2048

/* maximum names in host cache */
#define MAX_LOOKUP_CACHE 256

#define DEFAULT_LOG_FILESPEC "*.LOG;"
#define DEFAULT_LOG_FILESPEC_APACHE "APACHE$SPECIFIC:[LOGS]ACCESS_LOG*.;"
#define DEFAULT_LOG_FILESPEC_OSU "WWW_ROOT:[SYSTEM]*.LOG;"
#define DEFAULT_LOG_FILESPEC_WASD "HT_LOGS:*ACCESS*.LOG;"

#define VIEW_NONE    0
#define VIEW_ALL     1
#define VIEW_MATCH   2
#define VIEW_NOMATCH 3

char  Utility [] = "QDLOGSTATS";

boolean  Debug,
         DoCgiStats,
         DoCliStats,
         FilterOnAll,
         LookupName;

int  AccessProblemCount,
     AuthUserFilterAcceptCount,
     AuthUserFilterRejectCount,
     ClientFilterAcceptCount,
     ClientFilterRejectCount,
     CombinedLogRecordCount,
     CommonLogRecordCount,
     DateTimeFilterRejectCount,
     DateTimeFilterAcceptCount,
     FileCountTotal,
     MethodFilterAcceptCount,
     MethodFilterRejectCount,
     PathFilterAcceptCount,
     PathFilterRejectCount,
     ProgressCount,
     ProgressWrap,
     QueryFilterAcceptCount,
     QueryFilterRejectCount,
     RecordCount,
     RecordCountTotal,
     SuspectRecordCountTotal,
     RequestCountTotal,
     RefererFilterAcceptCount,
     RefererFilterRejectCount,
     RemoteIdentFilterAcceptCount,
     RemoteIdentFilterRejectCount,
     ShowProgress,
     UserAgentFilterAcceptCount,
     UserAgentFilterRejectCount,
     ViewRecords;

int  StatusCodeCount [6];

float  ByteCountTotal;

char  *AuthUserFilterPtr,
      *CgiFormLogFileSpecPtr,
      *CgiLibEnvironmentPtr,
      *CgiScriptNamePtr,
      *ClientFilterPtr,
      *DateTimeFilterPtr,
      *LookupNamePtr,
      *MethodFilterPtr,
      *OutputPtr,
      *PathFilterPtr,
      *QueryFilterPtr,
      *RefererFilterPtr,
      *RemoteIdentFilterPtr,
      *SearchDna,
      *UserAgentFilterPtr;

char  LogFileSpec [256],
      SoftwareID [64] = SOFTWAREID;

/* required function prototypes */
boolean  FilterThisOut (char*, char*);
void CgiStats ();
void CgiForm ();
void CliStats ();
int GetParameters ();
char* LookupHostName (char**);
void OutputLogRecord (char*);
int ProcessLogFile (char*);
int ProcessLogRecord (char*);
int SearchFileSpec (char*);
int ShowHelp ();
int strsame (char*, char*, int);

/*****************************************************************************/
/*
'argc' and 'argv' are only required to support CgiLibEnvironmentInit(), in
particular the OSU environment.
*/

main
(
int argc,
char *argv[]
)
{
   /*********/
   /* begin */
   /*********/

   /* always initialize the CGILIB so we can at least determine the mode */
   if (getenv ("QDLOGSTATS$DBUG") != NULL) Debug = true;
   CgiLibEnvironmentSetDebug (Debug);
   CgiLibEnvironmentInit (argc, argv, false);

   GetParameters ();

   /* determine if we're at the command line or being used as a script */
   if (CgiLibVarNull ("WWW_GATEWAY_INTERFACE") == NULL)
   {
      DoCliStats = true;
      CliStats ();
   }
   else
   {
      DoCgiStats = true;
      CgiStats ();
   }

   exit (SS$_NORMAL);
}

/*****************************************************************************/
/*
*/

void CliStats ()

{
   int  DurationHr,
        DurationMin,
        DurationSec;
   char  AccessProblemString [64],
         AuthUserString [64],
         ByteString [64],
         ClientString [64],
         DateTimeString [64],
         MethodString [64],
         PathString [64],
         QueryString [64],
         RefererString [64],
         RemoteIdentString [64],
         UserAgentString [64];
   unsigned long  StartSeconds,
                  TimeSeconds;

   /*********/
   /* begin */
   /*********/

   if (OutputPtr != NULL)
      if ((stdout = freopen (OutputPtr, "w", stdout)) == NULL)
         exit (vaxc$errno);

   if (!LogFileSpec[0])
   {
      ShowHelp ();
      exit (SS$_NORMAL);
   }

   ProgressWrap = PROGRESS_WRAP_CLI;

   time (&StartSeconds);
   fprintf (stdout, "%s, %s", SoftwareID, ctime (&StartSeconds));

   /* make a guess at the log file defaults */
   if (getenv("HT_ROOT") != NULL)
      SearchDna = DEFAULT_LOG_FILESPEC_WASD;
   else
   if (getenv("WWW_ROOT") != NULL)
      SearchDna = DEFAULT_LOG_FILESPEC_OSU;
   else
   if (getenv("APACHE$SPECIFIC") != NULL)
      SearchDna = DEFAULT_LOG_FILESPEC_APACHE;
   else
      SearchDna = DEFAULT_LOG_FILESPEC;

   SearchFileSpec (LogFileSpec);

   if (ShowProgress && FileCountTotal) fputs ("\n", stdout);

   if (AccessProblemCount)
      sprintf (AccessProblemString, ", %d access failed", AccessProblemCount);
   else
      AccessProblemString[0] = '\0';

   if (ByteCountTotal > 1000000000.0)
   {
      ByteCountTotal /= 1000000000.0;
      sprintf (ByteString, "GBytes ....... %.3f", ByteCountTotal);
   }
   else
   if (ByteCountTotal > 1000000.0)
   {
      ByteCountTotal /= 1000000.0;
      sprintf (ByteString, "MBytes ....... %.3f", ByteCountTotal);
   }
   else
   if (ByteCountTotal > 1000.0)
   {
      ByteCountTotal /= 1000.0;
      sprintf (ByteString, "KBytes ....... %.3f", ByteCountTotal);
   }
   else
      sprintf (ByteString, "Bytes ........ %.0f", ByteCountTotal);

   time (&TimeSeconds);
   TimeSeconds -= StartSeconds;
   DurationHr = TimeSeconds / 3600;
   TimeSeconds -= DurationHr * 3600;
   DurationMin = TimeSeconds / 60;
   DurationSec = TimeSeconds - DurationMin * 60;

   if (FilterOnAll)
   {
      if (ClientFilterPtr == NULL)
         strcpy (ClientString, "<none>");
      else
         sprintf (ClientString, "  (%d nomatch, %d match)",
                  ClientFilterRejectCount, ClientFilterAcceptCount);
      if (AuthUserFilterPtr == NULL)
         strcpy (AuthUserString, "<none>");
      else
         sprintf (AuthUserString, "  (%d nomatch, %d match)",
                  AuthUserFilterRejectCount, AuthUserFilterAcceptCount);
      if (DateTimeFilterPtr == NULL)
         strcpy (DateTimeString, "<none>");
      else
         sprintf (DateTimeString, "  (%d nomatch, %d match)",
                  DateTimeFilterRejectCount, DateTimeFilterAcceptCount);
      if (MethodFilterPtr == NULL)
         strcpy (MethodString, "<none>");
      else
         sprintf (MethodString, "  (%d nomatch, %d match)",
                  MethodFilterRejectCount, MethodFilterAcceptCount);
      if (PathFilterPtr == NULL)
         strcpy (PathString, "<none>");
      else
         sprintf (PathString, "  (%d nomatch, %d match)",
                  PathFilterRejectCount, PathFilterAcceptCount);
      if (QueryFilterPtr == NULL)
         strcpy (QueryString, "<none>");
      else
         sprintf (QueryString, "  (%d nomatch, %d match)",
                  QueryFilterRejectCount, QueryFilterAcceptCount);
      if (RefererFilterPtr == NULL)
         strcpy (RefererString, "<none>");
      else
         sprintf (RefererString, "  (%d nomatch, %d match)",
                  RefererFilterRejectCount, RefererFilterAcceptCount);
      if (RemoteIdentFilterPtr == NULL)
         strcpy (RemoteIdentString, "<none>");
      else
         sprintf (RemoteIdentString, "  (%d nomatch, %d match)",
                  RemoteIdentFilterRejectCount, RemoteIdentFilterAcceptCount);
      if (UserAgentFilterPtr == NULL)
         strcpy (UserAgentString, "<none>");
      else
         sprintf (UserAgentString, "  (%d nomatch, %d match)",
                  UserAgentFilterRejectCount, UserAgentFilterAcceptCount);
   }
   else
   {
      if (ClientFilterPtr == NULL)
         strcpy (ClientString, "<none>");
      else
         sprintf (ClientString, "  (%d nomatch)", ClientFilterRejectCount);
      if (AuthUserFilterPtr == NULL)
         strcpy (AuthUserString, "<none>");
      else
         sprintf (AuthUserString, "  (%d nomatch)", AuthUserFilterRejectCount);
      if (DateTimeFilterPtr == NULL)
         strcpy (DateTimeString, "<none>");
      else
         sprintf (DateTimeString, "  (%d nomatch)", DateTimeFilterRejectCount);
      if (MethodFilterPtr == NULL)
         strcpy (MethodString, "<none>");
      else
         sprintf (MethodString, "  (%d nomatch)", MethodFilterRejectCount);
      if (PathFilterPtr == NULL)
         strcpy (PathString, "<none>");
      else
         sprintf (PathString, "  (%d nomatch)", PathFilterRejectCount);
      if (QueryFilterPtr == NULL)
         strcpy (QueryString, "<none>");
      else
         sprintf (QueryString, "  (%d nomatch)", QueryFilterRejectCount);
      if (RefererFilterPtr == NULL)
         strcpy (RefererString, "<none>");
      else
         sprintf (RefererString, "  (%d nomatch)", RefererFilterRejectCount);
      if (RemoteIdentFilterPtr == NULL)
         strcpy (RemoteIdentString, "<none>");
      else
         sprintf (RemoteIdentString, "  (%d nomatch)", RemoteIdentFilterRejectCount);
      if (UserAgentFilterPtr == NULL)
         strcpy (UserAgentString, "<none>");
      else
         sprintf (UserAgentString, "  (%d nomatch)", UserAgentFilterRejectCount);
   }

   fprintf (stdout,
"\n\
Log .......... %s  (%d processed%s)\n\
Client ....... %s%s%s%s\n\
Remote ID .... %s%s%s%s\n\
Auth User .... %s%s%s%s\n\
Date/Time .... %s%s%s%s\n\
Method ....... %s%s%s%s\n\
Path ......... %s%s%s%s\n\
Query ........ %s%s%s%s\n\
Referer ...... %s%s%s%s\n\
User Agent ... %s%s%s%s\n\
\n\
Duration ..... %02d:%02d:%02d\n\
Records ...... %d  (%d suspect, %d common, %d combined)\n\
Requests ..... %d\n\
Responses .... 1nn:%d  2nn:%d  3nn:%d  4nn:%d  5nn:%d  ?:%d\n\
%s\n",
      LogFileSpec, FileCountTotal, AccessProblemString,
      ClientFilterPtr == NULL ? "" : "\"" ,
      ClientFilterPtr == NULL ? "" : ClientFilterPtr,
      ClientFilterPtr == NULL ? "" : "\"" ,
      ClientString,
      RemoteIdentFilterPtr == NULL ? "" : "\"" ,
      RemoteIdentFilterPtr == NULL ? "" : RemoteIdentFilterPtr,
      RemoteIdentFilterPtr == NULL ? "" : "\"" ,
      RemoteIdentString,
      AuthUserFilterPtr == NULL ? "" : "\"" ,
      AuthUserFilterPtr == NULL ? "" : AuthUserFilterPtr,
      AuthUserFilterPtr == NULL ? "" : "\"" ,
      AuthUserString,
      DateTimeFilterPtr == NULL ? "" : "\"" ,
      DateTimeFilterPtr == NULL ? "" : DateTimeFilterPtr,
      DateTimeFilterPtr == NULL ? "" : "\"" ,
      DateTimeString,
      MethodFilterPtr == NULL ? "" : "\"" ,
      MethodFilterPtr == NULL ? "" : MethodFilterPtr,
      MethodFilterPtr == NULL ? "" : "\"" ,
      MethodString,
      PathFilterPtr == NULL ? "" : "\"" ,
      PathFilterPtr == NULL ? "" : PathFilterPtr,
      PathFilterPtr == NULL ? "" : "\"" ,
      PathString,
      QueryFilterPtr == NULL ? "" : "\"" ,
      QueryFilterPtr == NULL ? "" : QueryFilterPtr,
      QueryFilterPtr == NULL ? "" : "\"" ,
      QueryString,
      RefererFilterPtr == NULL ? "" : "\"" ,
      RefererFilterPtr == NULL ? "" : RefererFilterPtr,
      RefererFilterPtr == NULL ? "" : "\"" ,
      RefererString,
      UserAgentFilterPtr == NULL ? "" : "\"" ,
      UserAgentFilterPtr == NULL ? "" : UserAgentFilterPtr,
      UserAgentFilterPtr == NULL ? "" : "\"" ,
      UserAgentString,
      DurationHr, DurationMin, DurationSec,
      RecordCountTotal, SuspectRecordCountTotal,
      CommonLogRecordCount, CombinedLogRecordCount,
      RequestCountTotal,
      StatusCodeCount[1],
      StatusCodeCount[2],
      StatusCodeCount[3],
      StatusCodeCount[4],
      StatusCodeCount[5],
      StatusCodeCount[0],
      ByteString);
}      

/*****************************************************************************/
/*
*/

void CgiStats ()

{
#ifndef PRV$M_READALL
#define PRV$M_READALL 0x0008
#endif

   static unsigned long  PrvMask [2] =
      { (unsigned long)PRV$M_SYSPRV | (unsigned long)PRV$M_READALL, 0 };

   boolean  ShowProgressOnPage;
   int  status,
        DurationHr,
        DurationMin,
        DurationSec;
   char  *cptr,
         *ByteStringPtr;
   char  AccessProblemString [64],
         AuthUserString [64],
         ByteString [16],
         ClientString [64],
         DateTimeString [64],
         MethodString [64],
         PathString [64],
         QueryString [64],
         RefererString [64],
         RemoteIdentString [64],
         UserAgentString [64];
   unsigned long  StartSeconds,
                  TimeSeconds;

   /*********/
   /* begin */
   /*********/

   sprintf (SoftwareID, "%s (%s)", SOFTWAREID, CgiLibEnvironmentVersion());

   cptr = CgiLibVar ("WWW_REMOTE_USER");
   if (!cptr[0])
   {
      CgiLibResponseError (FI_LI, 0, "Authorization mandatory.");
      return;
   }

   CgiLibEnvironmentRecordOut ();
   CgiLibEnvironmentPtr = CgiLibEnvironmentName();

   CgiFormLogFileSpecPtr = CgiLibVarNull ("WWW_FORM_LOGFILESPEC");
   if (CgiFormLogFileSpecPtr == NULL)
   {
      CgiForm ();
      return;
   }

   /* get the filter components from the form */
   ClientFilterPtr = CgiLibVar ("WWW_FORM_CLIENT");
   if (!ClientFilterPtr[0])
      ClientFilterPtr = NULL;
   else
      /*
         Strictly speaking I shouldn't fool about with CGILIB variables
         without copying the contents but I'm just forcing it to lower
         case as FilterThisOut() will be expecting it this way!
      */
      for (cptr = ClientFilterPtr; *cptr; cptr++) *cptr = tolower(*cptr);
   RemoteIdentFilterPtr = CgiLibVar ("WWW_FORM_REMOTEID");
   if (!RemoteIdentFilterPtr[0])
      RemoteIdentFilterPtr = NULL;
   else
      for (cptr = RemoteIdentFilterPtr; *cptr; cptr++) *cptr = tolower(*cptr);
   AuthUserFilterPtr = CgiLibVar ("WWW_FORM_AUTHUSER");
   if (!AuthUserFilterPtr[0])
      AuthUserFilterPtr = NULL;
   else
      for (cptr = AuthUserFilterPtr; *cptr; cptr++) *cptr = tolower(*cptr);
   DateTimeFilterPtr = CgiLibVar ("WWW_FORM_DATETIME");
   if (!DateTimeFilterPtr[0])
      DateTimeFilterPtr = NULL;
   else
      for (cptr = DateTimeFilterPtr; *cptr; cptr++) *cptr = tolower(*cptr);
   MethodFilterPtr = CgiLibVar ("WWW_FORM_METHOD");
   if (!MethodFilterPtr[0])
      MethodFilterPtr = NULL;
   else
      for (cptr = MethodFilterPtr; *cptr; cptr++) *cptr = tolower(*cptr);
   PathFilterPtr = CgiLibVar ("WWW_FORM_PATH");
   if (!PathFilterPtr[0])
      PathFilterPtr = NULL;
   else
      for (cptr = PathFilterPtr; *cptr; cptr++) *cptr = tolower(*cptr);
   QueryFilterPtr = CgiLibVar ("WWW_FORM_QUERY");
   if (!QueryFilterPtr[0])
      QueryFilterPtr = NULL;
   else
      for (cptr = QueryFilterPtr; *cptr; cptr++) *cptr = tolower(*cptr);
   RefererFilterPtr = CgiLibVar ("WWW_FORM_REFERER");
   if (!RefererFilterPtr[0])
      RefererFilterPtr = NULL;
   else
      for (cptr = RefererFilterPtr; *cptr; cptr++) *cptr = tolower(*cptr);
   UserAgentFilterPtr = CgiLibVar ("WWW_FORM_USERAGENT");
   if (!UserAgentFilterPtr[0])
      UserAgentFilterPtr = NULL;
   else
      for (cptr = UserAgentFilterPtr; *cptr; cptr++) *cptr = tolower(*cptr);

   cptr = CgiLibVar ("WWW_FORM_VIEW");
   ShowProgressOnPage = false;
   if (strsame (cptr, "ALL", -1))
      ViewRecords = VIEW_ALL;
   else
   if (strsame (cptr, "MATCH", -1))
      ViewRecords = VIEW_MATCH;
   else
   if (strsame (cptr, "NOMATCH", -1))
      ViewRecords = VIEW_NOMATCH;
   else
   if (strsame (cptr, "PROGRESS", -1))
      ShowProgressOnPage = true;

   cptr = CgiLibVar ("WWW_FORM_ALL");
   if (cptr[0]) FilterOnAll = true;

   cptr = CgiLibVar ("WWW_FORM_LOOKUP");
   if (cptr[0]) LookupName = true;

   /* WASD stream mode will stop each fflush() having carriage control added */
   CgiLibEnvironmentBinaryOut ();
   CgiLibResponseHeader (200, "text/html", "Script-Control: X-stream-mode\n");

   time (&StartSeconds);
   fprintf (stdout,
"<HTML>\n\
<HEAD>\n\
<META NAME=\"generator\" CONTENT=\"%s\">\n\
<META NAME=\"environment\" CONTENT=\"%s\">\n\
<TITLE>%s</TITLE>\n\
</HEAD>\n\
<BODY>\n\
<FONT SIZE=+1><B><U>%s</U></B></FONT><BR>\n\
%s",
      SoftwareID, CgiLibEnvironmentPtr,
      SOFTWAREID, SOFTWAREID, ctime(&StartSeconds));

   if (ViewRecords)
      fputs ("<P><PRE>\n<HR SIZE=1 WIDTH=85% ALIGN=left NOSHADE>", stdout);
   else
   {
      /* the CGI interface always provides hidden progress indication */
      ShowProgress = PROGRESS_RECORDS;
      if (ShowProgressOnPage)
         fputs ("<P><PRE>", stdout);
      else
         fputs ("<!-- just an indicator of progress ...\n", stdout);
   }
   fflush (stdout);

   ProgressWrap = PROGRESS_WRAP_CGI;

   /* make a guess at the log file defaults */
   if (CgiLibEnvironmentIsWasd())
      SearchDna = DEFAULT_LOG_FILESPEC_WASD;
   else
   if (CgiLibEnvironmentIsOsu())
      SearchDna = DEFAULT_LOG_FILESPEC_OSU;
   else
   if (CgiLibEnvironmentIsApache())
      SearchDna = DEFAULT_LOG_FILESPEC_APACHE;
   else
      SearchDna = DEFAULT_LOG_FILESPEC;

   status = sys$setprv (1, &PrvMask, 0, 0);
   if (Debug) fprintf (stdout, "sys$setprv() %%X%08.08X\n", status);

   SearchFileSpec (CgiFormLogFileSpecPtr);

   status = sys$setprv (0, &PrvMask, 0, 0);
   if (Debug) fprintf (stdout, "sys$setprv() %%X%08.08X\n", status);

   if (ViewRecords)
      fputs ("<HR SIZE=1 WIDTH=85% ALIGN=left NOSHADE></PRE>\n", stdout);
   else
   if (ShowProgressOnPage)
      fputs ("</PRE>", stdout);
   else
      fputs (" -->", stdout);

   if (AccessProblemCount)
      sprintf (AccessProblemString, ", %d access failed", AccessProblemCount);
   else
      AccessProblemString[0] = '\0';

   time (&TimeSeconds);
   TimeSeconds -= StartSeconds;
   DurationHr = TimeSeconds / 3600;
   TimeSeconds -= DurationHr * 3600;
   DurationMin = TimeSeconds / 60;
   DurationSec = TimeSeconds - DurationMin * 60;

   if (ByteCountTotal > 1000000000.0)
   {
      ByteCountTotal /= 1000000000.0;
      ByteStringPtr = "GBytes";
      sprintf (ByteString, "%.3f", ByteCountTotal);
   }
   else
   if (ByteCountTotal > 1000000.0)
   {
      ByteCountTotal /= 1000000.0;
      ByteStringPtr = "MBytes";
      sprintf (ByteString, "%.3f", ByteCountTotal);
   }
   else
   if (ByteCountTotal > 1000.0)
   {
      ByteCountTotal /= 1000.0;
      ByteStringPtr = "KBytes";
      sprintf (ByteString, "%.3f", ByteCountTotal);
   }
   else
   {
      ByteStringPtr = "Bytes";
      sprintf (ByteString, "%.0f", ByteCountTotal);
   }

   if (ShowProgress && FileCountTotal) fputs ("\n", stdout);

   if (FilterOnAll)
   {
      if (ClientFilterPtr == NULL)
         strcpy (ClientString, "<I>&lt;none&gt;</I>");
      else
         sprintf (ClientString, "&nbsp; (%d nomatch, %d match)",
                  ClientFilterRejectCount, ClientFilterAcceptCount);
      if (AuthUserFilterPtr == NULL)
         strcpy (AuthUserString, "<I>&lt;none&gt;</I>");
      else
         sprintf (AuthUserString, "&nbsp; (%d nomatch, %d match)",
                  AuthUserFilterRejectCount, AuthUserFilterAcceptCount);
      if (DateTimeFilterPtr == NULL)
         strcpy (DateTimeString, "<I>&lt;none&gt;</I>");
      else
         sprintf (DateTimeString, "&nbsp; (%d nomatch, %d match)",
                  DateTimeFilterRejectCount, DateTimeFilterAcceptCount);
      if (MethodFilterPtr == NULL)
         strcpy (MethodString, "<I>&lt;none&gt;</I>");
      else
         sprintf (MethodString, "&nbsp; (%d nomatch, %d match)",
                  MethodFilterRejectCount, MethodFilterAcceptCount);
      if (PathFilterPtr == NULL)
         strcpy (PathString, "<I>&lt;none&gt;</I>");
      else
         sprintf (PathString, "&nbsp; (%d nomatch, %d match)",
                  PathFilterRejectCount, PathFilterAcceptCount);
      if (QueryFilterPtr == NULL)
         strcpy (QueryString, "<I>&lt;none&gt;</I>");
      else
         sprintf (QueryString, "&nbsp; (%d nomatch, %d match)",
                  QueryFilterRejectCount, QueryFilterAcceptCount);
      if (RefererFilterPtr == NULL)
         strcpy (RefererString, "<I>&lt;none&gt;</I>");
      else
         sprintf (RefererString, "&nbsp; (%d nomatch, %d match)",
                  RefererFilterRejectCount, RefererFilterAcceptCount);
      if (RemoteIdentFilterPtr == NULL)
         strcpy (RemoteIdentString, "<I>&lt;none&gt;</I>");
      else
         sprintf (RemoteIdentString, "&nbsp; (%d nomatch, %d match)",
                  RemoteIdentFilterRejectCount, RemoteIdentFilterAcceptCount);
      if (UserAgentFilterPtr == NULL)
         strcpy (UserAgentString, "<I>&lt;none&gt;</I>");
      else
         sprintf (UserAgentString, "&nbsp; (%d nomatch, %d match)",
                  UserAgentFilterRejectCount, UserAgentFilterAcceptCount);
   }
   else
   {
      if (ClientFilterPtr == NULL)
         strcpy (ClientString, "<I>&lt;none&gt;</I>");
      else
         sprintf (ClientString, "&nbsp; (%d nomatch)", ClientFilterRejectCount);
      if (AuthUserFilterPtr == NULL)
         strcpy (AuthUserString, "<I>&lt;none&gt;</I>");
      else
         sprintf (AuthUserString, "&nbsp; (%d nomatch)", AuthUserFilterRejectCount);
      if (DateTimeFilterPtr == NULL)
         strcpy (DateTimeString, "<I>&lt;none&gt;</I>");
      else
         sprintf (DateTimeString, "&nbsp; (%d nomatch)", DateTimeFilterRejectCount);
      if (MethodFilterPtr == NULL)
         strcpy (MethodString, "<I>&lt;none&gt;</I>");
      else
         sprintf (MethodString, "&nbsp; (%d nomatch)", MethodFilterRejectCount);
      if (PathFilterPtr == NULL)
         strcpy (PathString, "<I>&lt;none&gt;</I>");
      else
         sprintf (PathString, "&nbsp; (%d nomatch)", PathFilterRejectCount);
      if (QueryFilterPtr == NULL)
         strcpy (QueryString, "<I>&lt;none&gt;</I>");
      else
         sprintf (QueryString, "&nbsp; (%d nomatch)", QueryFilterRejectCount);
      if (RefererFilterPtr == NULL)
         strcpy (RefererString, "<I>&lt;none&gt;</I>");
      else
         sprintf (RefererString, "&nbsp; (%d nomatch)", RefererFilterRejectCount);
      if (RemoteIdentFilterPtr == NULL)
         strcpy (RemoteIdentString, "<I>&lt;none&gt;</I>");
      else
         sprintf (RemoteIdentString, "&nbsp; (%d nomatch)", RemoteIdentFilterRejectCount);
      if (UserAgentFilterPtr == NULL)
         strcpy (UserAgentString, "<I>&lt;none&gt;</I>");
      else
         sprintf (UserAgentString, "&nbsp; (%d nomatch)", UserAgentFilterRejectCount);
   }

   fprintf (stdout,
"<P><TABLE CELLPADDING=0 CELLSPACING=3 BORDER=0>\n\
<TR><TH ALIGN=right>Log:&nbsp;</TH><TD>%s%s(%d processed%s)</TD></TR>\n\
<TR><TH ALIGN=right>Client:&nbsp;</TH><TD>%s%s%s%s</TD></TR>\n\
<TR><TH ALIGN=right>Remote ID:&nbsp;</TH><TD>%s%s%s%s</TD></TR>\n\
<TR><TH ALIGN=right>Auth User:&nbsp;</TH><TD>%s%s%s%s</TD></TR>\n\
<TR><TH ALIGN=right>Date/Time:&nbsp;</TH><TD>%s%s%s%s</TD></TR>\n\
<TR><TH ALIGN=right>Method:&nbsp;</TH><TD>%s%s%s%s</TD></TR>\n\
<TR><TH ALIGN=right>Path:&nbsp;</TH><TD>%s%s%s%s</TD></TR>\n\
<TR><TH ALIGN=right>Query:&nbsp;</TH><TD>%s%s%s%s</TD></TR>\n\
<TR><TH ALIGN=right>Referer:&nbsp;</TH><TD>%s%s%s%s</TD></TR>\n\
<TR><TH ALIGN=right>User Agent:&nbsp;</TH><TD>%s%s%s%s</TD></TR>\n\
<TR><TH>&nbsp;</TH></TR>\n\
<TR><TH ALIGN=right>Duration:&nbsp;</TH><TD>%02d:%02d:%02d</TD></TR>\n\
<TR><TH ALIGN=right>Records:&nbsp;</TH>\
<TD><NOBR>%d&nbsp; (%d suspect, %d common, %d combined)</NOBR></TD></TR>\n\
<TR><TH ALIGN=right>Requests:&nbsp;</TH><TD>%d</TD></TR>\n\
<TR><TH ALIGN=right>Responses:&nbsp;</TH>\
<TD><NOBR>1nn:%d&nbsp; 2nn:%d&nbsp; 3nn:%d&nbsp; 4nn:%d&nbsp; 5nn:%d&nbsp; \
?:%d&nbsp;</NOBR></TD></TR>\n\
<TR><TH ALIGN=right>%s:&nbsp;</TH><TD>%s</TD></TR>\n\
</TABLE>\n\
</BODY>\n\
</HTML>\n",
      CgiFormLogFileSpecPtr,
      CgiFormLogFileSpecPtr[0] ? "&nbsp;&nbsp;" : "", FileCountTotal,
      AccessProblemString,
      ClientFilterPtr == NULL ? "" : "&quot;" ,
      ClientFilterPtr == NULL ? "" :
         (char*)CgiLibHtmlEscape (ClientFilterPtr, -1, NULL, 0),
      ClientFilterPtr == NULL ? "" : "&quot;" ,
      ClientString,
      RemoteIdentFilterPtr == NULL ? "" : "&quot;" ,
      RemoteIdentFilterPtr == NULL ? "" :
         (char*)CgiLibHtmlEscape (RemoteIdentFilterPtr, -1, NULL, 0),
      RemoteIdentFilterPtr == NULL ? "" : "&quot;" ,
      RemoteIdentString,
      AuthUserFilterPtr == NULL ? "" : "&quot;" ,
      AuthUserFilterPtr == NULL ? "" :
         (char*)CgiLibHtmlEscape (AuthUserFilterPtr, -1, NULL, 0),
      AuthUserFilterPtr == NULL ? "" : "&quot;" ,
      AuthUserString,
      DateTimeFilterPtr == NULL ? "" : "&quot;" ,
      DateTimeFilterPtr == NULL ? "" :
         (char*)CgiLibHtmlEscape (DateTimeFilterPtr, -1, NULL, 0),
      DateTimeFilterPtr == NULL ? "" : "&quot;" ,
      DateTimeString,
      MethodFilterPtr == NULL ? "" : "&quot;" ,
      MethodFilterPtr == NULL ? "" :
         (char*)CgiLibHtmlEscape (MethodFilterPtr, -1, NULL, 0),
      MethodFilterPtr == NULL ? "" : "&quot;" ,
      MethodString,
      PathFilterPtr == NULL ? "" : "&quot;" ,
      PathFilterPtr == NULL ? "" :
         (char*)CgiLibHtmlEscape (PathFilterPtr, -1, NULL, 0),
      PathFilterPtr == NULL ? "" : "&quot;" ,
      PathString,
      QueryFilterPtr == NULL ? "" : "&quot;" ,
      QueryFilterPtr == NULL ? "" :
         (char*)CgiLibHtmlEscape (QueryFilterPtr, -1, NULL, 0),
      QueryFilterPtr == NULL ? "" : "&quot;" ,
      QueryString,
      RefererFilterPtr == NULL ? "" : "&quot;" ,
      RefererFilterPtr == NULL ? "" :
         (char*)CgiLibHtmlEscape (RefererFilterPtr, -1, NULL, 0),
      RefererFilterPtr == NULL ? "" : "&quot;" ,
      RefererString,
      UserAgentFilterPtr == NULL ? "" : "&quot;" ,
      UserAgentFilterPtr == NULL ? "" :
         (char*)CgiLibHtmlEscape (UserAgentFilterPtr, -1, NULL, 0),
      UserAgentFilterPtr == NULL ? "" : "&quot;" ,
      UserAgentString,
      DurationHr, DurationMin, DurationSec,
      RecordCountTotal, SuspectRecordCountTotal,
      CommonLogRecordCount, CombinedLogRecordCount,
      RequestCountTotal,
      StatusCodeCount[1],
      StatusCodeCount[2],
      StatusCodeCount[3],
      StatusCodeCount[4],
      StatusCodeCount[5],
      StatusCodeCount[0],
      ByteStringPtr, ByteString);
}

/****************************************************************************/
/*
*/ 

void CgiForm ()

{
   unsigned long  TimeSeconds;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "CgiForm()\n");

   /* make a guess at the log file defaults */
   if (CgiLibEnvironmentIsWasd())
      SearchDna = DEFAULT_LOG_FILESPEC_WASD;
   else
   if (CgiLibEnvironmentIsOsu())
      SearchDna = DEFAULT_LOG_FILESPEC_OSU;
   else
   if (CgiLibEnvironmentIsApache())
      SearchDna = DEFAULT_LOG_FILESPEC_APACHE;
   else
      SearchDna = DEFAULT_LOG_FILESPEC;

   CgiLibEnvironmentPtr = CgiLibEnvironmentName();

   CgiScriptNamePtr = CgiLibVar ("WWW_SCRIPT_NAME");

   CgiLibResponseHeader (200, "text/html");

   time (&TimeSeconds);
   fprintf (stdout,
"<HTML>\n\
<HEAD>\n\
<META NAME=\"generator\" CONTENT=\"%s\">\n\
<META NAME=\"environment\" CONTENT=\"%s\">\n\
<TITLE>%s</TITLE>\n\
</HEAD>\n\
<BODY>\n\
<FONT SIZE=+1><B><U>%s</U></B></FONT><BR>\n\
%s\
<FORM METHOD=GET ACTION=\"%s\">\n\
<P><TABLE CELLPADDING=0 CELLSPACING=3 BORDER=0>\n\
<TR><TH ALIGN=right>Log Spec:&nbsp;</TH>\n\
<TD><INPUT TYPE=text NAME=logfilespec SIZE=30 VALUE=\"%s\"></TD></TR>\n\
<TR><TH ALIGN=right>Client:&nbsp;</TH>\n\
<TD><INPUT TYPE=text NAME=client SIZE=30>\n\
&nbsp;<INPUT TYPE=checkbox NAME=lookup VALUE=1>\
&nbsp;<FONT SIZE=-1><I>lookup name</I></FONT>\n\
</TD></TR>\n\
<TR><TH ALIGN=right>Remote ID:&nbsp;</TH>\n\
<TD><INPUT TYPE=text NAME=remoteid SIZE=30></TD></TR>\n\
<TR><TH ALIGN=right>Auth User:&nbsp;</TH>\n\
<TD><INPUT TYPE=text NAME=authuser SIZE=30></TD></TR>\n\
<TR><TH ALIGN=right>Date/Time:&nbsp;</TH>\n\
<TD><INPUT TYPE=text NAME=datetime SIZE=30></TD></TR>\n\
<TR><TH ALIGN=right>Method:&nbsp;</TH>\n\
<TD><INPUT TYPE=text NAME=method SIZE=30></TD></TR>\n\
<TR><TH ALIGN=right>Path:&nbsp;</TH>\n\
<TD><INPUT TYPE=text NAME=path SIZE=30></TD></TR>\n\
<TR><TH ALIGN=right>Query:&nbsp;</TH>\n\
<TD><INPUT TYPE=text NAME=query SIZE=30></TD></TR>\n\
<TR><TH ALIGN=right>Referer:&nbsp;</TH>\n\
<TD><INPUT TYPE=text NAME=referer SIZE=30></TD></TR>\n\
<TR><TH ALIGN=right>User Agent:&nbsp;</TH>\n\
<TD><INPUT TYPE=text NAME=useragent SIZE=30></TD></TR>\n\
<TR><TH ALIGN=right>View Records:&nbsp;</TH><TD>\n\
<SELECT NAME=view>\n\
<OPTION VALUE=none SELECTED>none\n\
<OPTION VALUE=progress>progress\n\
<OPTION VALUE=match>matching\n\
<OPTION VALUE=nomatch>non-matching\n\
<OPTION VALUE=all>all\n\
</SELECT>\n\
&nbsp;<INPUT TYPE=checkbox NAME=all VALUE=1>\
<FONT SIZE=-1>&nbsp;<I>match all</I></FONT>\n\
</TD></TR>\n\
<TR><TH HEIGHT=3></TH></TR>\n\
<TR><TH></TH><TD>\n\
<INPUT TYPE=submit VALUE=\"Submit\">&nbsp;&nbsp;\
<INPUT TYPE=reset VALUE=\"reset\">\n\
</TD></TR>\n\
</TABLE>\n\
</FORM>\n\
</BODY>\n\
</HTML>\n",
      SoftwareID, CgiLibEnvironmentPtr,
      SOFTWAREID, SOFTWAREID, ctime(&TimeSeconds),
      CgiScriptNamePtr, SearchDna);
}

/****************************************************************************/
/*
Search against the command line file specification, passing each file found to
be processed.
*/ 

SearchFileSpec (char *FileSpec)

{
   int  status,
        FileNameLength,
        Length;
   char  FileName [256],
         ExpFileName [256];
   struct FAB  SearchFab;
   struct NAM  SearchNam;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "SearchFileSpec() |%s|\n", FileSpec);

   /* initialize the file access block */
   SearchFab = cc$rms_fab;
   SearchFab.fab$l_dna = SearchDna;
   SearchFab.fab$b_dns = strlen(SearchDna);
   SearchFab.fab$l_fna = FileSpec;
   SearchFab.fab$b_fns = strlen(FileSpec);
   SearchFab.fab$l_nam = &SearchNam;

   SearchNam = cc$rms_nam;
   SearchNam.nam$l_esa = ExpFileName;
   SearchNam.nam$b_ess = sizeof(ExpFileName)-1;
   SearchNam.nam$l_rsa = FileName;
   SearchNam.nam$b_rss = sizeof(FileName)-1;

   if (VMSnok (status = sys$parse (&SearchFab, 0, 0)))
      exit (status);

   while (VMSok (status = sys$search (&SearchFab, 0, 0)))
   {
      *SearchNam.nam$l_ver = '\0';
      if (Debug) fprintf (stdout, "FileName |%s|\n", FileName);

      ProcessLogFile (FileName);

      FileCountTotal++;
      *SearchNam.nam$l_ver = ';';
   }

   if (VMSnok (status) && status != RMS$_NMF) exit (status);
}

/****************************************************************************/
/*
Open the log file, read and process each record from it, close the file!
*/ 

int ProcessLogFile (char *FileName)

{
   boolean  accepted;
   int  status;
   char  HtmlLine [MAX_LINE_LENGTH+(MAX_LINE_LENGTH/4)],
         Line [MAX_LINE_LENGTH],
         LineBuffer [MAX_LINE_LENGTH];
   FILE  *FilePtr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProcessLogFile() |%s|\n", FileName);

   if (ShowProgress && !ViewRecords)
   {
      /* this works for both CLI and CGI (inside "<!-- -->"!) */
      if (ProgressCount == ProgressWrap)
      {
         ProgressCount = 0;
         fputc ('\n', stdout);
      }
      ProgressCount++;
      fputc ('+', stdout);
      fflush (stdout);
   }

   RecordCount = 0;

   FilePtr = fopen (FileName, "r", "shr=get", "shr=put");
   if (FilePtr == NULL)
   {
      status = vaxc$errno;
      if (Debug) fprintf (stdout, "fopen() %%X%08.08X\n", status);
      AccessProblemCount++;
      return (status);
   }

   while (fgets (Line, sizeof(Line), FilePtr) != NULL)
   {
      RecordCount++;
      RecordCountTotal++;

      if (ViewRecords == VIEW_NONE)
      {
         /* again this works for both CLI and CGI (inside "<!-- -->"!) */
         if (ShowProgress && !(RecordCount % ShowProgress))
         {
            if (ProgressCount == ProgressWrap)
            {
               ProgressCount = 0;
               fputc ('\n', stdout);
            }
            ProgressCount++;
            fputc ('.', stdout);
            fflush (stdout);
         }
      }
      else
      if (ViewRecords == VIEW_ALL)
      {
         if (DoCliStats)
            OutputLogRecord (Line);
         else
         {
            CgiLibHtmlEscape (Line, -1, HtmlLine, sizeof(HtmlLine));
            OutputLogRecord (HtmlLine);
         }
      }
      else
         strcpy (LineBuffer, Line);

      if (Debug) fprintf (stdout, "|%s|\n", Line);
      accepted = ProcessLogRecord (Line);

      if (ViewRecords == VIEW_MATCH && accepted)
      {
         if (DoCliStats)
            OutputLogRecord (LineBuffer);
         else
         {
            CgiLibHtmlEscape (LineBuffer, -1, HtmlLine, sizeof(HtmlLine));
            OutputLogRecord (HtmlLine);
            fflush (stdout);
         }
      }
      else
      if (ViewRecords == VIEW_NOMATCH && !accepted)
      {
         if (DoCliStats)
            OutputLogRecord (LineBuffer);
         else
         {
            CgiLibHtmlEscape (LineBuffer, -1, HtmlLine, sizeof(HtmlLine));
            OutputLogRecord (HtmlLine);
            fflush (stdout);
         }
      }
   }

   fclose (FilePtr);

   return (SS$_NORMAL);
}

/*****************************************************************************/
/*
Output a single record from the log.  If client host name lookup is enabled
then check whether the client field is a dotted-decimal host address.  If it is
then lookup the host name and output that instead of the address.
*/

void OutputLogRecord (char *StringPtr)

{
   char  *cptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "OutputLogRecord()\n");

   if (!LookupName)
   {
      fputs (StringPtr, stdout);
      return;
   }

   for (cptr = StringPtr; *cptr && (isdigit(*cptr) || *cptr == '.'); cptr++);
   if (!isspace(*cptr))
   {
      fputs (StringPtr, stdout);
      return;
   }

   if (LookupNamePtr != NULL)
   {
      fputs (LookupNamePtr, stdout);
      fputs (cptr, stdout);
      return;
   }

   cptr = LookupHostName (&StringPtr);
   if (cptr == NULL)
   {
      fputs (StringPtr, stdout);
      return;
   }

   fputs (cptr, stdout);
   fputs (StringPtr, stdout);
}

/*****************************************************************************/
/*
Process a single record (line) from the log file.
Common: 'client rfc891 authuser date/time request status bytes'
Combined: 'client rfc891 authuser date/time request status bytes referer agent'
*/

boolean ProcessLogRecord (char *Line)

{
   boolean  RejectRecord;
   char  *cptr, *sptr,
         *AuthUserPtr,
         *ClientPtr,
         *BytesPtr,
         *DateTimePtr,
         *RefererPtr,
         *RemoteIdentPtr,
         *RequestPtr,
         *StatusPtr,
         *UserAgentPtr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "ProcessLogRecord()\n");

   LookupNamePtr = NULL;

   cptr = Line;

   /* client */
   ClientPtr = cptr;
   while (*cptr && !isspace(*cptr)) cptr++;
   if (*cptr) *cptr++ = '\0';

   /* remote ident (RFC891) */
   while (*cptr && isspace(*cptr)) cptr++;
   RemoteIdentPtr = cptr;
   while (*cptr && !isspace(*cptr)) cptr++;
   if (*cptr) *cptr++ = '\0';

   /* authorized user */
   while (*cptr && isspace(*cptr)) cptr++;
   AuthUserPtr = cptr;
   while (*cptr && !isspace(*cptr)) cptr++;
   if (*cptr) *cptr++ = '\0';

   /* date/time */
   while (*cptr && *cptr != '[') cptr++;
   if (*cptr) cptr++;
   DateTimePtr = cptr;
   while (*cptr && *cptr != ']') cptr++;
   if (*cptr) *cptr++ = '\0';

   /* request ("method path?query") */
   while (*cptr && *cptr != '\"') cptr++;
   if (*cptr) cptr++;
   RequestPtr = cptr;
   while (*cptr && *cptr != '\"') cptr++;
   if (*cptr) *cptr++ = '\0';

   /* HTTP response status */
   while (*cptr && isspace(*cptr)) cptr++;
   StatusPtr = cptr;
   while (*cptr && !isspace(*cptr)) cptr++;
   if (*cptr) *cptr++ = '\0';

   /* bytes transmitted */
   while (*cptr && isspace(*cptr)) cptr++;
   BytesPtr = cptr;
   while (*cptr && !isspace(*cptr)) cptr++;
   if (*cptr) *cptr++ = '\0';

   /* referer (only for COMBINED) */
   RefererPtr = NULL;
   while (*cptr && isspace(*cptr)) cptr++;
   if (*cptr == '\"')
   {
      cptr++;
      RefererPtr = cptr;
      while (*cptr && *cptr != '\"') cptr++;
   }
   else
   if (*cptr)
   {
      RefererPtr = cptr;
      while (*cptr && !isspace(*cptr)) cptr++;
   }
   if (*cptr) *cptr++ = '\0';

   /* user agent (only for COMBINED) */
   UserAgentPtr = NULL;
   while (*cptr && isspace(*cptr)) cptr++;
   if (*cptr == '\"')
   {
      cptr++;
      UserAgentPtr = cptr;
      while (*cptr && *cptr != '\"') cptr++;
   }
   else
   if (*cptr)
   {
      UserAgentPtr = cptr;
      while (*cptr && !isspace(*cptr)) cptr++;
   }
   if (*cptr) *cptr++ = '\0';

   if (!ClientPtr[0] ||
       !DateTimePtr[0] ||
       !RequestPtr[0] ||
       !StatusPtr[0] ||
       !BytesPtr)
   {
      SuspectRecordCountTotal++;
      return (false);
   }

   if (RefererPtr == NULL && UserAgentPtr == NULL)
      CommonLogRecordCount++;
   else
      CombinedLogRecordCount++;

   RejectRecord = false;

   if (ClientFilterPtr != NULL)
   {
      if (LookupName)
      {
         cptr = LookupHostName (&ClientPtr);
         if (cptr != NULL) ClientPtr = cptr;
      }
      if (FilterThisOut (ClientPtr, ClientFilterPtr))
      {
         ClientFilterRejectCount++;
         if (!FilterOnAll) return (false);
         RejectRecord = true;
      }
      else
         ClientFilterAcceptCount++;
   }
   if (RemoteIdentFilterPtr != NULL)
   {
      if (FilterThisOut (RemoteIdentPtr, RemoteIdentFilterPtr))
      {
         RemoteIdentFilterRejectCount++;
         if (!FilterOnAll) return (false);
         RejectRecord = true;
      }
      else
         RemoteIdentFilterAcceptCount++;
   }
   if (AuthUserFilterPtr != NULL)
   {
      if (FilterThisOut (AuthUserPtr, AuthUserFilterPtr))
      {
         AuthUserFilterRejectCount++;
         if (!FilterOnAll) return (false);
         RejectRecord = true;
      }
      else
         AuthUserFilterAcceptCount++;
   }
   if (DateTimeFilterPtr != NULL)
   {
      if (FilterThisOut (DateTimePtr, DateTimeFilterPtr))
      {
         DateTimeFilterRejectCount++;
         if (!FilterOnAll) return (false);
         RejectRecord = true;
      }
      else
         DateTimeFilterAcceptCount++;
   }
   if (MethodFilterPtr != NULL)
   {
      for (cptr = RequestPtr; *cptr && *cptr != ' '; cptr++);
      /* terminate path at query string (should be necessary) */
      if (!*cptr) cptr == NULL;
      if (cptr != NULL) *cptr = '\0';
      if (FilterThisOut (RequestPtr, MethodFilterPtr))
      {
         MethodFilterRejectCount++;
         if (!FilterOnAll) return (false);
         RejectRecord = true;
      }
      else
         MethodFilterAcceptCount++;
      if (cptr != NULL) *cptr = ' ';
   }
   if (PathFilterPtr != NULL)
   {
      /* skip over the method */
      for (cptr = RequestPtr; *cptr && *cptr != ' '; cptr++);
      while (*cptr && *cptr == ' ') cptr++;
      /* find the start of any query string */
      for (sptr = cptr; *sptr && *sptr != '?'; sptr++);
      /* terminate path at query string if necessary */
      if (!*sptr) sptr == NULL;
      if (sptr != NULL) *sptr = '\0';
      if (FilterThisOut (cptr, PathFilterPtr))
      {
         PathFilterRejectCount++;
         if (!FilterOnAll) return (false);
         RejectRecord = true;
      }
      else
         PathFilterAcceptCount++;
      /* return request to pristine condition :^) */
      if (sptr != NULL) *sptr = '?';
   }
   if (QueryFilterPtr != NULL)
   {
      /* find the start of any query string */
      for (cptr = RequestPtr; *cptr && *cptr != '?'; cptr++);
      if (*cptr) cptr++;
      if (FilterThisOut (cptr, QueryFilterPtr))
      {
         QueryFilterRejectCount++;
         if (!FilterOnAll) return (false);
         RejectRecord = true;
      }
      else
         QueryFilterAcceptCount++;
   }
   if (RefererFilterPtr != NULL)
   {
      /* if the record did not have a COMBINED referer field then reject */
      if (RefererPtr == NULL ||
          FilterThisOut (RefererPtr, RefererFilterPtr))
      {
         RefererFilterRejectCount++;
         if (!FilterOnAll) return (false);
         RejectRecord = true;
      }
      else
         RefererFilterAcceptCount++;
   }
   if (UserAgentFilterPtr != NULL)
   {
      /* if the record did not have a COMBINED user agent field then reject */
      if (UserAgentPtr == NULL ||
          FilterThisOut (UserAgentPtr, UserAgentFilterPtr))
      {
         UserAgentFilterRejectCount++;
         if (!FilterOnAll) return (false);
         RejectRecord = true;
      }
      else
         UserAgentFilterAcceptCount++;
   }

   if (RejectRecord) return (false);

   RequestCountTotal++;
   ByteCountTotal += (float)atoi(BytesPtr);
   switch (StatusPtr[0])
   {
      case '1' : StatusCodeCount[1]++; break;
      case '2' : StatusCodeCount[2]++; break;
      case '3' : StatusCodeCount[3]++; break;
      case '4' : StatusCodeCount[4]++; break;
      case '5' : StatusCodeCount[5]++; break;
      default  : StatusCodeCount[0]++;
   }

   return (true);
}

/*****************************************************************************/
/*
Using decc$match_wild() match the pattern against the string.  Parses out the
"+{}" and "-{}" kludges from composite expressions and does the appropriate
boolean processing to return a result.  Expects the pattern already to be all
lower-case, as this is a case-less matching.
*/

boolean FilterThisOut
(
char *StringPtr,
char *PatternPtr
)
{
   boolean  Matched,
            NegateMatch;
   char  *cptr, *sptr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "FilterThisOut()\n");

   for (cptr = StringPtr; *cptr; cptr++) *cptr = tolower(*cptr);
   cptr = PatternPtr;
   while (cptr != NULL && *cptr)
   {
      if (*(unsigned short*)cptr == '+{')
      {
         NegateMatch = false;
         cptr += 2;
      }
      else
      if (*(unsigned short*)cptr == '-{')
      {
         NegateMatch = true;
         cptr += 2;
      }
      else
         return (!decc$match_wild (StringPtr, PatternPtr));

      sptr = cptr;
      while (*cptr && *cptr != '}') cptr++;
      if (!*cptr) cptr = NULL;
      if (cptr != NULL) *cptr = '\0';
      Matched = decc$match_wild (StringPtr, sptr);
      if (cptr != NULL) *cptr++ = '}';
      if (NegateMatch) Matched = !Matched;
      if (!Matched) return (true);
   }

   return (false);
}

/*****************************************************************************/
/*
*/

char* LookupHostName (char **StringPtrPtr)

{
   static int  NameCacheCount,
               CurrentIndex;
   static struct
   {
      int  HitCount,
           IpAddress;
      char  *NamePtr;
   } NameCache [MAX_LOOKUP_CACHE];

   int  idx,
        IpAddress;
   char  ch;
   char  *cptr;
   struct hostent  *HostEntryPtr;

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "LookupHostName() |%s|\n", *StringPtrPtr);

   if (!LookupName) return (NULL);

   for (cptr = *StringPtrPtr;
        *cptr && (isdigit(*cptr) || *cptr == '.');
        cptr++);
   if (*cptr && !isspace(*cptr)) return (NULL);

   ch = *cptr;
   *cptr = '\0';
   if (Debug) fprintf (stdout, "|%s|\n", *StringPtrPtr);
   IpAddress = inet_addr (*StringPtrPtr);
   *cptr = ch;
   if (Debug) fprintf (stdout, "%08.08X\n", IpAddress);
   if (IpAddress == -1) return (NULL);

   if (IpAddress == NameCache[CurrentIndex].IpAddress)
   {
      NameCache[CurrentIndex].HitCount++;
      *StringPtrPtr = cptr;
      return (NameCache[CurrentIndex].NamePtr);
   }

   for (CurrentIndex = 0; CurrentIndex < NameCacheCount; CurrentIndex++)
   {
      if (IpAddress != NameCache[CurrentIndex].IpAddress) continue;
      NameCache[CurrentIndex].HitCount++;
      *StringPtrPtr = cptr;
      return (NameCache[CurrentIndex].NamePtr);
   }

   HostEntryPtr = gethostbyaddr (&IpAddress, sizeof(IpAddress), AF_INET);
   if (HostEntryPtr == NULL) return (NULL);

   if (NameCacheCount < MAX_LOOKUP_CACHE-1)
      CurrentIndex = NameCacheCount++;
   else
   {
      /* find the first entry with the lowest hit rate */
      CurrentIndex = 0;
      for (idx = 0; idx < NameCacheCount; idx++)
      {
         if (NameCache[CurrentIndex].IpAddress && !NameCache[idx].HitCount)
            continue;
         if (NameCache[idx].HitCount >= NameCache[CurrentIndex].HitCount)
            continue; 
         CurrentIndex = idx;
      }
      NameCache[CurrentIndex].HitCount = 0;
      free (NameCache[CurrentIndex].NamePtr);
   }

   NameCache[CurrentIndex].IpAddress = IpAddress;
   NameCache[CurrentIndex].NamePtr = malloc(strlen(HostEntryPtr->h_name)+1);
   strcpy (NameCache[CurrentIndex].NamePtr, HostEntryPtr->h_name);

   *StringPtrPtr = cptr;
   return (NameCache[CurrentIndex].NamePtr);
}

/*****************************************************************************/
/*
Get "command-line" parameters, whether from the command-line or from a
configuration symbol or logical containing the equivalent.
*/

GetParameters ()

{
   static char  CommandLine [256];
   static unsigned long  Flags = 0;

   int  status;
   unsigned short  Length;
   char  ch;
   char  *aptr, *cptr, *clptr, *sptr;
   $DESCRIPTOR (CommandLineDsc, CommandLine);

   /*********/
   /* begin */
   /*********/

   if (Debug) fprintf (stdout, "GetParameters()\n");

   if ((clptr = getenv ("QDLOGSTATS$PARAM")) == NULL)
   {
      /* get the entire command line following the verb */
      if (VMSnok (status =
          lib$get_foreign (&CommandLineDsc, 0, &Length, &Flags)))
         exit (status);
      (clptr = CommandLine)[Length] = '\0';
   }

   aptr = NULL;
   ch = *clptr;
   for (;;)
   {
      if (aptr != NULL && *aptr == '/') *aptr = '\0';
      if (!ch) break;

      *clptr = ch;
      if (Debug) fprintf (stdout, "clptr |%s|\n", clptr);
      while (*clptr && isspace(*clptr)) *clptr++ = '\0';
      aptr = clptr;
      if (*clptr == '/') clptr++;
      while (*clptr && !isspace (*clptr) && *clptr != '/')
      {
         if (*clptr != '\"')
         {
            clptr++;
            continue;
         }
         cptr = clptr;
         clptr++;
         while (*clptr)
         {
            if (*clptr == '\"')
               if (*(clptr+1) == '\"')
                  clptr++;
               else
                  break;
            *cptr++ = *clptr++;
         }
         *cptr = '\0';
         if (*clptr) clptr++;
      }
      ch = *clptr;
      if (*clptr) *clptr = '\0';
      if (Debug) fprintf (stdout, "aptr |%s|\n", aptr);
      if (!*aptr) continue;

      if (strsame (aptr, "/ALL", -1))
      {
         FilterOnAll = true;
         continue;
      }
      if (strsame (aptr, "/AUTHUSER=", 4))
      {
         for (cptr = aptr; *cptr && *cptr != '='; cptr++);
         if (*cptr) cptr++;
         for (AuthUserFilterPtr = cptr; *cptr; cptr++) *cptr = tolower(*cptr);
         continue;
      }
      if (strsame (aptr, "/CLIENT=", 4))
      {
         for (cptr = aptr; *cptr && *cptr != '='; cptr++);
         if (*cptr) cptr++;
         for (ClientFilterPtr = cptr; *cptr; cptr++) *cptr = tolower(*cptr);
         continue;
      }
      if (strsame (aptr, "/DBUG", -1))
      {
         Debug = true;
         continue;
      }
      if (strsame (aptr, "/DATETIME=", 4))
      {
         for (cptr = aptr; *cptr && *cptr != '='; cptr++);
         if (*cptr) cptr++;
         for (DateTimeFilterPtr = cptr; *cptr; cptr++) *cptr = tolower(*cptr);
         continue;
      }
      if (strsame (aptr, "/LOOKUP", -1))
      {
         LookupName = true;
         continue;
      }
      if (strsame (aptr, "/METHOD=", 4))
      {
         for (cptr = aptr; *cptr && *cptr != '='; cptr++);
         if (*cptr) cptr++;
         for (MethodFilterPtr = cptr; *cptr; cptr++) *cptr = tolower(*cptr);
         continue;
      }
      if (strsame (aptr, "/OUTPUT=", 4))
      {
         for (cptr = aptr; *cptr && *cptr != '='; cptr++);
         if (*cptr) cptr++;
         OutputPtr = cptr;
         continue;
      }
      if (strsame (aptr, "/PATH=", 4))
      {
         for (cptr = aptr; *cptr && *cptr != '='; cptr++);
         if (*cptr) cptr++;
         for (PathFilterPtr = cptr; *cptr; cptr++) *cptr = tolower(*cptr);
         continue;
      }
      if (strsame (aptr, "/PROGRESS=", 4))
      {
         for (cptr = aptr; *cptr && *cptr != '='; cptr++);
         if (*cptr) cptr++;
         ShowProgress = atoi(cptr);
         if (ShowProgress <= 0) ShowProgress = PROGRESS_RECORDS;
         continue;
      }
      if (strsame (aptr, "/QUERY=", 4))
      {
         for (cptr = aptr; *cptr && *cptr != '='; cptr++);
         if (*cptr) cptr++;
         for (QueryFilterPtr = cptr; *cptr; cptr++) *cptr = tolower(*cptr);
         continue;
      }
      if (strsame (aptr, "/REFERER=", 4))
      {
         for (cptr = aptr; *cptr && *cptr != '='; cptr++);
         if (*cptr) cptr++;
         for (RefererFilterPtr = cptr; *cptr; cptr++) *cptr = tolower(*cptr);
         continue;
      }
      if (strsame (aptr, "/REMOTEID=", 4))
      {
         for (cptr = aptr; *cptr && *cptr != '='; cptr++);
         if (*cptr) cptr++;
         for (RemoteIdentFilterPtr = cptr; *cptr; cptr++) *cptr = tolower(*cptr);
         continue;
      }
      if (strsame (aptr, "/USERAGENT=", 4))
      {
         for (cptr = aptr; *cptr && *cptr != '='; cptr++);
         if (*cptr) cptr++;
         for (UserAgentFilterPtr = cptr; *cptr; cptr++) *cptr = tolower(*cptr);
         continue;
      }
      if (strsame (aptr, "/VIEW=", 4))
      {
         ViewRecords = VIEW_MATCH;
         for (cptr = aptr; *cptr && *cptr != '='; cptr++);
         if (!*cptr) continue;
         cptr++;
         if (strsame (cptr, "ALL", 3))
            ViewRecords = VIEW_ALL;
         else
         if (strsame (cptr, "MATCH", 3))
            ViewRecords = VIEW_MATCH;
         else
         if (strsame (cptr, "NOMATCH", 3))
            ViewRecords = VIEW_NOMATCH;
         else
         {
            fprintf (stdout, "%%%s-E-INVPARM, invalid parameter\n \\%s\\\n",
                     Utility, cptr);
            exit (STS$K_ERROR | STS$M_INHIB_MSG);
         }
         continue;
      }

      if (*aptr == '/')
      {
         fprintf (stdout, "%%%s-E-IVQUAL, unrecognized qualifier\n \\%s\\\n",
                  Utility, aptr+1);
         exit (STS$K_ERROR | STS$M_INHIB_MSG);
      }

      if (!LogFileSpec[0])
      {
         sptr = LogFileSpec;
         for (cptr = aptr; *cptr; *sptr++ = toupper(*cptr++));
         *sptr = '\0';
         continue;
      }

      fprintf (stdout, "%%%s-E-MAXPARM, too many parameters\n \\%s\\\n",
               Utility, aptr);
      exit (STS$K_ERROR | STS$M_INHIB_MSG);
   }
}

/****************************************************************************/
/*
Does a case-insensitive, character-by-character string compare and returns 
true if two strings are the same, or false if not.  If a maximum number of 
characters are specified only those will be compared, if the entire strings 
should be compared then specify the number of characters as 0.
*/ 

boolean strsame
(
char *sptr1,
char *sptr2,
int  count
)
{
   while (*sptr1 && *sptr2)
   {
      if (toupper (*sptr1++) != toupper (*sptr2++)) return (false);
      if (count)
         if (!--count) return (true);
   }
   if (*sptr1 || *sptr2)
      return (false);
   else
      return (true);
}

/*****************************************************************************/
/*
*/

int ShowHelp ()

{
   fprintf (stdout,
"Usage for Quick and Dirty LOG STATisticS (%s)\n\
\n\
$ QDLOGSTATS <log-file-spec> [<filters>] [<other qualifiers>]\n\
\n\
Utility to extract very elementary statistics from Web server common/combined\n\
format log files.  A number of filters allow subsets of the log contents to be\n\
selected using simple wildcard expressions.  Strings are NOT case-sensitive.\n\
Optionally, log file records can be viewed as processed, or a simple progress\n\
indicator can be displayed (\"+\" for each file, \".\" per 1000 records thereof).\n\
\n\
/ALL /AUTHUSER=filter /CLIENT=filter /DATETIME=filter /LOOKUP /METHOD=filter\n\
/OUTPUT=file /PATH=filter /PROGRESS[=integer] /QUERY=filter /REFERER=filter\n\
/USERAGENT=filter /VIEW[=MATCH(D)|ALL|NOMATCH]\n\
\n\
Usage examples:\n\
\n\
$ QDLOGSTATS == \"$dir:QDLOGSTATS\"\n\
$ QDLOGSTATS HT_LOGS:*.LOG /PROGRESS\n\
$ QDLOGSTATS HT_LOGS:*NOV*ACCESS* /PATH=\"/CGI-BIN/*\" /QUERY=\"-{-}\"\n\
$ QDLOGSTATS HT_LOGS:*ACCESS*.LOG /METHOD=POST /DATE=\"*/NOV/2000/*\"\n\
$ QDLOGSTATS HT_LOGS:* /REFERER=*COMPAQ.COM*\n\
$ QDLOGSTATS HT_LOGS:*.LOG /USERAGENT=*MOZILLA*X11*\n\
\n",
   SoftwareID);

   return (SS$_NORMAL);
}

/*****************************************************************************/

