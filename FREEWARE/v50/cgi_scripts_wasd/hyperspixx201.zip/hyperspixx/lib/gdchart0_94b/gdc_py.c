/*  Python interface to Bruce Verderaime's GDChart library.

    Mike Steed
    msteed@fiber.net

    August 11, 1999:	Version 0.1: first public release.
    February 3, 2000:	Version 0.2: minor bug fixes, support for Solaris.
    February 17, 2000:	Version 0.3: support for missing values in datasets.
    May 2, 2000:	Version 0.4: use gd-1.8.1 (png and jpeg), cStringIo,
			    transparent backgrounds in pie charts
    May 9, 2000:        Version 0.41: bug fix (percent_labels)
*/

/* TODO:
    support background images (patch from Chui Tey)
    accept None or empty tuple for labels
    handle empty file obj/name (useful w/ hold_img)
    support annotations
    support scatter
    deal with in/out params (GDC_hard_*)
    return a dict of current option values when option() is called w/o args?
*/

#include <stdio.h>
#include <string.h>
#include <assert.h>

#include "Python.h"
#include "cStringIO.h"

#include "gdc.h"
#include "gdchart.h"
#include "gdcpie.h"

// Use unique values for pie chart types, since we export a single function
// for creating all types of charts.
#define  MY_GDC_2DPIE   (100 + GDC_2DPIE)
#define  MY_GDC_3DPIE   (100 + GDC_3DPIE)

#define SetTypeError(f, a) \
    sprintf(Msgbuf, "%s: illegal argument type for %s", f, a); \
    PyErr_SetString(GDChartError, Msgbuf)

#define SetValueError(f, a) \
    sprintf(Msgbuf, "%s: illegal value for %s", f, a); \
    PyErr_SetString(GDChartError, Msgbuf)

static char ModuleDoc[] =
"This module provides an interface to the GDChart library by Bruce Verderaime\n\
(see http://www.fred.net/brv/chart/).\n\
\n\
Dynamic objects:\n\
\n\
error -- Module-level exception.\n\
\n\
Constants:\n\
\n\
image formats --\n\
   GDC_PNG                    GDC_JPEG\n\
\n\
chart styles --\n\
   GDC_AREA                   GDC_3DAREA\n\
   GDC_BAR                    GDC_3DBAR\n\
   GDC_LINE                   GDC_3DLINE\n\
   GDC_COMBO_LINE_AREA        GDC_3DCOMBO_LINE_AREA\n\
   GDC_COMBO_LINE_BAR         GDC_3DCOMBO_LINE_BAR\n\
   GDC_HILOCLOSE              GDC_3DHILOCLOSE\n\
   GDC_COMBO_HLC_AREA         GDC_3DCOMBO_HLC_AREA\n\
   GDC_COMBO_HLC_BAR          GDC_3DCOMBO_HLC_BAR\n\
   GDC_2DPIE                  GDC_3DPIE\n\
\n\
fonts --\n\
   GDC_TINY                   GDC_SMALL                  GDC_MEDBOLD\n\
   GDC_LARGE                  GDC_GIANT\n\
\n\
stack options --\n\
   GDC_STACK_BESIDE           GDC_STACK_DEPTH\n\
   GDC_STACK_LAYER            GDC_STACK_SUM\n\
\n\
hi-lo-close styles (may be combined) --\n\
   GDC_HLC_CLOSE_CONNECTED    GDC_HLC_CONNECTING\n\
   GDC_HLC_DIAMOND            GDC_HLC_I_CAP\n\
\n\
scatter point styles --\n\
   GDC_SCATTER_TRIANGLE_DOWN  GDC_SCATTER_TRIANGLE_UP\n\
\n\
percent placement options (pie charts) --\n\
   GDCPIE_PCT_NONE            GDCPIE_PCT_ABOVE           GDCPIE_PCT_BELOW\n\
   GDCPIE_PCT_RIGHT           GDCPIE_PCT_LEFT\n\
\n\
Functions:\n\
\n\
chart() -- create a chart\n\
option() -- set chart options\n\
";

static char ChartDoc[] =
"chart(s, (w, h), f, l, data...)\n\
\n\
s     -- chart style\n\
(w,h) -- dimensions of GIF image (width, height)\n\
f     -- file object or name of file where GIF should be written\n\
l     -- sequence of x-axis labels\n\
data  -- one or more sequences of data values, depending on the chart style:\n\
           simple:      chart(s, (w,h), f, l, d [,d...])\n\
           combo:       chart(s, (w,h), f, l, d [,d...], da)\n\
           hi-lo-close: chart(s, (w,h), f, l, (dh,dl,dc) [,(dh,dl,dc)...])\n\
           combo hlc:   chart(s, (w,h), f, l, (dh,dl,dc) [,(dh,dl,dc)...], dv)\n\
           pie:         chart(s, (w,h), f, l, d [, p])\n\
         missing values:\n\
            for pie charts, p is a sequence indicating which values in d are\n\
                'present' (0 or None => corresponding value in d is missing)\n\
            for other charts, None in a dataset indicates a missing value";

static char OptionDoc[] =
"option(keyword=value [,keyword=value...])\n\
\n\
keywords and type codes --\n\
   b: boolean                 c: color (0xRRGGBB)        e: enum (GDC_*)\n\
   n: number                  s: string                  *: not implemented\n\
   (x): sequence of type x\n\
\n\
   annotation=*               label_dist=n               xaxis=b\n\
   annotation_font=e          label_font=e               xaxis_font=e\n\
   bar_width=n                label_line=b               xlabel_color=c\n\
   bg_color=c                 line_color=c               xlabel_spacing=n\n\
   bg_image=*                 other_threshold=n          xtitle=s\n\
   bg_transparent=b           percent_labels=e           xtitle_color=c\n\
   border=b                   pie_color=(c)              xtitle_font=e\n\
   edge_color=c               plot_color=c               yaxis=b\n\
   explode=(i)                requested_ymax=n           yaxis2=b\n\
   ext_color=(c)              requested_ymin=n           yaxis_font=e\n\
   ext_vol_color=(c)          requested_yinterval=n      ylabel_color=c\n\
   format=e|(e,n)             scatter=*                  ylabel_density=n\n\
   generate_gif=b             set_color=(c)              ylabel_fmt=s\n\
   grid=b                     stack_type=e               ylabel2_color=c\n\
   grid_color=c               thumblabel=s               ylabel2_fmt=s\n\
   hard_graphheight=n         thumbnail=b                ytitle=s\n\
   hard_graphwidth=n          thumbval=n                 ytitle_color=c\n\
   hard_size=b                threed_angle=n             ytitle_font=e\n\
   hard_xorig=n               threed_depth=n             ytitle2=s\n\
   hard_yorig=n               title=s                    ytitle2_color=c\n\
   hlc_cap_width=n            title_color=c              zeroshelf=b\n\
   hlc_style=e                title_font=e               \n\
   hold_img=b                 vol_color=c                \n\
\n\
   'format' specifies the image format (default is GDC_PNG).  With GDC_JPEG,\n\
   you can optionally specify the image quality (0-95, or -1 for default).";

static PyObject *GDChartError;
static char Msgbuf[128];

// Cached values for array & string options
//static void *Missing = NULL;        // GDCPIE_missing
static void *Explode = NULL;        // GDCPIE_explode
static void *ExtColor = NULL;       // GDC_ExtColor
static void *ExtVolColor = NULL;    // GDC_ExtVolColor
static void *PieColor = NULL;       // GDCPIE_Color
static void *SetColor = NULL;       // GDC_SetColor
static void *BGImage = NULL;        // GDC_BGImage
static void *ThumbLabel = NULL;     // GDC_thumblabel
static void *Title = NULL;          // GDC_title
static void *XTitle = NULL;         // GDC_xtitle
static void *YLabelFmt = NULL;      // GDC_ylabel_fmt
static void *YLabel2Fmt = NULL;     // GDC_ylabel2_fmt
static void *YTitle = NULL;         // GDC_ytitle
static void *YTitle2 = NULL;        // GDC_ytitle

// Pointers to the above pointers, used to free any allocated memory at exit.
static void **ArrayData[] = {
    /*&Missing,*/   &Explode,	    &ExtColor,	    &ExtVolColor,   &PieColor,
    &SetColor,	    &BGImage,	    &ThumbLabel,    &Title,	    &XTitle,
    &YLabelFmt,	    &YLabel2Fmt,    &YTitle,	    &YTitle2,	    NULL
};

static void
_cleanup()
{
    int i = 0;
    void **mem;
    for (i = 0; (mem = ArrayData[i]) != NULL; i++) {
	if (*mem != NULL) {
	     Py_Free(*mem);
	     *mem = NULL;
	}
    }
}


// Retrieve chart style, gif dimensions, file, and labels from a Python
// argument list.  Also return the number of points expected in each data set,
// if known.
static int
_parse_common_args(
    PyObject   *args,
    char       *caller,
    int	       *chartStyle,
    int	       *gifWidth,
    int	       *gifHeight,
    FILE      **file,
    PyObject  **stringIO,
    char     ***labels,
    int	       *numPoints,
    int	       *closeFile)
{
    PyObject   *arg;
    PyObject   *width;
    PyObject   *height;
    PyObject   *label;
    char       *filename;
    int		i;

    // Parse common arguments.  Can't use PyArg_ParseTuple() because we need
    // to handle variable arg quantities & types.

    // Chart style: int.
    arg = PyTuple_GetItem(args, 0);
    if (!PyInt_Check(arg)) {
	sprintf(Msgbuf, "%s, argument 1: expected int", caller);
	PyErr_SetString(PyExc_TypeError, Msgbuf);
	return 0;
    }
    *chartStyle = (int) PyInt_AsLong(arg);

    // GIF dimensions: (int, int).
    arg = PyTuple_GetItem(args, 1);
    if (!PySequence_Check(arg) || PyObject_Length(arg) != 2) {
	sprintf(Msgbuf, "%s, argument 2: expected 2-tuple", caller);
	PyErr_SetString(PyExc_TypeError, Msgbuf);
	return 0;
    }
    width = PySequence_GetItem(arg, 0);
    height = PySequence_GetItem(arg, 1);
    Py_DECREF(width);
    Py_DECREF(height);
    if (!PyInt_Check(width) || !PyInt_Check(height)) {
	sprintf(Msgbuf, "%s, argument 3: expected (int,int)", caller);
	PyErr_SetString(PyExc_TypeError, Msgbuf);
	return 0;
    }
    *gifWidth = (int) PyInt_AsLong(width);
    *gifHeight = (int) PyInt_AsLong(height);
    if (*gifWidth < 0 || *gifHeight < 0) {
	SetValueError(caller, "GIF dimensions");
	return 0;
    }

    // File: file, cStringIO, or string (=filename) object.
    *stringIO = NULL;
    arg = PyTuple_GetItem(args, 2);
    if (PyFile_Check(arg)) {
	*file = PyFile_AsFile(arg);
	*closeFile = 0;
    }
    else if (PycStringIO != NULL && PycStringIO_OutputCheck(arg)) {
	*file = tmpfile();
	*closeFile = 1;
	*stringIO = arg;
    }
    else if (PyString_Check(arg)) {
	filename = PyString_AsString(arg);
	*file = fopen(filename, "wb");
	if (*file == NULL) {
	    sprintf(Msgbuf, "%s: can't open %s for writing", caller, filename);
	    PyErr_SetString(PyExc_TypeError, Msgbuf);
	    return 0;
	}
	*closeFile = 1;
    }
    else {
	if (PycStringIO == NULL) {
	    sprintf(Msgbuf, "%s, argument 3: expected file or string", caller);
	}
	else {
	    sprintf(Msgbuf, "%s, argument 3: expected file, string, or cStringIO", caller);
	}
	PyErr_SetString(PyExc_TypeError, Msgbuf);
	return 0;
    }

    // Labels: (string, ...).
    arg = PyTuple_GetItem(args, 3);
    if (!PySequence_Check(arg)) {
	sprintf(Msgbuf, "%s, argument 4: expected sequence", caller);
	PyErr_SetString(PyExc_TypeError, Msgbuf);
	return 0;
    }

    // The label count must equal the number of points in each data set, so
    // just store this value in numPoints.
    *numPoints = PyObject_Length(arg);
    *labels = (char **) Py_Malloc((*numPoints + 1) * sizeof(char **));
    if (*labels == NULL) {
	return 0;
    }
    memset(*labels, 0, (*numPoints + 1) * sizeof(char **));
    for (i = 0; i < *numPoints; i++) {
	label = PySequence_GetItem(arg, i);
	// It's safe to decrement the refcount immediately, since this object is
	// part of a sequence object, which also owns a reference to it.
	Py_DECREF(label);
	if (PyString_Check(label)) {
	    (*labels)[i] = PyString_AsString(label);
	}
	else {
	    // Found an invalid label.  Clean up and return failure.
	    Py_Free(*labels);
	    *labels = NULL;
	    sprintf(Msgbuf, "%s, argument 4: expected (string, ...)", caller);
	    PyErr_SetString(PyExc_TypeError, Msgbuf);
	    return 0;
	}
    }

    // Note: caller is responsible for freeing the labels array when this
    // function succeeds!
    return 1;
}


// Retrieve a data set from a Python object.
static float *
_parse_data_set(
    PyObject   *pyseq,
    char       *caller,
    int		numPoints)
{
    int		i;
    PyObject   *value; 
    float      *data;

    if (!PySequence_Check(pyseq) || PyObject_Length(pyseq) != numPoints) {
	sprintf(Msgbuf, "%s: mismatched data sets", caller);
	PyErr_SetString(PyExc_TypeError, Msgbuf);
	return NULL;
    }

    data = Py_Malloc(numPoints * sizeof(float));
    if (data != NULL) {
	for (i = 0; i < numPoints; i++) {
	    value = PySequence_GetItem(pyseq, i);
	    if (PyObject_Compare(value, Py_None) == 0) {
		data[i] = GDC_NOVALUE;
	    }
	    else {
		data[i] = (float) PyFloat_AsDouble(value);
	    }
	    Py_DECREF(value);
	}
	if (PyErr_Occurred()) {
	    Py_Free(data);
	    data = NULL;
	}
    }

    // Note: caller is responsible for freeing the data array when this
    // function succeeds!
    return data;
}


// Retrieve n data sets from a Python object.
static float **
_parse_data_sets(
    PyObject   *pyseq,
    char       *caller,
    int		numSets,
    int		numPoints)
{
    int	    i;
    float **data;  

    if (!PySequence_Check(pyseq) || PyObject_Length(pyseq) != numSets) {
	sprintf(Msgbuf, "%s: mismatched data sets", caller);
	PyErr_SetString(PyExc_TypeError, Msgbuf);
	return NULL;
    }

    data = Py_Malloc(numSets * sizeof(float *));
    if (data == NULL) {
	return NULL;
    }

    for (i = 0; i < numSets; i++) {
	PyObject *dataset = PySequence_GetItem(pyseq, i);
	Py_DECREF(dataset);
	data[i] = _parse_data_set(dataset, caller, numPoints);
    }

    if (PyErr_Occurred()) {
	for (i = 0; i < numSets; i++) {
	    if (data[i] != NULL) {
		Py_Free(data[i]);
	    }
	}
	Py_Free(data);
	data = NULL;
    }

    return data;
}


// Module function chart(style, (w, h), file, labels, data...)
static PyObject *
gdc_chart(PyObject *self, PyObject *args)
{
    int     argc;
    int     chartStyle;
    int	    gifWidth, gifHeight;
    FILE   *file;
    char  **labels;
    int     setSize;
    int     setCount, minDatasets = 1, maxDatasets = -1;
    int     hiloclose = 0, combo = 0;
    int     arrayCount = 1;
    float  **data;
    int     argidx, setidx, i;
    int     closeFile;
    PyObject *stringIO;

    argc = PyTuple_Size(args);
    if (argc < 5) {
	sprintf(Msgbuf, "chart requires at least 5 arguments; %d given", argc);
	PyErr_SetString(PyExc_TypeError, Msgbuf);
	return NULL;
    }

    if (!_parse_common_args(args, "chart", &chartStyle, &gifWidth, &gifHeight,
	&file, &stringIO, &labels, &setSize, &closeFile)) {
	return NULL;
    }

    // Set parameters based on chart type.
    setCount = argc - 4;
    if (chartStyle == GDC_LINE || chartStyle == GDC_3DLINE ||
	 chartStyle == GDC_AREA || chartStyle == GDC_3DAREA ||
	 chartStyle == GDC_BAR	|| chartStyle == GDC_3DBAR) {
	arrayCount = setCount;
    }
    else if (chartStyle == GDC_COMBO_LINE_AREA	||
		chartStyle == GDC_COMBO_LINE_BAR ||
		chartStyle == GDC_3DCOMBO_LINE_AREA ||
		chartStyle == GDC_3DCOMBO_LINE_BAR) {
	minDatasets = 2;
	combo = 1;
	arrayCount = setCount;
    }
    else if (chartStyle == GDC_HILOCLOSE || chartStyle == GDC_3DHILOCLOSE) {
	hiloclose = 1;
	arrayCount = 3 * setCount;
    }
    else if (chartStyle == GDC_COMBO_HLC_AREA ||
		chartStyle == GDC_COMBO_HLC_BAR ||
		chartStyle == GDC_3DCOMBO_HLC_AREA ||
		chartStyle == GDC_3DCOMBO_HLC_AREA) {
	minDatasets = 2;
	hiloclose = 1;
	combo = 1;
	arrayCount = 3 * (setCount - 1) + 1;
    }
    else if (chartStyle == MY_GDC_2DPIE || chartStyle == MY_GDC_3DPIE) {
	// For pie charts, the second data set (if any) is a sequence of
	// values indicating missing data points (0 == missing).
	maxDatasets = 2;
	arrayCount = setCount;
    }

    // Check number of data sets.
    if (setCount < minDatasets) {
	PyErr_SetString(PyExc_TypeError, "chart: more data expected");
	return NULL;
    }
    if (maxDatasets > 0 && setCount > maxDatasets) {
	PyErr_SetString(PyExc_TypeError, "chart: less data expected");
	return NULL;
    }

    // Allocate space for formatted data.
    data = Py_Malloc(arrayCount * sizeof(float *));
    if (data == NULL) {
	return NULL;
    }
    for (i = 0; i < arrayCount; i++) {
	data[i] = Py_Malloc(setSize * sizeof(float));
    }

    // Format data for calls to GDChart.
    if (!PyErr_Occurred()) {
	setidx = 0;
	for (argidx = 4; argidx < argc; argidx++) {
	    PyObject *dataset = PyTuple_GetItem(args, argidx);
	    if (hiloclose && (!combo || argidx < argc - 1)) {
		// Get a (hi, lo, close) data set.
		float **hlc = _parse_data_sets(dataset, "chart", 3, setSize);
		if (hlc != NULL) {
		    data[setidx++] = hlc[0];
		    data[setidx++] = hlc[1];
		    data[setidx++] = hlc[2];
		}
	    }
	    else {
		// Get a normal data set.
		data[setidx++] = _parse_data_set(dataset, "chart", setSize);
	    }
	}
    }

    // Call GDChart.
    if (!PyErr_Occurred()) {
	if (chartStyle == MY_GDC_2DPIE || chartStyle == MY_GDC_3DPIE) {
	    // Scale data so it sums to 100.
	    float scale, sum = 0.0;
	    for (i = 0; i < setSize; i++) {
		sum += data[0][i];
	    }
	    scale = 100.0 / sum;
	    for (i = 0; i < setSize; i++) {
		data[0][i] *= scale;
	    }

	    // If a second data set was provided, it indicates what values
	    // are missing (0 == missing).
	    if (setCount == 2) {
		GDCPIE_missing = Py_Malloc(setSize * sizeof(unsigned char));
		for (i = 0; i < setSize; i++) {
		    GDCPIE_missing[i] = (unsigned char)
			(data[1][i] == 0.0 || data[1][i] == GDC_NOVALUE) ?  TRUE : FALSE;
		}
	    }

	    chartStyle = (chartStyle == MY_GDC_2DPIE) ? GDC_2DPIE : GDC_3DPIE;
	    pie_gif(gifWidth, gifHeight, file, chartStyle, setSize, labels, data[0]);

	    if (setCount == 2) {
		Py_Free(GDCPIE_missing);
		GDCPIE_missing = NULL;
	    }
	}
	else {
	    out_graph_a(gifWidth, gifHeight, file, chartStyle, setSize, labels,
		setCount - combo, data);
	}
    }

    // Clean up.
    if (stringIO != NULL) {
	size_t n;
	void *buf = malloc(1024);
	fseek(file, 0, SEEK_SET);
	do {
	    n = fread(buf, 1, 1024, file);
	    PycStringIO->cwrite(stringIO, (char *)buf, n);
	} while (n == 1024);
    }

    if (closeFile) {
	fclose(file);
    }

    for (i = 0; i < arrayCount; i++) {
	if (data[i] != NULL) {
	    Py_Free(data[i]);
	}
    }
    Py_Free(data);
    Py_Free(labels);

    Py_INCREF(Py_None);
    return Py_None;
}


// Handle 'special' options.
static int
_handle_special_option(char *keyword, PyObject *value)
{
    // annotation
    if (strcmp(keyword, "annotation") == 0) {
	// TODO: this.
	PyErr_SetString(GDChartError, "option: annotation unimplemented");
	return 0;
    }

    // format
    else if (strcmp(keyword, "format") == 0) {
	if (PySequence_Check(value)) {
	    PyObject *formatObj, *qualityObj;
	    int format, quality;
	    int size = PyObject_Length(value);
	    if (size != 2) {
		SetValueError("option", keyword);
		return 0;
	    }

	    formatObj = PySequence_GetItem(value, 0);
	    format = (int) PyInt_AsLong(formatObj);
	    Py_DECREF(formatObj);
	    if (PyErr_Occurred()) {
		SetTypeError("option", keyword);
		return 0;
	    }
	    if (format != GDC_JPEG) {
		SetValueError("option", keyword);
		return 0;
	    }

	    qualityObj = PySequence_GetItem(value, 1);
	    quality = (int) PyInt_AsLong(qualityObj);
	    Py_DECREF(qualityObj);
	    if (PyErr_Occurred()) {
		SetTypeError("option", keyword);
		return 0;
	    }

	    GDC_output_type = format;
	    GDC_jpeg_quality = quality;

	    return 1;
	}
	else {
	    int format = (int) PyInt_AsLong(value);
	    if (PyErr_Occurred()) {
		SetTypeError("option", keyword);
		return 0;
	    }
	    if (format != GDC_PNG && format != GDC_JPEG) {
		SetValueError("option", keyword);
		return 0;
	    }

	    GDC_output_type = format;
	    if (format == GDC_JPEG) {
		GDC_jpeg_quality = -1; // default
	    }

	    return 1;
	}
    }

    // hlc_style
    else if (strcmp(keyword, "hlc_style") == 0) {
	int x = (int) PyInt_AsLong(value);
	if (PyErr_Occurred()) {
	    SetTypeError("option", keyword);
	    return 0;
	}

	if (x < 1 || x > 15 || (x & 6) == 6) {
	    SetValueError("option", keyword);
	    return 0;
	}

	GDC_HLC_style = x;
	return 1;
    }

    // hold_img
    else if (strcmp(keyword, "hold_img") == 0) {
	int x = (int) PyInt_AsLong(value);
	if (PyErr_Occurred()) {
	    SetTypeError("option", keyword);
	    return 0;
	}

	if (x < GDC_DESTROY_IMAGE || x > GDC_REUSE_IMAGE) {
	    SetValueError("option", keyword);
	    return 0;
	}

	GDC_hold_img = x;
	return 1;
    }

    // other_threshold
    else if (strcmp(keyword, "other_threshold") == 0) {
	char	x;

	if (value == Py_None) {
	    GDCPIE_other_threshold = -1;
	    return 1;
	}

	x = (char) PyInt_AsLong(value);
	if (PyErr_Occurred()) {
	    SetTypeError("option", keyword);
	    return 0;
	}

	if (x < 0 || x > 100) {
	    SetValueError("option", keyword);
	    return 0;
	}

	GDCPIE_other_threshold = x;
	return 1;
    }

    // percent_labels
    else if (strcmp(keyword, "percent_labels") == 0) {
	int x = (int) PyInt_AsLong(value);
	if (PyErr_Occurred()) {
	    SetTypeError("option", keyword);
	    return 0;
	}

	if (x < GDCPIE_PCT_NONE || x > GDCPIE_PCT_LEFT) {
	    SetValueError("option", keyword);
	    return 0;
	}

	GDCPIE_percent_labels = x;
	return 1;
    }

    // scatter
    else if (strcmp(keyword, "scatter") == 0) {
	// TODO: this.
	PyErr_SetString(GDChartError, "option: scatter unimplemented");
	return 0;
    }

    // stack_type
    else if (strcmp(keyword, "stack_type") == 0) {
	int x = (int) PyInt_AsLong(value);
	if (PyErr_Occurred()) {
	    SetTypeError("option", keyword);
	    return 0;
	}

	if (x < GDC_STACK_DEPTH || x > GDC_STACK_LAYER) {
	    SetValueError("option", keyword);
	    return 0;
	}

	GDC_stack_type = x;
	return 1;
    }

    // threed_angle
    else if (strcmp(keyword, "threed_angle") == 0) {
	unsigned short x = (unsigned short) PyInt_AsLong(value);
	if (PyErr_Occurred()) {
	    SetTypeError("option", keyword);
	    return 0;
	}

	if (x > 359) {
	    SetValueError("option", keyword);
	    return 0;
	}

	GDC_3d_angle = (unsigned char) x;
	GDCPIE_3d_angle = x;
	return 1;
    }

    // threed_depth
    else if (strcmp(keyword, "threed_depth") == 0) {
	float x = (float) PyFloat_AsDouble(value);
	if (PyErr_Occurred()) {
	    SetTypeError("option", keyword);
	    return 0;
	}

	if (x < 0.0 || x > 100.0) {
	    SetValueError("option", keyword);
	    return 0;
	}

	GDC_3d_depth = x;
	GDCPIE_3d_depth = (unsigned short) x;
	return 1;
    }

    // xlabel_spacing
    else if (strcmp(keyword, "xlabel_spacing") == 0) {
	short x;

	if (value == Py_None) {
	    GDC_xlabel_spacing = MAXSHORT;
	    return 1;
	}

	x = (short) PyInt_AsLong(value);
	if (PyErr_Occurred()) {
	    SetTypeError("option", keyword);
	    return 0;
	}

	if (x < 0) {
	    SetValueError("option", keyword);
	    return 0;
	}

	GDC_xlabel_spacing = x;
	return 1;
    }

    // Oops!
    else {
	PyErr_SetString(GDChartError, "something is horribly wrong in gdchart");
	return 0;
    }
}

// Module function option(keyword=value, ...)
static PyObject *
gdc_option(PyObject *self, PyObject *args, PyObject *keywordDict)
{
    typedef enum {
	opt_bool,
	opt_bool_a,
	opt_float,
	opt_font,
	opt_int,
	opt_int_a,
	opt_long,
	opt_long_a,
	opt_percent,
	opt_special,
	opt_string
    } option_type;

    static struct option {
	char	       *keyword;
	option_type	type;
	void	       *chartvar;
	void	       *pievar;
	void	      **cache;
    } options[] = {
	{ "annotation",		opt_special,	NULL,			NULL		    },
	{ "annotation_font",	opt_font,	&GDC_annotation_font,	NULL		    },
	{ "bar_width",		opt_percent,	&GDC_bar_width,		NULL		    },
	{ "bg_color",		opt_long,	&GDC_BGColor,		&GDCPIE_BGColor	    },
	{ "bg_image",		opt_string,	&GDC_BGImage,		&GDC_BGImage,	    &BGImage	    },
	{ "bg_transparent",	opt_bool,	&GDC_transparent_bg,	&GDC_transparent_bg },
	{ "border",		opt_bool,	&GDC_border,		NULL		    },
	{ "edge_color",		opt_long,	NULL,			&GDCPIE_EdgeColor   },
	{ "explode",		opt_int_a,	NULL,			&GDCPIE_explode,    &Explode	    },
	{ "ext_color",		opt_long_a,	&GDC_ExtColor,		NULL,		    &ExtColor	    },
	{ "ext_vol_color",	opt_long_a,	&GDC_ExtVolColor,	NULL,		    &ExtVolColor    },
	{ "format",		opt_special,	NULL,			NULL,		    },
	{ "generate_gif",	opt_bool,	&GDC_generate_gif,	&GDC_generate_gif   },
	{ "grid",		opt_bool,	&GDC_grid,		NULL		    },
	{ "grid_color",		opt_long,	&GDC_GridColor,		NULL		    },
	{ "hard_graphheight",	opt_int,	&GDC_hard_grapheight,	NULL		    },
	{ "hard_graphwidth",	opt_int,	&GDC_hard_graphwidth,	NULL		    },
	{ "hard_size",		opt_bool,	&GDC_hard_size,		NULL		    },
	{ "hard_xorig",		opt_int,	&GDC_hard_xorig,	NULL		    },
	{ "hard_yorig",		opt_int,	&GDC_hard_yorig,	NULL		    },
	{ "hlc_cap_width",	opt_percent,	&GDC_HLC_cap_width,	NULL		    },
	{ "hlc_style",		opt_special,	NULL,			NULL		    },
	{ "hold_img",		opt_special,	NULL,			NULL		    },
	{ "label_dist",		opt_int,	NULL,			&GDCPIE_label_dist  },
	{ "label_font",		opt_font,	NULL,			&GDCPIE_label_size  },
	{ "label_line",		opt_bool,	NULL,			&GDCPIE_label_line  },
	{ "line_color",		opt_long,	&GDC_LineColor,		&GDCPIE_LineColor   },

        // "missing" is obsolete (now: 2nd data set indicates missing pie slices)
	//{ "missing",		opt_bool_a,	NULL,			&GDCPIE_missing,    &Missing	    },

	{ "other_threshold",	opt_special,	NULL,			NULL		    },
	{ "percent_labels",	opt_special,	NULL,			NULL		    },
	{ "pie_color",		opt_long_a,	NULL,			&GDCPIE_Color,	    &PieColor	    },
	{ "plot_color",		opt_long,	&GDC_PlotColor,		&GDCPIE_PlotColor   },
	{ "requested_ymax",	opt_float,	&GDC_requested_ymax,	NULL		    },
	{ "requested_ymin",	opt_float,	&GDC_requested_ymin,	NULL		    },
	{ "requested_yinterval", opt_float,	&GDC_requested_yinterval, NULL		    },
	{ "scatter",		opt_special,	NULL,			NULL		    },
	{ "set_color",		opt_long_a,	&GDC_SetColor,		NULL,		    &SetColor	    },
	{ "stack_type",		opt_special,	NULL,			NULL		    },
	{ "thumblabel",		opt_string,	&GDC_thumblabel,	NULL,		    &ThumbLabel	    },
	{ "thumbnail",		opt_bool,	&GDC_thumbnail,		NULL		    },
	{ "thumbval",		opt_float,	&GDC_thumbval,		NULL		    },
	{ "threed_angle",	opt_special,	NULL,			NULL		    },
	{ "threed_depth",	opt_special,	NULL,			NULL		    }, // different types!
	{ "title",		opt_string,	&GDC_title,		&GDCPIE_title,	    &Title	    },
	{ "title_color",	opt_long,	&GDC_TitleColor,	NULL		    }, // why no pie opt?
	{ "title_font",		opt_font,	&GDC_title_size,	&GDCPIE_title_size  },
	{ "vol_color",		opt_long,	&GDC_VolColor,		NULL		    },
	{ "xaxis",		opt_bool,	&GDC_xaxis,		NULL		    },
	{ "xaxis_font",		opt_font,	&GDC_xaxisfont_size,	NULL		    },
	{ "xlabel_color",	opt_long,	&GDC_XLabelColor,	NULL		    },
	{ "xlabel_spacing",	opt_special,	NULL,			NULL		    },
	{ "xtitle",		opt_string,	&GDC_xtitle,		NULL,		    &XTitle	    },
	{ "xtitle_color",	opt_long,	&GDC_XTitleColor,	NULL		    },
	{ "xtitle_font",	opt_font,	&GDC_xtitle_size,	NULL		    },
	{ "yaxis",		opt_bool,	&GDC_yaxis,		NULL		    },
	{ "yaxis2",		opt_bool,	&GDC_yaxis2,		NULL		    },
	{ "yaxis_font",		opt_font,	&GDC_yaxisfont_size,	NULL		    },
	{ "ylabel_color",	opt_long,	&GDC_YLabelColor,	NULL		    },
	{ "ylabel_density",	opt_percent,	&GDC_ylabel_density,	NULL		    },
	{ "ylabel_fmt",		opt_string,	&GDC_ylabel_fmt,	NULL,		    &YLabelFmt	    },
	{ "ylabel2_color",	opt_long,	&GDC_YLabel2Color,	NULL		    },
	{ "ylabel2_fmt",	opt_string,	&GDC_ylabel2_fmt,	NULL,		    &YLabel2Fmt	    },
	{ "ytitle",		opt_string,	&GDC_ytitle,		NULL,		    &YTitle	    },
	{ "ytitle_color",	opt_long,	&GDC_YTitleColor,	NULL		    },
	{ "ytitle_font",	opt_font,	&GDC_ytitle_size,	NULL		    },
	{ "ytitle2",		opt_string,	&GDC_ytitle2,		NULL,		    &YTitle2	    },
	{ "ytitle2_color",	opt_long,	&GDC_YTitle2Color,	NULL		    },
	{ "zeroshelf",		opt_bool,	&GDC_0Shelf,		NULL		    },
	{ NULL }
    };

    int		pos;
    PyObject   *key;
    PyObject   *value; 

    // If there are any non-keyword arguments, or no arguments at all, report
    // an error.
    if (args != NULL && PyTuple_Size(args) > 0) {
	PyErr_SetString(GDChartError, "option: only keyword arguments allowed");
	return NULL;
    }
    // TODO: return a dict of current option values when no args are passed?
    if (keywordDict == NULL) {
	PyErr_SetString(PyExc_TypeError, "option requires at least one argument; none given");
	return NULL;
    }

    // Process keyword arguments.
    pos = 0;
    while (PyDict_Next(keywordDict, &pos, &key, &value)) {
	struct option *opt = options;
	char *keyword = PyString_AsString(key);
	while (opt->keyword != NULL) {
	    if (strcmp(opt->keyword, keyword) == 0) {
		break;
	    }
	    opt++;
	}
	if (opt->keyword == NULL) {
	    sprintf(Msgbuf, "option: unexpected keyword argument: %s", keyword);
	    PyErr_SetString(GDChartError, Msgbuf);
	    return NULL;
	}

	switch (opt->type) {
	    case opt_bool:
	    case opt_percent:
	    {
		char x = (char) PyInt_AsLong(value);
		if (PyErr_Occurred()) {
		    SetTypeError("option", keyword);
		    return NULL;
		}

		if (opt->type == opt_bool) {
		    x = (x != 0) ? 1 : 0;
		}
		else if (opt->type == opt_percent && (x < 0 || x > 100)) {
		    SetValueError("option", keyword);
		    return NULL;
		}

		if (opt->chartvar != NULL) {
		    *((char *) opt->chartvar) = x;
		}
		if (opt->pievar != NULL) {
		    *((char *) opt->pievar) = x;
		}
		break;
	    }

#if 0
            // "missing" was the only option of this type, and is now
            // obsolete.
	    case opt_bool_a:
	    {
		int		size;
		unsigned char *vals = NULL; 

		if (value == Py_None) {
		    size = 0;
		}
		else {
		    if (!PySequence_Check(value)) {
			SetTypeError("option", keyword);
			return NULL;
		    }
		    size = PyObject_Length(value);
		}

		if (size > 0) {
		    int i;
		    vals = Py_Malloc(size * sizeof(unsigned char));
		    if (vals == NULL) {
			return NULL;
		    }

		    for (i = 0; i < size; i++) {
			PyObject *element = PySequence_GetItem(value, i);
			int x = PyInt_AsLong(element);
			Py_DECREF(element);
			vals[i] = (x != 0) ? 1 : 0;
		    }
		    if (PyErr_Occurred()) {
			SetTypeError("option", keyword);
			return NULL;
		    }
		}
		if (opt->chartvar != NULL) {
		    *((unsigned char **) opt->chartvar) = vals;
		}
		if (opt->pievar != NULL) {
		    *((unsigned char **) opt->pievar) = vals;
		}
		if (*opt->cache != NULL) {
		    Py_Free(*opt->cache);
		}
		*opt->cache = vals;
		break;
	    }
#endif

	    case opt_float:
	    {
		float x = (float) PyFloat_AsDouble(value);
		if (PyErr_Occurred()) {
		    SetTypeError("option", keyword);
		    return NULL;
		}

		if (opt->chartvar != NULL) {
		    *((float *) opt->chartvar) = x;
		}
		if (opt->pievar != NULL) {
		    *((float *) opt->pievar) = x;
		}
		break;
	    }

	    case opt_font:
	    {
		enum GDC_font_size x = (enum GDC_font_size) PyInt_AsLong(value);
		if (PyErr_Occurred()) {
		    SetTypeError("option", keyword);
		    return NULL;
		}

		if (x < GDC_pad || x >= GDC_numfonts) {
		    SetValueError("option", keyword);
		    return NULL;
		}

		if (opt->chartvar != NULL) {
		    *((enum GDC_font_size *) opt->chartvar) = x;
		}
		if (opt->pievar != NULL) {
		    *((enum GDC_font_size *) opt->pievar) = x;
		}
		break;
	    }

	    case opt_int: 
	    case opt_long:	// assumes that sizeof(int) == sizeof(long)!
	    {
		int x = (int) PyInt_AsLong(value);
		if (PyErr_Occurred()) {
		    SetTypeError("option", keyword);
		    return NULL;
		}

		if (opt->chartvar != NULL) {
		    *((int *) opt->chartvar) = x;
		}
		if (opt->pievar != NULL) {
		    *((int *) opt->pievar) = x;
		}
		break;
	    }

	    case opt_int_a:
	    case opt_long_a:	    assert(sizeof(int) == sizeof(long));
	    {
		int size;
		int  *vals = NULL; 

		if (value == Py_None) {
		    size = 0;
		}
		else {
		    if (!PySequence_Check(value)) {
			SetTypeError("option", keyword);
			return NULL;
		    }
		    size = PyObject_Length(value);
		}

		if (size > 0) {
		    int i;
		    vals = Py_Malloc(size * sizeof(int));
		    if (vals == NULL) {
			return NULL;
		    }

		    for (i = 0; i < size; i++) {
			PyObject *element = PySequence_GetItem(value, i);
			int x = PyInt_AsLong(element);
			Py_DECREF(element);
			vals[i] = x;
		    }
		    if (PyErr_Occurred()) {
			SetTypeError("option", keyword);
			return NULL;
		    }
		}
		if (opt->chartvar != NULL) {
		    *((int **) opt->chartvar) = vals;
		}
		if (opt->pievar != NULL) {
		    *((int **) opt->pievar) = vals;
		}
		if (*opt->cache != NULL) {
		    Py_Free(*opt->cache);
		}
		*opt->cache = vals;
		break;
	    }

	    case opt_special:
		if (!_handle_special_option(keyword, value)) {
		    return NULL;
		}
		break;

	    case opt_string:
	    {
		int len;
		char *val = NULL; 

		if (value == Py_None) {
		    len = 0;
		}
		else {
		    if (!PyString_Check(value)) {
			SetTypeError("option", keyword);
			return NULL;
		    }
		    len = PyString_Size(value);
		}

		if (len > 0) {
		    val = strdup(PyString_AsString(value));
		}
		if (opt->chartvar != NULL) {
		    *((unsigned char **) opt->chartvar) = val;
		}
		if (opt->pievar != NULL) {
		    *((unsigned char **) opt->pievar) = val;
		}
		if (*opt->cache != NULL) {
		    Py_Free(*opt->cache);
		}
		*opt->cache = val;
		break;
	    }

	    default:
		PyErr_SetString(GDChartError, "something is horribly wrong in gdchart");
		return NULL;
		//break;
	}
    }

    Py_INCREF(Py_None);
    return Py_None;
}


// Export an integer value.
static void
_export_int(PyObject *dict, char *name, int value)
{
    PyObject *x = PyInt_FromLong((long) value);
    if (x == NULL || PyDict_SetItemString(dict, name, x) != 0) {
	PyErr_Clear();
    }
    Py_XDECREF(x);
}


// Initialize the module.
void
initgdchart()
{
    static PyMethodDef methods[] = {
	{ "chart",		    gdc_chart,	METH_VARARGS,	ChartDoc  },
	{ "option",   (PyCFunction) gdc_option,	METH_KEYWORDS,	OptionDoc },
	{ NULL,			    NULL }
    };

    PyObject   *module; 
    PyObject   *dict;

    module = Py_InitModule4("gdchart", methods, ModuleDoc, NULL,
	PYTHON_API_VERSION);
    dict = PyModule_GetDict(module);

    // Create module-level exception.
    GDChartError = PyErr_NewException("gdchart.error", NULL, NULL);
    PyDict_SetItemString(dict, "error", GDChartError);

    // Export GDChart constants.

    // Image formats:
    _export_int(dict, "GDC_PNG", GDC_PNG);
    _export_int(dict, "GDC_JPEG", GDC_JPEG);

    // Chart styles (including pie):
    _export_int(dict, "GDC_LINE", GDC_LINE);
    _export_int(dict, "GDC_AREA", GDC_AREA);
    _export_int(dict, "GDC_BAR", GDC_BAR);
    _export_int(dict, "GDC_HILOCLOSE", GDC_HILOCLOSE);
    _export_int(dict, "GDC_COMBO_LINE_BAR", GDC_COMBO_LINE_BAR);
    _export_int(dict, "GDC_COMBO_HLC_BAR", GDC_COMBO_HLC_BAR);
    _export_int(dict, "GDC_COMBO_LINE_AREA", GDC_COMBO_LINE_AREA);
    _export_int(dict, "GDC_COMBO_HLC_AREA", GDC_COMBO_HLC_AREA);
    _export_int(dict, "GDC_3DHILOCLOSE", GDC_3DHILOCLOSE);
    _export_int(dict, "GDC_3DCOMBO_LINE_BAR", GDC_3DCOMBO_LINE_BAR);
    _export_int(dict, "GDC_3DCOMBO_LINE_AREA", GDC_3DCOMBO_LINE_AREA);
    _export_int(dict, "GDC_3DCOMBO_HLC_BAR", GDC_3DCOMBO_HLC_BAR);
    _export_int(dict, "GDC_3DCOMBO_HLC_AREA", GDC_3DCOMBO_HLC_AREA);
    _export_int(dict, "GDC_3DBAR", GDC_3DBAR);
    _export_int(dict, "GDC_3DAREA", GDC_3DAREA);
    _export_int(dict, "GDC_3DLINE", GDC_3DLINE);
    _export_int(dict, "GDC_3DPIE", MY_GDC_3DPIE);
    _export_int(dict, "GDC_2DPIE", MY_GDC_2DPIE);

    // Fonts:
    _export_int(dict, "GDC_TINY", GDC_TINY);
    _export_int(dict, "GDC_SMALL", GDC_SMALL);
    _export_int(dict, "GDC_MEDBOLD", GDC_MEDBOLD);
    _export_int(dict, "GDC_LARGE", GDC_LARGE);
    _export_int(dict, "GDC_GIANT", GDC_GIANT);

    // Stack options:
    _export_int(dict, "GDC_STACK_DEPTH", GDC_STACK_DEPTH);
    _export_int(dict, "GDC_STACK_SUM", GDC_STACK_SUM);
    _export_int(dict, "GDC_STACK_BESIDE", GDC_STACK_BESIDE);
    _export_int(dict, "GDC_STACK_LAYER", GDC_STACK_LAYER);

    // Hi-lo-close styles:
    _export_int(dict, "GDC_HLC_DIAMOND", GDC_HLC_DIAMOND);
    _export_int(dict, "GDC_HLC_CLOSE_CONNECTED", GDC_HLC_CLOSE_CONNECTED);
    _export_int(dict, "GDC_HLC_CONNECTING", GDC_HLC_CONNECTING);
    _export_int(dict, "GDC_HLC_I_CAP", GDC_HLC_I_CAP);

    // Scatter point styles:
    _export_int(dict, "GDC_SCATTER_TRIANGLE_DOWN", GDC_SCATTER_TRIANGLE_DOWN);
    _export_int(dict, "GDC_SCATTER_TRIANGLE_UP", GDC_SCATTER_TRIANGLE_UP);

    // Percent placement (pie charts):
    _export_int(dict, "GDCPIE_PCT_NONE", GDCPIE_PCT_NONE);
    _export_int(dict, "GDCPIE_PCT_ABOVE", GDCPIE_PCT_ABOVE);
    _export_int(dict, "GDCPIE_PCT_BELOW", GDCPIE_PCT_BELOW);
    _export_int(dict, "GDCPIE_PCT_RIGHT", GDCPIE_PCT_RIGHT);
    _export_int(dict, "GDCPIE_PCT_LEFT", GDCPIE_PCT_LEFT);

    // Get cStringIO module if it is available: reference is in PycStringIO.
    PycString_IMPORT;

    Py_AtExit(_cleanup);

    if (PyErr_Occurred()) {
	Py_FatalError("can't initialize module gdchart");
    }
}

