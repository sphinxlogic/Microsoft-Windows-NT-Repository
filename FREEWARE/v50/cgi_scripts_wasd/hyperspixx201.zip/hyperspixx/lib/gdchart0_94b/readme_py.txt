Python interface to GDChart
Mike Steed
msteed@fiber.net
May 9, 2000

HISTORY

  May 9, 2000: Version 0.41
    - Bug fix (percent_labels).

  May 2, 2000: Version 0.4
    - Updated the library to use gd-1.8.1.  GDChart now produces PNG and JPEG
      images instead of GIFs.
    - Support for transparent backgrounds in pie charts (thanks to Chui Tey).
    - Support for cStringIO.

  February 17, 2000: Version 0.3
    - Support for missing values in datasets.

  February 3, 2000: Version 0.2
    - Fixed a Windows NT crash (thanks to Roger Dev).
    - Updated the Win32 build to reflect Robert Kern's directions for building
	Python extension modules with the mingw32 tools.  See
	<http://starship.python.net/crew/kernr/mingw32/Notes.html>.
    - The pre-built Win32 binary is now built against Python-1.5.2.
    - test.py: Open file in binary mode for Win32.
    - Included Solaris makefile by Nathan Clegg (makepy.solaris).

  August 11, 1999: Version 0.1, based on GDChart-0.94b.
    - Initial release.

FILES

  The following files make up the Python interface to GDChart:

  gdc_py.c:       The Python module source.
  gdchart.def:    DEF file for Win32 build module.
  makepy.linux:   Makefile for building the module under Linux.
  makepy.solaris: Makefile for building the module under Solaris (with gcc).
  makepy.w32      Makefile for building the module under Win32.
  test.py:        Examples of gdchart in action.
  README_PY.txt:  This file.

  Also of possible interest:

  gdchart.pyd:    Pre-built Win32 module.

BUILDING

    1. Build GDChart -- just run make with no arguments.  Note that to get a
       smaller and faster shared library, you may want to turn on
       optimizations in the GDChart makefile ('CC=gcc -O' or 'CC=gcc -O2').

    2. Make sure Python is on your system. :-)  I have built the module with
       Python-1.5.2.  It will probably build against other versions of Python
       on Linux/Solaris without changes.  A little more work may be required
       on Win32.

    3. Follow the appropriate platform-specific instructions below.

  -Linux/Solaris-

    1. Edit makepy.linux (or makepy.solaris) to specify the location of the
       Python include files and the jpeg, libpng, and zlib includes files and
       libraries.

    2. make -f makepy.linux (or make -f makepy.solaris)

  This should produce gdchart.so, which you can then copy to a convenient
  place, e.g., somewhere in your $PYTHONPATH.  If you run into build problems,
  I will do what I can to help.  I don't have access to a Solaris box.

  -Win32-

  There should be a pre-built Win32 binary (gdchart.pyd) in the distribution.
  If not, I will be happy to provide one for you.  Otherwise, read on...

  To build the module under Win32, you must use gcc.  This is because GDChart
  itself must be built with gcc.  I used gcc-2.95.2/mingw32.

    1. Edit makepy.w32 to specify the location of the Python headers and
       import library for the minwg32 tools (PY_INC and PY_LIB).  Paths
       containing spaces may cause trouble.  Complain to Microsoft.

    2. make -f makepy.w32

  This should produce gdchart.pyd, which you can then copy to a convenient
  place, e.g., somewhere in your $PYTHONPATH.  If you run into build problems,
  I will do what I can to help.

USE

  There are doc strings for the module and the two functions that it exports.
  Beyond that, there are some examples in test.py, and you can always look at
  the C source code. :-)  The sparse documentation for the Python module
  reflects the state of the library documentation, which is non-existent.

TODO

  See gdc_py.c
