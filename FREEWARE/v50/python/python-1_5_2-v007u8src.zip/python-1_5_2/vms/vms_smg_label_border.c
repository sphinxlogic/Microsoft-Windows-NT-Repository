/* VMS_SMG_LABEL_BORDER.C -- 22-MAR-2000 Uwe Zessin
   Python interface to SMG$LABEL_BORDER

--------------------
$ @ PYTHON_VMS:BLDRUN  VMS  VMS_SMG_LABEL_BORDER

*/

#if defined(__DECC) || defined(__DECCXX)
#pragma module VMS_SMG_LABEL_BORDER "20000322"
#endif

/* ------------------------------------------------------------------------- */

#include "vmsdef.h"		/* includes "Python.h" */

#include <descrip.h>
#include <smg$routines.h>	/* SMG$name  */
#include <ssdef.h>		/* SS$_name  */

/* ------------------------------------------------------------------------- */
extern PyObject *vms_smg_gr_error;		/* exception vms_smg.error */
/* ------------------------------------------------------------------------- */

char vms_smg_label_border__doc[] =
"None = vms_smg.label_border (display_id, [text], [position_code],\
 [units], [rendition_set], [rendition_complement], [character_set])\n\
Label a Virtual Display Border.";

/* ------------------------------------------------------------------------- */

PyObject *
vms_smg_label_border (PyObject *self, PyObject *args)
{
	unsigned long		  l_display_id;

	char			* at_text;
	struct dsc$descriptor_s   r_text;
	struct dsc$descriptor_s * ar_text;
	unsigned long		  l_text_len;

	PyObject		* ar_position_code;
	unsigned long		  l_position_code;
	unsigned long		* al_position_code;

	PyObject		* ar_units;
	long			  l_units;
	long			* al_units;

	PyObject		* ar_rendition_set;
	unsigned long		  l_rendition_set;
	unsigned long		* al_rendition_set;

	PyObject		* ar_rendition_complement;
	unsigned long		  l_rendition_complement;
	unsigned long		* al_rendition_complement;

	PyObject		* ar_character_set;
	long			  l_character_set;
	long			* al_character_set;

	unsigned long		  l_status;

	/* -------------------- */
	at_text                 = NULL;    l_text_len = 0;
	ar_position_code        = Py_None;
	ar_units                = Py_None;
	ar_rendition_set        = Py_None;
	ar_rendition_complement = Py_None;
	ar_character_set        = Py_None;

	/* -------------------- */
	if (!PyArg_ParseTuple(args, "i|z#OOOOO"
	    ,&l_display_id
	    ,&at_text     ,&l_text_len
	    ,&ar_position_code
	    ,&ar_units
	    ,&ar_rendition_set
	    ,&ar_rendition_complement
	    ,&ar_character_set
	    ))
	{
	    return NULL;
	}

	/* -------------------- */
	/* argument 1: display_id */

	/* -------------------- */
	/* argument 2: text */
	if (at_text == NULL)
	{
	    ar_text = 0;	/* omitted */
	}
	else
	{
	    if (l_text_len > 65535)
	    {
		PyErr_SetString(PyExc_ValueError,
		 "argument 2: text - string size limited to 65535 characters");
		return NULL;
	    }
	    r_text.dsc$w_length  = l_text_len;
	    r_text.dsc$b_dtype   = DSC$K_DTYPE_T;
	    r_text.dsc$b_class   = DSC$K_CLASS_S;
	    r_text.dsc$a_pointer = at_text;
	    ar_text = &r_text;
	}

	/* -------------------- */
	/* argument 3: [position_code] */
	if (ar_position_code == Py_None)
	{
	    al_position_code = 0;		/* omitted */
	    l_position_code  = 0;
	}
	else
	{
	    if (!PyInt_Check(ar_position_code))
	    {
		PyErr_SetString(PyExc_TypeError,
		    "argument 3: position_code - must be integer or None");
		return NULL;
	    }
	    l_position_code = PyInt_AsLong(ar_position_code);
	    if (PyErr_Occurred())
	    {
		return NULL;
	    }
	    al_position_code = &l_position_code;
	}

	/* -------------------- */
	/* argument 4: [units] */
	if (ar_units == Py_None)
	{
	    al_units = 0;		/* omitted */
	    l_units  = 0;
	}
	else
	{
	    if (!PyInt_Check(ar_units))
	    {
		PyErr_SetString(PyExc_TypeError,
		    "argument 4: units - must be integer or None");
		return NULL;
	    }
	    l_units = PyInt_AsLong(ar_units);
	    if (PyErr_Occurred())
	    {
		return NULL;
	    }
	    al_units = &l_units;
	}

	/* -------------------- */
	/* argument 5: [rendition_set] */
	if (ar_rendition_set == Py_None)
	{
	    al_rendition_set = 0;		/* omitted */
	    l_rendition_set  = 0;
	}
	else
	{
	    if (!PyInt_Check(ar_rendition_set))
	    {
		PyErr_SetString(PyExc_TypeError,
		    "argument 5: rendition_set - must be integer or None");
		return NULL;
	    }
	    l_rendition_set = PyInt_AsLong(ar_rendition_set);
	    if (PyErr_Occurred())
	    {
		return NULL;
	    }
	    al_rendition_set = &l_rendition_set;
	}

	/* -------------------- */
	/* argument 6: [rendition_complement] */
	if (ar_rendition_complement == Py_None)
	{
	    al_rendition_complement = 0;		/* omitted */
	    l_rendition_complement  = 0;
	}
	else
	{
	    if (!PyInt_Check(ar_rendition_complement))
	    {
		PyErr_SetString(PyExc_TypeError,
		 "argument 6: rendition_complement - must be integer or None");
		return NULL;
	    }
	    l_rendition_complement = PyInt_AsLong(ar_rendition_complement);
	    if (PyErr_Occurred())
	    {
		return NULL;
	    }
	    al_rendition_complement = &l_rendition_complement;
	}

	/* -------------------- */
	/* argument 7: [character_set] */
	if (ar_character_set == Py_None)
	{
	    al_character_set = 0;		/* omitted */
	    l_character_set  = 0;
	}
	else
	{
	    if (!PyInt_Check(ar_character_set))
	    {
		PyErr_SetString(PyExc_TypeError,
		    "argument 7: character_set - must be integer or None");
		return NULL;
	    }
	    l_character_set = PyInt_AsLong(ar_character_set);
	    if (PyErr_Occurred())
	    {
		return NULL;
	    }
	    al_character_set = &l_character_set;
	}

	/* -------------------- */
	l_status = smg$label_border
		(&l_display_id
		,ar_text
		,al_position_code
		,al_units
		,al_rendition_set
		,al_rendition_complement
		,al_character_set
		);

	/* -------------------- */
	if (l_status == SS$_NORMAL)
	{
	    Py_INCREF(Py_None);
	    return (Py_None);
	}

	/* -------------------- */
	/* error */
	return PyVMS_ErrSetVal(vms_smg_gr_error, 1, l_status);
} /* vms_smg_label_border () */

/* ------------------------------------------------------------------------- */

/* EOF: VMS_SMG_LABEL_BORDER.C */
