/* VMS_SMG_KEYCODE_TO_NAME.C -- 22-MAR-2000 Uwe Zessin
   Python interface to SMG$KEYCODE_TO_NAME

20-AUG-2000 ZE. -- bugfix, parameter passing

--------------------
$ @ PYTHON_VMS:BLDRUN  VMS  VMS_SMG_KEYCODE_TO_NAME

*/

#if defined(__DECC) || defined(__DECCXX)
#pragma module VMS_SMG_KEYCODE_TO_NAME "20000820"
#endif

/* ------------------------------------------------------------------------- */

#include "vmsdef.h"		/* includes "Python.h" */

#include <descrip.h>
#include <lib$routines.h>	/* LIB$name */
#include <smg$routines.h>	/* SMG$name */
#include <ssdef.h>		/* SS$_name */

/* ------------------------------------------------------------------------- */
extern PyObject *vms_smg_gr_error;		/* exception vms_smg.error */
/* ------------------------------------------------------------------------- */

char vms_smg_keycode_to_name__doc[] =
"key_name = vms_smg.keycode_to_name (key_code)\n\
Translate a Key Code into a Key Name.";

/* ------------------------------------------------------------------------- */

PyObject *
vms_smg_keycode_to_name (PyObject *self, PyObject *args)
{
	unsigned long		  l_key_code;
	unsigned short		  w_key_code;

	struct dsc$descriptor_s   r_key_name;

	unsigned long		  l_status_smg;
	unsigned long		  l_status_free;

	PyObject		* ar_return;

	/* -------------------- */
	if (!PyArg_ParseTuple(args, "i", &l_key_code))
	{
	    return NULL;
	}

	/* -------------------- */
	/* argument 1: key_code */
	if ((l_key_code < 0) || (l_key_code > 65535))
	{
	    PyErr_SetString(PyExc_ValueError,
	     "argument 1: key_code - must be between 0..65535");
	    return NULL;
	}
	w_key_code = l_key_code;

	/* -------------------- */
	/* set up string descriptor */
	/*  let SMG$KEYCODE_TO_NAME allocate the memory */
	r_key_name.dsc$w_length  = 0;
	r_key_name.dsc$b_dtype   = DSC$K_DTYPE_T;
	r_key_name.dsc$b_class   = DSC$K_CLASS_D; /* not _S !! */
	r_key_name.dsc$a_pointer = 0;

	/* -------------------- */
	l_status_smg = smg$keycode_to_name
		(&w_key_code
		,&r_key_name
		);

	/* -------------------- */
	if (l_status_smg == SS$_NORMAL)
	{
	    ar_return = Py_BuildValue
		("s#"
		,(r_key_name.dsc$w_length == 0) /* empty string? */
		  ? (void*)&r_key_name       /* non-NULL address */
		  : (void*)r_key_name.dsc$a_pointer
		,(unsigned int)r_key_name.dsc$w_length
		);
	}
	else
	{
	    ar_return = NULL;
	}

	/* -------------------- */
	/* deallocate memory of dynamic string descriptors */
	l_status_free = lib$sfree1_dd (&r_key_name);
	if (l_status_free != SS$_NORMAL)
	{
	    PyErr_SetString(PyExc_SystemError,
		"vms_smg_keycode_to_name: LIB$SFREE1_DD() failed");
	    (void) PyErr_Print();

	    if (l_status_smg == SS$_NORMAL)
	    {
		l_status_smg = l_status_free; /* fail anyway */
	        Py_XDECREF(ar_return);
		ar_return = NULL;
	    }
	}

	/* -------------------- */
	if (l_status_smg == SS$_NORMAL)
	{
	    return ar_return;
	}

	Py_XDECREF(ar_return);

	/* -------------------- */
	/* error */
	return PyVMS_ErrSetVal(vms_smg_gr_error, 1, l_status_smg);
} /* vms_smg_keycode_to_name () */

/* ------------------------------------------------------------------------- */

/* EOF: VMS_SMG_KEYCODE_TO_NAME.C */
