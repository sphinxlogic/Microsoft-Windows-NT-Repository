/* VMS_SMG_RETURN_CURSOR_POS.C -- 26-MAR-2000 Uwe Zessin
   Python interface to SMG$RETURN_CURSOR_POS

--------------------
$ @ PYTHON_VMS:BLDRUN  VMS  VMS_SMG_RETURN_CURSOR_POS

27-AUG-2000 ZE. -- fix doc-string
*/

#if defined(__DECC) || defined(__DECCXX)
#pragma module VMS_SMG_RETURN_CURSOR_POS "20000827"
#endif

/* ------------------------------------------------------------------------- */

#include "vmsdef.h"		/* includes "Python.h" */

#include <smg$routines.h>	/* SMG$name */
#include <ssdef.h>		/* SS$_name */

/* ------------------------------------------------------------------------- */
extern PyObject *vms_smg_gr_error;		/* exception vms_smg.error */
/* ------------------------------------------------------------------------- */

char vms_smg_return_cursor_pos__doc[] =
"start_row, start_column = vms_smg.return_cursor_pos (display_id)\n\
Return Cursor Position.";

/* ------------------------------------------------------------------------- */

PyObject *
vms_smg_return_cursor_pos (PyObject *self, PyObject *args)
{
	unsigned long		  l_display_id;

	long			  l_start_row;
	long			  l_start_column;

	unsigned long		  l_status;

	/* -------------------- */
	if (!PyArg_ParseTuple(args, "i", &l_display_id))
	{
	    return NULL;
	}

	/* -------------------- */
	/* argument 1: display_id */

	/* -------------------- */
	l_start_row    = 0;
	l_start_column = 0;

	/* -------------------- */
	l_status = smg$return_cursor_pos
		(&l_display_id
		,&l_start_row
		,&l_start_column
		);

	/* -------------------- */
	if (l_status == SS$_NORMAL)
	{
	    return Py_BuildValue ("ii", l_start_row, l_start_column);
	}

	/* -------------------- */
	/* error */
	return PyVMS_ErrSetVal(vms_smg_gr_error, 1, l_status);
} /* vms_smg_return_cursor_pos () */

/* ------------------------------------------------------------------------- */

/* EOF: VMS_SMG_RETURN_CURSOR_POS.C */
