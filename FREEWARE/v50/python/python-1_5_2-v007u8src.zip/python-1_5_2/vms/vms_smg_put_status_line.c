/* VMS_SMG_PUT_STATUS_LINE.C -- 25-MAR-2000 Uwe Zessin
   Python interface to SMG$PUT_STATUS_LINE

25-AUG-2000 ZE. -- return |status|

--------------------
$ @ PYTHON_VMS:BLDRUN  VMS  VMS_SMG_PUT_STATUS_LINE

*/

#if defined(__DECC) || defined(__DECCXX)
#pragma module VMS_SMG_PUT_STATUS_LINE "20000825"
#endif

/* ------------------------------------------------------------------------- */

#include "vmsdef.h"		/* includes "Python.h" */

#include <descrip.h>
#include <smg$routines.h>	/* SMG$name  */
#include <smgmsg.h>		/* SMG$_name */
#include <ssdef.h>		/* SS$_name  */

/* ------------------------------------------------------------------------- */
extern PyObject *vms_smg_gr_error;		/* exception vms_smg.error */
/* ------------------------------------------------------------------------- */

char vms_smg_put_status_line__doc[] =
"status = vms_smg.put_status_line (pasteboard_id, text)\n\
Output Line of Text to Hardware Status Line.";

/* ------------------------------------------------------------------------- */

PyObject *
vms_smg_put_status_line (PyObject *self, PyObject *args)
{
	unsigned long		  l_pasteboard_id;

	char			* at_text;
	struct dsc$descriptor_s   r_text;
	unsigned long		  l_text_len;

	unsigned long		  l_status;

	/* -------------------- */
	if (!PyArg_ParseTuple(args, "is#"
	    ,&l_pasteboard_id
	    ,&at_text         ,&l_text_len
	    ))
	{
	    return NULL;
	}

	/* -------------------- */
	/* argument 1: pasteboard_id */

	/* -------------------- */
	/* argument 2: text */
	if (l_text_len > 65535)
	{
	    PyErr_SetString(PyExc_ValueError,
		"argument 2: text - string size limited to 65535 characters");
	    return NULL;
	}
	r_text.dsc$w_length  = l_text_len;
	r_text.dsc$b_dtype   = DSC$K_DTYPE_T;
	r_text.dsc$b_class   = DSC$K_CLASS_S;
	r_text.dsc$a_pointer = at_text;

	/* -------------------- */
	l_status = smg$put_status_line
		(&l_pasteboard_id
		,&r_text
		);

	/* -------------------- */
	if ((l_status == SS$_NORMAL) || (l_status == SMG$_OPNOTSUP))
	{
	    return Py_BuildValue ("i", l_status);
	}

	/* -------------------- */
	/* error */
	return PyVMS_ErrSetVal(vms_smg_gr_error, 1, l_status);
} /* vms_smg_put_status_line () */

/* ------------------------------------------------------------------------- */

/* EOF: VMS_SMG_PUT_STATUS_LINE.C */
