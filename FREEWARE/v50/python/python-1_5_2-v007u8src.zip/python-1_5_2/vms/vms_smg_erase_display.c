/* VMS_SMG_ERASE_DISPLAY.C -- 09-MAR-2000 Uwe Zessin
   Python interface to SMG$ERASE_DISPLAY

--------------------
$ @ PYTHON_VMS:BLDRUN  VMS  VMS_SMG_ERASE_DISPLAY

*/

#if defined(__DECC) || defined(__DECCXX)
#pragma module VMS_SMG_ERASE_DISPLAY "20000819"
#endif

/* ------------------------------------------------------------------------- */

#include "vmsdef.h"		/* includes "Python.h" */

#include <smg$routines.h>	/* SMG$name  */
#include <ssdef.h>		/* SS$_name  */

/* ------------------------------------------------------------------------- */
extern PyObject *vms_smg_gr_error;		/* exception vms_smg.error */
/* ------------------------------------------------------------------------- */

char vms_smg_erase_display__doc[] =
"None = vms_smg.erase_display (display_id, [start_row], [start_column],\
 [end_row], [end_column])\n\
Erase all or part of Virtual Display.";

/* ------------------------------------------------------------------------- */

PyObject *
vms_smg_erase_display (PyObject *self, PyObject *args)
{
	unsigned long		  l_display_id;

	PyObject		* ar_start_row;
	unsigned long		  l_start_row;
	unsigned long		* al_start_row;

	PyObject		* ar_start_column;
	unsigned long		  l_start_column;
	unsigned long		* al_start_column;

	PyObject		* ar_end_row;
	unsigned long		  l_end_row;
	unsigned long		* al_end_row;

	PyObject		* ar_end_column;
	unsigned long		  l_end_column;
	unsigned long		* al_end_column;

	unsigned long		  l_status;

	/* -------------------- */
	ar_start_row    = Py_None;
	ar_start_column = Py_None;
	ar_end_row      = Py_None;
	ar_end_column   = Py_None;

	/* -------------------- */
	if (!PyArg_ParseTuple(args, "i|OOOO"
	    ,&l_display_id
	    ,&ar_start_row
	    ,&ar_start_column
	    ,&ar_end_row
	    ,&ar_end_column
	    ))
	{
	    return NULL;
	}

	/* -------------------- */
	/* argument 1: display_id */

	/* -------------------- */
	/* argument 2: [start_row] */
	if (ar_start_row == Py_None)
	{
	    al_start_row = 0;		/* omitted */
	    l_start_row  = 0;
	}
	else
	{
	    if (!PyInt_Check(ar_start_row))
	    {
		PyErr_SetString(PyExc_TypeError,
		    "argument 2: start_row - must be integer or None");
		return NULL;
	    }
	    l_start_row = PyInt_AsLong(ar_start_row);
	    if (PyErr_Occurred())
	    {
		return NULL;
	    }
	    al_start_row = &l_start_row;
	}

	/* -------------------- */
	/* argument 3: [start_column] */
	if (ar_start_column == Py_None)
	{
	    al_start_column = 0;		/* omitted */
	    l_start_column  = 0;
	}
	else
	{
	    if (!PyInt_Check(ar_start_column))
	    {
		PyErr_SetString(PyExc_TypeError,
		    "argument 3: start_column - must be integer or None");
		return NULL;
	    }
	    l_start_column = PyInt_AsLong(ar_start_column);
	    if (PyErr_Occurred())
	    {
		return NULL;
	    }
	    al_start_column = &l_start_column;
	}

	/* -------------------- */
	/* argument 4: [end_row] */
	if (ar_end_row == Py_None)
	{
	    al_end_row = 0;		/* omitted */
	    l_end_row  = 0;
	}
	else
	{
	    if (!PyInt_Check(ar_end_row))
	    {
		PyErr_SetString(PyExc_TypeError,
		    "argument 4: end_row - must be integer or None");
		return NULL;
	    }
	    l_end_row = PyInt_AsLong(ar_end_row);
	    if (PyErr_Occurred())
	    {
		return NULL;
	    }
	    al_end_row = &l_end_row;
	}

	/* -------------------- */
	/* argument 5: [end_column] */
	if (ar_end_column == Py_None)
	{
	    al_end_column = 0;		/* omitted */
	    l_end_column  = 0;
	}
	else
	{
	    if (!PyInt_Check(ar_end_column))
	    {
		PyErr_SetString(PyExc_TypeError,
		    "argument 5: end_column - must be integer or None");
		return NULL;
	    }
	    l_end_column = PyInt_AsLong(ar_end_column);
	    if (PyErr_Occurred())
	    {
		return NULL;
	    }
	    al_end_column = &l_end_column;
	}

	/* -------------------- */
	l_status = smg$erase_display
		(&l_display_id
		,al_start_row
		,al_start_column
		,al_end_row
		,al_end_column
		);

	/* -------------------- */
	if (l_status == SS$_NORMAL)
	{
	    Py_INCREF(Py_None);
	    return (Py_None);
	}

	/* -------------------- */
	/* error */
	return PyVMS_ErrSetVal(vms_smg_gr_error, 1, l_status);
} /* vms_smg_erase_display () */

/* ------------------------------------------------------------------------- */

/* EOF: VMS_SMG_ERASE_DISPLAY.C */
