/* VMS_SMG_LOAD_VIRTUAL_DISPLAY.C -- 22-MAR-2000 Uwe Zessin
   Python interface to SMG$LOAD_VIRTUAL_DISPLAY

31-AUG-2000 ZE. -- bugfix - paramaters, return display_id

--------------------
$ @ PYTHON_VMS:BLDRUN  VMS  VMS_SMG_LOAD_VIRTUAL_DISPLAY

*/

#if defined(__DECC) || defined(__DECCXX)
#pragma module VMS_SMG_LOAD_VIRTUAL_DISPLAY "20000831"
#endif

/* ------------------------------------------------------------------------- */

#include "vmsdef.h"		/* includes "Python.h" */

#include <descrip.h>
#include <smg$routines.h>	/* SMG$name */
#include <ssdef.h>		/* SS$_name */

/* ------------------------------------------------------------------------- */
extern PyObject *vms_smg_gr_error;		/* exception vms_smg.error */
/* ------------------------------------------------------------------------- */

char vms_smg_load_virtual_dpy__doc[] =
"display_id = vms_smg.load_virtual_display ([filespec])\n\
Load a Virtual Display from a File.";

/* ------------------------------------------------------------------------- */

PyObject *
vms_smg_load_virtual_display (PyObject *self, PyObject *args)
{
	unsigned long		  l_display_id;

	char			* at_filespec;
	struct dsc$descriptor_s   r_filespec;
	struct dsc$descriptor_s * ar_filespec;
	unsigned long		  l_filespec_len;

	unsigned long		  l_status;

	/* -------------------- */
	at_filespec = NULL; l_filespec_len = 0;

	/* -------------------- */
	if (!PyArg_ParseTuple(args, "z#"
	    ,&at_filespec ,&l_filespec_len
	    ))
	{
	    return NULL;
	}

	/* -------------------- */
	/* argument 1: filespec */
	if (at_filespec == NULL)
	{
	    ar_filespec = 0;	/* omitted */
	}
	else
	{
	    if (l_filespec_len > 65535)
	    {
		PyErr_SetString(PyExc_ValueError,
	     "argument 1: filespec - string size limited to 65535 characters");
		return NULL;
	    }
	    r_filespec.dsc$w_length  = l_filespec_len;
	    r_filespec.dsc$b_dtype   = DSC$K_DTYPE_T;
	    r_filespec.dsc$b_class   = DSC$K_CLASS_S;
	    r_filespec.dsc$a_pointer = at_filespec;
	    ar_filespec = &r_filespec;
	}

	/* -------------------- */
	l_status = smg$load_virtual_display
		(&l_display_id
		,ar_filespec
		);

	/* -------------------- */
	if (l_status == SS$_NORMAL)
	{
	    return Py_BuildValue ("i", l_display_id);
	}

	/* -------------------- */
	/* error */
	return PyVMS_ErrSetVal(vms_smg_gr_error, 1, l_status);
} /* vms_smg_load_virtual_display () */

/* ------------------------------------------------------------------------- */

/* EOF: VMS_SMG_LOAD_VIRTUAL_DISPLAY.C */
