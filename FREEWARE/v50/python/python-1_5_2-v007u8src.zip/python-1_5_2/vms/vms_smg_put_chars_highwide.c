/* VMS_SMG_PUT_CHARS_HIGHWIDE.C -- 25-MAR-2000 Uwe Zessin
   Python interface to SMG$PUT_CHARS_HIGHWIDE

22-AUG-2000 ZE. -- return |status|

--------------------
$ @ PYTHON_VMS:BLDRUN  VMS  VMS_SMG_PUT_CHARS_HIGHWIDE

*/

#if defined(__DECC) || defined(__DECCXX)
#pragma module VMS_SMG_PUT_CHARS_HIGHWIDE "20000822"
#endif

/* ------------------------------------------------------------------------- */

#include "vmsdef.h"		/* includes "Python.h" */

#include <descrip.h>
#include <smg$routines.h>	/* SMG$name  */
#include <smgmsg.h>		/* SMG$_name */
#include <ssdef.h>		/* SS$_name  */

/* ------------------------------------------------------------------------- */
extern PyObject *vms_smg_gr_error;		/* exception vms_smg.error */
/* ------------------------------------------------------------------------- */

char vms_smg_put_chars_highwide__doc[] =
"status = vms_smg.put_chars_highwide (display_id, text,\
 [start_row], [start_column],\
 [rendition_set], [rendition_complement], [character_set])\n\
Write Double-Height Double-Width Characters.";

/* ------------------------------------------------------------------------- */

PyObject *
vms_smg_put_chars_highwide (PyObject *self, PyObject *args)
{
	unsigned long		  l_display_id;

	char			* at_text;
	struct dsc$descriptor_s   r_text;
	unsigned long		  l_text_len;

	PyObject		* ar_start_row;
	long			  l_start_row;
	long			* al_start_row;

	PyObject		* ar_start_column;
	long			  l_start_column;
	long			* al_start_column;

	PyObject		* ar_rendition_set;
	unsigned long		  l_rendition_set;
	unsigned long		* al_rendition_set;

	PyObject		* ar_rendition_complement;
	unsigned long		  l_rendition_complement;
	unsigned long		* al_rendition_complement;

	PyObject		* ar_character_set;
	unsigned long		  l_character_set;
	unsigned long		* al_character_set;

	unsigned long		  l_status;

	/* -------------------- */
	ar_start_row            = Py_None;
	ar_start_column         = Py_None;
	ar_rendition_set        = Py_None;
	ar_rendition_complement = Py_None;
	ar_character_set        = Py_None;

	/* -------------------- */
	if (!PyArg_ParseTuple(args, "is#|OOOOO"
	    ,&l_display_id
	    ,&at_text                 ,&l_text_len
	    ,&ar_start_row
	    ,&ar_start_column
	    ,&ar_rendition_set
	    ,&ar_rendition_complement
	    ,&ar_character_set
	    ))
	{
	    return NULL;
	}

	/* -------------------- */
	/* argument 1: display_id */

	/* -------------------- */
	/* argument 2: text */
	if (l_text_len > 65535)
	{
	    PyErr_SetString(PyExc_ValueError,
		"argument 2: text - string size limited to 65535 characters");
	    return NULL;
	}
	r_text.dsc$w_length  = l_text_len;
	r_text.dsc$b_dtype   = DSC$K_DTYPE_T;
	r_text.dsc$b_class   = DSC$K_CLASS_S;
	r_text.dsc$a_pointer = at_text;

	/* -------------------- */
	/* argument 3: [start_row] */
	if (ar_start_row == Py_None)
	{
	    al_start_row = 0;		/* omitted */
	    l_start_row  = 0;
	}
	else
	{
	    if (!PyInt_Check(ar_start_row))
	    {
		PyErr_SetString(PyExc_TypeError,
		    "argument 3: start_row - must be integer or None");
		return NULL;
	    }
	    l_start_row = PyInt_AsLong(ar_start_row);
	    if (PyErr_Occurred())
	    {
		return NULL;
	    }
	    al_start_row = &l_start_row;
	}

	/* -------------------- */
	/* argument 4: [start_column] */
	if (ar_start_column == Py_None)
	{
	    al_start_column = 0;		/* omitted */
	    l_start_column  = 0;
	}
	else
	{
	    if (!PyInt_Check(ar_start_column))
	    {
		PyErr_SetString(PyExc_TypeError,
		 "argument 4: column - must be integer or None");
		return NULL;
	    }
	    l_start_column = PyInt_AsLong(ar_start_column);
	    if (PyErr_Occurred())
	    {
		return NULL;
	    }
	    al_start_column = &l_start_column;
	}

	/* -------------------- */
	/* argument 5: [rendition_set] */
	if (ar_rendition_set == Py_None)
	{
	    al_rendition_set = 0;		/* omitted */
	    l_rendition_set  = 0;
	}
	else
	{
	    if (!PyInt_Check(ar_rendition_set))
	    {
		PyErr_SetString(PyExc_TypeError,
		    "argument 5: rendition_set - must be integer or None");
		return NULL;
	    }
	    l_rendition_set = PyInt_AsLong(ar_rendition_set);
	    if (PyErr_Occurred())
	    {
		return NULL;
	    }
	    al_rendition_set = &l_rendition_set;
	}

	/* -------------------- */
	/* argument 6: [rendition_complement] */
	if (ar_rendition_complement == Py_None)
	{
	    al_rendition_complement = 0;		/* omitted */
	    l_rendition_complement  = 0;
	}
	else
	{
	    if (!PyInt_Check(ar_rendition_complement))
	    {
		PyErr_SetString(PyExc_TypeError,
		 "argument 6: rendition_complement - must be integer or None");
		return NULL;
	    }
	    l_rendition_complement = PyInt_AsLong(ar_rendition_complement);
	    if (PyErr_Occurred())
	    {
		return NULL;
	    }
	    al_rendition_complement = &l_rendition_complement;
	}

	/* -------------------- */
	/* argument 7: [character_set] */
	if (ar_character_set == Py_None)
	{
	    al_character_set = 0;		/* omitted */
	    l_character_set  = 0;
	}
	else
	{
	    if (!PyInt_Check(ar_character_set))
	    {
		PyErr_SetString(PyExc_TypeError,
		    "argument 7: character_set - must be integer or None");
		return NULL;
	    }
	    l_character_set = PyInt_AsLong(ar_character_set);
	    if (PyErr_Occurred())
	    {
		return NULL;
	    }
	    al_character_set = &l_character_set;
	}

	/* -------------------- */
	l_status = smg$put_chars_highwide
		(&l_display_id
		,&r_text
		,al_start_row
		,al_start_column
		,al_rendition_set
		,al_rendition_complement
		,al_character_set
		);

	/* -------------------- */
	if ((l_status == SS$_NORMAL) || (l_status == SMG$_WILUSERMS))
	{
	    return Py_BuildValue ("i", l_status);
	}

	/* -------------------- */
	/* error */
	return PyVMS_ErrSetVal(vms_smg_gr_error, 1, l_status);
} /* vms_smg_put_chars_highwide () */

/* ------------------------------------------------------------------------- */

/* EOF: VMS_SMG_PUT_CHARS_HIGHWIDE.C */
