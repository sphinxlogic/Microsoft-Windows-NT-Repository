/* VMS_SMG_FLUSH_DISPLAY_UPDATE.C -- 09-MAR-2000 Uwe Zessin
   Python interface to SMG$FLUSH_DISPLAY_UPDATE

19-AUG-2000 ZE. -- return |status|

--------------------
$ @ PYTHON_VMS:BLDRUN  VMS  VMS_SMG_FLUSH_DISPLAY_UPDATE

*/

#if defined(__DECC) || defined(__DECCXX)
#pragma module VMS_SMG_FLUSH_DISPLAY_UPDATE "20000819"
#endif

/* ------------------------------------------------------------------------- */

#include "vmsdef.h"		/* includes "Python.h" */

#include <smg$routines.h>	/* SMG$name  */
#include <smgmsg.h>		/* SMG$_name */
#include <ssdef.h>		/* SS$_name  */

/* ------------------------------------------------------------------------- */
/* smg$flush_display_update() is missing in DEC C version 5.0-003 */
#ifdef __DECC
#ifndef __DECC_VER      /* don't know if this is defined in all versions ... */
#define __DECC_VER 0
#endif /* __DECC_VER */
#if (__DECC_VER <= 50090003) /* @@ might need to change version */
#ifndef __unknown_params
#define __unknown_params ...
#endif
#pragma __nostandard      /* non-ANSI-Standard feature */
unsigned long smg$flush_display_update(__unknown_params);
#pragma __standard
#endif /* __DECC_VER <= 50090003 */
#endif /* __DECC */
/* ------------------------------------------------------------------------- */
extern PyObject *vms_smg_gr_error;		/* exception vms_smg.error */
/* ------------------------------------------------------------------------- */

char vms_smg_flush_display_upd__doc[] =
"None = vms_smg.flush_display_update (display_id)\n\
Flush Display Update.";

/* ------------------------------------------------------------------------- */

PyObject *
vms_smg_flush_display_update (PyObject *self, PyObject *args)
{
	unsigned long		  l_display_id;

	unsigned long		  l_status;

	/* -------------------- */
	if (!PyArg_ParseTuple(args, "i", &l_display_id))
	{
	    return NULL;
	}

	/* -------------------- */
	/* argument 1: display_id */

	/* -------------------- */
	l_status = smg$flush_display_update (&l_display_id);

	/* -------------------- */
	if ( (l_status == SS$_NORMAL) || (l_status == SMG$_BATWASOFF) )
	{
	    return Py_BuildValue ("i", l_status);
	}

	/* -------------------- */
	/* error */
	return PyVMS_ErrSetVal(vms_smg_gr_error, 1, l_status);
} /* vms_smg_flush_display_update () */

/* ------------------------------------------------------------------------- */

/* EOF: VMS_SMG_FLUSH_DISPLAY_UPDATE.C */
