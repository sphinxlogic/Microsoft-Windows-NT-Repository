/* VMS_SMG_READ_STRING.C -- 25-MAR-2000 Uwe Zessin
   Python interface to SMG$READ_STRING

06-SEP-2000 ZE. fix |ar_return = Py_BuildValue|

--------------------
$ @ PYTHON_VMS:BLDRUN  VMS  VMS_SMG_READ_STRING

*/

#if defined(__DECC) || defined(__DECCXX)
#pragma module VMS_SMG_READ_STRING "20000906"
#endif

/* ------------------------------------------------------------------------- */

#include "vmsdef.h"		/* includes "Python.h" */

#include <descrip.h>
#include <lib$routines.h>	/* LIB$name */
#include <smg$routines.h>	/* SMG$name */
#include <ssdef.h>		/* SS$_name */

/* ------------------------------------------------------------------------- */
extern PyObject *vms_smg_gr_error;		/* exception vms_smg.error */
/* ------------------------------------------------------------------------- */

char vms_smg_read_string__doc[] =
"status, resultant_string, terminator_code, terminator_string\
 = vms_smg.read_string\
 (keyboard_id, [prompt_string], [maximum_length], [modifiers], [timeout],\
 [terminator_set], [display_id], [initial_string],\
 [rendition_set], [rendition_complement])\n\
Read String.";

/* ------------------------------------------------------------------------- */

PyObject *
vms_smg_read_string (PyObject *self, PyObject *args)
{
	unsigned long		  l_keyboard_id;

	char			* at_prompt_string;
	struct dsc$descriptor_s   r_prompt_string;
	struct dsc$descriptor_s * ar_prompt_string;
	unsigned long		  l_prompt_string_len;

	PyObject		* ar_maximum_length;
	long			  l_maximum_length;
	long			* al_maximum_length;

	PyObject		* ar_modifiers;
	unsigned long		  l_modifiers;
	unsigned long		* al_modifiers;

	PyObject		* ar_timeout;
	long			  l_timeout;
	long			* al_timeout;

	PyObject		* ar_terminator_set;
	unsigned long		  l_terminator_set;
	unsigned long		  l_trmmsk_short[2];
	struct dsc$descriptor_s   r_terminator_set;
	void			* ax_terminator_set;

	PyObject		* ar_display_id;
	long			  l_display_id;
	long			* al_display_id;

	char			* at_initial_string;
	struct dsc$descriptor_s   r_initial_string;
	struct dsc$descriptor_s * ar_initial_string;
	unsigned long		  l_initial_string_len;

	PyObject		* ar_rendition_set;
	unsigned long		  l_rendition_set;
	unsigned long		* al_rendition_set;

	PyObject		* ar_rendition_complement;
	unsigned long		  l_rendition_complement;
	unsigned long		* al_rendition_complement;

	struct dsc$descriptor_s   r_resultant_string;
	unsigned short		  w_resultant_length;
	unsigned short		  w_terminator_code;
	struct dsc$descriptor_s   r_terminator_string;

	unsigned long		  l_status_smg;
	unsigned long		  l_status_free1;
	unsigned long		  l_status_free2;

	/* -------------------- */
	at_prompt_string        = NULL;    l_prompt_string_len = 0;
	ar_maximum_length       = Py_None;
	ar_modifiers            = Py_None;
	ar_timeout              = Py_None;
	ar_terminator_set       = Py_None;
	ar_display_id           = Py_None;
	at_initial_string       = NULL;    l_initial_string_len = 0;
	ar_rendition_set        = Py_None;
	ar_rendition_complement = Py_None;

	/* -------------------- */
	if (!PyArg_ParseTuple(args, "i|z#OOOOOz#OO"
	    ,&l_keyboard_id
	    ,&at_prompt_string       ,&l_prompt_string_len
	    ,&ar_maximum_length
	    ,&ar_modifiers
	    ,&ar_timeout
	    ,&ar_terminator_set
	    ,&ar_display_id
	    ,&at_initial_string       ,&l_initial_string_len
	    ,&ar_rendition_set
	    ,&ar_rendition_complement
	    ))
	{
	    return NULL;
	}

	/* -------------------- */
	/* argument 1: keyboard_id */

	/* -------------------- */
	/* argument 2: [prompt_string} */
	if (at_prompt_string == NULL)
	{
	    ar_prompt_string = 0;	/* omitted */
	}
	else
	{
	    if (l_prompt_string_len > 65535)
	    {
		PyErr_SetString(PyExc_ValueError,
       "argument 2: prompt_string - string size limited to 65535 characters");
		return NULL;
	    }
	    r_prompt_string.dsc$w_length  = l_prompt_string_len;
	    r_prompt_string.dsc$b_dtype   = DSC$K_DTYPE_T;
	    r_prompt_string.dsc$b_class   = DSC$K_CLASS_S;
	    r_prompt_string.dsc$a_pointer = at_prompt_string;
	    ar_prompt_string = &r_prompt_string;
	}

	/* -------------------- */
	/* argument 3: [maximum_length] */
	if (ar_maximum_length == Py_None)
	{
	    al_maximum_length = 0;		/* omitted */
	    l_maximum_length  = 0;
	}
	else
	{
	    if (!PyInt_Check(ar_maximum_length))
	    {
		PyErr_SetString(PyExc_TypeError,
		    "argument 3: maximum_length - must be integer or None");
		return NULL;
	    }
	    l_maximum_length = PyInt_AsLong(ar_maximum_length);
	    if (PyErr_Occurred())
	    {
		return NULL;
	    }
	    al_maximum_length = &l_maximum_length;
	}

	/* -------------------- */
	/* argument 4: [modifiers] */
	if (ar_modifiers == Py_None)
	{
	    al_modifiers = 0;		/* omitted */
	    l_modifiers  = 0;
	}
	else
	{
	    if (!PyInt_Check(ar_modifiers))
	    {
		PyErr_SetString(PyExc_TypeError,
		    "argument 4: modifiers - must be integer or None");
		return NULL;
	    }
	    l_modifiers = PyInt_AsLong(ar_modifiers);
	    if (PyErr_Occurred())
	    {
		return NULL;
	    }
	    al_modifiers = &l_modifiers;
	}

	/* -------------------- */
	/* argument 5: [timeout] */
	if (ar_timeout == Py_None)
	{
	    al_timeout = 0;		/* omitted */
	    l_timeout  = 0;
	}
	else
	{
	    if (!PyInt_Check(ar_timeout))
	    {
		PyErr_SetString(PyExc_TypeError,
		    "argument 5: timeout - must be integer or None");
		return NULL;
	    }
	    l_timeout = PyInt_AsLong(ar_timeout);
	    if (PyErr_Occurred())
	    {
		return NULL;
	    }
	    al_timeout = &l_timeout;
	}

	/* -------------------- */
	/* argument 6: [terminator_set] */
	if (ar_terminator_set == Py_None)
	{
	    ax_terminator_set = 0;		/* omitted */
	}
	else
	{
	    /* integer - short form terminator */
	    if (PyInt_Check(ar_terminator_set))
	    {
		l_terminator_set = PyInt_AsLong(ar_terminator_set);
		if (PyErr_Occurred())
		{
		    return NULL;
		}
		l_trmmsk_short[0] = 0;
		l_trmmsk_short[1] = l_terminator_set;
		ax_terminator_set = &l_trmmsk_short[0];
	    }
	    else
	    {
		/* string  - long form terminator  */
		if (!PyString_Check(ar_terminator_set))
		{
		    PyErr_SetString(PyExc_TypeError,
	      "argument 6: terminator_set - must be integer, string or None");
		    return NULL;
		}
		/* build long terminator mask */
		r_terminator_set.dsc$w_length  =
					PyString_Size(ar_terminator_set);
		r_terminator_set.dsc$b_dtype   = 0; /* not used */
		r_terminator_set.dsc$b_class   = 0; /* " */
		r_terminator_set.dsc$a_pointer =
					PyString_AS_STRING(ar_terminator_set);
		ax_terminator_set = &r_terminator_set;
	    }
	}

	/* -------------------- */
	/* argument 7: [display_id] */
	if (ar_display_id == Py_None)
	{
	    al_display_id = 0;		/* omitted */
	    l_display_id  = 0;
	}
	else
	{
	    if (!PyInt_Check(ar_display_id))
	    {
		PyErr_SetString(PyExc_TypeError,
		    "argument 7: display_id - must be integer or None");
		return NULL;
	    }
	    l_display_id = PyInt_AsLong(ar_display_id);
	    if (PyErr_Occurred())
	    {
		return NULL;
	    }
	    al_display_id = &l_display_id;
	}

	/* -------------------- */
	/* argument 8: [initial_string} */
	if (at_initial_string == NULL)
	{
	    ar_initial_string = 0;	/* omitted */
	}
	else
	{
	    if (l_initial_string_len > 65535)
	    {
		PyErr_SetString(PyExc_ValueError,
      "argument 8: initial_string - string size limited to 65535 characters");
		return NULL;
	    }
	    r_initial_string.dsc$w_length  = l_initial_string_len;
	    r_initial_string.dsc$b_dtype   = DSC$K_DTYPE_T;
	    r_initial_string.dsc$b_class   = DSC$K_CLASS_S;
	    r_initial_string.dsc$a_pointer = at_initial_string;
	    ar_initial_string = &r_initial_string;
	}

	/* -------------------- */
	/* argument 9: [rendition_set] */
	if (ar_rendition_set == Py_None)
	{
	    al_rendition_set = 0;		/* omitted */
	    l_rendition_set  = 0;
	}
	else
	{
	    if (!PyInt_Check(ar_rendition_set))
	    {
		PyErr_SetString(PyExc_TypeError,
		 "argument 9: rendition_set - must be integer or None");
		return NULL;
	    }
	    l_rendition_set = PyInt_AsLong(ar_rendition_set);
	    if (PyErr_Occurred())
	    {
		return NULL;
	    }
	    al_rendition_set = &l_rendition_set;
	}

	/* -------------------- */
	/* argument 10: [rendition_complement] */
	if (ar_rendition_complement == Py_None)
	{
	    al_rendition_complement = 0;		/* omitted */
	    l_rendition_complement  = 0;
	}
	else
	{
	    if (!PyInt_Check(ar_rendition_complement))
	    {
		PyErr_SetString(PyExc_TypeError,
	       "argument 10: rendition_complement - must be integer or None");
		return NULL;
	    }
	    l_rendition_complement = PyInt_AsLong(ar_rendition_complement);
	    if (PyErr_Occurred())
	    {
		return NULL;
	    }
	    al_rendition_complement = &l_rendition_complement;
	}

	/* -------------------- */
	/* set up string descriptor */
	/*  let SMG$READ_STRING allocate the memory */
	r_resultant_string.dsc$w_length  = 0;
	r_resultant_string.dsc$b_dtype   = DSC$K_DTYPE_T;
	r_resultant_string.dsc$b_class   = DSC$K_CLASS_D; /* not _S !! */
	r_resultant_string.dsc$a_pointer = 0;

	w_resultant_length = 0;
	w_terminator_code  = 0;

	r_terminator_string.dsc$w_length  = 0;
	r_terminator_string.dsc$b_dtype   = DSC$K_DTYPE_T;
	r_terminator_string.dsc$b_class   = DSC$K_CLASS_D; /* not _S !! */
	r_terminator_string.dsc$a_pointer = 0;

	/* -------------------- */
	l_status_smg = smg$read_string
		(&l_keyboard_id
		,&r_resultant_string
		,ar_prompt_string
		,al_maximum_length
		,al_modifiers
		,al_timeout
		,ax_terminator_set
		,&w_resultant_length
		,&w_terminator_code
		,al_display_id
		,ar_initial_string
		,al_rendition_set
		,al_rendition_complement
		,&r_terminator_string
		);

	/* -------------------- */
	{
	    PyObject	* ar_return;

	    ar_return = Py_BuildValue
		("is#is#"
		,l_status_smg

		,(r_resultant_string.dsc$w_length == 0)	/* empty string? */
		  ? (void*)&r_resultant_string		/* non-NULL address */
		  : (void*)r_resultant_string.dsc$a_pointer
		,(unsigned int)r_resultant_string.dsc$w_length

		,(unsigned int)w_terminator_code

		,(r_terminator_string.dsc$w_length == 0) /* empty string? */
		  ? (void*)&r_terminator_string		 /* non-NULL address */
		  : (void*)r_terminator_string.dsc$a_pointer
		,(unsigned int)r_terminator_string.dsc$w_length

		);

	    /* -------------------- */
	    /* deallocate memory of dynamic string descriptor */
	    l_status_free1 = lib$sfree1_dd (&r_resultant_string);
	    l_status_free2 = lib$sfree1_dd (&r_terminator_string);

	    if ((l_status_free1 != SS$_NORMAL) ||
		(l_status_free2 != SS$_NORMAL)   )
	    {
		PyErr_SetString(PyExc_SystemError,
		    "vms_smg_read_string: LIB$SFREE1_DD() failed");
		(void) PyErr_Print();

		Py_XDECREF(ar_return);

		/* -------------------- */
		if (l_status_free1 == SS$_NORMAL)
		{
		    l_status_free1 = l_status_free2;
		}
		/* -------------------- */
		/* error */
		return PyVMS_ErrSetVal(vms_smg_gr_error, 1, l_status_free1);
	    }

	    /* -------------------- */
	    return ar_return;
	}

} /* vms_smg_read_string () */

/* ------------------------------------------------------------------------- */

/* EOF: VMS_SMG_READ_STRING.C */
