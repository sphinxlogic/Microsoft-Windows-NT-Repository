/* VMS_SMG_INSERT_LINE.C -- 21-MAR-2000 Uwe Zessin
   Python interface to SMG$INSERT_LINE

20-AUG-2000 ZE. -- return |status|

--------------------
$ @ PYTHON_VMS:BLDRUN  VMS  VMS_SMG_INSERT_LINE

*/

#if defined(__DECC) || defined(__DECCXX)
#pragma module VMS_SMG_INSERT_LINE "20000820"
#endif

/* ------------------------------------------------------------------------- */

#include "vmsdef.h"		/* includes "Python.h" */

#include <descrip.h>
#include <smg$routines.h>	/* SMG$name  */
#include <smgmsg.h>		/* SMG$_name */
#include <ssdef.h>		/* SS$_name  */

/* ------------------------------------------------------------------------- */
extern PyObject *vms_smg_gr_error;		/* exception vms_smg.error */
/* ------------------------------------------------------------------------- */

char vms_smg_insert_line__doc[] =
"status = vms_smg.insert_line (display_id, start_row, [character_string],\
 direction, [rendition_set], [rendition_complement], [flags],\
 [character_set])\n\
Insert Line.";

/* ------------------------------------------------------------------------- */

PyObject *
vms_smg_insert_line (PyObject *self, PyObject *args)
{
	unsigned long		  l_display_id;

	long			  l_start_row;

	char			* at_character_string;
	struct dsc$descriptor_s   r_character_string;
	struct dsc$descriptor_s * ar_character_string;
	unsigned long		  l_character_string_len;

	PyObject		* ar_direction;
	unsigned long		  l_direction;
	unsigned long		* al_direction;

	PyObject		* ar_rendition_set;
	unsigned long		  l_rendition_set;
	unsigned long		* al_rendition_set;

	PyObject		* ar_rendition_complement;
	unsigned long		  l_rendition_complement;
	unsigned long		* al_rendition_complement;

	PyObject		* ar_flags;
	unsigned long		  l_flags;
	unsigned long		* al_flags;

	PyObject		* ar_character_set;
	long			  l_character_set;
	long			* al_character_set;

	unsigned long		  l_status;

	/* -------------------- */
	at_character_string     = NULL;    l_character_string_len = 0;
	ar_direction            = Py_None;
	ar_rendition_set        = Py_None;
	ar_rendition_complement = Py_None;
	ar_flags                = Py_None;
	ar_character_set        = Py_None;

	/* -------------------- */
	if (!PyArg_ParseTuple(args, "ii|z#OOOOO"
	    ,&l_display_id
	    ,&l_start_row
	    ,&at_character_string    ,&l_character_string_len
	    ,&ar_direction
	    ,&ar_rendition_set
	    ,&ar_rendition_complement
	    ,&ar_flags
	    ,&ar_character_set
	    ))
	{
	    return NULL;
	}

	/* -------------------- */
	/* argument 1: display_id */

	/* -------------------- */
	/* argument 2: start_row */

	/* -------------------- */
	/* argument 3: character_string */
	if (at_character_string == NULL)
	{
	    ar_character_string = 0;	/* omitted */
	}
	else
	{
	    if (l_character_string_len > 65535)
	    {
		PyErr_SetString(PyExc_ValueError,
     "argument 3: character_string - string size limited to 65535 characters");
		return NULL;
	    }
	    r_character_string.dsc$w_length  = l_character_string_len;
	    r_character_string.dsc$b_dtype   = DSC$K_DTYPE_T;
	    r_character_string.dsc$b_class   = DSC$K_CLASS_S;
	    r_character_string.dsc$a_pointer = at_character_string;
	    ar_character_string = &r_character_string;
	}

	/* -------------------- */
	/* argument 4: [direction] */
	if (ar_direction == Py_None)
	{
	    al_direction = 0;		/* omitted */
	    l_direction  = 0;
	}
	else
	{
	    if (!PyInt_Check(ar_direction))
	    {
		PyErr_SetString(PyExc_TypeError,
		    "argument 4: direction - must be integer or None");
		return NULL;
	    }
	    l_direction = PyInt_AsLong(ar_direction);
	    if (PyErr_Occurred())
	    {
		return NULL;
	    }
	    al_direction = &l_direction;
	}

	/* -------------------- */
	/* argument 5: [rendition_set] */
	if (ar_rendition_set == Py_None)
	{
	    al_rendition_set = 0;		/* omitted */
	    l_rendition_set  = 0;
	}
	else
	{
	    if (!PyInt_Check(ar_rendition_set))
	    {
		PyErr_SetString(PyExc_TypeError,
		    "argument 5: rendition_set - must be integer or None");
		return NULL;
	    }
	    l_rendition_set = PyInt_AsLong(ar_rendition_set);
	    if (PyErr_Occurred())
	    {
		return NULL;
	    }
	    al_rendition_set = &l_rendition_set;
	}

	/* -------------------- */
	/* argument 6: [rendition_complement] */
	if (ar_rendition_complement == Py_None)
	{
	    al_rendition_complement = 0;		/* omitted */
	    l_rendition_complement  = 0;
	}
	else
	{
	    if (!PyInt_Check(ar_rendition_complement))
	    {
		PyErr_SetString(PyExc_TypeError,
		 "argument 6: rendition_complement - must be integer or None");
		return NULL;
	    }
	    l_rendition_complement = PyInt_AsLong(ar_rendition_complement);
	    if (PyErr_Occurred())
	    {
		return NULL;
	    }
	    al_rendition_complement = &l_rendition_complement;
	}

	/* -------------------- */
	/* argument 7: [flags] */
	if (ar_flags == Py_None)
	{
	    al_flags = 0;		/* omitted */
	    l_flags  = 0;
	}
	else
	{
	    if (!PyInt_Check(ar_flags))
	    {
		PyErr_SetString(PyExc_TypeError,
		    "argument 7: flags - must be integer or None");
		return NULL;
	    }
	    l_flags = PyInt_AsLong(ar_flags);
	    if (PyErr_Occurred())
	    {
		return NULL;
	    }
	    al_flags = &l_flags;
	}

	/* -------------------- */
	/* argument 8: [character_set] */
	if (ar_character_set == Py_None)
	{
	    al_character_set = 0;		/* omitted */
	    l_character_set  = 0;
	}
	else
	{
	    if (!PyInt_Check(ar_character_set))
	    {
		PyErr_SetString(PyExc_TypeError,
		 "argument 8: character_set - must be integer or None");
		return NULL;
	    }
	    l_character_set = PyInt_AsLong(ar_character_set);
	    if (PyErr_Occurred())
	    {
		return NULL;
	    }
	    al_character_set = &l_character_set;
	}

	/* -------------------- */
	l_status = smg$insert_line
		(&l_display_id
		,&l_start_row
		,ar_character_string
		,al_direction
		,al_rendition_set
		,al_rendition_complement
		,al_flags
		,al_character_set
		);

	/* -------------------- */
	if ((l_status == SS$_NORMAL) || (l_status == SMG$_WILUSERMS))
	{
	    return Py_BuildValue ("i", l_status);
	}

	/* -------------------- */
	/* error */
	return PyVMS_ErrSetVal(vms_smg_gr_error, 1, l_status);
} /* vms_smg_insert_line () */

/* ------------------------------------------------------------------------- */

/* EOF: VMS_SMG_INSERT_LINE.C */
