/* VMS_SMG_MOVE_TEXT.C -- 22-MAR-2000 Uwe Zessin
   Python interface to SMG$MOVE_TEXT

21-AUG-2000 ZE. -- fix PyArg_ParseTuple() arguments

--------------------
$ @ PYTHON_VMS:BLDRUN  VMS  VMS_SMG_MOVE_TEXT

*/

#if defined(__DECC) || defined(__DECCXX)
#pragma module VMS_SMG_MOVE_TEXT "20000821"
#endif

/* ------------------------------------------------------------------------- */

#include "vmsdef.h"		/* includes "Python.h" */

#include <descrip.h>
#include <smg$routines.h>	/* SMG$name  */
#include <ssdef.h>		/* SS$_name  */

/* ------------------------------------------------------------------------- */
extern PyObject *vms_smg_gr_error;		/* exception vms_smg.error */
/* ------------------------------------------------------------------------- */

char vms_smg_move_text__doc[] =
"None = vms_smg.move_text (display_id, top_left_row, top_left_column,\
 bottom_right_row, bottom_right_column,\
 display_id2, [top_left_row2], [top_left_column2], [flags])\n\
Move Text from One Virtual Display to Another.";

/* ------------------------------------------------------------------------- */

PyObject *
vms_smg_move_text (PyObject *self, PyObject *args)
{
	unsigned long		  l_display_id;

	unsigned long		  l_top_left_row;
	unsigned long		  l_top_left_column;
	unsigned long		  l_bottom_right_row;
	unsigned long		  l_bottom_right_column;
	unsigned long		  l_display_id2;

	PyObject		* ar_top_left_row2;
	unsigned long		  l_top_left_row2;
	unsigned long		* al_top_left_row2;

	PyObject		* ar_top_left_column2;
	unsigned long		  l_top_left_column2;
	unsigned long		* al_top_left_column2;

	PyObject		* ar_flags;
	unsigned long		  l_flags;
	unsigned long		* al_flags;

	unsigned long		  l_status;

	/* -------------------- */
	ar_top_left_row2    = Py_None;
	ar_top_left_column2 = Py_None;
	ar_flags            = Py_None;

	/* -------------------- */
	if (!PyArg_ParseTuple(args, "iiiiii|OOO"
	    ,&l_display_id
	    ,&l_top_left_row
	    ,&l_top_left_column
	    ,&l_bottom_right_row
	    ,&l_bottom_right_column
	    ,&l_display_id2
	    ,&ar_top_left_row2
	    ,&ar_top_left_column2
	    ,&ar_flags
	    ))
	{
	    return NULL;
	}

	/* -------------------- */
	/* argument 1: display_id */

	/* -------------------- */
	/* argument 2: top_left_row */

	/* -------------------- */
	/* argument 3: top_left_column */

	/* -------------------- */
	/* argument 4: bottom_right_row */

	/* -------------------- */
	/* argument 5: bottom_right_column */

	/* -------------------- */
	/* argument 6: display_id2 */

	/* -------------------- */
	/* argument 7: [top_left_row2] */
	if (ar_top_left_row2 == Py_None)
	{
	    al_top_left_row2 = 0;		/* omitted */
	    l_top_left_row2  = 0;
	}
	else
	{
	    if (!PyInt_Check(ar_top_left_row2))
	    {
		PyErr_SetString(PyExc_TypeError,
		    "argument 7: top_left_row2 - must be integer or None");
		return NULL;
	    }
	    l_top_left_row2 = PyInt_AsLong(ar_top_left_row2);
	    if (PyErr_Occurred())
	    {
		return NULL;
	    }
	    al_top_left_row2 = &l_top_left_row2;
	}

	/* -------------------- */
	/* argument 8: [top_left_column2] */
	if (ar_top_left_column2 == Py_None)
	{
	    al_top_left_column2 = 0;		/* omitted */
	    l_top_left_column2  = 0;
	}
	else
	{
	    if (!PyInt_Check(ar_top_left_column2))
	    {
		PyErr_SetString(PyExc_TypeError,
		    "argument 8: top_left_column2 - must be integer or None");
		return NULL;
	    }
	    l_top_left_column2 = PyInt_AsLong(ar_top_left_column2);
	    if (PyErr_Occurred())
	    {
		return NULL;
	    }
	    al_top_left_column2 = &l_top_left_column2;
	}

	/* -------------------- */
	/* argument 9: [flags] */
	if (ar_flags == Py_None)
	{
	    al_flags = 0;		/* omitted */
	    l_flags  = 0;
	}
	else
	{
	    if (!PyInt_Check(ar_flags))
	    {
		PyErr_SetString(PyExc_TypeError,
		    "argument 9: flags - must be integer or None");
		return NULL;
	    }
	    l_flags = PyInt_AsLong(ar_flags);
	    if (PyErr_Occurred())
	    {
		return NULL;
	    }
	    al_flags = &l_flags;
	}

	/* -------------------- */
	l_status = smg$move_text
		(&l_display_id
		,&l_top_left_row
		,&l_top_left_column
		,&l_bottom_right_row
		,&l_bottom_right_column
		,&l_display_id2
		,al_top_left_row2
		,al_top_left_column2
		,al_flags
		);

	/* -------------------- */
	if (l_status == SS$_NORMAL)
	{
	    Py_INCREF(Py_None);
	    return (Py_None);
	}

	/* -------------------- */
	/* error */
	return PyVMS_ErrSetVal(vms_smg_gr_error, 1, l_status);
} /* vms_smg_move_text () */

/* ------------------------------------------------------------------------- */

/* EOF: VMS_SMG_MOVE_TEXT.C */
