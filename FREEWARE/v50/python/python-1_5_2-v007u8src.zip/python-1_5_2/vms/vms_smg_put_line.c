/* VMS_SMG_PUT_LINE.C -- 25-MAR-2000 Uwe Zessin
   Python interface to SMG$PUT_LINE

23-AUG-2000 ZE. -- return |status|

--------------------
$ @ PYTHON_VMS:BLDRUN  VMS  VMS_SMG_PUT_LINE

*/

#if defined(__DECC) || defined(__DECCXX)
#pragma module VMS_SMG_PUT_LINE "20000823"
#endif

/* ------------------------------------------------------------------------- */

#include "vmsdef.h"		/* includes "Python.h" */

#include <descrip.h>
#include <smg$routines.h>	/* SMG$name  */
#include <smgmsg.h>		/* SMG$_name */
#include <ssdef.h>		/* SS$_name  */

/* ------------------------------------------------------------------------- */
extern PyObject *vms_smg_gr_error;		/* exception vms_smg.error */
/* ------------------------------------------------------------------------- */

char vms_smg_put_line__doc[] =
"status = vms_smg.put_line (display_id, text, [line_advance], [rendition_set],\
 [rendition_complement], [flags], [character_set], [direction])\n\
Write Line to Virtual Display.";

/* ------------------------------------------------------------------------- */

PyObject *
vms_smg_put_line (PyObject *self, PyObject *args)
{
	unsigned long		  l_display_id;

	char			* at_text;
	struct dsc$descriptor_s   r_text;
	unsigned long		  l_text_len;

	PyObject		* ar_line_advance;
	long			  l_line_advance;
	long			* al_line_advance;

	PyObject		* ar_rendition_set;
	unsigned long		  l_rendition_set;
	unsigned long		* al_rendition_set;

	PyObject		* ar_rendition_complement;
	unsigned long		  l_rendition_complement;
	unsigned long		* al_rendition_complement;

	PyObject		* ar_flags;
	unsigned long		  l_flags;
	unsigned long		* al_flags;

	PyObject		* ar_character_set;
	unsigned long		  l_character_set;
	unsigned long		* al_character_set;

	PyObject		* ar_direction;
	unsigned long		  l_direction;
	unsigned long		* al_direction;

	unsigned long		  l_status;

	/* -------------------- */
	ar_line_advance         = Py_None;
	ar_rendition_set        = Py_None;
	ar_rendition_complement = Py_None;
	ar_flags                = Py_None;
	ar_character_set        = Py_None;
	ar_direction            = Py_None;

	/* -------------------- */
	if (!PyArg_ParseTuple(args, "is#|OOOOOO"
	    ,&l_display_id
	    ,&at_text                 ,&l_text_len
	    ,&ar_line_advance
	    ,&ar_rendition_set
	    ,&ar_rendition_complement
	    ,&ar_flags
	    ,&ar_character_set
	    ,&ar_direction
	    ))
	{
	    return NULL;
	}

	/* -------------------- */
	/* argument 1: display_id */

	/* -------------------- */
	/* argument 2: text */
	if (l_text_len > 65535)
	{
	    PyErr_SetString(PyExc_ValueError,
		"argument 2: text - string size limited to 65535 characters");
	    return NULL;
	}
	r_text.dsc$w_length  = l_text_len;
	r_text.dsc$b_dtype   = DSC$K_DTYPE_T;
	r_text.dsc$b_class   = DSC$K_CLASS_S;
	r_text.dsc$a_pointer = at_text;

	/* -------------------- */
	/* argument 3: [line_advance] */
	if (ar_line_advance == Py_None)
	{
	    al_line_advance = 0;		/* omitted */
	    l_line_advance  = 0;
	}
	else
	{
	    if (!PyInt_Check(ar_line_advance))
	    {
		PyErr_SetString(PyExc_TypeError,
		    "argument 3: line_advance - must be integer or None");
		return NULL;
	    }
	    l_line_advance = PyInt_AsLong(ar_line_advance);
	    if (PyErr_Occurred())
	    {
		return NULL;
	    }
	    al_line_advance = &l_line_advance;
	}

	/* -------------------- */
	/* argument 4: [rendition_set] */
	if (ar_rendition_set == Py_None)
	{
	    al_rendition_set = 0;		/* omitted */
	    l_rendition_set  = 0;
	}
	else
	{
	    if (!PyInt_Check(ar_rendition_set))
	    {
		PyErr_SetString(PyExc_TypeError,
		    "argument 4: rendition_set - must be integer or None");
		return NULL;
	    }
	    l_rendition_set = PyInt_AsLong(ar_rendition_set);
	    if (PyErr_Occurred())
	    {
		return NULL;
	    }
	    al_rendition_set = &l_rendition_set;
	}

	/* -------------------- */
	/* argument 5: [rendition_complement] */
	if (ar_rendition_complement == Py_None)
	{
	    al_rendition_complement = 0;		/* omitted */
	    l_rendition_complement  = 0;
	}
	else
	{
	    if (!PyInt_Check(ar_rendition_complement))
	    {
		PyErr_SetString(PyExc_TypeError,
		 "argument 5: rendition_complement - must be integer or None");
		return NULL;
	    }
	    l_rendition_complement = PyInt_AsLong(ar_rendition_complement);
	    if (PyErr_Occurred())
	    {
		return NULL;
	    }
	    al_rendition_complement = &l_rendition_complement;
	}

	/* -------------------- */
	/* argument 6: [flags] */
	if (ar_flags == Py_None)
	{
	    al_flags = 0;		/* omitted */
	    l_flags  = 0;
	}
	else
	{
	    if (!PyInt_Check(ar_flags))
	    {
		PyErr_SetString(PyExc_TypeError,
		    "argument 6: flags - must be integer or None");
		return NULL;
	    }
	    l_flags = PyInt_AsLong(ar_flags);
	    if (PyErr_Occurred())
	    {
		return NULL;
	    }
	    al_flags = &l_flags;
	}

	/* -------------------- */
	/* argument 7: [character_set] */
	if (ar_character_set == Py_None)
	{
	    al_character_set = 0;		/* omitted */
	    l_character_set  = 0;
	}
	else
	{
	    if (!PyInt_Check(ar_character_set))
	    {
		PyErr_SetString(PyExc_TypeError,
		    "argument 7: character_set - must be integer or None");
		return NULL;
	    }
	    l_character_set = PyInt_AsLong(ar_character_set);
	    if (PyErr_Occurred())
	    {
		return NULL;
	    }
	    al_character_set = &l_character_set;
	}

	/* -------------------- */
	/* argument 8: [direction] */
	if (ar_direction == Py_None)
	{
	    al_direction = 0;		/* omitted */
	    l_direction  = 0;
	}
	else
	{
	    if (!PyInt_Check(ar_direction))
	    {
		PyErr_SetString(PyExc_TypeError,
		    "argument 8: direction - must be integer or None");
		return NULL;
	    }
	    l_direction = PyInt_AsLong(ar_direction);
	    if (PyErr_Occurred())
	    {
		return NULL;
	    }
	    al_direction = &l_direction;
	}

	/* -------------------- */
	l_status = smg$put_line
		(&l_display_id
		,&r_text
		,al_line_advance
		,al_rendition_set
		,al_rendition_complement
		,al_flags
		,al_character_set
		,al_direction
		);

	/* -------------------- */
	if ((l_status == SS$_NORMAL) || (l_status == SMG$_WILUSERMS))
	{
	    return Py_BuildValue ("i", l_status);
	}

	/* -------------------- */
	/* error */
	return PyVMS_ErrSetVal(vms_smg_gr_error, 1, l_status);
} /* vms_smg_put_line () */

/* ------------------------------------------------------------------------- */

/* EOF: VMS_SMG_PUT_LINE.C */
