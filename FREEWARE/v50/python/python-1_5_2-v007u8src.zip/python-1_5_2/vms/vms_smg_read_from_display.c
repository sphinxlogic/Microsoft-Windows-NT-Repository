/* VMS_SMG_READ_FROM_DISPLAY.C -- 25-MAR-2000 Uwe Zessin
   Python interface to SMG$READ_FROM_DISPLAY

28-AUG-2000 ZE. -- bugfix

--------------------
$ @ PYTHON_VMS:BLDRUN  VMS  VMS_SMG_READ_FROM_DISPLAY

*/

#if defined(__DECC) || defined(__DECCXX)
#pragma module VMS_SMG_READ_FROM_DISPLAY "20000828"
#endif

/* ------------------------------------------------------------------------- */

#include "vmsdef.h"		/* includes "Python.h" */

#include <descrip.h>
#include <lib$routines.h>	/* LIB$name */
#include <smg$routines.h>	/* SMG$name */
#include <ssdef.h>		/* SS$_name */

/* ------------------------------------------------------------------------- */
extern PyObject *vms_smg_gr_error;		/* exception vms_smg.error */
/* ------------------------------------------------------------------------- */

char vms_smg_read_from_display__doc[] =
"status, resultant_string, rendition_string = vms_smg.read_from_display\
 (display_id, [terminator_string], [start_row])\n\
Read Text from Display.";

/* ------------------------------------------------------------------------- */

PyObject *
vms_smg_read_from_display (PyObject *self, PyObject *args)
{
	unsigned long		  l_display_id;

	char			* at_terminator_string;
	struct dsc$descriptor_s   r_terminator_string;
	struct dsc$descriptor_s * ar_terminator_string;
	unsigned long		  l_terminator_string_len;

	PyObject		* ar_start_row;
	unsigned long		  l_start_row;
	unsigned long		* al_start_row;

	struct dsc$descriptor_s   r_resultant_string;

	struct dsc$descriptor_s   r_rendition_string;

	unsigned long		  l_status_smg;
	unsigned long		  l_status_free1;
	unsigned long		  l_status_free2;

	PyObject	* ar_return;

	/* -------------------- */
	at_terminator_string = NULL;    l_terminator_string_len = 0;
	ar_start_row         = Py_None;

	/* -------------------- */
	if (!PyArg_ParseTuple(args, "i|z#O"
	    ,&l_display_id
	    ,&at_terminator_string ,&l_terminator_string_len
	    ,&ar_start_row
	    ))
	{
	    return NULL;
	}

	/* -------------------- */
	/* argument 1: display_id */

	/* -------------------- */
	/* argument 2: [terminator_string} */
	if (at_terminator_string == NULL)
	{
	    ar_terminator_string = 0;	/* omitted */
	}
	else
	{
	    if (l_terminator_string_len > 65535)
	    {
		PyErr_SetString(PyExc_ValueError,
   "argument 2: terminator_string - string size limited to 65535 characters");
		return NULL;
	    }
	    r_terminator_string.dsc$w_length  = l_terminator_string_len;
	    r_terminator_string.dsc$b_dtype   = DSC$K_DTYPE_T;
	    r_terminator_string.dsc$b_class   = DSC$K_CLASS_S;
	    r_terminator_string.dsc$a_pointer = at_terminator_string;
	    ar_terminator_string = &r_terminator_string;
	}

	/* -------------------- */
	/* argument 3: [start_row] */
	if (ar_start_row == Py_None)
	{
	    al_start_row = 0;		/* omitted */
	    l_start_row  = 0;
	}
	else
	{
	    if (!PyInt_Check(ar_start_row))
	    {
		PyErr_SetString(PyExc_TypeError,
		    "argument 3: start_row - must be integer or None");
		return NULL;
	    }
	    l_start_row = PyInt_AsLong(ar_start_row);
	    if (PyErr_Occurred())
	    {
		return NULL;
	    }
	    al_start_row = &l_start_row;
	}

	/* -------------------- */
	/* set up string descriptor */
	/*  let SMG$READ_FROM_DISPLAY allocate the memory */
	r_resultant_string.dsc$w_length  = 0;
	r_resultant_string.dsc$b_dtype   = DSC$K_DTYPE_T;
	r_resultant_string.dsc$b_class   = DSC$K_CLASS_D; /* not _S !! */
	r_resultant_string.dsc$a_pointer = 0;

	/* -------------------- */
	/* set up string descriptor */
	/*  let SMG$READ_FROM_DISPLAY allocate the memory */
	r_rendition_string.dsc$w_length  = 0;
	r_rendition_string.dsc$b_dtype   = DSC$K_DTYPE_T;
	r_rendition_string.dsc$b_class   = DSC$K_CLASS_D; /* not _S !! */
	r_rendition_string.dsc$a_pointer = 0;

	/* -------------------- */
	l_status_smg = smg$read_from_display
		(&l_display_id
		,&r_resultant_string
		,ar_terminator_string
		,al_start_row
		,&r_rendition_string
		);

	/* -------------------- */
	ar_return = Py_BuildValue
		("is#s#"
		/* <i> */
		,l_status_smg
		/* <s#> */
		,(r_resultant_string.dsc$w_length == 0)	/* empty string? */
		  ? (void*)&r_resultant_string		/* non-NULL address */
		  : (void*)r_resultant_string.dsc$a_pointer
		,(unsigned int)r_resultant_string.dsc$w_length
		/* <s#> */
		,(r_rendition_string.dsc$w_length == 0)	/* empty string? */
		  ? (void*)&r_rendition_string		/* non-NULL address */
		  : (void*)r_rendition_string.dsc$a_pointer
		,(unsigned int)r_rendition_string.dsc$w_length

		);

	/* -------------------- */
	/* deallocate memory of dynamic string descriptor */
	l_status_free1 = lib$sfree1_dd (&r_resultant_string);
	if (l_status_free1 != SS$_NORMAL)
	{
		PyErr_SetString(PyExc_SystemError,
	"vms_smg_read_from_display: LIB$SFREE1_DD(r_resultant_string) failed");
		(void) PyErr_Print();

		Py_XDECREF(ar_return);
		ar_return = NULL;
	}

	/* -------------------- */
	/* deallocate memory of dynamic string descriptor */
	l_status_free2 = lib$sfree1_dd (&r_rendition_string);
	if (l_status_free2 != SS$_NORMAL)
	{
		PyErr_SetString(PyExc_SystemError,
	"vms_smg_read_from_display: LIB$SFREE1_DD(r_rendition_string) failed");
		(void) PyErr_Print();

		Py_XDECREF(ar_return);
		ar_return = NULL;
	}

	/* -------------------- */
	if (l_status_free1 == SS$_NORMAL)
	{
		l_status_free1 = l_status_free2;	/* copy error */
	}

	if (l_status_free1 != SS$_NORMAL)
	{
		/* error during LIB$SFREE1_DD() */
		return PyVMS_ErrSetVal(vms_smg_gr_error, 1, l_status_free1);
	}

	/* -------------------- */
	return ar_return;

} /* vms_smg_read_from_display () */

/* ------------------------------------------------------------------------- */

/* EOF: VMS_SMG_READ_FROM_DISPLAY.C */
