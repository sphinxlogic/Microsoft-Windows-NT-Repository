/* VMS_SMG_PRINT_PASTEBOARD.C -- 25-MAR-2000 Uwe Zessin
   Python interface to SMG$PRINT_PASTEBOARD

01-SEP-2000 ZE. -- small fix to doc-string

--------------------
$ @ PYTHON_VMS:BLDRUN  VMS  VMS_SMG_PRINT_PASTEBOARD

*/

#if defined(__DECC) || defined(__DECCXX)
#pragma module VMS_SMG_PRINT_PASTEBOARD "20000901"
#endif

/* ------------------------------------------------------------------------- */

#include "vmsdef.h"		/* includes "Python.h" */

#include <descrip.h>
#include <smg$routines.h>	/* SMG$name */
#include <ssdef.h>		/* SS$_name */

/* ------------------------------------------------------------------------- */
extern PyObject *vms_smg_gr_error;		/* exception vms_smg.error */
/* ------------------------------------------------------------------------- */

char vms_smg_print_pasteboard__doc[] =
"None = vms_smg.print_pasteboard\
 (pasteboard_id, [queue_name], [copies], [form_name])\n\
Print Pasteboard Using a Print Queue.";

/* ------------------------------------------------------------------------- */

PyObject *
vms_smg_print_pasteboard (PyObject *self, PyObject *args)
{
	unsigned long		  l_pasteboard_id;

	char			* at_queue_name;
	struct dsc$descriptor_s   r_queue_name;
	struct dsc$descriptor_s * ar_queue_name;
	unsigned long		  l_queue_name_len;

	PyObject		* ar_copies;
	long			  l_copies;
	long			* al_copies;

	char			* at_form_name;
	struct dsc$descriptor_s   r_form_name;
	struct dsc$descriptor_s * ar_form_name;
	unsigned long		  l_form_name_len;

	unsigned long		  l_status;

	/* -------------------- */
	at_queue_name = NULL;    l_queue_name_len = 0;
	ar_copies     = Py_None;
	at_form_name  = NULL;    l_form_name_len = 0;

	/* -------------------- */
	if (!PyArg_ParseTuple(args, "i|z#Oz#"
	    ,&l_pasteboard_id
	    ,&at_queue_name   ,&l_queue_name_len
	    ,&ar_copies
	    ,&at_form_name    ,&l_form_name_len
	    ))
	{
	    return NULL;
	}

	/* -------------------- */
	/* argument 1: pasteboard_id */

	/* -------------------- */
	/* argument 2: [queue_name] */
	if (at_queue_name == NULL)
	{
	    ar_queue_name = 0;	/* omitted */
	}
	else
	{
	    if (l_queue_name_len > 65535)
	    {
		PyErr_SetString(PyExc_ValueError,
	   "argument 2: queue_name - string size limited to 65535 characters");
		return NULL;
	    }
	    r_queue_name.dsc$w_length  = l_queue_name_len;
	    r_queue_name.dsc$b_dtype   = DSC$K_DTYPE_T;
	    r_queue_name.dsc$b_class   = DSC$K_CLASS_S;
	    r_queue_name.dsc$a_pointer = at_queue_name;
	    ar_queue_name = &r_queue_name;
	}

	/* -------------------- */
	/* argument 3: [copies] */
	if (ar_copies == Py_None)
	{
	    al_copies = 0;		/* omitted */
	    l_copies  = 0;
	}
	else
	{
	    if (!PyInt_Check(ar_copies))
	    {
		PyErr_SetString(PyExc_TypeError,
		    "argument 3: copies - must be integer or None");
		return NULL;
	    }
	    l_copies = PyInt_AsLong(ar_copies);
	    if (PyErr_Occurred())
	    {
		return NULL;
	    }
	    al_copies = &l_copies;
	}

	/* -------------------- */
	/* argument 4: [form_name] */
	if (at_form_name == NULL)
	{
	    ar_form_name = 0;	/* omitted */
	}
	else
	{
	    if (l_form_name_len > 65535)
	    {
		PyErr_SetString(PyExc_ValueError,
	    "argument 4: form_name - string size limited to 65535 characters");
		return NULL;
	    }
	    r_form_name.dsc$w_length  = l_form_name_len;
	    r_form_name.dsc$b_dtype   = DSC$K_DTYPE_T;
	    r_form_name.dsc$b_class   = DSC$K_CLASS_S;
	    r_form_name.dsc$a_pointer = at_form_name;
	    ar_form_name = &r_form_name;
	}

	/* -------------------- */
	l_status = smg$print_pasteboard
		(&l_pasteboard_id
		,ar_queue_name
		,al_copies
		,ar_form_name
		);

	/* -------------------- */
	if (l_status == SS$_NORMAL)
	{
	    Py_INCREF(Py_None);
	    return (Py_None);
	}

	/* -------------------- */
	/* error */
	return PyVMS_ErrSetVal(vms_smg_gr_error, 1, l_status);
} /* vms_smg_print_pasteboard () */

/* ------------------------------------------------------------------------- */

/* EOF: VMS_SMG_PRINT_PASTEBOARD.C */
