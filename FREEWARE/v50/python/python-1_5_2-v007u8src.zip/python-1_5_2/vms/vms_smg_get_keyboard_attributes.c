/* VMS_SMG_GET_KEYBOARD_ATTRIBUTES.C -- 20-MAR-2000 Uwe Zessin
   Python interface to SMG$GET_KEYBOARD_ATTRIBUTES

04-SEP-2000 ZE. -- fix KIT size

--------------------
$ @ PYTHON_VMS:BLDRUN  VMS  VMS_SMG_GET_KEYBOARD_ATTRIBUTES

*/

#if defined(__DECC) || defined(__DECCXX)
#pragma module VMS_SMG_GET_KEYBOARD_ATTRIBUTES "20000904"
#endif

/* ------------------------------------------------------------------------- */

#include "vmsdef.h"		/* includes "Python.h" */

#include <smg$routines.h>	/* SMG$name  */
#include <smgdef.h>		/* SMG$_name */
#include <ssdef.h>		/* SS$_name  */

/* ------------------------------------------------------------------------- */
extern PyObject *vms_smg_gr_error;		/* exception vms_smg.error */
/* ------------------------------------------------------------------------- */

char vms_smg_get_keyboard_attr__doc[] =
"keyboard_info_table = vms_smg.get_keyboard_attributes (keyboard_id)\n\
Get Keyboard Attributes.";

/* ------------------------------------------------------------------------- */

PyObject *
vms_smg_get_keyboard_attributes (PyObject *self, PyObject *args)
{
	unsigned long		  l_keyboard_id;

	struct smg$r_attribute_info_block r_kbd_info;

	unsigned long		  l_kbd_info_len;
				  /* SMG$C_ATTRIBUTE_INFO_BLOCK */

	unsigned long		  l_status;

	/* -------------------- */
	if (!PyArg_ParseTuple(args, "i", &l_keyboard_id))
	{
	    return NULL;
	}

	/* -------------------- */
	/* argument 1: keyboard_id */

	/* -------------------- */
	l_kbd_info_len = SMG$C_KEYBOARD_INFO_BLOCK;

	/* -------------------- */
	l_status = smg$get_keyboard_attributes
		(&l_keyboard_id
		,&r_kbd_info
		,&l_kbd_info_len
		);

	/* -------------------- */
	if (l_status == SS$_NORMAL)
	{
	    /* create dictionary */
	    PyObject		  * ar_dict;	/* dictionary to be returned */
	    PyObject		  * ar_dictobj;	/* temp. for insert into " */

	    ar_dict = PyDict_New();
	    if (ar_dict == NULL)
	    {
		return NULL;
	    }

	    /* ---------- */
	    ar_dictobj = PyInt_FromLong((unsigned int)r_kbd_info.smg$l_dev_char);
	    if (ar_dictobj == NULL)
	    {
		Py_DECREF(ar_dict);
		return NULL;
	    }
	    if (PyDict_SetItemString(ar_dict, "L_DEV_CHAR", ar_dictobj) < 0)
	    {
		Py_DECREF(ar_dict);
		return NULL;
	    }
	    Py_DECREF(ar_dictobj);

	    /* ---------- */
	    ar_dictobj = PyInt_FromLong((unsigned int)r_kbd_info.smg$l_dev_depend);
	    if (ar_dictobj == NULL)
	    {
		Py_DECREF(ar_dict);
		return NULL;
	    }
	    if (PyDict_SetItemString(ar_dict, "L_DEV_DEPEND", ar_dictobj) < 0)
	    {
		Py_DECREF(ar_dict);
		return NULL;
	    }
	    Py_DECREF(ar_dictobj);

	    /* ---------- */
	    ar_dictobj = PyInt_FromLong((unsigned int)r_kbd_info.smg$l_dev_depend2);
	    if (ar_dictobj == NULL)
	    {
		Py_DECREF(ar_dict);
		return NULL;
	    }
	    if (PyDict_SetItemString(ar_dict, "L_DEV_DEPEND2", ar_dictobj) < 0)
	    {
		Py_DECREF(ar_dict);
		return NULL;
	    }
	    Py_DECREF(ar_dictobj);

	    /* ---------- */
	    ar_dictobj = PyInt_FromLong((unsigned int)r_kbd_info.smg$b_dev_class);
	    if (ar_dictobj == NULL)
	    {
		Py_DECREF(ar_dict);
		return NULL;
	    }
	    if (PyDict_SetItemString(ar_dict, "B_DEV_CLASS", ar_dictobj) < 0)
	    {
		Py_DECREF(ar_dict);
		return NULL;
	    }
	    Py_DECREF(ar_dictobj);

	    /* ---------- */
	    ar_dictobj = PyInt_FromLong((unsigned int)r_kbd_info.smg$b_recall_num);
	    if (ar_dictobj == NULL)
	    {
		Py_DECREF(ar_dict);
		return NULL;
	    }
	    if (PyDict_SetItemString(ar_dict, "B_RECALL_NUM", ar_dictobj) < 0)
	    {
		Py_DECREF(ar_dict);
		return NULL;
	    }
	    Py_DECREF(ar_dictobj);

	    /* ---------- */
	    /* note: the documentation of OpenVMS VAX V6.1 says 'DEVTYPE'
	       which is correct for offsets */
	    ar_dictobj = PyInt_FromLong((unsigned int)r_kbd_info.smg$b_dev_type);
	    if (ar_dictobj == NULL)
	    {
		Py_DECREF(ar_dict);
		return NULL;
	    }
	    if (PyDict_SetItemString(ar_dict, "B_DEVTYPE", ar_dictobj) < 0)
	    {
		Py_DECREF(ar_dict);
		return NULL;
	    }
	    Py_DECREF(ar_dictobj);

	    /* ---------- */
	    ar_dictobj = PyInt_FromLong((unsigned int)r_kbd_info.smg$b_typeahd_char);
	    if (ar_dictobj == NULL)
	    {
		Py_DECREF(ar_dict);
		return NULL;
	    }
	    if (PyDict_SetItemString(ar_dict, "B_TYPEAHD_CHAR", ar_dictobj) < 0)
	    {
		Py_DECREF(ar_dict);
		return NULL;
	    }
	    Py_DECREF(ar_dictobj);

	    /* ---------- */
	    ar_dictobj = PyInt_FromLong((unsigned int)r_kbd_info.smg$w_num_columns);
	    if (ar_dictobj == NULL)
	    {
		Py_DECREF(ar_dict);
		return NULL;
	    }
	    if (PyDict_SetItemString(ar_dict, "W_NUM_COLUMNS", ar_dictobj) < 0)
	    {
		Py_DECREF(ar_dict);
		return NULL;
	    }
	    Py_DECREF(ar_dictobj);

	    /* ---------- */
	    ar_dictobj = PyInt_FromLong((unsigned int)r_kbd_info.smg$w_typeahd_cnt);
	    if (ar_dictobj == NULL)
	    {
		Py_DECREF(ar_dict);
		return NULL;
	    }
	    if (PyDict_SetItemString(ar_dict, "W_TYPEAHD_CNT", ar_dictobj) < 0)
	    {
		Py_DECREF(ar_dict);
		return NULL;
	    }
	    Py_DECREF(ar_dictobj);
	    /* ---------- */

	    return (ar_dict);
	}

	/* -------------------- */
	/* error */
	return PyVMS_ErrSetVal(vms_smg_gr_error, 1, l_status);
} /* vms_smg_get_keyboard_attributes () */

/* ------------------------------------------------------------------------- */

/* EOF: VMS_SMG_GET_KEYBOARD_ATTRIBUTES.C */
