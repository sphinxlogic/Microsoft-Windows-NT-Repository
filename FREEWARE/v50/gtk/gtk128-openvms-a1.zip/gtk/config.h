/* config.h.  Specific for OpenVMS */

/* Define if using alloca.c.  */
#define C_ALLOCA 1

/* Define to empty if the keyword does not work.  */
/* #undef const */

/* Define to one of _getb67, GETB67, getb67 for Cray-2 and Cray-YMP systems.
   This function is required for alloca.c support on those systems.  */
/* #undef CRAY_STACKSEG_END */

/* Define if you have alloca, as a function or macro.  */
/* #undef HAVE_ALLOCA */

/* Define if you have <alloca.h> and it should be used (not on Ultrix).  */
/* #undef HAVE_ALLOCA_H */

/* Define if you have a working `mmap' system call.  */
#define HAVE_MMAP 1

/* Define as __inline if that's what the C compiler calls it.  */
#define inline __inline

/* Define to `long' if <sys/types.h> doesn't define.  */
/* #undef off_t */

/* Define if you need to in order for stat and other things to work.  */
/* #undef _POSIX_SOURCE */

/* Define as the return type of signal handlers (int or void).  */
#define RETSIGTYPE void

/* Define to `unsigned' if <sys/types.h> doesn't define.  */
/* #undef size_t */

/* If using the C implementation of alloca, define if you know the
   direction of stack growth for your system; otherwise it will be
   automatically deduced at run-time.
 STACK_DIRECTION > 0 => grows toward higher addresses
 STACK_DIRECTION < 0 => grows toward lower addresses
 STACK_DIRECTION = 0 => direction of growth unknown
 */
#define STACK_DIRECTION -1

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

/* Define if the X Window System is missing or not being used.  */
/* #undef X_DISPLAY_MISSING */

/* Other stuff */
/* #undef ENABLE_NLS */
#define GTK_COMPILED_WITH_DEBUGGING "no"

/* #undef HAVE_CATGETS */
/* #undef HAVE_GETTEXT */
/* #undef HAVE_IPC_H */
#define HAVE_LC_MESSAGES 1
/* #undef HAVE_SHM_H */
/* #undef HAVE_STPCPY */
#define HAVE_XSHM_H 1
#define HAVE_SHAPE_EXT 1
/* #undef HAVE_SYS_SELECT_H */
/* #undef HAVE_XCONVERTCASE */

/* #undef NO_FD_SET */

/* Define to use X11R6 additions to XIM */
/* #undef USE_X11R6_XIM */

#define XINPUT_NONE 1
/* #undef XINPUT_GXI */
/* #undef XINPUT_XFREE */

/* Define as the return type of signal handlers (int or void).  */
#define RETSIGTYPE void

/* Define if you have the __argz_count function.  */
/* #undef HAVE___ARGZ_COUNT */

/* Define if you have the __argz_next function.  */
/* #undef HAVE___ARGZ_NEXT */

/* Define if you have the __argz_stringify function.  */
/* #undef HAVE___ARGZ_STRINGIFY */

/* Define if you have the broken_wctype function.  */
/* #undef HAVE_BROKEN_WCTYPE */

/* Define if you have the dcgettext function.  */
/* #undef HAVE_DCGETTEXT */

/* Define if you have the getcwd function.  */
#define HAVE_GETCWD 1

/* Define if you have the getpagesize function.  */
#define HAVE_GETPAGESIZE 1

/* Define if you have the munmap function.  */
#define HAVE_MUNMAP 1

/* Define if you have the putenv function.  */
#define HAVE_PUTENV 1

/* Define if you have the setenv function.  */
#define HAVE_SETENV 1

/* Define if you have the setlocale function.  */
#define HAVE_SETLOCALE 1

/* Define if you have the stpcpy function.  */
/* #undef HAVE_STPCPY */

/* Define if you have the strcasecmp function.  */
#define HAVE_STRCASECMP 1

/* Define if you have the strchr function.  */
#define HAVE_STRCHR 1

/* Define if you have the strdup function.  */
#define HAVE_STRDUP 1

/* Define if you have the <argz.h> header file.  */
/* #undef HAVE_ARGZ_H */

/* Define if you have the <limits.h> header file.  */
#define HAVE_LIMITS_H 1

/* Define if you have the <locale.h> header file.  */
#define HAVE_LOCALE_H 1

/* Define if you have the <malloc.h> header file.  */
/* #undef HAVE_MALLOC_H */

/* Define if you have the <nl_types.h> header file.  */
#define HAVE_NL_TYPES_H 1

/* Define if you have the <string.h> header file.  */
#define HAVE_STRING_H 1

/* Define if you have the <sys/param.h> header file.  */
/* #undef HAVE_SYS_PARAM_H */

/* Define if you have the <unistd.h> header file.  */
#define HAVE_UNISTD_H 1

/* Define if you have the <wchar.h> header file.  */
#define HAVE_WCHAR_H 1

/* Define if you have the <wctype.h> header file.  */
#define HAVE_WCTYPE_H 1

/* Define if you have the i library (-li).  */
/* #undef HAVE_LIBI */

/* Define if you have the intl library (-lintl).  */
#define HAVE_LIBINTL 1

/* define if compiled symbols have a leading underscore */
/* #undef WITH_SYMBOL_UNDERSCORE */

/* These are defined here instead of on the command line */
/* They don't make much sense for VMS, maybe some other values */
/* would be better. But they're only defaults... */
#define GTK_DATA_PREFIX "/share/themes"
#define GTK_EXE_PREFIX  "/lib/gtk/themes/engines"
#define GTK_SYSCONFDIR  "/usr/local"

/* Should be allocated by LIB$GETEF */
#define VMS_EF_GTK_WINDOW_EVENT 2

/* Code to set an event flag when an X event occurs */
#define OLD_VMS_SETUP_WINDOW_NOTIFICATION(display,window)    \
{                                                        \
  extern XSelectAsyncInput( Display *display_id,         \
                            Window window_id,            \
                            unsigned long event_mask,    \
                            int (*ast_routine)(),        \
                            unsigned long ast_userarg);  \
  XSelectAsyncInput( display,                            \
                     window,                             \
                     0xFFFFFFFF,                         \
                     sys$setef,                          \
                     VMS_EF_GTK_WINDOW_EVENT);           \
}

/* Code to set an event flag when an X event occurs */
#define VMS_SETUP_WINDOW_NOTIFICATION(display,window)     \
{                                                         \
  extern XSelectAsyncEvent( Display *display_id,          \
                            Window window_id,             \
                            unsigned long event,          \
                            int (*ast_routine)(),         \
                            unsigned long ast_userarg);   \
  unsigned long event;                                    \
  for (event = KeyPress; event < LASTEvent; event += 1) { \
    XSelectAsyncEvent( display,                           \
                       window,                            \
                       event,                             \
                       sys$setef,                         \
                       VMS_EF_GTK_WINDOW_EVENT);          \
  }                                                       \
}

