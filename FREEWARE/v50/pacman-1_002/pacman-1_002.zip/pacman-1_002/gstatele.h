#ifndef __gstatele_h_ 
#define __gstatele_h_
#include"graphele.h"

class StaticGraphElement : public GraphElement {

};

#endif
