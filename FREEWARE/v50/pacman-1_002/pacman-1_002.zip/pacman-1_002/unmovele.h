#ifndef __unmovele_h_ 
 #define __unmovele_h_
 #include"dynamiel.h"

class UnmoveableElement : public DynamicElement {
       
public:       
          
          
};

#endif
