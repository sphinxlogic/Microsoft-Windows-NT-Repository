#ifndef __t0_h_ 
#define __t0_h_
#include"twall.h"

class T0 : public T_Wall {
         
public:         
         
T0();

};

#endif   
