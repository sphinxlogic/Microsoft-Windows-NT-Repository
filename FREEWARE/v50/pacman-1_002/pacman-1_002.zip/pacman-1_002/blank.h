#ifndef __blank_h_ 
#define __blank_h_
#include"staticel.h"

class Blank : public StaticElement {
         
public:         

Blank();				//constructor         
typ is_a(void) {return classBlank;}   	//what it is 

};

#endif   
