#ifndef __t90_h_ 
#define __t90_h_
#include"twall.h"

class T90 : public T_Wall {
         
public:         
         
T90();

};

#endif   
