#ifndef __gsupfood_h_ 
 #define __gsupfood_h_
 #include"gedible.h"

class G_SuperFood : public G_Edible {
          
public:

G_SuperFood();

};

#endif 
