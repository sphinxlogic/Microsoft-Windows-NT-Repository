#ifndef __horiwall_h_ 
#define __horiwall_h_
#include"strawall.h"

class HorizontalWall : public StraightWall {
         
public:         
         
HorizontalWall();

};

#endif   
