#ifndef __supefood_h_ 
 #define __supefood_h_
 #include"edible.h"

class SuperFood : public Edible {
          
public:

SuperFood();
typ is_a(void) {return classSuperFood;}    
          

};

#endif 
