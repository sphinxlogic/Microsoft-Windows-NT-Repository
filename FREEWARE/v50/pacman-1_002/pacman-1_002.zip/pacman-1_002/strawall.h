#ifndef __strawall_h_ 
#define __strawall_h_
#include"gwalls.h"

class StraightWall : public G_Walls {
         
public:         
         
void draw(void);

};

#endif   
