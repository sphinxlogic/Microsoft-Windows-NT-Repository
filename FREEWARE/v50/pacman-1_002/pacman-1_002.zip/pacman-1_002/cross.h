#ifndef __cross_h_ 
#define __cross_h_
#include"gwalls.h"

class Cross : public G_Walls {
         
public:         
         
Cross();
             
};

#endif   
