#ifndef __object_
#define __object_

#include"basis.h"

class Object {

};

#endif 
