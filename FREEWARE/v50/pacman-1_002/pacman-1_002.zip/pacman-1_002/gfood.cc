#include"gfood.h"
  
G_Food::G_Food() {
 
consfn();
pix(&pixmap,food_bits,Colour::FOODCOLOUR,Colour::MYBACKGROUND);

};



