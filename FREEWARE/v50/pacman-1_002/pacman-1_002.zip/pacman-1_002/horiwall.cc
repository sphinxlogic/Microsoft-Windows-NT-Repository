#include"horiwall.h"  


HorizontalWall::HorizontalWall() {
 
consfn();
pix(&pixmap,horiwall_bits,Colour::WALLCOLOUR,Colour::MYBACKGROUND);
};
