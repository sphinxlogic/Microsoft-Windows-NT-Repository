#ifndef __gfood_h_ 
 #define __gfood_h_
 #include"gedible.h"

class G_Food : public G_Edible {
          
public:

G_Food();
         
};

#endif 
