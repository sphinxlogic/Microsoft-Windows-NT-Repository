#include"t0.h"
  
T0::T0() {
 
consfn();
pix(&pixmap,t0_bits,Colour::WALLCOLOUR,Colour::MYBACKGROUND);
}

