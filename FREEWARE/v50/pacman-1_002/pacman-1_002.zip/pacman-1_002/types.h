#ifndef __types_h_
#define __types_h_

typedef enum {classSpecialWall,classWall,classFood,classSuperFood,classBlank,classBonusPoint,classBonusLife,classPacman,classGhost,classOther} typ;

#endif
