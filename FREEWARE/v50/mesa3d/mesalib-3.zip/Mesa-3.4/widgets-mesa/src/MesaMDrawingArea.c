/* MesaMDrawingArea.c */

#define __GLX_MOTIF 1
#include "MesaDrawingArea.c"

