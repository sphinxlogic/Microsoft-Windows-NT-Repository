#ifndef _MesaMWorkstation_h
#define _MesaMWorkstation_h

#define __GLX_MOTIF

#include "MesaWorkstationP.h"

#endif
