/* MesaMDrawingArea.h */


#ifndef MESAMDRAWINGAREA_H
#define MESAMDRAWINGAREA_H


#define __GLX_MOTIF 1

#include "MesaDrawingArea.h"


#endif
