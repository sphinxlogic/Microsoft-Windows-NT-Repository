
#define __GLX_MOTIF

#include "tea.c"
