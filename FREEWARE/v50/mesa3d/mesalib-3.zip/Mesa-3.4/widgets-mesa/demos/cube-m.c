
#define __GLX_MOTIF

#include "cube.c"
