#ifndef __MYALERT_H__
#define __MYALERT_H__

/*********************************************************************************
 *
 * ShowStopAlert(char *error,char *description);
 *
 *********************************************************************************/
extern void ShowStopAlert(char *error,char *description);



#endif