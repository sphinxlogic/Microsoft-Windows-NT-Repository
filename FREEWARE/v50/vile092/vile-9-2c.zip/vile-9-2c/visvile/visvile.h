// VisVile.h : main header file for the VISVILE DLL
//

#if !defined(AFX_VISVILE_H__E4C5E2EC_36FF_11D2_B8E4_0020AF0F4354__INCLUDED_)
#define AFX_VISVILE_H__E4C5E2EC_36FF_11D2_B8E4_0020AF0F4354__INCLUDED_

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

#include <ObjModel\addguid.h>
#include <ObjModel\appguid.h>
#include <ObjModel\bldguid.h>
#include <ObjModel\textguid.h>
#include <ObjModel\dbgguid.h>

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_VISVILE_H__E4C5E2EC_36FF_11D2_B8E4_0020AF0F4354__INCLUDED)
