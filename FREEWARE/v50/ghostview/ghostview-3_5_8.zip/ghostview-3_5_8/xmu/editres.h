/* $XConsortium: Editres.h,v 1.1 91/07/30 15:28:40 rws Exp $ */

#ifdef VMS
#   include <X11_DIRECTORY/Xfuncproto.h>
#else
#   include <X11/Xfuncproto.h>
#endif

_XFUNCPROTOBEGIN

void _XEditResCheckMessages();

_XFUNCPROTOEND
