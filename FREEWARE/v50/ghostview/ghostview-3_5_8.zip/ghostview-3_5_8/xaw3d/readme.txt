All documentation, old and new versions of the
  o Paned widget
  o Scrollbar widget
and the original version of the layout widget
may be found in the subdirectory [.widget].
