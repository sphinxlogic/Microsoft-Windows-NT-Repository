GhostView_(GV3.5.8), MOTIF_Toys, PostScript Viewer (needs GhostScript)

                          Overview of GhostView

GV allows to view and navigate through PostScript and PDF documents on an
X display by providing a user interface for the ghostscript interpreter. 

The current version is 3.5.8 (June 21 1997) 

Please note that GV is derived from Tim Theisen's ghostview 1.5. 
