static void
Dark(w,xev,argv,argcp)
Widget w;
XEvent *xev;
String *argv;
int *argcp;
{
	Rdata.dark = !Rdata.dark;
	redraw();
}
