/* config.h.in.  Generated automatically from configure.in by autoheader.  */
/* and edited by me */

#ifndef __CONFIG_H__
#define __CONFIG_H__

/* Define to empty if the keyword does not work.  */
#undef const

/* Define to `int' if <sys/types.h> doesn't define.  */
#undef gid_t

/* Define to `int' if <sys/types.h> doesn't define.  */
#undef mode_t

/* Define to `int' if <sys/types.h> doesn't define.  */
#undef pid_t

/* Define if you need to in order for stat and other things to work.  */
#undef _POSIX_SOURCE

/* Define as the return type of signal handlers (int or void).  */
#define RETSIGTYPE void

#ifdef RETSIGTYPE
#define SIGNAL_CALLBACK_TYPE (RETSIGTYPE (*)())
#endif

/* Define to `unsigned' if <sys/types.h> doesn't define.  */
#undef size_t

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS

/* Define to `int' if <sys/types.h> doesn't define.  */
#undef uid_t

/* Define if you do not have the gethostname function.  */
#undef NO_GETHOSTNAME

/* Define if you do not have the strcasecmp function.  */
#define NO_STRCASECMP

/* Define if you do not have the XawViewportSetCoordinates function.  */
#undef NO_VIEWPORT_SET_FUNCTIONS

/* Define if you have a POSIX regexp library */
#undef USE_POSIX_REGEXP

#endif
