
#ifndef _YAWN_PRIVATE_H_
#define _YAWN_PRIVATE_H_

extern Widget YCreateShadedActionButton(String, Widget,
					Pixmap, WidgetClass, YShade);

#endif
