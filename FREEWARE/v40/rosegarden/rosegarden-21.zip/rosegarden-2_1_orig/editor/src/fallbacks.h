
#ifndef _MUSIC_FALLBACKS_
#define _MUSIC_FALLBACKS_


static String fallbacks[] = {

"Rosegarden*Text*Translations:   #override <Key>Return: end-of-line()",

NULL,
};

#endif /* _MUSIC_FALLBACKS_ */

