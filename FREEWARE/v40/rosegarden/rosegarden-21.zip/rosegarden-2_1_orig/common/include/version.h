
#ifndef _ROSEGARDEN_VERSION_H_
#define _ROSEGARDEN_VERSION_H_

#define ROSEGARDEN_VERSION "Release 2.1-beta, October 1997"

#endif

