#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <signal.h>
#include <pwd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/file.h>

#ifndef VMS
#include <sys/wait.h>
#else
#include <lib$routines.h>
#include <unixlib.h>
#include "unix_types.h"
#include "unix_time.h"
#define random rand
#define srandom srand
#define fork vfork
unsigned long int statvms;
float seconds;
char * vmsusername;
int    vmsuserlen;
#endif /* VMS */

#include <X11/Xlib.h>
#include <X11/Xutil.h> 
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <X11/Shell.h>
#include "c_config.h"
#include "c_colors.h"
#include "c_defs.h"
#include "c_structs.h"
#include "c_externs.h"
