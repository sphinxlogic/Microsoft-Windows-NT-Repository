/*
        Copyright (c) 1998, Ruslan R. Laishev (@RRL)
*/

#include        "nntp.h"

/*
 *--------------------------------------------------------------------------------
 */
int	chk_IP_prot		(	
				char	*ipadr,
				int	 ipadrlen,
				char	*ipname,
				int	 ipnamelen
				)
{
char	*mask;
int	 masklen;
int	 i;
struct dsc$descriptor_s dsc_t;

	INIT_SDESC(dsc_t,ipadrlen,ipadr);


	if ( !nntp_conf._s_clnt_list.dsc$w_length )
		return 0;

	for (i = 0;masklen=strelem(&nntp_conf._s_clnt_list,'|',i,&mask); i++)
		{
		if ( strmatch(mask,masklen,ipadr,ipadrlen) )		
			return	1;
		}

	return	0;
}
