/*
 * stubs module
 */
void set_right_footer(char *msg)
{
}
#ifdef VMS
void lgamma(void)
{
}
void erf(void)
{
}
void erfc(void)
{
}
#endif
