/*
 * for Motif specific items
 */

extern Widget app_shell;        /* defined in xmgr.c */
extern XmStringCharSet charset; /* defined in xmgr.c */

#include "xprotos.h"
#include "noxprotos.h"
