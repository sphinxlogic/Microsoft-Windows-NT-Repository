# 23-OCT-97  MGD  initial
# Hmmm, really taxing my Perl skills here (which are pretty much non-existant)

$CgiPlusEof = $ENV{"CGIPLUSEOF"};

if ($CgiPlusEof eq "")
{
#  (standard CGI environment)

   printf ("Content-Type: text/html\n\n");
   printf ("<FONT SIZE=+2>Hello there &nbsp&quot;%s&quot;\n",
           $ENV{"WWW_REMOTE_HOST"});
}
else
{
#  (CGIplus environment)

   open (CGIPLUSIN, $ENV{"CGIPLUSIN"}) || die "Could not open CGIPLUSIN\n";

   $Again = "";
   $Reuse = "";
   $UsageCount = 1;

   for (;;)
   {
      <CGIPLUSIN>;  # discard start-of-request record
      while (<CGIPLUSIN>)
      {
        chop;
        if (substr($_,0,16) eq "WWW_REMOTE_HOST=")
           { $WwwRemoteHost = substr($_,16,999) }
        if ($_ eq "") { last; }
      }
      printf ("Content-Type: text/html\n\n");
      printf ("<FONT SIZE=+2>Hello there%s &nbsp&quot;%s&quot;%s\n",
              $Again, $WwwRemoteHost, $Reuse);
      printf ("%s\n", $CgiPlusEof);
      $Again = " again";
      $Reuse = " (reuse " . $UsageCount++ . ") "
   }
}
