# 02-NOV-97  MGD  this version unwrapped from CGIPLUSPERL.COM
# 08-JUN-97  MGD  initial
# BTW: Seems a shame to broadcast how little I know about Perl :^)

$CgiPlusEof = $ENV{"CGIPLUSEOF"};
$CgiPlusEof ne "" || die "Only executes in CGIplus environment!\n";

$FirstUsed = localtime(time());
$UsageCount = 1;

open (CGIPLUSIN, $ENV{"CGIPLUSIN"}) || die "Could not open CGIPLUSIN\n";

for (;;)
{
   <CGIPLUSIN>;  # discard start-of-request record

   $Now = localtime(time());

   printf ("Content-Type: text/plain\n\n");

   printf ("Number of times used: %d\nFirst used: %s\nNow: %s\n\n",
           $UsageCount++, $FirstUsed, $Now);

   while (<CGIPLUSIN>)
   {
     chop;
     if ($_ eq "") { last; }
     printf ("%s\n", $_);
   }

   printf ("%s\n", $CgiPlusEof);
}
