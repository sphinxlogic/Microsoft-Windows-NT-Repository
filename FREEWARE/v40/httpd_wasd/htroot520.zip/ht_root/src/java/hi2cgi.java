// hi2CGI.java
// Compile using: $ javac "hi2CGI.java"
//
// 03-SEP-98  MGD  changes in line with JDK 1.1.6 final release
// 09-DEC-97  MGD  initial
//
// Quick demonstration of using the CGIplus class for a "CGI" script.
// Can be invoked using ... http://host/cgiplus-bin/hi2cgi.class

import java.io.*;

public class hi2cgi {

   private static CGIplus cgienv = new CGIplus();

   public static void main (String args[]) {

      // CGI-compliant header line making document HTML
      System.out.print("Content-Type: text/html\n\n");

      System.out.print("<H1><U>Hi &nbsp;" +
                       cgienv.getCgiVar("WWW_REMOTE_HOST") +
                       "</U></H1>\n" + 
                       "You are using \"<B>" +
                       cgienv.getCgiVar("WWW_HTTP_USER_AGENT") +
                       "</B>\"\n<P>It\'s currently <B>" +
                       cgienv.getCgiVar("WWW_REQUEST_TIME_LOCAL") +
                       "</B> here at <B>" +
                       cgienv.getCgiVar("WWW_SERVER_NAME") +
                       "</B>");
   }
}
