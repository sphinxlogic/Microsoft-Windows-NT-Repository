// hi1CGI.java
// Compile using: $ javac "hi1CGI.java"
//
// 03-SEP-98  MGD  changes in line with JDK 1.1.6 final release
// 09-DEC-97  MGD  initial
//
// Quick demonstration of using the CGIplus class for a "CGI" script.
// Can be invoked using ... http://host/cgiplus-bin/hi1cgi.class

import java.io.*;

public class hi1cgi {

   private static CGIplus cgienv = new CGIplus();

   public static void main (String args[]) {

      System.out.print("Hi " +
                       cgienv.getCgiVar("WWW_REMOTE_HOST") +
                       ", using \"" +
                       cgienv.getCgiVar("WWW_HTTP_USER_AGENT") +
                       "\",\nit\'s currently " +
                       cgienv.getCgiVar("WWW_REQUEST_TIME_LOCAL") +
                       " here at " +
                       cgienv.getCgiVar("WWW_SERVER_NAME"));
   }
}
