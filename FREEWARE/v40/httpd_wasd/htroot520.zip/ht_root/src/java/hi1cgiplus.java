// hi1CGIplus.java
// Compile using: $ javac "hi1CGIplus.java"
//
// 03-SEP-98  MGD  changes in line with JDK 1.1.6 final release
// 09-DEC-97  MGD  initial
//
// Quick demonstration of using the CGIplus class for a "CGIplus" script.
// Can be invoked using ... http://host/cgiplus-bin/hi1cgiplus.class

import java.io.*;

public class hi1cgiplus {

   private static CGIplus cgienv = new CGIplus();

   public static void main (String args[]) {

      /* CGIplus "infinite loop" */
      for (;;) {

         cgienv.begin();

         System.out.print("Hi " +
                          cgienv.getCgiVar("WWW_REMOTE_HOST") +
                          "\n\nYou are using \"" +
                          cgienv.getCgiVar("WWW_HTTP_USER_AGENT") +
                          "\"\nIt\'s currently " +
                          cgienv.getCgiVar("WWW_REQUEST_TIME_LOCAL") +
                          " here at " +
                          cgienv.getCgiVar("WWW_SERVER_NAME") +
                          "\n\nCGIplus version ... used " +
                          cgienv.getUsageCount() + 
                          " time(s).\n");

         cgienv.end();
      }
   }
}
