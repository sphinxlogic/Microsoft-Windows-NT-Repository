// dumpCGI.java
// Compile using: $ javac "dumpCGI.java"
//
// 03-SEP-98  MGD  changes in line with JDK 1.1.6 final release
// 09-DEC-97  MGD  initial
//
// Dump CGI variable values using the CGIplus class for a "CGI" script.
// Can be invoked using ... http://host/cgiplus-bin/dumpcgi.class

import java.io.*;

public class dumpcgi {

   private static CGIplus cgienv = new CGIplus();
   private static String nameValue = null;

   public static void main (String args[]) {

      System.out.println("There are " +
                         cgienv.getCgiVarCount() +
                         " CGI variables ...");
      while ((nameValue = cgienv.nextCgiVar()) != null)
         System.out.print(nameValue);

      // an alternative would have been ...
      // cgienv.dumpCgiVar();

      if (cgienv.isPOSTedForm())
      {
         System.out.print(cgienv.getCgiVar("CONTENT_TYPE"));

         cgienv.dumpForm();

         while ((nameValue = cgienv.nextFormField()) != null)
            System.out.print(nameValue);

         System.out.print(cgienv.getFormField("hidden2"));
         System.out.print(cgienv.getFormField("hidden3"));
      }
   }
}
