/*****************************************************************************/
/*
                                  upd.h

Function prototypes for update module.

*/
/*****************************************************************************/

UpdBegin (struct RequestStruct*, void*);
UpdConfirmCreate (struct RequestStruct*);
UpdConfirmDelete (struct RequestStruct*);
UpdConfirmRename (struct RequestStruct*, char*, char*, char*);
UpdCopyFileBegin (struct RequestStruct*);
UpdCopyFileEnd (struct RequestStruct*);
UpdCopyFileNextBlock (struct RequestStruct*);
UpdCopyFileNextBlockAST (struct RAB*); 
UpdEditFileBegin (struct RequestStruct*);
UpdEditFileEnd (struct RequestStruct*);
UpdEditFileNextRecord (struct RequestStruct*);
UpdEditFileNextRecordAST (struct RAB*); 
UpdEnd (struct RequestStruct*);
UpdNavigateBeginFiles (struct RequestStruct*);
UpdNavigateDirs (struct FAB*); 
UpdNavigateFiles (struct FAB*); 
UpdNavigateSearchDirs (struct RequestStruct*); 
UpdNavigateSearchFiles (struct RequestStruct*); 
UpdTreeListDirs (struct RequestStruct*);
UpdTreeDirs (struct FAB*); 
UpdTreeEnd (struct RequestStruct*);

/*****************************************************************************/

