/*****************************************************************************/
/*
                                 Digest.h

Function prototypes for DIGEST authentication module.

*/
/*****************************************************************************/

DigestA1 (char*, char*, char*, unsigned char*);
int DigestChallenge (struct RequestStruct*, char*);
int DigestCheckNonce (struct RequestStruct*, char*);
DigestHexString (unsigned char*, int, unsigned char*);
DigestResponse (unsigned char*, char*, char*, char*, char*);

/*****************************************************************************/

