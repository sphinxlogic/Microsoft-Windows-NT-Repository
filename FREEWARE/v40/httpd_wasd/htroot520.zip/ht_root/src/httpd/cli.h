/*****************************************************************************/
/*
                                  CLI.h

Function prototypes for CLI module.

*/
/*****************************************************************************/

int ParseCommandLine ();
int ParseCommand (char*);
boolean ParseCommandString (char*, char*, boolean, boolean, boolean);
boolean ParseCommandInteger (char*, int, int, boolean);
int ParseEntity (char*);

/*****************************************************************************/

