/*****************************************************************************/
/*
                                  file.h

Function prototypes for file transfer module.

*/
/*****************************************************************************/

FileBegin (struct RequestStruct*, void*, void*, char*, char*,
           boolean, boolean, boolean);
FileEnd (struct RequestStruct*);
FileEmptyBuffer (struct RequestStruct*);
FileFlushBuffer (struct RequestStruct*, void*);
FileFlushBufferEscapeHtml (struct RequestStruct*, void*);
FileHttpHeader (struct RequestStruct*, int, char*, int);
FileNextBlocks (struct RequestStruct*);
FileNextBlocksAST (struct RAB*); 
FileNextRecord (struct RequestStruct*);
FileNextRecordAST (struct RAB*); 
FileAcpInfo (struct RequestStruct*);

/*****************************************************************************/
