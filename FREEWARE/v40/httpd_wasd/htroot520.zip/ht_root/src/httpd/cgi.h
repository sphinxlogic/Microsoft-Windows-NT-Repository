/*****************************************************************************/
/*
                                  CGI.h

Defines and function prototypes for CGI module.

*/
/*****************************************************************************/

#define CGI_VARIABLE_DCL 1
#define CGI_VARIABLE_STREAM 2

#define CGI_OUTPUT_ABSORB -2
#define CGI_OUTPUT_TERMINATE -1

CgiGenerateVariables (struct RequestStruct*, int);
CgiVariable (struct RequestStruct*, char*, char*, int);

/*****************************************************************************/

