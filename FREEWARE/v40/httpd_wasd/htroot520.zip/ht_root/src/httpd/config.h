/*****************************************************************************/
/*
                                  Config.h

Function prototypes for configuration module.

*/
/*****************************************************************************/

int Configure (struct ConfigStruct*);
boolean ConfigAcceptClientHostName (char*, char*);
ConfigAddType (struct ConfigStruct*, char*);
char* ConfigCommaList (struct RequestStruct*, char*, char);
char* ConfigContentType (struct ContentTypeStruct*, char*);
ConfigContentTypeIcon (struct ConfigStruct*);
char* ConfigHomePage (int);
ConfigAddIcon (struct ConfigStruct*, char*);
char* ConfigIconFor (char*);
char* ConfigReadMeFile (int);
ConfigReport (struct RequestStruct*, void*, boolean);
ConfigRevise (struct RequestStruct*, void*, boolean);
ConfigSetAccept (struct ConfigStruct*, char*);
ConfigSetCommaList (struct ConfigStruct*, char*, char**, int*);
ConfigSetDirReadMe (struct ConfigStruct*, char*);
ConfigSetDirReadMeFile (struct ConfigStruct*, char*);
ConfigSetReject (struct ConfigStruct*, char*);
ConfigSetWelcome (struct ConfigStruct*, char*);

/*****************************************************************************/
