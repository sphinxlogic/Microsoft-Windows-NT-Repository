/*****************************************************************************/
/*
                                  HTAdmin.h

Function prototypes for HTAdmin module.

*/
/*****************************************************************************/

HTAdminBegin (struct RequestStruct*, void*);
HTAdminCacheResetEntry (struct AuthCacheRecordStruct*,
                        struct AuthCacheRecordStruct*);
char* HTAdminCanString (struct RequestStruct*, unsigned long, boolean);
HTAdminDatabaseBegin (struct RequestStruct*);
HTAdminDatabaseEnd (struct RequestStruct*);
HTAdminDatabaseSearch (struct RequestStruct*);
HTAdminDatabaseSearchAst (struct FAB*); 
HTAdminDatabaseUsersBegin (struct RequestStruct*, char*);
HTAdminDatabaseUsersEnd (struct RequestStruct*);
HTAdminDatabaseUsersList (struct RequestStruct*);
HTAdminDatabaseUsersListSort (struct RequestStruct*);
HTAdminDatabaseUsersNext (struct RequestStruct*);
HTAdminDatabaseUsersNextAst (struct RAB*); 
HTAdminEnd (struct RequestStruct*);
HTAdminListUsersBegin (struct RequestStruct*, char*);
HTAdminListUsersEnd (struct RequestStruct*);
HTAdminListUsersList (struct RequestStruct*);
HTAdminListUsersListSort (struct RequestStruct*);
HTAdminListUsersNext (struct RequestStruct*);
HTAdminListUsersNextAst (struct RAB*); 
HTAdminModifyUser (struct RequestStruct*, boolean, char*, char*, char*,
                   char*, char*, char*, char*, char*, char*, char*);
HTAdminModifyUserForm (struct RequestStruct*, boolean, char*, char*);
HTAdminPasswordChange (struct RequestStruct*, char*, char*, char*);
HTAdminPasswordChangeForm (struct RequestStruct*);
HTAdminResetCacheEntry (struct RequestStruct*, char*, char*);

/*****************************************************************************/

