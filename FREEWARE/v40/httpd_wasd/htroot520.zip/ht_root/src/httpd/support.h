/*****************************************************************************/
/*
                                 Support.h

Function prototypes for support module.

*/
/*****************************************************************************/

void* ListAddHead (struct ListHeadStruct*, struct ListEntryStruct*);
void* ListAddTail (struct ListHeadStruct*, struct ListEntryStruct*);
void* ListAddBefore (struct ListHeadStruct*, struct ListEntryStruct*,
                     struct ListEntryStruct*);
void* ListRemove (struct ListHeadStruct*, struct ListEntryStruct*);
ListDebug (struct ListHeadStruct*);

EnableSysPrv ();
DisableSysPrv ();
int CompareVmsBinTimes (unsigned long*, unsigned long*);
int CopyTextIntoHtml (char*, char*, int);
char* DayOfWeekName (unsigned long*);
int DefineMonitorLogicals (struct RequestStruct*);
int DefineMonitorLogicalsHere (struct RequestStruct*);
int FormatProtection (unsigned short, char*);
char* HeapStringAppend (struct RequestStruct*, char*, char*, int);
char* HeapStringPrepend (struct RequestStruct*, char*, char*, int);
char* HtmlMetaInfo (struct RequestStruct*, char*);
char* HttpHeader (struct RequestStruct*, int, char*, int,
                  unsigned long*, char*);
char *HttpHeaderAppend (struct RequestStruct*, char*, char*, int);
int HttpGmTime (char*, unsigned long*);
int HttpGmTimeString (char*, unsigned long*);
int HttpIfModifiedSince (struct RequestStruct*, unsigned long*, int);
int NameOfDirectoryFile (char*, int, char*, int*);
int TimeAdjustGMT (boolean, unsigned long*);
int TimeSetGMT ();
int TimeVmsToUnix (unsigned long*, struct tm*);
int UrlDecodeString (char*);
int ZeroAccounting ();

char *ParseQueryField (struct RequestStruct*, char*, char*, int, char*, int,
                       char*, int);

/* this macro generates an HTML content-type, success header */
#define HttpHeader200Html(rqptr) \
        HttpHeader (rqptr, 200, "text/html", -1, NULL, NULL)

/*****************************************************************************/
