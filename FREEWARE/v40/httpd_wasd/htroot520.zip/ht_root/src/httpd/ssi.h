/*****************************************************************************/
/*
                                  SSI.h

Function prototypes for pre-processed HTML (Server-Side Includes) module.

*/
/*****************************************************************************/

SsiAccessCount (struct RequestStruct*, unsigned long*, unsigned long*);
SsiBegin (struct RequestStruct*, void*, void*, char*);
SsiDoAccesses (struct RequestStruct*);
SsiDoDcl (struct RequestStruct*);
SsiDoDir (struct RequestStruct*);
SsiDoEcho (struct RequestStruct*);
SsiDoElif (struct RequestStruct*);
SsiDoElse (struct RequestStruct*);
SsiDoEnd (struct RequestStruct*);
SsiDoEndif (struct RequestStruct*);
SsiDoIf (struct RequestStruct*);
SsiDoInclude (struct RequestStruct*);
SsiDoPrintEnv (struct RequestStruct*);
SsiDoSet (struct RequestStruct*);
SsiDoTrace (struct RequestStruct*);
SsiIncludeError (struct RequestStruct*);
SsiNextRecord (struct RequestStruct*);
SsiNextRecordAST (struct RAB*);
SsiParse (struct RequestStruct*);
SsiStatement (struct RequestStruct*);
SsiTraceGetVar (struct RequestStruct*, char*, char*);
SsiTraceLine (struct RequestStruct*);
SsiTraceSetVar (struct RequestStruct*, char*, char*);
char* SsiSysGetMsg (int);
char* SsiGetVar (struct RequestStruct*, char*, char*, boolean);
char* SsiGetServerVar (struct RequestStruct*, char*, char*);
char* SsiGetUserVar (struct RequestStruct*, char*);
int SsiTimeString (struct RequestStruct*, unsigned long*, char*, char*, int);

/*****************************************************************************/
