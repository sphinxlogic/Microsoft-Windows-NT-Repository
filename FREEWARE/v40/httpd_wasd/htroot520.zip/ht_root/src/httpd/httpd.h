/*****************************************************************************
/*
                                 HTTPd.h

Function prototypes for HTTPd.c module.

*/
/*****************************************************************************/

HttpdExit ();
HttpdSupervisor (boolean);
HttpdCheckPriv ();
int HttpdTimeoutSet (struct RequestStruct*, int);

/*****************************************************************************/

