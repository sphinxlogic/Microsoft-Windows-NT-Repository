/*****************************************************************************/
/*
                                  DCL.h

Function prototypes for DCL (with CGIplus) module.

*/
/*****************************************************************************/

/* no world or group access */
#define SubprocessMbxProtectionMask 0xff00

DclAbortSubprocess (struct DclTaskStruct*);
DclAllocateTask (struct RequestStruct*); 
DclBegin (struct RequestStruct*, void*, char*, char*); 
DclConcludeTask (struct DclTaskStruct*, boolean);
DclDeallocateTask (struct DclTaskStruct*);
DclFindScript (struct RequestStruct*, char*, char**, char**);
DclHttpInputAst (struct DclTaskStruct*);
DclQioSysCommand (struct DclTaskStruct*, char*, int);
DclQioCgiPlusIn (struct DclTaskStruct*, char*, int);
DclQioSysOutput (struct DclTaskStruct*);

/* NOTE ... pointer to request structure! */
DclSysOutputToClientAst (struct RequestStruct*);

DclCgiScriptSysCommand (struct DclTaskStruct*, char*, char*, char*, char*);
DclPlusScriptSysCommand (struct DclTaskStruct*, char*, char*, char*, char*);
DclPlusScriptSysCgiPlusIn (struct DclTaskStruct*);
DclPurgeAllCgiPlusScripts (struct RequestStruct*, void*, boolean);
DclSysCommandAst (struct DclTaskStruct*);
DclCgiPlusInAst (struct DclTaskStruct*);
DclSubprocessCompletionAST (struct DclTaskStruct*);
DclSysOutputHeader (struct DclTaskStruct*);
DclSysOutputLocation (struct DclTaskStruct*);
DclSysOutputAst (struct DclTaskStruct*);
DclSysOutputWaitAst (struct DclTaskStruct*);
DclSetCgiPlusLifeTime (struct DclTaskStruct*);
DclCgiPlusLifeTimeAst (struct DclTaskStruct*);
DclSetZombieLifeTime (struct DclTaskStruct*);
DclZombieLifeTimeAst (struct DclTaskStruct*);

char* DclControlPurgeAllSubprocesses (boolean);

/*****************************************************************************/

