/*****************************************************************************/
/*
                                 Basic.h

Function prototypes for BASIC authentication module.

*/
/*****************************************************************************/

int BasicAuthentication (struct RequestStruct*);
int BasicChallenge (struct RequestStruct*);
char* BasicPrintableDecode (char*, char*, int);

/*****************************************************************************/

