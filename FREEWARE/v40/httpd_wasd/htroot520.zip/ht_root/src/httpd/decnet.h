/*****************************************************************************/
/*
                                  DECnet.h

Function prototypes for DECnet module.

*/
/*****************************************************************************/

DECnetCgiDialog (struct RequestStruct*);
DECnetConnect (struct RequestStruct*, void*, char*);
DECnetConnectAst (struct RequestStruct*);
DECnetEnd (struct RequestStruct*);
DECnetOsuCgi (struct RequestStruct*, char*);
DECnetOsuDialog (struct RequestStruct*);
DECnetOsuDnetId (struct RequestStruct*, struct DECnetTaskStruct*, boolean);
DECnetOsuDnetXlate (struct RequestStruct*, struct DECnetTaskStruct*, char*);
DECnetRead (struct RequestStruct*);
DECnetReadAst (struct RequestStruct*);
DECnetWrite (struct RequestStruct*, char*, int);
DECnetWriteAst (struct RequestStruct*);
DECnetWriteRequest (struct RequestStruct*);
DECnetWriteRequestAst (struct RequestStruct*);

/*****************************************************************************/

