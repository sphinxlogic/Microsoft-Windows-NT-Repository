/*****************************************************************************/
/*
                                 Error.h

Function prototypes for error reporting module.

*/
/*****************************************************************************/

ErrorHeapAlloc (struct RequestStruct*, char*, int);
ErrorExitVmsStatus (int, char*, char*, int);
ErrorGeneral (struct RequestStruct*, char*, char*, int);
ErrorGeneralOverflow (struct RequestStruct*, char*, int);
ErrorMessageDividerAst (struct RequestStruct*);
ErrorSendToClient (struct RequestStruct*, void*);
ErrorServerShutdown (unsigned short);
char* ErrorSourceInfo (char*, int);
ErrorVmsStatus (struct RequestStruct*, int, char*, int);

/*****************************************************************************/

