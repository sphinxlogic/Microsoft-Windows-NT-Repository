/*****************************************************************************/
/*
                                  Put.h

Function prototypes for PUT/POST/DELETE module.

*/
/*****************************************************************************/

PutBegin (struct RequestStruct*, void*);
int PutCheckAccess (char*);
PutCreateDirectory (struct RequestStruct*, char*);
PutDelete (struct RequestStruct*, char*);
PutEnd (struct RequestStruct*);
PutResponse (struct RequestStruct*, char*, char*, char*, int);
PutWriteFile (struct RequestStruct*);
PutWriteFileAst (struct RAB*); 
PutWriteFileEnd (struct RequestStruct*);
int PutMultipartFormData (struct RequestStruct*);
char *PutStoreString (struct RequestStruct*, char*, int, char*, int);
char* PutGetMultipartFieldName (struct RequestStruct*, char*,
                                char*, char*, int);
char* PutGetMultipartFieldValue (struct RequestStruct*, char*,
                                 char*, char*, int);
int PutText (struct RequestStruct*);
int PutUrlDecode (struct RequestStruct*);
int PutChangeFileAttributes (struct RequestStruct*);

/*****************************************************************************/

