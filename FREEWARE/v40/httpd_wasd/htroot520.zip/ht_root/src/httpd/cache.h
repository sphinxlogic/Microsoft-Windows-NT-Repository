/*****************************************************************************/
/*
                                  cache.h

Function prototypes for caching module.

*/
/*****************************************************************************/

CacheAcpInfo (struct RequestStruct*);
CacheBegin (struct RequestStruct*);
CacheEnd (struct RequestStruct*);
CacheInit ();
CacheLoadBegin (struct RequestStruct*, int);
CacheLoadEnd (struct RequestStruct*, struct FileTaskStruct*);
CacheSearch (struct RequestStruct*, char*);
CacheNext (struct RequestStruct*);
CachePurge (boolean, int*, int*);
CacheReport (struct RequestStruct*, void*);
CacheZeroCounters ();

/*****************************************************************************/
