/*****************************************************************************/
/*
                                  Descr.h

Function prototypes for file description module.

*/
/*****************************************************************************/

int Description (struct RequestStruct*, void*, char*, char*, char*, int, int);
DescriptionEscape (struct RequestStruct*);
DescriptionHtml (struct RequestStruct*);
DescriptionHtmlRecord (struct RAB*);
DescriptionPlain (struct RequestStruct*);
DescriptionPlainRecord (struct RAB*);

/*****************************************************************************/

