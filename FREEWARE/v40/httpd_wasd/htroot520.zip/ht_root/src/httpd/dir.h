/*****************************************************************************/
/*
                                  Dir.h

Function prototypes for the directory listing module.

*/
/*****************************************************************************/

DirBegin (struct RequestStruct*, void*, char*, char*, char*);
DirBeginDirectories (struct RequestStruct*);
DirBeginFiles (struct RequestStruct*);
DirDirectories (struct FAB*);
DirEnd (struct RequestStruct*);
DirEndDescription (struct RequestStruct*);
DirEndOutput (struct RequestStruct*);
DirFiles (struct FAB*);
boolean DirFileExists (struct RequestStruct*, char*, char*);
DirFormat (struct RequestStruct*, void*, char*, boolean);
DirFormatLayout (struct RequestStruct*);
DirHeading (struct RequestStruct*);
int DirHttpHeader (struct RequestStruct*);
DirReadMe (struct RequestStruct*,
           void(*NextTaskFunction)(struct RequestStruct*));
DirReadMeTop (struct RequestStruct*);
DirReadMeBottom (struct RequestStruct*);
DirSearchDirectories (struct RequestStruct*);

/*****************************************************************************/
