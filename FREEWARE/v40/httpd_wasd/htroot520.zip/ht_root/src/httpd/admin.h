/*****************************************************************************/
/*
                                 Admin.h

Function prototypes for server administration module.

*/
/*****************************************************************************/

AdminBegin (struct RequestStruct*, void*);
AdminControl (struct RequestStruct*, void*, char*);
AdminControlSuccess (struct RequestStruct*, char*, char*);
AdminMenu (struct RequestStruct*, void*);
AdminReportServerStats (struct RequestStruct*, void*);

/*****************************************************************************/
