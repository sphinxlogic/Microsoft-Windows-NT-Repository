/*****************************************************************************/
/*
                                  Logging.h

Function prototypes for logging module.

*/
/*****************************************************************************/

int Logging (struct RequestStruct*, int);
int LoggingDo (struct RequestStruct*, struct ServiceStruct*, int);
LoggingFlushFileAST ();

/*****************************************************************************/
