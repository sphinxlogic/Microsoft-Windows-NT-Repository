/*****************************************************************************/
/*
                                  Request.h

Function prototypes for request processing module.

*/
/*****************************************************************************/

RequestBegin (struct RequestStruct*, boolean);
RequestBodyReadBegin (struct RequestStruct*);
RequestBodyReadAst (struct RequestStruct*);
RequestDiscardAst (struct RequestStruct*);
RequestEnd (struct RequestStruct*);
RequestEndConnection (struct RequestStruct*);
RequestExecute (struct RequestStruct*);
RequestFields (struct RequestStruct*);
RequestFile (struct RequestStruct*, void*, void*);
RequestFileNoType (struct RequestStruct*);
RequestGet (struct RequestStruct*);
RequestHistory (struct RequestStruct*);
RequestHomePage (struct RequestStruct*);
RequestMethodPathQuery (struct RequestStruct*);
RequestParseAndExecute (struct RequestStruct*);
RequestRedirect (struct RequestStruct*);
RequestReport (struct RequestStruct*, void*);

/*****************************************************************************/
