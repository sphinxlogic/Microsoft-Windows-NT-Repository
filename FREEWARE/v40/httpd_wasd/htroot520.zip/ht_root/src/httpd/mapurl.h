/*****************************************************************************/
/*
                                  MapUrl.h

Function prototypes for path mapping module.

*/
/*****************************************************************************/

/* for (what's essentially) backward compatibility */
#define MapUrl(pp,vp,sp,svp) MapUrl_Map(pp,vp,sp,svp,NULL)

/* "quick and dirty" return path equivalent of VMS file specification */
#define MapVmsPath(vp) MapUrl_Map(NULL,vp,NULL,NULL,NULL)

char* MapUrl_Map (char*, char*, char*, char*, void*);
char* MapUrl_LoadRules (struct MappingRuleListStruct*);
char* MapUrl_ReportProblem (struct MappingRuleListStruct*, char*, int);
int MapUrl_UrlToVms (char*, char*);
int MapUrl_VmsToUrl (char*, char*, boolean);
int MapUrl_VirtualPath (char*, char*, char*, int);

/*****************************************************************************/
