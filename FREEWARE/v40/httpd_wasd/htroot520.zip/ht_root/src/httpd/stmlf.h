/*****************************************************************************/
/*
                                  StmLF.h

Function prototypes for variable-to-stream-LF file conversion module.

*/
/*****************************************************************************/

StmLfBegin (char*, char*, int, boolean);
StmLfEnd (struct StreamLfStruct*);
StmLfNextRecord (struct RAB*); 
StmLfNextRecordAst (struct RAB*); 
StmLfLog (struct StreamLfStruct*, char*, int);

/*****************************************************************************/
