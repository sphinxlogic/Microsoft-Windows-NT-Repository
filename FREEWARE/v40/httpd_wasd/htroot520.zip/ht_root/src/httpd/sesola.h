/*****************************************************************************/
/*
                                 SeSoLa.h

Function prototypes for Secure Sockets Layer module.

*/
/*****************************************************************************/

SeSoLaAccept (struct RequestStruct*);
SeSoLaBegin (struct RequestStruct*);
SeSoLaEnd (struct RequestStruct*);
SeSoLaError (struct RequestStruct*, char*);
SeSoLaInit ();
SeSoLaRead (struct RequestStruct*, void*, char*, int);
SeSoLaReport (struct RequestStruct*, void*);
SeSoLaWrite (struct RequestStruct*, void*, char*, int);

/*****************************************************************************/

