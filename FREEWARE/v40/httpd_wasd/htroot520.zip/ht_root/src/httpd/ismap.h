/*****************************************************************************/
/*
                                  IsMap.h

Function prototypes for image mapping module.

*/
/*****************************************************************************/

IsMapBegin (struct RequestStruct*, void*, char*);
IsMapEnd (struct RequestStruct*);
IsMapNextRecordAST (struct RAB*);
IsMapParseLine (struct RequestStruct*);
IsMapExplainError (struct RequestStruct*, char*, char*, int);

/*****************************************************************************/
