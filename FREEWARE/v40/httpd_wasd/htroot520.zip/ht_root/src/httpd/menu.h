/*****************************************************************************/
/*
                                  Menu.h

Function prototypes for menu module.

*/
/*****************************************************************************/

MenuBegin (struct RequestStruct*, void*, void*, char*);
MenuBeginImplicitDescription (struct RequestStruct*);
MenuContents (struct RAB*);
MenuDescription (struct RequestStruct*, int);
MenuEnd (struct RequestStruct*);
MenuEndImplicitDescription (struct RequestStruct*);
MenuFileDescription (struct RequestStruct*, void*, char*);
MenuFileDescriptionNext (struct RequestStruct*);
MenuFileDescriptionOf (struct FAB*);
MenuFileDescriptionDone (struct RequestStruct*);
MenuItems (struct RequestStruct*);
MenuNextContents (struct RequestStruct*);
MenuTitle (struct RequestStruct*);
MenuSearchItem (struct RequestStruct*, void*, char*, char*, char*);

/*****************************************************************************/
