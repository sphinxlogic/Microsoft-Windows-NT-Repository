/*****************************************************************************/
/*
                                  Control.h

Function prototypes for HTTPd control module.

*/
/*****************************************************************************/

int ControlCommand (char*);
ControlCommandTimeoutAST ();
int ControlHttpd ();
ControlMbxReadAST ();
ControlMbxWrite (char*);
ControlMbxWriteAST ();
ControlMessage (char*);

/*****************************************************************************/
