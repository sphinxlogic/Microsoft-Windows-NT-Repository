#ifndef __CCISERVER_H__
#define __CCISERVER_H__

#include "cci.h"

#ifdef VMS
/* VMS does not permit long names, so to avoid compilation warnings ... */
#define MCCIReturnListenPortSocketDescriptor    MCCIReturnListenPortSocketDescr
#endif /* VMS, BSN */

extern int MCCIServerInitialize();
extern MCCIPort MCCICheckAndAcceptConnection();
extern int MCCISendResponseLine();
extern int MCCIIsThereInput();
extern int MCCIReadInputMessage();

typedef struct {
	MCCIPort client;
	int status;
	char *url;
} cciStat;			/* ejb 03/09/95 */

#endif
