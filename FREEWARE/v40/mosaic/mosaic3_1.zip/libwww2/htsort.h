extern void HTSortInit (void);
extern void HTSortAdd (char *str);
extern void HTSortSort (void);
extern int HTSortCurrentCount (void);
extern char *HTSortFetch (int i);
