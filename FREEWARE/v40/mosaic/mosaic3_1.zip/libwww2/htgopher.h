/*                      GOPHER ACCESS                           HTGopher.h
**                      =============
**
** History:
**       8 Jan 92       Adapted from HTTP TBL
*/

#ifndef HTGOPHER_H
#define HTGOPHER_H

#include "HTAccess.h"
#include "HTAnchor.h"

extern HTProtocol HTGopher;

#endif /* HTGOPHER_H */
