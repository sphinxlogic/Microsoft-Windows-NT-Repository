/* This file is Copyright (C) 1996 - G.Dauphin
 * See the file "license.mMosaic" for information on usage and redistribution
 * of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 */

extern	void EndForm(HTMLWidget hw, MarkInfo **mptr,
        PhotoComposeContext *pcc);
extern	void BeginForm(HTMLWidget hw, MarkInfo **mptr,
        PhotoComposeContext *pcc);

extern	void FormInputField(HTMLWidget hw, MarkInfo **mptr,
        PhotoComposeContext *pcc);

extern	void FormTextAreaBegin(HTMLWidget hw, MarkInfo **mptr,
        PhotoComposeContext *pcc);
extern	void FormTextAreaEnd(HTMLWidget hw, MarkInfo **mptr,
        PhotoComposeContext *pcc);
extern	void FormSelectOptionField(HTMLWidget hw, MarkInfo **mptr,
        PhotoComposeContext *pcc);
extern	void FormSelectBegin(HTMLWidget hw, MarkInfo **mptr,
        PhotoComposeContext *pcc);
extern	void FormSelectEnd(HTMLWidget hw, MarkInfo **mptr,
        PhotoComposeContext *pcc);

