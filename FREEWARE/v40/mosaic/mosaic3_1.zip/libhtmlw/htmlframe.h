extern void FramePlace(HTMLWidget hw, MarkInfo *mptr, PhotoComposeContext *pcc);

