#ifndef HTML_FONT_H
#define HTML_FONT_H

extern void SetFontSize(HTMLWidget hw, PhotoComposeContext *pcc, int refresh);
FontRec *PushFont(PhotoComposeContext *pcc);
extern XFontStruct *PopFont(PhotoComposeContext *pcc);
extern void InitFontStack(HTMLWidget hw);

#endif /* HTML_FONT_H */
