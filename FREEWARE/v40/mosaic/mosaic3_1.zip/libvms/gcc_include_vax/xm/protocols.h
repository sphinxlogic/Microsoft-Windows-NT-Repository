/* <Xm/protocols.h>
 */
#ifndef _XM_PROTOCOLS_H
#define _XM_PROTOCOLS_H

#include "decw$include:protocols.h"

#endif	/*_XM_PROTOCOLS_H*/
