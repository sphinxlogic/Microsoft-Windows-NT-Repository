/* <Xm/DragDrop.h>
 */
#ifndef _XM_DRAGDROP_H
#define _XM_DRAGDROP_H

#include "decw$include:dragdrop.h"

#endif	/*_XM_DRAGDROP_H*/
