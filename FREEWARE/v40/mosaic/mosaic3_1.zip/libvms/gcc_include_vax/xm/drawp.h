/* <Xm/DrawP.h>
 */
#ifndef _XM_XmDrawP_H
#define _XM_XmDrawP_H

#include "decw$include:drawp.h"

#endif	/*_XM_XmDrawP_H*/
