/* <Xm/atommgr.h>
 */
#ifndef _XM_ATOMMGR_H
#define _XM_ATOMMGR_H

#include "decw$include:atommgr.h"

#endif	/*_XM_ATOMMGR_H*/
