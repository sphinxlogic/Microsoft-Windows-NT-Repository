/* <Xmu/atoms.h>
 */
#ifndef _XMU_ATOMS_H
#define _XMU_ATOMS_H

#include "XMU:atoms.h"

#endif	/*_XMU_ATOMS_H*/
