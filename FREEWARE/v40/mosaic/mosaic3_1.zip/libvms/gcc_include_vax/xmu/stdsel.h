/* <Xmu/stdsel.h>
 */
#ifndef _XMU_STDSEL_H
#define _XMU_STDSEL_H

#include "XMU:stdsel.h"

#endif	/*_XMU_STDSEL_H*/
