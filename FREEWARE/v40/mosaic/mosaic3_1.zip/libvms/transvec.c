/*  ABSTRACT:	This module is the source for the jacket image used
 */

char *shell$translate_vms(value_1)
{
  return (char *)decc$translate_vms(value_1);
}
