#include "xisola.h"

void affichage(val,tableau)

int val;
Widget         tableau;

{
	Arg	       ar[10];

	XtSetArg(ar[0],XtNbitmap,pixtab[val]);
	XtSetValues(tableau,ar,1);

};

void single(w,client_data,call_data)
Widget w;
XtPointer client_data,call_data;
{
	is_single=!(is_single);
	if (is_single) { 
		XtSetArg(ar[0],XtNlabel,"SINGLE"); 
	} else { 
		XtSetArg(ar[0],XtNlabel," TWO  "); 
	};
	XtSetValues(wsingle,ar,1);
};


void quit(w,client_data,call_data)
Widget w;
XtPointer client_data,call_data;
{
	exit(0);
};

void compuplay(w,client_data,call_data)
Widget w;
XtPointer client_data,call_data;
{
	int mi,mj,dump,di,dj,ii,jj;

if (player)
	{
	mi=white_i;
	mj=white_j;
	di=black_i;
	dj=black_j;
	}
else
	{
	di=white_i;
	dj=white_j;
	mi=black_i;
	mj=black_j;
	};
if (liberte(play_board,mi,mj)&&mode&&(!the_end))/* on ne joue que si on peut  */
	{					/* et qu'on est en phase move */
	play_board[mi][mj]=0;			/* et si the_end est faux     */
	dump=move(play_board,mi,mj);		/* mouvement du pion */
	affichage(0,tabl[mi][mj]);
	jj=dump%10;
	ii=(dump-jj)/10;
	if (!play_board[ii][jj])
		{
		mi=ii;
		mj=jj;
		};
	play_board[mi][mj]=3-player;
	affichage(play_board[mi][mj],tabl[mi][mj]);

	dump=move(play_board,di,dj);		/* destruction d'une case */
	dj=dump%10;
	di=(dump-dj)/10;
	play_board[di][dj]=1;
	affichage(play_board[di][dj],tabl[di][dj]);
	if (player)
		{
		white_i=mi;
		white_j=mj;
		}
	else
		{
		black_i=mi;
		black_j=mj;
		};
	player=!player;
	};

if (player)
	{
	XtSetArg(ar[0],XtNlabel,"it's you to play,white...");
	}
else
	{
	XtSetArg(ar[0],XtNlabel,"it's you to play,black...");
	};
XtSetValues(wmesg,ar,1);

if (!(liberte(play_board,white_i,white_j)))
	{                       
	XtSetArg(ar[0],XtNlabel," BLACK IS THE WINNER !!! ");
	XtSetValues(wmesg,ar,1);
        XtSetArg(ar[0],XtNlabel,"   GAME OVER  ");
	XtSetValues(wmode,ar,1);
	the_end=1;
	};

if (!(liberte(play_board,black_i,black_j)))
	if (liberte(play_board,white_i,white_j))
		{                       
  	        XtSetArg(ar[0],XtNlabel," WHITE IS THE WINNER !!! ");
		XtSetValues(wmesg,ar,1);
 	        XtSetArg(ar[0],XtNlabel,"   GAME OVER  ");
		XtSetValues(wmode,ar,1);
		the_end=1;
		}
	else
		{
	        XtSetArg(ar[0],XtNlabel,"      A DRAW .......     ");
		XtSetValues(wmesg,ar,1);
	        XtSetArg(ar[0],XtNlabel,"   GAME OVER  ");
		XtSetValues(wmode,ar,1);
		the_end=1;
		};
};

void play(w,client_data,call_data)
Widget w;
XtPointer client_data,call_data;
{
	int ii,jj,dump,di,dj,ok;

	dump= (int) client_data;
	jj= dump % 10;
	ii= (dump-jj)/10;
	
	ok=0;
	if (mode)  
		{
		if (player)
			{
			  if (!(abs(ii-white_i)/2+abs(jj-white_j)/2)&&(!(play_board[ii][jj]))&&(!((ii==white_i)&&(jj==white_j))))
				{
				play_board[white_i][white_j]=0;
				affichage(0,tabl[white_i][white_j]);
				white_i=ii;
				white_j=jj;
				play_board[ii][jj]=2;
				affichage(2,tabl[white_i][white_j]);
				mode=!mode;
			        XtSetArg(ar[0],XtNlabel,"destroy phase ");
				XtSetValues(wmode,ar,1);
				};
			}
		else
			{
			  if (!(abs(ii-black_i)/2+abs(jj-black_j)/2)&&(!(play_board[ii][jj]))&&(!((ii==black_i)&&(jj==black_j))))
				{
				play_board[black_i][black_j]=0;
				affichage(0,tabl[black_i][black_j]);
				black_i=ii;
				black_j=jj;
				play_board[ii][jj]=2;
				affichage(3,tabl[black_i][black_j]);
				mode=!mode;
			        XtSetArg(ar[0],XtNlabel,"destroy phase ");
				XtSetValues(wmode,ar,1);
				};
			};
		}
		else
		{
		if (!(play_board[ii][jj]))
			{
			play_board[ii][jj]=1;
			affichage(1,tabl[ii][jj]);
			mode=!mode;
			player=!player;
		        XtSetArg(ar[0],XtNlabel,"movement phase");
			XtSetValues(wmode,ar,1);
			if (player)
				{
			        XtSetArg(ar[0],XtNlabel,"it's you to play,white...");
				}
			else
				{
			        XtSetArg(ar[0],XtNlabel,"it's you to play,black...");
				};
			XtSetValues(wmesg,ar,1);
			ok=1;
			};
		};
	if (!(liberte(play_board,white_i,white_j)))
		{                       
	        XtSetArg(ar[0],XtNlabel," BLACK IS THE WINNER !!! ");
		XtSetValues(wmesg,ar,1);
	        XtSetArg(ar[0],XtNlabel,"   GAME OVER  ");
		XtSetValues(wmode,ar,1);
		the_end=1;
		};

	if (!(liberte(play_board,black_i,black_j)))
		if (liberte(play_board,white_i,white_j))
			{                       
	  	        XtSetArg(ar[0],XtNlabel," WHITE IS THE WINNER !!! ");
			XtSetValues(wmesg,ar,1);
	 	        XtSetArg(ar[0],XtNlabel,"   GAME OVER  ");
			XtSetValues(wmode,ar,1);
			the_end=1;
			}
		else
			{
	  	        XtSetArg(ar[0],XtNlabel,"      A DRAW .......     ");
			XtSetValues(wmesg,ar,1);
	 	        XtSetArg(ar[0],XtNlabel,"   GAME OVER  ");
			XtSetValues(wmode,ar,1);
			the_end=1;
			};

if ((!the_end)&&is_single&&ok)
	{
	compuplay(w,client_data,call_data);
	};
};

void reset(w,client_data,call_data)
Widget w;
XtPointer client_data,call_data;
{
int i,j;

for(i=1;i<=8;i++)
  for(j=1;j<=6;j++)
	{
	XtSetArg(args[0],XtNbitmap,pixtab[0]);
	XtSetValues(tabl[i][j],args,1);
	};

 XtSetArg(args[0],XtNbitmap,pixtab[2]);
 XtSetValues(tabl[1][3],args,1);

 XtSetArg(args[0],XtNbitmap,pixtab[3]);
 XtSetValues(tabl[8][4],args,1);

  for(i=0;i<8;i++)
     for(j=0;j<8;j++)
	play_board[i][j]=0;

  for(i=0;i<10;i++)
	{
	play_board[i][0]=1;
	play_board[i][7]=1;
	};

  for(i=0;i<8;i++)
	{
	play_board[0][i]=1;
	play_board[9][i]=1;
	};

  player=1;
  mode=1;
  the_end=0;
  white_i=1;
  white_j=3;
  black_i=8;
  black_j=4;
  play_board[1][3]=2;
  play_board[8][4]=3;

  XtSetArg(ar[0],XtNlabel,"movement phase");
  XtSetValues(wmode,ar,1);
  XtSetArg(ar[0],XtNlabel,"it's you to play,white...");
  XtSetValues(wmesg,ar,1);
};

