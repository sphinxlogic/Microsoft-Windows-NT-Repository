#include "types.h"

int liberte(play_board,i,j)

board play_board;
int i,j;

{
int a;

a =!play_board[i-1][j]+!play_board[i+1][j];
a+=!play_board[i-1][j-1]+!play_board[i+1][j-1];
a+=!play_board[i-1][j+1]+!play_board[i+1][j+1];
a+=!play_board[i][j-1]+!play_board[i][j+1];

return(a);
};
