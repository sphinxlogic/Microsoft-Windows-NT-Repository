#include "types.h"
#include "strategie.h"
#include "val_strategie.h"

int stratcalc(play_board,depth,i,j)

board play_board;
int i,j,depth;
{
int a;

if (!(play_board[i][j])&&(i!=0)&&(j!=0)&&(i!=9)&&(j!=7))
	{
	if (depth)
		{
		a=stratcalc(play_board,depth-1,i-1,j);
		a+=stratcalc(play_board,depth-1,i+1,j);
		a+=stratcalc(play_board,depth-1,i-1,j-1);
		a+=stratcalc(play_board,depth-1,i,j-1);
		a+=stratcalc(play_board,depth-1,i+1,j-1);
		a+=stratcalc(play_board,depth-1,i-1,j+1);
		a+=stratcalc(play_board,depth-1,i,j+1);
		a+=stratcalc(play_board,depth-1,i+1,j+1);
		a+=!play_board[i][j];
		}
	else
		{
		a=liberte(play_board,i,j);
		};
	return(a);
	}
else
	{
	return(0);
	};
}

int move(play_board,i,j)

board play_board;
int i,j;
{
int a,ii,jj,dump;

a = -1000;
dump=stratcalc(play_board,PROF,i-1,j-1);
if (dump>a)
	{
	ii=i-1;
	jj=j-1;
	a=dump;
	};
dump=stratcalc(play_board,PROF,i-1,j);
if (dump>a)
	{	
	ii=i-1;
	jj=j;
	a=dump;
	};
dump=stratcalc(play_board,PROF,i-1,j+1);
if (dump>a)
	{
	ii=i-1;
	jj=j+1;
	a=dump;
	};
dump=stratcalc(play_board,PROF,i,j-1);
if (dump>a)
	{
	ii=i;
	jj=j-1;
	a=dump;
	};
dump=stratcalc(play_board,PROF,i,j+1);
if (dump>a)
	{
	ii=i;
	jj=j+1;
	a=dump;
	};
dump=stratcalc(play_board,PROF,i+1,j-1);
if (dump>a)
	{
	ii=i+1;
	jj=j-1;
	a=dump;
	};
dump=stratcalc(play_board,PROF,i+1,j);
if (dump>a)
	{
	ii=i+1;
	jj=j;
	a=dump;
	};
dump=stratcalc(play_board,PROF,i+1,j+1);
if (dump>a)
	{
	ii=i+1;
	jj=j+1;
	a=dump;
	};
dump=10*ii+jj;
return(dump);
}
