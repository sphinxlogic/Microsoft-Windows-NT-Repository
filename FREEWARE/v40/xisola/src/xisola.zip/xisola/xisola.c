#include "xisola.h"

#include "vide.bm"
#include "destroyed.bm"
#include "white.bm"
#include "black.bm"


static String fallback_resources[] = { 

	"XIsola.wboard.borderWidth: 		    4",
	"XIsola.wmesg.borderWidth: 		    0",


	"XIsola.wwarn.shapeStyle:		    oval",
	"XIsola.wreset.shapeStyle:		    oval",
	"XIsola.wplay.shapeStyle:		    oval",
	"XIsola.wquit.shapeStyle:		    oval",
	"XIsola.wsingle.shapeStyle:		    oval",

	NULL
};



main(argc,argv)
int    argc;
char **argv;
{
car=0;
XtSetArg(ar[car],XtNwidth,600);car++;
XtSetArg(ar[car],XtNheight,400);car++;
XtSetArg(ar[car],XtNtitle,"Xisola (ver 0.1 draft 1) by The Spif (1993)");car++;
toplevel=XtAppInitialize(&app_context,"XIsola",NULL,0,&argc,argv,fallback_resources,NULL,0);
XtSetValues(toplevel,ar,car);

interm=XtCreateManagedWidget("Interm",formWidgetClass,toplevel,NULL,0);
wboard=XtCreateManagedWidget("BOard",formWidgetClass,interm,NULL,0);

XtSetArg(ar[0],XtNwidth,400);
XtSetValues(wboard,ar,car);

XtSetArg(ar[0],XtNfromHoriz,wboard);
XtSetArg(ar[1],XtNfromVert,NULL);
wplay=XtCreateManagedWidget(" PLAY ",commandWidgetClass,interm,ar,2);
XtAddCallback(wplay,XtNcallback,compuplay,0);

XtSetArg(ar[0],XtNfromHoriz,wboard);
XtSetArg(ar[1],XtNfromVert,wplay);
wreset=XtCreateManagedWidget("RESET ",commandWidgetClass,interm,ar,2);
XtAddCallback(wreset,XtNcallback,reset,0);

XtSetArg(ar[0],XtNfromHoriz,wboard);
XtSetArg(ar[1],XtNfromVert,wreset);
wsingle=XtCreateManagedWidget("SINGLE",commandWidgetClass,interm,ar,2);
XtAddCallback(wsingle,XtNcallback,single,0);

XtSetArg(ar[0],XtNfromHoriz,wboard);
XtSetArg(ar[1],XtNfromVert,wsingle);
wquit=XtCreateManagedWidget(" QUIT ",commandWidgetClass,interm,ar,2);
XtAddCallback(wquit,XtNcallback,quit,0);

XtSetArg(ar[0],XtNfromHoriz,NULL);
XtSetArg(ar[1],XtNfromVert,wboard);
wmode=XtCreateManagedWidget("movement phase",labelWidgetClass,interm,ar,2);

XtSetArg(ar[0],XtNfromHoriz,wmode);
XtSetArg(ar[1],XtNfromVert,wboard);
wmesg=XtCreateManagedWidget("it's you to play,white...",labelWidgetClass,interm,ar,2);

XtSetArg(ar[0],XtNfromHoriz,wmesg);
XtSetArg(ar[1],XtNfromVert,wboard);
winfo=XtCreateManagedWidget("         ",labelWidgetClass,interm,ar,2);

for(i=1;i<=8;i++)
  for(j=1;j<=6;j++)
	{
	sprintf(buf,"case %d,%d",i,j);
	card=0;
	XtSetArg(args[card],XtNwidth,50);card++;
	XtSetArg(args[card],XtNheight,50);card++;
	if ((i/=1) || (j/=1))
		{
		XtSetArg(args[card],XtNfromHoriz,tabl[i-1][j]);card++;
		XtSetArg(args[card],XtNfromVert,tabl[i][j-1]);card++;
		};
      tabl[i][j]=XtCreateManagedWidget(buf,commandWidgetClass,wboard,args,card);
      dump=i*10+j;
      XtAddCallback(tabl[i][j],XtNcallback,play,(XtPointer) dump);
};
pixtab[0] =XCreateBitmapFromData(XtDisplay(toplevel),RootWindowOfScreen(XtScreen(toplevel)),vide_bits     ,vide_width     ,vide_height     );
pixtab[1] =XCreateBitmapFromData(XtDisplay(toplevel),RootWindowOfScreen(XtScreen(toplevel)),destroyed_bits,destroyed_width,destroyed_height);
pixtab[2] =XCreateBitmapFromData(XtDisplay(toplevel),RootWindowOfScreen(XtScreen(toplevel)),white_bits    ,white_width    ,white_height    );
pixtab[3] =XCreateBitmapFromData(XtDisplay(toplevel),RootWindowOfScreen(XtScreen(toplevel)),black_bits    ,black_width    ,black_height    );

for(i=1;i<=8;i++)
  for(j=1;j<=6;j++)
	{
	XtSetArg(args[0],XtNbitmap,pixtab[0]);
	XtSetValues(tabl[i][j],args,1);
	};

 XtSetArg(args[0],XtNbitmap,pixtab[2]);
 XtSetValues(tabl[1][3],args,1);

 XtSetArg(args[0],XtNbitmap,pixtab[3]);
 XtSetValues(tabl[8][4],args,1);

/* initialisation du jeu */

  for(i=0;i<8;i++)
     for(j=0;j<8;j++)
	play_board[i][j]=0;

  for(i=0;i<10;i++)
	{
	play_board[i][0]=1;
	play_board[i][7]=1;
	};

  for(i=0;i<8;i++)
	{
	play_board[0][i]=1;
	play_board[9][i]=1;
	};

  player=1;
  is_single=1;
  mode=1;
  white_i=1;
  white_j=3;
  black_i=8;
  black_j=4;
  play_board[1][3]=2;
  play_board[8][4]=3;



XtRealizeWidget(toplevel);
XtAppMainLoop(app_context);
}

