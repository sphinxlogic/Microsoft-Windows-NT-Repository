#include "xbill.h"

void insert (data_ptr d, list *root) {
	node *temp=(node *)malloc(sizeof(node));
	temp->next = *root;
	temp->data = d;
	if (*root) (*root)->prev=temp;
	*root = temp;
}

void delete (node *n, list *root) {
	if (n==*root) *root = n->next;
	else n->prev->next=n->next;
	if (n->next) n->next->prev=n->prev;
	free(n);
}

void move (node *n, list *src, list *dest) { 
	if (n==*src) *src = n->next;
	else n->prev->next=n->next;
	if (n->next) n->next->prev=n->prev;
	
	n->next = *dest;
	n->prev = NULL;
	if (*dest) (*dest)->prev = n;
	*dest = n;
}

void init (list *l) {l=NULL;}

int empty (list l) {return l==NULL;}

void destroy (list *l) {
	while (!empty(*l)) delete (*l, l);
}

int count (list l) {
	int i;
	node *temp=l;
	for (i=0; temp; i++, temp=temp->next);
	return i;
}
