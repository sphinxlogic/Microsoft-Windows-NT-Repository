#ifndef PIXMAPS_H
#define PIXMAPS_H

void init_pixmaps(int back);
void load_bill_pixmaps (horde *bill, XpmAttributes attr);
void load_systems_pixmaps_and_bitmaps(library *systems, XpmAttributes attr);
void load_net_pixmaps (network *net, library *systems, XpmAttributes attr);
void load_cursors (Pixmap *defaultcursor, Pixmap *downcursor);
void load_dialog_pixmaps (Pixmap *about_pix, Pixmap *thanks_pix,
	Pixmap *rules_pix, Pixmap *story_pix, Pixmap *freeware_pix,
	XpmAttributes attr);
void load_icon(Pixmap *icon, XpmAttributes attr);

#endif
