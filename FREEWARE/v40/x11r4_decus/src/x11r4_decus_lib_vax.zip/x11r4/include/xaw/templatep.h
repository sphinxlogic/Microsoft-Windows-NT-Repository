#ifdef vax11c
#include "copyright.h"
#else
#include <X11/copyright.h>
#endif /* vax11c */

/* $XConsortium: TemplateP.h,v 1.4 89/07/21 01:41:48 kit Exp $ */
/* Copyright	Massachusetts Institute of Technology	1987, 1988 */

#ifndef _TemplateP_h
#define _TemplateP_h

#include "Template.h"
/* include superclass private header file */
#ifdef vax11c
#include <decw$include/CoreP.h>
#else
#include <X11/CoreP.h>
#endif /* vax11c */

/* define unique representation types not found in <X11/StringDefs.h> */

#define XtRTemplateResource "TemplateResource"

typedef struct {
    int empty;
} TemplateClassPart;

typedef struct _TemplateClassRec {
    CoreClassPart	core_class;
    TemplateClassPart	template_class;
} TemplateClassRec;

#ifndef XAW_TEMPLATE_WIDGET

#ifdef vax11c
globalref TemplateClassRec templateClassRec;
#else
extern TemplateClassRec templateClassRec;
#endif /* vax11c */

#endif /* !XAW_TEMPLATE_WIDGET */

typedef struct {
    /* resources */
    char* resource;
    /* private state */
} TemplatePart;

typedef struct _TemplateRec {
    CorePart		core;
    TemplatePart	template;
} TemplateRec;

#endif /* _TemplateP_h */
