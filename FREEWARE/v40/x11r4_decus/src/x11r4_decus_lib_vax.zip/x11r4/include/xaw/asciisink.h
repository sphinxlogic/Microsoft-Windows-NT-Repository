/*
 * $XConsortium: AsciiSink.h,v 1.3 89/11/01 17:33:17 kit Exp $
 */

/***********************************************************
Copyright 1987, 1988 by Digital Equipment Corporation, Maynard, Massachusetts,
and the Massachusetts Institute of Technology, Cambridge, Massachusetts.

                        All Rights Reserved

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in 
supporting documentation, and that the names of Digital or MIT not be
used in advertising or publicity pertaining to distribution of the
software without specific, written prior permission.  

DIGITAL DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL
DIGITAL BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
SOFTWARE.

******************************************************************/

#ifndef _XawAsciiSink_h
#define _XawAsciiSink_h

/***********************************************************************
 *
 * AsciiSink Object
 *
 ***********************************************************************/

#ifdef vax11c
#include "TextSink.h"
#else
#include <X11/Xaw/TextSink.h>
#endif /* vax11c */

/* Resources:

 Name		     Class		RepType		Default Value
 ----		     -----		-------		-------------
 echo                Output             Boolean         True
 displayNonprinting  Output             Boolean         True

*/

#define XtCOutput "Output"

#define XtNdisplayNonprinting "displayNonprinting"
#define XtNecho "echo"

/* Class record constants */

#ifndef XAW_ASCII_SINK_OBJECT

#ifdef vax11c
globalref WidgetClass asciiSinkObjectClass;
#else
extern WidgetClass asciiSinkObjectClass;
#endif /* vax11c */

#endif /* !XAW_ASCII_SINK_OBJECT */

typedef struct _AsciiSinkClassRec *AsciiSinkObjectClass;
typedef struct _AsciiSinkRec      *AsciiSinkObject;

/************************************************************
 *
 * Public Functions.
 *
 ************************************************************/

#ifdef XAW_BC
/************************************************************
 *  For Compatability Only.

#define XtAsciiSinkCreate          XawAsciiSinkCreate
#define XtAsciiSinkDestroy         XawAsciiSinkDestroy

#define XawTextSink Widget
#define XtTextSink XawTextSink

extern XawTextSink XawAsciiSinkCreate(); /* parent, args, num_args */
    /* Widget parent;		*/
    /* ArgList args;		*/
    /* Cardinal num_args;	*/

#define XawAsciiSinkDestroy XtDestroyWidget

#endif /* XAW_BC */

#endif /* _XawAsciiSrc_h */
/* DON'T ADD STUFF AFTER THIS #endif */
