
/*
**  jazz - a midi sequencer for Linux
**
**  Copyright (C) 1994-1996 Andreas Voss (andreas@avix.rhein-neckar.de)
**
**  Copyright (C) 1995-1996 Per Sigmond (Per.Sigmond@hia.no)
**
**  This program is free software; you can redistribute it and/or modify
**  it under the terms of the GNU General Public License as published by
**  the Free Software Foundation; either version 2 of the License, or
**  (at your option) any later version.
**
**  This program is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU General Public License for more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program; if not, write to the Free Software
**  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "wx.h"
#pragma hdrstop

#include "dialogs.h"
#include "song.h"
#include "command.h"
#include "eventwin.h"
#include "track.h"
#include "events.h"
#include "util.h"
#include "jazz.h"

// **************************************************************************
// Quantize
// *************************************************************************

Bool tQuantizeDlg::NoteStart = 1;
Bool tQuantizeDlg::NoteLength = 0;
long tQuantizeDlg::QntStep = 16;

static tNamedValue QntSteps[] =
{
  { "1/8",   8 },
  { "1/12", 12 },
  { "1/16", 16 },
  { "1/24", 24 },
  { "1/32", 32 },
  { "1/48", 48 },
  { "1/96", 96 },
  {  0,      1  }
};


tQuantizeDlg::tQuantizeDlg(tEventWin *w, tFilter *f)
   : wxForm( USED_WXFORM_BUTTONS ), Steps("steps", QntSteps, &QntStep)
{
  Filter = f;
  Song = f->Song;
  EventWin = w;
}



void tQuantizeDlg::OnOk()
{
  Steps.GetValue();
  int step = Song->TicksPerQuarter * 4 / QntStep;
  tCmdQuantize qnt(Filter, step);
  qnt.NoteStart = NoteStart;
  qnt.NoteLength = NoteLength;
  qnt.Execute();
  EventWin->Redraw();
  if (EventWin->NextWin)
 	 EventWin->NextWin->Redraw();
  wxForm::OnOk();
}

void tQuantizeDlg::OnHelp()
{
#ifndef VMS
	HelpInstance->LoadFile( HelpPathList.FindValidPath("jazz") );
  	if (EventWin->NextWin)
		HelpInstance->KeywordSearch("Track window");
	else
		HelpInstance->KeywordSearch("Piano window");
#endif
}

void tQuantizeDlg::EditForm(wxPanel *panel)
{
  Add(Steps.mkFormItem(100));
  Add(wxMakeFormNewLine());
  Add(wxMakeFormBool("Note start", &NoteStart));
  Add(wxMakeFormBool("Note length", &NoteLength));
  AssociatePanel(panel);
}


// **************************************************************************
// Cleanup
// *************************************************************************

long tCleanupDlg::lowLimit = 48;

static tNamedValue limitSteps[] =
{
  { "1/8",   8 },
  { "1/12", 12 },
  { "1/16", 16 },
  { "1/24", 24 },
  { "1/32", 32 },
  { "1/48", 48 },
  { "1/96", 96 },
  {  0,      1  }
};


tCleanupDlg::tCleanupDlg(tEventWin *w, tFilter *f)
   : wxForm( USED_WXFORM_BUTTONS ), Steps("Shortest note", limitSteps, &lowLimit)
{
  Filter = f;
  Song = f->Song;
  EventWin = w;
}



void tCleanupDlg::OnOk()
{
  Steps.GetValue();
  int limit = Song->TicksPerQuarter * 4 / lowLimit;
  tCmdCleanup cln(Filter, limit);
  cln.Execute();
  EventWin->Redraw();
  if (EventWin->NextWin)
 	 EventWin->NextWin->Redraw();
  wxForm::OnOk();
}

void tCleanupDlg::OnHelp()
{
#ifndef VMS
	HelpInstance->LoadFile( HelpPathList.FindValidPath("jazz") );
	HelpInstance->KeywordSearch("Cleanup");
#endif
}

void tCleanupDlg::EditForm(wxPanel *panel)
{
  panel->SetLabelPosition(wxVERTICAL);
  Add(Steps.mkFormItem(100));
  Add(wxMakeFormNewLine());
  AssociatePanel(panel);
}

// **************************************************************************
// SearchReplace
// *************************************************************************

long tSearchReplaceDlg::frCtrl = 1;
long tSearchReplaceDlg::toCtrl = 1;

tSearchReplaceDlg::tSearchReplaceDlg(tEventWin *w, tFilter *f)
   : wxForm( USED_WXFORM_BUTTONS ),
     frList("Search", ControlNames, &frCtrl),
     toList("Replace", ControlNames, &toCtrl)
{
  Filter = f;
  Song = f->Song;
  EventWin = w;
}

void tSearchReplaceDlg::OnOk()
{
  frList.GetValue();
  toList.GetValue();
  tCmdSearchReplace sr(Filter, frCtrl-1, toCtrl-1);
  sr.Execute();
  EventWin->Redraw();
  if (EventWin->NextWin)
    EventWin->NextWin->Redraw();
  wxForm::OnOk();
}

void tSearchReplaceDlg::OnHelp()
{
#ifndef VMS
  HelpInstance->LoadFile( HelpPathList.FindValidPath("jazz") );
  HelpInstance->KeywordSearch("Search Replace");
#endif
}

void tSearchReplaceDlg::EditForm(wxPanel *panel)
{
  //panel->SetLabelPosition(wxVERTICAL);
  Add(wxMakeFormMessage("Search and replace controller types"));
  Add(wxMakeFormNewLine());
  Add(frList.mkFormItem(200));
  Add(toList.mkFormItem(200));
  //Add(wxMakeFormNewLine());
  AssociatePanel(panel);
}

// **************************************************************************
// Shift
// *************************************************************************

int tShiftDlg::Steps = 0;

tShiftDlg::tShiftDlg(tEventWin *w, tFilter *f, long unit)
: wxForm( USED_WXFORM_BUTTONS )
{
  Filter = f;
  Song = f->Song;
  Unit  = unit;
  EventWin = w;
}



void tShiftDlg::OnOk()
{
  tCmdShift cmd(Filter, Steps * Unit);
  cmd.Execute();
  EventWin->Redraw();
  if (EventWin->NextWin)
  	EventWin->NextWin->Redraw();
  wxForm::OnOk();
}

void tShiftDlg::OnHelp()
{
#ifndef VMS
        HelpInstance->LoadFile( HelpPathList.FindValidPath("jazz") );
	if (EventWin->NextWin)
        	HelpInstance->KeywordSearch("Track window");
	else
        	HelpInstance->KeywordSearch("Piano window");
#endif
}


void tShiftDlg::EditForm(wxPanel *panel)
{
  char buf[100];
  sprintf(buf, "Snap is currently %ld clocks", Unit);
  Add(wxMakeFormMessage(buf));
  Add(wxMakeFormNewLine());
  Add(wxMakeFormShort("Snaps", &Steps, wxFORM_DEFAULT,
                       new wxList(wxMakeConstraintRange(-16.0, 16.0), 0)));
  Add(wxMakeFormNewLine());
  AssociatePanel(panel);
}


// **************************************************************************
// Transpose
// *************************************************************************

static tNamedValue ScaleNames[] =
{
  {"None",     ScaleChromatic},
  {"Selected", ScaleSelected},
  {"C",   0},
  {"C#",  1},
  {"D",   2},
  {"D#",  3},
  {"E",   4},
  {"F",   5},
  {"F#",  6},
  {"G",   7},
  {"G#",  8},
  {"A",   9},
  {"A#", 10},
  {"B",  11},
  { 0,   ScaleChromatic}
};


int tTransposeDlg::Notes  = 0;
long tTransposeDlg::Scale  = ScaleChromatic;
Bool tTransposeDlg::FitIntoScale = 0;

tTransposeDlg::tTransposeDlg(tEventWin *w, tFilter *f)
   : wxForm( USED_WXFORM_BUTTONS ), ScaleDlg("scale", ScaleNames, &Scale)
{
  EventWin = w;
  Filter = f;
  Song   = f->Song;
}


void tTransposeDlg::OnOk()
{
  ScaleDlg.GetValue();
  tCmdTranspose trn(Filter, Notes, Scale, FitIntoScale);
  trn.Execute();
  if (EventWin->NextWin)
  	EventWin->NextWin->Redraw();
  else
  	EventWin->Redraw();
  wxForm::OnOk();
}

void tTransposeDlg::OnHelp()
{
#ifndef VMS
        HelpInstance->LoadFile( HelpPathList.FindValidPath("jazz") );
	if (EventWin->NextWin)
        	HelpInstance->KeywordSearch("Track window");
	else
		HelpInstance->KeywordSearch("Piano window");
#endif
}


void tTransposeDlg::EditForm(wxPanel *panel)
{
  char buf[100];
  int s = tScale::Analyze(Filter);
  sprintf(buf, "selection looks like %s", ScaleNames[s+2].Name);
  Add(wxMakeFormMessage(buf));
  Add(wxMakeFormNewLine());

  Add(wxMakeFormShort("Amount", &Notes, wxFORM_DEFAULT,
                       new wxList(wxMakeConstraintRange(-12.0, 12.0), 0)));
  Add(wxMakeFormNewLine());
  Add(ScaleDlg.mkFormItem(150));
  Add(wxMakeFormBool("Fit into Scale", &FitIntoScale));
  Add(wxMakeFormNewLine());
  AssociatePanel(panel);
}


// **************************************************************************
// SetChannel
// *************************************************************************

int tSetChannelDlg::NewChannel = 1;

tSetChannelDlg::tSetChannelDlg(tFilter *f)
: wxForm( USED_WXFORM_BUTTONS )
{
  Filter = f;
  Song = f->Song;
}



void tSetChannelDlg::OnOk()
{
  if (NewChannel)
  {
    tCmdSetChannel exe(Filter, NewChannel - 1);
    exe.Execute();
  }
  wxForm::OnOk();
}

void tSetChannelDlg::OnHelp()
{
#ifndef VMS
        HelpInstance->LoadFile( HelpPathList.FindValidPath("jazz") );
        HelpInstance->KeywordSearch("Set MIDI Channel");
#endif
}


void tSetChannelDlg::EditForm(wxPanel *panel)
{
  Add(wxMakeFormShort("new Channel", &NewChannel, wxFORM_DEFAULT,
                       new wxList(wxMakeConstraintRange(1.0, 16.0), 0)));
  Add(wxMakeFormNewLine());
  AssociatePanel(panel);
}


// **************************************************************************
// Velocity
// *************************************************************************

int tVelocityDlg::FromValue = 64;
int tVelocityDlg::ToValue = 0;
int tVelocityDlg::Mode = 0;
char *tVelocityDlg::mode_str = 0;

tVelocityDlg::tVelocityDlg(tFilter *f)
: wxForm( USED_WXFORM_BUTTONS )
{
  Filter = f;
  Song = f->Song;
  if (!mode_str)
    mode_str = copystring("Set");
}


void tVelocityDlg::OnOk()
{
  if (!strcmp(mode_str, "Set")) Mode = 0;
  if (!strcmp(mode_str, "Add")) Mode = 1;
  if (!strcmp(mode_str, "Sub")) Mode = 2;
  tCmdVelocity cmd(Filter, FromValue, ToValue, Mode);
  cmd.Execute();
  wxForm::OnOk();
}

void tVelocityDlg::OnHelp()
{
#ifndef VMS
        HelpInstance->LoadFile( HelpPathList.FindValidPath("jazz") );
        HelpInstance->KeywordSearch("Velocity");
#endif
}


void tVelocityDlg::EditForm(wxPanel *panel)
{
  Add(wxMakeFormShort("Start", &FromValue, wxFORM_DEFAULT,
                       new wxList(wxMakeConstraintRange(0.0, 127.0), 0)));
  Add(wxMakeFormNewLine());
  Add(wxMakeFormShort("Stop ", &ToValue, wxFORM_DEFAULT,
                       new wxList(wxMakeConstraintRange(0.0, 127.0), 0)));
  Add(wxMakeFormNewLine());

  Add(wxMakeFormString("Mode", &mode_str, wxFORM_DEFAULT,
                       new wxList(wxMakeConstraintStrings("Set", "Add", "Sub", 0) , 0), NULL, wxHORIZONTAL));
  AssociatePanel(panel);
}


// **************************************************************************
// Length
// *************************************************************************

int tLengthDlg::FromValue = 30;
int tLengthDlg::ToValue = 0;
int tLengthDlg::Mode = 0;
char *tLengthDlg::mode_str = 0;

tLengthDlg::tLengthDlg(tEventWin *w, tFilter *f)
: wxForm( USED_WXFORM_BUTTONS )
{
  Filter = f;
  Song = f->Song;
  EventWin = w;
  if (!mode_str)
    mode_str = copystring("Set");
}


void tLengthDlg::OnOk()
{
  if (!strcmp(mode_str, "Set")) Mode = 0;
  if (!strcmp(mode_str, "Add")) Mode = 1;
  if (!strcmp(mode_str, "Sub")) Mode = 2;
  tCmdLength cmd(Filter, FromValue, ToValue, Mode);
  cmd.Execute();
  EventWin->Redraw();
  if (EventWin->NextWin)
  	EventWin->NextWin->Redraw();
  wxForm::OnOk();
}

void tLengthDlg::OnHelp()
{
#ifndef VMS
        HelpInstance->LoadFile( HelpPathList.FindValidPath("jazz") );
        HelpInstance->KeywordSearch("Length");
#endif
}


void tLengthDlg::EditForm(wxPanel *panel)
{
  char buf[200];
  sprintf(buf, "Ticks per Quarter: %d", (int)Song->TicksPerQuarter);
  Add(wxMakeFormMessage(buf));
  Add(wxMakeFormNewLine());
  Add(wxMakeFormShort("Start", &FromValue, wxFORM_DEFAULT,
                       new wxList(wxMakeConstraintRange(0.1, Song->TicksPerQuarter * 4.0), 0)));
  Add(wxMakeFormNewLine());
  Add(wxMakeFormShort("Stop ", &ToValue, wxFORM_DEFAULT,
                       new wxList(wxMakeConstraintRange(0.0, Song->TicksPerQuarter * 4.0), 0)));
  Add(wxMakeFormNewLine());

  Add(wxMakeFormString("Mode", &mode_str, wxFORM_DEFAULT,
                       new wxList(wxMakeConstraintStrings("Set", "Add", "Sub", 0) , 0), NULL, wxHORIZONTAL));
  AssociatePanel(panel);
}



// *************************************************************************
// Delete
// *************************************************************************

Bool tDeleteDlg::LeaveSpace = 1;

tDeleteDlg::tDeleteDlg(tEventWin *w, tFilter *f)
: wxForm( USED_WXFORM_BUTTONS )
{
  Filter = f;
  EventWin = w;
}


void tDeleteDlg::OnOk()
{
  tCmdErase cmd(Filter, LeaveSpace);
  cmd.Execute();
  EventWin->Redraw();
  if (EventWin->NextWin)
  	EventWin->NextWin->Redraw();
  wxForm::OnOk();
}

void tDeleteDlg::OnHelp()
{
#ifndef VMS
        HelpInstance->LoadFile( HelpPathList.FindValidPath("jazz") );
        HelpInstance->KeywordSearch("Delete");
#endif
}

void tDeleteDlg::EditForm(wxPanel *panel)
{
  Add(wxMakeFormBool("Leave Space", &LeaveSpace));
  AssociatePanel(panel);
}


// ***********************************************************************
// Event-Dialoge
// ***********************************************************************

class tEventDlg : public wxForm
{
  public:

    tTrack    *Track;
    tClockDlg ClockDlg;
    tEventWin *Win;

    tEvent    *Event;
    tEvent    *Copy;

    tEventDlg(tEvent *e, tEventWin *w, tTrack *t);
    virtual void EditForm(wxPanel *panel);
    virtual void OnOk();
    virtual void OnHelp();
    virtual void OnCancel();
};


tEventDlg::tEventDlg(tEvent *e, tEventWin *w, tTrack *t)
  : wxForm( USED_WXFORM_BUTTONS ), ClockDlg(w->Song, "Time: ", e->Clock)
{
  Win   = w;
  Track = t;
  Event = e;
  Copy  = e->Copy();
}

void tEventDlg::EditForm(wxPanel *panel)
{
  Add(ClockDlg.mkFormItem());
  Add(wxMakeFormNewLine());
  AssociatePanel(panel);
}

void tEventDlg::OnCancel()
{
  delete Copy;
  wxForm::OnCancel();
}

void tEventDlg::OnOk()
{
  Copy->Clock = ClockDlg.GetClock();
  Track->Kill(Event);
  Track->Put(Copy);
  Track->Cleanup();
  Win->Redraw();
  if (Win->NextWin)
  	Win->NextWin->Redraw();
  wxForm::OnOk();
}

void tEventDlg::OnHelp()
{
#ifndef VMS
        HelpInstance->LoadFile( HelpPathList.FindValidPath("jazz") );
        HelpInstance->KeywordSearch("Piano Window");
#endif
}

// --------------------------- ChannelEvent ----------------------------


class tChEventDlg : public tEventDlg
{
  public:

    int Channel;

    tChEventDlg(tChannelEvent *e, tEventWin *w, tTrack *t)
      : tEventDlg(e, w, t)
    {
      Channel = e->Channel + 1;		// 1..16
    }
    void EditForm(wxPanel *panel);
    void OnOk();
};

void tChEventDlg::EditForm(wxPanel *panel)
{
  Add(wxMakeFormShort("Channel:", &Channel, wxFORM_DEFAULT, new wxList(wxMakeConstraintRange(1.0, 16.0), 0)));
  Add(wxMakeFormNewLine());
  tEventDlg::EditForm(panel);
}


void tChEventDlg::OnOk()
{
  ((tChannelEvent *)Copy)->Channel = Channel - 1;
  tEventDlg::OnOk();
}

// -------------------------------- Note On -------------------------------

class tKeyOnDlg : public tChEventDlg
{
 public:

  tKeyDlg PitchDlg;
  int Pitch;
  int Veloc;
  int Length;

  tKeyOnDlg(tKeyOn *e, tEventWin *w, tTrack *t);

  void EditForm(wxPanel *panel);
  void OnOk();
};


tKeyOnDlg::tKeyOnDlg(tKeyOn *e, tEventWin *w, tTrack *t)
  : tChEventDlg(e, w, t),
    PitchDlg("Pitch:", e->Key)
{
  Event = e;
  Veloc = e->Veloc;
  Pitch = e->Key;
  Length = e->Length;
}


void tKeyOnDlg::OnOk()
{
  tKeyOn *k = (tKeyOn *)Copy;
  k->Key = PitchDlg.GetKey();
  k->Veloc = Veloc;
  k->Length = Length;
  tChEventDlg::OnOk();
}

void tKeyOnDlg::EditForm(wxPanel *panel)
{
  Add(PitchDlg.mkFormItem());
  Add(wxMakeFormNewLine());
  Add(wxMakeFormShort("Veloc:", &Veloc, wxFORM_DEFAULT, new wxList(wxMakeConstraintRange(1.0, 127.0), 0)));
  Add(wxMakeFormNewLine());
  Add(wxMakeFormShort("Length:", &Length, wxFORM_DEFAULT));
  Add(wxMakeFormNewLine());
  tChEventDlg::EditForm(panel);
}


// -------------------------------- Pitch -------------------------------

class tPitchDlg : public tChEventDlg
{
 public:

  int Value;

  tPitchDlg(tPitch *e, tEventWin *w, tTrack *t);

  void EditForm(wxPanel *panel);
  void OnOk();
};


tPitchDlg::tPitchDlg(tPitch *e, tEventWin *w, tTrack *t)
  : tChEventDlg(e, w, t)
{
  Event = e;
  Value = e->Value;
}


void tPitchDlg::OnOk()
{
  ((tPitch *)Copy)->Value = Value;
  tChEventDlg::OnOk();
}

void tPitchDlg::EditForm(wxPanel *panel)
{
  Add(wxMakeFormShort("Pitch:", &Value, wxFORM_DEFAULT, new wxList(wxMakeConstraintRange(-8191.0, 8191.0), 0)));
  Add(wxMakeFormNewLine());
  tChEventDlg::EditForm(panel);
}

// -------------------------------- Controller ---------------------------

class tControlDlg : public tChEventDlg
{
 public:

  int Value;
  long Control;
  tNamedChoice Choice;

  tControlDlg(tControl *e, tEventWin *w, tTrack *t);

  void EditForm(wxPanel *panel);
  void OnOk();
};


tControlDlg::tControlDlg(tControl *e, tEventWin *w, tTrack *t)
  : tChEventDlg(e, w, t),
    Choice("Controller", ControlNames, &Control)
{
  Event = e;
  Value = e->Value;
  Control = e->Control + 1;
}


void tControlDlg::OnOk()
{
  ((tControl *)Copy)->Value = Value;
  Choice.GetValue();
  ((tControl *)Copy)->Control = Control - 1;
  tChEventDlg::OnOk();
}

void tControlDlg::EditForm(wxPanel *panel)
{
  Add(Choice.mkFormItem(300, 300));
  Add(wxMakeFormNewLine());
  Add(wxMakeFormShort("Value:", &Value, wxFORM_DEFAULT, new wxList(wxMakeConstraintRange(0.0, 127.0), 0)));
  Add(wxMakeFormNewLine());
  tChEventDlg::EditForm(panel);
}

// -------------------------------- Program ---------------------------

class tProgramDlg : public tChEventDlg
{
 public:

  long Program;
  tNamedChoice Choice;

  tProgramDlg(tProgram *e, tEventWin *w, tTrack *t);

  void EditForm(wxPanel *panel);
  void OnOk();
};


tProgramDlg::tProgramDlg(tProgram *e, tEventWin *w, tTrack *t)
  : tChEventDlg(e, w, t),
    Program(e->Program + 1),
    Choice("Program", VoiceNames, &Program)
{
  Event = e;
}


void tProgramDlg::OnOk()
{
  Choice.GetValue();
  if (Program <= 0)
    Program = 1;
  ((tProgram *)Copy)->Program = Program - 1;
  tChEventDlg::OnOk();
}

void tProgramDlg::EditForm(wxPanel *panel)
{
  Add(Choice.mkFormItem(300, 300));
  Add(wxMakeFormNewLine());
  tChEventDlg::EditForm(panel);
}

// -------------------------------- Set Tempo -------------------------------

class tSetTempoDlg : public tEventDlg
{
 public:

  int Value;

  tSetTempoDlg(tSetTempo *e, tEventWin *w, tTrack *t);

  void EditForm(wxPanel *panel);
  void OnOk();
};


tSetTempoDlg::tSetTempoDlg(tSetTempo *e, tEventWin *w, tTrack *t)
  : tEventDlg(e, w, t)
{
  Event = e;
  Value = e->GetBPM();
}


void tSetTempoDlg::OnOk()
{
  ((tSetTempo *)Copy)->SetBPM( Value );
  tEventDlg::OnOk();
}

void tSetTempoDlg::EditForm(wxPanel *panel)
{
  Add(wxMakeFormShort("Tempo:", &Value, wxFORM_DEFAULT, new wxList(wxMakeConstraintRange(20.0, 240.0), 0)));
  Add(wxMakeFormNewLine());
  tEventDlg::EditForm(panel);
}

// --------------------------------------------------------------------------
// create new event
// --------------------------------------------------------------------------

static tEvent *CreateEventDialog(long Clock, int Channel, int Pitch)
{
  static char *Names[] =
  // { "Note On", "Pitch", "Controller", "Program Change", (char *)0 };
  { "Note On", "Controller", "Program Change", "Set Tempo", (char *)0 };
  static long Values[] =
  // { StatKeyOn, StatPitch, StatControl, StatProgram, -1 };
  { StatKeyOn, StatControl, StatProgram, StatSetTempo, -1 };
  tEvent *e = 0;
  int i = wxGetSingleChoiceIndex("Select event to create", "Create Event", 4, Names);
  if (i >= 0)
  {
    switch (Values[i])
    {
      case StatKeyOn:
        e = new tKeyOn(Clock, Channel, Pitch, 64, 64);
        break;
      case StatPitch:
        e = new tPitch(Clock, Channel, 0);
        e->SetPitch(Pitch);
        break;
      case StatControl:
        e = new tControl(Clock, Channel, Pitch, 64);
        break;
      case StatProgram:
        e = new tProgram(Clock, Channel, Pitch);
        break;
      case StatSetTempo:
        e = new tSetTempo(Clock, 100);
        break;
    }
  }
  return e;
}




void EventDialog(tEvent *e, tEventWin *w, tTrack *t, long Clock, int Channel, int Pitch)
{
  if (!e)
    e = CreateEventDialog(Clock, Channel, Pitch);
  if (!e)
    return;

  tEventDlg *dlg = 0;
  char *str = 0;
  switch (e->Stat)
  {
    case StatKeyOn:
      str = "Key On";
      dlg = new tKeyOnDlg(e->IsKeyOn(), w, t);
      break;

    case StatPitch:
      str = "Pitch Wheel";
      dlg = new tPitchDlg(e->IsPitch(), w, t);
      break;

    case StatControl:
      str = "Controller";
      dlg = new tControlDlg(e->IsControl(), w, t);
      break;

    case StatProgram:
      str = "Program Change";
      dlg = new tProgramDlg(e->IsProgram(), w, t);
      break;

    case StatSetTempo:
      str = "Set Tempo";
      dlg = new tSetTempoDlg(e->IsSetTempo(), w, w->Song->GetTrack(0) );
      break;

    default:
      break;
  }
  if (dlg)
  {
    wxDialogBox *panel = new wxDialogBox(w, str, FALSE );
    dlg->EditForm(panel);
    panel->Fit();
    panel->Show(TRUE);
  }
}
