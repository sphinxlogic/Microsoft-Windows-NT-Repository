#ifndef LYEDIT_H
#define LYEDIT_H

#include <HTUtils.h>

extern int edit_current_file PARAMS((char *newfile, int cur, int lineno));

#endif /* LYEDIT_H */
