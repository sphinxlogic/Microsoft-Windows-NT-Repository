#ifndef LYCGI_H
#define LYCGI_H

#include <HTUtils.h>

extern void add_lynxcgi_environment PARAMS((CONST char *variable_name));

#endif /* LYGETFILE_H */
