#define B_NCOLORS 21
#define B_NPIX 27
#define PIC_W 32
#define PIC_H 32

#define PIC_BLANK       0
#define PIC_S_B         1
#define PIC_S_Y         2
#define PIC_R_B         3
#define PIC_R_Y         4
#define PIC_P_B         5
#define PIC_P_Y         6
#define PIC_D_B         7
#define PIC_D_Y         8
#define PIC_COLOR_B     9
#define PIC_COLOR_Y    10
#define PIC_COLOR_FLIP 11
#define PIC_WALL       12
#define PIC_MWALL      13
#define PIC_TELEPORT   14
#define PIC_MUTATE     15
#define PIC_PLAYER     16
#define PIC_STARS_A    17
#define PIC_STARS_B    18
#define PIC_STARS_C    19
#define PIC_STARS_D    20
#define PIC_STARS_E    21
#define PIC_STARS_F    22
#define PIC_STARS_G    23
#define PIC_STARS_H    24
#define PIC_STARS_I    25
#define PIC_STARS_J    26
#define PIC_NSTARS (PIC_STARS_J+1-PIC_STARS_A)

extern unsigned short int b_p_colors[B_NCOLORS][3];
extern char b_p_pix_color[B_NPIX][PIC_H][PIC_W];
extern char b_p_pix_bw[B_NPIX][PIC_H][PIC_W];
