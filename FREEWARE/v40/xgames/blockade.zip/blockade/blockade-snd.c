#include "blockade-snd.h"

playsound(n)
int n;
{
}
