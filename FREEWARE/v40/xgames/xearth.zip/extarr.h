/*
 * extarr.h
 * kirk johnson
 * july 1993
 *
 * RCS $Id: extarr.h,v 1.1 1993/07/23 03:38:43 tuna Exp $
 *
 * Copyright 1993 by Kirk Lauritz Johnson (see the included file
 * "kljcpyrt.h" for complete copyright information)
 */

#ifndef _EXTARR_H_
#define _EXTARR_H_

typedef struct extarr
{
  int   eltsize;
  int   limit;
  int   count;
  void *body;
} *ExtArr;

extern ExtArr extarr_alloc();
extern void   extarr_free();
extern void  *extarr_next();

#endif
