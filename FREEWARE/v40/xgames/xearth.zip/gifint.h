/****
  giflib/gifint.h
  kirk johnson
  november 1989

  RCS $Id: gifint.h,v 1.2 1993/07/23 03:53:53 tuna Exp $

  #defines, typedefs, and such internal to gifin.c and gifout.c

  Copyright 1989, 1990 by Kirk L. Johnson (see the included
  file "kljcpyrt.h" for complete copyright information)
  ****/

#ifndef _GIFINT_H_
#define _GIFINT_H_

#include "giflib.h"
#include "kljcpyrt.h"

#define GIF_SIG      "GIF87a"
#define GIF_SIG_LEN  6          /* GIF signature length */
#define GIF_SD_SIZE  7          /* GIF screen descriptor size */
#define GIF_ID_SIZE  9          /* GIF image descriptor size */

#define GIF_SEPARATOR   ','     /* GIF image separator */
#define GIF_EXTENSION   '!'     /* GIF extension block marker */
#define GIF_TERMINATOR  ';'     /* GIF terminator */

#define STAB_SIZE  4096         /* string table size */
#define PSTK_SIZE  4096         /* pixel stack size */

#define NULL_CODE  -1           /* string table null code */

#endif
