/*

	strategie.c  calcul du prochain coup (stratscore et alphabeta)

*/


#include <stdlib.h>


#include "types.h"
#include "strategie.h"
#include "val_strategie.h"

int stratscore(play_board,calc_board,player)

board play_board;
board calc_board;
int player;

{
   int scor=0;
   int i,j;

   for(i=1;i<7;i++)
      for(j=1;j<7;j++)
	{
	 if (play_board[i][j]+calc_board[i][j])
	    if ((player*(play_board[i][j]+calc_board[i][j]))>0)
	       {
		  scor+=MY_SCORE_RATE;
	       }
	    else
	       {
		  scor-=OPP_SCORE_RATE;
	       };  
	  		/* on teste si on est en danger (avec une valeur 0)
			   donc plus on est danger,plus le score diminue */

	     scor-=((player*play_board[i][j]>0)&&(!calc_board[i][j]))*PROTECT_RATE;
	};
   return(scor);
}



void alphabeta(play_board,player,depth,ii,jj,result)

board play_board;
int   player,depth;
int   *ii,*jj,*result;

{
   board temp_play_board;
   board temp_calc_board;
   board calc_board;
   board resuboard;
   int sco= -1000;
   int sc1= -1000;
   int dump,i,j,di,dj,i0,j0,resu,alpha,beta,ok,bi,bj;
  
   di=dj=0;
   alpha= -1000;
   calc(play_board,calc_board);

   for(i=0;i<8;i++)
      for(j=0;j<8;j++)
	 temp_play_board[i][j]=0;

   for(i=1;i<7;i++)
      for(j=1;j<7;j++)
	 temp_play_board[i][j]=play_board[i][j];

    
   for(i=1;i<7;i++)
      for(j=1;j<7;j++)
	 {

	   ok=1;
	   beta=1000;
           if ((!(player*temp_play_board[i][j]<0)) &&(player*temp_play_board[i][j]<3))
              {
		for(di=1;(di<7)&&ok;di++)
		   for(dj=1;(dj<7)&&ok;dj++)
		      {
                       if ((!(-player*temp_play_board[di][dj]<0))&&(-player*temp_play_board[di][dj]<3)&&((i!=di)||(j!=dj)))
			   {
			     temp_play_board[i][j]+=player;
			     calc(temp_play_board,temp_calc_board);
			     prise(temp_play_board,temp_calc_board);
			     temp_play_board[di][dj]-=player;
			     calc(temp_play_board,temp_calc_board);
			     prise(temp_play_board,temp_calc_board);
			     dump=stratscore(temp_play_board,temp_calc_board,player)*10+player*rand()/(67108864*4); /* le hasard est entre 0 et 8 */

			     dump+=((player*play_board[i][j]>0)&&(!calc_board[i][j]))*10*DEF_RATE;	  /* on rajoute def_rate si on  */
	 		     dump+=((player*play_board[i+1][j]>0)&&(!calc_board[i+1][j]))*10*DEF_RATE;	  /* risque d'etre pris */
	 		     dump+=((player*play_board[i-1][j]>0)&&(!calc_board[i-1][j]))*10*DEF_RATE;	  
	 		     dump+=((player*play_board[i][j+1]>0)&&(!calc_board[i][j+1]))*10*DEF_RATE;	  
			     dump+=((player*play_board[i][j-1]>0)&&(!calc_board[i][j-1]))*10*DEF_RATE;

			     dump+=((player*play_board[i][j]<0)&&(!calc_board[i][j]))*10*ATT_RATE;	  /* on rajoute ATT_rate si on  */
	 		     dump+=((player*play_board[i+1][j]<0)&&(!calc_board[i+1][j]))*10*ATT_RATE;	  /* peut prendre l'adversaire */
	 		     dump+=((player*play_board[i-1][j]<0)&&(!calc_board[i-1][j]))*10*ATT_RATE;	  
	 		     dump+=((player*play_board[i][j+1]<0)&&(!calc_board[i][j+1]))*10*ATT_RATE;	  
			     dump+=((player*play_board[i][j-1]<0)&&(!calc_board[i][j-1]))*10*ATT_RATE;

			     dump+=((i!=1)&&(i!=6)&&(j!=1)&&(j!=6))*POS_RATE; /* on rajoute POS_RATE si on est au centre */
									      /* ie: pas sur un bord... */
			     if (dump<beta) {beta=dump;};
			     ok=!(beta<alpha);
			     for(bi=1;bi<7;bi++)
			        for(bj=1;bj<7;bj++)
			           temp_play_board[bi][bj]=play_board[bi][bj];
			   };
  		      };
	   if (beta>alpha)
		{
		 alpha=beta;
		 i0=i;
		 j0=j;
		};
	     };
	 };

    *result=alpha;
    *ii=i0;
    *jj=j0;
}


void minmax(play_board,player,depth,ii,jj,result)

board play_board;
int   player,depth;
int   *ii,*jj,*result;

{
   board temp_play_board;
   board temp_calc_board;
   board calc_board;
   board resuboard;
   int sco= -1000;
   int sc1= -1000;
   int dump,i,j,di,dj,i0,j0,resu,ok,bi,bj;

   for(i=1;i<7;i++)
      for(j=1;j<7;j++)
	 temp_play_board[i][j]=play_board[i][j];

   for(i=1;i<7;i++)
      for(j=1;j<7;j++)
	{
           if ((!(player*temp_play_board[i][j]<0)) &&(player*temp_play_board[i][j]<3))
	  	{
		 temp_play_board[i][j]+=player;
		 calc(temp_play_board,temp_calc_board);
		 prise(temp_play_board,temp_calc_board);
		 if (!depth)
			{
			 dump=score(temp_play_board,temp_calc_board)*player;
			}
		 else
			{
			 minmax(temp_play_board,-player,depth-1,&i0,&j0,&resu);
			 dump= -resu;
			};
	         if (dump>0) 
			{
			 *ii=i;
			 *jj=j;
			 i=7;
			 j=7;
			}
		 	else
			{
			 if (dump>sco)
				{
				 *ii=i;
				 *jj=j;
				 sco=dump;
				};
			};
		 for(di=1;di<7;di++)
		    for(dj=1;dj<7;dj++)
		       temp_play_board[di][dj]=play_board[di][dj];
		};
	  };
	*result=dump;
/*printf("coup retenu : %d,%d niveau %d, resultat %d, joueur %d\n",*jj,*ii,depth,dump,player);*/
}
