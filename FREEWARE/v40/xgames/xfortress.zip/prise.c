	 
/*

	prise.c  test des prises dans le tableau

*/


#include "types.h"

void prise(play_board,calc_board)

board play_board;
board calc_board;

{
   int ok=1;
   int i,j;
   
   for(i=1;i<7;i++)
      for(j=1;j<7;j++)
	 if (play_board[i][j]*calc_board[i][j]<0)
	    {
		play_board[i][j]=0;
		ok=0;
	    };
   if (!ok)
      {
	  calc (play_board,calc_board);
	  prise(play_board,calc_board);
      };
}

