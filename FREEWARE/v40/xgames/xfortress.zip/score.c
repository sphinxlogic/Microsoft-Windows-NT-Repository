/*

	score.h  calcul du score

*/


#include "types.h"

int score(play_board,calc_board)

board play_board;
board calc_board;

{
   int scor=0;
   int i,j;

   for(i=1;i<7;i++)
      for(j=1;j<7;j++)
	 if (play_board[i][j]+calc_board[i][j])
	    if ((play_board[i][j]+calc_board[i][j])>0)
	       {
		  scor++;
	       }
	    else
	       {
		  scor--;
	       };
   return(scor);
}

