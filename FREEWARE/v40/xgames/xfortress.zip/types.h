/*

	types.h  definitions des types

*/

#ifndef _types_h
#define _types_h

typedef int board[8][8];

#define inf(a,b) (a<b?a:b)
#define MAX_COUPS 42
#define MIN_MAX_START 39
#define NB_TOURS 21

#endif /* _types_h  */
