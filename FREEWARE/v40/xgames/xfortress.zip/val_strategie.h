#define DEF_RATE 4
#define ATT_RATE 3
#define PROTECT_RATE 1
#define MY_SCORE_RATE 1
#define OPP_SCORE_RATE 1
#define POS_RATE 2
