#include "xfortress.h"

#include "whcas1.bm"	/* BITMAPS */
#include "whcas2.bm"
#include "whcas3.bm"
#include "wwhcas1.bm"
#include "wwhcas2.bm"
#include "wwhcas3.bm"
#include "blcas1.bm"
#include "blcas2.bm"
#include "blcas3.bm"
#include "wblcas1.bm"
#include "wblcas2.bm"
#include "wblcas3.bm"
#include "whitflag.bm"
#include "blacflag.bm"
#include "vide.bm"

#include "types.h"



static String fallback_resources[] = { 

	"*wboard.borderWidth: 		    4",
	"*wmesg.borderWidth: 		    0",


	"*wwarn.shapeStyle:		    oval",
	"*wreset.shapeStyle:		    oval",
	"*wplay.shapeStyle:		    oval",
	"*wquit.shapeStyle:		    oval",
	"*wsingle.shapeStyle:		    oval",

	NULL
};



main(argc,argv)
int    argc;
char **argv;
{
car=0;
XtSetArg(ar[car],XtNwidth,500);car++;
XtSetArg(ar[car],XtNheight,400);car++;
XtSetArg(ar[car],XtNtitle,"Xfortress (ver 1.1) by The Spif (1993)");car++;
toplevel=XtAppInitialize(&app_context,"XFortress",NULL,0,&argc,argv,fallback_resources,NULL,0);
XtSetValues(toplevel,ar,car);

interm=XtCreateManagedWidget("Interm",formWidgetClass,toplevel,NULL,0);
wboard=XtCreateManagedWidget("BOard",formWidgetClass,interm,NULL,0);

XtSetArg(ar[0],XtNwidth,400);
XtSetValues(wboard,ar,car);

XtSetArg(ar[0],XtNfromHoriz,wboard);
XtSetArg(ar[1],XtNfromVert,NULL);
wplay=XtCreateManagedWidget(" PLAY ",commandWidgetClass,interm,ar,2);
XtAddCallback(wplay,XtNcallback,compuplay,0);

XtSetArg(ar[0],XtNfromHoriz,wboard);
XtSetArg(ar[1],XtNfromVert,wplay);
wreset=XtCreateManagedWidget("RESET ",commandWidgetClass,interm,ar,2);
XtAddCallback(wreset,XtNcallback,reset,0);

XtSetArg(ar[0],XtNfromHoriz,wboard);
XtSetArg(ar[1],XtNfromVert,wreset);
wsingle=XtCreateManagedWidget("SINGLE",commandWidgetClass,interm,ar,2);
XtAddCallback(wsingle,XtNcallback,single,0);

XtSetArg(ar[0],XtNfromHoriz,wboard);
XtSetArg(ar[1],XtNfromVert,wsingle);
wwarn=XtCreateManagedWidget(" WARN ",commandWidgetClass,interm,ar,2);
XtAddCallback(wwarn,XtNcallback,setwarn,0);

XtSetArg(ar[0],XtNfromHoriz,wboard);
XtSetArg(ar[1],XtNfromVert,wwarn);
wquit=XtCreateManagedWidget(" QUIT ",commandWidgetClass,interm,ar,2);
XtAddCallback(wquit,XtNcallback,quit,0);

XtSetArg(ar[0],XtNfromHoriz,NULL);
XtSetArg(ar[1],XtNfromVert,wboard);
wscore=XtCreateManagedWidget("Score -> 0",labelWidgetClass,interm,ar,2);

XtSetArg(ar[0],XtNfromHoriz,wscore);
XtSetArg(ar[1],XtNfromVert,wboard);
wtour=XtCreateManagedWidget("Turn 1 ",labelWidgetClass,interm,ar,2);

XtSetArg(ar[0],XtNfromHoriz,wtour);
XtSetArg(ar[1],XtNfromVert,wboard);
wmesg=XtCreateManagedWidget("it's you to play,white...",labelWidgetClass,interm,ar,2);

for(i=1;i<=6;i++)
  for(j=1;j<=6;j++)
	{
	sprintf(buf,"case %d,%d",i,j);
	card=0;
	XtSetArg(args[card],XtNwidth,50);card++;
	XtSetArg(args[card],XtNheight,50);card++;
	if ((i/=1) || (j/=1))
		{
		XtSetArg(args[card],XtNfromHoriz,tabl[i-1][j]);card++;
		XtSetArg(args[card],XtNfromVert,tabl[i][j-1]);card++;
		};
      tabl[i][j]=XtCreateManagedWidget(buf,commandWidgetClass,wboard,args,card);
      dump=i*10+j;
      XtAddCallback(tabl[i][j],XtNcallback,play,(XtPointer) dump);
};
pixtab[0] =XCreateBitmapFromData(XtDisplay(toplevel),RootWindowOfScreen(XtScreen(toplevel)),vide_bits    ,vide_width    ,vide_height    );
pixtab[1] =XCreateBitmapFromData(XtDisplay(toplevel),RootWindowOfScreen(XtScreen(toplevel)),blacflag_bits,blacflag_width,blacflag_height);
pixtab[2] =XCreateBitmapFromData(XtDisplay(toplevel),RootWindowOfScreen(XtScreen(toplevel)),blcas1_bits  ,blcas1_width  ,blcas1_height  );
pixtab[3] =XCreateBitmapFromData(XtDisplay(toplevel),RootWindowOfScreen(XtScreen(toplevel)),blcas2_bits  ,blcas2_width  ,blcas2_height  );
pixtab[4] =XCreateBitmapFromData(XtDisplay(toplevel),RootWindowOfScreen(XtScreen(toplevel)),blcas3_bits  ,blcas3_width  ,blcas3_height  );
pixtab[5] =XCreateBitmapFromData(XtDisplay(toplevel),RootWindowOfScreen(XtScreen(toplevel)),wblcas1_bits ,wblcas1_width ,wblcas1_height );
pixtab[6] =XCreateBitmapFromData(XtDisplay(toplevel),RootWindowOfScreen(XtScreen(toplevel)),wblcas2_bits ,wblcas2_width ,wblcas2_height );
pixtab[7] =XCreateBitmapFromData(XtDisplay(toplevel),RootWindowOfScreen(XtScreen(toplevel)),wblcas3_bits ,wblcas3_width ,wblcas3_height );
pixtab[8] =XCreateBitmapFromData(XtDisplay(toplevel),RootWindowOfScreen(XtScreen(toplevel)),whitflag_bits,whitflag_width,whitflag_height);
pixtab[9] =XCreateBitmapFromData(XtDisplay(toplevel),RootWindowOfScreen(XtScreen(toplevel)),whcas1_bits  ,whcas1_width  ,whcas1_height  );
pixtab[10]=XCreateBitmapFromData(XtDisplay(toplevel),RootWindowOfScreen(XtScreen(toplevel)),whcas2_bits  ,whcas2_width  ,whcas2_height  );
pixtab[11]=XCreateBitmapFromData(XtDisplay(toplevel),RootWindowOfScreen(XtScreen(toplevel)),whcas3_bits  ,whcas3_width  ,whcas3_height  );
pixtab[12]=XCreateBitmapFromData(XtDisplay(toplevel),RootWindowOfScreen(XtScreen(toplevel)),wwhcas1_bits ,wwhcas1_width ,wwhcas1_height );
pixtab[13]=XCreateBitmapFromData(XtDisplay(toplevel),RootWindowOfScreen(XtScreen(toplevel)),wwhcas2_bits ,wwhcas2_width ,wwhcas2_height );
pixtab[14]=XCreateBitmapFromData(XtDisplay(toplevel),RootWindowOfScreen(XtScreen(toplevel)),wwhcas3_bits ,wwhcas3_width ,wwhcas3_height );

for(i=1;i<=6;i++)
  for(j=1;j<=6;j++)
	{
	XtSetArg(args[0],XtNbitmap,pixtab[0]);
	XtSetValues(tabl[i][j],args,1);
	};

/* initialisation du jeu */

   for(i=0;i<8;i++)
      for(j=0;j<8;j++)
	 play_board[i][j]=0;

  coups=1;	
  player=1;
  is_single=1;
  warn=1;

XtRealizeWidget(toplevel);
XtAppMainLoop(app_context);
}

