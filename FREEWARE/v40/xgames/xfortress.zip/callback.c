#include "xfortress.h"
#include "callback.h"

void affichage(play_val,calc_val,tableau)

int play_val,calc_val;
Widget         tableau;

{
	int i,j;
	Arg	       ar[10];
	Cardinal    car;

	if (play_val)
	{
		if (play_val<0)
		{ 
			XtSetArg(ar[0],XtNbitmap,pixtab[1-play_val+3*warn*(!calc_val)]);
		}
		else
		{ 
			XtSetArg(ar[0],XtNbitmap,pixtab[8+play_val+3*warn*(!calc_val)]);
		};
	}
	else
	{
		if (calc_val)
		{
			if (calc_val>0)
			{ 
				XtSetArg(ar[0],XtNbitmap,pixtab[8]);
			}
			else
			{ 
				XtSetArg(ar[0],XtNbitmap,pixtab[1]);
			};
		}
		else
		{ 
			XtSetArg(ar[0],XtNbitmap,pixtab[0]);
		};
	};
	XtSetValues(tableau,ar,1);

};

void single(w,client_data,call_data)
Widget w;
XtPointer client_data,call_data;
{
	is_single=!(is_single);
	if (is_single) { 
		XtSetArg(ar[0],XtNlabel,"SINGLE"); 
	} else { 
		XtSetArg(ar[0],XtNlabel," TWO  "); 
	};
	XtSetValues(wsingle,ar,1);
};

void setwarn(w,client_data,call_data)
Widget w;
XtPointer client_data,call_data;
{
	int ii,jj;

	warn=!(warn);
	if (warn) { 
		XtSetArg(ar[0],XtNlabel," WARN "); 
	} else { 
		XtSetArg(ar[0],XtNlabel,"NOWARN"); 
	};
	XtSetValues(wwarn,ar,1);
	for(ii=1;ii<=6;ii++)
		for(jj=1;jj<=6;jj++)
			affichage(play_board[ii][jj],calc_board[ii][jj],tabl[ii][jj]);

};

void quit(w,client_data,call_data)
Widget w;
XtPointer client_data,call_data;
{
	exit(0);
};

void compuplay(w,client_data,call_data)
Widget w;
XtPointer client_data,call_data;
{
	int ii,jj,dump;
	if (coups<=MAX_COUPS)
	{
		coups++;
		if (coups<6) { 
			dump=1;
		} else {
			if (coups<8) { 
				dump=1;
			} else {
				if (coups<30) { 
					dump=inf(1,MAX_COUPS-coups+1);
				} else {
					dump=inf(1,MAX_COUPS-coups+1);
				};
			};
		};
		if (coups<MIN_MAX_START)
		{ 
			alphabeta(play_board,player,dump,&ii,&jj,&dump); 
		}
		else {
			dump=MAX_COUPS-coups+1;
			minmax(play_board,player,dump,&ii,&jj,&dump);

/*if (dump<0) { printf("I'll lose\n");} else {if (dump) {printf("I will win !!\n");} else {printf("a draw...\n");};};*/

		};
		play_board[ii][jj]+=player;
		player= -player;
		calc(play_board,calc_board);
		prise(play_board,calc_board);
		for(ii=1;ii<=6;ii++)
			for(jj=1;jj<=6;jj++)
				affichage(play_board[ii][jj],calc_board[ii][jj],tabl[ii][jj]);
		sprintf(buf,"Score -> %d",score(play_board,calc_board));
		XtSetArg(ar[0],XtNlabel,buf);
		XtSetValues(wscore,ar,1);
		dump=((coups+1)/2);
		sprintf(buf,"Turn %2d",dump);
		XtSetArg(ar[0],XtNlabel,buf);
		XtSetValues(wtour,ar,1);
		if (player==1){
			XtSetArg(ar[0],XtNlabel,"it's you to play,white...");
		} else{
			XtSetArg(ar[0],XtNlabel,"it's you to play,black...");
		};
	};
	if (coups>MAX_COUPS)
	{
		for(ii=1;ii<=6;ii++)
			for(jj=1;jj<=6;jj++)
				affichage(play_board[ii][jj],calc_board[ii][jj],tabl[ii][jj]);
		sprintf(buf,"Score -> %d",score(play_board,calc_board));
		XtSetArg(ar[0],XtNlabel,buf);
		XtSetValues(wscore,ar,1);
		XtSetArg(ar[0],XtNlabel,buf);
		XtSetValues(wtour,ar,1);
		XtSetArg(ar[0],XtNlabel,"THE END");
		XtSetValues(wtour,ar,1);
		if (score(play_board,calc_board))
		{
			if (score(play_board,calc_board)>0)
			{ 
				XtSetArg(ar[0],XtNlabel,"   WHITE is the WINNER   ");
			}
			else
			{ 
				XtSetArg(ar[0],XtNlabel,"   BLACK is the WINNER   ");
			};
		}
		else { 
			XtSetArg(ar[0],XtNlabel,"        A DRAW ....      ");
		};

	};
	XtSetValues(wmesg,ar,1);
};

void play(w,client_data,call_data)
Widget w;
XtPointer client_data,call_data;
{
	int ii,jj,dump;

	dump= (int) client_data;
	jj= dump % 10;
	ii= (dump-jj)/10;
	if (play_board[ii][jj]*player>=0 && play_board[ii][jj]*player<3 && coups<=MAX_COUPS)
	{
		play_board[ii][jj]+=player;
		player= -player;
		coups++;
		calc(play_board,calc_board);
		prise(play_board,calc_board);

		if (is_single)
		{ 
			compuplay(w,client_data,call_data); 
		}
		else
		{
			for(ii=1;ii<=6;ii++)
				for(jj=1;jj<=6;jj++)
					affichage(play_board[ii][jj],calc_board[ii][jj],tabl[ii][jj]);

			sprintf(buf,"Score -> %d",score(play_board,calc_board));
			XtSetArg(ar[0],XtNlabel,buf);
			XtSetValues(wscore,ar,1);
			dump=((coups+1)/2);
			sprintf(buf,"Turn %2d",dump);
			XtSetArg(ar[0],XtNlabel,buf);
			XtSetValues(wtour,ar,1);
		};
	};
	if (coups>MAX_COUPS)
	{
		XtSetArg(ar[0],XtNlabel,"THE END");
		XtSetValues(wtour,ar,1);
		if (score(play_board,calc_board))
		{
			if (score(play_board,calc_board)>0)
			{ 
				XtSetArg(ar[0],XtNlabel,"   WHITE is the WINNER   ");
			}
			else
			{ 
				XtSetArg(ar[0],XtNlabel,"   BLACK is the WINNER   ");
			};
		}
		else { 
			XtSetArg(ar[0],XtNlabel,"        A DRAW ....      ");
		};
		XtSetValues(wmesg,ar,1);
	}
	else
	{
		if (player==1) { 
			XtSetArg(ar[0],XtNlabel,"it's you to play,white...");
		} else { 
			XtSetArg(ar[0],XtNlabel,"it's you to play,black...");
		};
		XtSetValues(wmesg,ar,1);
	};

};

void reset(w,client_data,call_data)
Widget w;
XtPointer client_data,call_data;
{
	int ii,jj;
	coups=1;
	player=1;
	for(i=0;i<8;i++)
		for(j=0;j<8;j++)
			play_board[i][j]=0;

	for(i=0;i<8;i++)
		for(j=0;j<8;j++)
			calc_board[i][j]=0;

	for(ii=1;ii<=6;ii++)
		for(jj=1;jj<=6;jj++)
			affichage(play_board[ii][jj],calc_board[ii][jj],tabl[ii][jj]);

	XtSetArg(ar[0],XtNlabel,"Score -> 0");
	XtSetValues(wscore,ar,1);

	XtSetArg(ar[0],XtNlabel,"it's you to play,white...");
	XtSetValues(wmesg,ar,1);

	XtSetArg(ar[0],XtNlabel,"Turn 1 ");
	XtSetValues(wtour,ar,1);
};

