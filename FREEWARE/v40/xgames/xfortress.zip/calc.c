/*

	calc.c  calcul des influences

*/


#include "types.h"

void calc(play_board,calc_board)

board play_board;
board calc_board;

{
   int i,j;

   for(i=1;i<7;i++)
      for(j=1;j<7;j++)
	 calc_board[i][j]=play_board[i][j];

   for(i=1;i<7;i++)
      for(j=1;j<7;j++)
	 if (play_board[i][j])
	    {
	       calc_board[i-1][j]+=play_board[i][j];
	       calc_board[i+1][j]+=play_board[i][j];
	       calc_board[i][j-1]+=play_board[i][j];
	       calc_board[i][j+1]+=play_board[i][j];
	    };
}

