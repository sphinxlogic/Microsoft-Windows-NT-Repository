/* scor2prt.f -- translated by f2c (version 19961017).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/

#include "f2c.h"

/* Common Block Declarations */

struct {
    integer noinst;
} all_;

#define all_1 all_

struct {
    logical topcoms;
} comtop_;

#define comtop_1 comtop_

/* Table of constant values */

static integer c__9 = 9;
static integer c__1 = 1;
static integer c__12 = 12;
static integer c__2 = 2;
static integer c__128 = 128;
static integer c__20 = 20;
static real c_b56 = (float).05;
static integer c__6 = 6;
static integer c__3 = 3;
static integer c__79 = 79;
static integer c__126 = 126;

/* ccccccccccccccccccccccccccccccccccccccccccccccc */
/* c                                            cc */
/* c  scor2prt.for  Version 1.3 -  9/9/97       cc */
/* c                                            cc */
/* ccccccccccccccccccccccccccccccccccccccccccccccc */

/* Changes since version 1.1: */

/* Deal with saved macros. */
/* Revise setup readin, to admit comments. */
/* Do not copy 'X' into parts */

/* ccccccccccccccccccccccccccccccccccccccccccccccc */
/* Main program */ MAIN__()
{
    /* Initialized data */

    static char achar[1*9+1] = "PmVRAhwKM";
    static integer nvi[7] = { 1,1,1,1,1,1,1 };

    /* System generated locals */
    address a__1[2], a__2[6], a__3[3];
    integer i__1[2], i__2, i__3, i__4[6], i__5[3];
    char ch__1[16], ch__2[17], ch__3[1], ch__4[1], ch__5[1], ch__6[4], ch__7[
	    2];
    cilist ci__1;
    icilist ici__1;
    olist o__1;
    cllist cl__1;
    alist al__1;

    /* Builtin functions */
    integer s_wsle(), do_lio(), e_wsle(), s_rsfe(), do_fio(), e_rsfe();
    /* Subroutine */ int s_stop(), s_cat();
    integer f_open(), s_cmp(), f_rew(), f_clos(), s_wsfe(), e_wsfe(), i_indx()
	    , s_rsfi(), e_rsfi();
    /* Subroutine */ int s_copy();

    /* Local variables */
    static integer nchk, idxa, ljob;
    static char line[128];
    static integer isig, ilev, ndxm;
    static real xmtrnum0;
    static integer nppp;
    extern /* Subroutine */ int allparts_();
    static integer i__, iinst, ntinx, nsyst;
    static logical oneof2;
    static integer musicsize, ia, ib, ic, iv;
    extern doublereal readin_();
    static char sq[1];
    static integer nv, npages;
    static char holdln[128];
    static real fracindent;
    static integer mtrdnp;
    extern integer lenstr_();
    static logical frstln;
    static integer mtrnmp, iy1, iy2, len;
    static logical isachar;
    static char jobname[12];
    static integer lenhold, lenline, iccount, mtrdenl;
    extern integer ntindex_();
    extern /* Subroutine */ int mbrests_();
    static integer inm1, inm2;
    static logical termrpt;
    static integer mtrnuml;
    static char instrum[128*7];

    /* Fortran I/O blocks */
    static cilist io___5 = { 0, 6, 0, 0, 0 };
    static cilist io___6 = { 0, 5, 0, "(a)", 0 };
    static cilist io___9 = { 0, 6, 0, 0, 0 };
    static cilist io___12 = { 0, 10, 0, "(a)", 0 };
    static cilist io___14 = { 0, 6, 0, 0, 0 };
    static cilist io___28 = { 0, 30, 1, "(a)", 0 };
    static cilist io___29 = { 0, 6, 0, 0, 0 };
    static cilist io___30 = { 0, 6, 0, 0, 0 };
    static cilist io___31 = { 0, 6, 0, 0, 0 };
    static cilist io___32 = { 0, 6, 0, 0, 0 };
    static cilist io___34 = { 0, 0, 0, "(6i5,f7.3,i5/3i5,f8.5)", 0 };
    static cilist io___35 = { 0, 10, 0, "(a)", 0 };
    static cilist io___37 = { 0, 0, 0, "(a)", 0 };
    static cilist io___43 = { 0, 0, 0, "(a)", 0 };
    static cilist io___44 = { 0, 10, 0, "(a)", 0 };
    static cilist io___45 = { 0, 0, 0, "(a1)", 0 };
    static cilist io___46 = { 0, 10, 0, "(a)", 0 };
    static cilist io___48 = { 0, 0, 0, "(a2/a)", 0 };
    static cilist io___51 = { 0, 10, 1, "(a)", 0 };
    static cilist io___52 = { 0, 10, 0, "(a)", 0 };
    static cilist io___53 = { 0, 10, 0, "(a)", 0 };
    static cilist io___55 = { 0, 0, 0, "(a)", 0 };
    static cilist io___56 = { 0, 10, 0, "(a)", 0 };
    static cilist io___57 = { 0, 10, 0, "(a)", 0 };
    static cilist io___62 = { 0, 6, 0, 0, 0 };
    static cilist io___63 = { 0, 6, 0, 0, 0 };
    static cilist io___67 = { 0, 10, 0, "(a)", 0 };
    static cilist io___71 = { 0, 0, 0, "(a)", 0 };
    static cilist io___72 = { 0, 0, 0, "(a)", 0 };


    comtop_1.topcoms = FALSE_;
    frstln = TRUE_;
    lenhold = 0;
    s_wsle(&io___5);
    do_lio(&c__9, &c__1, "jobname:", 8L);
    e_wsle();
    s_rsfe(&io___6);
    do_fio(&c__1, jobname, 12L);
    e_rsfe();
    ljob = lenstr_(jobname, &c__12, 12L);
    if (ljob > 7) {
	s_wsle(&io___9);
	do_lio(&c__9, &c__1, "Use a jobname with 7 or fewer letters", 37L);
	e_wsle();
	s_stop("", 0L);
    }
    *(unsigned char *)sq = '\\';
    o__1.oerr = 0;
    o__1.ounit = 10;
    o__1.ofnmlen = ljob + 4;
/* Writing concatenation */
    i__1[0] = ljob, a__1[0] = jobname;
    i__1[1] = 4, a__1[1] = ".pmx";
    s_cat(ch__1, a__1, i__1, &c__2, 16L);
    o__1.ofnm = ch__1;
    o__1.orl = 0;
    o__1.osta = 0;
    o__1.oacc = 0;
    o__1.ofm = 0;
    o__1.oblnk = 0;
    f_open(&o__1);
    iccount = 128;
    s_rsfe(&io___12);
    do_fio(&c__1, line, 128L);
    e_rsfe();
    if (s_cmp(line, "---", 3L, 3L) == 0) {
	s_wsle(&io___14);
	do_lio(&c__9, &c__1, "Sorry, scor2prt cannot deal with type-5 TeX st\
rings", 51L);
	e_wsle();
	s_stop("1", 1L);
    }
    al__1.aerr = 0;
    al__1.aunit = 10;
    f_rew(&al__1);
    nv = readin_(line, &iccount, 128L) + (float).1;
    all_1.noinst = readin_(line, &iccount, 128L) + (float).1;
    mtrnuml = readin_(line, &iccount, 128L) + (float).1;
    mtrdenl = readin_(line, &iccount, 128L) + (float).1;
    mtrnmp = readin_(line, &iccount, 128L) + (float).1;
    mtrdnp = readin_(line, &iccount, 128L) + (float).1;
    xmtrnum0 = readin_(line, &iccount, 128L);
    isig = readin_(line, &iccount, 128L);
    npages = readin_(line, &iccount, 128L) + (float).1;
    nsyst = readin_(line, &iccount, 128L) + (float).1;
    musicsize = readin_(line, &iccount, 128L) + (float).1;
    fracindent = readin_(line, &iccount, 128L);
    i__2 = all_1.noinst;
    for (iv = 1; iv <= i__2; ++iv) {
	o__1.oerr = 0;
	o__1.ounit = iv + 10;
	o__1.ofnm = 0;
	o__1.orl = 0;
	o__1.osta = "SCRATCH";
	o__1.oacc = 0;
	o__1.ofm = 0;
	o__1.oblnk = 0;
	f_open(&o__1);
/* L19: */
    }
    if (comtop_1.topcoms) {
	al__1.aerr = 0;
	al__1.aunit = 30;
	f_rew(&al__1);
	for (i__ = 1; i__ <= 10000; ++i__) {
	    i__2 = s_rsfe(&io___28);
	    if (i__2 != 0) {
		goto L15;
	    }
	    i__2 = do_fio(&c__1, line, 128L);
	    if (i__2 != 0) {
		goto L15;
	    }
	    i__2 = e_rsfe();
	    if (i__2 != 0) {
		goto L15;
	    }
	    allparts_(line, &c__128, 128L);
/* L14: */
	}
	s_wsle(&io___29);
	do_lio(&c__9, &c__1, "Should not be here.  Call Dr. Don!", 34L);
	e_wsle();
L15:
	cl__1.cerr = 0;
	cl__1.cunit = 30;
	cl__1.csta = 0;
	f_clos(&cl__1);
    }
    if (npages == 0) {
	s_wsle(&io___30);
	do_lio(&c__9, &c__1, "You entered npages=0, which means nsyst is not\
 the total number", 63L);
	e_wsle();
	s_wsle(&io___31);
	do_lio(&c__9, &c__1, "of systems.  Scor2prt has to know the total nu\
mber of systems.", 62L);
	e_wsle();
	s_wsle(&io___32);
	do_lio(&c__9, &c__1, "Please set npages and nsyst to their real valu\
es.", 49L);
	e_wsle();
	s_stop("", 0L);
    }
    nppp = (nsyst - 1) / 12 + 1;
    nvi[0] = nv - all_1.noinst + 1;
    i__2 = all_1.noinst;
    for (iv = 1; iv <= i__2; ++iv) {
	io___34.ciunit = iv + 10;
	s_wsfe(&io___34);
	do_fio(&c__1, (char *)&nvi[iv - 1], (ftnlen)sizeof(integer));
	do_fio(&c__1, (char *)&c__1, (ftnlen)sizeof(integer));
	do_fio(&c__1, (char *)&mtrnuml, (ftnlen)sizeof(integer));
	do_fio(&c__1, (char *)&mtrdenl, (ftnlen)sizeof(integer));
	do_fio(&c__1, (char *)&mtrnmp, (ftnlen)sizeof(integer));
	do_fio(&c__1, (char *)&mtrdnp, (ftnlen)sizeof(integer));
	do_fio(&c__1, (char *)&xmtrnum0, (ftnlen)sizeof(real));
	do_fio(&c__1, (char *)&isig, (ftnlen)sizeof(integer));
	do_fio(&c__1, (char *)&nppp, (ftnlen)sizeof(integer));
	do_fio(&c__1, (char *)&nsyst, (ftnlen)sizeof(integer));
	do_fio(&c__1, (char *)&c__20, (ftnlen)sizeof(integer));
	do_fio(&c__1, (char *)&c_b56, (ftnlen)sizeof(real));
	e_wsfe();
L16:
	s_rsfe(&io___35);
	do_fio(&c__1, instrum + (iv - 1 << 7), 128L);
	e_rsfe();
	if (*(unsigned char *)&instrum[(iv - 1) * 128] == '%') {
	    allparts_(instrum + (iv - 1 << 7), &c__128, 128L);
	    goto L16;
	}

/*  The following checks for macro that write original C-clef as part 
of */
/*  instrument name.  See pmx.tex */

	if (i_indx(instrum + (iv - 1 << 7), "namewpc", 128L, 7L) == 0) {
	    io___37.ciunit = iv + 10;
	    s_wsfe(&io___37);
	    do_fio(&c__1, " ", 1L);
	    e_wsfe();
	} else {
	    inm1 = i_indx(instrum + (iv - 1 << 7), "{", 128L, 1L) + 1;
	    inm2 = i_indx(instrum + (iv - 1 << 7), "}", 128L, 1L) - 1;
	    i__3 = inm2 + 1;
	    ici__1.icierr = 0;
	    ici__1.iciend = 0;
	    ici__1.icirnum = 1;
	    ici__1.icirlen = inm2 + 8 - i__3;
	    ici__1.iciunit = instrum + ((iv - 1 << 7) + i__3);
	    ici__1.icifmt = "(i1,4x,2i1)";
	    s_rsfi(&ici__1);
	    do_fio(&c__1, (char *)&ilev, (ftnlen)sizeof(integer));
	    do_fio(&c__1, (char *)&iy1, (ftnlen)sizeof(integer));
	    do_fio(&c__1, (char *)&iy2, (ftnlen)sizeof(integer));
	    e_rsfi();
	    io___43.ciunit = iv + 10;
	    s_wsfe(&io___43);
/* Writing concatenation */
	    i__4[0] = 1, a__2[0] = sq;
	    i__4[1] = 9, a__2[1] = "namewpc{}";
	    *(unsigned char *)&ch__3[0] = ilev + 48;
	    i__4[2] = 1, a__2[2] = ch__3;
	    i__4[3] = 4, a__2[3] = "{20}";
	    *(unsigned char *)&ch__4[0] = iy1 + 49;
	    i__4[4] = 1, a__2[4] = ch__4;
	    *(unsigned char *)&ch__5[0] = iy2 + 49;
	    i__4[5] = 1, a__2[5] = ch__5;
	    s_cat(ch__2, a__2, i__4, &c__6, 17L);
	    do_fio(&c__1, ch__2, 17L);
	    e_wsfe();
	    s_copy(instrum + (iv - 1 << 7), instrum + ((iv - 1 << 7) + (inm1 
		    - 1)), 128L, inm2 - (inm1 - 1));
	}
/* L1: */
    }

/*  Clef string */

L17:
    s_rsfe(&io___44);
    do_fio(&c__1, line, 128L);
    e_rsfe();
    if (*(unsigned char *)line == '%') {
	allparts_(line, &c__128, 128L);
	goto L17;
    }
    i__2 = all_1.noinst;
    for (iv = 1; iv <= i__2; ++iv) {
	if (iv == 1) {
	    ci__1.cierr = 0;
	    ci__1.ciunit = iv + 10;
/* Writing concatenation */
	    i__5[0] = 2, a__3[0] = "(a";
	    *(unsigned char *)&ch__3[0] = nv + 49 - all_1.noinst;
	    i__5[1] = 1, a__3[1] = ch__3;
	    i__5[2] = 1, a__3[2] = ")";
	    ci__1.cifmt = (s_cat(ch__6, a__3, i__5, &c__3, 4L), ch__6);
	    s_wsfe(&ci__1);
	    do_fio(&c__1, line, nv - all_1.noinst + 1);
	    e_wsfe();
	} else {
	    io___45.ciunit = iv + 10;
	    s_wsfe(&io___45);
	    i__3 = nv - all_1.noinst + iv - 1;
	    do_fio(&c__1, line + i__3, nv - all_1.noinst + iv - i__3);
	    e_wsfe();
	}
/* L2: */
    }

/*  Path string */

L18:
    s_rsfe(&io___46);
    do_fio(&c__1, line, 128L);
    e_rsfe();
    if (*(unsigned char *)line == '%') {
	allparts_(line, &c__128, 128L);
	goto L18;
    }
    allparts_(line, &c__128, 128L);

/*  Write instrument names.  Will be blank if later part of a score. */

    if (*(unsigned char *)&instrum[0] != ' ') {
	i__2 = all_1.noinst;
	for (iv = 1; iv <= i__2; ++iv) {
	    len = lenstr_(instrum + (iv - 1 << 7), &c__79, 128L);
	    io___48.ciunit = iv + 10;
	    s_wsfe(&io___48);
	    do_fio(&c__1, "Ti", 2L);
	    do_fio(&c__1, instrum + (iv - 1 << 7), len);
	    e_wsfe();
/* L3: */
	}
    }

/*  The big loop.  Except for '%%', put all comment lines in all parts. */
/*  Unless preceeded by '%%', put all type 2 or 3 TeX Strings in all parts
 */
/*  If a line starts with %!, put the rest of it in each part. */
/*  If a line starts with %[n], put the rest of it in part [n]. */
/* Check for Tt, Tc, Voltas, Repeats, headers, lower texts, meter changes.
*/
/*     Assume they only come at top of block, except terminal repeat needs
 */
/*     special handling. */
/*  Check for "P"; ignore in parts. */
/*  Check for consecutive full-bar rests; if found, replace with rm[nn] */

    iv = 1;
    iinst = 1;
    termrpt = FALSE_;
L4:
    i__2 = s_rsfe(&io___51);
    if (i__2 != 0) {
	goto L999;
    }
    i__2 = do_fio(&c__1, line, 128L);
    if (i__2 != 0) {
	goto L999;
    }
    i__2 = e_rsfe();
    if (i__2 != 0) {
	goto L999;
    }
    if (s_cmp(line, "%%", 2L, 2L) == 0) {

/*  Ignore next line */

	s_rsfe(&io___52);
	do_fio(&c__1, line, 128L);
	e_rsfe();
	if (i_indx("h XXl ", line, 6L, 2L) > 0) {
	    s_rsfe(&io___53);
	    do_fio(&c__1, line, 128L);
	    e_rsfe();
	}
	goto L4;
    } else if (*(unsigned char *)line == '%' && i_indx("1234567", line + 1, 
	    7L, 1L) > 0) {
	lenline = lenstr_(line, &c__128, 128L);
	io___55.ciunit = *(unsigned char *)&line[1] - 38;
	s_wsfe(&io___55);
	do_fio(&c__1, line + 2, lenline - 2);
	e_wsfe();
	goto L4;
    } else if (s_cmp(line, "%!", 2L, 2L) == 0) {
	allparts_(line + 2, &c__126, 126L);
	goto L4;
    } else if (*(unsigned char *)line == 'T') {
	allparts_(line, &c__128, 128L);
	s_rsfe(&io___56);
	do_fio(&c__1, line, 128L);
	e_rsfe();
	allparts_(line, &c__128, 128L);
	goto L4;
    } else /* if(complicated condition) */ {
/* Writing concatenation */
	i__1[0] = 1, a__1[0] = sq;
	i__1[1] = 1, a__1[1] = sq;
	s_cat(ch__7, a__1, i__1, &c__2, 2L);
	if (s_cmp(line, ch__7, 2L, 2L) == 0 || *(unsigned char *)line == '%') 
		{
	    allparts_(line, &c__128, 128L);
	    goto L4;
	} else if (i_indx("hl", line, 2L, 1L) > 0 && i_indx(" +-", line + 1, 
		3L, 1L) > 0) {
/*    *    line(2:2).eq.' ') then */
/*       call allparts(line(1:1),1) */
	    allparts_(line, &c__128, 128L);
	    s_rsfe(&io___57);
	    do_fio(&c__1, line, 128L);
	    e_rsfe();
	    allparts_(line, &c__128, 128L);
	    goto L4;
	} else if (iv == 1) {
	    for (ia = 1; ia <= 9; ++ia) {
		idxa = ntindex_(line, achar + (ia - 1), 128L, 1L);
		isachar = idxa > 0;
		if (idxa > 1) {
		    i__2 = idxa - 2;
		    isachar = s_cmp(line + i__2, " ", idxa - 1 - i__2, 1L) == 
			    0;
		}
		if (ia == 9) {
		    i__2 = idxa;
		    isachar = isachar && s_cmp(line + i__2, "S", idxa + 1 - 
			    i__2, 1L) == 0;
		}
		if (isachar) {

/*  Find next blank */

		    for (ib = idxa + 1; ib <= 128; ++ib) {
			if (*(unsigned char *)&line[ib - 1] == ' ') {
			    goto L7;
			}
/* L6: */
		    }
		    s_wsle(&io___62);
		    do_lio(&c__9, &c__1, "Problem with \"V,R,m,P,A,h,MS, o\
r w\"", 35L);
		    e_wsle();
		    s_wsle(&io___63);
		    do_lio(&c__9, &c__1, "Send files to Dr. Don at dsimons@l\
ogicon.com", 44L);
		    e_wsle();
		    s_stop("", 0L);
L7:

/*  Next blank is at position ib */

		    if (ia == 4) {

/* Check for terminal repeat.  Note if there's a term 
rpt, there can't be any*/
/*  others.  Also, must process repeats LAST, after m'
s and 'V's */

			for (ic = ib + 1; ic <= 128; ++ic) {
			    if (i_indx(" /", line + (ic - 1), 2L, 1L) == 0) {
				goto L9;
			    }
			    if (*(unsigned char *)&line[ic - 1] == '/') {
				termrpt = TRUE_;

/*  Process the line as if there were no "R" 
*/

				goto L10;
			    }
/* L8: */
			}

/* If here, all chars after "R" symbol are blanks, so 
process the line normally*/

		    } else if (ia == 1) {

/*  Do not transfer P into parts. */

			goto L12;
		    } else if (ia == 9) {

/* Start Saving a macro. After leaving here, a symbol 
will be sent to all parts,*/
/*  If all on this line, set ib to end and exit normal
ly. */

			i__2 = ib;
			ndxm = i_indx(line + i__2, "M", 128 - i__2, 1L);
			i__2 = ib + ndxm - 2;
			if (ndxm > 0 && s_cmp(line + i__2, " ", ib + ndxm - 1 
				- i__2, 1L) == 0) {

/*  Macro ends on this line */

			    ib = ib + ndxm + 1;
			} else {

/*  Save leading part of current line */

			    lenhold = idxa - 1;
			    if (lenhold > 0) {
				s_copy(holdln, line, 128L, lenhold);
			    }

/*  Transfer rest of line */

			    i__2 = 129 - idxa;
			    allparts_(line + (idxa - 1), &i__2, 128 - (idxa - 
				    1));

/*  Read next line */

L20:
			    s_rsfe(&io___67);
			    do_fio(&c__1, line, 128L);
			    e_rsfe();

/*  Check for comment, transfer and loop if so */

			    if (*(unsigned char *)line == '%') {
				allparts_(line, &c__128, 128L);
				goto L20;
			    }

/*  Look for terminal ' M' */

			    if (*(unsigned char *)line == 'M') {
				ndxm = 1;
			    } else {
				ndxm = i_indx(line, " M", 128L, 2L);
				if (ndxm > 0) {
				    ++ndxm;
				}
			    }
			    if (ndxm > 0) {

/* Set parameters, exit normally (but later ch
eck for leading part of 1st line*/

				idxa = 1;
				ib = ndxm + 1;
			    } else {

/*  No "M", transfer entire line, loop */

				allparts_(line, &c__128, 128L);
				goto L20;
			    }
			}
		    }
L9:
		    i__2 = ib - idxa;
		    allparts_(line + (idxa - 1), &i__2, ib - 1 - (idxa - 1));
L12:

/*  Remove the string from line */

		    if (idxa == 1) {
			s_copy(line, line + (ib - 1), 128L, 128 - (ib - 1));
		    } else {
/* Writing concatenation */
			i__1[0] = idxa - 1, a__1[0] = line;
			i__1[1] = 128 - (ib - 1), a__1[1] = line + (ib - 1);
			s_cat(line, a__1, i__1, &c__2, 128L);
		    }
		    lenline = lenstr_(line, &c__128, 128L);

/*  Loop if only blanks are left */

		    if (lenline == 0) {
			goto L4;
		    }

/*  Tack on front part from 1st line of saved macro */

		    if (lenhold > 0) {
/* Writing concatenation */
			i__5[0] = lenhold, a__3[0] = holdln;
			i__5[1] = 1, a__3[1] = " ";
			i__5[2] = lenline, a__3[2] = line;
			s_cat(line, a__3, i__5, &c__3, 128L);
			lenhold = 0;
		    }
		}
/* L5: */
	    }
	}
    }

/*  Now a special loop to remove 'X'.  If it was %[n]X..., will have been 
*/
/*  copied into part [n] already. */

L10:
    nchk = 1;
L13:
    ntinx = nchk - 1 + ntindex_(line + (nchk - 1), "X", 128 - (nchk - 1), 1L);
    if (ntinx > nchk - 1) {

/* There is a non-TeX 'X' in this line.  Loop if not 1st or preceded b
y blank.*/

	if (ntinx > 1) {
	    i__2 = ntinx - 2;
	    if (s_cmp(line + i__2, " ", ntinx - 1 - i__2, 1L) != 0) {

/*  The X is embedded in a PMX command.  Advance starting poin
t, loop. */

		nchk = ntinx + 1;
		goto L13;
	    }
	}

/*c  We now know the X starts a PMX command, so remove it. First, find
 next blank*/
/*  We now know the X starts a PMX command.  Find next blank */

	i__2 = ntinx;
	ib = ntinx + i_indx(line + i__2, " ", 128 - i__2, 1L);
	i__2 = ib - 2;
	if (i_indx(":S", line + i__2, 2L, ib - 1 - i__2) > 0) {

/*  The X command is a shift, not a hardspace.  Do not remove it 
*/

	    nchk = ib + 1;
	    goto L13;
	}
	if (ntinx == 1) {
	    i__2 = ib;
	    s_copy(line, line + i__2, 128L, 128 - i__2);
	} else {
	    i__2 = ib;
/* Writing concatenation */
	    i__1[0] = ntinx - 1, a__1[0] = line;
	    i__1[1] = 128 - i__2, a__1[1] = line + i__2;
	    s_cat(line, a__1, i__1, &c__2, 128L);
	}

/*  Resume checking after location of removed command. */

	nchk = ntinx;
	goto L13;
    }

/*  Done with loop for X-checks */

    oneof2 = ntindex_(line, "//", 128L, 2L) > 0;
    lenline = lenstr_(line, &c__128, 128L);
    if (termrpt && iv > nv - all_1.noinst + 1 && frstln && *(unsigned char *)&
	    line[lenline - 1] == '/') {

/*  Must add a terminal repeat before the slash */

	if (oneof2) {
	    --lenline;
	}
	io___71.ciunit = iinst + 10;
	s_wsfe(&io___71);
	do_fio(&c__1, line, lenline - 1);
	e_wsfe();
	if (! oneof2) {
	    s_copy(line, "Rr /", 128L, 4L);
	    lenline = 4;
	} else {
	    s_copy(line, "Rr //", 128L, 5L);
	    lenline = 5;
	}
	if (iv == nv) {
	    termrpt = FALSE_;
	}
    }
    io___72.ciunit = iinst + 10;
    s_wsfe(&io___72);
    do_fio(&c__1, line, lenline);
    e_wsfe();
    if (oneof2) {
	frstln = FALSE_;
    } else if (! frstln) {
	frstln = TRUE_;
    }
    if (ntindex_(line, "/", 128L, 1L) > 0 && i_indx(line, "//", 128L, 2L) == 
	    0) {
	iv = iv % nv + 1;
	if (iv == 1 || iv > nvi[0]) {
	    iinst = iinst % all_1.noinst + 1;
	}
    }
    goto L4;
L999:
    cl__1.cerr = 0;
    cl__1.cunit = 10;
    cl__1.csta = 0;
    f_clos(&cl__1);
    i__2 = all_1.noinst;
    for (iinst = 1; iinst <= i__2; ++iinst) {
	if (nvi[iinst - 1] == 1) {
	    mbrests_(&iinst, jobname, &ljob, 12L);
	} else {

/*  Send a signal to bypass mbrest processing */

	    i__3 = -ljob;
	    mbrests_(&iinst, jobname, &i__3, 12L);
	}
/* L11: */
    }
} /* MAIN__ */

integer lenstr_(string, n, string_len)
char *string;
integer *n;
ftnlen string_len;
{
    /* System generated locals */
    integer ret_val;

    for (ret_val = *n; ret_val >= 1; --ret_val) {
	if (*(unsigned char *)&string[ret_val - 1] != ' ') {
	    return ret_val;
	}
/* L1: */
    }
    ret_val = 0;
    return ret_val;
} /* lenstr_ */

/* Subroutine */ int allparts_(string, n, string_len)
char *string;
integer *n;
ftnlen string_len;
{
    /* System generated locals */
    integer i__1;

    /* Builtin functions */
    /* Subroutine */ int s_copy();
    integer s_wsfe(), do_fio(), e_wsfe();

    /* Local variables */
    static integer iv;
    extern integer lenstr_();
    static integer len;

    /* Fortran I/O blocks */
    static cilist io___75 = { 0, 0, 0, "(a)", 0 };


    len = lenstr_(string, n, string_len);
    if (len == 0) {
	len = 1;
	s_copy(string, " ", string_len, 1L);
    }
    i__1 = all_1.noinst;
    for (iv = 1; iv <= i__1; ++iv) {
	io___75.ciunit = iv + 10;
	s_wsfe(&io___75);
	do_fio(&c__1, string, len);
	e_wsfe();
/* L1: */
    }
    return 0;
} /* allparts_ */

/* Subroutine */ int mbrests_(iv, jobname, ljob, jobname_len)
integer *iv;
char *jobname;
integer *ljob;
ftnlen jobname_len;
{
    /* System generated locals */
    address a__1[3], a__2[2];
    integer i__1[3], i__2, i__3[2];
    real r__1;
    char ch__1[17], ch__2[1], ch__3[2], ch__4[10];
    cilist ci__1;
    olist o__1;
    cllist cl__1;
    alist al__1;

    /* Builtin functions */
    integer f_rew();
    /* Subroutine */ int s_cat();
    integer f_open(), s_rsfe(), do_fio(), e_rsfe(), i_indx(), s_wsfe(), 
	    e_wsfe(), s_rsfi(), e_rsfi();
    /* Subroutine */ int s_copy();
    integer s_cmp(), s_wsle(), do_lio(), e_wsle();
    double r_lg10();
    integer f_clos();

    /* Local variables */
    static integer ndig;
    static char line[128*10];
    static integer nmbr, lsym;
    static char line1[128];
    static integer i__, icden, iline, lwbrs, nwbrs, il, iw, lenbar;
    static char sq[1];
    static integer ipenew, mtrden;
    static logical wbrest;
    extern integer lenstr_();
    static integer ip1, lwbrsx, mtrnum;
    static char wbrsym[3*2];
    static integer ipc, ipe, len, idx, lenbeat;
    static logical alldone;
    static char sym[80];
    extern integer ifnodur_(), ntindex_();
    static integer lenmult;
    static logical rpfirst;
    extern /* Subroutine */ int fwbrsym_(), nextsym_();

    /* Fortran I/O blocks */
    static cilist io___79 = { 0, 0, 1, "(a)", 0 };
    static cilist io___82 = { 0, 20, 0, "(a)", 0 };
    static cilist io___83 = { 0, 0, 0, "(a)", 0 };
    static cilist io___84 = { 0, 20, 0, "(a)", 0 };
    static icilist io___85 = { 0, line, 0, "(10x,2i5)", 128, 1 };
    static cilist io___104 = { 0, 0, 1, "(a)", 0 };
    static cilist io___105 = { 0, 20, 0, "(a)", 0 };
    static cilist io___106 = { 0, 20, 0, "(a)", 0 };
    static cilist io___107 = { 0, 6, 0, 0, 0 };
    static cilist io___112 = { 0, 20, 0, "(a)", 0 };
    static cilist io___114 = { 0, 6, 0, 0, 0 };
    static cilist io___116 = { 0, 20, 0, "(a)", 0 };
    static cilist io___118 = { 0, 20, 0, "(a)", 0 };
    static cilist io___119 = { 0, 20, 0, "(a)", 0 };
    static cilist io___120 = { 0, 20, 0, "(a)", 0 };
    static cilist io___121 = { 0, 20, 0, "(a)", 0 };


    *(unsigned char *)sq = '\\';
    alldone = FALSE_;
    al__1.aerr = 0;
    al__1.aunit = *iv + 10;
    f_rew(&al__1);
    o__1.oerr = 0;
    o__1.ounit = 20;
    o__1.ofnmlen = abs(*ljob) + 5;
/* Writing concatenation */
    i__1[0] = abs(*ljob), a__1[0] = jobname;
    *(unsigned char *)&ch__2[0] = *iv + 48;
    i__1[1] = 1, a__1[1] = ch__2;
    i__1[2] = 4, a__1[2] = ".pmx";
    s_cat(ch__1, a__1, i__1, &c__3, 17L);
    o__1.ofnm = ch__1;
    o__1.orl = 0;
    o__1.osta = 0;
    o__1.oacc = 0;
    o__1.ofm = 0;
    o__1.oblnk = 0;
    f_open(&o__1);
    for (i__ = 1; i__ <= 10000; ++i__) {
L13:
	io___79.ciunit = *iv + 10;
	i__2 = s_rsfe(&io___79);
	if (i__2 != 0) {
	    goto L999;
	}
	i__2 = do_fio(&c__1, line, 128L);
	if (i__2 != 0) {
	    goto L999;
	}
	i__2 = e_rsfe();
	if (i__2 != 0) {
	    goto L999;
	}
L7:
	len = lenstr_(line, &c__128, 128L);

/*  Pass-through if inst. #1 has >1 voice. */

	if (*ljob < 0) {
	    goto L2;
	}
	if (i_indx("TtTiTch+h-h l ", line, 14L, 2L) > 0) {

/* Traps titles, instruments, composers, headers, lower strings.  
Read 2 lines.*/

	    s_wsfe(&io___82);
	    do_fio(&c__1, line, len);
	    e_wsfe();
	    io___83.ciunit = *iv + 10;
	    s_rsfe(&io___83);
	    do_fio(&c__1, line, 128L);
	    e_rsfe();
	    len = lenstr_(line, &c__128, 128L);
	    goto L2;
	}
	if (i__ == 1 || i__ > 5 && *(unsigned char *)&line[0] == 'm') {
	    if (*(unsigned char *)&line[0] == '%') {
		s_wsfe(&io___84);
		do_fio(&c__1, line, len);
		e_wsfe();
		goto L13;
	    }
	    if (i__ == 1) {
		s_rsfi(&io___85);
		do_fio(&c__1, (char *)&mtrnum, (ftnlen)sizeof(integer));
		do_fio(&c__1, (char *)&mtrden, (ftnlen)sizeof(integer));
		e_rsfi();
	    } else {
		icden = 3;
		if (*(unsigned char *)&line[1] == 'o') {
		    mtrnum = 1;
		} else {
		    mtrnum = *(unsigned char *)&line[1] - 48;
		    if (mtrnum == 1) {
			icden = 4;
			mtrnum = *(unsigned char *)&line[2] - 38;
		    }
		}
		mtrden = *(unsigned char *)&line[icden - 1] - 48;
	    }
	    lenbeat = ifnodur_(&mtrden, "x", 1L);
	    lenmult = 1;
	    if (mtrden == 2) {
		lenbeat = 16;
		lenmult = 2;
	    }
	    lenbar = lenmult * mtrnum * lenbeat;
	    fwbrsym_(&lenbar, &nwbrs, wbrsym, &lwbrs, 3L);
	}
	ip1 = 0;
	s_copy(line1, line, 128L, 128L);
	i__2 = nwbrs;
	for (iw = 0; iw <= i__2; ++iw) {
	    if (iw > 0) {
		idx = ntindex_(line1, wbrsym + (iw - 1) * 3, 128L, lwbrs);
	    } else {
		idx = ntindex_(line1, "rp", 128L, 2L);
	    }
	    if (idx > 0) {
		if (ip1 == 0) {
		    ip1 = idx;
		} else {
		    ip1 = min(ip1,idx);
		}
	    }
/* L3: */
	}
/* Writing concatenation */
	i__3[0] = 1, a__2[0] = sq;
	i__3[1] = 1, a__2[1] = sq;
	s_cat(ch__3, a__2, i__3, &c__2, 2L);
	if (i__ <= 5 || *(unsigned char *)&line[0] == '%' || s_cmp(line, 
		ch__3, 2L, 2L) == 0 || ip1 == 0) {
	    goto L2;
	}

/*  Switch to multibar rest search mode!!!  Start forward in line(1) 
*/

	rpfirst = s_cmp(line1 + (ip1 - 1), "rp", 2L, 2L) == 0;
	iline = 1;
	nmbr = 1;
	if (rpfirst) {
	    lwbrsx = 2;
	} else {
	    lwbrsx = lwbrs;
	}
	ipe = ip1 + lwbrsx - 1;
L4:
	if (ipe == len) {

/*  Need a new line */

	    ++iline;
L6:
	    io___104.ciunit = *iv + 10;
	    i__2 = s_rsfe(&io___104);
	    if (i__2 != 0) {
		goto L998;
	    }
	    i__2 = do_fio(&c__1, line + (iline - 1 << 7), 128L);
	    if (i__2 != 0) {
		goto L998;
	    }
	    i__2 = e_rsfe();
	    if (i__2 != 0) {
		goto L998;
	    }
	    len = lenstr_(line + (iline - 1 << 7), &c__128, 128L);
	    if (*(unsigned char *)&line[(iline - 1) * 128] == '%') {
		s_wsfe(&io___105);
		do_fio(&c__1, "% Following comment has been moved forward", 
			42L);
		e_wsfe();
		s_wsfe(&io___106);
		do_fio(&c__1, line + (iline - 1 << 7), len);
		e_wsfe();
		goto L6;
	    }
	    ipe = 0;
	    goto L4;
L998:

/*  No more input left */

	    s_wsle(&io___107);
	    do_lio(&c__9, &c__1, "All done!", 9L);
	    e_wsle();
	    alldone = TRUE_;
	    ipe = 0;
	    --iline;
	    goto L4;
	} else {
	    if (alldone) {
		*(unsigned char *)sym = ' ';
	    } else {

/*  ipe<len here, so it's ok to get a symbol */

		nextsym_(line + (iline - 1 << 7), &len, &ipe, &ipenew, sym, &
			lsym, 128L, 80L);
	    }

/*  Check for end of block or bar line symbol */

	    if (i_indx("/|", sym, 2L, 1L) > 0) {
		ipe = ipenew;
		goto L4;
	    } else {
		wbrest = FALSE_;
		if (alldone) {
		    goto L12;
		}
		i__2 = nwbrs;
		for (iw = 1; iw <= i__2; ++iw) {
		    wbrest = wbrest || s_cmp(sym, wbrsym + (iw - 1) * 3, lsym,
			     lwbrs) == 0;
/* L5: */
		}
		wbrest = wbrest || s_cmp(sym, "r", lsym, 1L) == 0 && lwbrs == 
			2 || s_cmp(sym, "rd", lsym, 2L) == 0 && lwbrs == 3 || 
			s_cmp(sym, "rp", lsym, 2L) == 0 || s_cmp(sym, "r", 
			lsym, 1L) == 0 && rpfirst;
L12:
		if (wbrest) {
		    ipe = ipenew;
		    ++nmbr;
		    goto L4;
		} else {

/*  AHA! Failed prev. test, so last symbol was *not* mbr. 
*/
/*  It must be saved, and its starting position is ipenew-
lsym+1 */

		    if (nmbr > 1) {

/*  Write stuff up to start of mbr */

			if (ip1 > 1) {
			    s_wsfe(&io___112);
			    do_fio(&c__1, line, ip1 - 1);
			    e_wsfe();
			}

/* Insert mbr symbol.  Always end with a slash just in
 case next sym must be*/
/*  at start of block.  May think this causes undefine
d octaves, but */
/*  probably not since it's a single voice. */

			r__1 = nmbr + (float).01;
			ndig = (integer) r_lg10(&r__1) + 1;
			s_wsle(&io___114);
			do_lio(&c__9, &c__1, "Inserting rm, iv,nmbr:", 22L);
			do_lio(&c__3, &c__1, (char *)&(*iv), (ftnlen)sizeof(
				integer));
			do_lio(&c__3, &c__1, (char *)&nmbr, (ftnlen)sizeof(
				integer));
			e_wsle();
			ci__1.cierr = 0;
			ci__1.ciunit = 20;
/* Writing concatenation */
			i__1[0] = 5, a__1[0] = "(a2,i";
			*(unsigned char *)&ch__2[0] = ndig + 48;
			i__1[1] = 1, a__1[1] = ch__2;
			i__1[2] = 4, a__1[2] = ",a2)";
			ci__1.cifmt = (s_cat(ch__4, a__1, i__1, &c__3, 10L), 
				ch__4);
			s_wsfe(&ci__1);
			do_fio(&c__1, "rm", 2L);
			do_fio(&c__1, (char *)&nmbr, (ftnlen)sizeof(integer));
			do_fio(&c__1, " /", 2L);
			e_wsfe();
			if (alldone) {
			    goto L999;
			}
			ipc = ipenew - lsym + 1;
			s_copy(line, line + ((iline - 1 << 7) + (ipc - 1)), 
				128L, len - (ipc - 1));
		    } else {

/*  Write old stuff up to end of original lonesome wbr
, save the rest. */
/* 4 cases:  (wbr /) , (wbr line-end) , (wbr followed 
by other non-/ symbols) ,*/
/*      alldone. */
/* In 1st 2 will have gotten some other lines, so writ
e all up to one b4 last*/
/* non-comment line; then revert to normal mode on tha
t.  In 3rd case must*/
/*  split line. */

			if (alldone) {
			    s_wsfe(&io___116);
			    do_fio(&c__1, line, len);
			    e_wsfe();
			    goto L999;
			} else if (iline > 1) {
			    i__2 = iline - 1;
			    for (il = 1; il <= i__2; ++il) {
				len = lenstr_(line + (il - 1 << 7), &c__128, 
					128L);
				s_wsfe(&io___118);
				do_fio(&c__1, line + (il - 1 << 7), len);
				e_wsfe();
/* L9: */
			    }
			    s_copy(line, line + (iline - 1 << 7), 128L, 128L);
			} else {

/*  Since iline = 1 the wbr is not the last sym, s
o must split */

			    s_wsfe(&io___119);
			    do_fio(&c__1, line, ip1 + lwbrsx - 1);
			    e_wsfe();
			    i__2 = ip1 + lwbrsx;
			    s_copy(line, line + i__2, 128L, len - i__2);
			}
		    }

/*  Exit multibar mode */

		    goto L7;
		}
	    }
	}
/* 2       write(20,'(a)')line(1)(1:len) */
L2:
	if (len > 0) {
	    s_wsfe(&io___120);
	    do_fio(&c__1, line, len);
	    e_wsfe();
	} else {
	    s_wsfe(&io___121);
	    do_fio(&c__1, " ", 1L);
	    e_wsfe();
	}
/* L1: */
    }
L999:
    cl__1.cerr = 0;
    cl__1.cunit = *iv + 10;
    cl__1.csta = 0;
    f_clos(&cl__1);
    cl__1.cerr = 0;
    cl__1.cunit = 20;
    cl__1.csta = 0;
    f_clos(&cl__1);
    return 0;
} /* mbrests_ */

integer ifnodur_(idur, dotq, dotq_len)
integer *idur;
char *dotq;
ftnlen dotq_len;
{
    /* System generated locals */
    integer ret_val;

    /* Builtin functions */
    integer s_wsle(), do_lio(), e_wsle();
    /* Subroutine */ int s_stop();

    /* Fortran I/O blocks */
    static cilist io___122 = { 0, 6, 0, 0, 0 };


    if (*idur == 6) {
	ret_val = 1;
    } else if (*idur == 3) {
	ret_val = 2;
    } else if (*idur == 1) {
	ret_val = 4;
    } else if (*idur == 8) {
	ret_val = 8;
    } else if (*idur == 4) {
	ret_val = 16;
    } else if (*idur == 2) {
	ret_val = 32;
    } else if (*idur == 0) {
	ret_val = 64;
    } else {
	s_wsle(&io___122);
	do_lio(&c__9, &c__1, "You entered an invalid note-length value", 40L);
	e_wsle();
	s_stop("", 0L);
    }
    if (*(unsigned char *)dotq == 'd') {
	ret_val = ret_val * 3 / 2;
    }
    return ret_val;
} /* ifnodur_ */

/* Subroutine */ int fwbrsym_(lenbar, nwbrs, wbrsym, lwbrs, wbrsym_len)
integer *lenbar, *nwbrs;
char *wbrsym;
integer *lwbrs;
ftnlen wbrsym_len;
{
    /* Builtin functions */
    /* Subroutine */ int s_copy();
    integer s_wsfe(), do_fio(), e_wsfe();

    /* Fortran I/O blocks */
    static cilist io___123 = { 0, 6, 0, "(33H Any whole-bar rests of duratio\
n ,i3,                  26H/64 will not be recognized)", 0 };


    /* Parameter adjustments */
    wbrsym -= 3;

    /* Function Body */
    *nwbrs = 1;
    *lwbrs = 2;
    if (*lenbar == 16) {
	s_copy(wbrsym + 3, "r4", 3L, 2L);
    } else if (*lenbar == 32) {
	s_copy(wbrsym + 3, "r2", 3L, 2L);
    } else if (*lenbar == 64) {
	s_copy(wbrsym + 3, "r0", 3L, 2L);
    } else if (*lenbar == 8) {
	s_copy(wbrsym + 3, "r8", 3L, 2L);
    } else {
	*nwbrs = 2;
	*lwbrs = 3;
	if (*lenbar == 24) {
	    s_copy(wbrsym + 3, "rd4", 3L, 3L);
	    s_copy(wbrsym + 6, "r4d", 3L, 3L);
	} else if (*lenbar == 48) {
	    s_copy(wbrsym + 3, "rd2", 3L, 3L);
	    s_copy(wbrsym + 6, "r2d", 3L, 3L);
	} else if (*lenbar == 96) {
	    s_copy(wbrsym + 3, "rd0", 3L, 3L);
	    s_copy(wbrsym + 6, "r0d", 3L, 3L);
	} else {
	    s_wsfe(&io___123);
	    do_fio(&c__1, (char *)&(*lenbar), (ftnlen)sizeof(integer));
	    e_wsfe();
	}
    }
    return 0;
} /* fwbrsym_ */

/* Subroutine */ int nextsym_(line, len, ipeold, ipenew, sym, lsym, line_len, 
	sym_len)
char *line;
integer *len, *ipeold, *ipenew;
char *sym;
integer *lsym;
ftnlen line_len;
ftnlen sym_len;
{
    /* System generated locals */
    integer i__1, i__2;

    /* Builtin functions */
    integer s_wsle(), do_lio(), e_wsle();
    /* Subroutine */ int s_stop(), s_copy();

    /* Local variables */
    static integer ip, iip;

    /* Fortran I/O blocks */
    static cilist io___124 = { 0, 6, 0, 0, 0 };
    static cilist io___125 = { 0, 6, 0, 0, 0 };
    static cilist io___128 = { 0, 6, 0, 0, 0 };



/*  Know its the last symbol if on return ipenew = len!.  So should never 
*/
/*    be called when ipstart=len. */

    if (*ipeold >= *len) {
	s_wsle(&io___124);
	do_lio(&c__9, &c__1, "Called nextsym with ipstart>=len ", 33L);
	e_wsle();
	s_wsle(&io___125);
	do_lio(&c__9, &c__1, "Send files to Dr. Don at dsimons@logicon.com", 
		44L);
	e_wsle();
	s_stop("", 0L);
    }
    i__1 = *len;
    for (ip = *ipeold + 1; ip <= i__1; ++ip) {
	if (*(unsigned char *)&line[ip - 1] != ' ') {

/*  symbol starts here (ip).  We're committed to exit the loop. */

	    if (ip < *len) {
		i__2 = *len;
		for (iip = ip + 1; iip <= i__2; ++iip) {
		    if (*(unsigned char *)&line[iip - 1] != ' ') {
			goto L2;
		    }

/*  iip is the space after the symbol */

		    *ipenew = iip - 1;
		    *lsym = *ipenew - ip + 1;
		    s_copy(sym, line + (ip - 1), 80L, *ipenew - (ip - 1));
		    return 0;
L2:
		    ;
		}

/*  Have len>=2 and ends on len */

		*ipenew = *len;
		*lsym = *ipenew - ip + 1;
		s_copy(sym, line + (ip - 1), 80L, *ipenew - (ip - 1));
		return 0;
	    } else {

/*  ip = len */

		*ipenew = *len;
		*lsym = 1;
		s_copy(sym, line + (ip - 1), 80L, 1L);
		return 0;
	    }
	}
/* L1: */
    }
    s_wsle(&io___128);
    do_lio(&c__9, &c__1, "Error #3.  Send files to Dr. Don at dsimons@logico\
n.com", 55L);
    e_wsle();
} /* nextsym_ */

integer ntindex_(line, s2q, line_len, s2q_len)
char *line, *s2q;
ftnlen line_len;
ftnlen s2q_len;
{
    /* System generated locals */
    integer ret_val, i__1, i__2;

    /* Builtin functions */
    integer i_indx(), s_cmp();

    /* Local variables */
    static integer ndxs2, ndxbs;
    static logical intex;
    static integer ic;
    extern integer lenstr_();
    static integer len;


/*  Returns index(line,s2q) if NOT in TeX string, 0 otherwise */


/*     print*,'Starting ntindex.  s2q:',s2q,', line(1:79) is below' */
/*     print*,line(1:79) */

    ndxs2 = i_indx(line, s2q, 128L, s2q_len);
    ndxbs = i_indx(line, "\\", 128L, 1L);
    if (ndxbs == 0 || ndxs2 < ndxbs) {
	ret_val = ndxs2;
/*     print*,'No bs, or char is left of 1st bs, ntindex:',ntindex */
    } else {

/* There are both bs and s2q, and bs is to the left of sq2. So check b
s's to*/
/*  right of first: End is '\ ', start is ' \' */

	len = lenstr_(line, &c__128, 128L);
	intex = TRUE_;
/*     print*,'intex+>',intex */
	i__1 = len;
	for (ic = ndxbs + 1; ic <= i__1; ++ic) {
	    if (ic == ndxs2) {
		if (intex) {
		    ret_val = 0;
		    i__2 = ic;
		    ndxs2 = i_indx(line + i__2, s2q, len - i__2, s2q_len) + 
			    ic;
/*     print*,'ndxs2 =>',ndxs2 */
		} else {
		    ret_val = ndxs2;
		    return ret_val;
		}
/*     print*,'Internal exit, intex, ntindex:',intex,ntindex 
*/
	    } else /* if(complicated condition) */ {
		i__2 = ic;
		if (intex && s_cmp(line + i__2, "\\ ", ic + 2 - i__2, 2L) == 
			0) {
		    intex = FALSE_;
/*     print*,'intex+>',intex */
		} else /* if(complicated condition) */ {
		    i__2 = ic;
		    if (! intex && s_cmp(line + i__2, " \\", ic + 2 - i__2, 
			    2L) == 0) {
			intex = TRUE_;
/*     print*,'intex+>',intex */
		    }
		}
	    }
/* L1: */
	}
/*     print*,'Out end of loop 1' */
    }
/*     print*,'Exiting ntindex at the end???' */
    return ret_val;
} /* ntindex_ */

/* Subroutine */ int getchar_(line, iccount, charq, line_len, charq_len)
char *line;
integer *iccount;
char *charq;
ftnlen line_len;
ftnlen charq_len;
{
    /* Builtin functions */
    integer s_rsfe(), do_fio(), e_rsfe();

    /* Fortran I/O blocks */
    static cilist io___134 = { 0, 10, 0, "(a)", 0 };



/* Gets the next character out of line*128.  If pointer iccount=128 on ent
ry,*/
/* then reads in a new line.  Resets iccount to position of the new charac
ter.*/

    if (*iccount == 128) {
	s_rsfe(&io___134);
	do_fio(&c__1, line, 128L);
	e_rsfe();
	*iccount = 0;
    }
    ++(*iccount);
    *(unsigned char *)charq = *(unsigned char *)&line[*iccount - 1];
    return 0;
} /* getchar_ */

doublereal readin_(line, iccount, line_len)
char *line;
integer *iccount;
ftnlen line_len;
{
    /* System generated locals */
    address a__1[3];
    integer i__1[3];
    real ret_val;
    char ch__1[27], ch__2[6], ch__3[1];
    icilist ici__1;
    olist o__1;

    /* Builtin functions */
    integer s_rsfe(), do_fio(), e_rsfe(), f_open(), s_wsfe(), e_wsfe(), 
	    i_indx(), s_wsle();
    /* Subroutine */ int s_cat();
    integer do_lio(), e_wsle();
    /* Subroutine */ int s_stop();
    integer s_rsfi(), e_rsfi();

    /* Local variables */
    static char durq[1];
    static integer i1, i2;
    extern integer lenstr_();
    static integer icf;
    extern /* Subroutine */ int getchar_();
    static integer lenline;

    /* Fortran I/O blocks */
    static cilist io___135 = { 0, 10, 0, "(a)", 0 };
    static cilist io___137 = { 0, 30, 0, "(a)", 0 };
    static cilist io___141 = { 0, 6, 0, 0, 0 };



/*  Reads a piece of setup data from line, gets a new line from */
/* file 10 (jobname.pmx) if needed, Transfers comment lines into all parts
.*/

L4:
    if (*iccount == 128) {
L1:
	s_rsfe(&io___135);
	do_fio(&c__1, line, 128L);
	e_rsfe();
	if (*(unsigned char *)line == '%') {
	    if (! comtop_1.topcoms) {

/* Set flag, check it after getting all top data, then put all
 %'s in all parts.*/

		comtop_1.topcoms = TRUE_;

/*  Open file to store top comments */

		o__1.oerr = 0;
		o__1.ounit = 30;
		o__1.ofnm = 0;
		o__1.orl = 0;
		o__1.osta = "SCRATCH";
		o__1.oacc = 0;
		o__1.ofm = 0;
		o__1.oblnk = 0;
		f_open(&o__1);
	    }
	    lenline = lenstr_(line, &c__128, 128L);
	    s_wsfe(&io___137);
	    do_fio(&c__1, line, lenline);
	    e_wsfe();
	    goto L1;
	}
	*iccount = 0;
    }
    ++(*iccount);

/*  Find next non-blank or end of line */

    for (*iccount = *iccount; *iccount <= 127; ++(*iccount)) {
	if (*(unsigned char *)&line[*iccount - 1] != ' ') {
	    goto L3;
	}
/* L2: */
    }

/*  If here, need to get a new line */

    *iccount = 128;
    goto L4;
L3:

/*  iccount now points to start of number to read */

    i1 = *iccount;
L5:
    getchar_(line, iccount, durq, 128L, 1L);

/* Remember that getchar first increments iccount, *then* reads a characte
r.*/

    if (i_indx("0123456789.-", durq, 12L, 1L) > 0) {
	goto L5;
    }
    i2 = *iccount - 1;
    if (i2 < i1) {
	s_wsle(&io___141);
/* Writing concatenation */
	i__1[0] = 7, a__1[0] = "Found \"";
	i__1[1] = 1, a__1[1] = durq;
	i__1[2] = 19, a__1[2] = "\" instead of number";
	s_cat(ch__1, a__1, i__1, &c__3, 27L);
	do_lio(&c__9, &c__1, ch__1, 27L);
	e_wsle();
	s_stop("1", 1L);
    }
    icf = i2 - i1 + 49;
    ici__1.icierr = 0;
    ici__1.iciend = 0;
    ici__1.icirnum = 1;
    ici__1.icirlen = i2 - (i1 - 1);
    ici__1.iciunit = line + (i1 - 1);
/* Writing concatenation */
    i__1[0] = 2, a__1[0] = "(f";
    *(unsigned char *)&ch__3[0] = icf;
    i__1[1] = 1, a__1[1] = ch__3;
    i__1[2] = 3, a__1[2] = ".0)";
    ici__1.icifmt = (s_cat(ch__2, a__1, i__1, &c__3, 6L), ch__2);
    s_rsfi(&ici__1);
    do_fio(&c__1, (char *)&ret_val, (ftnlen)sizeof(real));
    e_rsfi();
    return ret_val;
} /* readin_ */

