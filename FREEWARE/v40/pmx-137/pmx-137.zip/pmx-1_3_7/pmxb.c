/* pmxb.f -- translated by f2c (version 19961017).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/

#include "f2c.h"

/* Common Block Declarations */

union {
    struct {
	integer mult[1400]	/* was [7][200] */, iv, list[800]	/* 
		was [4][200] */, nnl[7], nv, ibar, ipl[1400]	/* was [7][
		200] */, ibm1[56]	/* was [7][8] */, ibm2[56]	/* 
		was [7][8] */, nolev[1400]	/* was [7][200] */, ibmcnt[7],
		 nodur[1400]	/* was [7][200] */, jn, lenbar, iccount, 
		nbars, itsofar[7], nib[105]	/* was [7][15] */, nn[7], 
		lenb0, lenb1;
	real slfac;
	integer musicsize;
	real stemmax, stemmin, stemlen;
	integer mtrnuml, mtrdenl, mtrnmp, mtrdnp, islur[1400]	/* was [7][
		200] */, ifigdrop[125], iline;
	logical figbass, figcheck, firstgulp;
	integer irest[1400]	/* was [7][200] */;
	logical beamon[7], isfig[200];
	char sepsymq[7], sq[1], accq[1400]	/* was [7][200] */, ulq[56]	
		/* was [7][8] */;
	integer iornq[1400]	/* was [7][200] */, isdat1[202], isdat2[202], 
		nsdat;
    } _1;
    struct {
	integer mult[1400]	/* was [7][200] */, jv, list[800]	/* 
		was [4][200] */, nnl[7], nv, ibar, ipl[1400]	/* was [7][
		200] */, ibm1[56]	/* was [7][8] */, ibm2[56]	/* 
		was [7][8] */, nolev[1400]	/* was [7][200] */, ibmcnt[7],
		 nodur[1400]	/* was [7][200] */, jn, lenbar, iccount, 
		nbars, itsofar[7], nib[105]	/* was [7][15] */, nn[7], 
		lenb0, lenb1;
	real slfac;
	integer musicsize;
	real stemmax, stemmin, stemlen;
	integer mtrnuml, mtrdenl, mtrnmp, mtrdnp, islur[1400]	/* was [7][
		200] */, ifigdrop[125], iline;
	logical figbass, figcheck, firstgulp;
	integer irest[1400]	/* was [7][200] */;
	logical beamon[7], isfig[200];
	char sepsymq[7], sq[1], accq[1400]	/* was [7][200] */, ulq[56]	
		/* was [7][8] */;
	integer iornq[1400]	/* was [7][200] */, isdat1[202], isdat2[202], 
		nsdat;
    } _2;
} all_;

#define all_1 (all_._1)
#define all_2 (all_._2)

struct {
    integer ivbjmp;
    logical isbjmp;
} combjmp_;

#define combjmp_1 combjmp_

struct comtitl_1_ {
    char instrq[60], titleq[60], compoq[60];
    logical headlog;
    integer inskip, ncskip, inhead, inbothd;
};

#define comtitl_1 (*(struct comtitl_1_ *) &comtitl_)

union {
    struct {
	integer itfig[74];
	char figq[444];
	integer nfigs;
    } _1;
    struct {
	integer itfig[74];
	char figqq[444];
	integer nfigs;
    } _2;
} comfig_;

#define comfig_1 (comfig_._1)
#define comfig_2 (comfig_._2)

struct {
    integer nspace[20], nb;
    real xtfold[7];
    logical xtupb4;
    integer lastnodur[7];
    real flgndv[7];
    logical flgndb;
    real eskgnd, ptsgnd;
    integer ivmxsav[14]	/* was [7][2] */, nvmxsav[7];
} comnsp_;

#define comnsp_1 comnsp_

struct comstart_1_ {
    char nstartq[90];
    integer lstart[15];
    real facmtr;
};

#define comstart_1 (*(struct comstart_1_ *) &comstart_)

struct {
    integer nfb[7], it1fb[140]	/* was [7][20] */, it2fb[140]	/* was [7][20]
	     */;
    char ulfbq[140]	/* was [7][20] */;
    integer ifb;
} comfb_;

#define comfb_1 comfb_

struct {
    logical lastchar, rptprev, rptfin, sluron[14]	/* was [7][2] */, 
	    fbon, ornrpt;
    integer movbrk, movnmp, movdnp, movgap;
    real parmov, fintstf, gintstf;
    char rptfiq[1];
} comget_;

#define comget_1 comget_

struct {
    integer ibmtyp;
} combeam_;

#define combeam_1 combeam_

struct {
    integer nnodur, lastlev, ndlev[7];
    logical shifton, setis, notcrd;
    integer npreslur;
} comnotes_;

#define comnotes_1 comnotes_

struct {
    integer itopfacteur, ibotfacteur, interfacteur, isig0, isig, lastisig;
    real fracindent, widthpt, height;
    char inameq[553];
    integer idsig;
} comtop_;

#define comtop_1 comtop_

struct {
    integer naskb, itask[20];
    real wask[20], elask[20];
    integer iasxb, nasxb, ipasx[20], ivasx[20];
    real wasx[20], elasx[20];
} comas1_;

#define comas1_1 comas1_

struct {
    integer nasksys;
    real wasksys[400], elasksys[400];
    integer nasxsys;
    real wasxsys[100], elasxsys[100];
} comas2_;

#define comas2_1 comas2_

struct {
    real ask[1000];
    integer iask;
    real asx[200];
    integer iasx;
    logical topmods;
} comas3_;

#define comas3_1 comas3_

union {
    struct {
	logical bar1syst;
	real fixednew, scaldold, apt, abigpt, wheadpt, fbar, poenom;
    } _1;
    struct {
	real bar1syst, fixednew, scaldold, apt, abigpt, wheadpt, fbar, poenom;
    } _2;
} comask_;

#define comask_1 (comask_._1)
#define comask_2 (comask_._2)

union {
    struct {
	integer listslur;
	logical upslur[14]	/* was [7][2] */;
	integer ndxslur;
    } _1;
    struct {
	integer listslur;
	real upslur[14]	/* was [7][2] */;
	integer ndxslur;
    } _2;
} comslur_;

#define comslur_1 (comslur_._1)
#define comslur_2 (comslur_._2)

struct {
    integer is1n1, is2n1, irzbnd, isnx;
} comsln_;

#define comsln_1 comsln_

struct {
    integer ivg[37], ipg[37], nolevg[74], itoff[74];
    real aftshft;
    integer nng[37], ngstrt[37], ibarmbr, mbrest;
    real xb4mbr;
    integer noffseg, ngrace, nvolt, ivlit[36], iplit[36], nlit, lenlit[36], 
	    multg[37];
    logical upg[37], slurg[37], slashg[37];
    char accgq[74], voltxtq[60], litq[4608];
} comgrace_;

#define comgrace_1 comgrace_

struct {
    integer ntrill, ivtrill[18], iptrill[18];
    real xnsktr[18];
    integer ncrd, icrdat[62], icrdot[62], icrdorn[62], nudorn, kudorn[63], 
	    minlev, maxlev, icrd1, icrd2;
} comtrill_;

#define comtrill_1 comtrill_

struct {
    integer ncc[7], itcc[70]	/* was [7][10] */, ncmidcc[70]	/* was [7][10]
	     */, ndotmv[7];
    real updot[140]	/* was [7][20] */, rtdot[140]	/* was [7][20] */;
} comcc_;

#define comcc_1 comcc_

struct {
    logical ispoi;
} compoi_;

#define compoi_1 compoi_

struct {
    logical bcspec;
} combc_;

#define combc_1 combc_

struct {
    real eonk, ewmxk;
} comeon_;

#define comeon_1 comeon_

struct spfacs_1_ {
    real grafac, acgfac, accfac, xspfac, xb4fac, clefac, emgfac, flagfac, 
	    dotfac, bacfac, agc1fac, gslfac, arpfac, rptfac;
    integer lrrptfac;
    real dbarfac, ddbarfac, dotsfac, upstmfac, rtshfac;
};

#define spfacs_1 (*(struct spfacs_1_ *) &spfacs_)

struct {
    real hpttot[176];
} comhsp_;

#define comhsp_1 comhsp_

struct combmh_1_ {
    real bmhgt, clefend;
};

#define combmh_1 (*(struct combmh_1_ *) &combmh_)

struct {
    integer nvmx[7], ivmx[14]	/* was [7][2] */, ivx;
} commvl_;

#define commvl_1 commvl_

struct {
    integer ntrans;
} comtrans_;

#define comtrans_1 comtrans_

struct {
    integer macnum;
    logical mrecord, mplay;
    integer macuse, icchold;
    char lnholdq[128];
    logical endmac;
} commac_;

#define commac_1 commac_

struct {
    real udsp[25];
    integer itudsp[25], nudsp;
    real udoff[140]	/* was [7][20] */;
    integer nudoff[7];
    real uxsp[25];
    integer ivuxsp[25], ipuxsp[25], nuxsp;
} comudsp_;

#define comudsp_1 comudsp_

struct {
    integer ihnum3;
    logical flipend[7];
} strtmid_;

#define strtmid_1 strtmid_

struct {
    integer narp, itar[8], ivar1[8], levar1[8], ncmar1[8];
    real xinsnow;
    logical lowdot;
} comarp_;

#define comarp_1 comarp_

struct {
    integer nvi[7];
} comnvi_;

#define comnvi_1 comnvi_

struct {
    integer ihdht;
    logical lower;
    char headrq[80], lowerq[80];
    integer ihdvrt;
} comhead_;

#define comhead_1 comhead_

struct {
    integer noctup;
} comoct_;

#define comoct_1 comoct_

union {
    struct {
	real xtupfac[7];
	integer n2xtup[20], ixtup;
	logical vxtup[7], inxtup;
	integer ntupv[7], nolev1, islope;
	real xelsk[24], eloff;
    } _1;
    struct {
	real xtupfac[7];
	integer n2xtup[20], ixtup;
	logical vxtup[7], inxtup;
	integer ntupv[7], nole11, islo11;
	real xels11[24], eloff;
    } _2;
} comxtup_;

#define comxtup_1 (comxtup_._1)
#define comxtup_2 (comxtup_._2)

/* Initialized data */

struct {
    real e_1[14];
    integer e_2;
    real e_3[5];
    } spfacs_ = { (float)1.3333, (float).4, (float).7, (float).3, (float).2, (
	    float)2., (float)1., (float).7, (float).7, (float).9, (float).5, (
	    float)9., (float)1.7, (float)1.32, 2, (float).47, (float).83, (
	    float).17, (float).5, (float)1.3 };

struct {
    real e_1[2];
    } combmh_ = { (float)1.1, (float)2.3 };

struct {
    char e_1[180];
    logical e_2;
    integer fill_3[4];
    } comtitl_ = { {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 
	    ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 
	    ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 
	    ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 
	    ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 
	    ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 
	    ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 
	    ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 
	    ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 
	    ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 
	    ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 
	    ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 
	    ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 
	    ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '}, 
	    FALSE_ };

struct {
    char e_1[90];
    integer e_2[15];
    real e_3;
    } comstart_ = { {'n', 'o', 't', 's', 's', ' ', 'd', 'u', 'm', 'm', 'y', 
	    ' ', 'n', 'o', 't', 'e', 's', ' ', 'n', 'o', 't', 'e', 's', 'p', 
	    'N', 'o', 't', 'e', 's', ' ', 'N', 'o', 't', 'e', 's', 'p', 'N', 
	    'O', 't', 'e', 's', ' ', 'N', 'O', 't', 'e', 's', 'p', 'N', 'O', 
	    'T', 'e', 's', ' ', 'N', 'O', 'T', 'e', 's', 'p', 'N', 'O', 'T', 
	    'E', 's', ' ', 'N', 'O', 'T', 'E', 's', 'p', 'N', 'O', 'T', 'E', 
	    'S', ' ', 'N', 'O', 'T', 'E', 'S', 'p', 'N', 'O', 'T', 'E', 'Z', 
	    ' '}, 5, 5, 5, 6, 5, 6, 5, 6, 5, 6, 5, 6, 5, 6, 5, (float).7 };


/* Table of constant values */

static integer c__1 = 1;
static integer c__3 = 3;
static integer c__4 = 4;
static integer c__2 = 2;
static integer c__12 = 12;
static integer c__5 = 5;
static real c_b159 = (float)0.;
static integer c__0 = 0;
static integer c__7 = 7;
static integer c__19 = 19;
static integer c__8 = 8;
static integer c__6 = 6;
static integer c__9 = 9;
static logical c_false = FALSE_;
static logical c_true = TRUE_;
static integer c__10 = 10;
static integer c__80 = 80;
static integer c__34 = 34;
static integer c__23 = 23;
static real c_b792 = (float)-2.;
static integer c__60 = 60;
static integer c__22 = 22;
static integer c__14 = 14;
static integer c__128 = 128;
static integer c__28 = 28;
static integer c__11 = 11;
static integer c__17 = 17;
static integer c__129 = 129;
static integer c__16 = 16;
static integer c__26 = 26;
static integer c__29 = 29;

/* ccccccccccccccccccccccccccccccccccc */
/* c */
/* c  pmxb.for (Version 1.3.7) 4/14/98 */
/* c */
/* cccccccccccccccccccccccccccccc */
/* c */
/* c Need to do */
/* c */
/* c  Rd at end of movement or piece. */
/* c  Add staves/instrument to manual */
/* c  Make inline TeX more context sensitive. */
/* c  Werner's 4/2/98 problem with "o?" */
/* c  Scor2prt converts e.g. "r0+0" into "r0 0", which seems to be wrong. */
/* c    converts e.g. "r2db" into "r2d", which might be wrong. */
/*c  Werner's generalsignature problem with Key change and new transposition.
*/
/* c    (wibug8.pmx) */
/* c  Unequal xtuplets */
/* c  Whole-bar rests with double lines of music */
/* c  Print both sets of bar #'s in tex file. */
/* c  Make barlines invisible \def\xbar{\empty} , fix fbar. */
/* c  Print meter change before page break */
/* c  Auto-tie slurs  'At' */
/* c  Forced line break anywhere (e.g. at a mid-bar repeat). */
/* c  Clef change at very start of file. */
/* c  Accidentals on left-shifted chord note not shifted? */
/* c  Tighten test for M as macro terminator. */
/* c  Rests in xtuplets. */
/* c  Fix title so not separate limit on author length + composer length. */
/* c  Arpeggios in xtups. */
/* c */
/* c mx01b */
/* c  Fix bug in multiple (A (B c4 , replaced preslur by npreslur. */
/* c */
/* c ver1363 */
/*c  alter auto slur-height adjustment with _ or . so user-defined adjustments
*/
/* c     are relative. */
/* c  change \usf (>) to \lsf if user-defined ivoff <-7 */
/* c ver136 */
/* c  >19 beats per bar, alternate meter syntax e.g. m23/16/12/8 */
/* c  Expand binary mask to include ornaments >^ */
/* c  Enable ornrpt in xtup. */
/* c ver135 */
/* c  Fix t-slur auto height change. */
/* c  Fix o> in xtups in pmxa */
/* c  Fix repeated ornament by making durq=' ' */
/* c  Disallow rx3 in pmxa */
/* c mx99 */
/* c  Fix bug in floating figure: increase format to 2 decimals */
/* c  ver134 */
/* c  Placeholder figure '_' */
/* c mx98b */
/*c  Force beam multiplicity (m[digit], flag in islur bit 21, value in 22-24)
*/
/* c  Tie slurs 'st' (isdat2,bit3) */
/* c  \stdstemfalse with graces. (all in pmx.tex, \shlft and \gaft) */
/* c  Force 0-slope beam. 'sh'?  (uses islur bit 2) */
/* c  Fix minor bug in call getfig (itsofar not dimensioned in sub). */
/* c  Fix minor bug (mixed type args) in ihorn = min or max(...) */
/* c  Restrict slur ID codes to caps or numbers. */
/* c pmx133 */
/* c  Double whole notes */
/* c mx97 */
/* c  slurs with external ID. */
/* c mx96 */
/* c  Error Trap for figure before 1st note in a notes group. */
/* c  Error Trap for e.g. x19 7 */
/* c pmx132b */
/* c  Fix bug in 6-character figures (e.g., #2#4n6) */
/* c mx95b */
/* c  Fix meter-only change at end of line to repeat meter at end & start. */
/* c  Fix meter+sig changes midline, end-of-line mid page (repeat both). */
/* c  Rework Ai, AI */
/* c  Clef change after movement break */
/* c  Add ornaments >, ^. */
/* c pmx131b */
/* c  split makeabar in two. */
/* c mx94 */
/*c  Key signature/transposition bugs fixed here and in pmxa by defining idsig
.*/
/* c  Fixed centered whole-bar rest fermata bug by defining cwrferm(iv) */
/* c  Use subroutine getorn to input ornaments. */
/* c  Reorder iornq */
/* c mx93 */
/* c  Include o( in binary mask for ornament repeat toggle. */
/* c  Leave space for o( as if it were and accidental. */
/*c  Special treatment in pmxa of Ai at start, so it gets handled in topfile.
*/
/* c  Set interstaff with Ai[x] where [x] is decimal fraction. */
/* c  Arbitrary # voices per inst: use noinst<0, then nvi(1,...,-noinst) */
/* c  Bug fix for graces with slurs when nnl(ivx)=0 */
/* c  Chords in xtups */
/* c  Need to fix o( o) on dotted half note. */
/* c  Need to check flag spaces at end of line. */
/* c  Need to raise ornaments if on an up-slurred grace. */
/* c mx92 */
/* c  Correct width of brace above xtup for asx's */
/* c  Enable user-define spaces in xtups */
/*c  Check for crashes with right-shifted chord notes (rtshfac, not in xtups)
*/
/* c  Fix moveable dots in normal and shifted chord notes */
/* c  Raise ornaments if slur start or stop. */
/* c  Reverse order of inserting ornaments and slur/graces */
/* c Ver 1.25 */
/* c  Enabled hardspace at end of bar. */
/* c  User-defined shifts   X(number)[p]: =>on, X: =>off */
/* c  Macro Saves (record but don't execute)    MS(integer)  Fix scor2prt */
/* c  Parameterize # of notes/line/input block; check it (pmxa) */
/* c  "o(orn):" = start ornament rpt, "o:" = stop it. */
/* c  put orn rpts in xtups */
/* c Ver 1.24 */
/* c  Change width of format for slur horiz adjustment when shift<-0.95 */
/* c  Redefine ornament height in chords. */
/* c  Movement breaks. */
/* c  Fix slurs + o. */
/* c Ver 1.23 */
/*c  Ornament repeat toggle is ":"; if turning on, must come after ornament*/
/* c  Flip xtup number. */
/* c  Fine-tune height, horiz pos'n of xtup number */
/* c  replace rest by irest */
/* c  Re-order checks on stem-directions for determining slur shifts. */
/* c  Version 1.23 still does not have details for spacing/positioning */
/*c    arpeggios if there are accidentals or shifted notes or crowded scores.
*/
/* c  Fix problem in 1.22 with arpeggios across multi-line staves */
/* c  Fix problem in 1.22 with flat key signatures */
/* c Ver 1.22 */
/* c   Arpeggios '?'. */
/* c Ver 1.21 */
/*c   Editorial accidentals: "oes,f,n" (treated like accid.'s, print above not
e)*/
/*c   Parse setup data from full lines: permit up-front TeX (start & end with
*/
/* c        '---' at start of a line)  & permit comments in setup. */
/* c   Enable midbar Rd . */
/* c   Shortcut 2:1 rhythms, e.g., a4,b = a4 b8 */
/* c */
/* cccccccccccccccccccccccccccccc */
/* Main program */ MAIN__()
{
    /* System generated locals */
    address a__1[2], a__2[12], a__3[4], a__4[5], a__5[2], a__6[3], a__7[8], 
	    a__8[6];
    integer i__1[2], i__2, i__3[12], i__4[4], i__5, i__6, i__7[5], i__8[2], 
	    i__9, i__10[3], i__11[8], i__12[6];
    real r__1, r__2;
    char ch__1[28], ch__2[46], ch__3[19], ch__4[20], ch__5[107], ch__6[12], 
	    ch__7[14], ch__8[15], ch__9[13], ch__10[9], ch__11[11], ch__12[22]
	    , ch__13[4], ch__14[16], ch__15[8], ch__16[18], ch__17[82], 
	    ch__18[1], ch__19[73], ch__20[6], ch__21[70], ch__22[27], ch__23[
	    72], ch__24[40], ch__25[68], ch__26[44], ch__27[5], ch__28[24];
    olist o__1;
    cllist cl__1;
    alist al__1;

    /* Builtin functions */
    integer f_open(), s_rsfe(), do_fio(), e_rsfe(), s_rsle(), do_lio(), 
	    e_rsle();
    /* Subroutine */ int s_cat();
    integer s_wsfe(), e_wsfe(), i_indx();
    double r_dim(), r_lg10();
    integer i_dim();
    /* Subroutine */ int s_copy();
    integer lbit_shift(), f_clos(), s_wsle(), e_wsle(), f_rew();

    /* Local variables */
    extern /* Subroutine */ int clefsym_(), wsclef_();
    static integer islnow, lvoltxt, iplnow;
    static real poe;
    static integer nbarss, ifig;
    static real elsktot;
    static integer ioff;
    static real hesk[19];
    extern doublereal feon_();
    static integer ieneed;
    static char fmtq[24];
    static logical loop;
    static real xmtrnum0, hpts[19], wdpt;
    static logical lrpt, rrpt;
    extern /* Subroutine */ int defnotes_();
    static integer iedo;
    static logical lrptpend;
    extern /* Subroutine */ int setmeter_();
    static integer ndigbn, isn2;
    extern integer igetbits_();
    static integer indsym;
    extern /* Subroutine */ int wgmeter_();
    static integer ipi;
    static real xnstbot;
    static integer islide, icc;
    extern /* Subroutine */ int puttitle_();
    static integer it, icrd, iudorn, isdata;
    extern /* Subroutine */ int setbits_();
    static integer jfig;
    extern /* Subroutine */ int make1bar_();
    static integer nbxtup;
    extern /* Subroutine */ int make2bar_(), askfig_();
    static integer i__, j;
    static logical clchb;
    static integer ipage, lbase, lclef, nclef;
    static char clefq[1*7];
    extern integer ncmid_();
    static logical endon;
    static char basenameq[24];
    static logical clchv[7], slint;
    static char pathnameq[40];
    static integer istop[20];
    static real slfac1, etait, etatc;
    static integer lpath;
    static real etacs1;
    static integer nsyst, iauto;
    static real xintstaff[20];
    static integer lnote, ipnow;
    static real fsyst;
    static integer isdat, iinst, ipnew, iuxsp, ia, itglp1, nxtup;
    static real hardb4;
    static integer ig, il, ibcoff, n1xtup[20], nindex[20];
    static logical evolta;
    static integer numbms[7], istart[20];
    static logical cwrest[7], svolta;
    static integer lbxtup[20];
    static char notexq[79];
    static logical onvolt;
    static integer nsystp[20];
    static real etatop, etabot;
    static integer inhnoh;
    extern /* Subroutine */ int getset_();
    static integer noinst, npages;
    static logical istype0;
    static integer ipa, lenbeat, ibmrep, ibarcnt, nhstot, jprntb, nregon;
    extern /* Subroutine */ int topfile_();
    static integer nhssys;
    extern integer ifnodur_(), ncmidf_();
    static logical vshrink;
    extern /* Subroutine */ int getnote_(), outbar_();
    static integer itstart[20];
    static real ptsndb;
    static integer isystpg, kv;
    static real ptsndv;
    static integer ip;
    static real esk, ptsdflt, xnsttop[20];
    static integer iiv;

    /* Fortran I/O blocks */
    static cilist io___2 = { 0, 12, 0, "(a)", 0 };
    static cilist io___4 = { 0, 12, 0, 0, 0 };
    static cilist io___6 = { 0, 12, 0, 0, 0 };
    static cilist io___21 = { 0, 12, 0, 0, 0 };
    static cilist io___27 = { 0, 13, 0, 0, 0 };
    static cilist io___29 = { 0, 14, 0, "(a)", 0 };
    static cilist io___32 = { 0, 11, 0, "(a)", 0 };
    static cilist io___35 = { 0, 11, 0, "(a)", 0 };
    static cilist io___50 = { 0, 11, 0, "(a5,i3)", 0 };
    static cilist io___51 = { 0, 6, 0, "(/,a19,i4,a1,i4)", 0 };
    static cilist io___61 = { 0, 11, 0, "(a)", 0 };
    static cilist io___70 = { 0, 11, 0, "(a)", 0 };
    static cilist io___71 = { 0, 11, 0, "(a)", 0 };
    static cilist io___72 = { 0, 12, 0, 0, 0 };
    static cilist io___76 = { 0, 11, 0, "(a)", 0 };
    static cilist io___77 = { 0, 11, 0, "(a)", 0 };
    static cilist io___78 = { 0, 11, 0, "(a)", 0 };
    static cilist io___79 = { 0, 11, 0, "(a)", 0 };
    static cilist io___80 = { 0, 11, 0, "(a)", 0 };
    static cilist io___83 = { 0, 11, 0, "(a)", 0 };
    static cilist io___84 = { 0, 11, 0, "(a)", 0 };
    static cilist io___86 = { 0, 11, 0, "(a)", 0 };
    static cilist io___87 = { 0, 11, 0, "(a)", 0 };
    static cilist io___96 = { 0, 11, 0, "(a)", 0 };
    static cilist io___97 = { 0, 12, 0, 0, 0 };
    static cilist io___100 = { 0, 14, 0, "(a9,i2,a10)", 0 };
    static cilist io___104 = { 0, 11, 0, fmtq, 0 };
    static cilist io___106 = { 0, 11, 0, "(a)", 0 };
    static cilist io___107 = { 0, 11, 0, "(a12,2i1,a1)", 0 };
    static cilist io___108 = { 0, 11, 0, "(a13,i2,a1,i1,a1)", 0 };
    static cilist io___110 = { 0, 11, 0, "(a8,i1,a3)", 0 };
    static cilist io___111 = { 0, 11, 0, "(a18,i1,a2)", 0 };
    static cilist io___112 = { 0, 11, 0, "(a18,i2,a2)", 0 };
    static cilist io___114 = { 0, 11, 0, "(a11,i1,a2)", 0 };
    static cilist io___115 = { 0, 11, 0, "(a11,i2,a2)", 0 };
    static cilist io___116 = { 0, 11, 0, "(a)", 0 };
    static cilist io___117 = { 0, 11, 0, "(a)", 0 };
    static cilist io___118 = { 0, 11, 0, "(a)", 0 };
    static cilist io___119 = { 0, 11, 0, "(a)", 0 };
    static cilist io___121 = { 0, 11, 0, fmtq, 0 };
    static cilist io___122 = { 0, 11, 0, "(a)", 0 };
    static cilist io___123 = { 0, 11, 0, fmtq, 0 };
    static cilist io___124 = { 0, 11, 0, "(a)", 0 };
    static cilist io___125 = { 0, 11, 0, "(a)", 0 };
    static cilist io___126 = { 0, 11, 0, "(a)", 0 };
    static cilist io___127 = { 0, 11, 0, "(a)", 0 };
    static cilist io___128 = { 0, 11, 0, "(a)", 0 };
    static cilist io___129 = { 0, 11, 0, "(a)", 0 };
    static cilist io___130 = { 0, 11, 0, "(a)", 0 };
    static cilist io___131 = { 0, 11, 0, "(a)", 0 };
    static cilist io___132 = { 0, 11, 0, "(a)", 0 };
    static cilist io___133 = { 0, 11, 0, "(a)", 0 };
    static cilist io___134 = { 0, 11, 0, "(a)", 0 };
    static cilist io___135 = { 0, 11, 0, "(a)", 0 };
    static cilist io___136 = { 0, 11, 0, "(a16,i1,a14)", 0 };
    static cilist io___137 = { 0, 12, 1, 0, 0 };
    static cilist io___138 = { 0, 11, 0, "(a)", 0 };
    static cilist io___139 = { 0, 11, 0, "(a)", 0 };
    static cilist io___140 = { 0, 11, 0, "(a)", 0 };
    static cilist io___141 = { 0, 11, 0, "(a)", 0 };
    static cilist io___142 = { 0, 11, 0, "(a)", 0 };
    static cilist io___143 = { 0, 11, 0, "(a,2i1,a)", 0 };
    static cilist io___144 = { 0, 11, 0, "(a)", 0 };
    static cilist io___145 = { 0, 11, 0, "(a)", 0 };
    static cilist io___169 = { 0, 11, 0, "(a11,f5.1,a4)", 0 };
    static cilist io___170 = { 0, 11, 0, "(a)", 0 };
    static cilist io___171 = { 0, 11, 0, "(a)", 0 };
    static cilist io___172 = { 0, 6, 0, 0, 0 };
    static cilist io___173 = { 0, 6, 0, 0, 0 };
    static cilist io___174 = { 0, 11, 0, "(a)", 0 };
    static cilist io___175 = { 0, 6, 0, 0, 0 };
    static cilist io___176 = { 0, 11, 0, "(a)", 0 };
    static cilist io___177 = { 0, 11, 0, fmtq, 0 };
    static cilist io___178 = { 0, 11, 0, "(a)", 0 };
    static cilist io___179 = { 0, 11, 0, "(a)", 0 };
    static cilist io___180 = { 0, 11, 0, "(a)", 0 };
    static cilist io___181 = { 0, 14, 0, "(a9,i2,a10)", 0 };
    static cilist io___182 = { 0, 6, 0, 0, 0 };
    static cilist io___183 = { 0, 6, 0, 0, 0 };



/*  FYI /all/ differs in appearance in function ncmid */

/* Bits 1-13: stmgx+Tupf._)  14: Down fermata, was F  15: Trill w/o "tr", 
was U*/

/*  islur is used as a bank of switches */

/*  bit  meaning */
/*  0     slur activity on this note */
/*  1     t-slur here. */
/*  2     force 0-slope beam starting on this note */
/*  3  Unused */
/*  4     grace before main note */
/*  5     left repeat */
/*  6     right repeat */
/*  7     start Volta */
/*  8     doublebar */
/*  9     end Volta */
/*  10    on=>endvoltabox */
/*  11    on=>clefchange */
/*  12-14 0=>treble, ... , 6=>bass */
/*  15    on=> start new block for clef change (maybe diff. voice) */
/*  16    literal TeX string */
/*  17    1=up, 0=down stem for single note (override) See bit 30! */
/*  18    if on, prohibit beaming */
/*  19    if on, full bar rest as pause */
/*  20    Beam multiplicity down-up */
/*  21    Forced multiplicity for any beam including xtups */
/*  22-24 Value of forced multiplicity */
/*  25  Unused */
/*  26    doubleBAR (see bits 5,6,8) */
/*  27-28 Forced beam fine-tune height (1 to 3) */
/*  29    Blank rest */
/*  30    If on, get stem dir'n from bit 17 */
/*  31    If on, suppress printing number with xtuplet starting here */


/*  Bit values for 2nd bank of switches, ipl */

/*  0-7   Location in list [0,200] */
/*  8     \loff */
/*  9     \roff */
/*  10    chord present? */
/*  11-16 Forced beam height adjustment (-30 to +30) */
/*  17-22 Forced beam slope adjustment (-30 to +30) */
/*  23-26 Slur index for Way-after grace.  Inserted when slur is started. 
*/
/*  28    key change: only in voice 1 */
/*  29    Grace after main note. (Type A) */
/*  30    In forced beam.  Signals need to check beam heights */
/*  31    Grace way after main note. (stretch to next note, type W) */

/*  Set up iornq as bitmap. */
/* 0     Ornament "(".  Was user-defined horizontal slur shift on this not
e*/
/*               until 9/24/97; changed that to irest(21) */
/*  1-13  stmgx+Tupf._) */
/*  14    Down fermata, was F */
/*  15    Trill w/o "tr", was U */
/*  16-18 Editorial s,f,n */
/*  19-20 >^ */
/*  21    New ornaments TBD */
/*  22    Set if ihornb governs ornament height.  Same in icrdorn. */
/* 23    Set in getorn if ANY note at time of this main note has ornament.
*/
/*             This is ONLY used in beamstrt to signal whether to do more 
*/
/*             tests for whether ihornb is needed.  (ihornb is only needed
 */
/*             if nonchord+upbm, chord+upbm+top_note, chord+dnbm+bot_note)
 */
/*  24    Slur on after or way-after grace.  Use as signal to START slur. 
*/
/*  25    Tweak orn ht. Same in icrdorn for chord note */
/*  26    Insert user-defined space before this note (was 22) */
/*  27    Arpeggio stop or start (if 2 at same time), or all-in-this-chord
 */
/*  28-31 Value of horiz slur shift, 0...15 => -.8,...,-.1,+.1,...,+.8 */

/*   And now irest is also a set of switches */

/*  0        rest=1, no rest = 0 */
/*  1        There will be a vertical shift for number of this xtup */
/* 2-6      Height shift, 1 => -15, 31 => +15  Indicate by +/- [n] after '
n'*/
/*  7        There is a horizontal shift for xtup number */
/*  9-13     Horiz shift, 1=>-1.5, ... , 31=>+1.5 */
/*  14       Flip up/down-ness of xtup number */
/*  15       Single-voice, single note shift  X(...)[p]S */
/*  16       Start single-voice, multinote shift with this note X(...)[p]:
 */
/* 17       End single-voice, multinote shift after this note. Enter symbo
l*/
/*              after note. X: */
/* 18       User-defined hardspace after last note of bar, *after* this no
te.*/
/*             Value still stored in udoff(ivx,nudoff(ivx)), not with othe
r*/
/*              hardspaces in udsp, to avoid confusion with time checks. 
*/
/*  19       Move the dot.  Data stored in ndotmv,updot,rtdot */
/*  20       Set if right-shifted chord note here.  Use for space checks. 
*/
/*  21       User-defined hardspace in xtup */
/*  22       User-defined slur shift horizontal slur shift. */
/*  23       Set on last note before staff-jumping a beam. */
/*  24       Set on first note after staff-jumping a beam */

/*  isdat1: Slur information */

/*  0-2      ivx */
/*  3-10     ip */
/*  11       start/stop switch */
/*  19-25    ichar(code$) */
/*  26       force direction? */
/*  27       forced dir'n = up if on, set in sslur; also */
/*          final direction, set in doslur when beam is started, used on t
erm.*/
/*  28-31    ndxslur, set in doslur when beam is started, used on term. */

/*  isdat2 */

/*  0        Chord switch.  Not set on main note. */
/*  1-2      left/right notehead shift.  Set only for chord note. */
/*  3        tie positioning */
/*  6-11     voff1 1-63  =>  -31...+31 */
/*  12-18    hoff1 1-127 => -6.3...+6.3 */
/*  19-25    nolev */

/* ccccccccccccccccccccccccccccccc */
    slfac1 = (float).00569;
    all_1.stemmax = (float)8.2;
    all_1.stemmin = (float)3.9;
    all_1.stemlen = (float)6.;
    *(unsigned char *)all_1.sq = '\\';
    combc_1.bcspec = TRUE_;
    comas3_1.topmods = FALSE_;
    o__1.oerr = 0;
    o__1.ounit = 12;
    o__1.ofnmlen = 10;
    o__1.ofnm = "pmxtex.dat";
    o__1.orl = 0;
    o__1.osta = 0;
    o__1.oacc = 0;
    o__1.ofm = 0;
    o__1.oblnk = 0;
    f_open(&o__1);
    s_rsfe(&io___2);
    do_fio(&c__1, basenameq, 24L);
    e_rsfe();
    s_rsle(&io___4);
    do_lio(&c__3, &c__1, (char *)&lbase, (ftnlen)sizeof(integer));
    e_rsle();
    s_rsle(&io___6);
    do_lio(&c__4, &c__1, (char *)&comask_1.fbar, (ftnlen)sizeof(real));
    do_lio(&c__4, &c__1, (char *)&comask_1.apt, (ftnlen)sizeof(real));
    do_lio(&c__4, &c__1, (char *)&comask_1.abigpt, (ftnlen)sizeof(real));
    do_lio(&c__4, &c__1, (char *)&comask_1.wheadpt, (ftnlen)sizeof(real));
    do_lio(&c__4, &c__1, (char *)&etait, (ftnlen)sizeof(real));
    do_lio(&c__4, &c__1, (char *)&etatc, (ftnlen)sizeof(real));
    do_lio(&c__4, &c__1, (char *)&etacs1, (ftnlen)sizeof(real));
    do_lio(&c__4, &c__1, (char *)&etatop, (ftnlen)sizeof(real));
    do_lio(&c__4, &c__1, (char *)&etabot, (ftnlen)sizeof(real));
    do_lio(&c__3, &c__1, (char *)&comtitl_1.inbothd, (ftnlen)sizeof(integer));
    do_lio(&c__3, &c__1, (char *)&inhnoh, (ftnlen)sizeof(integer));
    do_lio(&c__3, &c__1, (char *)&comtop_1.isig, (ftnlen)sizeof(integer));
    e_rsle();
    o__1.oerr = 0;
    o__1.ounit = 10;
    o__1.ofnmlen = lbase + 4;
/* Writing concatenation */
    i__1[0] = lbase, a__1[0] = basenameq;
    i__1[1] = 4, a__1[1] = ".pmx";
    s_cat(ch__1, a__1, i__1, &c__2, 28L);
    o__1.ofnm = ch__1;
    o__1.orl = 0;
    o__1.osta = 0;
    o__1.oacc = 0;
    o__1.ofm = 0;
    o__1.oblnk = 0;
    f_open(&o__1);
    getset_(&all_1.nv, &noinst, &all_1.mtrnuml, &all_1.mtrdenl, &all_1.mtrnmp,
	     &all_1.mtrdnp, &xmtrnum0, &npages, &nsyst, &all_1.musicsize, &
	    comtop_1.fracindent, &istype0, comtop_1.inameq, clefq, 
	    all_1.sepsymq, pathnameq, &lpath, &comtop_1.isig0, 79L, 1L, 1L, 
	    40L);
    s_rsle(&io___21);
    do_lio(&c__3, &c__1, (char *)&npages, (ftnlen)sizeof(integer));
    do_lio(&c__4, &c__1, (char *)&comtop_1.widthpt, (ftnlen)sizeof(real));
    do_lio(&c__4, &c__1, (char *)&comtop_1.height, (ftnlen)sizeof(real));
    do_lio(&c__3, &c__1, (char *)&nsyst, (ftnlen)sizeof(integer));
    i__2 = npages;
    for (ipa = 1; ipa <= i__2; ++ipa) {
	do_lio(&c__3, &c__1, (char *)&nsystp[ipa - 1], (ftnlen)sizeof(integer)
		);
	do_lio(&c__4, &c__1, (char *)&xnsttop[ipa - 1], (ftnlen)sizeof(real));
	do_lio(&c__4, &c__1, (char *)&xintstaff[ipa - 1], (ftnlen)sizeof(real)
		);
    }
    do_lio(&c__3, &c__1, (char *)&iauto, (ftnlen)sizeof(integer));
    e_rsle();
    o__1.oerr = 0;
    o__1.ounit = 13;
    o__1.ofnmlen = 10;
    o__1.ofnm = "pmxtex.fig";
    o__1.orl = 0;
    o__1.osta = 0;
    o__1.oacc = 0;
    o__1.ofm = 0;
    o__1.oblnk = 0;
    f_open(&o__1);
    all_1.figbass = FALSE_;
    s_rsle(&io___27);
    do_lio(&c__3, &c__1, (char *)&ifig, (ftnlen)sizeof(integer));
    e_rsle();
    if (ifig == 1) {
	all_1.figbass = TRUE_;
	o__1.oerr = 0;
	o__1.ounit = 14;
	o__1.ofnm = 0;
	o__1.orl = 0;
	o__1.osta = "SCRATCH";
	o__1.oacc = 0;
	o__1.ofm = 0;
	o__1.oblnk = 0;
	f_open(&o__1);
	s_wsfe(&io___29);
/* Writing concatenation */
	i__3[0] = 1, a__2[0] = all_1.sq;
	i__3[1] = 3, a__2[1] = "def";
	i__3[2] = 1, a__2[2] = all_1.sq;
	i__3[3] = 8, a__2[3] = "fixdrop{";
	i__3[4] = 1, a__2[4] = all_1.sq;
	i__3[5] = 7, a__2[5] = "advance";
	i__3[6] = 1, a__2[6] = all_1.sq;
	i__3[7] = 10, a__2[7] = "sysno by 1";
	i__3[8] = 1, a__2[8] = all_1.sq;
	i__3[9] = 6, a__2[9] = "ifcase";
	i__3[10] = 1, a__2[10] = all_1.sq;
	i__3[11] = 6, a__2[11] = "sysno%";
	s_cat(ch__2, a__2, i__3, &c__12, 46L);
	do_fio(&c__1, ch__2, 46L);
	e_wsfe();
    }
    comget_1.lastchar = FALSE_;
    ibcoff = 0;
    if (xmtrnum0 > (float)0.) {
	ibcoff = -1;
    }
    o__1.oerr = 0;
    o__1.ounit = 11;
    o__1.ofnm = 0;
    o__1.orl = 0;
    o__1.osta = "SCRATCH";
    o__1.oacc = 0;
    o__1.ofm = 0;
    o__1.oblnk = 0;
    f_open(&o__1);
    topfile_(basenameq, &lbase, &all_1.nv, clefq, &noinst, &all_1.musicsize, 
	    xintstaff, &all_1.mtrnmp, &all_1.mtrdnp, &vshrink, &comask_1.fbar,
	     24L, 1L);

/*  Save original printed meter in case movement breaks */

    comget_1.movnmp = all_1.mtrnmp;
    comget_1.movdnp = all_1.mtrdnp;

/*  vshrink for the first page is calculated in topfile, */
/*  and if true set interstaff=10.  vshrink affects Titles. */
/*  Must also save vshrink for page ending. */

    if (all_1.figbass && all_1.musicsize == 16) {
	s_wsfe(&io___32);
/* Writing concatenation */
	i__4[0] = 1, a__3[0] = all_1.sq;
	i__4[1] = 4, a__3[1] = "font";
	i__4[2] = 1, a__3[2] = all_1.sq;
	i__4[3] = 13, a__3[3] = "figfont=cmr8%";
	s_cat(ch__3, a__3, i__4, &c__4, 19L);
	do_fio(&c__1, ch__3, 19L);
	e_wsfe();
    }
    lenbeat = ifnodur_(&all_1.mtrdenl, "x", 1L);
    if (all_1.mtrdenl == 2) {
	lenbeat = 16;
    }
    all_1.lenb1 = all_1.mtrnuml * lenbeat;
    if (all_1.mtrdenl == 2) {
	all_1.lenb1 <<= 1;
    }
    setmeter_(&all_1.mtrnuml, &all_1.mtrdenl, &combeam_1.ibmtyp, &ibmrep);
    all_1.lenb0 = xmtrnum0 * lenbeat + (float).5;
    if (all_1.mtrdenl == 2) {
	all_1.lenb0 <<= 1;
    }
    if (all_1.lenb0 != 0) {
	s_wsfe(&io___35);
/* Writing concatenation */
	i__4[0] = 1, a__3[0] = all_1.sq;
	i__4[1] = 7, a__3[1] = "advance";
	i__4[2] = 1, a__3[2] = all_1.sq;
	i__4[3] = 11, a__3[3] = "barno by -1";
	s_cat(ch__4, a__3, i__4, &c__4, 20L);
	do_fio(&c__1, ch__4, 20L);
	e_wsfe();
	all_1.lenbar = all_1.lenb0;
    } else {
	all_1.lenbar = all_1.lenb1;
    }

/* Initialize system fixed space (pt), removed scalable space (elsk), nask
b*/

    comask_1.fixednew = (float)0.;
    comask_1.scaldold = (float)0.;
    comget_1.fintstf = (float)-1.;
    comget_1.gintstf = (float)1.;
    comas2_1.nasksys = 0;
    comas2_1.nasxsys = 0;
    ibarcnt = 0;
    all_1.iline = 0;
    comget_1.movbrk = 0;
    isystpg = 0;
    ipage = 1;
    all_1.iccount = 128;
    comas3_1.iask = 0;
    comas3_1.iasx = 0;
    nhstot = 0;
    jprntb = 81;
    comtop_1.idsig = 0;

/* Switch bank for which notes groups have been defined.  Runs for whole p
iece.*/

    nregon = 0;

/* Next 5 are raise-barno parameters.  irzbnd is integer part of default l
evel.*/

    comsln_1.irzbnd = 3;
    if (comtop_1.isig == 3 && *(unsigned char *)&clefq[all_1.nv - 1] == 't') {
	comsln_1.irzbnd = 4;
    }
    comsln_1.is1n1 = 0;
    comsln_1.isnx = 0;
    compoi_1.ispoi = FALSE_;
    slint = FALSE_;
    lrptpend = FALSE_;
    endon = FALSE_;
    comget_1.rptfin = FALSE_;
    comget_1.rptprev = FALSE_;
    onvolt = FALSE_;
    comnsp_1.flgndb = FALSE_;
    comget_1.fbon = FALSE_;
    comnotes_1.shifton = FALSE_;
    comget_1.ornrpt = FALSE_;
    comnotes_1.setis = FALSE_;
    comnotes_1.notcrd = TRUE_;
    comarp_1.lowdot = FALSE_;
    comnotes_1.npreslur = 0;
    nhssys = 0;
    comslur_1.listslur = 0;
/*      do 1 ivx = 1 , nm */
/*        ndxslur(ivx,1) = 0 */
/*        ndxslur(ivx,2) = 0 */
/* 1     continue */
    for (i__ = 1; i__ <= 101; ++i__) {
	all_1.isdat1[i__ - 1] = 0;
	all_1.isdat2[i__ - 1] = 0;
/* L31: */
    }
    all_1.nsdat = 0;

/*  Initialize for loop over gulps */

    all_1.firstgulp = TRUE_;

/*  Start a gulp */

L30:
    loop = TRUE_;
    all_1.nbars = 0;
    comfig_1.nfigs = 0;
    comgrace_1.ngrace = 0;
    comtrill_1.ntrill = 0;
    comtrill_1.ncrd = 0;
    comtrill_1.nudorn = 0;
    comgrace_1.nlit = 0;
    comgrace_1.nvolt = 0;
    comgrace_1.ibarmbr = 0;
    comudsp_1.nudsp = 0;
    comudsp_1.nuxsp = 0;

/* Now initialize up to nv.  Do it in getnote as r'qd for 2nd voices per s
yst.*/

/* L3: */
    i__2 = all_1.nv;
    for (all_1.iv = 1; all_1.iv <= i__2; ++all_1.iv) {
	commvl_1.nvmx[all_1.iv - 1] = 1;
	commvl_1.ivmx[all_1.iv - 1] = all_1.iv;
	all_1.itsofar[all_1.iv - 1] = 0;
	all_1.nnl[all_1.iv - 1] = 0;
	comfb_1.nfb[all_1.iv - 1] = 0;
	if (all_1.firstgulp) {
	    comcc_1.ncmidcc[all_1.iv - 1] = ncmidf_(clefq + (all_1.iv - 1), 
		    1L);
	} else {
	    comcc_1.ncmidcc[all_1.iv - 1] = comcc_1.ncmidcc[all_1.iv + 
		    comcc_1.ncc[all_1.iv - 1] * 7 - 8];
	}
	comcc_1.itcc[all_1.iv - 1] = 0;
	comcc_1.ncc[all_1.iv - 1] = 1;
	comudsp_1.nudoff[all_1.iv - 1] = 0;
	comcc_1.ndotmv[all_1.iv - 1] = 0;
	for (j = 1; j <= 200; ++j) {
	    all_1.irest[all_1.iv + j * 7 - 8] = 0;
	    all_1.islur[all_1.iv + j * 7 - 8] = 0;
	    all_1.ipl[all_1.iv + j * 7 - 8] = 0;
	    *(unsigned char *)&all_1.accq[all_1.iv + j * 7 - 8] = 'x';
	    all_1.iornq[all_1.iv + j * 7 - 8] = (float)0.;
	    if (all_1.iv == 1) {
		all_1.isfig[j - 1] = FALSE_;
	    }
/* L5: */
	}
/* L4: */
    }
    all_1.iv = 1;
    commvl_1.ivx = 1;
L2:
    if (loop) {

/* Within this loop, nv voices are filled up for the duration of the b
lock.*/
/*  On exit (loop=.false.) the following are set: nnl(nv),itsofar(nv) 
*/
/*  nolev(nv,nnl(nv)),nodur(..),accq(..),irest(..). */
/*  nbars is for this input block. */
/* Only at the beginning of an input block will there be a possible mt
r change,*/
/* signalled by a nonzero mtrnuml. (which will be re-zeroed right afte
r change)*/

	getnote_(&loop);
	if (comget_1.lastchar) {
	    goto L40;
	}
	goto L2;
    }

/*  Finished an input block (gulp). */

    comgrace_1.nvolt = 0;
    for (all_1.iv = 1; all_1.iv <= 7; ++all_1.iv) {
	comudsp_1.nudoff[all_1.iv - 1] = 0;
	comcc_1.ndotmv[all_1.iv - 1] = 0;
/* L28: */
    }

/* Put in titles at top of p.1.  Must wait until now to have read title in
fo.*/

    if (ibarcnt == 0) {
	puttitle_(&inhnoh, &xnsttop[ipage - 1], &etatop, all_1.sq, &etait, &
		etatc, &etacs1, &all_1.nv, &vshrink, all_1.sepsymq, 1L, 1L);
    }
    i__2 = all_1.nbars;
    for (all_1.ibar = 1; all_1.ibar <= i__2; ++all_1.ibar) {
	++ibarcnt;
	comask_1.bar1syst = ibarcnt == iauto;
	s_wsfe(&io___50);
	do_fio(&c__1, "% bar", 5L);
	i__5 = ibarcnt + ibcoff;
	do_fio(&c__1, (char *)&i__5, (ftnlen)sizeof(integer));
	e_wsfe();
	if (all_1.ibar != comgrace_1.ibarmbr) {
	    i__5 = ibarcnt + ibcoff;
	    outbar_(&i__5, &jprntb);
	} else {
	    s_wsfe(&io___51);
	    do_fio(&c__1, " Multibar rest, bars", 20L);
	    i__5 = ibarcnt + ibcoff;
	    do_fio(&c__1, (char *)&i__5, (ftnlen)sizeof(integer));
	    do_fio(&c__1, "-", 1L);
	    i__6 = ibarcnt + ibcoff + comgrace_1.mbrest - 1;
	    do_fio(&c__1, (char *)&i__6, (ftnlen)sizeof(integer));
	    e_wsfe();
	    jprntb = 0;
	    ibcoff = ibcoff + comgrace_1.mbrest - 1;
	    if (all_1.ibar == 1 && all_1.firstgulp) {
		comgrace_1.xb4mbr = comstart_1.facmtr * all_1.musicsize;
	    }
	}

/* Move the read to after end-of-bar hardspace checks, so we get right
 poenom*/
/*  at end of a line. */
/*       if (bar1syst) read(12,*) poenom */

/* Check for clef at start of bar.  No slide yet.  Also flags at end o
f prev.*/
/* bar.  This block is run at the start of every bar.  May fail for fl
ag at*/
/*  end of last bar.  To account for necc. hardspaces, compute and sto
re */
/*    nhssys = # of hard spaces for this system */
/*    hesk(nhssys) = elemskips avialable */
/*    hpts(nhssys) = hard points needed, including notehead */
/* Here, merely insert placeholder into output.  Later, when poe is co
mputed,*/
/* compute additional pts and store them in hpttot(1...nhstot).  Final
ly in*/
/*  subroutine askfig, write true pts where placeholders are. */

	ioff = 0;
	if (all_1.ibar > 1) {
	    ioff = all_1.nib[(all_1.ibar - 1) * 7 - 7];
	}
	clchb = bit_test(all_1.islur[(ioff + 1) * 7 - 7],15);
	if (! (clchb || comnsp_1.flgndb)) {
	    goto L23;
	}

/*  Must check available space */

	ptsndb = (float)0.;

/*  Zero out block signal */

	if (clchb) {
	    all_1.islur[(ioff + 1) * 7 - 7] = bit_clear(all_1.islur[(ioff + 1)
		     * 7 - 7],15);
	}

/*  In this loop, we determine how much hardspace is needed (if any) 
*/
/*  9/7/97  Note that for last bar in input block, if number of lines 
of */
/*    music decreases in new block, highest numbered ones won't be che
cked */
/*   since the loop below covers the new nvmx(iv), not necessarily the
 old*/
/*    one. */

	i__5 = all_1.nv;
	for (all_1.iv = 1; all_1.iv <= i__5; ++all_1.iv) {
	    i__6 = comnsp_1.nvmxsav[all_1.iv - 1];
	    for (kv = 1; kv <= i__6; ++kv) {
		commvl_1.ivx = comnsp_1.ivmxsav[all_1.iv + kv * 7 - 8];
		ptsndv = comnsp_1.flgndv[commvl_1.ivx - 1] * comask_1.wheadpt;
		ioff = 0;
		if (all_1.ibar > 1) {
		    ioff = all_1.nib[commvl_1.ivx + (all_1.ibar - 1) * 7 - 8];
		    ip = ioff;
		    if (all_1.ibar > 2) {
			ip = ioff - all_1.nib[commvl_1.ivx + (all_1.ibar - 2) 
				* 7 - 8];
		    }
		    comnsp_1.lastnodur[commvl_1.ivx - 1] = all_1.nodur[
			    commvl_1.ivx + ip * 7 - 8];

/*If ibar=1 (1st bar in input block), lastnodur(ivx) was s
et at end of makeabar.*/

		}

/*  Only allow clef changes when ivx <= nv */

		if (commvl_1.ivx <= all_1.nv) {
		    clchv[all_1.iv - 1] = clchb && bit_test(all_1.islur[
			    all_1.iv + (ioff + 1) * 7 - 8],11);
		    if (clchv[all_1.iv - 1]) {

/*  Clef change in this voice.  Turn off signal.  Get 
space avail. */

			all_1.islur[all_1.iv + (ioff + 1) * 7 - 8] = 
				bit_clear(all_1.islur[all_1.iv + (ioff + 1) * 
				7 - 8],11);
			if (comnsp_1.lastnodur[all_1.iv - 1] == 
				comnsp_1.nspace[comnsp_1.nb - 1]) {
			    ptsndv += combmh_1.clefend * comask_1.wheadpt;
			}
		    }
		}
/* Computing MAX */
		r__1 = ptsndb, r__2 = ptsndv + comask_1.wheadpt * 
			spfacs_1.xspfac;
		ptsndb = dmax(r__1,r__2);
/* L16: */
	    }
	}

/* ????  where is nb set???  nb probably in left over from makeabar */

	r__1 = (real) comnsp_1.nspace[comnsp_1.nb - 1];
	esk = feon_(&r__1);
	ptsdflt = esk * comask_1.poenom - comask_1.wheadpt;
	if ((ptsndb > ptsdflt || comnsp_1.ptsgnd > (float)0.) && 
		comget_1.movbrk == 0) {

/* Must ADD hardspace!  So put in a placeholder, and store params 
for later.*/

	    s_wsfe(&io___61);
/* Writing concatenation */
	    i__1[0] = 1, a__1[0] = all_1.sq;
	    i__1[1] = 18, a__1[1] = "xardspace{    pt}%";
	    s_cat(ch__3, a__1, i__1, &c__2, 19L);
	    do_fio(&c__1, ch__3, 19L);
	    e_wsfe();
	    ++nhssys;
	    if (ptsndb - ptsdflt > comnsp_1.ptsgnd - comask_1.poenom * 
		    comnsp_1.eskgnd) {
		hesk[nhssys - 1] = esk;
		hpts[nhssys - 1] = ptsndb + comask_1.wheadpt;
	    } else {
		hesk[nhssys - 1] = comnsp_1.eskgnd;
		hpts[nhssys - 1] = comnsp_1.ptsgnd + comask_1.wheadpt;
	    }
	    comask_1.fixednew += hpts[nhssys - 1];
	    comask_1.scaldold += hesk[nhssys - 1];
	}
	if (clchb) {
	    i__6 = all_1.nv;
	    for (all_1.iv = 1; all_1.iv <= i__6; ++all_1.iv) {
		if (clchv[all_1.iv - 1]) {
/* Writing concatenation */
		    i__1[0] = 1, a__1[0] = all_1.sq;
		    i__1[1] = 6, a__1[1] = "znotes";
		    s_cat(notexq, a__1, i__1, &c__2, 79L);
		    lnote = 7;
		    i__5 = all_1.iv;
		    for (iiv = 2; iiv <= i__5; ++iiv) {
/* Writing concatenation */
			i__1[0] = lnote, a__1[0] = notexq;
			i__1[1] = 1, a__1[1] = all_1.sepsymq + (iiv - 2);
			s_cat(notexq, a__1, i__1, &c__2, 79L);
			++lnote;
/* L24: */
		    }

/*  Recompute ioff since it will vary from voice to voice 
*/

		    if (all_1.ibar == 1) {
			ioff = 0;
		    } else {
			ioff = all_1.nib[all_1.iv + (all_1.ibar - 1) * 7 - 8];
		    }

/*  Must call clefsym to get nclef, even if there is a mov
ement break */

		    clefsym_(&all_1.islur[all_1.iv + (ioff + 1) * 7 - 8], 
			    fmtq, &lclef, &nclef, 24L);
		    if (comget_1.movbrk == 0) {
			s_wsfe(&io___70);
/* Writing concatenation */
			i__4[0] = lnote, a__3[0] = notexq;
			i__4[1] = lclef, a__3[1] = fmtq;
			i__4[2] = 1, a__3[2] = all_1.sq;
			i__4[3] = 3, a__3[3] = "en%";
			s_cat(ch__5, a__3, i__4, &c__4, 107L);
			do_fio(&c__1, ch__5, lnote + lclef + 4);
			e_wsfe();
		    }
		    wsclef_(&all_1.iv, &all_1.nv, &noinst, clefq, &nclef, 1L);
		}
/* L17: */
	    }
	    s_wsfe(&io___71);
/* Writing concatenation */
	    i__1[0] = 1, a__1[0] = all_1.sq;
	    i__1[1] = 11, a__1[1] = "pmxnewclefs";
	    s_cat(ch__6, a__1, i__1, &c__2, 12L);
	    do_fio(&c__1, ch__6, 12L);
	    e_wsfe();
	}
L23:

/*  End of loop for end-of-bar hardspaces */

	if (comask_1.bar1syst) {
	    s_rsle(&io___72);
	    do_lio(&c__4, &c__1, (char *)&comask_1.poenom, (ftnlen)sizeof(
		    real));
	    e_rsle();
	}

/* Repeat symbols.  Haven't slid down yet, so use islur(1,nib(1,ibar-1
)+1)*/

	if (all_1.ibar == 1) {
	    islnow = all_1.islur[0];
	} else {
	    islnow = all_1.islur[(all_1.nib[(all_1.ibar - 1) * 7 - 7] + 1) * 
		    7 - 7];
	}
	if ((islnow & 352) != 0) {

/*  Bit 5(lrpt), 6(rrpt), or 8(doublebar) has been set */

	    lrpt = bit_test(islnow,5);
	    rrpt = bit_test(islnow,6);
	    lrptpend = lrpt && comask_1.bar1syst;
	    if (lrpt && ! lrptpend) {
		if (rrpt) {
		    s_wsfe(&io___76);
/* Writing concatenation */
		    i__1[0] = 1, a__1[0] = all_1.sq;
		    i__1[1] = 18, a__1[1] = "setleftrightrepeat";
		    s_cat(ch__3, a__1, i__1, &c__2, 19L);
		    do_fio(&c__1, ch__3, 19L);
		    e_wsfe();
		    comask_1.fixednew = comask_1.fixednew + comask_1.wheadpt *
			     spfacs_1.lrrptfac - (float).4;
		} else {
		    s_wsfe(&io___77);
/* Writing concatenation */
		    i__1[0] = 1, a__1[0] = all_1.sq;
		    i__1[1] = 13, a__1[1] = "setleftrepeat";
		    s_cat(ch__7, a__1, i__1, &c__2, 14L);
		    do_fio(&c__1, ch__7, 14L);
		    e_wsfe();
		    comask_1.fixednew = comask_1.fixednew + comask_1.wheadpt *
			     spfacs_1.rptfac - (float).4;
		}
	    } else if (rrpt) {
		s_wsfe(&io___78);
/* Writing concatenation */
		i__1[0] = 1, a__1[0] = all_1.sq;
		i__1[1] = 14, a__1[1] = "setrightrepeat";
		s_cat(ch__8, a__1, i__1, &c__2, 15L);
		do_fio(&c__1, ch__8, 15L);
		e_wsfe();
		comask_1.fixednew = comask_1.fixednew + comask_1.wheadpt * 
			spfacs_1.rptfac - (float).4;
	    } else if (bit_test(islnow,8)) {
		s_wsfe(&io___79);
/* Writing concatenation */
		i__1[0] = 1, a__1[0] = all_1.sq;
		i__1[1] = 12, a__1[1] = "setdoublebar";
		s_cat(ch__9, a__1, i__1, &c__2, 13L);
		do_fio(&c__1, ch__9, 13L);
		e_wsfe();
		comask_1.fixednew = comask_1.fixednew + comask_1.wheadpt * 
			spfacs_1.dbarfac - (float).4;
	    }
	} else if (bit_test(islnow,26)) {

/*  doubleBAR */

	    s_wsfe(&io___80);
/* Writing concatenation */
	    i__1[0] = 1, a__1[0] = all_1.sq;
	    i__1[1] = 12, a__1[1] = "setdoubleBAR";
	    s_cat(ch__9, a__1, i__1, &c__2, 13L);
	    do_fio(&c__1, ch__9, 13L);
	    e_wsfe();
	    comask_1.fixednew = comask_1.fixednew + comask_1.wheadpt * 
		    spfacs_1.ddbarfac - (float).4;
	}

/*  1st and 2nd endings */

	svolta = bit_test(islnow,7);
	evolta = bit_test(islnow,9);
	if (evolta) {
	    if (bit_test(islnow,10)) {
		s_wsfe(&io___83);
/* Writing concatenation */
		i__1[0] = 1, a__1[0] = all_1.sq;
		i__1[1] = 11, a__1[1] = "endvoltabox";
		s_cat(ch__6, a__1, i__1, &c__2, 12L);
		do_fio(&c__1, ch__6, 12L);
		e_wsfe();
	    } else {
		s_wsfe(&io___84);
/* Writing concatenation */
		i__1[0] = 1, a__1[0] = all_1.sq;
		i__1[1] = 8, a__1[1] = "endvolta";
		s_cat(ch__10, a__1, i__1, &c__2, 9L);
		do_fio(&c__1, ch__10, 9L);
		e_wsfe();
	    }
	    onvolt = FALSE_;
	}
	if (svolta) {
	    ++comgrace_1.nvolt;
	    lvoltxt = i_indx(comgrace_1.voltxtq + (comgrace_1.nvolt - 1) * 10,
		     " ", 10L, 1L) - 1;
	    if (lvoltxt == 1) {
		s_wsfe(&io___86);
/* Writing concatenation */
		i__4[0] = 1, a__3[0] = all_1.sq;
		i__4[1] = 8, a__3[1] = "Setvolta";
		i__4[2] = 1, a__3[2] = comgrace_1.voltxtq + (comgrace_1.nvolt 
			- 1) * 10;
		i__4[3] = 1, a__3[3] = "%";
		s_cat(ch__11, a__3, i__4, &c__4, 11L);
		do_fio(&c__1, ch__11, 11L);
		e_wsfe();
	    } else {
		s_wsfe(&io___87);
/* Writing concatenation */
		i__7[0] = 1, a__4[0] = all_1.sq;
		i__7[1] = 8, a__4[1] = "Setvolta";
		i__7[2] = 1, a__4[2] = "{";
		i__7[3] = lvoltxt, a__4[3] = comgrace_1.voltxtq + (
			comgrace_1.nvolt - 1) * 10;
		i__7[4] = 2, a__4[4] = "}%";
		s_cat(ch__12, a__4, i__7, &c__5, 22L);
		do_fio(&c__1, ch__12, lvoltxt + 12);
		e_wsfe();
	    }
	    onvolt = TRUE_;
	}
	if (all_1.ibar > 1) {
	    ipnow = all_1.nib[(all_1.ibar - 1) * 7 - 7] + 1;
	} else {
	    ipnow = 1;
	}
	iplnow = all_1.ipl[ipnow * 7 - 7];
	if (comask_1.bar1syst) {
	    ++all_1.iline;

/*  End an old system, Start a new system */

	    if (all_1.iline != 1) {

/*  Not first line. */

/*  Get corrected poe = points/elemskip for *previous* system 
*/

		wdpt = comtop_1.widthpt;
		if (all_1.iline == 2 || comget_1.movbrk > 0) {
		    wdpt = comtop_1.widthpt * (1 - comtop_1.fracindent);
		}
		poe = (wdpt - fsyst * all_1.musicsize - nbarss * (float).4 - 
			comask_1.fixednew) / (elsktot + comask_1.fbar * 
			nbarss - comask_1.scaldold);

/*  Transfer data for system into global arrays to hold until 
very end */

		i__6 = comas2_1.nasksys;
		for (ia = 1; ia <= i__6; ++ia) {
		    ++comas3_1.iask;
		    comas3_1.ask[comas3_1.iask - 1] = comas2_1.wasksys[ia - 1]
			     / poe - (r__1 = comas2_1.elasksys[ia - 1], dabs(
			    r__1));

/* Only admit negative ask if it was user-defined space, s
ignalled by elask<=0.*/

		    if (comas2_1.elasksys[ia - 1] > (float)0.) {
			comas3_1.ask[comas3_1.iask - 1] = r_dim(&comas3_1.ask[
				comas3_1.iask - 1], &c_b159);
		    }
/*     print*,'iask,ask,ia,wasksys,poe,elasksys:' */
/*     print*,iask,ask(iask),ia,wasksys(ia),poe,elasksys(i
a) */
/* L9: */
		}
		i__6 = comas2_1.nasxsys;
		for (ia = 1; ia <= i__6; ++ia) {
		    ++comas3_1.iasx;
		    comas3_1.asx[comas3_1.iasx - 1] = comas2_1.wasxsys[ia - 1]
			     / poe - comas2_1.elasxsys[ia - 1];
/* L8: */
		}
		i__6 = nhssys;
		for (ia = 1; ia <= i__6; ++ia) {
		    ++nhstot;
/* Computing MAX */
		    r__1 = hpts[ia - 1] - hesk[ia - 1] * poe;
		    comhsp_1.hpttot[nhstot - 1] = dmax(r__1,(float)0.);
/* L25: */
		}
/*     print*,'widthpt,fsyst,musicsize,elsktot,fbar,nbarss:' 
*/
/*     print*,widthpt,fsyst,musicsize,elsktot,fbar,nbarss */
/*     print*,'poe,fixednew,scaldold:' */
/*     print*,poe,fixednew,scaldold */

/*  Reset counters for new system */

		comask_1.scaldold = (float)0.;
		comask_1.fixednew = (float)0.;
		comas2_1.nasksys = 0;
		comas2_1.nasxsys = 0;
		nhssys = 0;
	    }

/* End of if block for first bar of non-first system. Still 1st ba
r, any system*/

	    if (all_1.figbass) {
		s_wsfe(&io___96);
/* Writing concatenation */
		i__1[0] = 1, a__1[0] = all_1.sq;
		i__1[1] = 8, a__1[1] = "fixdrop%";
		s_cat(ch__10, a__1, i__1, &c__2, 9L);
		do_fio(&c__1, ch__10, 9L);
		e_wsfe();
	    }
	    ++isystpg;
	    if (isystpg == nsystp[ipage - 1]) {
		isystpg = 0;
	    }
/*          read(12,*)nbarss,elsktot,fsyst,eonk,ewmxk,iemin,iemax 
*/
	    s_rsle(&io___97);
	    do_lio(&c__3, &c__1, (char *)&nbarss, (ftnlen)sizeof(integer));
	    do_lio(&c__4, &c__1, (char *)&elsktot, (ftnlen)sizeof(real));
	    do_lio(&c__4, &c__1, (char *)&fsyst, (ftnlen)sizeof(real));
	    do_lio(&c__4, &c__1, (char *)&comeon_1.eonk, (ftnlen)sizeof(real))
		    ;
	    do_lio(&c__4, &c__1, (char *)&comeon_1.ewmxk, (ftnlen)sizeof(real)
		    );
	    do_lio(&c__3, &c__1, (char *)&ieneed, (ftnlen)sizeof(integer));
	    e_rsle();

/* Redefine notes as required.  nregon is a running bitmap of acti
ve, non-tight*/
/*  notes def'ns in TeX file. */

	    if (all_1.iline == 1) {

/*  No checks needed; must write all requested levels. */

		defnotes_(&ieneed);
		if (comeon_1.eonk < (float).001) {
		    nregon = ieneed;
		}
	    } else {

/*  Not first stystem. */

		if (comeon_1.eonk > (float).001) {

/*  Define all necessary notes groups */

		    defnotes_(&ieneed);

/*  Unmark all groups just done from list of regulars */

		    nregon &= ~ ieneed;
		} else {

/*  Regular values.  Get ones needed but not done. */

		    iedo = ieneed & ~ nregon;
		    defnotes_(&iedo);
		    nregon |= iedo;
		}
	    }
	    if (all_1.figbass) {
		all_1.ifigdrop[all_1.iline - 1] = 4;
	    }
	    all_1.slfac = slfac1 * all_1.musicsize * elsktot;
	    if (all_1.iline != 1) {

/*  For the line just _finished_, put figdrop in separate file
. */

		if (all_1.figbass) {
		    s_wsfe(&io___100);
/* Writing concatenation */
		    i__1[0] = 1, a__1[0] = all_1.sq;
		    i__1[1] = 8, a__1[1] = "figdrop=";
		    s_cat(ch__10, a__1, i__1, &c__2, 9L);
		    do_fio(&c__1, ch__10, 9L);
		    do_fio(&c__1, (char *)&all_1.ifigdrop[all_1.iline - 2], (
			    ftnlen)sizeof(integer));
/* Writing concatenation */
		    i__8[0] = 1, a__5[0] = all_1.sq;
		    i__8[1] = 3, a__5[1] = "or%";
		    s_cat(ch__13, a__5, i__8, &c__2, 4L);
		    do_fio(&c__1, ch__13, 4L);
		    e_wsfe();
		}

/*  Check slurs in top staff for interference w/ barno. Only c
heck when */
/* # if digits in barno >= |isig|  But to keep on/off phasing,
 must ALWAYS*/
/*  keep track of ons and offs when |isig|<=3. */

		r__1 = ibarcnt + ibcoff + (float).01;
		ndigbn = (integer) r_lg10(&r__1) + 1;
		comsln_1.isnx = 0;
		if (ndigbn >= abs(comtop_1.isig) && comsln_1.is1n1 > 0) {

/* There's a slur in top voice over the line break, hgt=is
1n1, idcode=is2n1*/
/*  Look for termination in remainder of this input block.
  If not found, */
/*  just use is1n1.  Remember, haven't slid down yet. */

		    isn2 = 0;
		    ioff = 0;
		    if (all_1.ibar > 1) {
			ioff = all_1.nib[commvl_1.ivmx[all_1.nv + 
				commvl_1.nvmx[all_1.nv - 1] * 7 - 8] + (
				all_1.ibar - 1) * 7 - 8];
		    }
		    i__6 = all_1.nsdat;
		    for (isdat = 1; isdat <= i__6; ++isdat) {
			if (igetbits_(&all_1.isdat1[isdat - 1], &c__3, &c__0) 
				== commvl_1.ivmx[all_1.nv + commvl_1.nvmx[
				all_1.nv - 1] * 7 - 8] && ! bit_test(
				all_1.isdat1[isdat - 1],11) && igetbits_(&
				all_1.isdat1[isdat - 1], &c__7, &c__19) == 
				comsln_1.is2n1) {

/*  Found slur ending.  Just check note height, ca
n't do fine adjustments. */

/* Computing MAX */
			    i__5 = comsln_1.is1n1, i__9 = igetbits_(&
				    all_1.isdat2[all_1.nsdat - 1], &c__7, &
				    c__19);
			    comsln_1.is1n1 = max(i__5,i__9);
			    goto L51;
			}
/* L50: */
		    }

/*  If exiting loop normally, did not find end of slur.  c
'est la vie. */

L51:
		    i__6 = ncmid_(&all_1.nv, &c__1) + 1 + comsln_1.irzbnd;
		    comsln_1.isnx = i_dim(&comsln_1.is1n1, &i__6);
		    if (comsln_1.isnx > 0) {

/*  AHA! Slur likely to interfere with barno. */

			slint = TRUE_;
			s_copy(fmtq, "(a16,i1,a14)", 24L, 12L);
			if (comsln_1.irzbnd + comsln_1.isnx > 9) {
			    s_copy(fmtq, "(a16,i2,a14)", 24L, 12L);
			}
			s_wsfe(&io___104);
/* Writing concatenation */
			i__4[0] = 1, a__3[0] = all_1.sq;
			i__4[1] = 3, a__3[1] = "def";
			i__4[2] = 1, a__3[2] = all_1.sq;
			i__4[3] = 11, a__3[3] = "raisebarno{";
			s_cat(ch__14, a__3, i__4, &c__4, 16L);
			do_fio(&c__1, ch__14, 16L);
			i__6 = comsln_1.irzbnd + comsln_1.isnx;
			do_fio(&c__1, (char *)&i__6, (ftnlen)sizeof(integer));
/* Writing concatenation */
			i__10[0] = 2, a__6[0] = ".5";
			i__10[1] = 1, a__6[1] = all_1.sq;
			i__10[2] = 11, a__6[2] = "internote}%";
			s_cat(ch__7, a__6, i__10, &c__3, 14L);
			do_fio(&c__1, ch__7, 14L);
			e_wsfe();
		    }
		}
		if (comget_1.movbrk > 0) {
/*              movbrk = 0 */
/*  Move the reset down, so can use movbrk>0 to stop extra
 meter prints. */
/* c */
/* c  Check for terminal right-repeat in movement just end
ed */
/* c */
/*      if (rptfin) then */
/*        write(11,'(a)')sq//'setrightrepeat%' */
/*        rptfin = .false. */
/*      end if */

/* New movement.  Redefine stoppiece, contpiece.  These wi
ll be called either*/
/*     explicitly or as part of alaligne. */
/* indsym = 0 for doubleBAR (default), 1 otherwise (right 
repeat, doublebar).*/
/*     This is passed to \newmovement.  If 0, newmovement 
includes a */
/*     \setdoubleBAR; otherwise, pmxb will have \setsometh
ingelse earlier. */

		    indsym = 0;
		    if ((320 & all_1.islur[ipnow * 7 - 7]) > 0) {
			indsym = 1;
		    } else if (comget_1.rptfin) {
			s_wsfe(&io___106);
/* Writing concatenation */
			i__1[0] = 1, a__1[0] = all_1.sq;
			i__1[1] = 15, a__1[1] = "setrightrepeat%";
			s_cat(ch__14, a__1, i__1, &c__2, 16L);
			do_fio(&c__1, ch__14, 16L);
			e_wsfe();
			indsym = 1;
			comget_1.rptfin = FALSE_;
		    }
		    if (comget_1.movgap < 10) {
			s_wsfe(&io___107);
/* Writing concatenation */
			i__1[0] = 1, a__1[0] = all_1.sq;
			i__1[1] = 11, a__1[1] = "newmovement";
			s_cat(ch__6, a__1, i__1, &c__2, 12L);
			do_fio(&c__1, ch__6, 12L);
			do_fio(&c__1, (char *)&comget_1.movgap, (ftnlen)
				sizeof(integer));
			do_fio(&c__1, (char *)&indsym, (ftnlen)sizeof(integer)
				);
			do_fio(&c__1, "%", 1L);
			e_wsfe();
		    } else {
			s_wsfe(&io___108);
/* Writing concatenation */
			i__1[0] = 1, a__1[0] = all_1.sq;
			i__1[1] = 12, a__1[1] = "newmovement{";
			s_cat(ch__9, a__1, i__1, &c__2, 13L);
			do_fio(&c__1, ch__9, 13L);
			do_fio(&c__1, (char *)&comget_1.movgap, (ftnlen)
				sizeof(integer));
			do_fio(&c__1, "}", 1L);
			do_fio(&c__1, (char *)&indsym, (ftnlen)sizeof(integer)
				);
			do_fio(&c__1, "%", 1L);
			e_wsfe();
		    }
		    wgmeter_(&all_1.mtrnmp, &all_1.mtrdnp);
		    i__6 = noinst;
		    for (iinst = 1; iinst <= i__6; ++iinst) {
			s_wsfe(&io___110);
/* Writing concatenation */
			i__1[0] = 1, a__1[0] = all_1.sq;
			i__1[1] = 7, a__1[1] = "setname";
			s_cat(ch__15, a__1, i__1, &c__2, 8L);
			do_fio(&c__1, ch__15, 8L);
			do_fio(&c__1, (char *)&iinst, (ftnlen)sizeof(integer))
				;
			do_fio(&c__1, "{}%", 3L);
			e_wsfe();
/* L60: */
		    }
		    if (bit_test(iplnow,28)) {

/*  Key signature at movement break */

			iplnow = bit_clear(iplnow,28);
			if (comtop_1.isig > 0) {
			    s_wsfe(&io___111);
/* Writing concatenation */
			    i__1[0] = 1, a__1[0] = all_1.sq;
			    i__1[1] = 17, a__1[1] = "generalsignature{";
			    s_cat(ch__16, a__1, i__1, &c__2, 18L);
			    do_fio(&c__1, ch__16, 18L);
			    do_fio(&c__1, (char *)&comtop_1.isig, (ftnlen)
				    sizeof(integer));
			    do_fio(&c__1, "}%", 2L);
			    e_wsfe();
			} else {
			    s_wsfe(&io___112);
/* Writing concatenation */
			    i__1[0] = 1, a__1[0] = all_1.sq;
			    i__1[1] = 17, a__1[1] = "generalsignature{";
			    s_cat(ch__16, a__1, i__1, &c__2, 18L);
			    do_fio(&c__1, ch__16, 18L);
			    do_fio(&c__1, (char *)&comtop_1.isig, (ftnlen)
				    sizeof(integer));
			    do_fio(&c__1, "}%", 2L);
			    e_wsfe();
			}
		    }
		    if (comget_1.parmov >= (float)-.1) {

/*  Resent paragraph indentation */

			ipi = comget_1.parmov * comtop_1.widthpt + (float).1;
			if (ipi < 10) {
			    s_wsfe(&io___114);
/* Writing concatenation */
			    i__1[0] = 1, a__1[0] = all_1.sq;
			    i__1[1] = 10, a__1[1] = "parindent ";
			    s_cat(ch__11, a__1, i__1, &c__2, 11L);
			    do_fio(&c__1, ch__11, 11L);
			    do_fio(&c__1, (char *)&ipi, (ftnlen)sizeof(
				    integer));
			    do_fio(&c__1, "pt", 2L);
			    e_wsfe();
			} else {
			    s_wsfe(&io___115);
/* Writing concatenation */
			    i__1[0] = 1, a__1[0] = all_1.sq;
			    i__1[1] = 10, a__1[1] = "parindent ";
			    s_cat(ch__11, a__1, i__1, &c__2, 11L);
			    do_fio(&c__1, ch__11, 11L);
			    do_fio(&c__1, (char *)&ipi, (ftnlen)sizeof(
				    integer));
			    do_fio(&c__1, "pt", 2L);
			    e_wsfe();
			}
		    }
		}
		if (isystpg == 1) {

/*  First line on a page (not 1st page, still first bar). 
 Eject old page. */

		    if (onvolt) {
			s_wsfe(&io___116);
/* Writing concatenation */
			i__1[0] = 1, a__1[0] = all_1.sq;
			i__1[1] = 12, a__1[1] = "endvoltabox%";
			s_cat(ch__9, a__1, i__1, &c__2, 13L);
			do_fio(&c__1, ch__9, 13L);
			e_wsfe();
			onvolt = FALSE_;
		    }

/*  Key signature change? */

		    if (bit_test(iplnow,28)) {
/* Writing concatenation */
			i__11[0] = 1, a__7[0] = all_1.sq;
			i__11[1] = 4, a__7[1] = "xbar";
			i__11[2] = 1, a__7[2] = all_1.sq;
			i__11[3] = 10, a__7[3] = "addspace{-";
			i__11[4] = 1, a__7[4] = all_1.sq;
			i__11[5] = 14, a__7[5] = "afterruleskip}";
			i__11[6] = 1, a__7[6] = all_1.sq;
			i__11[7] = 17, a__7[7] = "generalsignature{";
			s_cat(notexq, a__7, i__11, &c__8, 79L);
			lnote = 49;
			if (comtop_1.isig < 0) {
/* Writing concatenation */
			    i__1[0] = 49, a__1[0] = notexq;
			    i__1[1] = 1, a__1[1] = "-";
			    s_cat(notexq, a__1, i__1, &c__2, 79L);
			    lnote = 50;
			}
			s_wsfe(&io___117);
/* Writing concatenation */
			i__10[0] = lnote, a__6[0] = notexq;
			*(unsigned char *)&ch__18[0] = abs(comtop_1.isig) + 
				48;
			i__10[1] = 1, a__6[1] = ch__18;
			i__10[2] = 2, a__6[2] = "}%";
			s_cat(ch__17, a__6, i__10, &c__3, 82L);
			do_fio(&c__1, ch__17, lnote + 3);
			e_wsfe();
			s_wsfe(&io___118);
/* Writing concatenation */
			i__3[0] = 1, a__2[0] = all_1.sq;
			i__3[1] = 14, a__2[1] = "zchangecontext";
			i__3[2] = 1, a__2[2] = all_1.sq;
			i__3[3] = 12, a__2[3] = "addspace{-.5";
			i__3[4] = 1, a__2[4] = all_1.sq;
			i__3[5] = 14, a__2[5] = "afterruleskip}";
			i__3[6] = 1, a__2[6] = all_1.sq;
			i__3[7] = 3, a__2[7] = "def";
			i__3[8] = 1, a__2[8] = all_1.sq;
			i__3[9] = 13, a__2[9] = "writezbarno{}";
			i__3[10] = 1, a__2[10] = all_1.sq;
			i__3[11] = 11, a__2[11] = "zstoppiece%";
			s_cat(ch__19, a__2, i__3, &c__12, 73L);
			do_fio(&c__1, ch__19, 73L);
			e_wsfe();
		    } else {
			s_wsfe(&io___119);
/* Writing concatenation */
			i__1[0] = 1, a__1[0] = all_1.sq;
			i__1[1] = 10, a__1[1] = "stoppiece%";
			s_cat(ch__11, a__1, i__1, &c__2, 11L);
			do_fio(&c__1, ch__11, 11L);
			e_wsfe();
		    }
		    if (! vshrink) {
			xnstbot = xnsttop[ipage - 1] * etabot / etatop;
			if (xnstbot < (float)9.95) {
			    s_copy(fmtq, "(a,f3.1,a)", 24L, 10L);
			} else {
			    s_copy(fmtq, "(a,f4.1,a)", 24L, 10L);
			}
/*               write(11,fmtq)sq//'stoppiece'//sq//'v
skip',xnstbot, */
			s_wsfe(&io___121);
/* Writing concatenation */
			i__1[0] = 1, a__1[0] = all_1.sq;
			i__1[1] = 5, a__1[1] = "vskip";
			s_cat(ch__20, a__1, i__1, &c__2, 6L);
			do_fio(&c__1, ch__20, 6L);
			do_fio(&c__1, (char *)&xnstbot, (ftnlen)sizeof(real));
/* Writing concatenation */
			i__4[0] = 1, a__3[0] = all_1.sq;
			i__4[1] = 10, a__3[1] = "Interligne";
			i__4[2] = 1, a__3[2] = all_1.sq;
			i__4[3] = 6, a__3[3] = "eject%";
			s_cat(ch__16, a__3, i__4, &c__4, 18L);
			do_fio(&c__1, ch__16, 18L);
			e_wsfe();
		    } else {
			s_wsfe(&io___122);
/* Writing concatenation */
			i__4[0] = 1, a__3[0] = all_1.sq;
			i__4[1] = 5, a__3[1] = "vfill";
			i__4[2] = 1, a__3[2] = all_1.sq;
			i__4[3] = 6, a__3[3] = "eject%";
			s_cat(ch__9, a__3, i__4, &c__4, 13L);
			do_fio(&c__1, ch__9, 13L);
			e_wsfe();
		    }
		    ++ipage;
		    vshrink = xintstaff[ipage - 1] > (float)20.;
		    if (vshrink) {
			comarp_1.xinsnow = (float)10.;
		    } else {
			comarp_1.xinsnow = xintstaff[ipage - 1];
		    }
		    if (comget_1.fintstf > (float)0. && ipage > 1) {
			comarp_1.xinsnow = comarp_1.xinsnow * 
				comget_1.fintstf / comget_1.gintstf;
			comget_1.fintstf = (float)-1.;
		    }
		    if (comarp_1.xinsnow < (float)9.95) {
			s_copy(fmtq, "(a,f3.1,a)", 24L, 10L);
		    } else if (comarp_1.xinsnow < (float)99.95) {
			s_copy(fmtq, "(a,f4.1,a)", 24L, 10L);
		    } else {
			s_copy(fmtq, "(a,f5.1,a)", 24L, 10L);
		    }

/*  Vertical spacing parameters, then restart */

		    s_wsfe(&io___123);
/* Writing concatenation */
		    i__1[0] = 1, a__1[0] = all_1.sq;
		    i__1[1] = 11, a__1[1] = "interstaff{";
		    s_cat(ch__6, a__1, i__1, &c__2, 12L);
		    do_fio(&c__1, ch__6, 12L);
		    do_fio(&c__1, (char *)&comarp_1.xinsnow, (ftnlen)sizeof(
			    real));
/* Writing concatenation */
		    i__10[0] = 1, a__6[0] = "}";
		    i__10[1] = 1, a__6[1] = all_1.sq;
		    i__10[2] = 9, a__6[2] = "contpiece";
		    s_cat(ch__11, a__6, i__10, &c__3, 11L);
		    do_fio(&c__1, ch__11, 11L);
		    e_wsfe();

/*  Check for meter change at start of a new PAGE */

		    if (all_1.mtrnuml > 0) {

/*  Meter change at start of a new page */

			setmeter_(&all_1.mtrnuml, &all_1.mtrdenl, &
				combeam_1.ibmtyp, &ibmrep);
			if (comget_1.movbrk == 0) {
			    wgmeter_(&all_1.mtrnmp, &all_1.mtrdnp);
			    if (all_1.mtrdnp > 0) {
				s_wsfe(&io___124);
/* Writing concatenation */
				i__1[0] = 1, a__1[0] = all_1.sq;
				i__1[1] = 10, a__1[1] = "newtimes2%";
				s_cat(ch__11, a__1, i__1, &c__2, 11L);
				do_fio(&c__1, ch__11, 11L);
				e_wsfe();
				if (all_1.ibar == comgrace_1.ibarmbr) {
				    comgrace_1.xb4mbr = comstart_1.facmtr * 
					    all_1.musicsize;
				}
			    }
			}
		    }

/* If no real titles here, which there probably will never
 be, make vertical*/
/*  space at page top with \titles{...}.  headlog=.false.
<=>no real titles */

		    puttitle_(&inhnoh, &xnsttop[ipage - 1], &etatop, all_1.sq,
			     &etait, &etatc, &etacs1, &all_1.nv, &vshrink, 
			    all_1.sepsymq, 1L, 1L);
		} else {

/*  First bar of system, not a new page, force line break 
*/

		    if (bit_test(iplnow,28)) {

/*  Signature change */

/* Writing concatenation */
			i__11[0] = 1, a__7[0] = all_1.sq;
			i__11[1] = 4, a__7[1] = "xbar";
			i__11[2] = 1, a__7[2] = all_1.sq;
			i__11[3] = 10, a__7[3] = "addspace{-";
			i__11[4] = 1, a__7[4] = all_1.sq;
			i__11[5] = 14, a__7[5] = "afterruleskip}";
			i__11[6] = 1, a__7[6] = all_1.sq;
			i__11[7] = 17, a__7[7] = "generalsignature{";
			s_cat(notexq, a__7, i__11, &c__8, 79L);
			lnote = 49;
			if (comtop_1.isig < 0) {
/* Writing concatenation */
			    i__1[0] = 49, a__1[0] = notexq;
			    i__1[1] = 1, a__1[1] = "-";
			    s_cat(notexq, a__1, i__1, &c__2, 79L);
			    lnote = 50;
			}
			s_wsfe(&io___125);
/* Writing concatenation */
			i__10[0] = lnote, a__6[0] = notexq;
			*(unsigned char *)&ch__18[0] = abs(comtop_1.isig) + 
				48;
			i__10[1] = 1, a__6[1] = ch__18;
			i__10[2] = 2, a__6[2] = "}%";
			s_cat(ch__17, a__6, i__10, &c__3, 82L);
			do_fio(&c__1, ch__17, lnote + 3);
			e_wsfe();
			if (all_1.mtrnuml != 0) {

/*  Meter+sig change, new line, may need mods if m
ovement break here. */

			    setmeter_(&all_1.mtrnuml, &all_1.mtrdenl, &
				    combeam_1.ibmtyp, &ibmrep);
			    wgmeter_(&all_1.mtrnmp, &all_1.mtrdnp);
			    s_wsfe(&io___126);
/* Writing concatenation */
			    i__3[0] = 1, a__2[0] = all_1.sq;
			    i__3[1] = 14, a__2[1] = "xchangecontext";
			    i__3[2] = 1, a__2[2] = all_1.sq;
			    i__3[3] = 10, a__2[3] = "addspace{-";
			    i__3[4] = 1, a__2[4] = all_1.sq;
			    i__3[5] = 14, a__2[5] = "afterruleskip}";
			    i__3[6] = 1, a__2[6] = all_1.sq;
			    i__3[7] = 3, a__2[7] = "def";
			    i__3[8] = 1, a__2[8] = all_1.sq;
			    i__3[9] = 13, a__2[9] = "writezbarno{}";
			    i__3[10] = 1, a__2[10] = all_1.sq;
			    i__3[11] = 10, a__2[11] = "zalaligne%";
			    s_cat(ch__21, a__2, i__3, &c__12, 70L);
			    do_fio(&c__1, ch__21, 70L);
			    e_wsfe();
			    s_wsfe(&io___127);
/* Writing concatenation */
			    i__4[0] = 1, a__3[0] = all_1.sq;
			    i__4[1] = 10, a__3[1] = "addspace{-";
			    i__4[2] = 1, a__3[2] = all_1.sq;
			    i__4[3] = 15, a__3[3] = "afterruleskip}%";
			    s_cat(ch__22, a__3, i__4, &c__4, 27L);
			    do_fio(&c__1, ch__22, 27L);
			    e_wsfe();
			    wgmeter_(&all_1.mtrnmp, &all_1.mtrdnp);
			    s_wsfe(&io___128);
/* Writing concatenation */
			    i__1[0] = 1, a__1[0] = all_1.sq;
			    i__1[1] = 14, a__1[1] = "zchangecontext";
			    s_cat(ch__8, a__1, i__1, &c__2, 15L);
			    do_fio(&c__1, ch__8, 15L);
			    e_wsfe();
			} else {
			    s_wsfe(&io___129);
/* Writing concatenation */
			    i__3[0] = 1, a__2[0] = all_1.sq;
			    i__3[1] = 14, a__2[1] = "xchangecontext";
			    i__3[2] = 1, a__2[2] = all_1.sq;
			    i__3[3] = 12, a__2[3] = "addspace{-.5";
			    i__3[4] = 1, a__2[4] = all_1.sq;
			    i__3[5] = 14, a__2[5] = "afterruleskip}";
			    i__3[6] = 1, a__2[6] = all_1.sq;
			    i__3[7] = 3, a__2[7] = "def";
			    i__3[8] = 1, a__2[8] = all_1.sq;
			    i__3[9] = 13, a__2[9] = "writezbarno{}";
			    i__3[10] = 1, a__2[10] = all_1.sq;
			    i__3[11] = 10, a__2[11] = "zalaligne%";
			    s_cat(ch__23, a__2, i__3, &c__12, 72L);
			    do_fio(&c__1, ch__23, 72L);
			    e_wsfe();
			}
		    } else if (all_1.mtrnuml == 0) {

/*  No meter change */

			s_wsfe(&io___130);
/* Writing concatenation */
			i__1[0] = 1, a__1[0] = all_1.sq;
			i__1[1] = 8, a__1[1] = "alaligne";
			s_cat(ch__10, a__1, i__1, &c__2, 9L);
			do_fio(&c__1, ch__10, 9L);
			e_wsfe();
		    } else {

/*  New meter, no new sig, end of line, not new page. 
*/

/* \generalmeter{\meterfrac{3}{4}}% */
/* \xchangecontext\addspace{-\afterruleskip}% */
/* \zalaligne\generalmeter{\meterfrac{3}{4}}\addspace{
-\afterruleskip}% */
/* \zchangecontext */

			setmeter_(&all_1.mtrnuml, &all_1.mtrdenl, &
				combeam_1.ibmtyp, &ibmrep);
			if (comget_1.movbrk == 0) {
			    wgmeter_(&all_1.mtrnmp, &all_1.mtrdnp);
			    if (all_1.mtrdnp > 0) {
				s_wsfe(&io___131);
/* Writing concatenation */
				i__3[0] = 1, a__2[0] = all_1.sq;
				i__3[1] = 3, a__2[1] = "let";
				i__3[2] = 1, a__2[2] = all_1.sq;
				i__3[3] = 4, a__2[3] = "bnat";
				i__3[4] = 1, a__2[4] = all_1.sq;
				i__3[5] = 8, a__2[5] = "barnoadd";
				i__3[6] = 1, a__2[6] = all_1.sq;
				i__3[7] = 3, a__2[7] = "def";
				i__3[8] = 1, a__2[8] = all_1.sq;
				i__3[9] = 9, a__2[9] = "barnoadd{";
				i__3[10] = 1, a__2[10] = all_1.sq;
				i__3[11] = 7, a__2[11] = "empty}%";
				s_cat(ch__24, a__2, i__3, &c__12, 40L);
				do_fio(&c__1, ch__24, 40L);
				e_wsfe();
				s_wsfe(&io___132);
/* Writing concatenation */
				i__3[0] = 1, a__2[0] = all_1.sq;
				i__3[1] = 14, a__2[1] = "xchangecontext";
				i__3[2] = 1, a__2[2] = all_1.sq;
				i__3[3] = 24, a__2[3] = "addspace{-afterrule\
skip}";
				i__3[4] = 1, a__2[4] = all_1.sq;
				i__3[5] = 9, a__2[5] = "zalaligne";
				i__3[6] = 1, a__2[6] = all_1.sq;
				i__3[7] = 3, a__2[7] = "let";
				i__3[8] = 1, a__2[8] = all_1.sq;
				i__3[9] = 8, a__2[9] = "barnoadd";
				i__3[10] = 1, a__2[10] = all_1.sq;
				i__3[11] = 4, a__2[11] = "bnat";
				s_cat(ch__25, a__2, i__3, &c__12, 68L);
				do_fio(&c__1, ch__25, 68L);
				e_wsfe();
				wgmeter_(&all_1.mtrnmp, &all_1.mtrdnp);
				s_wsfe(&io___133);
/* Writing concatenation */
				i__4[0] = 1, a__3[0] = all_1.sq;
				i__4[1] = 24, a__3[1] = "addspace{-afterrule\
skip}";
				i__4[2] = 1, a__3[2] = all_1.sq;
				i__4[3] = 14, a__3[3] = "zchangecontext";
				s_cat(ch__24, a__3, i__4, &c__4, 40L);
				do_fio(&c__1, ch__24, 40L);
				e_wsfe();
/*                   write(11,'(a)')sq//'newti
mes1%' */
				if (all_1.ibar == comgrace_1.ibarmbr) {
				    comgrace_1.xb4mbr = comstart_1.facmtr * 
					    all_1.musicsize;
				}
			    } else {
				s_wsfe(&io___134);
/* Writing concatenation */
				i__1[0] = 1, a__1[0] = all_1.sq;
				i__1[1] = 8, a__1[1] = "alaligne";
				s_cat(ch__10, a__1, i__1, &c__2, 9L);
				do_fio(&c__1, ch__10, 9L);
				e_wsfe();
			    }
			} else {
			    s_wsfe(&io___135);
/* Writing concatenation */
			    i__1[0] = 1, a__1[0] = all_1.sq;
			    i__1[1] = 8, a__1[1] = "alaligne";
			    s_cat(ch__10, a__1, i__1, &c__2, 9L);
			    do_fio(&c__1, ch__10, 9L);
			    e_wsfe();
			}
		    }
		}
		if (slint) {
		    slint = FALSE_;
		    s_wsfe(&io___136);
/* Writing concatenation */
		    i__4[0] = 1, a__3[0] = all_1.sq;
		    i__4[1] = 3, a__3[1] = "def";
		    i__4[2] = 1, a__3[2] = all_1.sq;
		    i__4[3] = 11, a__3[3] = "raisebarno{";
		    s_cat(ch__14, a__3, i__4, &c__4, 16L);
		    do_fio(&c__1, ch__14, 16L);
		    do_fio(&c__1, (char *)&comsln_1.irzbnd, (ftnlen)sizeof(
			    integer));
/* Writing concatenation */
		    i__10[0] = 2, a__6[0] = ".5";
		    i__10[1] = 1, a__6[1] = all_1.sq;
		    i__10[2] = 11, a__6[2] = "internote}%";
		    s_cat(ch__7, a__6, i__10, &c__3, 14L);
		    do_fio(&c__1, ch__7, 14L);
		    e_wsfe();
		}
		comget_1.movbrk = 0;
	    }
	    i__6 = s_rsle(&io___137);
	    if (i__6 != 0) {
		goto L14;
	    }
	    i__6 = do_lio(&c__3, &c__1, (char *)&iauto, (ftnlen)sizeof(
		    integer));
	    if (i__6 != 0) {
		goto L14;
	    }
	    i__6 = e_rsle();
	    if (i__6 != 0) {
		goto L14;
	    }
L14:

/*  We come thru here for the 1st bar of every system, so initiali
ze is1n1 */

	    comsln_1.is1n1 = 0;
	} else {

/*  Not first bar of system */

	    if (bit_test(iplnow,28)) {

/*  Signature change */

		if (all_1.mtrnuml != 0) {

/*  Meter+signature change mid line, assume no movement br
eak */

		    setmeter_(&all_1.mtrnuml, &all_1.mtrdenl, &
			    combeam_1.ibmtyp, &ibmrep);
		    wgmeter_(&all_1.mtrnmp, &all_1.mtrdnp);
/* Writing concatenation */
		    i__1[0] = 1, a__1[0] = all_1.sq;
		    i__1[1] = 17, a__1[1] = "generalsignature{";
		    s_cat(notexq, a__1, i__1, &c__2, 79L);
		    lnote = 18;
		    if (comtop_1.isig < 0) {
/* Writing concatenation */
			i__1[0] = 18, a__1[0] = notexq;
			i__1[1] = 1, a__1[1] = "-";
			s_cat(notexq, a__1, i__1, &c__2, 79L);
			lnote = 19;
		    }
		    s_wsfe(&io___138);
/* Writing concatenation */
		    i__10[0] = lnote, a__6[0] = notexq;
		    *(unsigned char *)&ch__18[0] = abs(comtop_1.isig) + 48;
		    i__10[1] = 1, a__6[1] = ch__18;
		    i__10[2] = 2, a__6[2] = "}%";
		    s_cat(ch__17, a__6, i__10, &c__3, 82L);
		    do_fio(&c__1, ch__17, lnote + 3);
		    e_wsfe();
		    s_wsfe(&io___139);
/* Writing concatenation */
		    i__1[0] = 1, a__1[0] = all_1.sq;
		    i__1[1] = 15, a__1[1] = "xchangecontext%";
		    s_cat(ch__14, a__1, i__1, &c__2, 16L);
		    do_fio(&c__1, ch__14, 16L);
		    e_wsfe();
		} else {

/*  Signature change only */

/* Writing concatenation */
		    i__11[0] = 1, a__7[0] = all_1.sq;
		    i__11[1] = 4, a__7[1] = "xbar";
		    i__11[2] = 1, a__7[2] = all_1.sq;
		    i__11[3] = 10, a__7[3] = "addspace{-";
		    i__11[4] = 1, a__7[4] = all_1.sq;
		    i__11[5] = 14, a__7[5] = "afterruleskip}";
		    i__11[6] = 1, a__7[6] = all_1.sq;
		    i__11[7] = 17, a__7[7] = "generalsignature{";
		    s_cat(notexq, a__7, i__11, &c__8, 79L);
		    lnote = 49;
		    if (comtop_1.isig < 0) {
/* Writing concatenation */
			i__1[0] = 49, a__1[0] = notexq;
			i__1[1] = 1, a__1[1] = "-";
			s_cat(notexq, a__1, i__1, &c__2, 79L);
			lnote = 50;
		    }
		    s_wsfe(&io___140);
/* Writing concatenation */
		    i__10[0] = lnote, a__6[0] = notexq;
		    *(unsigned char *)&ch__18[0] = abs(comtop_1.isig) + 48;
		    i__10[1] = 1, a__6[1] = ch__18;
		    i__10[2] = 2, a__6[2] = "}%";
		    s_cat(ch__17, a__6, i__10, &c__3, 82L);
		    do_fio(&c__1, ch__17, lnote + 3);
		    e_wsfe();
		    s_wsfe(&io___141);
/* Writing concatenation */
		    i__12[0] = 1, a__8[0] = all_1.sq;
		    i__12[1] = 14, a__8[1] = "zchangecontext";
		    i__12[2] = 1, a__8[2] = all_1.sq;
		    i__12[3] = 12, a__8[3] = "addspace{-.5";
		    i__12[4] = 1, a__8[4] = all_1.sq;
		    i__12[5] = 15, a__8[5] = "afterruleskip}%";
		    s_cat(ch__26, a__8, i__12, &c__6, 44L);
		    do_fio(&c__1, ch__26, 44L);
		    e_wsfe();
		}
	    } else if (all_1.mtrnuml == 0) {

/*  No meter change */

		s_wsfe(&io___142);
/* Writing concatenation */
		i__1[0] = 1, a__1[0] = all_1.sq;
		i__1[1] = 4, a__1[1] = "xbar";
		s_cat(ch__27, a__1, i__1, &c__2, 5L);
		do_fio(&c__1, ch__27, 5L);
		e_wsfe();
	    } else {

/*  Change meter midline */

		setmeter_(&all_1.mtrnuml, &all_1.mtrdenl, &combeam_1.ibmtyp, &
			ibmrep);
		if (comget_1.movbrk == 0) {
		    wgmeter_(&all_1.mtrnmp, &all_1.mtrdnp);
		    if (all_1.mtrdnp > 0) {
			s_wsfe(&io___143);
/* Writing concatenation */
			i__1[0] = 1, a__1[0] = all_1.sq;
			i__1[1] = 10, a__1[1] = "newtimes0%";
			s_cat(ch__11, a__1, i__1, &c__2, 11L);
			do_fio(&c__1, ch__11, 11L);
			e_wsfe();
			if (all_1.ibar == comgrace_1.ibarmbr) {
			    comgrace_1.xb4mbr = comstart_1.facmtr * 
				    all_1.musicsize;
			}
		    } else {
			s_wsfe(&io___144);
/* Writing concatenation */
			i__1[0] = 1, a__1[0] = all_1.sq;
			i__1[1] = 4, a__1[1] = "xbar";
			s_cat(ch__27, a__1, i__1, &c__2, 5L);
			do_fio(&c__1, ch__27, 5L);
			e_wsfe();
		    }
		}
	    }
	}

/* Now that xbar's are written, can put in left-repeats at line beginn
ings*/

	if (lrptpend) {
	    s_wsfe(&io___145);
/* Writing concatenation */
	    i__12[0] = 1, a__8[0] = all_1.sq;
	    i__12[1] = 7, a__8[1] = "advance";
	    i__12[2] = 1, a__8[2] = all_1.sq;
	    i__12[3] = 7, a__8[3] = "barno-1";
	    i__12[4] = 1, a__8[4] = all_1.sq;
	    i__12[5] = 10, a__8[5] = "leftrepeat";
	    s_cat(ch__22, a__8, i__12, &c__6, 27L);
	    do_fio(&c__1, ch__22, 27L);
	    e_wsfe();
	    lrptpend = FALSE_;
	}
	if (all_1.ibar > 1) {

/*  For bars after first, slide all stuff down to beginning of arr
ays */

	    i__6 = all_1.nv;
	    for (all_1.iv = 1; all_1.iv <= i__6; ++all_1.iv) {
		i__5 = commvl_1.nvmx[all_1.iv - 1];
		for (kv = 1; kv <= i__5; ++kv) {
		    commvl_1.ivx = commvl_1.ivmx[all_1.iv + kv * 7 - 8];
		    ioff = all_1.nib[commvl_1.ivx + (all_1.ibar - 1) * 7 - 8];
		    i__9 = all_1.nib[commvl_1.ivx + all_1.ibar * 7 - 8] - 
			    ioff;
		    for (ip = 1; ip <= i__9; ++ip) {
			all_1.nolev[commvl_1.ivx + ip * 7 - 8] = all_1.nolev[
				commvl_1.ivx + (ip + ioff) * 7 - 8];
			all_1.nodur[commvl_1.ivx + ip * 7 - 8] = all_1.nodur[
				commvl_1.ivx + (ip + ioff) * 7 - 8];
			*(unsigned char *)&all_1.accq[commvl_1.ivx + ip * 7 - 
				8] = *(unsigned char *)&all_1.accq[
				commvl_1.ivx + (ip + ioff) * 7 - 8];
			all_1.irest[commvl_1.ivx + ip * 7 - 8] = all_1.irest[
				commvl_1.ivx + (ip + ioff) * 7 - 8];
			all_1.islur[commvl_1.ivx + ip * 7 - 8] = all_1.islur[
				commvl_1.ivx + (ip + ioff) * 7 - 8];
			all_1.ipl[commvl_1.ivx + ip * 7 - 8] = all_1.ipl[
				commvl_1.ivx + (ip + ioff) * 7 - 8];
			all_1.iornq[commvl_1.ivx + ip * 7 - 8] = all_1.iornq[
				commvl_1.ivx + (ip + ioff) * 7 - 8];
			if (commvl_1.ivx == 1 && all_1.figbass) {
			    all_1.isfig[ip - 1] = all_1.isfig[ip + ioff - 1];
			}
/* L12: */
		    }
		    if (commvl_1.ivx <= all_1.nv && comcc_1.ncc[all_1.iv - 1] 
			    > 1) {
			islide = 0;
			i__9 = comcc_1.ncc[all_1.iv - 1];
			for (icc = 1; icc <= i__9; ++icc) {
			    if (comcc_1.itcc[all_1.iv + icc * 7 - 8] <= 
				    all_1.lenbar) {

/*  This time will drop <=0 when slid. */

				islide = icc - 1;
				comcc_1.ncmidcc[all_1.iv - 1] = 
					comcc_1.ncmidcc[all_1.iv + icc * 7 - 
					8];
			    } else {
				comcc_1.itcc[all_1.iv + (icc - islide) * 7 - 
					8] = comcc_1.itcc[all_1.iv + icc * 7 
					- 8] - all_1.lenbar;
				comcc_1.ncmidcc[all_1.iv + (icc - islide) * 7 
					- 8] = comcc_1.ncmidcc[all_1.iv + icc 
					* 7 - 8];
			    }
/* L13: */
			}
			comcc_1.ncc[all_1.iv - 1] -= islide;
			comcc_1.itcc[all_1.iv - 1] = 0;
		    }
/* L11: */
		}
	    }
	    i__5 = comgrace_1.ngrace;
	    for (ig = 1; ig <= i__5; ++ig) {
		comgrace_1.ipg[ig - 1] -= all_1.nib[comgrace_1.ivg[ig - 1] + (
			all_1.ibar - 1) * 7 - 8];
		if (all_1.ibar > 2) {
		    comgrace_1.ipg[ig - 1] += all_1.nib[comgrace_1.ivg[ig - 1]
			     + (all_1.ibar - 2) * 7 - 8];
		}
/* L15: */
	    }
	    i__5 = comgrace_1.nlit;
	    for (il = 1; il <= i__5; ++il) {
		comgrace_1.iplit[il - 1] -= all_1.nib[comgrace_1.ivlit[il - 1]
			 + (all_1.ibar - 1) * 7 - 8];
		if (all_1.ibar > 2) {
		    comgrace_1.iplit[il - 1] += all_1.nib[comgrace_1.ivlit[il 
			    - 1] + (all_1.ibar - 2) * 7 - 8];
		}
/* L21: */
	    }
	    i__5 = comtrill_1.ntrill;
	    for (it = 1; it <= i__5; ++it) {
		comtrill_1.iptrill[it - 1] -= all_1.nib[comtrill_1.ivtrill[it 
			- 1] + (all_1.ibar - 1) * 7 - 8];
		if (all_1.ibar > 2) {
		    comtrill_1.iptrill[it - 1] += all_1.nib[
			    comtrill_1.ivtrill[it - 1] + (all_1.ibar - 2) * 7 
			    - 8];
		}
/* L22: */
	    }
	    i__5 = comtrill_1.ncrd;
	    for (icrd = 1; icrd <= i__5; ++icrd) {
		commvl_1.ivx = 15 & lbit_shift(comtrill_1.icrdat[icrd - 1], 
			-8L);
		ipnew = (255 & comtrill_1.icrdat[icrd - 1]) - all_1.nib[
			commvl_1.ivx + (all_1.ibar - 1) * 7 - 8];
		if (all_1.ibar > 2) {
		    ipnew += all_1.nib[commvl_1.ivx + (all_1.ibar - 2) * 7 - 
			    8];
		}
		comtrill_1.icrdat[icrd - 1] = -256 & comtrill_1.icrdat[icrd - 
			1];
		comtrill_1.icrdat[icrd - 1] = max(0,ipnew) | 
			comtrill_1.icrdat[icrd - 1];
/* L27: */
	    }
	    i__5 = comtrill_1.nudorn;
	    for (iudorn = 1; iudorn <= i__5; ++iudorn) {
		commvl_1.ivx = 15 & lbit_shift(comtrill_1.kudorn[iudorn - 1], 
			-8L);
		ipnew = (255 & comtrill_1.kudorn[iudorn - 1]) - all_1.nib[
			commvl_1.ivx + (all_1.ibar - 1) * 7 - 8];
		if (all_1.ibar > 2) {
		    ipnew += all_1.nib[commvl_1.ivx + (all_1.ibar - 2) * 7 - 
			    8];
		}
		comtrill_1.kudorn[iudorn - 1] = -256 & comtrill_1.kudorn[
			iudorn - 1];
		comtrill_1.kudorn[iudorn - 1] = max(0,ipnew) | 
			comtrill_1.kudorn[iudorn - 1];
/* L29: */
	    }
	    i__5 = all_1.nsdat;
	    for (isdat = 1; isdat <= i__5; ++isdat) {
/*     call report(nsdat,isdat1,isdat2) */
		isdata = all_1.isdat1[isdat - 1];
		commvl_1.ivx = 7 & isdata;
		ipnew = igetbits_(&isdata, &c__8, &c__3) - all_1.nib[
			commvl_1.ivx + (all_1.ibar - 1) * 7 - 8];
		if (all_1.ibar > 2) {
		    ipnew += all_1.nib[commvl_1.ivx + (all_1.ibar - 2) * 7 - 
			    8];
		}
		ipnew = i_dim(&ipnew, &c__0);
		setbits_(&isdata, &c__8, &c__3, &ipnew);
		all_1.isdat1[isdat - 1] = isdata;
/*     call report(nsdat,isdat1,isdat2) */
/* L41: */
	    }
	    i__5 = comudsp_1.nuxsp;
	    for (iuxsp = 1; iuxsp <= i__5; ++iuxsp) {
		ipnew = comudsp_1.ipuxsp[iuxsp - 1] - all_1.nib[
			comudsp_1.ivuxsp[iuxsp - 1] + (all_1.ibar - 1) * 7 - 
			8];
		if (all_1.ibar > 2) {
		    ipnew += all_1.nib[comudsp_1.ivuxsp[iuxsp - 1] + (
			    all_1.ibar - 2) * 7 - 8];
		}
		comudsp_1.ipuxsp[iuxsp - 1] = i_dim(&ipnew, &c__0);

/*  This sets ipuxsp=0 for already used ones, and reduces it f
or others */

/* L6: */
	    }

/* Bookkeeping for figures.  This will set nfigs = 0 if there are 
no figs left.*/
/*  If there are figs left, it will reset all times relative to st
art of */
/*  current bar. */

	    if (all_1.figbass) {
		islide = 0;
		i__5 = comfig_1.nfigs;
		for (jfig = 1; jfig <= i__5; ++jfig) {
		    if (comfig_1.itfig[jfig - 1] < all_1.lenbar) {

/*  This figure was already used */

			islide = jfig;
		    } else {
			comfig_1.itfig[jfig - islide - 1] = comfig_1.itfig[
				jfig - 1] - all_1.lenbar;
			s_copy(comfig_1.figq + (jfig - islide - 1) * 6, 
				comfig_1.figq + (jfig - 1) * 6, 6L, 6L);
			comgrace_1.itoff[jfig - islide - 1] = 
				comgrace_1.itoff[jfig - 1];
		    }
/* L20: */
		}
		comfig_1.nfigs -= islide;
	    }
	}

/*  The following may not be needed by makeabar, but just in case... 
*/

	if (all_1.firstgulp && all_1.lenb0 != 0) {
	    if (all_1.ibar == 1) {
		all_1.lenbar = all_1.lenb0;
	    } else {
		all_1.lenbar = all_1.lenb1;
	    }
	}
	make1bar_(&ibmrep, &nbxtup, &itglp1, itstart, cwrest, nindex, istop, 
		n1xtup, numbms, istart, &nxtup, lbxtup);
	make2bar_(&noinst, &nbxtup, &itglp1, itstart, cwrest, nindex, istop, 
		n1xtup, numbms, istart, &nxtup, lbxtup, clefq, 1L);

/*  Hardspace before barline? */

	hardb4 = (float)0.;
	i__5 = all_1.nv;
	for (all_1.iv = 1; all_1.iv <= i__5; ++all_1.iv) {
	    i__6 = commvl_1.nvmx[all_1.iv - 1];
	    for (kv = 1; kv <= i__6; ++kv) {
		commvl_1.ivx = commvl_1.ivmx[all_1.iv + kv * 7 - 8];
		if (bit_test(all_1.irest[commvl_1.ivx + all_1.nn[commvl_1.ivx 
			- 1] * 7 - 8],18)) {
		    ++comudsp_1.nudoff[commvl_1.ivx - 1];
/* Computing MAX */
		    r__1 = hardb4, r__2 = comudsp_1.udoff[commvl_1.ivx + 
			    comudsp_1.nudoff[commvl_1.ivx - 1] * 7 - 8];
		    hardb4 = dmax(r__1,r__2);
		}
/* L35: */
	    }
	}
	if (hardb4 > (float)0.) {
	    s_wsfe(&io___169);
/* Writing concatenation */
	    i__1[0] = 1, a__1[0] = all_1.sq;
	    i__1[1] = 10, a__1[1] = "hardspace{";
	    s_cat(ch__11, a__1, i__1, &c__2, 11L);
	    do_fio(&c__1, ch__11, 11L);
	    do_fio(&c__1, (char *)&hardb4, (ftnlen)sizeof(real));
	    do_fio(&c__1, "pt}%", 4L);
	    e_wsfe();
	    comask_1.fixednew -= hardb4;
	}
/* L10: */
    }
    all_1.firstgulp = FALSE_;
    all_1.lenb0 = 0;
    goto L30;
L40:
    cl__1.cerr = 0;
    cl__1.cunit = 12;
    cl__1.csta = 0;
    f_clos(&cl__1);
    cl__1.cerr = 0;
    cl__1.cunit = 13;
    cl__1.csta = 0;
    f_clos(&cl__1);
    cl__1.cerr = 0;
    cl__1.cunit = 10;
    cl__1.csta = 0;
    f_clos(&cl__1);
    wdpt = comtop_1.widthpt;
    if (all_1.iline == 1) {
	wdpt = comtop_1.widthpt * (1 - comtop_1.fracindent);
    }
    poe = (wdpt - fsyst * all_1.musicsize - nbarss * (float).4 - 
	    comask_1.fixednew) / (elsktot + comask_1.fbar * nbarss - 
	    comask_1.scaldold);
    i__2 = comas2_1.nasksys;
    for (ia = 1; ia <= i__2; ++ia) {
	++comas3_1.iask;
/*       ask(iask) = wasksys(ia)/poe-elasksys(ia) */
	comas3_1.ask[comas3_1.iask - 1] = comas2_1.wasksys[ia - 1] / poe - (
		r__1 = comas2_1.elasksys[ia - 1], dabs(r__1));
	if (comas2_1.elasksys[ia - 1] > (float)0.) {
	    comas3_1.ask[comas3_1.iask - 1] = r_dim(&comas3_1.ask[
		    comas3_1.iask - 1], &c_b159);
	}
/*     print*,'iask,ask,ia,wasksys,poe,elasksys:' */
/*     print*,iask,ask(iask),ia,wasksys(ia),poe,elasksys(ia) */
/* L19: */
    }
    i__2 = comas2_1.nasxsys;
    for (ia = 1; ia <= i__2; ++ia) {
	++comas3_1.iasx;
	comas3_1.asx[comas3_1.iasx - 1] = comas2_1.wasxsys[ia - 1] / poe - 
		comas2_1.elasxsys[ia - 1];
/* L18: */
    }
    i__2 = nhssys;
    for (ia = 1; ia <= i__2; ++ia) {
	++nhstot;
/* Computing MAX */
	r__1 = hpts[ia - 1] - hesk[ia - 1] * poe;
	comhsp_1.hpttot[nhstot - 1] = dmax(r__1,(float)0.);
/* L26: */
    }
    if (onvolt) {
	s_wsfe(&io___170);
/* Writing concatenation */
	i__1[0] = 1, a__1[0] = all_1.sq;
	i__1[1] = 11, a__1[1] = "endvoltabox";
	s_cat(ch__6, a__1, i__1, &c__2, 12L);
	do_fio(&c__1, ch__6, 12L);
	e_wsfe();
    }
    if (comget_1.rptfin) {
/* + */
/* Terminal repeat.  Right or double? */

/*        if (btest(islur(1,nnl(1)+1),6)) then */
	if (*(unsigned char *)comget_1.rptfiq == 'r') {
	    s_wsfe(&io___171);
/* Writing concatenation */
	    i__4[0] = 1, a__3[0] = all_1.sq;
	    i__4[1] = 14, a__3[1] = "setrightrepeat";
	    i__4[2] = 1, a__3[2] = all_1.sq;
	    i__4[3] = 8, a__3[3] = "endpiece";
	    s_cat(ch__28, a__3, i__4, &c__4, 24L);
	    do_fio(&c__1, ch__28, 24L);
	    e_wsfe();
	    s_wsle(&io___172);
	    do_lio(&c__9, &c__1, "Term rpt, bit 6 is set", 22L);
	    e_wsle();
/*        else if (btest(islur(1,nnl(1)+1),8)) then */
	} else if (*(unsigned char *)comget_1.rptfiq == 'd') {
	    s_wsle(&io___173);
	    do_lio(&c__9, &c__1, "Term rpt, bit 8 is set", 22L);
	    e_wsle();
	    s_wsfe(&io___174);
/* Writing concatenation */
	    i__4[0] = 1, a__3[0] = all_1.sq;
	    i__4[1] = 12, a__3[1] = "setdoublebar";
	    i__4[2] = 1, a__3[2] = all_1.sq;
	    i__4[3] = 8, a__3[3] = "endpiece";
	    s_cat(ch__12, a__3, i__4, &c__4, 22L);
	    do_fio(&c__1, ch__12, 22L);
	    e_wsfe();
	} else {
	    s_wsle(&io___175);
	    do_lio(&c__9, &c__1, "R? , ? not \"d\" or \"r\", rptfiq:", 30L);
	    do_lio(&c__9, &c__1, comget_1.rptfiq, 1L);
	    e_wsle();
	}
    } else {
	s_wsfe(&io___176);
/* Writing concatenation */
	i__1[0] = 1, a__1[0] = all_1.sq;
	i__1[1] = 8, a__1[1] = "Endpiece";
	s_cat(ch__10, a__1, i__1, &c__2, 9L);
	do_fio(&c__1, ch__10, 9L);
	e_wsfe();
    }
    if (! vshrink) {
	xnstbot = xnsttop[ipage - 1] * etabot / etatop;
	if (xnstbot < (float)9.95) {
	    s_copy(fmtq, "(a,f3.1,a)", 24L, 10L);
	} else {
	    s_copy(fmtq, "(a,f4.1,a)", 24L, 10L);
	}
	s_wsfe(&io___177);
/* Writing concatenation */
	i__1[0] = 1, a__1[0] = all_1.sq;
	i__1[1] = 5, a__1[1] = "vskip";
	s_cat(ch__20, a__1, i__1, &c__2, 6L);
	do_fio(&c__1, ch__20, 6L);
	do_fio(&c__1, (char *)&xnstbot, (ftnlen)sizeof(real));
/* Writing concatenation */
	i__12[0] = 1, a__8[0] = all_1.sq;
	i__12[1] = 10, a__8[1] = "Interligne";
	i__12[2] = 1, a__8[2] = all_1.sq;
	i__12[3] = 5, a__8[3] = "eject";
	i__12[4] = 1, a__8[4] = all_1.sq;
	i__12[5] = 9, a__8[5] = "endmuflex";
	s_cat(ch__22, a__8, i__12, &c__6, 27L);
	do_fio(&c__1, ch__22, 27L);
	e_wsfe();
	s_wsfe(&io___178);
/* Writing concatenation */
	i__1[0] = 1, a__1[0] = all_1.sq;
	i__1[1] = 3, a__1[1] = "bye";
	s_cat(ch__13, a__1, i__1, &c__2, 4L);
	do_fio(&c__1, ch__13, 4L);
	e_wsfe();
    } else {
	s_wsfe(&io___179);
/* Writing concatenation */
	i__12[0] = 1, a__8[0] = all_1.sq;
	i__12[1] = 5, a__8[1] = "vfill";
	i__12[2] = 1, a__8[2] = all_1.sq;
	i__12[3] = 5, a__8[3] = "eject";
	i__12[4] = 1, a__8[4] = all_1.sq;
	i__12[5] = 9, a__8[5] = "endmuflex";
	s_cat(ch__12, a__8, i__12, &c__6, 22L);
	do_fio(&c__1, ch__12, 22L);
	e_wsfe();
	s_wsfe(&io___180);
/* Writing concatenation */
	i__1[0] = 1, a__1[0] = all_1.sq;
	i__1[1] = 3, a__1[1] = "bye";
	s_cat(ch__13, a__1, i__1, &c__2, 4L);
	do_fio(&c__1, ch__13, 4L);
	e_wsfe();
    }
    al__1.aerr = 0;
    al__1.aunit = 11;
    f_rew(&al__1);
    if (all_1.figbass) {
	s_wsfe(&io___181);
/* Writing concatenation */
	i__1[0] = 1, a__1[0] = all_1.sq;
	i__1[1] = 8, a__1[1] = "figdrop=";
	s_cat(ch__10, a__1, i__1, &c__2, 9L);
	do_fio(&c__1, ch__10, 9L);
	do_fio(&c__1, (char *)&all_1.ifigdrop[all_1.iline - 1], (ftnlen)
		sizeof(integer));
/* Writing concatenation */
	i__8[0] = 1, a__5[0] = all_1.sq;
	i__8[1] = 4, a__5[1] = "fi}%";
	s_cat(ch__27, a__5, i__8, &c__2, 5L);
	do_fio(&c__1, ch__27, 5L);
	e_wsfe();
	al__1.aerr = 0;
	al__1.aunit = 14;
	f_rew(&al__1);
    }
    askfig_(pathnameq, &lpath, basenameq, &lbase, &all_1.figbass, &istype0, 
	    40L, 24L);
    s_wsle(&io___182);
    e_wsle();
    s_wsle(&io___183);
    do_lio(&c__9, &c__1, "Done with second pass.  Now run TeX", 35L);
    e_wsle();
} /* MAIN__ */

/* Subroutine */ int make2bar_(noinst, nbxtup, itglp1, itstart, cwrest, 
	nindex, istop, n1xtup, numbms, istart, nxtup, lbxtup, clefq, 
	clefq_len)
integer *noinst, *nbxtup, *itglp1, *itstart;
logical *cwrest;
integer *nindex, *istop, *n1xtup, *numbms, *istart, *nxtup, *lbxtup;
char *clefq;
ftnlen clefq_len;
{
    /* System generated locals */
    address a__1[6], a__2[3], a__3[2], a__4[4], a__5[8], a__6[5];
    integer i__1, i__2, i__3[6], i__4[3], i__5, i__6[2], i__7, i__8[4], i__9[
	    8], i__10, i__11[5];
    real r__1;
    logical L__1;
    char ch__1[82], ch__2[12], ch__3[1], ch__4[17], ch__5[16], ch__6[11], 
	    ch__7[10], ch__8[44], ch__9[81], ch__10[113], ch__11[19], ch__12[
	    3], ch__13[9], ch__14[129], ch__15[6], ch__16[4], ch__17[103], 
	    ch__18[85], ch__19[14];
    cilist ci__1;
    icilist ici__1;

    /* Builtin functions */
    integer s_wsfi(), do_fio(), e_wsfi();
    /* Subroutine */ int s_cat();
    integer s_wsfe(), e_wsfe(), lbit_shift(), s_wsle(), do_lio(), e_wsle();
    /* Subroutine */ int s_stop();
    integer pow_ii(), i_indx();
    /* Subroutine */ int s_copy();
    integer s_cmp();
    double r_lg10();

    /* Local variables */
    extern /* Subroutine */ int putorn_(), accsym_();
    static integer lacc;
    extern /* Subroutine */ int dotmov_(), beamend_(), beamid_();
    static logical hang;
    static integer ifig;
    extern /* Subroutine */ int addblank_(), notex_();
    static integer iib;
    extern doublereal feon_();
    static integer itleft, itright, itendb, nspb, ivlast, nodu, lcwr;
    extern /* Character */ VOID udqq_();
    static char cwrq[79];
    static real ptgr[37], spgr, zero;
    static integer ntup, iiv, jv, ndig;
    extern logical blkstart_();
    extern /* Subroutine */ int eskb4_(), beamstrt_();
    static real ptsavail;
    static integer mtrspc, itndxtup;
    static logical isacc;
    static integer nclef, iaskb[7];
    extern integer ncmid_();
    extern /* Subroutine */ int docrd_();
    static logical issig;
    static integer nornb[7];
    static logical iscln, isdot;
    static char noteq[8];
    static logical inarp, isarp;
    static char soutq[80];
    static integer lnote, lsout;
    static real fxtup;
    static integer itrpt, itsig;
    static logical found1;
    static integer iirpt, lclow, itnow, ib, jb;
    extern /* Subroutine */ int beamn1_();
    extern integer lc_();
    static integer ig, nd, lchead, in, ip;
    extern /* Subroutine */ int addask_();
    static logical isclef, bspend, isflag, isgaft;
    static integer ihornb[168]	/* was [7][24] */;
    static logical isaccs;
    static real ptclef[5], eskndg[7], ptsndg[7];
    static logical rpndot;
    static char notexq[79];
    static logical stemup;
    static char acsymq[3];
    static logical isxtup;
    static integer kv, ibxtup, numblx, lnoten;
    extern /* Subroutine */ int wsclef_();
    static integer maxtup, ithang, nodurx;
    static real elxtup;
    static integer jb1;
    static real fother;
    extern /* Subroutine */ int chkarp_();
    static integer ibmchk, ing;
    static real esk;
    extern /* Subroutine */ int addasx_();
    static logical isgrace;
    static real wgr;
    static integer nsp;
    static real ptbneed;
    extern /* Subroutine */ int addstr_();
    static real pts, offnsk;
    extern /* Subroutine */ int putfig_();
    static integer il;
    extern /* Character */ VOID upcaseq_();
    static real elother, ptsneed;
    static logical cwrferm[7];
    extern /* Subroutine */ int clefsym_(), putarp_(), precrd_();
    static logical isrshft, isfirst, nofirst, allxtup, isbstrt;
    static char slurudq[1];
    extern integer log2_();
    extern /* Subroutine */ int putshft_(), doslur_();
    static integer islhgt, iphold;
    extern /* Subroutine */ int dograce_(), endslur_(), notefq_(), setbits_();

    /* Fortran I/O blocks */
    static icilist io___193 = { 0, noteq, 0, "(1H{,i3,1H})", 5, 1 };
    static icilist io___195 = { 0, noteq, 0, "(1H{,i2,1H})", 4, 1 };
    static icilist io___196 = { 0, noteq, 0, "(i1)", 1, 1 };
    static cilist io___199 = { 0, 11, 0, "(a)", 0 };
    static cilist io___202 = { 0, 11, 0, "(a)", 0 };
    static cilist io___223 = { 0, 6, 0, 0, 0 };
    static cilist io___224 = { 0, 6, 0, 0, 0 };
    static cilist io___242 = { 0, 6, 0, 0, 0 };
    static cilist io___255 = { 0, 11, 0, "(a)", 0 };
    static cilist io___256 = { 0, 11, 0, "(a)", 0 };
    static cilist io___257 = { 0, 11, 0, "(a)", 0 };
    static cilist io___258 = { 0, 11, 0, "(a)", 0 };
    static cilist io___259 = { 0, 11, 0, "(a)", 0 };
    static cilist io___260 = { 0, 6, 0, 0, 0 };
    static cilist io___261 = { 0, 11, 0, "(a)", 0 };
    static cilist io___262 = { 0, 11, 0, "(a)", 0 };
    static icilist io___264 = { 0, notexq+11, 0, "(i2)", 2, 1 };
    static icilist io___266 = { 0, notexq+14, 0, "(f4.2)", 4, 1 };
    static icilist io___267 = { 0, notexq+14, 0, "(a1,f3.2)", 4, 1 };
    static icilist io___271 = { 0, notexq+6, 0, "(f3.1)", 3, 1 };
    static icilist io___272 = { 0, notexq+6, 0, "(f4.1)", 4, 1 };
    static icilist io___274 = { 0, notexq+5, 0, "(f3.1)", 3, 1 };
    static icilist io___275 = { 0, notexq+5, 0, "(f4.1)", 4, 1 };
    static cilist io___277 = { 0, 6, 0, 0, 0 };
    static cilist io___278 = { 0, 11, 0, "(a)", 0 };
    static cilist io___279 = { 0, 11, 0, "(a)", 0 };
    static icilist io___290 = { 0, notexq+6, 0, "(i1)", 1, 1 };
    static icilist io___291 = { 0, notexq+6, 0, "(i2)", 2, 1 };
    static cilist io___294 = { 0, 6, 0, 0, 0 };
    static cilist io___302 = { 0, 11, 0, "(a)", 0 };
    static cilist io___305 = { 0, 11, 0, "(a)", 0 };
    static cilist io___306 = { 0, 11, 0, "(a)", 0 };
    static cilist io___310 = { 0, 11, 0, "(a)", 0 };



/*  Factors for grace note, clef spacing. (fraction of wheadpt or apt) */
/*  In 1.04, moved to block data subprogram */

/*      common /comslur/ listslur,ndxslur(nm,2),upslur(nm,2) */

/*  Set up main ib loop within which a block (notes group) is written */

    /* Parameter adjustments */
    --clefq;
    --lbxtup;
    --istart;
    --numbms;
    --n1xtup;
    --istop;
    --nindex;
    --cwrest;
    --itstart;

    /* Function Body */
    i__1 = all_1.nv;
    for (all_1.iv = 1; all_1.iv <= i__1; ++all_1.iv) {
	i__2 = commvl_1.nvmx[all_1.iv - 1];
	for (kv = 1; kv <= i__2; ++kv) {
	    commvl_1.ivx = commvl_1.ivmx[all_1.iv + kv * 7 - 8];
	    all_1.ibmcnt[commvl_1.ivx - 1] = 1;
	    all_1.beamon[commvl_1.ivx - 1] = FALSE_;
	    nornb[commvl_1.ivx - 1] = 0;
	    iaskb[commvl_1.ivx - 1] = 1;
/* L25: */
	}
    }
    comas1_1.iasxb = 1;
    comas1_1.naskb = 0;
    comas1_1.nasxb = 0;
    ifig = 1;
    comxtup_1.ixtup = 0;
    ibxtup = 0;
    bspend = FALSE_;
    numblx = 0;
    comnsp_1.xtupb4 = FALSE_;

/* numblx = 1 when Xtup starts, and increased if Xtup goes into other bloc
ks*/

    i__2 = comnsp_1.nb;
    for (ib = 1; ib <= i__2; ++ib) {

/*  Check for segno */

/*       if (ornq(1,list(2,istart(ib))).eq.'g' .and. */
	if (bit_test(all_1.iornq[all_1.list[(istart[ib] << 2) - 3] * 7 - 7],4)
		 && all_1.list[(istart[ib] << 2) - 4] == 1) {
	    if (comgrace_1.noffseg <= -10) {
		s_wsfi(&io___193);
		do_fio(&c__1, (char *)&comgrace_1.noffseg, (ftnlen)sizeof(
			integer));
		e_wsfi();
		lnoten = 5;
	    } else if (comgrace_1.noffseg < 0 || comgrace_1.noffseg >= 10) {
		s_wsfi(&io___195);
		do_fio(&c__1, (char *)&comgrace_1.noffseg, (ftnlen)sizeof(
			integer));
		e_wsfi();
		lnoten = 4;
	    } else {
		s_wsfi(&io___196);
		do_fio(&c__1, (char *)&comgrace_1.noffseg, (ftnlen)sizeof(
			integer));
		e_wsfi();
		lnoten = 1;
	    }
/* Writing concatenation */
	    i__3[0] = 1, a__1[0] = all_1.sq;
	    i__3[1] = 6, a__1[1] = "znotes";
	    i__3[2] = 1, a__1[2] = all_1.sq;
	    i__3[3] = 6, a__1[3] = "segnoo";
	    i__3[4] = lnoten, a__1[4] = noteq;
	    i__3[5] = 1, a__1[5] = "9";
	    s_cat(notexq, a__1, i__3, &c__6, 79L);
	    lnote = lnoten + 15;
	    i__1 = all_1.nv;
	    for (all_1.iv = 2; all_1.iv <= i__1; ++all_1.iv) {
/* Writing concatenation */
		i__3[0] = lnote, a__1[0] = notexq;
		i__3[1] = 1, a__1[1] = "&";
		i__3[2] = 1, a__1[2] = all_1.sq;
		i__3[3] = 6, a__1[3] = "segnoo";
		i__3[4] = lnoten, a__1[4] = noteq;
		i__3[5] = 1, a__1[5] = "9";
		s_cat(notexq, a__1, i__3, &c__6, 79L);
		lnote = lnote + lnoten + 9;
/* L130: */
	    }
	    s_wsfe(&io___199);
/* Writing concatenation */
	    i__4[0] = lnote, a__2[0] = notexq;
	    i__4[1] = 1, a__2[1] = all_1.sq;
	    i__4[2] = 2, a__2[2] = "en";
	    s_cat(ch__1, a__2, i__4, &c__3, 82L);
	    do_fio(&c__1, ch__1, lnote + 3);
	    e_wsfe();
	    lnote = 0;
	}

/*  Check for new clefs */

	isclef = FALSE_;
	if (bit_test(all_1.islur[all_1.list[(istart[ib] << 2) - 4] + 
		all_1.list[(istart[ib] << 2) - 3] * 7 - 8],15)) {

/*  In preceding line, fl32 gave wrong result for ... .gt.0 !!! */

	    i__1 = istop[ib];
	    for (in = istart[ib]; in <= i__1; ++in) {
		if (bit_test(all_1.islur[all_1.list[(in << 2) - 4] + 
			all_1.list[(in << 2) - 3] * 7 - 8],11)) {
		    i__5 = lbit_shift(all_1.islur[all_1.list[(in << 2) - 4] + 
			    all_1.list[(in << 2) - 3] * 7 - 8], -12L) & 7;
		    wsclef_(&all_1.list[(in << 2) - 4], &all_1.nv, noinst, 
			    clefq + 1, &i__5, 1L);
		}
/* L140: */
	    }
	    s_wsfe(&io___202);
/* Writing concatenation */
	    i__6[0] = 1, a__3[0] = all_1.sq;
	    i__6[1] = 11, a__3[1] = "pmxnewclefs";
	    s_cat(ch__2, a__3, i__6, &c__2, 12L);
	    do_fio(&c__1, ch__2, 12L);
	    e_wsfe();
	    isclef = TRUE_;
	}

/*  Start the notes group */

	allxtup = FALSE_;
	comxtup_1.inxtup = FALSE_;
/* Writing concatenation */
	i__6[0] = 1, a__3[0] = all_1.sq;
	i__6[1] = comstart_1.lstart[nindex[ib] - 1], a__3[1] = 
		comstart_1.nstartq + (nindex[ib] - 1) * 6;
	s_cat(soutq, a__3, i__6, &c__2, 80L);
	lsout = comstart_1.lstart[nindex[ib] - 1] + 1;
	if (*nxtup > 0 && ibxtup < *nbxtup && ib == lbxtup[ibxtup + 1]) {

/*  Xtup in this block. Set vxtup, xtupfac, ntupv for each voice. 
*/

	    ++ibxtup;
	    comxtup_1.inxtup = TRUE_;
	    numblx = 1;
	    maxtup = 0;
	    allxtup = TRUE_;
	    ithang = 0;
	    i__1 = all_1.nv;
	    for (all_1.iv = 1; all_1.iv <= i__1; ++all_1.iv) {
		i__5 = commvl_1.nvmx[all_1.iv - 1];
		for (kv = 1; kv <= i__5; ++kv) {
		    commvl_1.ivx = commvl_1.ivmx[all_1.iv + kv * 7 - 8];
		    comxtup_1.xtupfac[commvl_1.ivx - 1] = (float)1.;
		    comxtup_1.vxtup[commvl_1.ivx - 1] = FALSE_;
		    comxtup_1.ntupv[commvl_1.ivx - 1] = 0;

/*  Search forward for ip of first note */

		    i__7 = istop[ib];
		    for (all_1.jn = istart[ib]; all_1.jn <= i__7; ++all_1.jn) 
			    {
			if (all_1.list[(all_1.jn << 2) - 4] == commvl_1.ivx) {
			    ip = all_1.list[(all_1.jn << 2) - 3];
			    goto L110;
			}
/* L109: */
		    }

/*  If here, ivx has no notes in this blk, but may overhan
g. */

		    goto L100;
L110:
		    if (all_1.nodur[commvl_1.ivx + ip * 7 - 8] == 0) {

/* This voice has an xtuplet. Count notes.  May go pas
t end of current block.*/

			comxtup_1.vxtup[commvl_1.ivx - 1] = TRUE_;
			++comxtup_1.ixtup;
			ntup = 2;
			for (++ip; ip <= 100; ++ip) {
			    if (all_1.nodur[commvl_1.ivx + ip * 7 - 8] > 0) {
				goto L102;
			    }
			    ++ntup;
/* L101: */
			}
L102:
			comxtup_1.ntupv[commvl_1.ivx - 1] = ntup;
			maxtup = max(maxtup,ntup);

/* Following will be repeated if >1 xtup, but all must
 span same *total* time*/

			nodurx = all_1.nodur[commvl_1.ivx + ip * 7 - 8];
		    } else {
			allxtup = FALSE_;
		    }
L100:
		    ;
		}
	    }
	    r__1 = nodurx / (float)1. / maxtup;
	    elxtup = maxtup * feon_(&r__1);
	    itndxtup = all_1.list[(n1xtup[comxtup_1.ixtup] << 2) - 2] + 
		    nodurx;
	    r__1 = (real) comnsp_1.nspace[ib - 1];
	    fxtup = elxtup / feon_(&r__1) / maxtup;

/*  Above fxtup is m-n-s based on maxtup, as if maxtup dominates l
ength. */
/*  allxtup true => each voice xtup or empty in this blk. May stil
l hang. */

	    hang = FALSE_;
	    if (allxtup && ib < comnsp_1.nb) {
		i__5 = all_1.nv;
		for (all_1.iv = 1; all_1.iv <= i__5; ++all_1.iv) {
		    i__1 = commvl_1.nvmx[all_1.iv - 1];
		    for (kv = 1; kv <= i__1; ++kv) {
			commvl_1.ivx = commvl_1.ivmx[all_1.iv + kv * 7 - 8];
			if (! comxtup_1.vxtup[commvl_1.ivx - 1]) {
			    i__7 = istop[ib + 1];
			    for (all_1.jn = istart[ib + 1]; all_1.jn <= i__7; 
				    ++all_1.jn) {
				if (all_1.list[(all_1.jn << 2) - 4] == 
					commvl_1.ivx) {
				    if (all_1.list[(all_1.jn << 2) - 2] < 
					    itndxtup) {
					hang = TRUE_;
					ithang = all_1.list[(all_1.jn << 2) - 
						2] - itstart[ib];
					goto L115;
				    }
				    goto L113;
				}
/* L114: */
			    }
			}
L113:
			;
		    }
		}
	    }
L115:
	    if (allxtup && ! hang) {
		i__1 = all_1.nv;
		for (all_1.iv = 1; all_1.iv <= i__1; ++all_1.iv) {
		    i__5 = commvl_1.nvmx[all_1.iv - 1];
		    for (kv = 1; kv <= i__5; ++kv) {
			commvl_1.ivx = commvl_1.ivmx[all_1.iv + kv * 7 - 8];
			if (comxtup_1.ntupv[commvl_1.ivx - 1] > 0) {
			    comxtup_1.xtupfac[commvl_1.ivx - 1] = fxtup * 
				    maxtup / comxtup_1.ntupv[commvl_1.ivx - 1]
				    ;
			}
/* L108: */
		    }
		}
	    } else {

/*  Must deal with simultaneous non-xtuplets */

		if (! hang) {
		    elother = (float)0.;
		    jb1 = ib;
		} else {
		    r__1 = (real) ithang;
		    elother = feon_(&r__1);
		    ++numblx;
		    jb1 = ib + 1;
		}
		i__5 = comnsp_1.nb;
		for (jb = jb1; jb <= i__5; ++jb) {
		    nspb = (all_1.list[(istop[jb] << 2) - 2] - all_1.list[(
			    istart[jb] << 2) - 2]) / comnsp_1.nspace[jb - 1] 
			    + 1;
		    r__1 = (real) comnsp_1.nspace[jb - 1];
		    elother += nspb * feon_(&r__1);
		    if (itndxtup <= all_1.list[(istop[jb] << 2) - 2] + 
			    comnsp_1.nspace[jb - 1]) {
			goto L104;
		    }

/*  If here, xtup spans more than one block, including pos
sible hanger. */

		    ++numblx;
/* L103: */
		}
L104:
		if (elxtup > elother) {

/*  Xtup dominates length.  Stretch other stuff. */

		    fother = elxtup / elother;
		} else {

/*  Other stuff dominates length, stretch xtup */

		    fother = (float)1.;
		    fxtup = fxtup * elother / elxtup;
		}
		i__5 = all_1.nv;
		for (all_1.iv = 1; all_1.iv <= i__5; ++all_1.iv) {
		    i__1 = commvl_1.nvmx[all_1.iv - 1];
		    for (kv = 1; kv <= i__1; ++kv) {
			commvl_1.ivx = commvl_1.ivmx[all_1.iv + kv * 7 - 8];
			if (comxtup_1.vxtup[commvl_1.ivx - 1]) {
			    comxtup_1.xtupfac[commvl_1.ivx - 1] = fxtup * 
				    maxtup / comxtup_1.ntupv[commvl_1.ivx - 1]
				    ;
			} else {
			    comxtup_1.xtupfac[commvl_1.ivx - 1] = fother;
			}
/* L105: */
		    }
		}
	    }
	} else if (numblx > 1) {

/* In a block with continuation--but not start--of xtup. Use left-
over fother*/

	    i__1 = all_1.nv;
	    for (all_1.iv = 1; all_1.iv <= i__1; ++all_1.iv) {
		i__5 = commvl_1.nvmx[all_1.iv - 1];
		for (kv = 1; kv <= i__5; ++kv) {
		    commvl_1.ivx = commvl_1.ivmx[all_1.iv + kv * 7 - 8];
		    if (comxtup_1.vxtup[commvl_1.ivx - 1]) {
			comxtup_1.xtupfac[commvl_1.ivx - 1] = (float)1.;
		    } else {
			comxtup_1.xtupfac[commvl_1.ivx - 1] = fother;
		    }
/* L106: */
		}
	    }
	    --numblx;
	} else {

/*  In a block unaffected by xtuplets */

	    i__5 = all_1.nv;
	    for (all_1.iv = 1; all_1.iv <= i__5; ++all_1.iv) {
		i__1 = commvl_1.nvmx[all_1.iv - 1];
		for (kv = 1; kv <= i__1; ++kv) {
		    commvl_1.ivx = commvl_1.ivmx[all_1.iv + kv * 7 - 8];
		    comxtup_1.vxtup[commvl_1.ivx - 1] = FALSE_;
		    comxtup_1.xtupfac[commvl_1.ivx - 1] = (float)1.;
/* L107: */
		}
	    }
	    numblx = 0;
	}

/* Done setting up xtuplet stuff.  Run thru whole block, flag accident
als etc*/
/*  that are too close.  just one per *time* . */
/* Note about bar starts and after rpt's/boublebars: There is an after
ruleskip*/
/*   (fbar*wheadpt) following, but rpts seem to occupy some of that ga
p, so*/
/*    (dotsfac*wheadpt) is presumed to be filled up. */

	in = istart[ib] - 1;
	inarp = FALSE_;
	itrpt = -1;
	itsig = -1;
L111:
	++in;
	if (in > istop[ib]) {
	    goto L112;
	}
	ip = all_1.list[(in << 2) - 3];
	commvl_1.ivx = all_1.list[(in << 2) - 4];
	if (commvl_1.ivx <= all_1.nv) {
	    all_1.iv = commvl_1.ivx;
	} else {
	    i__1 = all_1.nv;
	    for (all_1.iv = 1; all_1.iv <= i__1; ++all_1.iv) {
		if (commvl_1.nvmx[all_1.iv - 1] == 2 && commvl_1.ivmx[
			all_1.iv + 6] == commvl_1.ivx) {
		    goto L129;
		}
/* L128: */
	    }
	    s_wsle(&io___223);
	    do_lio(&c__9, &c__1, "Trouble finding iv!, ivx,nvmx,ivmx:", 35L);
	    do_lio(&c__3, &c__1, (char *)&commvl_1.ivx, (ftnlen)sizeof(
		    integer));
	    do_lio(&c__3, &c__1, (char *)&commvl_1.nvmx[0], (ftnlen)sizeof(
		    integer));
	    do_lio(&c__3, &c__1, (char *)&commvl_1.nvmx[1], (ftnlen)sizeof(
		    integer));
	    e_wsle();
	    s_wsle(&io___224);
	    do_lio(&c__3, &c__1, (char *)&commvl_1.ivmx[0], (ftnlen)sizeof(
		    integer));
	    do_lio(&c__3, &c__1, (char *)&commvl_1.ivmx[7], (ftnlen)sizeof(
		    integer));
	    do_lio(&c__3, &c__1, (char *)&commvl_1.ivmx[1], (ftnlen)sizeof(
		    integer));
	    do_lio(&c__3, &c__1, (char *)&commvl_1.ivmx[8], (ftnlen)sizeof(
		    integer));
	    e_wsle();
	    s_stop("", 0L);
	}
L129:

/* Remember, rpts & internal sigs can only come at start of (internal)
 block*/

	isacc = *(unsigned char *)&all_1.accq[commvl_1.ivx + ip * 7 - 8] != 
		'x';
	isaccs = isacc || bit_test(all_1.iornq[commvl_1.ivx + ip * 7 - 8],0);
	isarp = bit_test(all_1.iornq[commvl_1.ivx + ip * 7 - 8],27);
	if (bit_test(all_1.ipl[commvl_1.ivx + ip * 7 - 8],10)) {

/*  Check chord notes for accidentals and arpeggios. */

	    chkarp_(&found1, &comtrill_1.ncrd, comtrill_1.icrdat, &
		    commvl_1.ivx, &ip, &isaccs, &isarp);
	}

/*  When we get motivated, will do spacing for arpeggios here. */

	if (commvl_1.ivx == 1 && (all_1.islur[commvl_1.ivx + ip * 7 - 8] & 96)
		 > 0) {
	    itrpt = all_1.list[(in << 2) - 2];
	}
	issig = bit_test(all_1.ipl[commvl_1.ivx + ip * 7 - 8],28);
	if (commvl_1.ivx == 1 && issig) {
	    itsig = all_1.list[(in << 2) - 2];
	}
	isgrace = bit_test(all_1.islur[commvl_1.ivx + ip * 7 - 8],4) && ! 
		bit_test(all_1.ipl[commvl_1.ivx + ip * 7 - 8],29) && ! 
		bit_test(all_1.ipl[commvl_1.ivx + ip * 7 - 8],31);
	isgaft = FALSE_;
	if (ip > 1) {
	    nd = all_1.nodur[commvl_1.ivx + (ip - 1) * 7 - 8];
	    isbstrt = blkstart_(all_1.list, &in, &itstart[ib], &all_1.nodur[
		    all_1.list[(in - 1 << 2) - 4] + all_1.list[(in - 1 << 2) 
		    - 3] * 7 - 8]);
	    isgaft = bit_test(all_1.ipl[commvl_1.ivx + (ip - 1) * 7 - 8],29) 
		    || bit_test(all_1.ipl[commvl_1.ivx + (ip - 1) * 7 - 8],31)
		    ;
	    isgrace = isgrace || isgaft;
	}

/*  Bypass if non-grace, not 1st in bar, & prev. note uses > 1 noteski
p */

	if (ip > 1 && ! isgrace) {

/*  Prior note can't end Xtup, since not last note in voice in blo
ck. */

	    nsp = comnsp_1.nspace[ib - 1];
	    if (isbstrt) {
		nsp = comnsp_1.nspace[ib - 2];
	    }
	    if (nd > nsp) {
		if (isaccs && spfacs_1.bacfac < (float)1e5) {
		    upcaseq_(ch__3, 1L, all_1.accq + (commvl_1.ivx + ip * 7 - 
			    8), 1L);
		    *(unsigned char *)&all_1.accq[commvl_1.ivx + ip * 7 - 8] =
			     *(unsigned char *)&ch__3[0];
		}
		goto L99;
	    }
	}
	iscln = isclef && bit_test(all_1.islur[commvl_1.ivx + ip * 7 - 8],11);

/* Is prev. note non-beamed, up-stemmed, & flagged? Recall if ip>1, ha
ve nd*/

	isflag = ip > 1 && nd > 0 && nd < 16;
	if (isflag) {
	    i__5 = ip - 1;
	    i__1 = ncmid_(&all_1.iv, &i__5);
	    udqq_(ch__3, 1L, &all_1.nolev[commvl_1.ivx + (ip - 1) * 7 - 8], &
		    i__1, &all_1.islur[commvl_1.ivx + (ip - 1) * 7 - 8], &
		    commvl_1.nvmx[all_1.iv - 1], &commvl_1.ivx, &all_1.nv);
	    isflag = ! bit_test(all_1.irest[commvl_1.ivx + (ip - 1) * 7 - 8],
		    0) && *(unsigned char *)&ch__3[0] == 'u';
	}
	if (isflag) {
	    i__1 = numbms[commvl_1.ivx];
	    for (ibmchk = 1; ibmchk <= i__1; ++ibmchk) {
		if (ip - 1 < all_1.ibm1[commvl_1.ivx + ibmchk * 7 - 8]) {
		    goto L117;
		} else if (ip - 1 <= all_1.ibm2[commvl_1.ivx + ibmchk * 7 - 8]
			) {
		    isflag = FALSE_;
		    goto L117;
		}
/* L116: */
	    }
	}
L117:

/*  If isflag, then won't need to check for dot on prev. note. */

	isdot = ip > 1 && ! comxtup_1.vxtup[commvl_1.ivx - 1];
	if (isdot) {
	    i__5 = max(1,nd);
	    i__1 = log2_(&i__5);
	    isdot = pow_ii(&c__2, &i__1) != nd;
	}

/*  Next line negates isdot if dotted item is xtuplet. */

	if (isdot) {
	    isdot = ip == 2 || all_1.nodur[commvl_1.ivx + (ip - 2) * 7 - 8] > 
		    0;
	}
	isrshft = ip > 1;
	if (isrshft) {
	    isrshft = bit_test(all_1.irest[commvl_1.ivx + (ip - 1) * 7 - 8],
		    20);
	}
	if (! (isaccs || isgrace || iscln || isflag || isrshft || isdot || 
		bit_test(all_1.iornq[commvl_1.ivx + ip * 7 - 8],26) || 
		bit_test(all_1.irest[commvl_1.ivx + ip * 7 - 8],21) || isarp))
		 {
	    goto L111;
	}

/*  Here is an accid,grace,clef,flag,dot,udsp,uxsp,arpeg. May need spa
ce. */

	pts = comask_1.wheadpt;
	if (isgrace) {
	    i__1 = comgrace_1.ngrace;
	    for (ig = 1; ig <= i__1; ++ig) {
		if (! isgaft) {
		    if (comgrace_1.ipg[ig - 1] == ip && comgrace_1.ivg[ig - 1]
			     == commvl_1.ivx) {
			goto L123;
		    }
		} else if (ip > 1) {
		    if (comgrace_1.ipg[ig - 1] == ip - 1 && comgrace_1.ivg[ig 
			    - 1] == commvl_1.ivx) {
			goto L123;
		    }
		}
/* L122: */
	    }
	    s_wsle(&io___242);
	    do_lio(&c__9, &c__1, "Problem finding grace index in makeabar", 
		    39L);
	    e_wsle();
	    s_stop("", 0L);
L123:

/*  wgr = distance to backspace (in headwidths), less main acc. */
/*  ptgr = same in pts,+ main acc.  Not used for after-grace. */
/* spgr = total space needed (w/o main acc). NB apt=wheadpt, don't
 get confused.*/
/*  Also, spgr is same for b4 or after, but xb4fac-space will be i
n diff. place.*/

	    if (comgrace_1.nng[ig - 1] == 1) {
		wgr = spfacs_1.grafac;
	    } else {
		wgr = comgrace_1.nng[ig - 1] * spfacs_1.emgfac;
		i__1 = comgrace_1.nng[ig - 1];
		for (ing = 2; ing <= i__1; ++ing) {
		    if (*(unsigned char *)&comgrace_1.accgq[comgrace_1.ngstrt[
			    ig - 1] - 1 + ing - 1] != 'x') {
			wgr += spfacs_1.acgfac;
		    }
/* L126: */
		}
	    }
	    ptgr[ig - 1] = wgr * comask_1.wheadpt;
	    spgr = ptgr[ig - 1] + spfacs_1.xb4fac * comask_1.wheadpt;
	    if (isaccs) {
		ptgr[ig - 1] += spfacs_1.accfac * comask_1.wheadpt;
	    }
	    if (*(unsigned char *)&comgrace_1.accgq[comgrace_1.ngstrt[ig - 1] 
		    - 1] != 'x') {
		spgr += comask_1.wheadpt * spfacs_1.agc1fac;
	    }
	    pts += spgr;
	}
	if (iscln) {
	    pts += spfacs_1.clefac * comask_1.wheadpt;

/*  How far to backspace when printing the clef */

	    ptclef[commvl_1.ivx - 1] = (float)0.;
	    if (isaccs) {
		ptclef[commvl_1.ivx - 1] += spfacs_1.accfac * 
			comask_1.wheadpt;
	    }
	    if (isgrace) {
		ptclef[commvl_1.ivx - 1] += spgr;
	    }
/*     print*,'+CLEF, ptclef, pts->',ptclef(ivx),pts */
	}
	if (isrshft) {
	    pts += spfacs_1.rtshfac * comask_1.wheadpt;
	} else if (isflag) {
	    pts += spfacs_1.flagfac * comask_1.wheadpt;
/*     print*,'+FLAG, pts->',pts */
	} else if (isdot) {
	    pts += spfacs_1.dotfac * comask_1.wheadpt;
/*     print*,'+DOT, pts->',pts */
	}
	if (all_1.list[(in << 2) - 2] == itrpt) {

/*  Repeat, need a little extra space */

	    pts += spfacs_1.dotsfac * comask_1.wheadpt;
/*     print*,'ITRPT, pts->',pts */
	}
	if (isarp) {
	    pts += spfacs_1.arpfac * comask_1.wheadpt;
/*     print*,'Due to isarp, pts, arpfac:',pts,arpfac */
	}
	pts += spfacs_1.xspfac * comask_1.wheadpt;
/*     print*,'FINISH, xspfac,pts->',xspfac,pts */

/*  Get available space in elemskips (esk) */

	esk = (float)0.;
	isxtup = FALSE_;
	isfirst = FALSE_;
/*     print*,'numblx,isbstrt:',numblx,isbstrt */
/*       if (numblx.eq.0 .or. isbstrt) then */
	if (numblx == 0 || isbstrt || ip == 1) {

/* No influence of xtuplets (unless 1st note in non-1st blk & prev
 blk is xtup)*/

	    isfirst = ip == 1 || all_1.list[(in << 2) - 2] == itrpt || 
		    all_1.list[(in << 2) - 2] == itsig;
	    if (isfirst) {

/*  At start of bar or after repeat sign or new signature */

		if (all_1.list[(in << 2) - 2] == itsig) {
		    esk = (float)0.;
		} else {
		    esk = comask_1.fbar;
		}
/*     print*,'Start of bar or after repeat, ibar,esk:',ibar,e
sk */
	    } else if (isbstrt) {

/*  Not 1st note of bar; first note of block */

/*     print*,'Not 1st of bar; 1st of block; xtupb4,ip,nodur(i
p-2): ' */
/*    *,xtupb4,ip,nodur(ivx,ip-2) */
		if (comnsp_1.xtupb4) {
/*             if (ip.gt.2 .and. nodur(ivx,ip-2).eq.0) the
n */
/* c */
/* c  Xtup in prev block in this voice */
/*  Xtup in prev block in some voice */
/* c */
		    r__1 = (real) comnsp_1.nspace[ib - 2];
		    esk = feon_(&r__1) * comnsp_1.xtfold[commvl_1.ivx - 1];
/*             else */
/*               continue */

/*c  Xtup in prev block but not in this voice; use left-ov
er params from prev. blk*/
/* c  Fill in later */

/*             end if */
		} else {

/*  Not at start of bar; 1st in blk, no xtup. */
/*  Note in prior block uses only one noteskip */

		    r__1 = (real) comnsp_1.nspace[ib - 2];
		    esk = feon_(&r__1);
/*     print*,'Not at start of bar, 1st in blk, no xtup, e
sk:',esk */
		}
	    } else {

/*  No xtup, not 1st in bar, not 1st in blk */
/*  Note uses only one noteskip */

		r__1 = (real) comnsp_1.nspace[ib - 1];
		esk = feon_(&r__1);
/*     print*,'No xtup, not 1st in bar, not 1st in blk, esk:',
esk */
	    }
	} else if (comxtup_1.inxtup && in > istart[ib]) {
	    if (comxtup_1.vxtup[commvl_1.ivx - 1]) {

/*  Check for interference in xtuplet. */

		esk = elxtup / comxtup_1.ntupv[commvl_1.ivx - 1];
		isxtup = TRUE_;
/*     print*,'In xtup, esk:',esk */
	    } else {
		esk = (float)100.;
	    }
	}
	if (isgrace) {

/*  Since graces can be very long, cannot assume no interference i
f prior */
/* note uses >1 noteskip.  So must get elsk's back to prior note, 
whether or*/
/* not it used only one noteskip.  But if it was xtup. don't need 
to call eskb4.*/

	    if ((ip <= 2 || all_1.nodur[commvl_1.ivx + (ip - 2) * 7 - 8] > 0) 
		    && all_1.list[(in << 2) - 2] != itsig) {
		eskb4_(&ip, &commvl_1.ivx, &in, &ib, comnsp_1.nspace, &
			itstart[1], &comask_1.fbar, &itrpt, &esk);
	    }
	}

/*  Done getting available elemskips.  Check if we got anything: */

	if (esk < (float)1e-4) {
/*         print*,'BOOGERS!! esk not set' */
/*         go to 111 */
	}
	if (isfirst) {
	    pts -= comask_1.wheadpt;
	}
/*     print*,'isfirst,pts:',isfirst,pts */
	ptbneed = pts;
/*     print*,'ptbneed: ',ptbneed */
	if (isaccs) {
	    ptbneed += comask_1.wheadpt * spfacs_1.bacfac;
	}
/*     print*,'poenom*esk,ptbneed=>',poenom*esk,ptbneed */
	if (comask_1.poenom * esk > ptbneed) {
	    if (isacc) {
		upcaseq_(ch__3, 1L, all_1.accq + (commvl_1.ivx + ip * 7 - 8), 
			1L);
		*(unsigned char *)&all_1.accq[commvl_1.ivx + ip * 7 - 8] = *(
			unsigned char *)&ch__3[0];
	    }
/*     print*,'BIG GAP, UPCASEQ, pts,esk:',ptbneed,esk */
	    goto L99;
	}
	ptsneed = pts;
	if (isaccs) {
	    ptsneed += spfacs_1.accfac * comask_1.wheadpt;
	}
/*     print*,'ptsneed, ptsavail:',ptsneed,poenom*esk */
	if (comask_1.poenom * esk < ptsneed) {
	    if (! isxtup) {
		addask_(&all_1.list[(in << 2) - 2], &ptsneed, &esk, &
			comask_1.fixednew, &comask_1.scaldold, &c__0, &
			c_false);
/*     print*,'AddasK,pts,esk:',ptsneed,esk */
/*     print* */
	    } else {
		addasx_(&ip, &commvl_1.ivx, &ptsneed, &esk, &
			comask_1.fixednew, &comask_1.scaldold, &c_false);
/*     print*,'AddasX,pts,esk:',ptsneed,esk */
/*     print* */
		if (numblx > 1) {
		    comxtup_1.xtupfac[commvl_1.ivx - 1] *= 1 - ((comask_1.apt 
			    + comask_1.wheadpt) / comask_1.poenom - esk) / 
			    elxtup;
		}
	    }
	}
L99:
	if (bit_test(all_1.iornq[commvl_1.ivx + ip * 7 - 8],26)) {

/*  User-defined space.  Warning, "zero" may change value in addas
k! */

	    zero = (float)0.;
	    addask_(&all_1.list[(in << 2) - 2], &ptsneed, &zero, &
		    comask_1.fixednew, &comask_1.scaldold, itglp1, &c_true);
	} else if (bit_test(all_1.irest[commvl_1.ivx + ip * 7 - 8],21)) {

/*  User-defined xtup space.  Warning, "zero" may change value in 
addask! */

	    addasx_(&ip, &commvl_1.ivx, &ptsneed, &esk, &comask_1.fixednew, &
		    comask_1.scaldold, &c_true);
	}

/*  End of big manual loop over "in" for accidental checking */

	goto L111;
L112:

/*End of ask analysis for this block.  Check for internal repeat or si
g change.*/

	if (ib > 1 && all_1.list[(istart[ib] << 2) - 4] == 1) {
	    iirpt = all_1.islur[all_1.list[(istart[ib] << 2) - 3] * 7 - 7] & 
		    67109216;
	    if (iirpt > 0) {

/* Internal repeat */

		s_wsfe(&io___255);
/* Writing concatenation */
		i__8[0] = 1, a__4[0] = all_1.sq;
		i__8[1] = 7, a__4[1] = "advance";
		i__8[2] = 1, a__4[2] = all_1.sq;
		i__8[3] = 8, a__4[3] = "barno-1%";
		s_cat(ch__4, a__4, i__8, &c__4, 17L);
		do_fio(&c__1, ch__4, 17L);
		e_wsfe();
		if (iirpt == 96) {
		    s_wsfe(&io___256);
/* Writing concatenation */
		    i__6[0] = 1, a__3[0] = all_1.sq;
		    i__6[1] = 15, a__3[1] = "leftrightrepeat";
		    s_cat(ch__5, a__3, i__6, &c__2, 16L);
		    do_fio(&c__1, ch__5, 16L);
		    e_wsfe();
		    comask_1.fixednew += spfacs_1.lrrptfac * comask_1.wheadpt;
		} else if (bit_test(iirpt,5)) {
		    s_wsfe(&io___257);
/* Writing concatenation */
		    i__6[0] = 1, a__3[0] = all_1.sq;
		    i__6[1] = 10, a__3[1] = "leftrepeat";
		    s_cat(ch__6, a__3, i__6, &c__2, 11L);
		    do_fio(&c__1, ch__6, 11L);
		    e_wsfe();
		    comask_1.fixednew += spfacs_1.rptfac * comask_1.wheadpt;
		} else if (bit_test(iirpt,6)) {
		    s_wsfe(&io___258);
/* Writing concatenation */
		    i__6[0] = 1, a__3[0] = all_1.sq;
		    i__6[1] = 11, a__3[1] = "rightrepeat";
		    s_cat(ch__2, a__3, i__6, &c__2, 12L);
		    do_fio(&c__1, ch__2, 12L);
		    e_wsfe();
		    comask_1.fixednew += spfacs_1.rptfac * comask_1.wheadpt;
		} else if (bit_test(iirpt,8)) {
		    s_wsfe(&io___259);
/* Writing concatenation */
		    i__6[0] = 1, a__3[0] = all_1.sq;
		    i__6[1] = 9, a__3[1] = "doublebar";
		    s_cat(ch__7, a__3, i__6, &c__2, 10L);
		    do_fio(&c__1, ch__7, 10L);
		    e_wsfe();
		} else {
		    s_wsle(&io___260);
		    do_lio(&c__9, &c__1, "Unexpected mid-bar repeat command \
R*", 36L);
		    e_wsle();
		    s_stop("1", 1L);
		}
		comask_1.scaldold -= comask_1.fbar;
	    }
	    if (bit_test(all_1.ipl[all_1.list[(istart[ib] << 2) - 3] * 7 - 7],
		    28)) {

/*  Internal signature change. */

/* Writing concatenation */
		i__6[0] = 1, a__3[0] = all_1.sq;
		i__6[1] = 17, a__3[1] = "generalsignature{";
		s_cat(notexq, a__3, i__6, &c__2, 79L);
		lnote = 18;
		if (comtop_1.isig < 0) {
/* Writing concatenation */
		    i__6[0] = lnote, a__3[0] = notexq;
		    i__6[1] = 1, a__3[1] = "-";
		    s_cat(notexq, a__3, i__6, &c__2, 79L);
		    ++lnote;
		}
		s_wsfe(&io___261);
/* Writing concatenation */
		i__4[0] = lnote, a__2[0] = notexq;
		*(unsigned char *)&ch__3[0] = abs(comtop_1.isig) + 48;
		i__4[1] = 1, a__2[1] = ch__3;
		i__4[2] = 2, a__2[2] = "}%";
		s_cat(ch__1, a__2, i__4, &c__3, 82L);
		do_fio(&c__1, ch__1, lnote + 3);
		e_wsfe();
		s_wsfe(&io___262);
/* Writing concatenation */
		i__3[0] = 1, a__1[0] = all_1.sq;
		i__3[1] = 14, a__1[1] = "zchangecontext";
		i__3[2] = 1, a__1[2] = all_1.sq;
		i__3[3] = 12, a__1[3] = "addspace{-.5";
		i__3[4] = 1, a__1[4] = all_1.sq;
		i__3[5] = 15, a__1[5] = "afterruleskip}%";
		s_cat(ch__8, a__1, i__3, &c__6, 44L);
		do_fio(&c__1, ch__8, 44L);
		e_wsfe();
		lnote = 0;
	    }
	}
	comnsp_1.xtupb4 = FALSE_;
	comnsp_1.flgndb = FALSE_;
	i__1 = all_1.nv;
	for (all_1.iv = 1; all_1.iv <= i__1; ++all_1.iv) {
	    i__5 = commvl_1.nvmx[all_1.iv - 1];
	    for (kv = 1; kv <= i__5; ++kv) {
		commvl_1.ivx = commvl_1.ivmx[all_1.iv + kv * 7 - 8];
		all_1.figcheck = all_1.figbass && commvl_1.ivx == 1 && 
			comfig_1.nfigs > 0;
		if (commvl_1.ivx > 1) {
		    if (commvl_1.ivx <= all_1.nv) {
			addstr_(all_1.sepsymq + (all_1.iv - 2), &c__1, soutq, 
				&lsout, 1L, 80L);
		    } else {
/* Writing concatenation */
			i__6[0] = 1, a__3[0] = all_1.sq;
			i__6[1] = 9, a__3[1] = "nextvoice";
			s_cat(ch__7, a__3, i__6, &c__2, 10L);
			addstr_(ch__7, &c__10, soutq, &lsout, 10L, 80L);
		    }
		}
		if (comhead_1.ihdht > 0 && commvl_1.ivx == all_1.nv) {

/*  Write header.  First adjust height if needed to miss b
arno. */

		    if (comask_1.bar1syst && all_1.iline != 1) {
			comhead_1.ihdht = comsln_1.irzbnd + 15 + 
				comsln_1.isnx;
		    }

/*  Add user-defined vertical shift */

		    comhead_1.ihdht += comhead_1.ihdvrt;
		    lchead = lc_(comhead_1.headrq, &c__80, 80L);
/* Writing concatenation */
		    i__6[0] = 1, a__3[0] = all_1.sq;
		    i__6[1] = 10, a__3[1] = "zcharnote{";
		    s_cat(notexq, a__3, i__6, &c__2, 79L);
		    s_wsfi(&io___264);
		    do_fio(&c__1, (char *)&comhead_1.ihdht, (ftnlen)sizeof(
			    integer));
		    e_wsfi();
/* Writing concatenation */
		    i__3[0] = 13, a__1[0] = notexq;
		    i__3[1] = 2, a__1[1] = "}{";
		    i__3[2] = 1, a__1[2] = all_1.sq;
		    i__3[3] = 7, a__1[3] = "bigfont";
		    i__3[4] = 1, a__1[4] = all_1.sq;
		    i__3[5] = 10, a__1[5] = "kern-30pt ";
		    s_cat(notexq, a__1, i__3, &c__6, 79L);
		    addstr_(notexq, &c__34, soutq, &lsout, 79L, 80L);
/* Writing concatenation */
		    i__6[0] = lchead, a__3[0] = comhead_1.headrq;
		    i__6[1] = 1, a__3[1] = "}";
		    s_cat(ch__9, a__3, i__6, &c__2, 81L);
		    i__7 = lchead + 1;
		    addstr_(ch__9, &i__7, soutq, &lsout, lchead + 1, 80L);
		    comhead_1.ihdht = 0;
		}
		if (comhead_1.lower && commvl_1.ivx == all_1.nv) {
		    lclow = lc_(comhead_1.lowerq, &c__80, 80L);
/* Writing concatenation */
		    i__9[0] = 1, a__5[0] = all_1.sq;
		    i__9[1] = 14, a__5[1] = "zcharnote{-6}{";
		    i__9[2] = 1, a__5[2] = all_1.sq;
		    i__9[3] = 5, a__5[3] = "tempo";
		    i__9[4] = 1, a__5[4] = all_1.sq;
		    i__9[5] = 10, a__5[5] = "kern-10pt ";
		    i__9[6] = lclow, a__5[6] = comhead_1.lowerq;
		    i__9[7] = 1, a__5[7] = "}";
		    s_cat(ch__10, a__5, i__9, &c__8, 113L);
		    i__7 = lclow + 33;
		    addstr_(ch__10, &i__7, soutq, &lsout, lclow + 33, 80L);
		    comhead_1.lower = FALSE_;
		}
		if (numblx > 0) {
		    if ((r__1 = comxtup_1.xtupfac[commvl_1.ivx - 1] - (float)
			    1., dabs(r__1)) > (float).005) {
/* Writing concatenation */
			i__6[0] = 1, a__3[0] = all_1.sq;
			i__6[1] = 17, a__3[1] = "multnoteskip{    ";
			s_cat(notexq, a__3, i__6, &c__2, 79L);
			if (comxtup_1.xtupfac[commvl_1.ivx - 1] >= (float)
				.995) {
			    s_wsfi(&io___266);
			    do_fio(&c__1, (char *)&comxtup_1.xtupfac[
				    commvl_1.ivx - 1], (ftnlen)sizeof(real));
			    e_wsfi();
			} else {
			    s_wsfi(&io___267);
			    do_fio(&c__1, "0", 1L);
			    do_fio(&c__1, (char *)&comxtup_1.xtupfac[
				    commvl_1.ivx - 1], (ftnlen)sizeof(real));
			    e_wsfi();
			}
/* Writing concatenation */
			i__6[0] = 18, a__3[0] = notexq;
			i__6[1] = 1, a__3[1] = "}";
			s_cat(ch__11, a__3, i__6, &c__2, 19L);
			addstr_(ch__11, &c__19, soutq, &lsout, 19L, 80L);
		    }
		    if (comxtup_1.inxtup && hang && ! comxtup_1.vxtup[
			    commvl_1.ivx - 1]) {
/* Writing concatenation */
			i__6[0] = 1, a__3[0] = all_1.sq;
			i__6[1] = 2, a__3[1] = "sk";
			s_cat(ch__12, a__3, i__6, &c__2, 3L);
			addstr_(ch__12, &c__3, soutq, &lsout, 3L, 80L);
		    }
		}
		itnow = itstart[ib];
		nofirst = TRUE_;
		i__7 = istop[ib];
		for (all_1.jn = istart[ib]; all_1.jn <= i__7; ++all_1.jn) {
		    if (all_1.list[(all_1.jn << 2) - 4] != commvl_1.ivx) {
			goto L10;
		    }
		    ip = all_1.list[(all_1.jn << 2) - 3];
		    if (nofirst) {
			comoct_1.noctup = 0;
			if (ncmid_(&all_1.iv, &ip) == 23) {
			    comoct_1.noctup = -2;
			}
			nofirst = FALSE_;
		    }

/*  Check for internal floating figure (before last note o
f group). */

L12:
		    if (all_1.figcheck && comfig_1.itfig[ifig - 1] < itnow) {

/*  Bypassed figure location. Backup, place fig, retur
n. */

			offnsk = (real) (itnow - comfig_1.itfig[ifig - 1]) / 
				comnsp_1.nspace[ib - 1];
			putfig_(&ifig, &offnsk, &all_1.figcheck, soutq, &
				lsout, 80L);
			goto L12;
		    }

/*  Put in \sk if needed */

		    if (all_1.list[(all_1.jn << 2) - 2] > itnow) {
/* Writing concatenation */
			i__6[0] = 1, a__3[0] = all_1.sq;
			i__6[1] = 2, a__3[1] = "sk";
			s_cat(ch__12, a__3, i__6, &c__2, 3L);
			addstr_(ch__12, &c__3, soutq, &lsout, 3L, 80L);
			itnow += comnsp_1.nspace[ib - 1];
			goto L12;
		    }

/*  Check for user-defined shifts */

		    if (bit_test(all_1.irest[commvl_1.ivx + ip * 7 - 8],15) ||
			     bit_test(all_1.irest[commvl_1.ivx + ip * 7 - 8],
			    16)) {
			putshft_(&commvl_1.ivx, &c_true, soutq, &lsout, 80L);
		    }
L21:
		    if (iaskb[commvl_1.ivx - 1] <= comas1_1.naskb && itnow >= 
			    comas1_1.itask[iaskb[commvl_1.ivx - 1] - 1]) {
			if (comas1_1.itask[iaskb[commvl_1.ivx - 1] - 1] >= 
				itstart[ib]) {

/*  Insert placeholder for accidental skip */

/* Writing concatenation */
			    i__6[0] = 1, a__3[0] = all_1.sq;
			    i__6[1] = 8, a__3[1] = "ask     ";
			    s_cat(ch__13, a__3, i__6, &c__2, 9L);
			    addstr_(ch__13, &c__9, soutq, &lsout, 9L, 80L);
			    ++comas2_1.nasksys;
			    comas2_1.wasksys[comas2_1.nasksys - 1] = 
				    comas1_1.wask[iaskb[commvl_1.ivx - 1] - 1]
				    ;
			    if (comas1_1.wask[iaskb[commvl_1.ivx - 1] - 1] > (
				    float)0.) {
				comas2_1.elasksys[comas2_1.nasksys - 1] = 
					comas1_1.elask[iaskb[commvl_1.ivx - 1]
					 - 1];
			    } else {

/* This is a signal to permit negative ask's. 
 Should really have elask>=0.*/

				comas2_1.elasksys[comas2_1.nasksys - 1] = 
					-comas1_1.elask[iaskb[commvl_1.ivx - 
					1] - 1];
			    }
			}

/*  May have skipped some itask's in earlier blocks (d
ue to void voice) */

			++iaskb[commvl_1.ivx - 1];
			goto L21;
		    }
/* L22: */
		    if (comas1_1.iasxb <= comas1_1.nasxb && ip == 
			    comas1_1.ipasx[comas1_1.iasxb - 1] && 
			    commvl_1.ivx == comas1_1.ivasx[comas1_1.iasxb - 1]
			    ) {
/* Writing concatenation */
			i__6[0] = 1, a__3[0] = all_1.sq;
			i__6[1] = 8, a__3[1] = "asx     ";
			s_cat(ch__13, a__3, i__6, &c__2, 9L);
			addstr_(ch__13, &c__9, soutq, &lsout, 9L, 80L);
			++comas2_1.nasxsys;
			comas2_1.wasxsys[comas2_1.nasxsys - 1] = 
				comas1_1.wasx[comas1_1.iasxb - 1];
			comas2_1.elasxsys[comas2_1.nasxsys - 1] = 
				comas1_1.elasx[comas1_1.iasxb - 1];
			++comas1_1.iasxb;
		    }
		    if (all_1.figcheck && comfig_1.itfig[ifig - 1] == itnow) {

/*  Figure on a note.  NB: later special check for lat
e figs. */

			putfig_(&ifig, &c_b159, &all_1.figcheck, soutq, &
				lsout, 80L);
		    }

/*  Check for new clef here. */

		    if (isclef && bit_test(all_1.islur[commvl_1.ivx + ip * 7 
			    - 8],11)) {
/*     print*,'At clef insertion, ptclef:',ptclef(iv) 
*/
			if (ptclef[all_1.iv - 1] > (float)0.) {
/* Writing concatenation */
			    i__6[0] = 1, a__3[0] = all_1.sq;
			    i__6[1] = 5, a__3[1] = "off{-";
			    s_cat(notexq, a__3, i__6, &c__2, 79L);
			    if (ptclef[all_1.iv - 1] < (float)9.95) {
				s_wsfi(&io___271);
				do_fio(&c__1, (char *)&ptclef[all_1.iv - 1], (
					ftnlen)sizeof(real));
				e_wsfi();
				lnote = 9;
			    } else {
				s_wsfi(&io___272);
				do_fio(&c__1, (char *)&ptclef[all_1.iv - 1], (
					ftnlen)sizeof(real));
				e_wsfi();
				lnote = 10;
			    }
/* Writing concatenation */
			    i__6[0] = lnote, a__3[0] = notexq;
			    i__6[1] = 3, a__3[1] = "pt}";
			    s_cat(notexq, a__3, i__6, &c__2, 79L);
			    lnote += 3;
			    addstr_(notexq, &lnote, soutq, &lsout, 79L, 80L);
/*     print*,'Just added: ',notexq(1:lnote) */
			}
			clefsym_(&all_1.islur[all_1.iv + ip * 7 - 8], notexq, 
				&lnote, &nclef, 79L);
			addstr_(notexq, &lnote, soutq, &lsout, 79L, 80L);
			if (ptclef[all_1.iv - 1] > (float)0.) {
/* Writing concatenation */
			    i__6[0] = 1, a__3[0] = all_1.sq;
			    i__6[1] = 4, a__3[1] = "off{";
			    s_cat(notexq, a__3, i__6, &c__2, 79L);
			    if (ptclef[all_1.iv - 1] < (float)9.95) {
				s_wsfi(&io___274);
				do_fio(&c__1, (char *)&ptclef[all_1.iv - 1], (
					ftnlen)sizeof(real));
				e_wsfi();
				lnote = 8;
			    } else {
				s_wsfi(&io___275);
				do_fio(&c__1, (char *)&ptclef[all_1.iv - 1], (
					ftnlen)sizeof(real));
				e_wsfi();
				lnote = 9;
			    }
/* Writing concatenation */
			    i__6[0] = lnote, a__3[0] = notexq;
			    i__6[1] = 3, a__3[1] = "pt}";
			    s_cat(notexq, a__3, i__6, &c__2, 79L);
			    lnote += 3;
			    addstr_(notexq, &lnote, soutq, &lsout, 79L, 80L);
/*     print*,'Just added: ',notexq(1:lnote) */
			}
		    }

/*  Checking for literal TeX string BEFORE starting beams!
! */

		    if (bit_test(all_1.islur[commvl_1.ivx + ip * 7 - 8],16)) {
			i__10 = comgrace_1.nlit;
			for (il = 1; il <= i__10; ++il) {
			    if (comgrace_1.iplit[il - 1] == ip && 
				    comgrace_1.ivlit[il - 1] == commvl_1.ivx) 
				    {
				goto L125;
			    }
/* L124: */
			}
			s_wsle(&io___277);
			do_lio(&c__9, &c__1, "Problem finding index for lite\
ral string", 40L);
			e_wsle();
			s_stop("", 0L);
L125:

/*  Write a type 1 tex string. */

			if (comgrace_1.lenlit[il - 1] < 71) {

/*  Add normally */

			    addstr_(comgrace_1.litq + (il - 1 << 7), &
				    comgrace_1.lenlit[il - 1], soutq, &lsout, 
				    128L, 80L);
			} else {

/*  Longer than 71.  Write souq, Write string, sta
rt new soutq. */

			    s_wsfe(&io___278);
/* Writing concatenation */
			    i__6[0] = lsout, a__3[0] = soutq;
			    i__6[1] = 1, a__3[1] = "%";
			    s_cat(ch__9, a__3, i__6, &c__2, 81L);
			    do_fio(&c__1, ch__9, lsout + 1);
			    e_wsfe();
			    s_wsfe(&io___279);
/* Writing concatenation */
			    i__6[0] = comgrace_1.lenlit[il - 1], a__3[0] = 
				    comgrace_1.litq + (il - 1 << 7);
			    i__6[1] = 1, a__3[1] = "%";
			    s_cat(ch__14, a__3, i__6, &c__2, 129L);
			    do_fio(&c__1, ch__14, comgrace_1.lenlit[il - 1] + 
				    1);
			    e_wsfe();
			    lsout = 0;
			}
		    }

/*  Arpeggio on a main (non-chordal) note? */

		    if (bit_test(all_1.iornq[commvl_1.ivx + ip * 7 - 8],27)) {
			i__10 = ncmid_(&all_1.iv, &ip);
			putarp_(&itnow, &all_1.iv, &all_1.nolev[commvl_1.ivx 
				+ ip * 7 - 8], &i__10, soutq, &lsout, 80L);
		    }

/*  See if a beam starts here */

		    if (numbms[commvl_1.ivx] > 0 && all_1.ibmcnt[commvl_1.ivx 
			    - 1] <= numbms[commvl_1.ivx] && all_1.ibm1[
			    commvl_1.ivx + all_1.ibmcnt[commvl_1.ivx - 1] * 7 
			    - 8] == ip) {
			if (! bit_test(all_1.irest[commvl_1.ivx + ip * 7 - 8],
				24)) {

/*  Not a jump start */

			    beamstrt_(notexq, &lnote, nornb, ihornb, 79L);

/*  Shift beam start if necessary */

			    if (bit_test(all_1.ipl[commvl_1.ivx + ip * 7 - 8],
				    8)) {
/* Writing concatenation */
				i__6[0] = 1, a__3[0] = all_1.sq;
				i__6[1] = 5, a__3[1] = "loff{";
				s_cat(ch__15, a__3, i__6, &c__2, 6L);
				addstr_(ch__15, &c__6, soutq, &lsout, 6L, 80L)
					;
			    }
			    if (bit_test(all_1.ipl[commvl_1.ivx + ip * 7 - 8],
				    9)) {
/* Writing concatenation */
				i__6[0] = 1, a__3[0] = all_1.sq;
				i__6[1] = 5, a__3[1] = "roff{";
				s_cat(ch__15, a__3, i__6, &c__2, 6L);
				addstr_(ch__15, &c__6, soutq, &lsout, 6L, 80L)
					;
			    }
			    addstr_(notexq, &lnote, soutq, &lsout, 79L, 80L);
			    if (bit_test(all_1.ipl[commvl_1.ivx + ip * 7 - 8],
				    8) || bit_test(all_1.ipl[commvl_1.ivx + 
				    ip * 7 - 8],9)) {
				addstr_("}", &c__1, soutq, &lsout, 1L, 80L);
			    }
			}
			all_1.beamon[commvl_1.ivx - 1] = TRUE_;
			bspend = TRUE_;
		    }

/*  Setup for chords and possible slurs in chords */

		    if (bit_test(all_1.ipl[commvl_1.ivx + ip * 7 - 8],10)) {
			precrd_(&commvl_1.ivx, &ip, &all_1.nolev[commvl_1.ivx 
				+ ip * 7 - 8]);
		    }

/*  Is there slur or grace activity? */

		    isgrace = bit_test(all_1.islur[commvl_1.ivx + ip * 7 - 8],
			    4);
		    if (ip > 1) {
			isgrace = isgrace || bit_test(all_1.ipl[commvl_1.ivx 
				+ (ip - 1) * 7 - 8],31);
		    }

/*  isgrace if not 1st note in bar and previous note has W
ay-after grace. */

		    if (bit_test(all_1.islur[commvl_1.ivx + ip * 7 - 8],0) || 
			    isgrace) {
			if (bit_test(all_1.islur[commvl_1.ivx + ip * 7 - 8],0)
				) {
			    i__10 = ncmid_(&all_1.iv, &ip);
			    doslur_(&all_1.nolev[commvl_1.ivx + ip * 7 - 8], 
				    all_1.isdat1, all_1.isdat2, &all_1.nsdat, 
				    &ip, &all_1.iv, &all_1.nv, &all_1.beamon[
				    commvl_1.ivx - 1], &i__10, soutq, &lsout, 
				    all_1.ulq + (commvl_1.ivx + all_1.ibmcnt[
				    commvl_1.ivx - 1] * 7 - 8), &all_1.islur[
				    commvl_1.ivx + ip * 7 - 8], &all_1.ipl[
				    commvl_1.ivx + ip * 7 - 8], &all_1.iornq[
				    commvl_1.ivx + ip * 7 - 8], &islhgt, 80L, 
				    1L);
			}
			if (isgrace) {

/* Grace note. */

			    iphold = ip;
			    isgrace = FALSE_;
			    if (ip > 1) {
				isgrace = bit_test(all_1.ipl[commvl_1.ivx + (
					ip - 1) * 7 - 8],31);
			    }
			    if (isgrace) {
				--iphold;
			    }
			    isgrace = isgrace || ! bit_test(all_1.ipl[
				    commvl_1.ivx + ip * 7 - 8],31) && ! 
				    bit_test(all_1.ipl[commvl_1.ivx + ip * 7 
				    - 8],29);

/*Place grace now if (a) Way-after from prev note 
and ip>1 or (b) Pre-grace*/
/*  on current note.  Do A-grace on current note, 
and W-grace at barend, later.*/

			    if (isgrace) {
				i__10 = ncmid_(&all_1.iv, &ip);
				dograce_(&commvl_1.ivx, &iphold, ptgr, soutq, 
					&lsout, &i__10, all_1.accq + (
					commvl_1.ivx + ip * 7 - 8), &ig, &
					all_1.ipl[commvl_1.ivx + iphold * 7 - 
					8], &c_false, 80L, 1L);
				if (comgrace_1.slurg[ig - 1]) {

/* Terminate slur started in dograce.  Get
 direction of main note stem */

				    if (! all_1.beamon[commvl_1.ivx - 1]) {

/*  Separate note.  Get stem direction
. */

					i__10 = ncmid_(&all_1.iv, &ip);
					udqq_(ch__3, 1L, &all_1.nolev[
						commvl_1.ivx + ip * 7 - 8], &
						i__10, &all_1.islur[
						commvl_1.ivx + ip * 7 - 8], &
						commvl_1.nvmx[all_1.iv - 1], &
						commvl_1.ivx, &all_1.nv);
					stemup = *(unsigned char *)&ch__3[0] 
						== 'u';
				    } else {

/*  In a beam */

					stemup = *(unsigned char *)&all_1.ulq[
						commvl_1.ivx + all_1.ibmcnt[
						commvl_1.ivx - 1] * 7 - 8] == 
						'u';
				    }
				    L__1 = ! comgrace_1.upg[ig - 1];
				    i__10 = ncmid_(&all_1.iv, &ip);
				    endslur_(&stemup, &L__1, &all_1.nolev[
					    commvl_1.ivx + ip * 7 - 8], &c__0,
					     &comslur_1.ndxslur, &c__0, &
					    i__10, soutq, &lsout, 80L);
				}
			    }
			}
			if (bit_test(all_1.iornq[commvl_1.ivx + ip * 7 - 8],
				24)) {

/*  Start slur on main note for After- or Way-afte
r-grace. */

			    i__10 = 511 - comslur_1.listslur;
			    comslur_1.ndxslur = log2_(&i__10);

/*  Get note name */

			    i__10 = ncmid_(&all_1.iv, &ip);
			    notefq_(noteq, &lnoten, &all_1.nolev[commvl_1.ivx 
				    + ip * 7 - 8], &i__10, 8L);

/*  Get slur direction */

			    *(unsigned char *)slurudq = 'u';
			    if (! all_1.beamon[commvl_1.ivx - 1]) {
				i__10 = ncmid_(&all_1.iv, &ip);
				udqq_(ch__3, 1L, &all_1.nolev[commvl_1.ivx + 
					ip * 7 - 8], &i__10, &all_1.islur[
					commvl_1.ivx + ip * 7 - 8], &
					commvl_1.nvmx[all_1.iv - 1], &
					commvl_1.ivx, &all_1.nv);
				if (*(unsigned char *)&ch__3[0] == 'u') {
				    *(unsigned char *)slurudq = 'd';
				}
			    } else {
				if (*(unsigned char *)&all_1.ulq[commvl_1.ivx 
					+ all_1.ibmcnt[commvl_1.ivx - 1] * 7 
					- 8] == 'u') {
				    *(unsigned char *)slurudq = 'd';
				}
			    }
/* Writing concatenation */
			    i__11[0] = 1, a__6[0] = all_1.sq;
			    i__11[1] = 5, a__6[1] = "islur";
			    i__11[2] = 1, a__6[2] = slurudq;
			    *(unsigned char *)&ch__3[0] = comslur_1.ndxslur + 
				    48;
			    i__11[3] = 1, a__6[3] = ch__3;
			    i__11[4] = lnoten, a__6[4] = noteq;
			    s_cat(notexq, a__6, i__11, &c__5, 79L);
			    i__10 = lnoten + 8;
			    addstr_(notexq, &i__10, soutq, &lsout, 79L, 80L);
			    setbits_(&all_1.ipl[commvl_1.ivx + ip * 7 - 8], &
				    c__4, &c__23, &comslur_1.ndxslur);
			    if (bit_test(all_1.ipl[commvl_1.ivx + ip * 7 - 8],
				    31)) {
				comslur_1.listslur = bit_set(
					comslur_1.listslur,comslur_1.ndxslur);
			    }

/*  Starting slur on W-grace on THIS note.  Record
 ndxslur. */

			}
		    }

/* Check for chord notes.  Moved up from below, 10/27/96 s
o chord orns done 1st.*/

		    if (bit_test(all_1.ipl[commvl_1.ivx + ip * 7 - 8],10)) {

/*  Need a duration to set type of note head */

			if (! comxtup_1.vxtup[commvl_1.ivx - 1]) {
			    nodu = all_1.nodur[commvl_1.ivx + ip * 7 - 8];
			} else if (all_1.mult[commvl_1.ivx + ip * 7 - 8] < 0) 
				{
			    nodu = 32;
			} else {
			    nodu = 16;
			}
			i__10 = ncmid_(&all_1.iv, &ip);
			docrd_(&commvl_1.ivx, &ip, &nodu, &i__10, &all_1.iv, &
				itnow, soutq, &lsout, all_1.ulq, &
				all_1.ibmcnt[commvl_1.ivx - 1], &all_1.islur[
				commvl_1.ivx + ip * 7 - 8], &commvl_1.nvmx[
				all_1.iv - 1], &all_1.nv, &all_1.beamon[
				commvl_1.ivx - 1], &all_1.nolev[commvl_1.ivx 
				+ ip * 7 - 8], ihornb, nornb, &all_1.stemlen, 
				80L, 1L);
		    }

/* Check for main-note ornaments. ')' on dotted notes go i
n with note, not here.*/
/*  Bits 0-13: (stmgx+Tupf._) ; 14: Down fermata, was F */
/*  15: Trill w/o "tr", was U , 16-18 edit. accid., 19-21 
TBD */

		    isacc = (all_1.iornq[commvl_1.ivx + ip * 7 - 8] & 4194287)
			     > 0;

/*  isacc=.true. if any ornament except segno */

		    if (bit_test(all_1.iornq[commvl_1.ivx + ip * 7 - 8],13) &&
			     all_1.nodur[commvl_1.ivx + ip * 7 - 8] > 0) {

/* If ).  is only ornament, bypass.  If with others, t
emporarirly zero the bit.*/

			i__10 = log2_(&all_1.nodur[commvl_1.ivx + ip * 7 - 8])
				;
			if (pow_ii(&c__2, &i__10) != all_1.nodur[commvl_1.ivx 
				+ ip * 7 - 8]) {
			    if ((all_1.iornq[commvl_1.ivx + ip * 7 - 8] & 
				    516079) == 0) {

/*  ). is the only non-segno ornament */

				isacc = FALSE_;
			    } else {

/*  There are other ornaments in addition */

				rpndot = TRUE_;
				all_1.iornq[commvl_1.ivx + ip * 7 - 8] = 
					bit_clear(all_1.iornq[commvl_1.ivx + 
					ip * 7 - 8],13);
			    }
			}
		    }
		    if (isacc && ! cwrferm[commvl_1.ivx - 1]) {

/*  Check for centered whole-bar rest with fermata (bi
ts 10 or 14). */

			if ((all_1.iornq[commvl_1.ivx + ip * 7 - 8] & 17408) 
				> 0 && bit_test(all_1.irest[commvl_1.ivx + ip 
				* 7 - 8],0) && all_1.nodur[commvl_1.ivx + ip *
				 7 - 8] == all_1.lenbar && ! (all_1.firstgulp 
				&& all_1.ibar == 1 && all_1.lenb0 > 0)) {
			    cwrferm[commvl_1.ivx - 1] = TRUE_;
			    goto L30;
			}
			i__10 = ncmid_(&all_1.iv, &ip);
			L__1 = bit_test(all_1.ipl[commvl_1.ivx + ip * 7 - 8],
				10);
			putorn_(&all_1.iornq[commvl_1.ivx + ip * 7 - 8], &
				all_1.nolev[commvl_1.ivx + ip * 7 - 8], &
				all_1.nolev[commvl_1.ivx + ip * 7 - 8], &
				all_1.nodur[commvl_1.ivx + ip * 7 - 8], nornb,
				 all_1.ulq, &all_1.ibmcnt[commvl_1.ivx - 1], &
				commvl_1.ivx, &i__10, &all_1.islur[
				commvl_1.ivx + ip * 7 - 8], &commvl_1.nvmx[
				all_1.iv - 1], &all_1.nv, ihornb, &
				all_1.stemlen, notexq, &lnote, &ip, &islhgt, &
				all_1.beamon[commvl_1.ivx - 1], &L__1, 1L, 
				79L);
			addstr_(notexq, &lnote, soutq, &lsout, 79L, 80L);
		    }
		    if (rpndot) {
			all_1.iornq[commvl_1.ivx + ip * 7 - 8] = bit_set(
				all_1.iornq[commvl_1.ivx + ip * 7 - 8],13);
			rpndot = FALSE_;
		    }
L30:

/*  Accidentals */
/* May have 'X' on main note if chord note has accid.  Was
 set in \ask-checks.*/

		    if (i_indx("xX", all_1.accq + (commvl_1.ivx + ip * 7 - 8),
			     2L, 1L) == 0) {
			if ((all_1.ipl[commvl_1.ivx + ip * 7 - 8] & 768) > 0) 
				{

/* Main note shifted, so shift accid.  Remeber to 
terminate when accid is done.*/

			    if (bit_test(all_1.ipl[commvl_1.ivx + ip * 7 - 8],
				    8)) {
/* Writing concatenation */
				i__4[0] = 1, a__2[0] = all_1.sq;
				i__4[1] = 5, a__2[1] = "loff{";
				i__4[2] = 1, a__2[2] = all_1.sq;
				s_cat(notexq, a__2, i__4, &c__3, 79L);
			    } else {
/* Writing concatenation */
				i__4[0] = 1, a__2[0] = all_1.sq;
				i__4[1] = 5, a__2[1] = "roff{";
				i__4[2] = 1, a__2[2] = all_1.sq;
				s_cat(notexq, a__2, i__4, &c__3, 79L);
			    }
			    lnote = 7;
			} else {
			    s_copy(notexq, all_1.sq, 79L, 1L);
			    lnote = 1;
			}
			if (*(unsigned char *)&all_1.accq[commvl_1.ivx + ip * 
				7 - 8] <= 90) {
/* Writing concatenation */
			    i__6[0] = lnote, a__3[0] = notexq;
			    i__6[1] = 3, a__3[1] = "big";
			    s_cat(notexq, a__3, i__6, &c__2, 79L);
			    lnote += 3;
			}
			accsym_(all_1.accq + (commvl_1.ivx + ip * 7 - 8), 
				acsymq, &lacc, 1L, 3L);
/* Writing concatenation */
			i__6[0] = lnote, a__3[0] = notexq;
			i__6[1] = lacc, a__3[1] = acsymq;
			s_cat(notexq, a__3, i__6, &c__2, 79L);
			lnote += lacc;
			i__10 = ncmid_(&all_1.iv, &ip);
			notefq_(noteq, &lnoten, &all_1.nolev[commvl_1.ivx + 
				ip * 7 - 8], &i__10, 8L);
			if (lnoten == 1) {
			    addblank_(noteq, &lnoten, 8L);
			}
/* Writing concatenation */
			i__6[0] = lnote, a__3[0] = notexq;
			i__6[1] = lnoten, a__3[1] = noteq;
			s_cat(notexq, a__3, i__6, &c__2, 79L);
			lnote += lnoten;
			if ((all_1.ipl[commvl_1.ivx + ip * 7 - 8] & 768) > 0) 
				{

/*  Terminate shift */

/* Writing concatenation */
			    i__6[0] = lnote, a__3[0] = notexq;
			    i__6[1] = 1, a__3[1] = "}";
			    s_cat(notexq, a__3, i__6, &c__2, 79L);
			    ++lnote;
			}
			addstr_(notexq, &lnote, soutq, &lsout, 79L, 80L);
		    }

/*  Lower dot for lower-voice notes.  Conditions are: */
/*   1. Dotted time value */
/*   2. Lower voice of two */
/*   3. Note is on a line */
/*   4. Not a rest */
/* .  5. Flag (lowdot) is set to true */

		    if (comarp_1.lowdot && commvl_1.nvmx[all_1.iv - 1] == 2 &&
			     commvl_1.ivx <= all_1.nv) {
			i__10 = log2_(&all_1.nodur[commvl_1.ivx + ip * 7 - 8])
				;
			if (! bit_test(all_1.irest[commvl_1.ivx + ip * 7 - 8],
				0) && pow_ii(&c__2, &i__10) != all_1.nodur[
				commvl_1.ivx + ip * 7 - 8] && (all_1.nolev[
				commvl_1.ivx + ip * 7 - 8] - ncmid_(&
				commvl_1.ivx, &ip)) % 2 == 0) {
			    if (bit_test(all_1.irest[commvl_1.ivx + ip * 7 - 
				    8],19)) {

/*  Note already in movdot list.  Drop by 2. 
*/

				comcc_1.updot[commvl_1.ivx + (comcc_1.ndotmv[
					commvl_1.ivx - 1] + 1) * 7 - 8] += (
					float)-2.;
			    } else {

/*  Not in list so just move it right now */

				dotmov_(&c_b792, &c_b159, soutq, &lsout, 80L);
			    }
			}
		    }

/*  Check for dotted notes with moved dots */

		    if (bit_test(all_1.irest[commvl_1.ivx + ip * 7 - 8],19)) {
			++comcc_1.ndotmv[commvl_1.ivx - 1];
			dotmov_(&comcc_1.updot[commvl_1.ivx + comcc_1.ndotmv[
				commvl_1.ivx - 1] * 7 - 8], &comcc_1.rtdot[
				commvl_1.ivx + comcc_1.ndotmv[commvl_1.ivx - 
				1] * 7 - 8], soutq, &lsout, 80L);
		    }

/*  Zero out slur-height marker for raising ornaments */

		    islhgt = 0;

/*  Now start with spacing notes.  Is a beam start pending
? */

		    if (bspend && all_1.ibm2[commvl_1.ivx + all_1.ibmcnt[
			    commvl_1.ivx - 1] * 7 - 8] > all_1.ibm1[
			    commvl_1.ivx + all_1.ibmcnt[commvl_1.ivx - 1] * 7 
			    - 8]) {
			beamn1_(notexq, &lnote, 79L);
			bspend = FALSE_;

/*  Is a beam ending? */

		    } else if (numbms[commvl_1.ivx] > 0 && all_1.ibmcnt[
			    commvl_1.ivx - 1] <= numbms[commvl_1.ivx] && 
			    all_1.ibm2[commvl_1.ivx + all_1.ibmcnt[
			    commvl_1.ivx - 1] * 7 - 8] == ip) {
			if (bspend) {

/*  Must be a single-note ending of a jump-beam */

			    combjmp_1.isbjmp = TRUE_;
			    bspend = FALSE_;
			}
			beamend_(notexq, &lnote, 79L);

/*  If this is an xtuplet that stretches >1 block, mus
t backspace. */

			if (numblx > 1) {
			    addstr_(notexq, &lnote, soutq, &lsout, 79L, 80L);
/* Writing concatenation */
			    i__6[0] = 1, a__3[0] = all_1.sq;
			    i__6[1] = 7, a__3[1] = "off{-  ";
			    s_cat(notexq, a__3, i__6, &c__2, 79L);
			    if (comxtup_1.ntupv[commvl_1.ivx - 1] <= 9) {
				s_wsfi(&io___290);
				do_fio(&c__1, (char *)&comxtup_1.ntupv[
					commvl_1.ivx - 1], (ftnlen)sizeof(
					integer));
				e_wsfi();
/* Writing concatenation */
				i__4[0] = 7, a__2[0] = notexq;
				i__4[1] = 1, a__2[1] = all_1.sq;
				i__4[2] = 9, a__2[2] = "noteskip}";
				s_cat(notexq, a__2, i__4, &c__3, 79L);
				lnote = 17;
			    } else {
				s_wsfi(&io___291);
				do_fio(&c__1, (char *)&comxtup_1.ntupv[
					commvl_1.ivx - 1], (ftnlen)sizeof(
					integer));
				e_wsfi();
/* Writing concatenation */
				i__4[0] = 8, a__2[0] = notexq;
				i__4[1] = 1, a__2[1] = all_1.sq;
				i__4[2] = 9, a__2[2] = "noteskip}";
				s_cat(notexq, a__2, i__4, &c__3, 79L);
				lnote = 18;
			    }
			}
			nornb[commvl_1.ivx - 1] = 0;
			++all_1.ibmcnt[commvl_1.ivx - 1];
			all_1.beamon[commvl_1.ivx - 1] = FALSE_;

/*  Or if we're in the middle of a beam */

		    } else if (numbms[commvl_1.ivx] > 0 && all_1.beamon[
			    commvl_1.ivx - 1]) {
			beamid_(notexq, &lnote, 79L);

/*      Or whole-bar rest */

		    } else if (bit_test(all_1.irest[commvl_1.ivx + ip * 7 - 8]
			    ,0) && all_1.nodur[commvl_1.ivx + ip * 7 - 8] == 
			    all_1.lenbar && ! (all_1.firstgulp && all_1.ibar 
			    == 1 && all_1.lenb0 > 0) && ! bit_test(
			    all_1.islur[commvl_1.ivx + ip * 7 - 8],29)) {

/*  Rule out pickup bar, blank rests.  Remember that i
slur b19=> rp */

			cwrest[commvl_1.ivx] = TRUE_;
			notex_(cwrq, &lcwr, 79L);
			itnow += all_1.lenbar;
			goto L10;
		    } else {

/*  Write a separate note */

			notex_(notexq, &lnote, 79L);
		    }

/*  Right offset?  This may cause trouble */

		    if (bit_test(all_1.ipl[commvl_1.ivx + ip * 7 - 8],8)) {
/* Writing concatenation */
			i__6[0] = 1, a__3[0] = all_1.sq;
			i__6[1] = 5, a__3[1] = "loff{";
			s_cat(ch__15, a__3, i__6, &c__2, 6L);
			addstr_(ch__15, &c__6, soutq, &lsout, 6L, 80L);
		    }
		    if (bit_test(all_1.ipl[commvl_1.ivx + ip * 7 - 8],9)) {
/* Writing concatenation */
			i__6[0] = 1, a__3[0] = all_1.sq;
			i__6[1] = 5, a__3[1] = "roff{";
			s_cat(ch__15, a__3, i__6, &c__2, 6L);
			addstr_(ch__15, &c__6, soutq, &lsout, 6L, 80L);
		    }
		    addstr_(notexq, &lnote, soutq, &lsout, 79L, 80L);
		    if (bit_test(all_1.ipl[commvl_1.ivx + ip * 7 - 8],8) || 
			    bit_test(all_1.ipl[commvl_1.ivx + ip * 7 - 8],9)) 
			    {
			addstr_("}", &c__1, soutq, &lsout, 1L, 80L);
		    }

/*  Terminate user-defined offsets.  Fix format */

		    if (bit_test(all_1.irest[commvl_1.ivx + ip * 7 - 8],15) ||
			     bit_test(all_1.irest[commvl_1.ivx + ip * 7 - 8],
			    17)) {
			putshft_(&commvl_1.ivx, &c_false, soutq, &lsout, 80L);
		    }

/* Deal with After- and Way-after-graces.  First, if end o
f bar, compute space*/
/*   needed since it wasn't done during general ask-checks
. If extra space is*/
/*   rq'd, convert GW to GA.  Therefore GW at end of bar n
ever needs extra sp.*/
/*    But will still need to add extra space as hardspace.
 */

		    if (ip == all_1.nn[commvl_1.ivx - 1] && (bit_test(
			    all_1.ipl[commvl_1.ivx + ip * 7 - 8],31) || 
			    bit_test(all_1.ipl[commvl_1.ivx + ip * 7 - 8],29))
			    ) {
			i__10 = comgrace_1.ngrace;
			for (ig = 1; ig <= i__10; ++ig) {
			    if (comgrace_1.ipg[ig - 1] == ip && 
				    comgrace_1.ivg[ig - 1] == commvl_1.ivx) {
				goto L78;
			    }
/* L77: */
			}
			s_wsle(&io___294);
			do_lio(&c__9, &c__1, "Problem finding grace index \
at \"do 77\"", 38L);
			e_wsle();
			s_stop("1", 1L);
L78:

/*  Get elemskip to end of bar.  WON'T WORK IF XTUPS !
! */

			esk = (float)0.;
			i__10 = comnsp_1.nb;
			for (iib = ib; iib <= i__10; ++iib) {
			    if (iib == ib) {
				itleft = all_1.list[((255 & all_1.ipl[
					commvl_1.ivx + ip * 7 - 8]) << 2) - 2]
					;
			    } else {
				itleft = itstart[ib];
			    }
			    if (iib < comnsp_1.nb) {
				itright = itstart[iib + 1];
			    } else {
				itright = all_1.lenbar;
			    }
			    r__1 = (real) comnsp_1.nspace[ib - 1];
			    esk += feon_(&r__1) * (itright - itleft) / 
				    comnsp_1.nspace[ib - 1];
/* L40: */
			}
			ptsavail = comask_1.poenom * esk - comask_1.wheadpt;
			if (comgrace_1.nng[ig - 1] == 1) {
			    wgr = spfacs_1.grafac;
			} else {
			    wgr = comgrace_1.nng[ig - 1] * spfacs_1.emgfac;
			    i__10 = comgrace_1.nng[ig - 1];
			    for (ing = 1; ing <= i__10; ++ing) {
				if (*(unsigned char *)&comgrace_1.accgq[
					comgrace_1.ngstrt[ig - 1] - 1 + ing - 
					1] != 'x') {
				    wgr += spfacs_1.acgfac;
				}
/* L41: */
			    }
			}
			ptgr[ig - 1] = wgr * comask_1.wheadpt;
/*             ptsneed = (wgr+xb4fac)*wheadpt */
			ptsneed = (wgr + (float).5) * comask_1.wheadpt;
			ptsndg[commvl_1.ivx - 1] = (float)0.;
			if (ptsavail < ptsneed) {
			    ptsndg[commvl_1.ivx - 1] = ptsneed;
			    eskndg[commvl_1.ivx - 1] = esk;
			    if (bit_test(all_1.ipl[commvl_1.ivx + ip * 7 - 8],
				    31)) {

/*  Convert GW to GA */

				all_1.ipl[commvl_1.ivx + ip * 7 - 8] = 
					bit_set(bit_clear(all_1.ipl[
					commvl_1.ivx + ip * 7 - 8],31),29);
			    }
			}
		    }

/*  Check for GA */

		    if (bit_test(all_1.ipl[commvl_1.ivx + ip * 7 - 8],29)) {
			i__10 = ncmid_(&all_1.iv, &ip);
			dograce_(&commvl_1.ivx, &ip, ptgr, soutq, &lsout, &
				i__10, all_1.accq + (commvl_1.ivx + ip * 7 - 
				8), &ig, &all_1.ipl[commvl_1.ivx + ip * 7 - 8]
				, &c_false, 80L, 1L);
		    }
		    if (! comxtup_1.vxtup[commvl_1.ivx - 1] || all_1.nodur[
			    commvl_1.ivx + ip * 7 - 8] > 0) {
			itnow += comnsp_1.nspace[ib - 1];
		    }
L10:
		    ;
		}

/*  Have finished last note in this voice and block */

		itendb = all_1.list[(istop[ib] << 2) - 2] + comnsp_1.nspace[
			ib - 1];
L17:
		if (all_1.figcheck && comfig_1.itfig[ifig - 1] < itendb) {

/*  There's at least one figure left. offnsk could be <0 
*/

		    offnsk = (real) (itnow - comfig_1.itfig[ifig - 1]) / 
			    comnsp_1.nspace[ib - 1];
		    putfig_(&ifig, &offnsk, &all_1.figcheck, soutq, &lsout, 
			    80L);
		    goto L17;
		}

/*  Check for flag, dot, or upstem on last note of bar. */

		if (ib == comnsp_1.nb) {
		    ip = all_1.list[((255 & all_1.ipl[commvl_1.ivx + all_1.nn[
			    commvl_1.ivx - 1] * 7 - 8]) << 2) - 3];
		    comnsp_1.flgndv[commvl_1.ivx - 1] = (float)0.;
		    if (! comxtup_1.vxtup[commvl_1.ivx - 1] && all_1.nodur[
			    commvl_1.ivx + ip * 7 - 8] == comnsp_1.nspace[ib 
			    - 1]) {
			if (comnsp_1.nspace[ib - 1] < 16) {

/*  Non-xtup, in last nspace, smaller than a quart
er note. */

			    i__7 = ncmid_(&all_1.iv, &ip);
			    udqq_(ch__3, 1L, &all_1.nolev[commvl_1.ivx + ip * 
				    7 - 8], &i__7, &all_1.islur[commvl_1.ivx 
				    + ip * 7 - 8], &commvl_1.nvmx[all_1.iv - 
				    1], &commvl_1.ivx, &all_1.nv);
			    i__10 = log2_(&all_1.nodur[commvl_1.ivx + ip * 7 
				    - 8]);
			    if (! bit_test(all_1.irest[commvl_1.ivx + ip * 7 
				    - 8],0) && *(unsigned char *)&ch__3[0] == 
				    'u' || pow_ii(&c__2, &i__10) != 
				    all_1.nodur[commvl_1.ivx + ip * 7 - 8]) {

/*  Upstem non-rest, or dotted */

				i__7 = log2_(&all_1.nodur[commvl_1.ivx + ip * 
					7 - 8]);
				if (numbms[commvl_1.ivx] > 0 && ip == 
					all_1.ibm2[commvl_1.ivx + numbms[
					commvl_1.ivx] * 7 - 8] && pow_ii(&
					c__2, &i__7) == all_1.nodur[
					commvl_1.ivx + ip * 7 - 8]) {

/*  In beam and not dotted, so use smaller
 space */

				    comnsp_1.flgndv[commvl_1.ivx - 1] = 
					    spfacs_1.upstmfac;
				} else {
				    comnsp_1.flgndv[commvl_1.ivx - 1] = 
					    spfacs_1.flagfac;
				}
			    }
			} else {

/*  Last space, non-xtup, nonflagged (no beam) onl
y worry dot or up */

			    i__7 = log2_(&all_1.nodur[commvl_1.ivx + ip * 7 - 
				    8]);
			    if (pow_ii(&c__2, &i__7) != all_1.nodur[
				    commvl_1.ivx + ip * 7 - 8]) {

/*  Dotted */

				comnsp_1.flgndv[commvl_1.ivx - 1] = 
					spfacs_1.flagfac;
			    } else /* if(complicated condition) */ {
				i__7 = ncmid_(&all_1.iv, &ip);
				udqq_(ch__3, 1L, &all_1.nolev[commvl_1.ivx + 
					ip * 7 - 8], &i__7, &all_1.islur[
					commvl_1.ivx + ip * 7 - 8], &
					commvl_1.nvmx[all_1.iv - 1], &
					commvl_1.ivx, &all_1.nv);
				if (all_1.nodur[commvl_1.ivx + ip * 7 - 8] < 
					64 && *(unsigned char *)&ch__3[0] == 
					'u') {

/*  Upstem on last note , non-flagged */

				    comnsp_1.flgndv[commvl_1.ivx - 1] = 
					    spfacs_1.upstmfac;
				}
			    }
			}
		    }

/*  Check for right-shifted chordal note */

		    if (bit_test(all_1.irest[commvl_1.ivx + ip * 7 - 8],20)) {
			comnsp_1.flgndv[commvl_1.ivx - 1] = spfacs_1.rtshfac;
		    }
		    comnsp_1.flgndb = comnsp_1.flgndb || comnsp_1.flgndv[
			    commvl_1.ivx - 1] > (float)0.;
		}
		comnsp_1.xtupb4 = comnsp_1.xtupb4 || comxtup_1.vxtup[
			commvl_1.ivx - 1];
		comxtup_1.vxtup[commvl_1.ivx - 1] = FALSE_;
		comnsp_1.xtfold[commvl_1.ivx - 1] = comxtup_1.xtupfac[
			commvl_1.ivx - 1];
/* L11: */
	    }
	}

/*  Close out the notes group */

/* Writing concatenation */
	i__6[0] = 1, a__3[0] = all_1.sq;
	i__6[1] = 2, a__3[1] = "en";
	s_cat(ch__12, a__3, i__6, &c__2, 3L);
	addstr_(ch__12, &c__3, soutq, &lsout, 3L, 80L);
	if (lsout > 0) {
	    s_wsfe(&io___302);
/* Writing concatenation */
	    i__6[0] = lsout, a__3[0] = soutq;
	    i__6[1] = 1, a__3[1] = "%";
	    s_cat(ch__9, a__3, i__6, &c__2, 81L);
	    do_fio(&c__1, ch__9, lsout + 1);
	    e_wsfe();
	}
/* L16: */
    }

/* Check for way-after graces at end of bar.  We could not link these to n
otes*/
/* as in midbar since there is no note following grace!  Also, set flag if
*/
/* hardspace is needed. Also, save nvmx, ivmx for use in space checks on r
eloop.*/

    isgrace = FALSE_;
    i__2 = all_1.nv;
    for (all_1.iv = 1; all_1.iv <= i__2; ++all_1.iv) {
	comnsp_1.nvmxsav[all_1.iv - 1] = commvl_1.nvmx[all_1.iv - 1];
	i__5 = commvl_1.nvmx[all_1.iv - 1];
	for (kv = 1; kv <= i__5; ++kv) {
	    comnsp_1.ivmxsav[all_1.iv + kv * 7 - 8] = commvl_1.ivmx[all_1.iv 
		    + kv * 7 - 8];
	    commvl_1.ivx = commvl_1.ivmx[all_1.iv + kv * 7 - 8];
	    comnsp_1.ptsgnd = (float)0.;
	    if ((bit_test(all_1.ipl[commvl_1.ivx + all_1.nn[commvl_1.ivx - 1] 
		    * 7 - 8],29) || bit_test(all_1.ipl[commvl_1.ivx + 
		    all_1.nn[commvl_1.ivx - 1] * 7 - 8],31)) && ptsndg[
		    commvl_1.ivx - 1] > (float)0.) {
		comnsp_1.flgndb = TRUE_;
		if (ptsndg[commvl_1.ivx - 1] > comnsp_1.ptsgnd) {
		    comnsp_1.ptsgnd = ptsndg[commvl_1.ivx - 1];
		    comnsp_1.eskgnd = eskndg[commvl_1.ivx - 1];
		}
	    }
	    if (bit_test(all_1.ipl[commvl_1.ivx + all_1.nn[commvl_1.ivx - 1] *
		     7 - 8],31)) {

/*  This voice has a way-after grace here at end of bar */

		if (! isgrace) {

/*  This is the first one, so set up the string */

		    isgrace = TRUE_;
		    ivlast = 1;
/* Writing concatenation */
		    i__6[0] = 1, a__3[0] = all_1.sq;
		    i__6[1] = 6, a__3[1] = "znotes";
		    s_cat(soutq, a__3, i__6, &c__2, 80L);
		    lsout = 7;
		}
		i__1 = all_1.iv - 1;
		for (iiv = ivlast; iiv <= i__1; ++iiv) {
		    addstr_(all_1.sepsymq + (iiv - 1), &c__1, soutq, &lsout, 
			    1L, 80L);
/* L76: */
		}
		ivlast = all_1.iv;

/*  No need to put in 'nextvoice', even if 2 lines/staff */

		i__1 = ncmid_(&all_1.iv, &all_1.nn[commvl_1.ivx - 1]);
		dograce_(&commvl_1.ivx, &all_1.nn[commvl_1.ivx - 1], ptgr, 
			soutq, &lsout, &i__1, all_1.accq + (commvl_1.ivx + 
			all_1.nn[commvl_1.ivx - 1] * 7 - 8), &ig, &all_1.ipl[
			commvl_1.ivx + all_1.nn[commvl_1.ivx - 1] * 7 - 8], &
			c_true, 80L, 1L);
	    }
/* L75: */
	}
    }
    if (isgrace) {
/* Writing concatenation */
	i__6[0] = 1, a__3[0] = all_1.sq;
	i__6[1] = 3, a__3[1] = "en%";
	s_cat(ch__16, a__3, i__6, &c__2, 4L);
	addstr_(ch__16, &c__4, soutq, &lsout, 4L, 80L);
	if (lsout > 0) {
	    s_wsfe(&io___305);
	    do_fio(&c__1, soutq, lsout);
	    e_wsfe();
	}
    }

/* Write stuff for whole bar rests if needed.  Assuming no multi-voice sta
ves*/

    lsout = 0;
    i__5 = all_1.nv;
    for (all_1.iv = 1; all_1.iv <= i__5; ++all_1.iv) {
	if (lsout > 0) {

/*  Have already inserted at least one rest.  Append sepsymq */

/* Writing concatenation */
	    i__6[0] = lsout, a__3[0] = soutq;
	    i__6[1] = 1, a__3[1] = all_1.sepsymq + (all_1.iv - 2);
	    s_cat(soutq, a__3, i__6, &c__2, 80L);
	    ++lsout;
	}
	if (cwrest[all_1.iv]) {
/* ???        if (cwrest(ivx)) then */
	    if (lsout == 0) {

/* In case it's a liftpause, must surround w/ brackets as arg 
of centerbar*/

		if (all_1.ibar != comgrace_1.ibarmbr) {
		    if (s_cmp(cwrq + 1, "lift", 4L, 4L) == 0) {
/* Writing concatenation */
			i__4[0] = 1, a__2[0] = "{";
			i__4[1] = lcwr, a__2[1] = cwrq;
			i__4[2] = 1, a__2[2] = "}";
			s_cat(notexq, a__2, i__4, &c__3, 79L);
			lcwr += 2;
			s_copy(cwrq, notexq, 79L, lcwr);
		    } else if (cwrferm[all_1.iv - 1]) {

/*  Fermata on centered rest, use brackets */

/* Writing concatenation */
			i__11[0] = 1, a__6[0] = "{";
			i__11[1] = 1, a__6[1] = all_1.sq;
			i__11[2] = 10, a__6[2] = "fermataup7";
			i__11[3] = lcwr, a__6[3] = cwrq;
			i__11[4] = 1, a__6[4] = "}";
			s_cat(notexq, a__6, i__11, &c__5, 79L);
			lcwr += 13;
			s_copy(cwrq, notexq, 79L, lcwr);
			cwrferm[all_1.iv - 1] = FALSE_;
		    }
		    s_wsfe(&io___306);
/* Writing concatenation */
		    i__9[0] = 1, a__5[0] = all_1.sq;
		    i__9[1] = 3, a__5[1] = "def";
		    i__9[2] = 1, a__5[2] = all_1.sq;
		    i__9[3] = 7, a__5[3] = "wbrest{";
		    i__9[4] = 1, a__5[4] = all_1.sq;
		    i__9[5] = 9, a__5[5] = "centerbar";
		    i__9[6] = lcwr, a__5[6] = cwrq;
		    i__9[7] = 2, a__5[7] = "}%";
		    s_cat(ch__17, a__5, i__9, &c__8, 103L);
		    do_fio(&c__1, ch__17, lcwr + 24);
		    e_wsfe();
		}

/*  This is the first voice with rest.  Set up the string. */

/* Writing concatenation */
		i__3[0] = 1, a__1[0] = all_1.sq;
		i__3[1] = 3, a__1[1] = "def";
		i__3[2] = 1, a__1[2] = all_1.sq;
		i__3[3] = 10, a__1[3] = "atnextbar{";
		i__3[4] = 1, a__1[4] = all_1.sq;
		i__3[5] = 6, a__1[5] = "znotes";
		s_cat(soutq, a__1, i__3, &c__6, 80L);
		lsout = 22;
		i__2 = all_1.iv;
		for (jv = 2; jv <= i__2; ++jv) {
/* Writing concatenation */
		    i__6[0] = lsout, a__3[0] = soutq;
		    i__6[1] = 1, a__3[1] = all_1.sepsymq + (jv - 2);
		    s_cat(soutq, a__3, i__6, &c__2, 80L);
		    ++lsout;
/* L62: */
		}
	    }
	    if (all_1.ibar != comgrace_1.ibarmbr) {

/*  Single-bar rest */

/* Writing concatenation */
		i__4[0] = lsout, a__2[0] = soutq;
		i__4[1] = 1, a__2[1] = all_1.sq;
		i__4[2] = 6, a__2[2] = "wbrest";
		s_cat(soutq, a__2, i__4, &c__3, 80L);
		lsout += 7;
	    } else {

/*  Multibar rest */

/* Writing concatenation */
		i__4[0] = lsout, a__2[0] = soutq;
		i__4[1] = 1, a__2[1] = all_1.sq;
		i__4[2] = 7, a__2[2] = "mbrest{";
		s_cat(soutq, a__2, i__4, &c__3, 80L);
		lsout += 8;
		r__1 = comgrace_1.mbrest + (float).01;
		ndig = (integer) r_lg10(&r__1) + 1;
		i__2 = lsout;
		ici__1.icierr = 0;
		ici__1.icirnum = 1;
		ici__1.icirlen = lsout + 2 - i__2;
		ici__1.iciunit = soutq + i__2;
/* Writing concatenation */
		i__4[0] = 2, a__2[0] = "(i";
		*(unsigned char *)&ch__3[0] = ndig + 48;
		i__4[1] = 1, a__2[1] = ch__3;
		i__4[2] = 1, a__2[2] = ")";
		ici__1.icifmt = (s_cat(ch__16, a__2, i__4, &c__3, 4L), ch__16)
			;
		s_wsfi(&ici__1);
		do_fio(&c__1, (char *)&comgrace_1.mbrest, (ftnlen)sizeof(
			integer));
		e_wsfi();
		lsout += ndig;
/* Writing concatenation */
		i__6[0] = lsout, a__3[0] = soutq;
		i__6[1] = 2, a__3[1] = "}{";
		s_cat(soutq, a__3, i__6, &c__2, 80L);
		lsout += 2;
		mtrspc = comgrace_1.xb4mbr + (float).5;
		comgrace_1.xb4mbr = (float)0.;
		if (mtrspc == 0) {
		    ndig = 1;
		} else {
		    r__1 = mtrspc + (float).01;
		    ndig = (integer) r_lg10(&r__1) + 1;
		}
		i__2 = lsout;
		ici__1.icierr = 0;
		ici__1.icirnum = 1;
		ici__1.icirlen = lsout + 2 - i__2;
		ici__1.iciunit = soutq + i__2;
/* Writing concatenation */
		i__4[0] = 2, a__2[0] = "(i";
		*(unsigned char *)&ch__3[0] = ndig + 48;
		i__4[1] = 1, a__2[1] = ch__3;
		i__4[2] = 1, a__2[2] = ")";
		ici__1.icifmt = (s_cat(ch__16, a__2, i__4, &c__3, 4L), ch__16)
			;
		s_wsfi(&ici__1);
		do_fio(&c__1, (char *)&mtrspc, (ftnlen)sizeof(integer));
		e_wsfi();
		lsout += ndig;
/* Writing concatenation */
		i__6[0] = lsout, a__3[0] = soutq;
		i__6[1] = 2, a__3[1] = "}0";
		s_cat(soutq, a__3, i__6, &c__2, 80L);
		lsout += 2;
	    }
	}
/* L60: */
    }
    if (lsout > 0) {
	s_wsfe(&io___310);
/* Writing concatenation */
	i__4[0] = lsout, a__2[0] = soutq;
	i__4[1] = 1, a__2[1] = all_1.sq;
	i__4[2] = 4, a__2[2] = "en}%";
	s_cat(ch__18, a__2, i__4, &c__3, 85L);
	do_fio(&c__1, ch__18, lsout + 5);
	e_wsfe();
    }
    if (all_1.ibar == comgrace_1.ibarmbr) {
	r__1 = comgrace_1.mbrest - 1 + (float).01;
	ndig = (integer) r_lg10(&r__1) + 1;
	ci__1.cierr = 0;
	ci__1.ciunit = 11;
/* Writing concatenation */
	i__4[0] = 6, a__2[0] = "(a14,i";
	*(unsigned char *)&ch__3[0] = ndig + 48;
	i__4[1] = 1, a__2[1] = ch__3;
	i__4[2] = 4, a__2[2] = ",a1)";
	ci__1.cifmt = (s_cat(ch__6, a__2, i__4, &c__3, 11L), ch__6);
	s_wsfe(&ci__1);
/* Writing concatenation */
	i__8[0] = 1, a__4[0] = all_1.sq;
	i__8[1] = 7, a__4[1] = "advance";
	i__8[2] = 1, a__4[2] = all_1.sq;
	i__8[3] = 5, a__4[3] = "barno";
	s_cat(ch__19, a__4, i__8, &c__4, 14L);
	do_fio(&c__1, ch__19, 14L);
	i__5 = comgrace_1.mbrest - 1;
	do_fio(&c__1, (char *)&i__5, (ftnlen)sizeof(integer));
	do_fio(&c__1, "%", 1L);
	e_wsfe();
    }

/* If at end of block, save durations of last notes in bar, for possible u
se*/
/*  if clef changes at start of next bar */

    if (all_1.ibar == all_1.nbars) {
	i__5 = all_1.nv;
	for (all_1.iv = 1; all_1.iv <= i__5; ++all_1.iv) {
	    i__2 = commvl_1.nvmx[all_1.iv - 1];
	    for (kv = 1; kv <= i__2; ++kv) {
		commvl_1.ivx = commvl_1.ivmx[all_1.iv + kv * 7 - 8];
		comnsp_1.lastnodur[commvl_1.ivx - 1] = all_1.nodur[
			commvl_1.ivx + all_1.nn[all_1.iv - 1] * 7 - 8];
/* L63: */
	    }
	}
    }
    return 0;
} /* make2bar_ */

/* Subroutine */ int make1bar_(ibmrep, nbxtup, itglp1, itstart, cwrest, 
	nindex, istop, n1xtup, numbms, istart, nxtup, lbxtup)
integer *ibmrep, *nbxtup, *itglp1, *itstart;
logical *cwrest;
integer *nindex, *istop, *n1xtup, *numbms, *istart, *nxtup, *lbxtup;
{
    /* System generated locals */
    integer i__1, i__2, i__3, i__4, i__5, i__6;

    /* Builtin functions */
    integer s_wsle(), do_lio(), e_wsle();
    /* Subroutine */ int s_stop();

    /* Local variables */
    extern /* Subroutine */ int findbeam_();
    static integer irep, iivx, ntot, itbb1, itbb2, itbb3, itstopib;
    extern /* Subroutine */ int addfb_();
    static integer it1xt, it2xt, mapfb[4];
    static logical infbm;
    static integer itmin, ibrep, nip1fb, nip2fb, itglp2, ib1now, ib2now, 
	    ifbadd, ib, jb, in, ip, nfbbar, it[7];
    static logical rpndot;
    static integer kv, itminn;
    extern integer nindxf_();
    static integer numnew, ip1, ib1, ib2, mapnow, cnn[7], iin, iiv, isl;
    extern /* Subroutine */ int logbeam_();
    static integer it1xtup[20], ixt;
    static logical cwrferm[7];
    static integer n1xt, n2xt;

    /* Fortran I/O blocks */
    static cilist io___337 = { 0, 6, 0, 0, 0 };
    static cilist io___347 = { 0, 6, 0, 0, 0 };



/*  Factors for grace note, clef spacing. (fraction of wheadpt or apt) */
/*  In 1.04, moved to block data subprogram */

/*      common /comslur/ listslur,ndxslur(nm,2),upslur(nm,2) */

/*  Time from start of gulp to end of bar, used with forced beams */

    /* Parameter adjustments */
    --lbxtup;
    --istart;
    --numbms;
    --n1xtup;
    --istop;
    --nindex;
    --cwrest;
    --itstart;

    /* Function Body */
    itglp2 = all_1.lenb0 + all_1.ibar * all_1.lenb1;
    if (all_1.lenb0 > 0) {
	itglp2 -= all_1.lenb1;
    }
    *itglp1 = itglp2 - all_1.lenbar;

/*  For now, assume no whole bar rests if multi-voices per staff */

    i__1 = all_1.nv;
    for (all_1.iv = 1; all_1.iv <= i__1; ++all_1.iv) {
	i__2 = commvl_1.nvmx[all_1.iv - 1];
	for (kv = 1; kv <= i__2; ++kv) {
	    commvl_1.ivx = commvl_1.ivmx[all_1.iv + kv * 7 - 8];
	    if (commvl_1.ivx <= all_1.nv) {
		cwrest[all_1.iv] = FALSE_;
	    }
	    if (all_1.ibar > 1) {
		all_1.nn[commvl_1.ivx - 1] = all_1.nib[commvl_1.ivx + 
			all_1.ibar * 7 - 8] - all_1.nib[commvl_1.ivx + (
			all_1.ibar - 1) * 7 - 8];
	    } else {
		all_1.nn[commvl_1.ivx - 1] = all_1.nib[commvl_1.ivx + 
			all_1.ibar * 7 - 8];
	    }
/* L1: */
	}
    }

/* initialize list note counter, time(iv), curr. note(iv).  The loop to 4 
*/
/*   ONLY initializes each voice. */

    in = 1;
    rpndot = FALSE_;
    comxtup_1.inxtup = FALSE_;
    *nxtup = 0;
    comarp_1.narp = 0;
    i__2 = all_1.nv;
    for (all_1.iv = 1; all_1.iv <= i__2; ++all_1.iv) {
	i__1 = commvl_1.nvmx[all_1.iv - 1];
	for (kv = 1; kv <= i__1; ++kv) {
	    commvl_1.ivx = commvl_1.ivmx[all_1.iv + kv * 7 - 8];
	    cwrferm[commvl_1.ivx - 1] = FALSE_;
	    cnn[commvl_1.ivx - 1] = 1;
L2:
	    all_1.list[(in << 2) - 4] = commvl_1.ivx;
	    all_1.list[(in << 2) - 3] = cnn[commvl_1.ivx - 1];
	    all_1.list[(in << 2) - 2] = 0;
	    it[commvl_1.ivx - 1] = all_1.nodur[commvl_1.ivx + cnn[
		    commvl_1.ivx - 1] * 7 - 8];

/* Note that it(ivx) is to END of note in voice, but it1xtup is st
art time.*/

	    if (all_1.nodur[commvl_1.ivx + all_1.list[(in << 2) - 3] * 7 - 8] 
		    == 0) {
		if (! comxtup_1.inxtup) {

/*  First note of xtuplet. */

		    ++(*nxtup);
		    comxtup_1.inxtup = TRUE_;
		    it1xtup[*nxtup - 1] = 0;
		    n1xtup[*nxtup] = in;

/*  If not in explict forced beam, put xtup in one, & */
/*    put in order with all fb's in gulp. */

		    infbm = FALSE_;
		    if (comfb_1.nfb[commvl_1.ivx - 1] > 0) {
			i__3 = comfb_1.nfb[commvl_1.ivx - 1];
			for (comfb_1.ifb = 1; comfb_1.ifb <= i__3; 
				++comfb_1.ifb) {
			    if (comfb_1.it1fb[commvl_1.ivx + comfb_1.ifb * 7 
				    - 8] == *itglp1) {
				infbm = TRUE_;
				goto L71;
			    }
/* L70: */
			}
		    }
L71:
/*    *      call addfb(nfb,ivx,it1xtup(nxtup)+itglp1, */
		    if (! infbm) {
			i__3 = it1xtup[*nxtup - 1] + *itglp1;
			addfb_(comfb_1.nfb, &commvl_1.ivx, &i__3, 
				comfb_1.it1fb, comfb_1.it2fb, comfb_1.ulfbq, &
				ifbadd, 1L);
		    }
		}

/*  To keep all notes of xtup together, get another note from 
this voice */

		++in;
		++cnn[commvl_1.ivx - 1];
		goto L2;
	    } else if (comxtup_1.inxtup) {

/*  End the xtuplet */

		comxtup_1.inxtup = FALSE_;
		comxtup_1.n2xtup[*nxtup - 1] = in;
		if (! infbm) {
		    comfb_1.it2fb[commvl_1.ivx + ifbadd * 7 - 8] = it1xtup[*
			    nxtup - 1] + all_1.nodur[commvl_1.ivx + cnn[
			    commvl_1.ivx - 1] * 7 - 8] + *itglp1;
		}
	    }
	    if (it[commvl_1.ivx - 1] == all_1.lenbar) {
		it[commvl_1.ivx - 1] = 1000;
	    }
	    ++in;
/* L4: */
	}
    }

/*  Build the list:  Manual loop starting at 5 */

L5:

/*  Determine which voice comes next from end of notes done so far. */
/*  itmin is the earliest ending time of notes done so far */

    itmin = 1000;
    i__1 = all_1.nv;
    for (iiv = 1; iiv <= i__1; ++iiv) {
	i__2 = commvl_1.nvmx[iiv - 1];
	for (kv = 1; kv <= i__2; ++kv) {
	    iivx = commvl_1.ivmx[iiv + kv * 7 - 8];
/* Computing MIN */
	    i__3 = itmin, i__4 = it[iivx - 1];
	    itminn = min(i__3,i__4);
	    if (itminn < itmin) {
		itmin = itminn;
		commvl_1.ivx = iivx;
	    }
/* L6: */
	}
    }
    if (itmin == 1000) {
	goto L7;
    }
    all_1.list[(in << 2) - 4] = commvl_1.ivx;
    ++cnn[commvl_1.ivx - 1];
    all_1.list[(in << 2) - 3] = cnn[commvl_1.ivx - 1];
    all_1.list[(in << 2) - 2] = itmin;

/*  Check if this voice is done */

    if (cnn[commvl_1.ivx - 1] == all_1.nn[commvl_1.ivx - 1]) {
	it[commvl_1.ivx - 1] = 1000;
    } else {
	it[commvl_1.ivx - 1] += all_1.nodur[commvl_1.ivx + cnn[commvl_1.ivx - 
		1] * 7 - 8];
    }

/*  Flag xtups */

    if (all_1.nodur[commvl_1.ivx + cnn[commvl_1.ivx - 1] * 7 - 8] == 0) {
	if (! comxtup_1.inxtup) {

/*  First note of xtup, not at start of bar. */

	    ++(*nxtup);
	    comxtup_1.inxtup = TRUE_;
	    n1xtup[*nxtup] = in;
	    it1xtup[*nxtup - 1] = it[commvl_1.ivx - 1];

/*  (Note: can't be on last note in voice, so it(ivx) <> 1000) */
/*  Put xtuplet in a forced beam if not already in forced beam */

	    infbm = FALSE_;
	    if (comfb_1.nfb[commvl_1.ivx - 1] > 0) {
		i__2 = comfb_1.nfb[commvl_1.ivx - 1];
		for (comfb_1.ifb = 1; comfb_1.ifb <= i__2; ++comfb_1.ifb) {
		    if (comfb_1.it1fb[commvl_1.ivx + comfb_1.ifb * 7 - 8] <= *
			    itglp1 + it[commvl_1.ivx - 1] && comfb_1.it2fb[
			    commvl_1.ivx + comfb_1.ifb * 7 - 8] > *itglp1 + 
			    it[commvl_1.ivx - 1]) {
			infbm = TRUE_;
			goto L73;
		    }
/* L72: */
		}
	    }
L73:
/*         call addfb(nfb,ivx,it1xtup(nxtup)+itglp1, */
	    if (! infbm) {
		i__2 = it1xtup[*nxtup - 1] + *itglp1;
		addfb_(comfb_1.nfb, &commvl_1.ivx, &i__2, comfb_1.it1fb, 
			comfb_1.it2fb, comfb_1.ulfbq, &ifbadd, 1L);
	    }
	}
    } else if (comxtup_1.inxtup) {
	comxtup_1.inxtup = FALSE_;
	comxtup_1.n2xtup[*nxtup - 1] = in;
/*       it2fb(ivx,ifbadd) = it1xtup(nxtup)+nodur(ivx,cnn(ivx))+itglp2
 */
/*    *                         -lenbar */
	if (! infbm) {
	    comfb_1.it2fb[commvl_1.ivx + ifbadd * 7 - 8] = it1xtup[*nxtup - 1]
		     + all_1.nodur[commvl_1.ivx + cnn[commvl_1.ivx - 1] * 7 - 
		    8] + *itglp1;
	}
    }
    ++in;
    goto L5;
L7:
    ntot = in - 1;
    i__2 = ntot - 1;
    for (in = 1; in <= i__2; ++in) {
	all_1.list[(in << 2) - 1] = all_1.list[(in + 1 << 2) - 2] - 
		all_1.list[(in << 2) - 2];
/* L8: */
    }
    all_1.list[(ntot << 2) - 1] = all_1.nodur[all_1.list[(ntot << 2) - 4] + 
	    all_1.list[(ntot << 2) - 3] * 7 - 8];

/*  Done w/ list. A kluged up loop for parsing into note blocks: */

    ib = 1;
    istart[1] = 1;
    comnsp_1.nspace[0] = 0;
    in = 1;

/*  A loop to set nspace(ib) and istop(ib) */

L9:
/* Computing MIN */
    i__2 = in + 1;
    commvl_1.ivx = all_1.list[(min(i__2,ntot) << 2) - 4];
/* Computing MIN */
    i__2 = in + 1;
    ip = all_1.list[(min(i__2,ntot) << 2) - 3];
    isl = all_1.islur[commvl_1.ivx + ip * 7 - 8];
    if (in == ntot || (commvl_1.ivx == 1 && ((isl & 67109216) > 0 || bit_test(
	    all_1.ipl[ip * 7 - 7],28) || bit_test(all_1.iornq[ip * 7 - 7],4)) 
	    || bit_test(isl,15))) {
/*    *      .or. ornq(1,ip).eq.'g')) .or. btest(isl,15) )) then */
/*  Bits 1-13: stmgx+Tupf._) */
/*  14: Down fermata, was F */
/*  15: Trill w/o "tr", was U */

/* Bar end, segno, int. rpt or sig change, clef; flow out of if-loop a
nd into*/
/*  block-wrapup */

/* 10/18/97:  Problem with clef alignment.  Got isl{15} set on lowest-
numbered*/
/*  voice, but it wasn't first in the list at the same time.  So check
 if */
/*  prior notes in list have same time */

	if (bit_test(isl,15)) {
	    for (iin = in; iin >= 1; --iin) {
		if (all_1.list[(iin << 2) - 1] > 0) {
		    in = iin;
		    all_1.islur[commvl_1.ivx + ip * 7 - 8] = bit_clear(
			    all_1.islur[commvl_1.ivx + ip * 7 - 8],15);
		    all_1.islur[all_1.list[(in + 1 << 2) - 4] + all_1.list[(
			    in + 1 << 2) - 3] * 7 - 8] = bit_set(all_1.islur[
			    all_1.list[(in + 1 << 2) - 4] + all_1.list[(in + 
			    1 << 2) - 3] * 7 - 8],15);
		    goto L51;
		}
/* L50: */
	    }
L51:
	    ;
	}
	if (comnsp_1.nspace[ib - 1] == 0) {
	    comnsp_1.nspace[ib - 1] = all_1.list[(in << 2) - 1];
	}
	istop[ib] = in;
    } else if (comnsp_1.nspace[ib - 1] == 0) {

/*  Nspace hasn't been set yet, so tentatively set: */

	comnsp_1.nspace[ib - 1] = all_1.list[(in << 2) - 1];
	if (comnsp_1.nspace[ib - 1] == 0) {
	    ++in;
	} else {
	    istop[ib] = in;
	}
	goto L9;
    } else if (all_1.list[(in + 1 << 2) - 1] == 0) {

/*  This is not the last note in the group, so */

	++in;
	goto L9;
    } else if (all_1.list[(in + 1 << 2) - 1] == comnsp_1.nspace[ib - 1]) {

/*  Keep spacing the same, update tentative stop point */

	++in;
	istop[ib] = in;
	goto L9;
    }

/* At this point istart and istop are good, so finalize block */

    itstart[ib] = all_1.list[(istart[ib] << 2) - 2];
    nindex[ib] = nindxf_(&comnsp_1.nspace[ib - 1]);
    if (istop[ib] == ntot) {
	goto L15;
    }
    ++ib;
    istart[ib] = istop[ib - 1] + 1;
    in = istart[ib];

/* Set tentative block space for upcoming block */

    comnsp_1.nspace[ib - 1] = all_1.list[(in << 2) - 1];
    istop[ib] = in;
    goto L9;
L15:
    comnsp_1.nb = ib;
/*     print*,'istart(ib),istop(ib),nspace(ib)' */
/*     write(*,'(24i3)')(istart(ib),istop(ib),nspace(ib),ib=1,nb) */

/* Check for xtuplets.  Locate and split off all xtuplets into separate bl
ock*/
/* groups.  Each xtup starts and ends some block, and there may be interna
l*/
/* stops and new starts during the duration of the xtup.  Splitting off is
*/
/* a safety against e.g. e4x3 e8 e / e8 e e e / , where 1st half is longer
*/
/*  than second.  Make a list of the nbxtup blocks w/ xtups in lbxtup() */

    ib = 1;
    *nbxtup = 0;
    i__2 = *nxtup;
    for (ixt = 1; ixt <= i__2; ++ixt) {
	if (ixt > 1 && it1xtup[ixt - 1] == it1xt) {
	    goto L90;
	}
	n1xt = n1xtup[ixt];
	it1xt = it1xtup[ixt - 1];
L91:
	if (istop[ib] < n1xt) {

/*  Block ends before xtup starts, so go to next block */

	    ++ib;
	    goto L91;
	}

/* Know ib ends after xtup starts, and must start at or before xtup.  
If "at",*/
/*  don't need to start new block. */

	if (itstart[ib] < it1xt) {

/*  But now must add new block */

	    if (all_1.list[(n1xt << 2) - 4] > 1) {

/*  Back up to most recent note with earlier time */

		for (in = n1xt - 1; in >= 1; --in) {
		    if (all_1.list[(in << 2) - 2] != it1xt) {
			goto L93;
		    }
/* L92: */
		}
	    } else {
		in = n1xt - 1;
	    }
L93:

/*  "in" is now the last note of new version of ib.  Insert new bl
ock */

	    ++comnsp_1.nb;
	    i__1 = ib + 1;
	    for (jb = comnsp_1.nb; jb >= i__1; --jb) {
		nindex[jb] = nindex[jb - 1];
		istop[jb] = istop[jb - 1];
		istart[jb] = istart[jb - 1];
		comnsp_1.nspace[jb - 1] = comnsp_1.nspace[jb - 2];
		itstart[jb] = itstart[jb - 1];
/* L94: */
	    }
	    istop[ib] = in;
	    istart[ib + 1] = in + 1;
	    itstart[ib + 1] = all_1.list[(in + 1 << 2) - 2];
	    ++ib;
	}

/*  Add ib to the list of blocks in which xtups start. */

	if (*nbxtup == 0 || lbxtup[*nbxtup] != ib) {
	    ++(*nbxtup);
	    lbxtup[*nbxtup] = ib;
	}

/* Check for block ending time relative to xtup.  Check has to be base
d on*/
/*   time rather than note number in list. */

	n2xt = comxtup_1.n2xtup[ixt - 1];
	it2xt = all_1.list[(n2xt << 2) - 2] + all_1.nodur[all_1.list[(n2xt << 
		2) - 4] + all_1.list[(n2xt << 2) - 3] * 7 - 8];
/*     print*,'Checking end times of xtups. it2xt:',it2xt */
L95:
	itstopib = all_1.list[(istop[ib] << 2) - 2] + comnsp_1.nspace[ib - 1];
	if (itstopib < it2xt) {
	    ++ib;
	    goto L95;
	}
	if (itstopib != it2xt) {

/* Must stop a block at it2xt, restart a new one.  Look back from 
istop for*/
/*   most recent note w/ proper stopping time */

	    for (in = istop[ib] - 1; in >= 1; --in) {
		if (all_1.list[(in << 2) - 2] + comnsp_1.nspace[ib - 1] == 
			it2xt) {
		    goto L97;
		}
/* L96: */
	    }
	    s_wsle(&io___337);
	    do_lio(&c__9, &c__1, "Should not BEEE here!", 21L);
	    e_wsle();
	    s_stop("", 0L);
L97:

/*  Now "in" is the list place where new stop goes */

	    ++comnsp_1.nb;
	    i__1 = ib + 1;
	    for (jb = comnsp_1.nb; jb >= i__1; --jb) {
		istop[jb] = istop[jb - 1];
		istart[jb] = istart[jb - 1];
		nindex[jb] = nindex[jb - 1];
		comnsp_1.nspace[jb - 1] = comnsp_1.nspace[jb - 2];
		itstart[jb] = itstart[jb - 1];
/* L98: */
	    }
	    istop[ib] = in;
	    istart[ib + 1] = in + 1;
	    itstart[ib + 1] = all_1.list[(in + 1 << 2) - 2];
	    ++ib;
	}
L90:
	;
    }
/*     print* */
/*     print*,'istart,istop,itstart,nspace:' */
/*     write(*,'(24i3)')(istart(ib),istop(ib),itstart(ib),nspace(ib), */
/*    *                   ib=1,nb) */

/*  Invert the list of places, to make it easier to analyze a voice */

    i__2 = ntot;
    for (in = 1; in <= i__2; ++in) {
	all_1.ipl[all_1.list[(in << 2) - 4] + all_1.list[(in << 2) - 3] * 7 - 
		8] |= in;
/* L13: */
    }
/*     print* */
/*     write(*,'(26i3)')(list(1,in),in=1,ntot) */
/*     write(*,'(26i3)')(list(2,in),in=1,ntot) */
/*     write(*,'(26i3)')(list(3,in),in=1,ntot) */
/*     write(*,'(26i3)')(list(4,in),in=1,ntot) */
/*     write(*,'(26i3)')(nodur(list(1,in),list(2,in)),in=1,ntot) */
/*     write(*,'(26i3)')(iand(islur(list(1,in),list(2,in)),30720)/2048, */
/*    *                  in=1,ntot) */
/*     write(*,'(1x,26a3)')(ornq(list(1,in),list(2,in)),in=1,ntot) */
/*     write(*,'(1x,26a3)')(accq(list(1,in),list(2,in)),in=1,ntot) */

/*  Analyze for beams. */

    i__2 = all_1.nv;
    for (all_1.iv = 1; all_1.iv <= i__2; ++all_1.iv) {
	i__1 = commvl_1.nvmx[all_1.iv - 1];
	for (kv = 1; kv <= i__1; ++kv) {
	    commvl_1.ivx = commvl_1.ivmx[all_1.iv + kv * 7 - 8];
	    numbms[commvl_1.ivx] = 0;
	    mapfb[0] = 0;
	    mapfb[1] = 0;
	    mapfb[2] = 0;
	    mapfb[3] = 0;

/*  First forced beams. */

	    if (comfb_1.nfb[commvl_1.ivx - 1] > 0) {

/*  itglp2 is time from start of gulp to end of current bar. 
*/

		nfbbar = 0;
		i__3 = comfb_1.nfb[commvl_1.ivx - 1];
		for (comfb_1.ifb = 1; comfb_1.ifb <= i__3; ++comfb_1.ifb) {
		    if (comfb_1.it1fb[commvl_1.ivx + comfb_1.ifb * 7 - 8] >= 
			    itglp2) {
			goto L81;
		    }
		    ++nfbbar;
		    ++numbms[commvl_1.ivx];
		    numnew = numbms[commvl_1.ivx];

/*  Times from beginning of bar */

		    itbb1 = comfb_1.it1fb[commvl_1.ivx + comfb_1.ifb * 7 - 8] 
			    - *itglp1;
		    itbb2 = comfb_1.it2fb[commvl_1.ivx + comfb_1.ifb * 7 - 8] 
			    - *itglp1;
		    i__4 = all_1.nn[commvl_1.ivx - 1];
		    for (ip = 1; ip <= i__4; ++ip) {
			if (all_1.list[((255 & all_1.ipl[commvl_1.ivx + ip * 
				7 - 8]) << 2) - 2] == itbb1) {
			    nip1fb = ip;

/*  The following loop has a problem if beam ends 
right before xtuplet */
/*  1/11/95 Did a check.  Don't know why I put in 
the above comment */

/*                do 84 ip1 = ip+1 , nn(ivx) */
			    i__5 = all_1.nn[commvl_1.ivx - 1];
			    for (ip1 = ip; ip1 <= i__5; ++ip1) {
				if (all_1.list[((255 & all_1.ipl[commvl_1.ivx 
					+ ip1 * 7 - 8]) << 2) - 2] + 
					all_1.nodur[commvl_1.ivx + ip1 * 7 - 
					8] == itbb2) {
				    nip2fb = ip1;
				    itbb3 = itbb2 - 2;
				    goto L85;
				}
/* L84: */
			    }
			}
/* L83: */
		    }
		    s_wsle(&io___347);
		    do_lio(&c__9, &c__1, "Timing problem w/ fixed beams", 29L)
			    ;
		    e_wsle();
		    s_stop("", 0L);
L85:
		    logbeam_(&numnew, &nip1fb, &nip2fb);

/*  Set up mapfb for forced beam just logged: */

		    ib1 = itbb1 / 2;
		    ib2 = itbb3 / 2;
		    ibrep = all_1.lenbar / *ibmrep / 2;
		    i__4 = *ibmrep;
		    for (irep = 1; irep <= i__4; ++irep) {
/* Computing MAX */
			i__5 = 0, i__6 = ib1 - (irep - 1) * ibrep;
			ib1now = max(i__5,i__6);
/* Computing MIN */
			i__5 = irep * ibrep - 1, i__6 = ib2 - (irep - 1) * 
				ibrep;
			ib2now = min(i__5,i__6);
			mapnow = 0;
			i__5 = ib2now;
			for (ib = ib1now; ib <= i__5; ++ib) {
			    mapnow = bit_set(mapnow,ib);
/* L87: */
			}
			mapfb[irep - 1] |= mapnow;
/* L86: */
		    }
/* L80: */
		}
L81:

/* Slide down, reduce nfb(ivx).  This lets us count up from 1 
for each new bar.*/
/* Remember, makeabar is called 1/bar, and it calls findbeam o
nce per voice.*/

		if (nfbbar > 0) {
		    comfb_1.nfb[commvl_1.ivx - 1] -= nfbbar;
		    i__3 = comfb_1.nfb[commvl_1.ivx - 1];
		    for (comfb_1.ifb = 1; comfb_1.ifb <= i__3; ++comfb_1.ifb) 
			    {
			comfb_1.it1fb[commvl_1.ivx + comfb_1.ifb * 7 - 8] = 
				comfb_1.it1fb[commvl_1.ivx + (comfb_1.ifb + 
				nfbbar) * 7 - 8];
			comfb_1.it2fb[commvl_1.ivx + comfb_1.ifb * 7 - 8] = 
				comfb_1.it2fb[commvl_1.ivx + (comfb_1.ifb + 
				nfbbar) * 7 - 8];
			*(unsigned char *)&comfb_1.ulfbq[commvl_1.ivx + 
				comfb_1.ifb * 7 - 8] = *(unsigned char *)&
				comfb_1.ulfbq[commvl_1.ivx + (comfb_1.ifb + 
				nfbbar) * 7 - 8];
/* L82: */
		    }
		}
	    }
	    comfb_1.ifb = 0;

/* Done with forced beam masks for this bar and voice.  Now get no
rmal beams.*/

	    findbeam_(ibmrep, &numbms[1], mapfb);
/* L20: */
	}
    }
    return 0;
} /* make1bar_ */

/* Subroutine */ int puttitle_(inhnoh, xnsttop, etatop, sq, etait, etatc, 
	etacs1, nv, vshrink, sepsymq, sq_len, sepsymq_len)
integer *inhnoh;
real *xnsttop, *etatop;
char *sq;
real *etait, *etatc, *etacs1;
integer *nv;
logical *vshrink;
char *sepsymq;
ftnlen sq_len;
ftnlen sepsymq_len;
{
    /* System generated locals */
    address a__1[2], a__2[3], a__3[3], a__4[4];
    integer i__1[2], i__2, i__3[3], i__4[3], i__5[4];
    real r__1;
    char ch__1[8], ch__2[1], ch__3[10], ch__4[100], ch__5[81], ch__6[85];
    icilist ici__1;

    /* Builtin functions */
    /* Subroutine */ int s_cat();
    double r_lg10();
    integer s_wsfi(), do_fio(), e_wsfi(), s_wsfe(), e_wsfe();
    /* Subroutine */ int s_copy();
    integer s_wsle(), e_wsle(), do_lio();
    /* Subroutine */ int s_paus();

    /* Local variables */
    static integer ndig;
    extern /* Subroutine */ int writflot_();
    static real xcsil, xtcil, vskil, xitil;
    extern integer lc_();
    static integer iv;
    static real glueil;
    static char notexq[79];
    static integer lcq, lenline;

    /* Fortran I/O blocks */
    static cilist io___361 = { 0, 11, 0, "(a)", 0 };
    static cilist io___364 = { 0, 11, 0, "(a)", 0 };
    static cilist io___365 = { 0, 6, 0, 0, 0 };
    static cilist io___366 = { 0, 6, 0, 0, 0 };
    static cilist io___367 = { 0, 6, 0, 0, 0 };
    static cilist io___368 = { 0, 6, 0, 0, 0 };
    static cilist io___371 = { 0, 11, 0, "(a)", 0 };



/* Called once per page, at top of page!  If vshrink, only called for p.1.
*/
/*  Actual titles only allowed on p.1. (set by headlog). */

    /* Parameter adjustments */
    --sepsymq;

    /* Function Body */
/* Writing concatenation */
    i__1[0] = 1, a__1[0] = sq;
    i__1[1] = 6, a__1[1] = "znotes";
    s_cat(notexq, a__1, i__1, &c__2, 79L);
    lenline = 7;
    i__2 = *nv - 1;
    for (iv = 1; iv <= i__2; ++iv) {
/* Writing concatenation */
	i__1[0] = lenline, a__1[0] = notexq;
	i__1[1] = 1, a__1[1] = sepsymq + iv;
	s_cat(notexq, a__1, i__1, &c__2, 79L);
	++lenline;
/* L22: */
    }
/* Writing concatenation */
    i__3[0] = lenline, a__2[0] = notexq;
    i__3[1] = 1, a__2[1] = sq;
    i__3[2] = 10, a__2[2] = "zcharnote{";
    s_cat(notexq, a__2, i__3, &c__3, 79L);
    lenline += 11;
    if (! comtitl_1.headlog) {
	comtitl_1.inhead = *inhnoh;
    }
    if (*vshrink) {
	comtitl_1.inhead = 16;
    }
    r__1 = comtitl_1.inhead + (float).01;
    ndig = (integer) r_lg10(&r__1) + 1;
    i__2 = lenline;
    ici__1.icierr = 0;
    ici__1.icirnum = 1;
    ici__1.icirlen = lenline + ndig + 10 - i__2;
    ici__1.iciunit = notexq + i__2;
/* Writing concatenation */
    i__3[0] = 2, a__2[0] = "(i";
    *(unsigned char *)&ch__2[0] = ndig + 48;
    i__3[1] = 1, a__2[1] = ch__2;
    i__3[2] = 5, a__2[2] = ",a10)";
    ici__1.icifmt = (s_cat(ch__1, a__2, i__3, &c__3, 8L), ch__1);
    s_wsfi(&ici__1);
    do_fio(&c__1, (char *)&comtitl_1.inhead, (ftnlen)sizeof(integer));
/* Writing concatenation */
    i__4[0] = 2, a__3[0] = "}{";
    i__4[1] = 1, a__3[1] = sq;
    i__4[2] = 7, a__3[2] = "titles{";
    s_cat(ch__3, a__3, i__4, &c__3, 10L);
    do_fio(&c__1, ch__3, 10L);
    e_wsfi();
    lenline = lenline + ndig + 10;

/*  Vertical skip at top of page (\Il) = etatop*glueil.  Needed whether */
/*    headers are present or not. */

    glueil = *xnsttop / *etatop;
    vskil = *etatop * glueil;
    if (*vshrink) {
	vskil = (float)2.;
    }
    writflot_(&vskil, notexq, &lenline, 79L);
    if (! comtitl_1.headlog) {
	s_wsfe(&io___361);
/* Writing concatenation */
	i__5[0] = lenline, a__4[0] = notexq;
	i__5[1] = 17, a__4[1] = "}{}{0}{}{0}{}{0}}";
	i__5[2] = 1, a__4[2] = sq;
	i__5[3] = 3, a__4[3] = "en%";
	s_cat(ch__4, a__4, i__5, &c__4, 100L);
	do_fio(&c__1, ch__4, lenline + 21);
	e_wsfe();
    } else {
/* Writing concatenation */
	i__1[0] = lenline, a__1[0] = notexq;
	i__1[1] = 2, a__1[1] = "}{";
	s_cat(notexq, a__1, i__1, &c__2, 79L);
	lenline += 2;
	lcq = lc_(comtitl_1.instrq, &c__60, 60L);
	if (lcq > 0) {
	    xitil = *etait * glueil;
	    if (*vshrink) {
		xitil = (float)2.;
	    }
/* Writing concatenation */
	    i__3[0] = lenline, a__2[0] = notexq;
	    i__3[1] = lcq, a__2[1] = comtitl_1.instrq;
	    i__3[2] = 2, a__2[2] = "}{";
	    s_cat(notexq, a__2, i__3, &c__3, 79L);
	    lenline = lenline + lcq + 2;
	    writflot_(&xitil, notexq, &lenline, 79L);
	} else {
/* Writing concatenation */
	    i__1[0] = lenline, a__1[0] = notexq;
	    i__1[1] = 3, a__1[1] = "}{0";
	    s_cat(notexq, a__1, i__1, &c__2, 79L);
	    lenline += 3;
	}
	s_wsfe(&io___364);
/* Writing concatenation */
	i__1[0] = lenline, a__1[0] = notexq;
	i__1[1] = 2, a__1[1] = "}%";
	s_cat(ch__5, a__1, i__1, &c__2, 81L);
	do_fio(&c__1, ch__5, lenline + 2);
	e_wsfe();
	s_copy(notexq, "{", 79L, 1L);
	lenline = 1;
	lcq = lc_(comtitl_1.titleq, &c__60, 60L);
	if (lcq > 0) {
/* Writing concatenation */
	    i__1[0] = lenline, a__1[0] = notexq;
	    i__1[1] = lcq, a__1[1] = comtitl_1.titleq;
	    s_cat(notexq, a__1, i__1, &c__2, 79L);
	    lenline += lcq;
	} else {
	    s_wsle(&io___365);
	    e_wsle();
	    s_wsle(&io___366);
	    do_lio(&c__9, &c__1, "WARNING", 7L);
	    e_wsle();
	    s_wsle(&io___367);
	    do_lio(&c__9, &c__1, "  In a title block, you have specified ins\
trument and/or", 56L);
	    e_wsle();
	    s_wsle(&io___368);
	    do_lio(&c__9, &c__1, "  composer but no title for the piece.  To\
 suspend", 50L);
	    e_wsle();
	    s_paus("  processing hit <ctrl-break>, or <enter> to continue.", 
		    54L);
	}
/* Writing concatenation */
	i__1[0] = lenline, a__1[0] = notexq;
	i__1[1] = 2, a__1[1] = "}{";
	s_cat(notexq, a__1, i__1, &c__2, 79L);
	lenline += 2;
	xtcil = *etatc * glueil;
	lcq = lc_(comtitl_1.compoq, &c__60, 60L);
	if (lcq == 0) {
	    xtcil *= 2;
	}
	if (*vshrink) {
	    xtcil = (float)2.;
	}
	writflot_(&xtcil, notexq, &lenline, 79L);
/* Writing concatenation */
	i__1[0] = lenline, a__1[0] = notexq;
	i__1[1] = 2, a__1[1] = "}{";
	s_cat(notexq, a__1, i__1, &c__2, 79L);
	lenline += 2;
	if (lcq > 0) {
/* Writing concatenation */
	    i__3[0] = lenline, a__2[0] = notexq;
	    i__3[1] = lcq, a__2[1] = comtitl_1.compoq;
	    i__3[2] = 2, a__2[2] = "}{";
	    s_cat(notexq, a__2, i__3, &c__3, 79L);
	    lenline = lenline + 2 + lcq;
	    xcsil = *etacs1 * glueil;
	    if (*vshrink) {
		xcsil = (float)2.;
	    }
	    writflot_(&xcsil, notexq, &lenline, 79L);
	} else {
/* Writing concatenation */
	    i__1[0] = lenline, a__1[0] = notexq;
	    i__1[1] = 3, a__1[1] = "}{0";
	    s_cat(notexq, a__1, i__1, &c__2, 79L);
	    lenline += 3;
	}
	s_wsfe(&io___371);
/* Writing concatenation */
	i__5[0] = lenline, a__4[0] = notexq;
	i__5[1] = 2, a__4[1] = "}}";
	i__5[2] = 1, a__4[2] = sq;
	i__5[3] = 3, a__4[3] = "en%";
	s_cat(ch__6, a__4, i__5, &c__4, 85L);
	do_fio(&c__1, ch__6, lenline + 6);
	e_wsfe();
	comtitl_1.headlog = FALSE_;
    }
    return 0;
} /* puttitle_ */

/* Subroutine */ int getnote_(loop)
logical *loop;
{
    /* System generated locals */
    address a__1[2], a__2[14], a__3[7];
    integer i__1, i__2, i__3, i__4, i__5[2], i__6[14], i__7[7];
    char ch__1[46], ch__2[7], ch__3[15], ch__4[10];
    cllist cl__1;
    alist al__1;

    /* Builtin functions */
    integer s_wsle(), do_lio(), e_wsle(), s_cmp();
    /* Subroutine */ int s_stop();
    integer i_indx(), lbit_shift(), s_rsfe(), do_fio(), e_rsfe();
    /* Subroutine */ int s_copy(), s_cat();
    integer s_wsfe(), e_wsfe(), f_clos(), f_rew();

    /* Local variables */
    static integer iadj, nadj, nole, ioct;
    static char dotq[1], dumq[1], durq[1];
    static real fnum;
    static integer nnnl, itup, ndxm, ntup;
    extern integer igetbits_();
    static integer idotform, nfig1;
    extern /* Subroutine */ int mrec1_();
    static integer j;
    static char charq[1], lineq[128];
    static integer ifnum;
    extern /* Subroutine */ int readmeter_(), sslur_();
    static integer ic;
    static char hdlndq[59];
    static integer numnum;
    extern /* Subroutine */ int getorn_();
    static integer nnlivx;
    extern /* Subroutine */ int littex_(), getfig_();
    static integer nnliiv, ing, ipm;
    extern /* Subroutine */ int getchar_();
    static integer ndx;
    extern /* Subroutine */ int readnum_();
    static integer lenbeat, iofforn;
    extern integer ifnolev_();
    static real xofforn;
    static integer numshft;
    extern /* Subroutine */ int setbits_();
    extern integer ifnodur_();
    static logical pg1r;
    static real fmovbrk;
    static integer isl;
    extern integer numclef_();
    static integer iiv, itother, iip, npg1, num1, lvoltxt;

    /* Fortran I/O blocks */
    static cilist io___374 = { 0, 6, 0, 0, 0 };
    static cilist io___381 = { 0, 6, 0, 0, 0 };
    static cilist io___394 = { 0, 6, 0, 0, 0 };
    static cilist io___399 = { 0, 6, 0, 0, 0 };
    static cilist io___400 = { 0, 10, 0, "(a)", 0 };
    static cilist io___402 = { 0, 6, 0, 0, 0 };
    static cilist io___403 = { 0, 10, 0, "(a)", 0 };
    static cilist io___404 = { 0, 6, 0, 0, 0 };
    static cilist io___411 = { 0, 6, 0, 0, 0 };
    static cilist io___414 = { 0, 11, 0, "(a)", 0 };
    static cilist io___418 = { 0, 11, 0, "(a)", 0 };
    static cilist io___419 = { 0, 11, 0, "(a7,i1,a1)", 0 };
    static cilist io___420 = { 0, 11, 0, "(a7,i2,a1)", 0 };
    static cilist io___421 = { 0, 11, 0, "(a7,i3,a1)", 0 };
    static cilist io___422 = { 0, 10, 0, "(a)", 0 };
    static cilist io___423 = { 0, 10, 0, "(a)", 0 };
    static cilist io___424 = { 0, 10, 0, "(a)", 0 };
    static cilist io___425 = { 0, 11, 0, "(a)", 0 };
    static cilist io___426 = { 0, 11, 0, "(a)", 0 };
    static cilist io___430 = { 0, 10, 0, "(a)", 0 };



/*  nvmx is either 1 or 2.  ivmx(iv,1)=iv, ; ivmx(iv,2)>nv if defined */
/*  ivx is current ivmx, and is the index for all notes, acc's etc. */

L1:
    getchar_(lineq, &all_1.iccount, charq, 128L, 1L);
    if (comget_1.lastchar) {
	return 0;
    }
    if (*(unsigned char *)charq == ' ') {
	goto L1;
    }
    if (*(unsigned char *)charq == '%') {
	all_1.iccount = 128;
	goto L1;
    }

/* Closing repeat iff charq='/' and the prev. char was 'R' with 'l' or 'r'
*/

    if (comget_1.rptprev) {
	if (*(unsigned char *)charq != '/') {
	    comget_1.rptprev = FALSE_;
	} else {
	    s_wsle(&io___374);
	    do_lio(&c__9, &c__1, "Setting rptfin=true, ivx,nnl:", 29L);
	    do_lio(&c__3, &c__1, (char *)&commvl_1.ivx, (ftnlen)sizeof(
		    integer));
	    do_lio(&c__3, &c__1, (char *)&all_1.nnl[commvl_1.ivx - 1], (
		    ftnlen)sizeof(integer));
	    e_wsle();
	    comget_1.rptfin = TRUE_;
	}
    }

/*  Repeat at end of a piece */

    if (*(unsigned char *)charq >= 97 && *(unsigned char *)charq <= 103 || *(
	    unsigned char *)charq == 'r') {

/*  This is a note/rest.  Increase note count, then loop 'til blank */

	idotform = 0;
	numnum = 0;
	if (all_1.nnl[commvl_1.ivx - 1] == 0 && comnotes_1.ndlev[commvl_1.ivx 
		- 1] > 0) {
	    comnotes_1.lastlev = comnotes_1.ndlev[commvl_1.ivx - 1];
	}
	comnotes_1.notcrd = TRUE_;

/*  notcrd is used to tell if orn. goes on main note or chord note */

L28:
	++all_1.nnl[commvl_1.ivx - 1];
	if (comget_1.ornrpt) {
	    all_1.iornq[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 8] |=
		     all_1.iornq[commvl_1.ivx + (all_1.nnl[commvl_1.ivx - 1] 
		    - 1) * 7 - 8] & 1638383;
	    if ((all_1.iornq[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 
		    8] & 32896) > 0) {

/*  This is a trill (bit 7 or 15) so must dup the parameters 
*/

		++comtrill_1.ntrill;
		comtrill_1.ivtrill[comtrill_1.ntrill - 1] = commvl_1.ivx;
		comtrill_1.iptrill[comtrill_1.ntrill - 1] = all_1.nnl[
			commvl_1.ivx - 1];
		comtrill_1.xnsktr[comtrill_1.ntrill - 1] = comtrill_1.xnsktr[
			comtrill_1.ntrill - 2];
	    }
	}
	if (comget_1.fbon) {
	    all_1.ipl[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 8] = 
		    bit_set(all_1.ipl[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 
		    1] * 7 - 8],30);
	}
	*(unsigned char *)dotq = 'x';
	if (*(unsigned char *)charq == 'r') {
	    all_1.irest[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 8] = 
		    bit_set(all_1.irest[commvl_1.ivx + all_1.nnl[commvl_1.ivx 
		    - 1] * 7 - 8],0);
	}
	if (bit_test(all_1.irest[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 
		7 - 8],0)) {

/*  Rest stuff.  First check if previous note was full-bar-pause 
*/

	    i__1 = all_1.iccount;
	    if (s_cmp(lineq + i__1, " ", all_1.iccount + 1 - i__1, 1L) == 0 &&
		     all_1.nnl[commvl_1.ivx - 1] > 1) {
		if (bit_test(all_1.irest[commvl_1.ivx + (all_1.nnl[
			commvl_1.ivx - 1] - 1) * 7 - 8],0) && all_1.nodur[
			commvl_1.ivx + (all_1.nnl[commvl_1.ivx - 1] - 1) * 7 
			- 8] == all_1.lenbar) {
		    all_1.islur[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 
			    7 - 8] = bit_set(all_1.islur[commvl_1.ivx + 
			    all_1.nnl[commvl_1.ivx - 1] * 7 - 8],19);
		}
	    }

/* Set default rest level at 0 unless 2 voices/staff in which case
 it's -4 or 2*/
/*  for voice a or b.  Set a-types at 0 as encountered and adjust 
later */
/*  after '//'.  (Override heights will be set at 100+offset) */

	    if (commvl_1.ivx <= all_1.nv) {
		all_1.nolev[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 
			8] = 0;
	    } else {
		all_1.nolev[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 
			8] = 2;
	    }
	}
L2:
	getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	ic = *(unsigned char *)durq;
	if (ic <= 57 && ic >= 48) {

/*  Digit */

	    if (numnum == 0) {
		comnotes_1.nnodur = ic - 48;
		numnum = 1;
		goto L2;
	    } else if (numnum == 1) {
		ioct = ic - 48;
		numnum = 2;
		goto L2;
	    } else {
		s_wsle(&io___381);
		do_lio(&c__9, &c__1, ">2 digits in note sym., ivx,nn:", 31L);
		do_lio(&c__3, &c__1, (char *)&commvl_1.ivx, (ftnlen)sizeof(
			integer));
		do_lio(&c__3, &c__1, (char *)&all_1.nnl[commvl_1.ivx - 1], (
			ftnlen)sizeof(integer));
		e_wsle();
		s_stop("", 0L);
	    }
	} else if (*(unsigned char *)durq == 'd') {
	    *(unsigned char *)dotq = *(unsigned char *)durq;
	    i__1 = all_1.iccount;
	    if (i_indx("+-", lineq + i__1, 2L, all_1.iccount + 1 - i__1) > 0) 
		    {

/*  move a dot, unless next char is not part of a number */

		i__1 = all_1.iccount + 1;
		if (i_indx("0123456789.", lineq + i__1, 11L, all_1.iccount + 
			2 - i__1) == 0) {
		    goto L2;
		}
		all_1.irest[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 
			8] = bit_set(all_1.irest[commvl_1.ivx + all_1.nnl[
			commvl_1.ivx - 1] * 7 - 8],19);
		getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
		++comcc_1.ndotmv[commvl_1.ivx - 1];
		++all_1.iccount;
		readnum_(lineq, &all_1.iccount, dumq, &comcc_1.updot[
			commvl_1.ivx + comcc_1.ndotmv[commvl_1.ivx - 1] * 7 - 
			8], 128L, 1L);
		if (*(unsigned char *)durq == '-') {
		    comcc_1.updot[commvl_1.ivx + comcc_1.ndotmv[commvl_1.ivx 
			    - 1] * 7 - 8] = -comcc_1.updot[commvl_1.ivx + 
			    comcc_1.ndotmv[commvl_1.ivx - 1] * 7 - 8];
		}
		if (i_indx("+-", dumq, 2L, 1L) > 0) {

/*  Vertical shift also */

		    ++all_1.iccount;
		    readnum_(lineq, &all_1.iccount, durq, &comcc_1.rtdot[
			    commvl_1.ivx + comcc_1.ndotmv[commvl_1.ivx - 1] * 
			    7 - 8], 128L, 1L);
		    if (*(unsigned char *)dumq == '-') {
			comcc_1.rtdot[commvl_1.ivx + comcc_1.ndotmv[
				commvl_1.ivx - 1] * 7 - 8] = -comcc_1.rtdot[
				commvl_1.ivx + comcc_1.ndotmv[commvl_1.ivx - 
				1] * 7 - 8];
		    }
		} else {
		    comcc_1.rtdot[commvl_1.ivx + comcc_1.ndotmv[commvl_1.ivx 
			    - 1] * 7 - 8] = (float)0.;
		}
		--all_1.iccount;
	    }
	    goto L2;
	} else if (*(unsigned char *)durq == 'p') {

/*  Full-bar rest as pause */

	    all_1.islur[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 8] = 
		    bit_set(all_1.islur[commvl_1.ivx + all_1.nnl[commvl_1.ivx 
		    - 1] * 7 - 8],19);
	    goto L2;
	} else if (*(unsigned char *)durq == 'b') {

/*  Blank rest */

	    all_1.islur[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 8] = 
		    bit_set(all_1.islur[commvl_1.ivx + all_1.nnl[commvl_1.ivx 
		    - 1] * 7 - 8],29);
	    goto L2;
	} else if (i_indx("fsn", durq, 3L, 1L) > 0) {

/*  Accidental */

	    if (*(unsigned char *)&all_1.accq[commvl_1.ivx + all_1.nnl[
		    commvl_1.ivx - 1] * 7 - 8] != *(unsigned char *)durq) {
		*(unsigned char *)&all_1.accq[commvl_1.ivx + all_1.nnl[
			commvl_1.ivx - 1] * 7 - 8] = *(unsigned char *)durq;
	    } else {
		*(unsigned char *)&all_1.accq[commvl_1.ivx + all_1.nnl[
			commvl_1.ivx - 1] * 7 - 8] = (char) (*(unsigned char *
			)durq + 1);
	    }
	    goto L2;
	} else if (i_indx("+-", durq, 2L, 1L) > 0) {
	    ipm = i_indx("- +", durq, 3L, 1L) - 2;
	    if (! bit_test(all_1.irest[commvl_1.ivx + all_1.nnl[commvl_1.ivx 
		    - 1] * 7 - 8],0)) {
		if (numnum < 2) {
		    comnotes_1.lastlev += ipm * 7;
		} else {
		    ioct += ipm;
		}
		goto L2;
	    } else {

/*  Override default height; raise a rest */

		getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
		readnum_(lineq, &all_1.iccount, durq, &fnum, 128L, 1L);
		i__1 = all_1.iccount - 2;
		if (s_cmp(lineq + i__1, ".", all_1.iccount - 1 - i__1, 1L) == 
			0) {

/*  Kluge in case there is a shortcut ".". It will have be
en sucked up by */
/*  readnum.  (Same doesn't hold for ",") */

		    all_1.iccount += -2;
		    goto L2;
		}
		all_1.nolev[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 
			8] = ipm * (integer) (fnum + (float).1) + 100;

/*  There may be more characters for this rest */

		--all_1.iccount;
		goto L2;
	    }
	} else if (*(unsigned char *)durq == 'x') {

/* xtuplet: Set all durations to 0 except last one.  Next input wi
ll be digit*/

	    ++all_1.iccount;
	    readnum_(lineq, &all_1.iccount, durq, &fnum, 128L, 1L);
	    ntup = (integer) (fnum + (float).1);

/*  Only other possibilities here are ' ' or 'n' */

	    if (*(unsigned char *)durq == 'n') {

/*  Alter xtup number */

		i__1 = all_1.iccount;
		if (s_cmp(lineq + i__1, " ", all_1.iccount + 1 - i__1, 1L) == 
			0) {

/*  If the only modifier is 'n', cancel the number */

		    all_1.islur[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 
			    7 - 8] = bit_set(all_1.islur[commvl_1.ivx + 
			    all_1.nnl[commvl_1.ivx - 1] * 7 - 8],31);
		} else {
		    numshft = 0;
L30:
		    getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
		    if (*(unsigned char *)durq == 'f') {

/*  Flip up-down-ness */

			all_1.irest[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1]
				 * 7 - 8] = bit_set(all_1.irest[commvl_1.ivx 
				+ all_1.nnl[commvl_1.ivx - 1] * 7 - 8],14);
			goto L30;
		    } else if (*(unsigned char *)durq != ' ') {

/*  Vertical or horiz shift; durq must be +/- */

			++numshft;
			iofforn = 1;
			if (*(unsigned char *)durq == '-') {
			    iofforn = -1;
			}
			++all_1.iccount;
			readnum_(lineq, &all_1.iccount, durq, &xofforn, 128L, 
				1L);
			--all_1.iccount;
			if (numshft == 1) {

/*  Vertical shift */

			    iofforn = iofforn * (integer) (xofforn + (float)
				    .1) + 16;

/*  Turn on bit 1; set bits 2-6 to iofforn */

			    all_1.irest[commvl_1.ivx + all_1.nnl[commvl_1.ivx 
				    - 1] * 7 - 8] |= (iofforn << 2) + 2;
			} else {

/*  Horizontal shift */

			    iofforn = iofforn * (integer) (xofforn * 10 + (
				    float).01) + 16;
			    all_1.irest[commvl_1.ivx + all_1.nnl[commvl_1.ivx 
				    - 1] * 7 - 8] = bit_set(all_1.irest[
				    commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1]
				     * 7 - 8],7);
			    all_1.irest[commvl_1.ivx + all_1.nnl[commvl_1.ivx 
				    - 1] * 7 - 8] |= iofforn << 9;
			}
			goto L30;
		    }
		}
	    }
	    if (numnum == 2) {
		comnotes_1.lastlev = ifnolev_(charq, &ioct, 1L);
		all_1.nolev[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 
			8] = comnotes_1.lastlev;
	    } else {
		comnotes_1.lastlev = comnotes_1.lastlev - 3 + (ifnolev_(charq,
			 &c__10, 1L) - comnotes_1.lastlev + 3) % 7;
		all_1.nolev[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 
			8] = comnotes_1.lastlev;
	    }
	    for (comnotes_1.npreslur = comnotes_1.npreslur; 
		    comnotes_1.npreslur >= 1; --comnotes_1.npreslur) {

/*  Set note level for preslur on starting note of xtuplet */

		setbits_(&all_1.isdat2[all_1.nsdat - comnotes_1.npreslur], &
			c__7, &c__19, &comnotes_1.lastlev);
/* L40: */
	    }
	    numnum = 0;
	    all_1.nodur[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 8] = 
		    0;
	    i__1 = ntup;
	    for (itup = 2; itup <= i__1; ++itup) {
		if (comget_1.ornrpt) {
		    all_1.iornq[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 
			    7 - 8] |= all_1.iornq[commvl_1.ivx + (all_1.nnl[
			    commvl_1.ivx - 1] - 1) * 7 - 8] & 1638383;
		    if ((all_1.iornq[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 
			    1] * 7 - 8] & 32896) > 0) {

/*  This is a trill (bit 7 or 15) so must dup the para
meters */

			++comtrill_1.ntrill;
			comtrill_1.ivtrill[comtrill_1.ntrill - 1] = 
				commvl_1.ivx;
			comtrill_1.iptrill[comtrill_1.ntrill - 1] = all_1.nnl[
				commvl_1.ivx - 1];
			comtrill_1.xnsktr[comtrill_1.ntrill - 1] = 
				comtrill_1.xnsktr[comtrill_1.ntrill - 2];
		    }
		}
		++all_1.nnl[commvl_1.ivx - 1];
		if (comget_1.fbon) {
		    all_1.ipl[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 
			    - 8] = bit_set(all_1.ipl[commvl_1.ivx + all_1.nnl[
			    commvl_1.ivx - 1] * 7 - 8],30);
		}
L7:
		getchar_(lineq, &all_1.iccount, charq, 128L, 1L);
		if (*(unsigned char *)charq == ' ') {
		    goto L7;
		} else if (*(unsigned char *)charq == 'o') {

/*  Ornament in xtuplet.  "o" symbol must come AFTER the a
ffected note */

		    if (comnotes_1.notcrd) {
			nole = all_1.nolev[commvl_1.ivx + (all_1.nnl[
				commvl_1.ivx - 1] - 1) * 7 - 8];
		    } else {
			nole = 127 & lbit_shift(comtrill_1.icrdat[
				comtrill_1.ncrd - 1], -12L);
		    }
/* Computing MAX */
		    i__2 = 1, i__3 = all_1.nnl[commvl_1.ivx - 1] - 2;
		    i__4 = all_1.nnl[commvl_1.ivx - 1] - 1;
		    getorn_(lineq, &all_1.iccount, &all_1.iornq[commvl_1.ivx 
			    + (all_1.nnl[commvl_1.ivx - 1] - 1) * 7 - 8], &
			    all_1.iornq[commvl_1.ivx + max(i__2,i__3) * 7 - 8]
			    , &comget_1.ornrpt, &comgrace_1.noffseg, &i__4, &
			    commvl_1.ivx, &c_false, &comnotes_1.notcrd, &nole,
			     128L);
		    goto L7;
		} else if (i_indx("st()", charq, 4L, 1L) > 0) {
		    nnlivx = all_1.nnl[commvl_1.ivx - 1] - 1;
		    if (*(unsigned char *)charq == '(') {

/*  Detected preslur in xtuplet loop, non-chord note 
*/

			++nnlivx;
			++comnotes_1.npreslur;
		    }
		    all_1.islur[commvl_1.ivx + nnlivx * 7 - 8] = bit_set(
			    all_1.islur[commvl_1.ivx + nnlivx * 7 - 8],0);
		    if (*(unsigned char *)charq == 't') {
			all_1.islur[commvl_1.ivx + nnlivx * 7 - 8] = bit_set(
				all_1.islur[commvl_1.ivx + nnlivx * 7 - 8],1);
		    }
		    sslur_(lineq, &all_1.iccount, &commvl_1.ivx, &nnlivx, 
			    all_1.isdat1, all_1.isdat2, &all_1.nsdat, &
			    comnotes_1.notcrd, &all_1.nolev[commvl_1.ivx + 
			    nnlivx * 7 - 8], 128L);
		    goto L7;
		} else if (*(unsigned char *)charq == *(unsigned char *)
			all_1.sq) {
		    littex_(all_1.islur, &all_1.nnl[commvl_1.ivx - 1], &
			    commvl_1.ivx, &comas3_1.topmods, lineq, &
			    all_1.iccount, 128L);
		    goto L7;
		} else if (i_indx("0123456789#-nx_", charq, 15L, 1L) > 0) {

/*  Figure.  Must come AFTER the first note of xtup */

		    nfig1 = comfig_1.nfigs + 1;
		    getfig_(&comgrace_1.itoff[nfig1 - 1], charq, lineq, &
			    all_1.iccount, &all_1.isfig[all_1.nnl[
			    commvl_1.ivx - 1] - 1], &comfig_1.itfig[nfig1 - 1]
			    , all_1.itsofar, &c__0, comfig_1.figq + (nfig1 - 
			    1) * 6, &commvl_1.ivx, &comfig_1.nfigs, 1L, 128L, 
			    6L);
		    goto L7;
		} else if (*(unsigned char *)charq == 'X') {
		    getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
		    if (i_indx("+-", durq, 2L, 1L) > 0) {
			++all_1.iccount;
		    }
		    readnum_(lineq, &all_1.iccount, dumq, &fnum, 128L, 1L);
		    if (*(unsigned char *)durq == '-') {
			fnum = -fnum;
		    }
		    if (*(unsigned char *)dumq != 'p') {
			fnum *= comask_2.wheadpt;
		    } else {
			getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
		    }

/*  User-defined hardspace in xtup.  Goes before next note
. */
/*    (At "|" or "/" check for presence and shift to udoff
 if there) <= later*/

		    ++comudsp_1.nuxsp;
		    all_1.irest[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 
			    7 - 8] = bit_set(all_1.irest[commvl_1.ivx + 
			    all_1.nnl[commvl_1.ivx - 1] * 7 - 8],21);
		    comudsp_1.uxsp[comudsp_1.nuxsp - 1] = fnum;
		    comudsp_1.ipuxsp[comudsp_1.nuxsp - 1] = all_1.nnl[
			    commvl_1.ivx - 1];
		    comudsp_1.ivuxsp[comudsp_1.nuxsp - 1] = commvl_1.ivx;
		    goto L7;
		} else if (*(unsigned char *)charq == 'z') {

/*  Chord note in xtup.  Goes with *prior* note. */

		    comnotes_1.notcrd = FALSE_;
		    ++comtrill_1.ncrd;
		    all_1.ipl[commvl_1.ivx + (all_1.nnl[commvl_1.ivx - 1] - 1)
			     * 7 - 8] = bit_set(all_1.ipl[commvl_1.ivx + (
			    all_1.nnl[commvl_1.ivx - 1] - 1) * 7 - 8],10);
		    numnum = 0;
		    comtrill_1.icrdat[comtrill_1.ncrd - 1] = all_1.nnl[
			    commvl_1.ivx - 1] - 1 | commvl_1.ivx << 8;
		    comtrill_1.icrdorn[comtrill_1.ncrd - 1] = 0;

/*  Get note name */

		    getchar_(lineq, &all_1.iccount, charq, 128L, 1L);

/*  Get optional inputs */

L34:
		    getchar_(lineq, &all_1.iccount, durq, 128L, 1L);

/*  When chord note is done, get ' ', making ndx=0, so go 
past this block */

		    ndx = i_indx("nfs+-12345678re", durq, 15L, 1L);
		    if (ndx > 0) {
			if (ndx <= 3) {
			    if (! bit_test(comtrill_1.icrdat[comtrill_1.ncrd 
				    - 1],19)) {
				comtrill_1.icrdat[comtrill_1.ncrd - 1] = 
					bit_set(comtrill_1.icrdat[
					comtrill_1.ncrd - 1],19);
				comtrill_1.icrdat[comtrill_1.ncrd - 1] |= ndx 
					<< 20;
			    } else {
				comtrill_1.icrdat[comtrill_1.ncrd - 1] = 
					bit_set(comtrill_1.icrdat[
					comtrill_1.ncrd - 1],22);
			    }
			} else if (*(unsigned char *)durq == '+') {
			    comnotes_1.lastlev += 7;
			} else if (*(unsigned char *)durq == '-') {
			    comnotes_1.lastlev += -7;
			} else if (*(unsigned char *)durq == 'e') {
			    comtrill_1.icrdat[comtrill_1.ncrd - 1] = bit_set(
				    comtrill_1.icrdat[comtrill_1.ncrd - 1],23)
				    ;
			} else if (*(unsigned char *)durq == 'r') {
			    comtrill_1.icrdat[comtrill_1.ncrd - 1] = bit_set(
				    comtrill_1.icrdat[comtrill_1.ncrd - 1],24)
				    ;
			    all_1.irest[commvl_1.ivx + (all_1.nnl[
				    commvl_1.ivx - 1] - 1) * 7 - 8] = bit_set(
				    all_1.irest[commvl_1.ivx + (all_1.nnl[
				    commvl_1.ivx - 1] - 1) * 7 - 8],20);
			} else {

/* must be a number, save it in ioct */

			    numnum = 1;
			    ioct = ndx - 5;
			}
			goto L34;
		    }
		    if (numnum == 1) {
			comnotes_1.lastlev = ifnolev_(charq, &ioct, 1L);
		    } else {
			comnotes_1.lastlev = comnotes_1.lastlev - 3 + (
				ifnolev_(charq, &c__10, 1L) - 
				comnotes_1.lastlev + 3) % 7;
		    }
		    comtrill_1.icrdat[comtrill_1.ncrd - 1] |= 
			    comnotes_1.lastlev << 12;
		    for (comnotes_1.npreslur = comnotes_1.npreslur; 
			    comnotes_1.npreslur >= 1; --comnotes_1.npreslur) {

/*  Set note level for preslur on chord note in xtup 
*/

			setbits_(&all_1.isdat2[all_1.nsdat - 
				comnotes_1.npreslur], &c__7, &c__19, &
				comnotes_1.lastlev);
/* L41: */
		    }
		    goto L7;
		}

/* End of loop for xtup options. If here, charq must be a (non
-crd) note name.*/

		comnotes_1.notcrd = TRUE_;
L8:
		getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
		if (*(unsigned char *)durq != ' ') {
		    if (*(unsigned char *)durq == '+') {
			comnotes_1.lastlev += 7;
		    } else if (*(unsigned char *)durq == '-') {
			comnotes_1.lastlev += -7;
		    } else if (i_indx("fsn", durq, 3L, 1L) > 0) {
			if (*(unsigned char *)&all_1.accq[commvl_1.ivx + 
				all_1.nnl[commvl_1.ivx - 1] * 7 - 8] != *(
				unsigned char *)durq) {
			    *(unsigned char *)&all_1.accq[commvl_1.ivx + 
				    all_1.nnl[commvl_1.ivx - 1] * 7 - 8] = *(
				    unsigned char *)durq;
			} else {
			    *(unsigned char *)&all_1.accq[commvl_1.ivx + 
				    all_1.nnl[commvl_1.ivx - 1] * 7 - 8] = (
				    char) (*(unsigned char *)durq + 1);
			}
		    }
		    goto L8;
		}
		if (itup < ntup) {

/* Last note is handled *after* flowing out of the xtup if
 block, but still*/
/*    within block for a note-rest. */

		    comnotes_1.lastlev = comnotes_1.lastlev - 3 + (ifnolev_(
			    charq, &c__10, 1L) - comnotes_1.lastlev + 3) % 7;
		    all_1.nolev[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 
			    7 - 8] = comnotes_1.lastlev;
		    all_1.nodur[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 
			    7 - 8] = 0;
		    for (comnotes_1.npreslur = comnotes_1.npreslur; 
			    comnotes_1.npreslur >= 1; --comnotes_1.npreslur) {

/*  Set note level for preslur on internal xtup note 
*/

			setbits_(&all_1.isdat2[all_1.nsdat - 
				comnotes_1.npreslur], &c__7, &c__19, &
				comnotes_1.lastlev);
/* L42: */
		    }
		}
/* L6: */
	    }
	    if (comget_1.ornrpt) {
		all_1.iornq[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 
			8] |= all_1.iornq[commvl_1.ivx + (all_1.nnl[
			commvl_1.ivx - 1] - 1) * 7 - 8] & 1638383;
		if ((all_1.iornq[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 
			7 - 8] & 32896) > 0) {

/*  This is a trill (bit 7 or 15) so must dup the paramete
rs */

		    ++comtrill_1.ntrill;
		    comtrill_1.ivtrill[comtrill_1.ntrill - 1] = commvl_1.ivx;
		    comtrill_1.iptrill[comtrill_1.ntrill - 1] = all_1.nnl[
			    commvl_1.ivx - 1];
		    comtrill_1.xnsktr[comtrill_1.ntrill - 1] = 
			    comtrill_1.xnsktr[comtrill_1.ntrill - 2];
		}
	    }
	} else if (*(unsigned char *)durq == 'm') {

/*  Multi-bar rest: next 1 or two digits are # of bars. */
/*  For some purposes, pretend its one bar only */

	    all_1.nodur[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 8] = 
		    all_1.lenbar;
	    comgrace_1.ibarmbr = all_1.nbars + 1;
	    comgrace_1.mbrest = 0;
	    comgrace_1.xb4mbr = (float)0.;
L20:
	    getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	    if (*(unsigned char *)durq >= 48 && *(unsigned char *)durq <= 57) 
		    {
		comgrace_1.mbrest = comgrace_1.mbrest * 10 + *(unsigned char *
			)durq - 48;
		goto L20;
	    }
	} else if (i_indx("ul", durq, 2L, 1L) > 0) {

/*  Set stem flipper */

	    all_1.islur[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 8] = 
		    bit_set(all_1.islur[commvl_1.ivx + all_1.nnl[commvl_1.ivx 
		    - 1] * 7 - 8],30);
	    if (*(unsigned char *)durq == 'u') {
		all_1.islur[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 
			8] = bit_set(all_1.islur[commvl_1.ivx + all_1.nnl[
			commvl_1.ivx - 1] * 7 - 8],17);
	    }
	    goto L2;
	} else if (*(unsigned char *)durq == 'a') {

/*  "Alone", i.e., prohibit beam */

	    all_1.islur[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 8] = 
		    bit_set(all_1.islur[commvl_1.ivx + all_1.nnl[commvl_1.ivx 
		    - 1] * 7 - 8],18);
	    goto L2;
	} else if (*(unsigned char *)durq == 'r') {

/*  Right offset by one notehead */

	    all_1.ipl[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 8] = 
		    bit_set(all_1.ipl[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 
		    1] * 7 - 8],9);
	    goto L2;
	} else if (*(unsigned char *)durq == 'e') {

/*  Left offset by one notehead */

	    all_1.ipl[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 8] = 
		    bit_set(all_1.ipl[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 
		    1] * 7 - 8],8);
	    goto L2;
	} else if (*(unsigned char *)durq == ',') {

/*  2:1 pattern */

	    idotform = 3;
	} else if (*(unsigned char *)durq == '.') {

/*  Dotted pattern.  Close out note.  Mult time by 3/4. */
/*  Set time for next note to 1/4.  Start the note. */

	    idotform = 1;

/*  Now flow to duration setting, if durq=' ' */

	} else if (*(unsigned char *)durq != ' ') {
	    s_wsle(&io___394);
	    do_lio(&c__9, &c__1, "Illegal character in note: ", 27L);
	    do_lio(&c__9, &c__1, durq, 1L);
	    do_lio(&c__9, &c__1, ", ivx,nn:", 9L);
	    do_lio(&c__3, &c__1, (char *)&commvl_1.ivx, (ftnlen)sizeof(
		    integer));
	    do_lio(&c__3, &c__1, (char *)&all_1.nnl[commvl_1.ivx - 1], (
		    ftnlen)sizeof(integer));
	    e_wsle();
	    s_stop("", 0L);
	}
	if (! bit_test(all_1.irest[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] 
		* 7 - 8],0)) {
	    if (numnum == 2) {
		comnotes_1.lastlev = ifnolev_(charq, &ioct, 1L);
		all_1.nolev[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 
			8] = comnotes_1.lastlev;
	    } else {
		comnotes_1.lastlev = comnotes_1.lastlev - 3 + (ifnolev_(charq,
			 &c__10, 1L) - comnotes_1.lastlev + 3) % 7;
		all_1.nolev[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 
			8] = comnotes_1.lastlev;
	    }
	    for (comnotes_1.npreslur = comnotes_1.npreslur; 
		    comnotes_1.npreslur >= 1; --comnotes_1.npreslur) {

/*  Set level for preslur on normal note, non-chord */

		setbits_(&all_1.isdat2[all_1.nsdat - comnotes_1.npreslur], &
			c__7, &c__19, &comnotes_1.lastlev);
/* L43: */
	    }
	}
	if (idotform > 0) {
	    if (idotform == 1) {
		all_1.nodur[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 
			8] = ifnodur_(&comnotes_1.nnodur, dotq, 1L) * 3 / 2;
	    } else if (idotform == 2) {
		all_1.nodur[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 
			8] = all_1.nodur[commvl_1.ivx + (all_1.nnl[
			commvl_1.ivx - 1] - 1) * 7 - 8] / 3;
	    } else if (idotform == 3) {
		all_1.nodur[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 
			8] = ifnodur_(&comnotes_1.nnodur, dotq, 1L);
	    } else if (idotform == 4) {
		all_1.nodur[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 
			8] = all_1.nodur[commvl_1.ivx + (all_1.nnl[
			commvl_1.ivx - 1] - 1) * 7 - 8] / 2;
	    }
	} else if (bit_test(all_1.islur[commvl_1.ivx + all_1.nnl[commvl_1.ivx 
		- 1] * 7 - 8],19)) {
	    all_1.nodur[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 8] = 
		    all_1.lenbar;
	} else if (comgrace_1.ibarmbr != all_1.nbars + 1) {
	    all_1.nodur[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 8] = 
		    ifnodur_(&comnotes_1.nnodur, dotq, 1L);
	}
	if (comnotes_1.shifton && ! bit_test(all_1.irest[commvl_1.ivx + 
		all_1.nnl[commvl_1.ivx - 1] * 7 - 8],16)) {

/* Shift is on, and this is not first shifted note.  Check for dur
ation change*/

	    if (all_1.nodur[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 
		    8] != all_1.nodur[commvl_1.ivx + (all_1.nnl[commvl_1.ivx 
		    - 1] - 1) * 7 - 8]) {

/*  Must stop and restart the offset. */

		all_1.irest[commvl_1.ivx + (all_1.nnl[commvl_1.ivx - 1] - 1) *
			 7 - 8] = bit_set(all_1.irest[commvl_1.ivx + (
			all_1.nnl[commvl_1.ivx - 1] - 1) * 7 - 8],17);
		all_1.irest[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 
			8] = bit_set(all_1.irest[commvl_1.ivx + all_1.nnl[
			commvl_1.ivx - 1] * 7 - 8],16);
		++comudsp_1.nudoff[commvl_1.ivx - 1];
		comudsp_1.udoff[commvl_1.ivx + comudsp_1.nudoff[commvl_1.ivx 
			- 1] * 7 - 8] = comudsp_1.udoff[commvl_1.ivx + (
			comudsp_1.nudoff[commvl_1.ivx - 1] - 1) * 7 - 8];
	    }
	}
	all_1.itsofar[commvl_1.ivx - 1] += all_1.nodur[commvl_1.ivx + 
		all_1.nnl[commvl_1.ivx - 1] * 7 - 8];
	if ((all_1.itsofar[commvl_1.ivx - 1] - all_1.lenb0) % all_1.lenbar == 
		0) {

/*  Finished a bar */

	    ++all_1.nbars;
	    all_1.nib[commvl_1.ivx + all_1.nbars * 7 - 8] = all_1.nnl[
		    commvl_1.ivx - 1];
	    if (all_1.firstgulp && all_1.lenb0 != 0 && all_1.nbars == 1) {

/*  Just finished the pickup bar for this voice. */

		all_1.lenbar = all_1.lenb1;
	    }
	}
	if (idotform == 1) {
	    getchar_(lineq, &all_1.iccount, charq, 128L, 1L);
	    idotform = 2;
	    numnum = 1;
	    goto L28;
	} else if (idotform == 3) {
	    getchar_(lineq, &all_1.iccount, charq, 128L, 1L);
	    idotform = 4;
	    numnum = 1;
	    goto L28;
	}

/*  End of sub block for note-rest */

    } else if (*(unsigned char *)charq == 'z') {

/*  Chord note.  Must have note name, may have octave#,+,-,s,f,n,d */
/*  Actually the 'd' is not used, since time value comes from */
/*    basic note. Unless dot is to be shifted! */
/*  Doesn't increase # of notes, so must handle separately */
/*  ncrd: index of crd */
/*  Set bit 10 of ipl as flag */
/*  Bits in icrdat: */
/*     0-7   ip within voice */
/*     8-11  ivx */
/*     12-18 note level */
/*     19    accidental? */
/*    20-22 accidental value (1=natural, 2=flat, 3=sharp, 6=dflat, 7=d
sharp)*/
/*     23    shift left */
/*     24    shift right */
/*     25    arpeggio start or stop */
/*    26    flag for moved dot (here, not icrdot, since this is always
 reset!)*/

/*  Bits in icrdot: */
/*     0-6   10*abs(vertical dot shift in \internote) + 64 */
/*     7-13  10*abs(horiaontal dot shift in \internote) + 64 */

/* Bits in icrdorn are same as in iornq, even tho most orns won't go i
n crds.*/

	++comtrill_1.ncrd;
	all_1.ipl[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 8] = 
		bit_set(all_1.ipl[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] *
		 7 - 8],10);
	numnum = 0;
	comtrill_1.icrdat[comtrill_1.ncrd - 1] = all_1.nnl[commvl_1.ivx - 1] |
		 commvl_1.ivx << 8;
	comtrill_1.icrdorn[comtrill_1.ncrd - 1] = 0;

/*  Get note name */

	getchar_(lineq, &all_1.iccount, charq, 128L, 1L);

/*  Get optional inputs */

L25:
	getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	ndx = i_indx("nfs+-12345678red", durq, 16L, 1L);
	if (ndx > 0) {
	    if (ndx <= 3) {
		if (! bit_test(comtrill_1.icrdat[comtrill_1.ncrd - 1],19)) {
		    comtrill_1.icrdat[comtrill_1.ncrd - 1] = bit_set(
			    comtrill_1.icrdat[comtrill_1.ncrd - 1],19);
		    comtrill_1.icrdat[comtrill_1.ncrd - 1] |= ndx << 20;
		} else {
		    comtrill_1.icrdat[comtrill_1.ncrd - 1] = bit_set(
			    comtrill_1.icrdat[comtrill_1.ncrd - 1],22);
		}
	    } else if (*(unsigned char *)durq == '+') {
		comnotes_1.lastlev += 7;
	    } else if (*(unsigned char *)durq == '-') {
		comnotes_1.lastlev += -7;
	    } else if (*(unsigned char *)durq == 'e') {
		comtrill_1.icrdat[comtrill_1.ncrd - 1] = bit_set(
			comtrill_1.icrdat[comtrill_1.ncrd - 1],23);
	    } else if (*(unsigned char *)durq == 'r') {
		comtrill_1.icrdat[comtrill_1.ncrd - 1] = bit_set(
			comtrill_1.icrdat[comtrill_1.ncrd - 1],24);
		all_1.irest[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 
			8] = bit_set(all_1.irest[commvl_1.ivx + all_1.nnl[
			commvl_1.ivx - 1] * 7 - 8],20);
	    } else if (*(unsigned char *)durq == 'd') {

/*  Must keep 'd' optional (backward compatibility), unless it
 is moved! */

		i__1 = all_1.iccount;
		if (i_indx("+-", lineq + i__1, 2L, all_1.iccount + 1 - i__1) 
			> 0) {

/*  move a dot, unless next char is not part of a number 
*/

		    i__1 = all_1.iccount + 1;
		    if (i_indx("0123456789.", lineq + i__1, 11L, 
			    all_1.iccount + 2 - i__1) == 0) {
			goto L25;
		    }
		    comtrill_1.icrdat[comtrill_1.ncrd - 1] = bit_set(
			    comtrill_1.icrdat[comtrill_1.ncrd - 1],26);
		    getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
		    ++all_1.iccount;
		    readnum_(lineq, &all_1.iccount, dumq, &fnum, 128L, 1L);
		    if (*(unsigned char *)durq == '+') {
			comtrill_1.icrdot[comtrill_1.ncrd - 1] = (integer) (
				fnum * 10 + (float).5) + 64;
		    } else {
			comtrill_1.icrdot[comtrill_1.ncrd - 1] = -((integer) (
				fnum * 10 + (float).5)) + 64;
		    }
		    if (i_indx("+-", dumq, 2L, 1L) > 0) {

/*  Vertical shift specified also */

			++all_1.iccount;
			readnum_(lineq, &all_1.iccount, durq, &fnum, 128L, 1L)
				;
			if (*(unsigned char *)dumq == '+') {
			    ifnum = (integer) (fnum * 10 + (float).5) + 64;
			} else {
			    ifnum = -((integer) (fnum * 10 + (float).5)) + 64;
			}
		    } else {
			ifnum = 64;
		    }
		    comtrill_1.icrdot[comtrill_1.ncrd - 1] |= ifnum << 7;
		    --all_1.iccount;
		}
	    } else {

/* must be a number, save it in ioct */

		numnum = 1;
		ioct = ndx - 5;
	    }
	    goto L25;
	}
	if (numnum == 1) {
	    comnotes_1.lastlev = ifnolev_(charq, &ioct, 1L);
	} else {
	    comnotes_1.lastlev = comnotes_1.lastlev - 3 + (ifnolev_(charq, &
		    c__10, 1L) - comnotes_1.lastlev + 3) % 7;
	}
	comtrill_1.icrdat[comtrill_1.ncrd - 1] |= comnotes_1.lastlev << 12;
	for (comnotes_1.npreslur = comnotes_1.npreslur; comnotes_1.npreslur >=
		 1; --comnotes_1.npreslur) {
	    setbits_(&all_1.isdat2[all_1.nsdat - comnotes_1.npreslur], &c__7, 
		    &c__19, &comnotes_1.lastlev);

/*  Set level for chord note. */
/*  Initially I assigned the slur(s) to next note, so fix. */

	    all_1.islur[commvl_1.ivx + (all_1.nnl[commvl_1.ivx - 1] + 1) * 7 
		    - 8] = bit_clear(all_1.islur[commvl_1.ivx + (all_1.nnl[
		    commvl_1.ivx - 1] + 1) * 7 - 8],0);
	    all_1.islur[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 8] = 
		    bit_set(all_1.islur[commvl_1.ivx + all_1.nnl[commvl_1.ivx 
		    - 1] * 7 - 8],0);
	    all_1.isdat2[all_1.nsdat - comnotes_1.npreslur] = bit_set(
		    all_1.isdat2[all_1.nsdat - comnotes_1.npreslur],0);
	    i__1 = igetbits_(&all_1.isdat1[all_1.nsdat - comnotes_1.npreslur],
		     &c__8, &c__3) - 1;
	    setbits_(&all_1.isdat1[all_1.nsdat - comnotes_1.npreslur], &c__8, 
		    &c__3, &i__1);
/* L44: */
	}
	if (comnotes_1.notcrd) {

/*  This is the first chord note in this chord. */

/* Computing MIN */
	    i__1 = all_1.nolev[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 
		    - 8];
	    comtrill_1.minlev = min(i__1,comnotes_1.lastlev);
/* Computing MAX */
	    i__1 = all_1.nolev[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 
		    - 8];
	    comtrill_1.maxlev = max(i__1,comnotes_1.lastlev);
	} else {
	    comtrill_1.minlev = min(comtrill_1.minlev,comnotes_1.lastlev);
	    comtrill_1.maxlev = max(comtrill_1.maxlev,comnotes_1.lastlev);
	}
	comnotes_1.notcrd = FALSE_;
    } else if (*(unsigned char *)charq == 'G') {

/* Grace, comes *before* main note: */
/* UNLESS there's an 'A' or 'W' after the 'G' */
/*   ngrace = # of grace note groups so far in block */
/*   ivg(ngrace), ipg(ngrace) */
/*   nng(ngrace) = # of notes in this group: default = 1 */
/*   ngstrt(ngrace) = starting position in nolevg of levels for this g
race */
/*   multg(ngrace) = multiplicity: default = 1;  input as 'm(digit)' 
*/
/*   upg(ngrace) = logical for beam or stem dirn: default T, input'u,l
' */
/*   slurg(ngrace) = logical for slur; default F, input 's' */
/*   slashg(ngrace) = T if slash; default is F, input 'x' */
/* These data MUST precede note name of first note */
/*  nolevg, accgq: lists of levels and accid's, indexed as described a
bove.*/

	++comgrace_1.ngrace;
	comgrace_1.ivg[comgrace_1.ngrace - 1] = commvl_1.ivx;
	comgrace_1.ipg[comgrace_1.ngrace - 1] = all_1.nnl[commvl_1.ivx - 1] + 
		1;
	if (comgrace_1.ngrace == 1) {
	    comgrace_1.ngstrt[comgrace_1.ngrace - 1] = 1;
	} else {
	    comgrace_1.ngstrt[comgrace_1.ngrace - 1] = comgrace_1.ngstrt[
		    comgrace_1.ngrace - 2] + comgrace_1.nng[comgrace_1.ngrace 
		    - 2];
	}
	all_1.islur[commvl_1.ivx + (all_1.nnl[commvl_1.ivx - 1] + 1) * 7 - 8] 
		= bit_set(all_1.islur[commvl_1.ivx + (all_1.nnl[commvl_1.ivx 
		- 1] + 1) * 7 - 8],4);
	comgrace_1.nng[comgrace_1.ngrace - 1] = 1;
	comgrace_1.multg[comgrace_1.ngrace - 1] = 1;
	comgrace_1.upg[comgrace_1.ngrace - 1] = TRUE_;
	comgrace_1.slurg[comgrace_1.ngrace - 1] = FALSE_;
	comgrace_1.slashg[comgrace_1.ngrace - 1] = FALSE_;
L18:
	getchar_(lineq, &all_1.iccount, charq, 128L, 1L);
	if (i_indx("WA", charq, 2L, 1L) > 0) {

/* Grace is on note that was already done, so shift flags forward 
one note.*/
/* This puts flag on actual note with grace; later for W will go a
head one more.*/

	    comgrace_1.ipg[comgrace_1.ngrace - 1] = all_1.nnl[commvl_1.ivx - 
		    1];
	    all_1.islur[commvl_1.ivx + (all_1.nnl[commvl_1.ivx - 1] + 1) * 7 
		    - 8] = bit_clear(all_1.islur[commvl_1.ivx + (all_1.nnl[
		    commvl_1.ivx - 1] + 1) * 7 - 8],4);
	    all_1.islur[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 8] = 
		    bit_set(all_1.islur[commvl_1.ivx + all_1.nnl[commvl_1.ivx 
		    - 1] * 7 - 8],4);
	    if (comgrace_1.slurg[comgrace_1.ngrace - 1]) {
		all_1.iornq[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 
			8] = bit_set(all_1.iornq[commvl_1.ivx + all_1.nnl[
			commvl_1.ivx - 1] * 7 - 8],24);
	    }
	    if (*(unsigned char *)charq == 'A') {

/* close After, clear way-after bit, to ensure priority of mos
t recent A/W*/

		all_1.ipl[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 8] 
			= bit_set(bit_clear(all_1.ipl[commvl_1.ivx + 
			all_1.nnl[commvl_1.ivx - 1] * 7 - 8],31),29);
	    } else {

/* Way after; later assign to following note, and position lik
e normal grace.*/

		all_1.ipl[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 8] 
			= bit_set(bit_clear(all_1.ipl[commvl_1.ivx + 
			all_1.nnl[commvl_1.ivx - 1] * 7 - 8],29),31);
	    }
	} else if (*(unsigned char *)charq == 'm') {
	    getchar_(lineq, &all_1.iccount, charq, 128L, 1L);
	    comgrace_1.multg[comgrace_1.ngrace - 1] = *(unsigned char *)charq 
		    - 48;
	} else if (i_indx("123456789", charq, 9L, 1L) > 0) {
	    readnum_(lineq, &all_1.iccount, durq, &fnum, 128L, 1L);
	    --all_1.iccount;
	    comgrace_1.nng[comgrace_1.ngrace - 1] = (integer) (fnum + (float)
		    .1);
	} else if (*(unsigned char *)charq == 'l') {
	    comgrace_1.upg[comgrace_1.ngrace - 1] = FALSE_;
	} else if (*(unsigned char *)charq == 's') {
	    comgrace_1.slurg[comgrace_1.ngrace - 1] = TRUE_;
	    if (all_1.nnl[commvl_1.ivx - 1] > 0) {

/*  If A- or W-grace, set signal to start slur on main note. 
*/

		if (bit_test(all_1.ipl[commvl_1.ivx + all_1.nnl[commvl_1.ivx 
			- 1] * 7 - 8],31) || bit_test(all_1.ipl[commvl_1.ivx 
			+ all_1.nnl[commvl_1.ivx - 1] * 7 - 8],29)) {
		    all_1.iornq[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 
			    7 - 8] = bit_set(all_1.iornq[commvl_1.ivx + 
			    all_1.nnl[commvl_1.ivx - 1] * 7 - 8],24);
		}
	    }
	} else if (*(unsigned char *)charq == 'x') {
	    comgrace_1.slashg[comgrace_1.ngrace - 1] = TRUE_;
	} else if (*(unsigned char *)charq == 'u') {
	}
	if (i_indx("abcdefg", charq, 7L, 1L) == 0) {
	    goto L18;
	}

/*  At this point, charq is first note name in grace */

	i__1 = comgrace_1.ngstrt[comgrace_1.ngrace - 1] + comgrace_1.nng[
		comgrace_1.ngrace - 1] - 1;
	for (ing = comgrace_1.ngstrt[comgrace_1.ngrace - 1]; ing <= i__1; 
		++ing) {
	    *(unsigned char *)&comgrace_1.accgq[ing - 1] = 'x';
	    ioct = 0;
/*          if (ing .gt. ngstrt(ngrace)) call getchar(lineq,iccoun
t,charq) */
/* ++ */
	    if (ing > comgrace_1.ngstrt[comgrace_1.ngrace - 1]) {
L55:
		getchar_(lineq, &all_1.iccount, charq, 128L, 1L);
		if (*(unsigned char *)charq == ' ') {
		    goto L55;
		}
	    }
/* ++ */
L9:
	    getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	    if (*(unsigned char *)durq != ' ') {
		if (*(unsigned char *)durq == '+') {
		    comnotes_1.lastlev += 7;
		} else if (*(unsigned char *)durq == '-') {
		    comnotes_1.lastlev += -7;
		} else if (i_indx("fsn", durq, 3L, 1L) > 0) {
		    if (*(unsigned char *)&comgrace_1.accgq[ing - 1] != *(
			    unsigned char *)durq) {
			*(unsigned char *)&comgrace_1.accgq[ing - 1] = *(
				unsigned char *)durq;
		    } else {

/*  Double accidental */

			*(unsigned char *)&comgrace_1.accgq[ing - 1] = (char) 
				(*(unsigned char *)durq + 1);
		    }
		} else {
		    ioct = *(unsigned char *)durq - 48;
		}
		goto L9;
	    }
	    if (ioct > 0) {
		comnotes_1.lastlev = ifnolev_(charq, &ioct, 1L);
	    } else {
		comnotes_1.lastlev = comnotes_1.lastlev - 3 + (ifnolev_(charq,
			 &c__10, 1L) - comnotes_1.lastlev + 3) % 7;
	    }
	    comgrace_1.nolevg[ing - 1] = comnotes_1.lastlev;
/* L19: */
	}

/*  Grace could come before first note of block, so reset end level. 
*/

	if (all_1.nnl[commvl_1.ivx - 1] == 0) {
	    comnotes_1.ndlev[commvl_1.ivx - 1] = comnotes_1.lastlev;
	}
    } else if (*(unsigned char *)charq == *(unsigned char *)all_1.sq) {

/*  Literal TeX string */

	i__1 = all_1.nnl[commvl_1.ivx - 1] + 1;
	littex_(all_1.islur, &i__1, &commvl_1.ivx, &comas3_1.topmods, lineq, &
		all_1.iccount, 128L);
    } else if (*(unsigned char *)charq == 'o') {

/*  "o" on main note.  Symbol must come AFTER the affected note */

/*        if (notcrd) then */
/*          call getorn(lineq,iccount,iornq(ivx,nnl(ivx)), */
/*     *       iornq(ivx,max(1,nnl(ivx)-1)),ornrpt,noffseg,nnl(ivx),iv
x, */
/*     *      .true.) */
/*        else */
/* c */
/* c  Since the last note gotten was a chord-note, ncrd will represent
 it. */
/*c  Disallow ornament repeat toggle with chords, so 4th arg won't be 
used.*/
/* c  Also, no trills, so args 7 & 8 aren't used. */
/* c */
/*          call getorn(lineq,iccount,icrdorn(ncrd),0, */
/*     *           .false.,noffseg,nnl(ivx)-1,ivx,.true.) */
/*        end if */

/*  Get note level, many need if level shift */

	if (comnotes_1.notcrd) {
	    nole = all_1.nolev[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 
		    - 8];
	} else {
	    nole = 127 & lbit_shift(comtrill_1.icrdat[comtrill_1.ncrd - 1], 
		    -12L);
	}
/* Computing MAX */
	i__1 = 1, i__2 = all_1.nnl[commvl_1.ivx - 1] - 1;
	getorn_(lineq, &all_1.iccount, &all_1.iornq[commvl_1.ivx + all_1.nnl[
		commvl_1.ivx - 1] * 7 - 8], &all_1.iornq[commvl_1.ivx + max(
		i__1,i__2) * 7 - 8], &comget_1.ornrpt, &comgrace_1.noffseg, &
		all_1.nnl[commvl_1.ivx - 1], &commvl_1.ivx, &c_true, &
		comnotes_1.notcrd, &nole, 128L);
    } else if (i_indx("st()", charq, 4L, 1L) > 0) {
	nnlivx = all_1.nnl[commvl_1.ivx - 1];
	if (*(unsigned char *)charq == '(') {

/* Detect preslur on normal non-chord note */

	    ++nnlivx;
	    ++comnotes_1.npreslur;
	}
	all_1.islur[commvl_1.ivx + nnlivx * 7 - 8] = bit_set(all_1.islur[
		commvl_1.ivx + nnlivx * 7 - 8],0);
	if (*(unsigned char *)charq == 't') {
	    all_1.islur[commvl_1.ivx + nnlivx * 7 - 8] = bit_set(all_1.islur[
		    commvl_1.ivx + nnlivx * 7 - 8],1);
	}
	sslur_(lineq, &all_1.iccount, &commvl_1.ivx, &nnlivx, all_1.isdat1, 
		all_1.isdat2, &all_1.nsdat, &comnotes_1.notcrd, &all_1.nolev[
		commvl_1.ivx + nnlivx * 7 - 8], 128L);
    } else if (*(unsigned char *)charq == '?') {

/*  Arpeggio */

	if (bit_test(all_1.ipl[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 
		- 8],10)) {

/* This is a chordal note.  Set a bit in icrdat.  But if *main* (s
pacing) note*/
/*  of chord, will not set icrdat(25), but iornq(27) */

	    comtrill_1.icrdat[comtrill_1.ncrd - 1] = bit_set(
		    comtrill_1.icrdat[comtrill_1.ncrd - 1],25);
	} else {
	    all_1.iornq[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 8] = 
		    bit_set(all_1.iornq[commvl_1.ivx + all_1.nnl[commvl_1.ivx 
		    - 1] * 7 - 8],27);
	}
    } else if (i_indx("0123456789#-nx_", charq, 15L, 1L) > 0) {

/*  We have a figure.  Must come AFTER the note it goes under */

/*       nfigs = nfigs+1 */
	nfig1 = comfig_1.nfigs + 1;
	getfig_(&comgrace_1.itoff[nfig1 - 1], charq, lineq, &all_1.iccount, &
		all_1.isfig[all_1.nnl[commvl_1.ivx - 1] - 1], &comfig_1.itfig[
		nfig1 - 1], all_1.itsofar, &all_1.nodur[commvl_1.ivx + 
		all_1.nnl[commvl_1.ivx - 1] * 7 - 8], comfig_1.figq + (nfig1 
		- 1) * 6, &commvl_1.ivx, &comfig_1.nfigs, 1L, 128L, 6L);
    } else if (*(unsigned char *)charq == '[') {

/* Start forced beam.  Record barno & time since start of inp. blk.  S
et signal*/

	++comfb_1.nfb[commvl_1.ivx - 1];
	comget_1.fbon = TRUE_;
	*(unsigned char *)&comfb_1.ulfbq[commvl_1.ivx + comfb_1.nfb[
		commvl_1.ivx - 1] * 7 - 8] = 'x';
	comfb_1.it1fb[commvl_1.ivx + comfb_1.nfb[commvl_1.ivx - 1] * 7 - 8] = 
		all_1.itsofar[commvl_1.ivx - 1];
	nadj = 0;
L17:
	getchar_(lineq, &all_1.iccount, charq, 128L, 1L);
	if (i_indx("ul", charq, 2L, 1L) > 0) {
	    *(unsigned char *)&comfb_1.ulfbq[commvl_1.ivx + comfb_1.nfb[
		    commvl_1.ivx - 1] * 7 - 8] = *(unsigned char *)charq;
	    goto L17;
	} else if (*(unsigned char *)charq == 'j') {

/*  Continuing a jumped beam here */

	    all_1.irest[commvl_1.ivx + (all_1.nnl[commvl_1.ivx - 1] + 1) * 7 
		    - 8] = bit_set(all_1.irest[commvl_1.ivx + (all_1.nnl[
		    commvl_1.ivx - 1] + 1) * 7 - 8],24);
	    goto L17;
	} else if (*(unsigned char *)charq == 'h') {
	    all_1.islur[commvl_1.ivx + (all_1.nnl[commvl_1.ivx - 1] + 1) * 7 
		    - 8] = bit_set(all_1.islur[commvl_1.ivx + (all_1.nnl[
		    commvl_1.ivx - 1] + 1) * 7 - 8],2);
	    goto L17;
	} else if (*(unsigned char *)charq == 'm') {

/*  Force multiplicity.  Next input is digit */

	    getchar_(lineq, &all_1.iccount, charq, 128L, 1L);
	    all_1.islur[commvl_1.ivx + (all_1.nnl[commvl_1.ivx - 1] + 1) * 7 
		    - 8] = bit_set(all_1.islur[commvl_1.ivx + (all_1.nnl[
		    commvl_1.ivx - 1] + 1) * 7 - 8],21);
	    i__1 = *(unsigned char *)charq - 48;
	    setbits_(&all_1.islur[commvl_1.ivx + (all_1.nnl[commvl_1.ivx - 1] 
		    + 1) * 7 - 8], &c__3, &c__22, &i__1);
	    goto L17;
	} else if (*(unsigned char *)charq != ' ') {

/*  Must be '+/-' for height or slope shift */

	    ++nadj;

/* nadj = 1,2, or 3 for normal start level, slope, or beam-thk sta
rt level.*/

	    ++all_1.iccount;
	    readnum_(lineq, &all_1.iccount, durq, &fnum, 128L, 1L);
	    --all_1.iccount;
	    iadj = (integer) (fnum + (float).1);
	    if (*(unsigned char *)charq == '-') {
		iadj = -iadj;
	    }
	    if (nadj == 1) {

/*  This is a level shift.  Note if 0 was entered, iadj = 15 (
OLD) */
/*  This is a level shift.  Note if 0 was entered, iadj = 30 
*/

		all_1.ipl[commvl_1.ivx + (all_1.nnl[commvl_1.ivx - 1] + 1) * 
			7 - 8] |= iadj + 30 << 11;
/*    *           ior(ipl(ivx,nnl(ivx)+1),ishft(iadj+15,11)) 
*/
	    } else if (nadj == 2) {

/*  Must be a slope shift */

		all_1.ipl[commvl_1.ivx + (all_1.nnl[commvl_1.ivx - 1] + 1) * 
			7 - 8] |= iadj + 30 << 17;
	    } else {

/*  Beam-thk fine tune */

		all_1.islur[commvl_1.ivx + (all_1.nnl[commvl_1.ivx - 1] + 1) *
			 7 - 8] |= iadj << 27;
	    }
	    goto L17;
	}
    } else if (*(unsigned char *)charq == ']') {
	getchar_(lineq, &all_1.iccount, charq, 128L, 1L);
/*       if (charq .eq. ' ') then */
	if (i_indx("j ", charq, 2L, 1L) > 0) {

/* Since ']' comes AFTER note, itsofar has been updated.  Set endi
ng signal.*/

	    comfb_1.it2fb[commvl_1.ivx + comfb_1.nfb[commvl_1.ivx - 1] * 7 - 
		    8] = all_1.itsofar[commvl_1.ivx - 1];
	    comget_1.fbon = FALSE_;
	    if (*(unsigned char *)charq == 'j') {
		all_1.irest[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 
			8] = bit_set(all_1.irest[commvl_1.ivx + all_1.nnl[
			commvl_1.ivx - 1] * 7 - 8],23);
	    }
	} else if (*(unsigned char *)charq == '[') {

/*  Only other possibility is "[" for multiplicity down-up signal 
*/

	    all_1.islur[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 8] = 
		    bit_set(all_1.islur[commvl_1.ivx + all_1.nnl[commvl_1.ivx 
		    - 1] * 7 - 8],20);
	}
    } else if (*(unsigned char *)charq == 'h') {

/*  Heading or height.  For heading, only OK if at start of block */
/*  Check whether at beginning of a block */

	if (all_1.iv != 1 || all_1.nnl[0] != 0) {
	    s_wsle(&io___399);
	    do_lio(&c__9, &c__1, "You entered \"h\" not at beginning of block"
		    , 41L);
	    e_wsle();
	    s_stop("", 0L);
	}
	getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	comhead_1.ihdvrt = 0;
	if (i_indx("+-", durq, 2L, 1L) > 0) {

/* Vertical offset */

	    ++all_1.iccount;
	    readnum_(lineq, &all_1.iccount, charq, &fnum, 128L, 1L);
	    comhead_1.ihdvrt = fnum + (float).1;
	    if (*(unsigned char *)durq == '-') {
		comhead_1.ihdvrt = -comhead_1.ihdvrt;
	    }
	    *(unsigned char *)durq = *(unsigned char *)charq;
	}
	if (*(unsigned char *)durq != ' ') {

/*  Height symbol.  Read past (until next blank) */

L3:
	    getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	    if (*(unsigned char *)durq != ' ') {
		goto L3;
	    }
	} else {

/*  Set flag for header & read it in */

	    comhead_1.ihdht = 16;
	    s_rsfe(&io___400);
	    do_fio(&c__1, comhead_1.headrq, 80L);
	    e_rsfe();
	    all_1.iccount = 128;
	}
    } else if (*(unsigned char *)charq == 'L') {

/*  Linebreak, already handled in pmax, but check for movement break 
*/

	++all_1.iccount;
	readnum_(lineq, &all_1.iccount, durq, &fmovbrk, 128L, 1L);
	if (*(unsigned char *)durq == 'P') {
	    ++all_1.iccount;
	    readnum_(lineq, &all_1.iccount, durq, &fnum, 128L, 1L);
	}
	if (*(unsigned char *)durq == 'M') {
	    comget_1.movbrk = fmovbrk + (float).1;
	    comget_1.movgap = 0;
	    comget_1.parmov = (float)-1.;
	    getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
L31:
	    if (*(unsigned char *)durq == '+') {

/*  Get vertical space (\internotes) */

		++all_1.iccount;
		readnum_(lineq, &all_1.iccount, durq, &fnum, 128L, 1L);
		comget_1.movgap = fnum + (float).1;
		goto L31;
	    } else if (*(unsigned char *)durq == 'i') {
		++all_1.iccount;
		readnum_(lineq, &all_1.iccount, durq, &comget_1.parmov, 128L, 
			1L);
		goto L31;
	    }
	}
    } else if (*(unsigned char *)charq == '|') {

/*  End of bar symbol.  Check about end of bar hardspace. */

	if (bit_test(all_1.iornq[commvl_1.ivx + (all_1.nnl[commvl_1.ivx - 1] 
		+ 1) * 7 - 8],26)) {

/* There was a hardspace followed by a bar line.  Remove it from t
he hardspace*/
/* list, store with shifts instead, set special bit.  Need to repe
at this code*/
/*  at '/'. */

	    all_1.irest[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 8] = 
		    bit_set(all_1.irest[commvl_1.ivx + all_1.nnl[commvl_1.ivx 
		    - 1] * 7 - 8],18);
	    ++comudsp_1.nudoff[commvl_1.ivx - 1];
	    comudsp_1.udoff[commvl_1.ivx + comudsp_1.nudoff[commvl_1.ivx - 1] 
		    * 7 - 8] = comudsp_1.udsp[comudsp_1.nudsp - 1];
	    --comudsp_1.nudsp;
	    all_1.iornq[commvl_1.ivx + (all_1.nnl[commvl_1.ivx - 1] + 1) * 7 
		    - 8] = bit_clear(all_1.iornq[commvl_1.ivx + (all_1.nnl[
		    commvl_1.ivx - 1] + 1) * 7 - 8],26);
	}
    } else if (i_indx("wS", charq, 2L, 1L) > 0) {

/*  Width symbol or new nsyst.  Read past (until blank) */

L4:
	getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	if (*(unsigned char *)durq != ' ') {
	    goto L4;
	}
    } else if (*(unsigned char *)charq == 'l') {

/*  Lower string.  Only OK if at start of block */
/*  Check whether at beginning of a block */

	if (all_1.iv != 1 || all_1.nnl[0] != 0) {
	    s_wsle(&io___402);
	    do_lio(&c__9, &c__1, "You entered \"l\" not at beginning of block"
		    , 41L);
	    e_wsle();
	    s_stop("", 0L);
	}

/*  Set flag for lower string & read it in */

	comhead_1.lower = TRUE_;
	s_rsfe(&io___403);
	do_fio(&c__1, comhead_1.lowerq, 80L);
	e_rsfe();
	all_1.iccount = 128;
    } else if (*(unsigned char *)charq == 'm') {

/*  Meter change.  Only allow at beginning of block. */
/*    mtrnuml, mtrdenl (logical) and p (printable) will be input. */
/*    mtrnuml=0 initially. (In common) */

/*  Check whether at beginning of a block */

	if (all_1.iv != 1 || all_1.nnl[0] != 0) {
	    s_wsle(&io___404);
	    do_lio(&c__9, &c__1, "You entered \"m\" not at beginning of block"
		    , 41L);
	    e_wsle();
	    s_stop("", 0L);
	}
	readmeter_(lineq, &all_1.iccount, &all_1.mtrnuml, &all_1.mtrdenl, 
		128L);
	readmeter_(lineq, &all_1.iccount, &all_1.mtrnmp, &all_1.mtrdnp, 128L);
	lenbeat = ifnodur_(&all_1.mtrdenl, "x", 1L);
	if (all_1.mtrdenl == 2) {
	    lenbeat = 16;
	}
	all_1.lenbar = all_1.mtrnuml * lenbeat;
	if (all_1.mtrdenl == 2) {
	    all_1.lenbar <<= 1;
	}
	all_1.lenb1 = all_1.lenbar;
	all_1.lenb0 = 0;
    } else if (*(unsigned char *)charq == 'C') {

/* Clef change on next note.  Set bits 11,12,13,14.  Won't allow in 2n
d voice*/

	if (all_1.nnl[all_1.iv - 1] > 0) {
	    ++comcc_1.ncc[all_1.iv - 1];
	}
	comcc_1.itcc[all_1.iv + comcc_1.ncc[all_1.iv - 1] * 7 - 8] = 
		all_1.itsofar[all_1.iv - 1];
	isl = bit_set(all_1.islur[all_1.iv + (all_1.nnl[all_1.iv - 1] + 1) * 
		7 - 8],11);
	getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	isl |= numclef_(durq, 1L) << 12;

/*  Set marker on note with lowest voice # starting at same time. */

	comcc_1.ncmidcc[all_1.iv + comcc_1.ncc[all_1.iv - 1] * 7 - 8] = 35 - (
		(7 & lbit_shift(isl, -12L)) << 1);
	if (all_1.iv == 1) {
	    isl = bit_set(isl,15);
	} else {
/*         do 13 iiv = 1 , iv-1 */
	    i__1 = all_1.iv;
	    for (iiv = 1; iiv <= i__1; ++iiv) {
/* ++ */
		nnliiv = all_1.nnl[iiv - 1];
		if (iiv == all_1.iv) {
		    ++nnliiv;
		}
/* ++ */
		itother = 0;
/*           do 14 iip = 1 , nnl(iiv) */
		i__2 = nnliiv;
		for (iip = 1; iip <= i__2; ++iip) {
		    if (itother < all_1.itsofar[all_1.iv - 1]) {
			itother += all_1.nodur[iiv + iip * 7 - 8];
			goto L14;
		    } else if (itother == all_1.itsofar[all_1.iv - 1]) {
			all_1.islur[iiv + iip * 7 - 8] = bit_set(all_1.islur[
				iiv + iip * 7 - 8],15);
			goto L15;
		    }
L14:
		    ;
		}
/* L13: */
	    }
L15:
	    ;
	}
/*       islur(iv,nnl(iv)+1) = isl */

/*  Need 'or' since may have set bit 15 in the above loop */

	all_1.islur[all_1.iv + (all_1.nnl[all_1.iv - 1] + 1) * 7 - 8] = isl | 
		all_1.islur[all_1.iv + (all_1.nnl[all_1.iv - 1] + 1) * 7 - 8];
    } else if (*(unsigned char *)charq == 'R') {

/*  Repeats.  set bits 5, 6, and/or 8 of islur(1,ip+1) */

L10:
	getchar_(lineq, &all_1.iccount, durq, 128L, 1L);

/*  Save designator in case its a Terminal Rr or Rd */

	if (*(unsigned char *)durq == 'l') {
	    all_1.islur[(all_1.nnl[0] + 1) * 7 - 7] = bit_set(all_1.islur[(
		    all_1.nnl[0] + 1) * 7 - 7],5);
	    comget_1.rptprev = TRUE_;
	    *(unsigned char *)comget_1.rptfiq = *(unsigned char *)durq;
	    goto L10;
	} else if (*(unsigned char *)durq == 'r') {
	    all_1.islur[(all_1.nnl[0] + 1) * 7 - 7] = bit_set(all_1.islur[(
		    all_1.nnl[0] + 1) * 7 - 7],6);
	    comget_1.rptprev = TRUE_;
	    *(unsigned char *)comget_1.rptfiq = *(unsigned char *)durq;
	    goto L10;
	} else if (*(unsigned char *)durq == 'd') {
	    comget_1.rptprev = TRUE_;
	    *(unsigned char *)comget_1.rptfiq = *(unsigned char *)durq;
	    all_1.islur[(all_1.nnl[0] + 1) * 7 - 7] = bit_set(all_1.islur[(
		    all_1.nnl[0] + 1) * 7 - 7],8);
	    s_wsle(&io___411);
	    do_lio(&c__9, &c__1, "Just got Rd, set bit 8 of islur sub 1,", 
		    38L);
	    i__1 = all_1.nnl[0] + 1;
	    do_lio(&c__3, &c__1, (char *)&i__1, (ftnlen)sizeof(integer));
	    e_wsle();
	    goto L10;
	} else if (*(unsigned char *)durq == 'D') {
	    all_1.islur[(all_1.nnl[0] + 1) * 7 - 7] = bit_set(all_1.islur[(
		    all_1.nnl[0] + 1) * 7 - 7],26);
	    goto L10;
	}
    } else if (*(unsigned char *)charq == 'V') {

/*  Ending */

	nnnl = all_1.nnl[0] + 1;
	lvoltxt = 0;
L11:
	getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	if (*(unsigned char *)durq == 'b' || *(unsigned char *)durq == 'x') {

/*  End Volta, set bit9, and bit10 on if 'b' (end w/ box) */

	    all_1.islur[nnnl * 7 - 7] = bit_set(all_1.islur[nnnl * 7 - 7],9);
	    if (*(unsigned char *)durq == 'b') {
		all_1.islur[nnnl * 7 - 7] = bit_set(all_1.islur[nnnl * 7 - 7],
			10);
	    }
	    goto L11;
	} else if (*(unsigned char *)durq != ' ') {

/*  Start volta; Get text */

	    if (lvoltxt == 0) {

/*  First character for text */

		lvoltxt = 1;
		all_1.islur[nnnl * 7 - 7] = bit_set(all_1.islur[nnnl * 7 - 7],
			7);
		++comgrace_1.nvolt;
		s_copy(comgrace_1.voltxtq + (comgrace_1.nvolt - 1) * 10, durq,
			 10L, 1L);
	    } else {
/* Writing concatenation */
		i__5[0] = lvoltxt, a__1[0] = comgrace_1.voltxtq + (
			comgrace_1.nvolt - 1) * 10;
		i__5[1] = 1, a__1[1] = durq;
		s_cat(comgrace_1.voltxtq + (comgrace_1.nvolt - 1) * 10, a__1, 
			i__5, &c__2, 10L);
		++lvoltxt;
	    }
	    goto L11;
	}
    } else if (*(unsigned char *)charq == 'B') {
	combc_1.bcspec = ! combc_1.bcspec;
    } else if (*(unsigned char *)charq == 'P') {

/*  Page numbers.  Print stuff right now. */

	s_wsfe(&io___414);
/* Writing concatenation */
	i__6[0] = 1, a__2[0] = all_1.sq;
	i__6[1] = 10, a__2[1] = "headline={";
	i__6[2] = 1, a__2[2] = all_1.sq;
	i__6[3] = 5, a__2[3] = "ifodd";
	i__6[4] = 1, a__2[4] = all_1.sq;
	i__6[5] = 6, a__2[5] = "pageno";
	i__6[6] = 1, a__2[6] = all_1.sq;
	i__6[7] = 5, a__2[7] = "rhead";
	i__6[8] = 1, a__2[8] = all_1.sq;
	i__6[9] = 4, a__2[9] = "else";
	i__6[10] = 1, a__2[10] = all_1.sq;
	i__6[11] = 5, a__2[11] = "lhead";
	i__6[12] = 1, a__2[12] = all_1.sq;
	i__6[13] = 4, a__2[13] = "fi}%";
	s_cat(ch__1, a__2, i__6, &c__14, 46L);
	do_fio(&c__1, ch__1, 46L);
	e_wsfe();
	npg1 = 0;
	pg1r = TRUE_;
L16:
	getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	if (*(unsigned char *)durq >= 48 && *(unsigned char *)durq <= 57) {
	    npg1 = npg1 * 10 + *(unsigned char *)durq - 48;
	    goto L16;
	} else if (*(unsigned char *)durq == 'l') {
	    if (npg1 == 0 || npg1 % 2 == 1) {
		pg1r = FALSE_;
	    }
	} else if (*(unsigned char *)durq == 'r') {
	    if (npg1 > 0 && npg1 % 2 == 0) {
		pg1r = FALSE_;
	    }
	}
/* Writing concatenation */
	i__7[0] = 1, a__3[0] = all_1.sq;
	i__7[1] = 3, a__3[1] = "def";
	i__7[2] = 1, a__3[2] = all_1.sq;
	i__7[3] = 6, a__3[3] = "rhead{";
	i__7[4] = 1, a__3[4] = all_1.sq;
	i__7[5] = 5, a__3[5] = "tempo";
	i__7[6] = 1, a__3[6] = all_1.sq;
	s_cat(hdlndq, a__3, i__7, &c__7, 59L);
	if (pg1r) {

/*  Normal; odds on right */

/* Writing concatenation */
	    i__6[0] = 18, a__2[0] = hdlndq;
	    i__6[1] = 4, a__2[1] = "hfil";
	    i__6[2] = 1, a__2[2] = all_1.sq;
	    i__6[3] = 6, a__2[3] = "folio}";
	    i__6[4] = 1, a__2[4] = all_1.sq;
	    i__6[5] = 3, a__2[5] = "def";
	    i__6[6] = 1, a__2[6] = all_1.sq;
	    i__6[7] = 6, a__2[7] = "lhead{";
	    i__6[8] = 1, a__2[8] = all_1.sq;
	    i__6[9] = 5, a__2[9] = "tempo";
	    i__6[10] = 1, a__2[10] = all_1.sq;
	    i__6[11] = 5, a__2[11] = "folio";
	    i__6[12] = 1, a__2[12] = all_1.sq;
	    i__6[13] = 6, a__2[13] = "hfil}%";
	    s_cat(hdlndq, a__2, i__6, &c__14, 59L);
	} else {
/* Writing concatenation */
	    i__6[0] = 18, a__2[0] = hdlndq;
	    i__6[1] = 5, a__2[1] = "folio";
	    i__6[2] = 1, a__2[2] = all_1.sq;
	    i__6[3] = 5, a__2[3] = "hfil}";
	    i__6[4] = 1, a__2[4] = all_1.sq;
	    i__6[5] = 3, a__2[5] = "def";
	    i__6[6] = 1, a__2[6] = all_1.sq;
	    i__6[7] = 6, a__2[7] = "lhead{";
	    i__6[8] = 1, a__2[8] = all_1.sq;
	    i__6[9] = 5, a__2[9] = "tempo";
	    i__6[10] = 1, a__2[10] = all_1.sq;
	    i__6[11] = 4, a__2[11] = "hfil";
	    i__6[12] = 1, a__2[12] = all_1.sq;
	    i__6[13] = 7, a__2[13] = "folio}%";
	    s_cat(hdlndq, a__2, i__6, &c__14, 59L);
	}
	s_wsfe(&io___418);
	do_fio(&c__1, hdlndq, 59L);
	e_wsfe();
	if (npg1 > 0) {

/*  Write out starting page number */

	    if (npg1 < 10) {
		s_wsfe(&io___419);
/* Writing concatenation */
		i__5[0] = 1, a__1[0] = all_1.sq;
		i__5[1] = 6, a__1[1] = "pageno";
		s_cat(ch__2, a__1, i__5, &c__2, 7L);
		do_fio(&c__1, ch__2, 7L);
		do_fio(&c__1, (char *)&npg1, (ftnlen)sizeof(integer));
		do_fio(&c__1, "%", 1L);
		e_wsfe();
	    } else if (npg1 < 100) {
		s_wsfe(&io___420);
/* Writing concatenation */
		i__5[0] = 1, a__1[0] = all_1.sq;
		i__5[1] = 6, a__1[1] = "pageno";
		s_cat(ch__2, a__1, i__5, &c__2, 7L);
		do_fio(&c__1, ch__2, 7L);
		do_fio(&c__1, (char *)&npg1, (ftnlen)sizeof(integer));
		do_fio(&c__1, "%", 1L);
		e_wsfe();
	    } else {
		s_wsfe(&io___421);
/* Writing concatenation */
		i__5[0] = 1, a__1[0] = all_1.sq;
		i__5[1] = 6, a__1[1] = "pageno";
		s_cat(ch__2, a__1, i__5, &c__2, 7L);
		do_fio(&c__1, ch__2, 7L);
		do_fio(&c__1, (char *)&npg1, (ftnlen)sizeof(integer));
		do_fio(&c__1, "%", 1L);
		e_wsfe();
	    }
	}
    } else if (*(unsigned char *)charq == 'W') {

/*  Just get two more characters (.n), they were used in pmxa */

	getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
    } else if (*(unsigned char *)charq == 'T') {
	comtitl_1.headlog = TRUE_;
	comtitl_1.inhead = 0;
	getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	if (*(unsigned char *)durq == 'i') {
	    s_rsfe(&io___422);
	    do_fio(&c__1, comtitl_1.instrq, 60L);
	    e_rsfe();

/*  A kluge for parts from separate score file for later movements
. */

	    if (*(unsigned char *)comtitl_1.instrq == ' ') {
		comtitl_1.headlog = FALSE_;
	    }
	} else if (*(unsigned char *)durq == 't') {
L21:
	    getchar_(lineq, &all_1.iccount, durq, 128L, 1L);

/*  Optionally can include extra vertical \internotes above inboth
d */

	    if (i_indx("0123456789", durq, 10L, 1L) > 0) {
		comtitl_1.inhead = comtitl_1.inhead * 10 + *(unsigned char *)
			durq - 48;
		goto L21;
	    }
	    s_rsfe(&io___423);
	    do_fio(&c__1, comtitl_1.titleq, 60L);
	    e_rsfe();
	} else {
	    s_rsfe(&io___424);
	    do_fio(&c__1, comtitl_1.compoq, 60L);
	    e_rsfe();
	}
	comtitl_1.inhead += comtitl_1.inbothd;
	all_1.iccount = 128;
    } else if (*(unsigned char *)charq == 'A') {

/*  Accidental handling etc. */

L27:
	getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	if (*(unsigned char *)durq == 'r') {
	    s_wsfe(&io___425);
/* Writing concatenation */
	    i__5[0] = 1, a__1[0] = all_1.sq;
	    i__5[1] = 14, a__1[1] = "relativeaccid%";
	    s_cat(ch__3, a__1, i__5, &c__2, 15L);
	    do_fio(&c__1, ch__3, 15L);
	    e_wsfe();
	    goto L27;
	} else if (*(unsigned char *)durq == 's') {
	    spfacs_1.bacfac = (float)1e6;
	    goto L27;
	} else if (*(unsigned char *)durq == 'b') {
	    s_wsfe(&io___426);
/* Writing concatenation */
	    i__5[0] = 1, a__1[0] = all_1.sq;
	    i__5[1] = 9, a__1[1] = "bigaccid%";
	    s_cat(ch__4, a__1, i__5, &c__2, 10L);
	    do_fio(&c__1, ch__4, 10L);
	    e_wsfe();
	    spfacs_1.accfac = spfacs_1.bacfac;
	    goto L27;
	} else if (*(unsigned char *)durq == 'a') {
	    getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	    readnum_(lineq, &all_1.iccount, durq, &fnum, 128L, 1L);
	    --all_1.iccount;
	    goto L27;
	} else if (*(unsigned char *)durq == 'i') {
	    getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	    readnum_(lineq, &all_1.iccount, durq, &comget_1.fintstf, 128L, 1L)
		    ;
	    --all_1.iccount;
	    goto L27;
	} else if (*(unsigned char *)durq == 'I') {
	    getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	    readnum_(lineq, &all_1.iccount, durq, &comget_1.gintstf, 128L, 1L)
		    ;
	    --all_1.iccount;
	    goto L27;
	} else if (*(unsigned char *)durq == 'd') {
	    comarp_1.lowdot = TRUE_;
	}
    } else if (*(unsigned char *)charq == 'K') {
	getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	num1 = 44 - *(unsigned char *)durq;
	++all_1.iccount;
	readnum_(lineq, &all_1.iccount, durq, &fnum, 128L, 1L);
	num1 *= (integer) (fnum + (float).1);

/* On exit, durq='+','-'.  But only need isig if after start, else don
e in pmxa*/

	++all_1.iccount;
	readnum_(lineq, &all_1.iccount, charq, &fnum, 128L, 1L);
	if (num1 == 0) {

/*  Key change, not transposition. */

	    all_1.ipl[commvl_1.ivx + (all_1.nnl[commvl_1.ivx - 1] + 1) * 7 - 
		    8] = bit_set(all_1.ipl[commvl_1.ivx + (all_1.nnl[
		    commvl_1.ivx - 1] + 1) * 7 - 8],28);
	    comtop_1.lastisig = comtop_1.isig;
	    comtop_1.isig = fnum + (float).1;
	    if (*(unsigned char *)durq == '-') {
		comtop_1.isig = -comtop_1.isig;
	    }
	    comtop_1.isig += comtop_1.idsig;
	} else {

/* num1 .ne. 0, so transposition, so must be at beginning.  isig c
ame with K...*/
/* but was passed to pmxb through pmxtex.dat.  isig0 comes from se
tup data*/
/* (signature before transposition).  idsig must be added to futur
e key changes.*/

	    comtrans_1.ntrans = num1;
	    comtop_1.idsig = comtop_1.isig - comtop_1.isig0;
	}
    } else if (*(unsigned char *)charq == '/') {
	if (bit_test(all_1.iornq[commvl_1.ivx + (all_1.nnl[commvl_1.ivx - 1] 
		+ 1) * 7 - 8],26)) {

/* There was a hardspace followed by end of block.  Remove it from
 the hardspace*/
/* list, store with shifts instead, set special bit.  This code al
so at '|'*/

	    all_1.irest[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 8] = 
		    bit_set(all_1.irest[commvl_1.ivx + all_1.nnl[commvl_1.ivx 
		    - 1] * 7 - 8],18);
	    ++comudsp_1.nudoff[commvl_1.ivx - 1];
	    comudsp_1.udoff[commvl_1.ivx + comudsp_1.nudoff[commvl_1.ivx - 1] 
		    * 7 - 8] = comudsp_1.udsp[comudsp_1.nudsp - 1];
	    --comudsp_1.nudsp;
	    all_1.iornq[commvl_1.ivx + (all_1.nnl[commvl_1.ivx - 1] + 1) * 7 
		    - 8] = bit_clear(all_1.iornq[commvl_1.ivx + (all_1.nnl[
		    commvl_1.ivx - 1] + 1) * 7 - 8],26);
	}
	comnotes_1.ndlev[commvl_1.ivx - 1] = comnotes_1.lastlev;
	getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	if (*(unsigned char *)durq == ' ' && all_1.iv == all_1.nv) {

/*  End of input block */

	    *loop = FALSE_;
	} else {

/*  Start a new voice */

	    if (all_1.lenb0 != 0 && all_1.firstgulp) {
		all_1.lenbar = all_1.lenb0;
	    }
	    all_1.nbars = 0;
	    if (*(unsigned char *)durq == ' ') {

/*  New voice is on next staff */

		++all_1.iv;
		commvl_1.ivx = all_1.iv;
	    } else {

/*  New voice is on same staff.  Set up for it */

		commvl_1.ivx = all_1.nv + 1;
		i__1 = all_1.nv;
		for (iiv = 1; iiv <= i__1; ++iiv) {
		    if (commvl_1.nvmx[iiv - 1] == 2) {
			++commvl_1.ivx;
		    }
/* L23: */
		}
		commvl_1.nvmx[all_1.iv - 1] = 2;
		commvl_1.ivmx[all_1.iv + 6] = commvl_1.ivx;
		all_1.itsofar[commvl_1.ivx - 1] = 0;
		all_1.nnl[commvl_1.ivx - 1] = 0;
		comfb_1.nfb[commvl_1.ivx - 1] = 0;
		comudsp_1.nudoff[commvl_1.ivx - 1] = 0;
		comcc_1.ndotmv[commvl_1.ivx - 1] = 0;
		for (j = 1; j <= 200; ++j) {
		    all_1.irest[commvl_1.ivx + j * 7 - 8] = 0;
		    all_1.islur[commvl_1.ivx + j * 7 - 8] = 0;
		    *(unsigned char *)&all_1.accq[commvl_1.ivx + j * 7 - 8] = 
			    'x';
		    all_1.iornq[commvl_1.ivx + j * 7 - 8] = 0;
		    all_1.ipl[commvl_1.ivx + j * 7 - 8] = 0;
/* L24: */
		}

/* Go back and lower the rests in voice "a" that don't have ov
er-ridden heights*/

		i__1 = all_1.nnl[all_1.iv - 1];
		for (j = 1; j <= i__1; ++j) {
		    if (bit_test(all_1.irest[all_1.iv + j * 7 - 8],0) && 
			    all_1.nolev[all_1.iv + j * 7 - 8] == 0) {
			all_1.nolev[all_1.iv + j * 7 - 8] = -4;
		    }
/* L26: */
		}
	    }
	}
	all_1.iccount = 128;
    } else if (*(unsigned char *)charq == 'X') {
	getchar_(lineq, &all_1.iccount, charq, 128L, 1L);
	if (*(unsigned char *)charq == ':') {

/*  End a group shift after this last note entered. */

	    all_1.irest[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 8] = 
		    bit_set(all_1.irest[commvl_1.ivx + all_1.nnl[commvl_1.ivx 
		    - 1] * 7 - 8],17);
	    comnotes_1.shifton = FALSE_;
	} else {
	    if (*(unsigned char *)charq == '-') {
		++all_1.iccount;
	    }
	    readnum_(lineq, &all_1.iccount, durq, &fnum, 128L, 1L);
	    if (*(unsigned char *)charq == '-') {
		fnum = -fnum;
	    }
	    if (*(unsigned char *)durq != 'p') {
		fnum *= comask_2.wheadpt;
	    } else {
		getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	    }
	    if (*(unsigned char *)durq == ' ') {

/* User-defined hardspace.  Goes before next note. At "|" or "
/" check for*/
/*  presence and shift to udoff if there! */

		++comudsp_1.nudsp;
		all_1.iornq[commvl_1.ivx + (all_1.nnl[commvl_1.ivx - 1] + 1) *
			 7 - 8] = bit_set(all_1.iornq[commvl_1.ivx + (
			all_1.nnl[commvl_1.ivx - 1] + 1) * 7 - 8],26);
		comudsp_1.udsp[comudsp_1.nudsp - 1] = fnum;
		comudsp_1.itudsp[comudsp_1.nudsp - 1] = all_1.itsofar[
			commvl_1.ivx - 1];
	    } else {

/*  Only other possibilities are offsets, "S" for single, ':' 
for multiple */

		++comudsp_1.nudoff[commvl_1.ivx - 1];
		comudsp_1.udoff[commvl_1.ivx + comudsp_1.nudoff[commvl_1.ivx 
			- 1] * 7 - 8] = fnum;
		if (*(unsigned char *)durq == 'S') {
		    all_1.irest[commvl_1.ivx + (all_1.nnl[commvl_1.ivx - 1] + 
			    1) * 7 - 8] = bit_set(all_1.irest[commvl_1.ivx + (
			    all_1.nnl[commvl_1.ivx - 1] + 1) * 7 - 8],15);
		} else {
		    all_1.irest[commvl_1.ivx + (all_1.nnl[commvl_1.ivx - 1] + 
			    1) * 7 - 8] = bit_set(all_1.irest[commvl_1.ivx + (
			    all_1.nnl[commvl_1.ivx - 1] + 1) * 7 - 8],16);
		    comnotes_1.shifton = TRUE_;
		}
	    }
	}
    } else if (*(unsigned char *)charq == 'M') {

/*  Macro action */

	getchar_(lineq, &all_1.iccount, charq, 128L, 1L);
/*       if (charq .eq. 'R') then */
	if (i_indx("RS", charq, 2L, 1L) > 0) {

/*  Record or save a macro.  Get the number of the macro. */

/*         call getchar(lineq,iccount,charq) */
	    getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	    readnum_(lineq, &all_1.iccount, durq, &fnum, 128L, 1L);
	    commac_1.macnum = fnum + (float).1;
	    commac_1.macuse = bit_set(commac_1.macuse,commac_1.macnum);
	    if (bit_test(commac_1.macuse,commac_1.macnum)) {
		cl__1.cerr = 0;
		cl__1.cunit = commac_1.macnum + 20;
		cl__1.csta = 0;
		f_clos(&cl__1);
	    }
	    if (*(unsigned char *)charq == 'R') {
		mrec1_(lineq, &all_1.iccount, &ndxm, 128L);
	    } else {

/*  Save (Record but don't activate) */

L5:
		mrec1_(lineq, &all_1.iccount, &ndxm, 128L);
		if (commac_1.mrecord) {
		    s_rsfe(&io___430);
		    do_fio(&c__1, lineq, 128L);
		    e_rsfe();
		    all_1.iccount = 0;
		    goto L5;
		}
		all_1.iccount = all_1.iccount + ndxm + 1;
	    }
	} else if (*(unsigned char *)charq == 'P') {

/*  Playback the macro */

	    getchar_(lineq, &all_1.iccount, charq, 128L, 1L);
	    readnum_(lineq, &all_1.iccount, durq, &fnum, 128L, 1L);
	    commac_1.macnum = fnum + (float)1e-4;
	    al__1.aerr = 0;
	    al__1.aunit = commac_1.macnum + 20;
	    f_rew(&al__1);
	    commac_1.icchold = all_1.iccount;
	    s_copy(commac_1.lnholdq, lineq, 128L, 128L);
	    all_1.iccount = 128;
	    commac_1.mplay = TRUE_;
	}
    }
    return 0;
} /* getnote_ */

/* Subroutine */ int getchar_(lineq, iccount, charq, lineq_len, charq_len)
char *lineq;
integer *iccount;
char *charq;
ftnlen lineq_len;
ftnlen charq_len;
{
    /* Builtin functions */
    /* Subroutine */ int s_copy();

    /* Local variables */
    static integer ndxm;
    extern /* Subroutine */ int mrec1_(), read10_();


/* Gets the next character out of lineq*128.  If pointer iccount=128 on en
try,*/
/* then reads in a new line.  Resets iccount.  Ends program if no more inp
ut.*/

    if (*iccount == 128) {
	read10_(lineq, &c__128, &comget_1.lastchar, 128L);
	if (comget_1.lastchar) {
	    return 0;
	}
	if (! commac_1.endmac) {
	    *iccount = 0;
	} else {
	    commac_1.endmac = FALSE_;
	    *iccount = commac_1.icchold;
	    s_copy(lineq, commac_1.lnholdq, 128L, 128L);
	}
	if (commac_1.mrecord) {
	    mrec1_(lineq, iccount, &ndxm, 128L);
	}
    }
    ++(*iccount);
    *(unsigned char *)charq = *(unsigned char *)&lineq[*iccount - 1];
    return 0;
/* L999: */
    comget_1.lastchar = TRUE_;
    return 0;
} /* getchar_ */

integer log2_(n)
integer *n;
{
    /* System generated locals */
    integer ret_val;

    /* Builtin functions */
    double log();

    ret_val = log(*n * (float)1.) / (float).69315 + (float).001;
    return ret_val;
} /* log2_ */

integer ifnolev_(noq, oct, noq_len)
char *noq;
integer *oct;
ftnlen noq_len;
{
    /* System generated locals */
    integer ret_val;

    ret_val = *oct * 7 + (*(unsigned char *)noq - 92) % 7 + 1 + 
	    comtrans_1.ntrans;
    return ret_val;
} /* ifnolev_ */

integer ifnodur_(idur, dotq, dotq_len)
integer *idur;
char *dotq;
ftnlen dotq_len;
{
    /* System generated locals */
    integer ret_val;

    /* Builtin functions */
    integer s_wsle(), do_lio(), e_wsle();
    /* Subroutine */ int s_stop();

    /* Fortran I/O blocks */
    static cilist io___432 = { 0, 6, 0, 0, 0 };


    if (*idur == 6) {
	ret_val = 1;
    } else if (*idur == 3) {
	ret_val = 2;
    } else if (*idur == 1) {
	ret_val = 4;
    } else if (*idur == 8) {
	ret_val = 8;
    } else if (*idur == 4) {
	ret_val = 16;
    } else if (*idur == 2) {
	ret_val = 32;
    } else if (*idur == 0) {
	ret_val = 64;
    } else if (*idur == 9) {
	ret_val = 128;
    } else if (*idur == 16) {

/*  Only used for denominator of time signatures, not for notes */

	ret_val = 4;
    } else {
	s_wsle(&io___432);
	do_lio(&c__9, &c__1, "You entered an invalid note value", 33L);
	e_wsle();
	s_stop("", 0L);
    }
    if (*(unsigned char *)dotq == 'd') {
	ret_val = ret_val * 3 / 2;
    }
    return ret_val;
} /* ifnodur_ */

integer ncmidf_(clefq, clefq_len)
char *clefq;
ftnlen clefq_len;
{
    /* System generated locals */
    integer ret_val;

    if (*(unsigned char *)clefq == 't' || *(unsigned char *)clefq == '0') {
	ret_val = 35;
    } else if (*(unsigned char *)clefq == 's' || *(unsigned char *)clefq == 
	    '1') {
	ret_val = 33;
    } else if (*(unsigned char *)clefq == 'm' || *(unsigned char *)clefq == 
	    '2') {
	ret_val = 31;
    } else if (*(unsigned char *)clefq == 'a' || *(unsigned char *)clefq == 
	    '3') {
	ret_val = 29;
    } else if (*(unsigned char *)clefq == 'n' || *(unsigned char *)clefq == 
	    '4') {
	ret_val = 27;
    } else if (*(unsigned char *)clefq == 'r' || *(unsigned char *)clefq == 
	    '5') {
	ret_val = 25;
    } else {
	ret_val = 23;
    }
    return ret_val;
} /* ncmidf_ */

/* Subroutine */ int beamstrt_(notexq, lnote, nornb, ihornb, notexq_len)
char *notexq;
integer *lnote, *nornb, *ihornb;
ftnlen notexq_len;
{
    /* System generated locals */
    address a__1[3], a__2[2];
    integer i__1, i__2[3], i__3[2], i__4, i__5;
    real r__1;
    icilist ici__1;

    /* Builtin functions */
    /* Subroutine */ int s_cat();
    integer s_wsfi(), do_fio(), e_wsfi(), lbit_shift();

    /* Local variables */
    static integer iadj;
    static logical addbrack;
    extern /* Subroutine */ int addblank_();
    static integer icrd;
    static real smed;
    static integer iasl, levc;
    static real epns;
    static integer iorn;
    static real ymin, ybot;
    static integer levx;
    static real xnsk, sumx, sumy, scale;
    extern integer ncmid_();
    static real ybeam;
    static integer ipmid;
    static real bmlev;
    static integer iflop, icrdx, multb;
    static char noteq[8];
    static integer nlnum;
    static real zmult;
    static integer nomornlev;
    extern integer ni_();
    static integer ip;
    extern /* Subroutine */ int ntrbbb_();
    static real xnlmid;
    extern /* Subroutine */ int notefq_();
    static integer lnoten;
    extern /* Subroutine */ int setupb_();
    static real xslope;
    extern /* Subroutine */ int putxtn_();
    static integer ibc, inb, ipb[24], nnb, iud, imp, iup;
    static logical xto;
    static integer ipb1, maxdrop;

    /* Parameter adjustments */
    ihornb -= 8;
    --nornb;

    /* Function Body */
    ibc = all_1.ibmcnt[commvl_1.ivx - 1];
    ipb1 = all_1.ibm1[commvl_1.ivx + ibc * 7 - 8];
    multb = all_1.mult[commvl_1.ivx + ipb1 * 7 - 8];
    setupb_(comxtup_1.xelsk, &nnb, &sumx, &sumy, ipb, &comxtup_1.islope, &
	    smed, &comxtup_1.nolev1, &epns);
    *lnote = 0;
    if (comxtup_1.vxtup[commvl_1.ivx - 1]) {

/* Number goes on notehead side at middle note (or gap) of xtup, unles
s that*/
/*  puts it in staff, then it flops to stem (or beam) side. */
/*               __          __ */
/*         |    |  |   O    |  | */
/*         O      |    |      O */
/*       |___|    O  |__|     | */

/*  iud   -1     -1    1      1    ...stem direction */
/* iflop   0      1   -1      0    ...direction of flop */
/*  iup   -1      1   -1      1    ...direction of number and bracket 
*/

	iud = 1;
	if (*(unsigned char *)&all_1.ulq[commvl_1.ivx + ibc * 7 - 8] == 'u') {
	    iud = -1;
	}

/*  Get ip#, notelevel of middle note (or gap) in xtup */

	ipmid = ipb1 + comxtup_1.ntupv[commvl_1.ivx - 1] / 2;
	xnlmid = (real) all_1.nolev[commvl_1.ivx + ipmid * 7 - 8];
	if (comxtup_1.ntupv[commvl_1.ivx - 1] % 2 == 0) {
	    xnlmid = (xnlmid + all_1.nolev[commvl_1.ivx + (ipmid - 1) * 7 - 8]
		    ) / (float)2.;
	}
	iflop = 0;
	if ((r__1 = xnlmid - ncmid_(&all_1.iv, &ipb1), dabs(r__1)) < (float)
		3.) {
	    iflop = -iud;
	}
	iup = iud + (iflop << 1);
	if (bit_test(all_1.irest[commvl_1.ivx + ipb1 * 7 - 8],14)) {

/*  Alter iud, iflop, iup to flip number/bracket.  (Stare at above
 pic) */

	    iup = -iup;
	    iflop = 0;
	    if (iud * iup < 0) {
		iflop = iup;
	    }
	}

/*  Place xtup number if needed */

	if (! bit_test(all_1.islur[commvl_1.ivx + ipb1 * 7 - 8],31) || multb 
		<= 0) {
	    i__1 = ncmid_(&all_1.iv, &ipb1);
	    putxtn_(&comxtup_1.ntupv[commvl_1.ivx - 1], &iflop, &multb, &iud, 
		    &comask_1.wheadpt, &comask_1.poenom, &comxtup_1.nolev1, &
		    comxtup_1.islope, &all_1.slfac, &xnlmid, &all_1.islur[
		    commvl_1.ivx + ipb1 * 7 - 8], lnote, notexq, &i__1, &
		    nlnum, &comxtup_1.eloff, &iup, &all_1.irest[commvl_1.ivx 
		    + ipb1 * 7 - 8], 79L);
	}

/*  Why was this here ???????? */

/*         nornb(ivx) = 0 */
	if (multb <= 0) {

/* Put in the bracket. scale = stretch factor for bracket if there
 are asx's*/

	    scale = comxtup_1.xelsk[nnb - 1] / (nnb - 1) / epns;
	    xnsk = (comxtup_1.ntupv[commvl_1.ivx - 1] - 1) * scale;
	    if (iup == 1) {
/* Writing concatenation */
		i__2[0] = *lnote, a__1[0] = notexq;
		i__2[1] = 1, a__1[1] = all_1.sq;
		i__2[2] = 5, a__1[2] = "ovbkt";
		s_cat(notexq, a__1, i__2, &c__3, 79L);
	    } else {
/* Writing concatenation */
		i__2[0] = *lnote, a__1[0] = notexq;
		i__2[1] = 1, a__1[1] = all_1.sq;
		i__2[2] = 5, a__1[2] = "unbkt";
		s_cat(notexq, a__1, i__2, &c__3, 79L);
	    }
	    *lnote += 6;
	    if (all_1.iline == 1) {
		smed /= (float)1. - comtop_1.fracindent;
	    }
	    xslope = smed * (float)1.8 * all_1.slfac;
	    comxtup_1.islope = ni_(&xslope);
	    comxtup_1.nolev1 = nlnum - smed * comxtup_1.eloff;
	    if (comxtup_1.islope == 0) {
		--comxtup_1.nolev1;
	    }
	    if (iup == 1) {
		comxtup_1.nolev1 += 4;
	    }
	    i__1 = ncmid_(&all_1.iv, &ipb1);
	    notefq_(noteq, &lnoten, &comxtup_1.nolev1, &i__1, 8L);
	    if (lnoten == 1) {
		addblank_(noteq, &lnoten, 8L);
	    }
/* Writing concatenation */
	    i__2[0] = *lnote, a__1[0] = notexq;
	    i__2[1] = lnoten, a__1[1] = noteq;
	    i__2[2] = 1, a__1[2] = "{";
	    s_cat(notexq, a__1, i__2, &c__3, 79L);
	    *lnote = *lnote + lnoten + 1;
	    if (xnsk < (float).995) {
		i__1 = *lnote;
		ici__1.icierr = 0;
		ici__1.icirnum = 1;
		ici__1.icirlen = *lnote + 4 - i__1;
		ici__1.iciunit = notexq + i__1;
		ici__1.icifmt = "(i1,f3.2)";
		s_wsfi(&ici__1);
		do_fio(&c__1, (char *)&c__0, (ftnlen)sizeof(integer));
		do_fio(&c__1, (char *)&xnsk, (ftnlen)sizeof(real));
		e_wsfi();
		*lnote += 4;
	    } else if (xnsk < (float)9.995) {
		i__1 = *lnote;
		ici__1.icierr = 0;
		ici__1.icirnum = 1;
		ici__1.icirlen = *lnote + 4 - i__1;
		ici__1.iciunit = notexq + i__1;
		ici__1.icifmt = "(f4.2)";
		s_wsfi(&ici__1);
		do_fio(&c__1, (char *)&xnsk, (ftnlen)sizeof(real));
		e_wsfi();
		*lnote += 4;
	    } else {
		i__1 = *lnote;
		ici__1.icierr = 0;
		ici__1.icirnum = 1;
		ici__1.icirlen = *lnote + 5 - i__1;
		ici__1.iciunit = notexq + i__1;
		ici__1.icifmt = "(f5.2)";
		s_wsfi(&ici__1);
		do_fio(&c__1, (char *)&xnsk, (ftnlen)sizeof(real));
		e_wsfi();
		*lnote += 5;
	    }
/* Writing concatenation */
	    i__3[0] = *lnote, a__2[0] = notexq;
	    i__3[1] = 1, a__2[1] = "}";
	    s_cat(notexq, a__2, i__3, &c__2, 79L);
	    ++(*lnote);
	    if (comxtup_1.islope < 0 || comxtup_1.islope >= 10) {
/* Writing concatenation */
		i__3[0] = *lnote, a__2[0] = notexq;
		i__3[1] = 1, a__2[1] = "{";
		s_cat(notexq, a__2, i__3, &c__2, 79L);
		++(*lnote);
		if (comxtup_1.islope < -9) {
		    i__1 = *lnote;
		    ici__1.icierr = 0;
		    ici__1.icirnum = 1;
		    ici__1.icirlen = *lnote + 3 - i__1;
		    ici__1.iciunit = notexq + i__1;
		    ici__1.icifmt = "(i3)";
		    s_wsfi(&ici__1);
		    do_fio(&c__1, (char *)&comxtup_1.islope, (ftnlen)sizeof(
			    integer));
		    e_wsfi();
		    *lnote += 3;
		} else {
		    i__1 = *lnote;
		    ici__1.icierr = 0;
		    ici__1.icirnum = 1;
		    ici__1.icirlen = *lnote + 2 - i__1;
		    ici__1.iciunit = notexq + i__1;
		    ici__1.icifmt = "(i2)";
		    s_wsfi(&ici__1);
		    do_fio(&c__1, (char *)&comxtup_1.islope, (ftnlen)sizeof(
			    integer));
		    e_wsfi();
		    *lnote += 2;
		}
/* Writing concatenation */
		i__3[0] = *lnote, a__2[0] = notexq;
		i__3[1] = 1, a__2[1] = "}";
		s_cat(notexq, a__2, i__3, &c__2, 79L);
		++(*lnote);
	    } else {
		i__1 = *lnote;
		ici__1.icierr = 0;
		ici__1.icirnum = 1;
		ici__1.icirlen = *lnote + 1 - i__1;
		ici__1.iciunit = notexq + i__1;
		ici__1.icifmt = "(i1)";
		s_wsfi(&ici__1);
		do_fio(&c__1, (char *)&comxtup_1.islope, (ftnlen)sizeof(
			integer));
		e_wsfi();
		++(*lnote);
	    }
	    return 0;
	}
    }

/*  Adjust start level and slope if needed */

    iadj = (63 & lbit_shift(all_1.ipl[commvl_1.ivx + ipb1 * 7 - 8], -11L)) - 
	    30;
    if (iadj != -30) {
	comxtup_1.nolev1 += iadj;
    }
    iadj = (63 & lbit_shift(all_1.ipl[commvl_1.ivx + ipb1 * 7 - 8], -17L)) - 
	    30;
    if (iadj != -30) {
	comxtup_1.islope += iadj;
    }
    iadj = 3 & lbit_shift(all_1.islur[commvl_1.ivx + ipb1 * 7 - 8], -27L);
    addbrack = FALSE_;
    if (bit_test(all_1.ipl[commvl_1.ivx + ipb1 * 7 - 8],30)) {

/* Check for altered starting polarity.  Only in forced beams. Nominal
 start*/
/* level is nolev1. So beam level is nolev1 +/- 6, to be compared w/ n
olev(.,.).*/

	if (*(unsigned char *)&all_1.ulq[commvl_1.ivx + ibc * 7 - 8] == 'u' &&
		 comxtup_1.nolev1 + 6 < all_1.nolev[commvl_1.ivx + ipb1 * 7 - 
		8]) {
	    if (*lnote == 0) {
/* Writing concatenation */
		i__3[0] = 1, a__2[0] = all_1.sq;
		i__3[1] = 5, a__2[1] = "loff{";
		s_cat(notexq, a__2, i__3, &c__2, 79L);
	    } else {
/* Writing concatenation */
		i__2[0] = *lnote, a__1[0] = notexq;
		i__2[1] = 1, a__1[1] = all_1.sq;
		i__2[2] = 5, a__1[2] = "loff{";
		s_cat(notexq, a__1, i__2, &c__3, 79L);
	    }
	    *lnote += 6;
	    addbrack = TRUE_;
	} else if (*(unsigned char *)&all_1.ulq[commvl_1.ivx + ibc * 7 - 8] ==
		 'l' && comxtup_1.nolev1 - 6 > all_1.nolev[commvl_1.ivx + 
		ipb1 * 7 - 8]) {
	    if (*lnote == 0) {
/* Writing concatenation */
		i__3[0] = 1, a__2[0] = all_1.sq;
		i__3[1] = 5, a__2[1] = "roff{";
		s_cat(notexq, a__2, i__3, &c__2, 79L);
	    } else {
/* Writing concatenation */
		i__2[0] = *lnote, a__1[0] = notexq;
		i__2[1] = 1, a__1[1] = all_1.sq;
		i__2[2] = 5, a__1[2] = "roff{";
		s_cat(notexq, a__1, i__2, &c__3, 79L);
	    }
	    *lnote += 6;
	    addbrack = TRUE_;
	}

/* Check for end level in forced beam.  Have to do it here since with 
multiple*/
/*  voices, xelsk will not be preserved. */

	if (*(unsigned char *)&all_1.ulq[commvl_1.ivx + all_1.ibmcnt[
		commvl_1.ivx - 1] * 7 - 8] == 'u') {
	    bmlev = comxtup_1.nolev1 + 6 + comxtup_1.islope * comxtup_1.xelsk[
		    nnb - 1] / all_1.slfac;
	    strtmid_1.flipend[commvl_1.ivx - 1] = bmlev < (real) all_1.nolev[
		    commvl_1.ivx + all_1.ibm2[commvl_1.ivx + ibc * 7 - 8] * 7 
		    - 8];
	} else if (*(unsigned char *)&all_1.ulq[commvl_1.ivx + all_1.ibmcnt[
		commvl_1.ivx - 1] * 7 - 8] == 'l') {
	    bmlev = comxtup_1.nolev1 - 6 + comxtup_1.islope * comxtup_1.xelsk[
		    nnb - 1] / all_1.slfac;
	    strtmid_1.flipend[commvl_1.ivx - 1] = bmlev > (real) all_1.nolev[
		    commvl_1.ivx + all_1.ibm2[commvl_1.ivx + ibc * 7 - 8] * 7 
		    - 8];
	}
    }
    i__1 = multb + iadj;
    ntrbbb_(&i__1, "i", all_1.ulq + (commvl_1.ivx + ibc * 7 - 8), &
	    commvl_1.ivx, notexq, lnote, 1L, 1L, 79L);

/*   Put in name of start level and slope */

    i__1 = ncmid_(&all_1.iv, &ipb1);
    notefq_(noteq, &lnoten, &comxtup_1.nolev1, &i__1, 8L);
/* Computing MIN */
    i__1 = abs(comxtup_1.islope);
    iasl = min(i__1,9);
    if (comxtup_1.islope < 0) {
/* Writing concatenation */
	i__2[0] = *lnote, a__1[0] = notexq;
	i__2[1] = lnoten, a__1[1] = noteq;
	i__2[2] = 1, a__1[2] = "{";
	s_cat(notexq, a__1, i__2, &c__3, 79L);
	*lnote = *lnote + 4 + lnoten;
	i__1 = *lnote - 3;
	ici__1.icierr = 0;
	ici__1.icirnum = 1;
	ici__1.icirlen = *lnote - i__1;
	ici__1.iciunit = notexq + i__1;
	ici__1.icifmt = "(i2,a1)";
	s_wsfi(&ici__1);
	i__4 = -iasl;
	do_fio(&c__1, (char *)&i__4, (ftnlen)sizeof(integer));
	do_fio(&c__1, "}", 1L);
	e_wsfi();
    } else {
/* Writing concatenation */
	i__3[0] = *lnote, a__2[0] = notexq;
	i__3[1] = lnoten, a__2[1] = noteq;
	s_cat(notexq, a__2, i__3, &c__2, 79L);
	*lnote = *lnote + 1 + lnoten;
	ici__1.icierr = 0;
	ici__1.icirnum = 1;
	ici__1.icirlen = 1;
	ici__1.iciunit = notexq + (*lnote - 1);
	ici__1.icifmt = "(i1)";
	s_wsfi(&ici__1);
	do_fio(&c__1, (char *)&iasl, (ftnlen)sizeof(integer));
	e_wsfi();
    }

/*  Check for beam-thk fine-tuning */

    if (iadj > 0) {
	i__1 = multb + 1;
	for (imp = multb + iadj; imp >= i__1; --imp) {
	    ntrbbb_(&imp, "t", all_1.ulq + (commvl_1.ivx + ibc * 7 - 8), &
		    commvl_1.ivx, notexq, lnote, 1L, 1L, 79L);
/* L1: */
	}
    }

/*  If we shifted, must close with right bracket */

    if (addbrack) {
/* Writing concatenation */
	i__3[0] = *lnote, a__2[0] = notexq;
	i__3[1] = 1, a__2[1] = "}";
	s_cat(notexq, a__2, i__3, &c__2, 79L);
	++(*lnote);
    }

/*  Get 'floor' zmin for figures */

    if (all_1.figbass && all_1.iv == 1) {
	zmult = (multb - 1) * (float)1.2;
	ymin = (float)100.;
	i__1 = nnb;
	for (inb = 1; inb <= i__1; ++inb) {
	    if (all_1.isfig[ipb[inb - 1] - 1]) {
		if (*(unsigned char *)&all_1.ulq[ibc * 7 - 7] == 'u') {
		    ybot = (real) all_1.nolev[ipb[inb - 1] * 7 - 7];
		} else {
		    ybot = comxtup_1.islope / all_1.slfac * comxtup_1.xelsk[
			    inb - 1] + comxtup_1.nolev1 - all_1.stemlen - 
			    zmult;
		}
		ymin = dmin(ymin,ybot);
	    }
/* L3: */
	}
	maxdrop = ncmid_(&c__1, &ipb1) - 4 - ymin + (float)5.01;
/* Computing MAX */
	i__1 = all_1.ifigdrop[all_1.iline - 1];
	all_1.ifigdrop[all_1.iline - 1] = max(i__1,maxdrop);
    }

/*  Compute ornament levels if needed */

/*       if (nornb(ivx) .gt. 0) then */
/*       nornb(ivx) = 0 */
    nomornlev = ncmid_(&all_1.iv, &ipb1) + 5;
    iorn = 0;
    i__1 = nnb;
    for (inb = 1; inb <= i__1; ++inb) {
	ip = ipb[inb - 1];
	if (! bit_test(all_1.iornq[commvl_1.ivx + ip * 7 - 8],23)) {
	    goto L8;
	}

/*  Bits 0-13: (stmgx+Tupf._) , 14: Down fermata, was F */
/*  15: Trill w/o "tr", was U , 16-18 Editorial s,f,n , 19-21 TBD */

	if (! bit_test(all_1.ipl[commvl_1.ivx + ip * 7 - 8],10)) {

/*  Non-chord.  There IS an ornament.  Need ihornb only if upbeam,
 and if */
/*  ornament is 1,2,3,5,6,7,8,9,10,15-21 (up- but not domn ferm.) 
*/

	    if (*(unsigned char *)&all_1.ulq[commvl_1.ivx + ibc * 7 - 8] == 
		    'u' && (all_1.iornq[commvl_1.ivx + ipb[inb - 1] * 7 - 8] &
		     4163566) > 0) {
		++iorn;
		all_1.iornq[commvl_1.ivx + ip * 7 - 8] = bit_set(all_1.iornq[
			commvl_1.ivx + ip * 7 - 8],22);
		ybeam = comxtup_1.nolev1 + all_1.stemlen + comxtup_1.islope * 
			comxtup_1.xelsk[inb - 1] / all_1.slfac - 1 + (multb - 
			1) * (float)1.2;
/*           ihornb(ivx,iorn) = max(ni(ybeam+3.5),NomOrnLev) 
*/
/* Computing MAX */
		r__1 = ybeam + (float)3.;
		i__4 = ni_(&r__1);
		ihornb[commvl_1.ivx + iorn * 7] = max(i__4,nomornlev);
	    }
	} else {

/*In a chord.  Orn may be on main note or non-main or both.  Set i
hornb if*/
/*upbeam and highest note has orn, or down beam and lowest.  Find 
1st chord note*/

	    i__4 = comtrill_1.ncrd;
	    for (comtrill_1.icrd1 = 1; comtrill_1.icrd1 <= i__4; 
		    ++comtrill_1.icrd1) {
		if ((255 & comtrill_1.icrdat[comtrill_1.icrd1 - 1]) == ip && (
			15 & lbit_shift(comtrill_1.icrdat[comtrill_1.icrd1 - 
			1], -8L)) == commvl_1.ivx) {
		    goto L11;
		}
/* L10: */
	    }
L11:

/*Find outermost note, min or max depending on beam direction ulq.
  xto is true*/
/*if there's an ornament on that note.  Expand orn list to include
 ._, since if these*/
/* on extreme chord note in beam, will move. */
/* So ornaments are all except 0,4,13 (,g,) */

	    levx = all_1.nolev[commvl_1.ivx + ip * 7 - 8];
	    xto = (all_1.iornq[commvl_1.ivx + ipb[inb - 1] * 7 - 8] & 4186094)
		     > 0;
	    icrdx = 0;
	    i__4 = comtrill_1.ncrd;
	    for (icrd = comtrill_1.icrd1; icrd <= i__4; ++icrd) {
		if ((255 & comtrill_1.icrdat[icrd - 1]) != ip || (15 & 
			lbit_shift(comtrill_1.icrdat[icrd - 1], -8L)) != 
			commvl_1.ivx) {
		    goto L13;
		}
		levc = 127 & lbit_shift(comtrill_1.icrdat[icrd - 1], -12L);
		if (*(unsigned char *)&all_1.ulq[commvl_1.ivx + ibc * 7 - 8] 
			== 'u' && levc > levx || *(unsigned char *)&all_1.ulq[
			commvl_1.ivx + ibc * 7 - 8] == 'l' && levc < levx) {
		    levx = levc;
		    icrdx = icrd;
		    xto = (comtrill_1.icrdorn[icrd - 1] & 4186094) > 0;
		}
/* L12: */
	    }
L13:

/*  If there's orn on extreme note, do stuff */

	    if (xto) {
		++iorn;
		if (*(unsigned char *)&all_1.ulq[commvl_1.ivx + ibc * 7 - 8] 
			== 'u') {
		    ybeam = comxtup_1.nolev1 + all_1.stemlen + 
			    comxtup_1.islope * comxtup_1.xelsk[inb - 1] / 
			    all_1.slfac - 1 + (multb - 1) * (float)1.2;
/*             ihornb(ivx,iorn) = max(ni(ybeam+3.5),NomOrn
Lev) */
/* Computing MAX */
		    r__1 = ybeam + (float)3.;
		    i__4 = ni_(&r__1);
		    ihornb[commvl_1.ivx + iorn * 7] = max(i__4,nomornlev);
		} else {
		    ybeam = comxtup_1.nolev1 - all_1.stemlen + 
			    comxtup_1.islope * comxtup_1.xelsk[inb - 1] / 
			    all_1.slfac + 1 - (multb - 1) * (float)1.2;
/*             ihornb(ivx,iorn) = min(ni(ybeam-3.5),NomOrn
Lev-10) */
/* Computing MIN */
		    r__1 = ybeam - (float)3.;
		    i__4 = ni_(&r__1), i__5 = nomornlev - 10;
		    ihornb[commvl_1.ivx + iorn * 7] = min(i__4,i__5);
		}
		if (icrdx == 0) {

/*  Affected ornament is on main note */

		    all_1.iornq[commvl_1.ivx + ip * 7 - 8] = bit_set(
			    all_1.iornq[commvl_1.ivx + ip * 7 - 8],22);
		} else {
		    comtrill_1.icrdorn[icrdx - 1] = bit_set(
			    comtrill_1.icrdorn[icrdx - 1],22);
		}
	    }
	}
L8:
	;
    }
/* c */
/*c   Hecnceforth nornb(ivx) will be a counter.  Zero it out when beam is 
finished*/
/*c   Start it at 1 instead of 0 so it tells if there are orns in the beam
.*/
/* c */
/*        nornb(ivx) = 1 */
    if (iorn > 0) {
	nornb[commvl_1.ivx] = 1;
    }
/*      end if */
    return 0;
} /* beamstrt_ */

/* Subroutine */ int beamn1_(notexq, lnote, notexq_len)
char *notexq;
integer *lnote;
ftnlen notexq_len;
{
    /* System generated locals */
    address a__1[4], a__2[3], a__3[2];
    integer i__1, i__2[4], i__3[3], i__4[2];
    icilist ici__1;

    /* Builtin functions */
    /* Subroutine */ int s_cat();
    integer pow_ii(), s_wsfi(), do_fio(), e_wsfi();

    /* Local variables */
    extern /* Subroutine */ int addblank_();
    extern integer ncmid_();
    static char noteq[8];
    static integer multr, nd, im;
    extern /* Subroutine */ int ntrbbb_(), notefq_();
    static logical isdotm;
    static integer lnoten, ip1, multip;
    extern integer log2_();

    ip1 = all_1.ibm1[commvl_1.ivx + all_1.ibmcnt[commvl_1.ivx - 1] * 7 - 8];
    multip = all_1.mult[commvl_1.ivx + ip1 * 7 - 8];
    i__1 = ncmid_(&all_1.iv, &ip1);
    notefq_(noteq, &lnoten, &all_1.nolev[commvl_1.ivx + all_1.list[(all_1.jn 
	    << 2) - 3] * 7 - 8], &i__1, 8L);
    if (comxtup_1.vxtup[commvl_1.ivx - 1] && multip <= 0) {

/*  Xtuplet with no beam, just put in the right kind of note */

	if (lnoten == 1) {
	    addblank_(noteq, &lnoten, 8L);
	}
	if (multip == 0) {
/* Writing concatenation */
	    i__2[0] = 1, a__1[0] = all_1.sq;
	    i__2[1] = 1, a__1[1] = "q";
	    i__2[2] = 1, a__1[2] = all_1.ulq + (commvl_1.ivx + all_1.ibmcnt[
		    commvl_1.ivx - 1] * 7 - 8);
	    i__2[3] = 8, a__1[3] = noteq;
	    s_cat(notexq, a__1, i__2, &c__4, 79L);
	} else if (multip == -1) {
/* Writing concatenation */
	    i__2[0] = 1, a__1[0] = all_1.sq;
	    i__2[1] = 1, a__1[1] = "h";
	    i__2[2] = 1, a__1[2] = all_1.ulq + (commvl_1.ivx + all_1.ibmcnt[
		    commvl_1.ivx - 1] * 7 - 8);
	    i__2[3] = 8, a__1[3] = noteq;
	    s_cat(notexq, a__1, i__2, &c__4, 79L);
	}
	*lnote = lnoten + 3;
	return 0;
    }

/*  Check if mult. decreases from 1st note to 2nd */

    if (all_1.ibm2[commvl_1.ivx + all_1.ibmcnt[commvl_1.ivx - 1] * 7 - 8] > 
	    ip1) {
	if (! bit_test(all_1.irest[commvl_1.ivx + (ip1 + 1) * 7 - 8],0)) {
	    multr = all_1.mult[commvl_1.ivx + (ip1 + 1) * 7 - 8];
	} else {
	    multr = all_1.mult[commvl_1.ivx + (ip1 + 2) * 7 - 8];
	}
	*lnote = 0;
	if (multr < multip) {
	    i__1 = multr + 1;
	    for (im = multip; im >= i__1; --im) {
		ntrbbb_(&im, "r", all_1.ulq + (commvl_1.ivx + all_1.ibmcnt[
			commvl_1.ivx - 1] * 7 - 8), &commvl_1.ivx, notexq, 
			lnote, 1L, 1L, 79L);
/* L1: */
	    }
	}
    }

/*  Put in the note */

    if (*lnote > 0) {
/* Writing concatenation */
	i__3[0] = *lnote, a__2[0] = notexq;
	i__3[1] = 1, a__2[1] = all_1.sq;
	i__3[2] = 2, a__2[2] = "qb";
	s_cat(notexq, a__2, i__3, &c__3, 79L);
    } else {
/* Writing concatenation */
	i__4[0] = 1, a__3[0] = all_1.sq;
	i__4[1] = 2, a__3[1] = "qb";
	s_cat(notexq, a__3, i__4, &c__2, 79L);
    }
    *lnote += 3;

/*  Check for dot */

    isdotm = FALSE_;
    if (! comxtup_1.vxtup[commvl_1.ivx - 1]) {
	nd = all_1.nodur[commvl_1.ivx + all_1.list[(all_1.jn << 2) - 3] * 7 - 
		8];
	if (nd != 0) {
	    i__1 = log2_(&nd);
	    if (pow_ii(&c__2, &i__1) != nd) {
		if (! bit_test(all_1.iornq[commvl_1.ivx + ip1 * 7 - 8],13)) {
/* Writing concatenation */
		    i__4[0] = *lnote, a__3[0] = notexq;
		    i__4[1] = 1, a__3[1] = "p";
		    s_cat(notexq, a__3, i__4, &c__2, 79L);
		} else {
/* Writing concatenation */
		    i__4[0] = *lnote, a__3[0] = notexq;
		    i__4[1] = 1, a__3[1] = "m";
		    s_cat(notexq, a__3, i__4, &c__2, 79L);
		    isdotm = TRUE_;
		}
		++(*lnote);
	    }
	}
    }
    ++(*lnote);
    if (! bit_test(all_1.irest[commvl_1.ivx + ip1 * 7 - 8],24)) {
	ici__1.icierr = 0;
	ici__1.icirnum = 1;
	ici__1.icirlen = 1;
	ici__1.iciunit = notexq + (*lnote - 1);
	ici__1.icifmt = "(i1)";
	s_wsfi(&ici__1);
	do_fio(&c__1, (char *)&commvl_1.ivx, (ftnlen)sizeof(integer));
	e_wsfi();
    } else {
	ici__1.icierr = 0;
	ici__1.icirnum = 1;
	ici__1.icirlen = 1;
	ici__1.iciunit = notexq + (*lnote - 1);
	ici__1.icifmt = "(i1)";
	s_wsfi(&ici__1);
	do_fio(&c__1, (char *)&combjmp_1.ivbjmp, (ftnlen)sizeof(integer));
	e_wsfi();
	combjmp_1.isbjmp = TRUE_;
    }
/* Writing concatenation */
    i__4[0] = *lnote, a__3[0] = notexq;
    i__4[1] = lnoten, a__3[1] = noteq;
    s_cat(notexq, a__3, i__4, &c__2, 79L);
    *lnote += lnoten;
    if (isdotm) {
	if (lnoten == 1) {
/* Writing concatenation */
	    i__2[0] = *lnote, a__1[0] = notexq;
	    i__2[1] = 1, a__1[1] = "{";
	    i__2[2] = 1, a__1[2] = noteq;
	    i__2[3] = 1, a__1[3] = "}";
	    s_cat(notexq, a__1, i__2, &c__4, 79L);
	    *lnote += 3;
	} else {
	    i__1 = lnoten - 2;
/* Writing concatenation */
	    i__4[0] = *lnote, a__3[0] = notexq;
	    i__4[1] = lnoten - 1 - i__1, a__3[1] = noteq + i__1;
	    s_cat(notexq, a__3, i__4, &c__2, 79L);
	    ++(*lnote);
	}
    }
    return 0;
} /* beamn1_ */

/* Subroutine */ int beamend_(notexq, lnote, notexq_len)
char *notexq;
integer *lnote;
ftnlen notexq_len;
{
    /* System generated locals */
    address a__1[4], a__2[3], a__3[2];
    integer i__1, i__2[4], i__3[3], i__4[2];
    icilist ici__1;

    /* Builtin functions */
    /* Subroutine */ int s_cat();
    integer pow_ii(), s_wsfi(), do_fio(), e_wsfi();

    /* Local variables */
    extern /* Subroutine */ int addblank_();
    static integer ivbm;
    static char ulqq[1];
    extern integer ncmid_();
    static char noteq[8];
    static integer ip, mp;
    extern /* Subroutine */ int ntrbbb_(), notefq_();
    static logical isdotm;
    static integer lnoten, multip, imp;
    extern integer log2_();

    ip = all_1.list[(all_1.jn << 2) - 3];
    multip = all_1.mult[commvl_1.ivx + ip * 7 - 8];
    i__1 = ncmid_(&all_1.iv, &ip);
    notefq_(noteq, &lnoten, &all_1.nolev[commvl_1.ivx + ip * 7 - 8], &i__1, 
	    8L);
    if (comxtup_1.vxtup[commvl_1.ivx - 1] && multip <= 0) {

/*  Xtuplet with no beam, just put in the right kind of note */

	if (lnoten == 1) {
	    addblank_(noteq, &lnoten, 8L);
	}
	if (multip == 0) {
/* Writing concatenation */
	    i__2[0] = 1, a__1[0] = all_1.sq;
	    i__2[1] = 1, a__1[1] = "q";
	    i__2[2] = 1, a__1[2] = all_1.ulq + (commvl_1.ivx + all_1.ibmcnt[
		    commvl_1.ivx - 1] * 7 - 8);
	    i__2[3] = 8, a__1[3] = noteq;
	    s_cat(notexq, a__1, i__2, &c__4, 79L);
	} else if (multip == -1) {
/* Writing concatenation */
	    i__2[0] = 1, a__1[0] = all_1.sq;
	    i__2[1] = 1, a__1[1] = "h";
	    i__2[2] = 1, a__1[2] = all_1.ulq + (commvl_1.ivx + all_1.ibmcnt[
		    commvl_1.ivx - 1] * 7 - 8);
	    i__2[3] = 8, a__1[3] = noteq;
	    s_cat(notexq, a__1, i__2, &c__4, 79L);
	}
	*lnote = lnoten + 3;
	return 0;
    }
    *lnote = 0;

/* New way, with flipend, which was computed in beamstrt. */

    if (bit_test(all_1.ipl[commvl_1.ivx + ip * 7 - 8],30) && 
	    strtmid_1.flipend[commvl_1.ivx - 1]) {
	*(unsigned char *)&all_1.ulq[commvl_1.ivx + all_1.ibmcnt[commvl_1.ivx 
		- 1] * 7 - 8] = (char) (225 - *(unsigned char *)&all_1.ulq[
		commvl_1.ivx + all_1.ibmcnt[commvl_1.ivx - 1] * 7 - 8]);
    }
    if (ip > all_1.ibm1[commvl_1.ivx + all_1.ibmcnt[commvl_1.ivx - 1] * 7 - 8]
	    ) {

/*This is not a one-noter from beam-jump.  Check if multiplicity has i
ncreased*/

	if (bit_test(all_1.irest[commvl_1.ivx + (ip - 1) * 7 - 8],0)) {

/*  Prior note is a rest, check one before that */

	    mp = all_1.mult[commvl_1.ivx + (ip - 2) * 7 - 8];
	} else {
	    mp = all_1.mult[commvl_1.ivx + (ip - 1) * 7 - 8];
	}
	if (multip > mp) {

/*  Assume 1-3, 2-3, or 1-2 */

	    i__1 = mp + 1;
	    for (imp = multip; imp >= i__1; --imp) {
		ntrbbb_(&imp, "t", all_1.ulq + (commvl_1.ivx + all_1.ibmcnt[
			commvl_1.ivx - 1] * 7 - 8), &commvl_1.ivx, notexq, 
			lnote, 1L, 1L, 79L);
/* L2: */
	    }
	}
    }

/* Now the normal beam termination */

    if (! bit_test(all_1.irest[commvl_1.ivx + ip * 7 - 8],23)) {

/*  Don't terminate if starting a beam jump */

	*(unsigned char *)ulqq = *(unsigned char *)&all_1.ulq[commvl_1.ivx + 
		all_1.ibmcnt[commvl_1.ivx - 1] * 7 - 8];
	if (! combjmp_1.isbjmp) {
	    ivbm = commvl_1.ivx;
	} else {
	    ivbm = combjmp_1.ivbjmp;
	    *(unsigned char *)ulqq = (char) (225 - *(unsigned char *)ulqq);
	}
	ntrbbb_(&c__1, "t", ulqq, &ivbm, notexq, lnote, 1L, 1L, 79L);
    } else {
	combjmp_1.ivbjmp = commvl_1.ivx;
    }

/*  And now the note */

    if (*lnote > 0) {
/* Writing concatenation */
	i__3[0] = *lnote, a__2[0] = notexq;
	i__3[1] = 1, a__2[1] = all_1.sq;
	i__3[2] = 2, a__2[2] = "qb";
	s_cat(notexq, a__2, i__3, &c__3, 79L);
    } else {
/* Writing concatenation */
	i__4[0] = 1, a__3[0] = all_1.sq;
	i__4[1] = 2, a__3[1] = "qb";
	s_cat(notexq, a__3, i__4, &c__2, 79L);
    }
    *lnote += 3;
    isdotm = FALSE_;
    if (! comxtup_1.vxtup[commvl_1.ivx - 1]) {
	i__1 = log2_(&all_1.nodur[commvl_1.ivx + ip * 7 - 8]);
	if (pow_ii(&c__2, &i__1) != all_1.nodur[commvl_1.ivx + ip * 7 - 8]) {
	    if (! bit_test(all_1.iornq[commvl_1.ivx + ip * 7 - 8],13)) {
/* Writing concatenation */
		i__4[0] = *lnote, a__3[0] = notexq;
		i__4[1] = 1, a__3[1] = "p";
		s_cat(notexq, a__3, i__4, &c__2, 79L);
	    } else {
/* Writing concatenation */
		i__4[0] = *lnote, a__3[0] = notexq;
		i__4[1] = 1, a__3[1] = "m";
		s_cat(notexq, a__3, i__4, &c__2, 79L);
		isdotm = TRUE_;
	    }
	    ++(*lnote);
	}
    }
    ++(*lnote);
    if (! combjmp_1.isbjmp) {
	ici__1.icierr = 0;
	ici__1.icirnum = 1;
	ici__1.icirlen = 1;
	ici__1.iciunit = notexq + (*lnote - 1);
	ici__1.icifmt = "(i1)";
	s_wsfi(&ici__1);
	do_fio(&c__1, (char *)&commvl_1.ivx, (ftnlen)sizeof(integer));
	e_wsfi();
    } else {
	ici__1.icierr = 0;
	ici__1.icirnum = 1;
	ici__1.icirlen = 1;
	ici__1.iciunit = notexq + (*lnote - 1);
	ici__1.icifmt = "(i1)";
	s_wsfi(&ici__1);
	do_fio(&c__1, (char *)&combjmp_1.ivbjmp, (ftnlen)sizeof(integer));
	e_wsfi();
	combjmp_1.isbjmp = FALSE_;
    }
/* Writing concatenation */
    i__4[0] = *lnote, a__3[0] = notexq;
    i__4[1] = lnoten, a__3[1] = noteq;
    s_cat(notexq, a__3, i__4, &c__2, 79L);
    *lnote += lnoten;
    if (isdotm) {
	if (lnoten == 1) {
/* Writing concatenation */
	    i__2[0] = *lnote, a__1[0] = notexq;
	    i__2[1] = 1, a__1[1] = "{";
	    i__2[2] = 1, a__1[2] = noteq;
	    i__2[3] = 1, a__1[3] = "}";
	    s_cat(notexq, a__1, i__2, &c__4, 79L);
	    *lnote += 3;
	} else {
	    i__1 = lnoten - 2;
/* Writing concatenation */
	    i__4[0] = *lnote, a__3[0] = notexq;
	    i__4[1] = lnoten - 1 - i__1, a__3[1] = noteq + i__1;
	    s_cat(notexq, a__3, i__4, &c__2, 79L);
	    ++(*lnote);
	}
    }
    return 0;
} /* beamend_ */

/* Subroutine */ int beamid_(notexq, lnote, notexq_len)
char *notexq;
integer *lnote;
ftnlen notexq_len;
{
    /* System generated locals */
    address a__1[4], a__2[3], a__3[2];
    integer i__1, i__2[4], i__3[3], i__4[2];
    real r__1;
    icilist ici__1;

    /* Builtin functions */
    /* Subroutine */ int s_cat();
    integer pow_ii(), s_wsfi(), do_fio(), e_wsfi();

    /* Local variables */
    extern /* Subroutine */ int addblank_();
    extern integer ncmid_();
    static integer ipmid, iflop;
    static char noteq[8];
    static integer nlnum;
    extern /* Subroutine */ int notex_();
    static integer multl, multr, im, ip;
    extern /* Subroutine */ int ntrbbb_();
    static integer ipleft;
    extern /* Subroutine */ int notefq_();
    static real xnlmid;
    static logical isdotm;
    static integer lnoten, multip;
    extern /* Subroutine */ int putxtn_();
    static integer iud, mua, mub, iup, ipright;
    extern integer log2_();

    *lnote = 0;
    ip = all_1.list[(all_1.jn << 2) - 3];
    if (! bit_test(all_1.irest[commvl_1.ivx + ip * 7 - 8],0)) {
	multip = all_1.mult[commvl_1.ivx + ip * 7 - 8];

/* Move the following, because can't ask for note until after checking
 for*/
/*  embedded xtup with number, due to ordering/octave feature. */

/*         call notefq(noteq,lnoten,nolev(ivx,ip),ncmid(iv,ip)) */
/*      print*,'In beamid, nolev, notefq:', */
/*    *nolev(ivx,ip),' '//noteq(1:lnoten) */
    }
    if (comxtup_1.vxtup[commvl_1.ivx - 1]) {
	if (multip <= 0) {

/*  Xtuplet with no beam, just put in the right kind of note */

	    i__1 = ncmid_(&all_1.iv, &ip);
	    notefq_(noteq, &lnoten, &all_1.nolev[commvl_1.ivx + ip * 7 - 8], &
		    i__1, 8L);
	    if (lnoten == 1) {
		addblank_(noteq, &lnoten, 8L);
	    }
	    if (multip == 0) {
/* Writing concatenation */
		i__2[0] = 1, a__1[0] = all_1.sq;
		i__2[1] = 1, a__1[1] = "q";
		i__2[2] = 1, a__1[2] = all_1.ulq + (commvl_1.ivx + 
			all_1.ibmcnt[commvl_1.ivx - 1] * 7 - 8);
		i__2[3] = 8, a__1[3] = noteq;
		s_cat(notexq, a__1, i__2, &c__4, 79L);
	    } else if (multip == -1) {
/* Writing concatenation */
		i__2[0] = 1, a__1[0] = all_1.sq;
		i__2[1] = 1, a__1[1] = "h";
		i__2[2] = 1, a__1[2] = all_1.ulq + (commvl_1.ivx + 
			all_1.ibmcnt[commvl_1.ivx - 1] * 7 - 8);
		i__2[3] = 8, a__1[3] = noteq;
		s_cat(notexq, a__1, i__2, &c__4, 79L);
	    }
	    *lnote = lnoten + 3;
	    return 0;
	} else if (all_1.nodur[commvl_1.ivx + ip * 7 - 8] == 0) {

/*  In the xtup but not the last note */

	    if (all_1.nodur[commvl_1.ivx + (ip - 1) * 7 - 8] > 0) {

/*  Embedded Xtup, mult>0, starts here.  Put in number if need
ed */

		iud = 1;
		if (*(unsigned char *)&all_1.ulq[commvl_1.ivx + all_1.ibmcnt[
			commvl_1.ivx - 1] * 7 - 8] == 'u') {
		    iud = -1;
		}

/*  Get ip#, notelevel of middle note (or gap) in xtup */

		ipmid = ip + comxtup_1.ntupv[commvl_1.ivx - 1] / 2;
		xnlmid = (real) all_1.nolev[commvl_1.ivx + ipmid * 7 - 8];
		if (comxtup_1.ntupv[commvl_1.ivx - 1] % 2 == 0) {
		    xnlmid = (xnlmid + all_1.nolev[commvl_1.ivx + (ipmid - 1) 
			    * 7 - 8]) / (float)2.;
		}
		iflop = 0;
		if ((r__1 = xnlmid - ncmid_(&all_1.iv, &ip), dabs(r__1)) < (
			float)3.) {
		    iflop = -iud;
		}
		iup = iud + (iflop << 1);
		if (bit_test(all_1.irest[commvl_1.ivx + ip * 7 - 8],14)) {
		    iup = -iup;
		    iflop = 0;
		    if (iud * iup < 0) {
			iflop = iup;
		    }
		}

/*  Place number if needed */

		if (! bit_test(all_1.islur[commvl_1.ivx + ip * 7 - 8],31)) {
		    i__1 = ncmid_(&all_1.iv, &ip);
		    putxtn_(&comxtup_1.ntupv[commvl_1.ivx - 1], &iflop, &
			    multip, &iud, &comask_2.wheadpt, &comask_2.poenom,
			     &comxtup_1.nolev1, &comxtup_1.islope, &
			    all_1.slfac, &xnlmid, &all_1.islur[commvl_1.ivx + 
			    ip * 7 - 8], lnote, notexq, &i__1, &nlnum, &
			    comxtup_1.eloff, &iup, &all_1.irest[commvl_1.ivx 
			    + ip * 7 - 8], 79L);
		}
		i__1 = ncmid_(&all_1.iv, &ip);
		notefq_(noteq, &lnoten, &all_1.nolev[commvl_1.ivx + ip * 7 - 
			8], &i__1, 8L);
	    } else {

/*  Intermediate note of xtup */

		i__1 = ncmid_(&all_1.iv, &ip);
		notefq_(noteq, &lnoten, &all_1.nolev[commvl_1.ivx + ip * 7 - 
			8], &i__1, 8L);
	    }
	} else {

/*  Last note of xtup */

	    i__1 = ncmid_(&all_1.iv, &ip);
	    notefq_(noteq, &lnoten, &all_1.nolev[commvl_1.ivx + ip * 7 - 8], &
		    i__1, 8L);
	}
    } else if (bit_test(all_1.irest[commvl_1.ivx + ip * 7 - 8],0)) {
	notex_(notexq, lnote, 79L);
	return 0;
    } else {
	i__1 = ncmid_(&all_1.iv, &ip);
	notefq_(noteq, &lnoten, &all_1.nolev[commvl_1.ivx + ip * 7 - 8], &
		i__1, 8L);
    }

/* Check if multiplicity changes in a way requiring action */

    ipleft = ip - 1;
    if (bit_test(all_1.irest[commvl_1.ivx + ipleft * 7 - 8],0)) {
	--ipleft;
    }
    if (! bit_test(all_1.islur[commvl_1.ivx + ipleft * 7 - 8],20)) {
	multl = all_1.mult[commvl_1.ivx + ipleft * 7 - 8];
    } else {
	multl = 1;
    }
    mub = multip - multl;
    ipright = ip + 1;
    if (bit_test(all_1.irest[commvl_1.ivx + ipright * 7 - 8],0)) {
	--ipright;
    }
    if (! bit_test(all_1.islur[commvl_1.ivx + ip * 7 - 8],20)) {
	multr = all_1.mult[commvl_1.ivx + ipright * 7 - 8];
    } else {
	multr = 1;
    }
    mua = multr - multip;
    if (mub > 0 || mua < 0) {

/* Multiplicity has increased from left or will decrease to right. Nee
d action.*/

	if (mua >= 0) {
	    ntrbbb_(&multip, "n", all_1.ulq + (commvl_1.ivx + all_1.ibmcnt[
		    commvl_1.ivx - 1] * 7 - 8), &commvl_1.ivx, notexq, lnote, 
		    1L, 1L, 79L);
	} else if (multl >= multr) {
	    i__1 = multr + 1;
	    for (im = multip; im >= i__1; --im) {
		ntrbbb_(&im, "t", all_1.ulq + (commvl_1.ivx + all_1.ibmcnt[
			commvl_1.ivx - 1] * 7 - 8), &commvl_1.ivx, notexq, 
			lnote, 1L, 1L, 79L);
/* L1: */
	    }
	} else {
	    i__1 = multip;
	    for (im = multr + 1; im <= i__1; ++im) {
		ntrbbb_(&im, "r", all_1.ulq + (commvl_1.ivx + all_1.ibmcnt[
			commvl_1.ivx - 1] * 7 - 8), &commvl_1.ivx, notexq, 
			lnote, 1L, 1L, 79L);
/* L2: */
	    }
	    ntrbbb_(&multr, "n", all_1.ulq + (commvl_1.ivx + all_1.ibmcnt[
		    commvl_1.ivx - 1] * 7 - 8), &commvl_1.ivx, notexq, lnote, 
		    1L, 1L, 79L);
	}
    }

/* Now put in the note */

    if (*lnote > 0) {
/* Writing concatenation */
	i__3[0] = *lnote, a__2[0] = notexq;
	i__3[1] = 1, a__2[1] = all_1.sq;
	i__3[2] = 2, a__2[2] = "qb";
	s_cat(notexq, a__2, i__3, &c__3, 79L);
    } else {
/* Writing concatenation */
	i__4[0] = 1, a__3[0] = all_1.sq;
	i__4[1] = 2, a__3[1] = "qb";
	s_cat(notexq, a__3, i__4, &c__2, 79L);
    }
    *lnote += 3;
    isdotm = FALSE_;
/*       if (.not.vxtup(ivx) .and. 2**log2(nodur(ivx,ip)).ne. */
/*    *          nodur(ivx,ip)) then */
    if (! comxtup_1.vxtup[commvl_1.ivx - 1]) {
	i__1 = log2_(&all_1.nodur[commvl_1.ivx + ip * 7 - 8]);
	if (pow_ii(&c__2, &i__1) != all_1.nodur[commvl_1.ivx + ip * 7 - 8]) {
/*           if (ornq(ivx,ip) .ne. ')') then */
	    if (! bit_test(all_1.iornq[commvl_1.ivx + ip * 7 - 8],13)) {
/* Writing concatenation */
		i__4[0] = *lnote, a__3[0] = notexq;
		i__4[1] = 1, a__3[1] = "p";
		s_cat(notexq, a__3, i__4, &c__2, 79L);
	    } else {
/* Writing concatenation */
		i__4[0] = *lnote, a__3[0] = notexq;
		i__4[1] = 1, a__3[1] = "m";
		s_cat(notexq, a__3, i__4, &c__2, 79L);
		isdotm = TRUE_;
	    }
	    ++(*lnote);
	}
    }
    ++(*lnote);
    if (! combjmp_1.isbjmp) {
	ici__1.icierr = 0;
	ici__1.icirnum = 1;
	ici__1.icirlen = 1;
	ici__1.iciunit = notexq + (*lnote - 1);
	ici__1.icifmt = "(i1)";
	s_wsfi(&ici__1);
	do_fio(&c__1, (char *)&commvl_1.ivx, (ftnlen)sizeof(integer));
	e_wsfi();
    } else {
	ici__1.icierr = 0;
	ici__1.icirnum = 1;
	ici__1.icirlen = 1;
	ici__1.iciunit = notexq + (*lnote - 1);
	ici__1.icifmt = "(i1)";
	s_wsfi(&ici__1);
	do_fio(&c__1, (char *)&combjmp_1.ivbjmp, (ftnlen)sizeof(integer));
	e_wsfi();
    }
/* Writing concatenation */
    i__4[0] = *lnote, a__3[0] = notexq;
    i__4[1] = lnoten, a__3[1] = noteq;
    s_cat(notexq, a__3, i__4, &c__2, 79L);
    *lnote += lnoten;
    if (isdotm) {
	if (lnoten == 2) {
/* Writing concatenation */
	    i__2[0] = *lnote, a__1[0] = notexq;
	    i__2[1] = 1, a__1[1] = "{";
	    i__2[2] = 1, a__1[2] = noteq + 1;
	    i__2[3] = 1, a__1[3] = "}";
	    s_cat(notexq, a__1, i__2, &c__4, 79L);
	    *lnote += 3;
	} else {
	    i__1 = lnoten - 2;
/* Writing concatenation */
	    i__4[0] = *lnote, a__3[0] = notexq;
	    i__4[1] = lnoten - 1 - i__1, a__3[1] = noteq + i__1;
	    s_cat(notexq, a__3, i__4, &c__2, 79L);
	    ++(*lnote);
	}
    }
    return 0;
} /* beamid_ */

/* Subroutine */ int ntrbbb_(n, char1q, ulqq, iv, notexq, lnote, char1q_len, 
	ulqq_len, notexq_len)
integer *n;
char *char1q, *ulqq;
integer *iv;
char *notexq;
integer *lnote;
ftnlen char1q_len;
ftnlen ulqq_len;
ftnlen notexq_len;
{
    /* System generated locals */
    address a__1[3], a__2[2];
    integer i__1[3], i__2[2], i__3;
    char ch__1[1];

    /* Builtin functions */
    /* Subroutine */ int s_cat();

    /* Local variables */
    static integer im;


/*  This appends to notexq e.g. '\ibbbu1' */

    if (*lnote > 0) {
/* Writing concatenation */
	i__1[0] = *lnote, a__1[0] = notexq;
	i__1[1] = 1, a__1[1] = "\\";
	i__1[2] = 1, a__1[2] = char1q;
	s_cat(notexq, a__1, i__1, &c__3, 79L);
    } else {
/* Writing concatenation */
	i__2[0] = 1, a__2[0] = "\\";
	i__2[1] = 1, a__2[1] = char1q;
	s_cat(notexq, a__2, i__2, &c__2, 79L);
    }
    *lnote += 2;
    i__3 = *n;
    for (im = 1; im <= i__3; ++im) {
/* Writing concatenation */
	i__2[0] = *lnote, a__2[0] = notexq;
	i__2[1] = 1, a__2[1] = "b";
	s_cat(notexq, a__2, i__2, &c__2, 79L);
	++(*lnote);
/* L3: */
    }
/* Writing concatenation */
    i__1[0] = *lnote, a__1[0] = notexq;
    i__1[1] = 1, a__1[1] = ulqq;
    *(unsigned char *)&ch__1[0] = *iv + 48;
    i__1[2] = 1, a__1[2] = ch__1;
    s_cat(notexq, a__1, i__1, &c__3, 79L);
    *lnote += 2;
    return 0;
} /* ntrbbb_ */

/* Subroutine */ int addstr_(notexq, lnote, soutq, lsout, notexq_len, 
	soutq_len)
char *notexq;
integer *lnote;
char *soutq;
integer *lsout;
ftnlen notexq_len;
ftnlen soutq_len;
{
    /* System generated locals */
    address a__1[2];
    integer i__1[2];
    char ch__1[81];

    /* Builtin functions */
    integer s_wsfe();
    /* Subroutine */ int s_cat();
    integer do_fio(), e_wsfe();
    /* Subroutine */ int s_copy();

    /* Fortran I/O blocks */
    static cilist io___508 = { 0, 11, 0, "(a)", 0 };


    if (*lsout + *lnote > 72) {
	s_wsfe(&io___508);
/* Writing concatenation */
	i__1[0] = *lsout, a__1[0] = soutq;
	i__1[1] = 1, a__1[1] = "%";
	s_cat(ch__1, a__1, i__1, &c__2, 81L);
	do_fio(&c__1, ch__1, *lsout + 1);
	e_wsfe();
	*lsout = 0;
    }
    if (*lsout > 0) {
/* Writing concatenation */
	i__1[0] = *lsout, a__1[0] = soutq;
	i__1[1] = *lnote, a__1[1] = notexq;
	s_cat(soutq, a__1, i__1, &c__2, 80L);
    } else {
	s_copy(soutq, notexq, 80L, (*lnote));
    }
    *lsout += *lnote;
    return 0;
} /* addstr_ */

/* Subroutine */ int notefq_(noteq, lnote, nolev, ncmid, noteq_len)
char *noteq;
integer *lnote, *nolev, *ncmid;
ftnlen noteq_len;
{
    /* System generated locals */
    integer i__1;
    char ch__1[1];
    icilist ici__1;

    /* Builtin functions */
    /* Subroutine */ int s_copy();
    integer s_wsfi(), do_fio(), e_wsfi();

    /* Local variables */
    static integer nupfroma, i__, iname, ioctup;
    static char noteqt[1];
    extern /* Character */ VOID upcaseq_();

    nupfroma = (*nolev + 1) % 7;
    iname = nupfroma + 97;
    ioctup = (*nolev + 1) / 7 - 4;
    *(unsigned char *)noteqt = (char) iname;
    if (*ncmid == 23) {
	upcaseq_(ch__1, 1L, noteqt, 1L);
	*(unsigned char *)noteqt = *(unsigned char *)&ch__1[0];
    }
    if (ioctup == comoct_1.noctup) {
	*lnote = 1;
	s_copy(noteq, noteqt, 8L, 1L);

/*  Must ALWAYS check if lnote=1 for use with functions requiring a bl
ank */

    } else if (ioctup > comoct_1.noctup) {

/*  Raise octave.  Encase in {} */

	ici__1.icierr = 0;
	ici__1.icirnum = 1;
	ici__1.icirlen = 8;
	ici__1.iciunit = noteq;
	ici__1.icifmt = "(8a1)";
	s_wsfi(&ici__1);
	do_fio(&c__1, "{", 1L);
	i__1 = ioctup - 1;
	for (i__ = comoct_1.noctup; i__ <= i__1; ++i__) {
	    do_fio(&c__1, "'", 1L);
	}
	do_fio(&c__1, noteqt, 1L);
	do_fio(&c__1, "}", 1L);
	e_wsfi();
	*lnote = ioctup + 3 - comoct_1.noctup;
	comoct_1.noctup = ioctup;
    } else {

/*  Lower octave */

	ici__1.icierr = 0;
	ici__1.icirnum = 1;
	ici__1.icirlen = 8;
	ici__1.iciunit = noteq;
	ici__1.icifmt = "(8a1)";
	s_wsfi(&ici__1);
	do_fio(&c__1, "{", 1L);
	i__1 = comoct_1.noctup - 1;
	for (i__ = ioctup; i__ <= i__1; ++i__) {
	    do_fio(&c__1, "`", 1L);
	}
	do_fio(&c__1, noteqt, 1L);
	do_fio(&c__1, "}", 1L);
	e_wsfi();
	*lnote = comoct_1.noctup + 3 - ioctup;
	comoct_1.noctup = ioctup;
    }
    return 0;
} /* notefq_ */

/* Subroutine */ int notex_(notexq, lnote, notexq_len)
char *notexq;
integer *lnote;
ftnlen notexq_len;
{
    /* System generated locals */
    address a__1[4], a__2[3], a__3[5], a__4[2];
    integer i__1, i__2, i__3[4], i__4[3], i__5[5], i__6[2];
    char ch__1[1];

    /* Builtin functions */
    /* Subroutine */ int s_cat();
    integer pow_ii();
    /* Subroutine */ int s_copy();
    integer s_wsfi(), do_fio(), e_wsfi(), i_sign();

    /* Local variables */
    extern /* Subroutine */ int addblank_();
    static integer nole, nodu;
    static char dotq[1];
    extern /* Character */ VOID udqq_();
    static real zmin;
    extern integer ncmid_();
    static real fnole;
    static char noteq[8];
    static integer lrest;
    static char restq[8];
    static integer ip;
    extern /* Subroutine */ int notefq_();
    static integer lnoten;
    static char udq[1];
    extern integer log2_();

    /* Fortran I/O blocks */
    static icilist io___525 = { 0, noteq, 0, "(i2)", 2, 1 };
    static icilist io___526 = { 0, noteq+1, 0, "(i2)", 2, 1 };
    static icilist io___527 = { 0, noteq+1, 0, "(i3)", 3, 1 };


    ip = all_1.list[(all_1.jn << 2) - 3];
    nole = all_1.nolev[commvl_1.ivx + ip * 7 - 8];
    nodu = all_1.nodur[commvl_1.ivx + ip * 7 - 8];
    if (! bit_test(all_1.irest[commvl_1.ivx + ip * 7 - 8],0)) {
	i__1 = ncmid_(&all_1.iv, &ip);
	udqq_(ch__1, 1L, &nole, &i__1, &all_1.islur[commvl_1.ivx + ip * 7 - 8]
		, &commvl_1.nvmx[all_1.iv - 1], &commvl_1.ivx, &all_1.nv);
	*(unsigned char *)udq = *(unsigned char *)&ch__1[0];
    }

/*  Check figure level */

    if (all_1.figbass && commvl_1.ivx == 1 && all_1.isfig[ip - 1] && ! 
	    bit_test(all_1.irest[commvl_1.ivx + ip * 7 - 8],0)) {
	if (*(unsigned char *)udq == 'u') {

/*  Upper stem, fnole (in noleunits) set by notehead */

	    fnole = (real) nole;
	} else {

/*  Lower stem, fnole set by bottom of stem */

	    fnole = nole - all_1.stemlen;
	}
	zmin = fnole - ncmid_(&c__1, &ip) + 4;
/* Computing MAX */
	i__1 = all_1.ifigdrop[all_1.iline - 1], i__2 = (integer) (4 - zmin + (
		float).5);
	all_1.ifigdrop[all_1.iline - 1] = max(i__1,i__2);
    }
    if (! bit_test(all_1.irest[commvl_1.ivx + ip * 7 - 8],0)) {
	i__1 = ncmid_(&all_1.iv, &ip);
	notefq_(noteq, &lnoten, &nole, &i__1, 8L);
	if (lnoten == 1) {
	    addblank_(noteq, &lnoten, 8L);
	}
	if (nodu == 1) {
/* Writing concatenation */
	    i__3[0] = 1, a__1[0] = all_1.sq;
	    i__3[1] = 4, a__1[1] = "cccc";
	    i__3[2] = 1, a__1[2] = udq;
	    i__3[3] = lnoten, a__1[3] = noteq;
	    s_cat(notexq, a__1, i__3, &c__4, 79L);
	    *lnote = lnoten + 6;
	} else if (nodu == 2) {
/* Writing concatenation */
	    i__3[0] = 1, a__1[0] = all_1.sq;
	    i__3[1] = 3, a__1[1] = "ccc";
	    i__3[2] = 1, a__1[2] = udq;
	    i__3[3] = lnoten, a__1[3] = noteq;
	    s_cat(notexq, a__1, i__3, &c__4, 79L);
	    *lnote = lnoten + 5;
	} else if (nodu == 4) {
/* Writing concatenation */
	    i__3[0] = 1, a__1[0] = all_1.sq;
	    i__3[1] = 2, a__1[1] = "cc";
	    i__3[2] = 1, a__1[2] = udq;
	    i__3[3] = lnoten, a__1[3] = noteq;
	    s_cat(notexq, a__1, i__3, &c__4, 79L);
	    *lnote = lnoten + 4;
	} else if (nodu == 8) {
/* Writing concatenation */
	    i__3[0] = 1, a__1[0] = all_1.sq;
	    i__3[1] = 1, a__1[1] = "c";
	    i__3[2] = 1, a__1[2] = udq;
	    i__3[3] = lnoten, a__1[3] = noteq;
	    s_cat(notexq, a__1, i__3, &c__4, 79L);
	    *lnote = lnoten + 3;
	} else if (nodu == 16) {
/* Writing concatenation */
	    i__3[0] = 1, a__1[0] = all_1.sq;
	    i__3[1] = 1, a__1[1] = "q";
	    i__3[2] = 1, a__1[2] = udq;
	    i__3[3] = lnoten, a__1[3] = noteq;
	    s_cat(notexq, a__1, i__3, &c__4, 79L);
	    *lnote = lnoten + 3;
	} else if (nodu == 32) {
/* Writing concatenation */
	    i__3[0] = 1, a__1[0] = all_1.sq;
	    i__3[1] = 1, a__1[1] = "h";
	    i__3[2] = 1, a__1[2] = udq;
	    i__3[3] = lnoten, a__1[3] = noteq;
	    s_cat(notexq, a__1, i__3, &c__4, 79L);
	    *lnote = lnoten + 3;
	} else if (nodu == 64) {
/* Writing concatenation */
	    i__4[0] = 1, a__2[0] = all_1.sq;
	    i__4[1] = 2, a__2[1] = "wh";
	    i__4[2] = lnoten, a__2[2] = noteq;
	    s_cat(notexq, a__2, i__4, &c__3, 79L);
	    *lnote = lnoten + 3;
	} else if (nodu == 128) {
/* Writing concatenation */
	    i__5[0] = 1, a__3[0] = all_1.sq;
	    i__5[1] = 6, a__3[1] = "zbreve";
	    i__5[2] = lnoten, a__3[2] = noteq;
	    i__5[3] = 1, a__3[3] = all_1.sq;
	    i__5[4] = 2, a__3[4] = "sk";
	    s_cat(notexq, a__3, i__5, &c__5, 79L);
	    *lnote = lnoten + 10;
	} else {
	    *(unsigned char *)dotq = 'p';
/*           if (ornq(ivx,ip) .eq. ')') dotq='m' */
	    if (bit_test(all_1.iornq[commvl_1.ivx + ip * 7 - 8],13)) {
		*(unsigned char *)dotq = 'm';
	    }
	    if (nodu == 12) {
/* Writing concatenation */
		i__5[0] = 1, a__3[0] = all_1.sq;
		i__5[1] = 1, a__3[1] = "c";
		i__5[2] = 1, a__3[2] = udq;
		i__5[3] = 1, a__3[3] = dotq;
		i__5[4] = lnoten, a__3[4] = noteq;
		s_cat(notexq, a__3, i__5, &c__5, 79L);
		*lnote = lnoten + 4;
	    } else if (nodu == 24) {
/* Writing concatenation */
		i__5[0] = 1, a__3[0] = all_1.sq;
		i__5[1] = 1, a__3[1] = "q";
		i__5[2] = 1, a__3[2] = udq;
		i__5[3] = 1, a__3[3] = dotq;
		i__5[4] = lnoten, a__3[4] = noteq;
		s_cat(notexq, a__3, i__5, &c__5, 79L);
		*lnote = lnoten + 4;
	    } else if (nodu == 48) {
/* Writing concatenation */
		i__5[0] = 1, a__3[0] = all_1.sq;
		i__5[1] = 1, a__3[1] = "h";
		i__5[2] = 1, a__3[2] = udq;
		i__5[3] = 1, a__3[3] = dotq;
		i__5[4] = lnoten, a__3[4] = noteq;
		s_cat(notexq, a__3, i__5, &c__5, 79L);
		*lnote = lnoten + 4;
	    } else if (nodu == 96) {
/* Writing concatenation */
		i__4[0] = 1, a__2[0] = all_1.sq;
		i__4[1] = 3, a__2[1] = "whp";
		i__4[2] = lnoten, a__2[2] = noteq;
		s_cat(notexq, a__2, i__4, &c__3, 79L);
		*lnote = lnoten + 4;
	    } else if (nodu == 6) {
/* Writing concatenation */
		i__5[0] = 1, a__3[0] = all_1.sq;
		i__5[1] = 2, a__3[1] = "cc";
		i__5[2] = 1, a__3[2] = udq;
		i__5[3] = 1, a__3[3] = dotq;
		i__5[4] = lnoten, a__3[4] = noteq;
		s_cat(notexq, a__3, i__5, &c__5, 79L);
		*lnote = lnoten + 5;
		compoi_1.ispoi = TRUE_;
	    } else if (nodu == 3) {
/* Writing concatenation */
		i__5[0] = 1, a__3[0] = all_1.sq;
		i__5[1] = 3, a__3[1] = "ccc";
		i__5[2] = 1, a__3[2] = udq;
		i__5[3] = 1, a__3[3] = dotq;
		i__5[4] = lnoten, a__3[4] = noteq;
		s_cat(notexq, a__3, i__5, &c__5, 79L);
		*lnote = lnoten + 6;
		compoi_1.ispoi = TRUE_;
	    }
	    if (*(unsigned char *)dotq == 'm') {

/*  Need another call to the note, in case the first on has oc
tave shifts */

		if (lnoten == 2) {
/* Writing concatenation */
		    i__3[0] = *lnote, a__1[0] = notexq;
		    i__3[1] = 1, a__1[1] = "{";
		    i__3[2] = 1, a__1[2] = noteq + 1;
		    i__3[3] = 1, a__1[3] = "}";
		    s_cat(notexq, a__1, i__3, &c__4, 79L);
		    *lnote += 3;
		} else {
		    i__1 = lnoten - 2;
/* Writing concatenation */
		    i__6[0] = *lnote, a__4[0] = notexq;
		    i__6[1] = lnoten - 1 - i__1, a__4[1] = noteq + i__1;
		    s_cat(notexq, a__4, i__6, &c__2, 79L);
		    ++(*lnote);
		}
	    }
	}
    } else if (! bit_test(all_1.islur[commvl_1.ivx + ip * 7 - 8],19)) {

/*  Rest, but not full-bar-pause */

	*lnote = 0;
	nole = (nole + 20) % 100 - 20;
	if (bit_test(all_1.islur[commvl_1.ivx + ip * 7 - 8],29)) {

/*  Blank rest */

/* Writing concatenation */
	    i__6[0] = 1, a__4[0] = all_1.sq;
	    i__6[1] = 2, a__4[1] = "sk";
	    s_cat(notexq, a__4, i__6, &c__2, 79L);
	    *lnote = 3;
	} else if (nodu <= 24) {

/*  Normal rest < or = quarter */

	    if (nodu == 2) {
/* Writing concatenation */
		i__6[0] = 1, a__4[0] = all_1.sq;
		i__6[1] = 2, a__4[1] = "hs";
		s_cat(restq, a__4, i__6, &c__2, 8L);
	    } else if (nodu <= 6) {
/* Writing concatenation */
		i__6[0] = 1, a__4[0] = all_1.sq;
		i__6[1] = 2, a__4[1] = "qs";
		s_cat(restq, a__4, i__6, &c__2, 8L);
	    } else if (nodu <= 12) {
/* Writing concatenation */
		i__6[0] = 1, a__4[0] = all_1.sq;
		i__6[1] = 2, a__4[1] = "ds";
		s_cat(restq, a__4, i__6, &c__2, 8L);
	    } else {
/* Writing concatenation */
		i__6[0] = 1, a__4[0] = all_1.sq;
		i__6[1] = 2, a__4[1] = "qp";
		s_cat(restq, a__4, i__6, &c__2, 8L);
	    }
	    lrest = 3;
	    i__1 = log2_(&nodu);
	    if (pow_ii(&c__2, &i__1) != nodu) {
/* Writing concatenation */
		i__6[0] = 3, a__4[0] = restq;
		i__6[1] = 1, a__4[1] = "p";
		s_cat(restq, a__4, i__6, &c__2, 8L);
		lrest = 4;
	    }
	    s_copy(notexq, restq, 79L, 8L);
	    *lnote = lrest;

/* At this point notexq=restq,lnote=lrest are name of rest.  Now r
aise if necc.*/

	    if (nole != 0) {
		if (abs(nole) < 10) {
		    *(unsigned char *)&ch__1[0] = abs(nole) + 48;
		    s_copy(noteq, ch__1, 8L, 1L);
		    lnoten = 1;
		} else {
		    s_wsfi(&io___525);
		    i__1 = abs(nole);
		    do_fio(&c__1, (char *)&i__1, (ftnlen)sizeof(integer));
		    e_wsfi();
		    lnoten = 2;
		}
		if (nole > 0) {
/* Writing concatenation */
		    i__5[0] = 1, a__3[0] = all_1.sq;
		    i__5[1] = 5, a__3[1] = "raise";
		    i__5[2] = lnoten, a__3[2] = noteq;
		    i__5[3] = 1, a__3[3] = all_1.sq;
		    i__5[4] = 9, a__3[4] = "internote";
		    s_cat(notexq, a__3, i__5, &c__5, 79L);
		} else {
/* Writing concatenation */
		    i__5[0] = 1, a__3[0] = all_1.sq;
		    i__5[1] = 5, a__3[1] = "lower";
		    i__5[2] = lnoten, a__3[2] = noteq;
		    i__5[3] = 1, a__3[3] = all_1.sq;
		    i__5[4] = 9, a__3[4] = "internote";
		    s_cat(notexq, a__3, i__5, &c__5, 79L);
		}
		*lnote = lnoten + 16;
		i__1 = log2_(&nodu);
		if (pow_ii(&c__2, &i__1) != nodu) {

/*  Have dot in raised rest.  must put in hbox! */

/* Writing concatenation */
		    i__4[0] = *lnote, a__2[0] = notexq;
		    i__4[1] = 1, a__2[1] = all_1.sq;
		    i__4[2] = 5, a__2[2] = "hbox{";
		    s_cat(notexq, a__2, i__4, &c__3, 79L);
		    *lnote += 6;
		}
/* Writing concatenation */
		i__6[0] = *lnote, a__4[0] = notexq;
		i__6[1] = lrest, a__4[1] = restq;
		s_cat(notexq, a__4, i__6, &c__2, 79L);
		*lnote += lrest;
		i__1 = log2_(&nodu);
		if (pow_ii(&c__2, &i__1) != nodu) {
/* Writing concatenation */
		    i__6[0] = *lnote, a__4[0] = notexq;
		    i__6[1] = 1, a__4[1] = "}";
		    s_cat(notexq, a__4, i__6, &c__2, 79L);
		    ++(*lnote);
		}
	    }
	} else {

/*  Half or whole rest */

	    if (nole == 0) {
		if (nodu <= 48) {
/* Writing concatenation */
		    i__6[0] = 1, a__4[0] = all_1.sq;
		    i__6[1] = 6, a__4[1] = "hpause";
		    s_cat(notexq, a__4, i__6, &c__2, 79L);
		    *lnote = 7;
		} else {
/* Writing concatenation */
		    i__6[0] = 1, a__4[0] = all_1.sq;
		    i__6[1] = 5, a__4[1] = "pause";
		    s_cat(notexq, a__4, i__6, &c__2, 79L);
		    *lnote = 6;
		}
		i__1 = log2_(&nodu);
		if (pow_ii(&c__2, &i__1) != nodu) {
/* Writing concatenation */
		    i__6[0] = *lnote, a__4[0] = notexq;
		    i__6[1] = 1, a__4[1] = "p";
		    s_cat(notexq, a__4, i__6, &c__2, 79L);
		    ++(*lnote);
		}
	    } else {
		if (nodu == 32) {
/* Writing concatenation */
		    i__6[0] = 1, a__4[0] = all_1.sq;
		    i__6[1] = 10, a__4[1] = "lifthpause";
		    s_cat(notexq, a__4, i__6, &c__2, 79L);
		    *lnote = 11;
		} else if (nodu == 48) {
/* Writing concatenation */
		    i__6[0] = 1, a__4[0] = all_1.sq;
		    i__6[1] = 11, a__4[1] = "lifthpausep";
		    s_cat(notexq, a__4, i__6, &c__2, 79L);
		    *lnote = 12;
		} else if (nodu == 64) {
/* Writing concatenation */
		    i__6[0] = 1, a__4[0] = all_1.sq;
		    i__6[1] = 9, a__4[1] = "liftpause";
		    s_cat(notexq, a__4, i__6, &c__2, 79L);
		    *lnote = 10;
		} else {
/* Writing concatenation */
		    i__6[0] = 1, a__4[0] = all_1.sq;
		    i__6[1] = 10, a__4[1] = "liftpausep";
		    s_cat(notexq, a__4, i__6, &c__2, 79L);
		    *lnote = 11;
		}

/*  Set up height spec */

		i__1 = abs(nole) / 2;
		nole = i_sign(&i__1, &nole);
		if (nole <= 9 && nole >= 0) {
		    *(unsigned char *)&ch__1[0] = nole + 48;
		    s_copy(noteq, ch__1, 8L, 1L);
		    lnoten = 1;
		} else {
		    s_copy(noteq, "{", 8L, 1L);
		    if (nole >= -9) {
			s_wsfi(&io___526);
			do_fio(&c__1, (char *)&nole, (ftnlen)sizeof(integer));
			e_wsfi();
			lnoten = 3;
		    } else {
			s_wsfi(&io___527);
			do_fio(&c__1, (char *)&nole, (ftnlen)sizeof(integer));
			e_wsfi();
			lnoten = 4;
		    }
/* Writing concatenation */
		    i__6[0] = lnoten, a__4[0] = noteq;
		    i__6[1] = 1, a__4[1] = "}";
		    s_cat(noteq, a__4, i__6, &c__2, 8L);
		    ++lnoten;
		}
/* Writing concatenation */
		i__6[0] = *lnote, a__4[0] = notexq;
		i__6[1] = lnoten, a__4[1] = noteq;
		s_cat(notexq, a__4, i__6, &c__2, 79L);
		*lnote += lnoten;
	    }
	}
    } else {

/*  Full-bar-pause */

/* Writing concatenation */
	i__6[0] = 1, a__4[0] = all_1.sq;
	i__6[1] = 5, a__4[1] = "pause";
	s_cat(notexq, a__4, i__6, &c__2, 79L);
	*lnote = 6;
    }
    return 0;
} /* notex_ */

/* Character */ VOID udqq_(ret_val, ret_val_len, nole, ncm, isl, nvmx, ivx, 
	nv)
char *ret_val;
ftnlen ret_val_len;
integer *nole, *ncm, *isl, *nvmx, *ivx, *nv;
{
    /* System generated locals */
    real r__1;
    char ch__2[1];

    /* Local variables */
    extern /* Character */ VOID ulfq_();
    static char udqqq[1];


/*  Stem direction for single notes */

    if (bit_test(*isl,30)) {

/*  Absolute override */

	if (bit_test(*isl,17)) {
	    *(unsigned char *)udqqq = 'u';
	} else {
	    *(unsigned char *)udqqq = 'l';
	}
    } else if (*nvmx == 1) {

/*  Single voice per staff, default */

	r__1 = *nole * (float)1.;
	ulfq_(ch__2, 1L, &r__1, ncm);
	*(unsigned char *)udqqq = *(unsigned char *)&ch__2[0];
    } else {

/*  Multi-voice per staff, 1st is lower, 2nd upper */

	if (*ivx <= *nv) {
	    *(unsigned char *)udqqq = 'l';
	} else {
	    *(unsigned char *)udqqq = 'u';
	}
    }
    *(unsigned char *)ret_val = *(unsigned char *)udqqq;
    return ;
} /* udqq_ */

/* Subroutine */ int findbeam_(ibmrep, numbms, mapfb)
integer *ibmrep, *numbms, *mapfb;
{
    /* Initialized data */

    static integer nip1[48] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
    static integer nip2[48] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
    static integer nummask[3] = { 29,49,12 };
    static integer mask[147]	/* was [49][3] */ = { 65535,4095,65520,255,
	    65280,63,252,16128,64512,15,240,3840,61440,7,14,112,224,1792,3584,
	    28672,57344,3,12,48,192,768,3072,12288,49152,0,0,0,0,0,0,0,0,0,0,
	    0,0,0,0,0,0,0,0,0,0,16777215,65535,16776960,4095,65520,1048320,
	    16773120,255,65280,16711680,63,252,16128,64512,4128768,16515072,
	    15,60,240,3840,15360,61440,983040,3932160,15728640,7,14,112,224,
	    1792,3584,28672,57344,458752,917504,7340032,14680064,3,12,48,192,
	    768,3072,12288,49152,196608,786432,3145728,12582912,4095,255,4080,
	    15,240,3840,3,12,48,192,768,3072,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
    static logical eqonly[147]	/* was [49][3] */ = { TRUE_,TRUE_,TRUE_,
	    FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,
	    FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,
	    FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,
	    FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,
	    FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,
	    FALSE_,TRUE_,TRUE_,TRUE_,TRUE_,TRUE_,TRUE_,TRUE_,FALSE_,FALSE_,
	    FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,
	    FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,
	    FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,
	    FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,
	    FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,
	    FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,
	    FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,
	    FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,
	    FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,
	    FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_,FALSE_ };

    /* System generated locals */
    integer i__1, i__2, i__3, i__4;

    /* Builtin functions */
    integer lbit_shift(), s_wsle(), do_lio(), e_wsle();

    /* Local variables */
    static integer mape, mapm, irep, maps, nreal, itend, itoff, maskm, nodue[
	    48], itseg, mtemp;
    static logical short__[48];
    static integer ib, ip, ir, it, is, ithalf, ib1, ib2, numnew, ir1, is1, 
	    it2, is2, iip;
    extern /* Subroutine */ int logbeam_();
    static integer ipr[48], itr[48], masknow;

    /* Fortran I/O blocks */
    static cilist io___561 = { 0, 6, 0, 0, 0 };



/*  Called once per voice per bar, after setting forced beams. */

    /* Parameter adjustments */
    --mapfb;
    --numbms;

    /* Function Body */
    ip = 0;
    nreal = 0;
L1:
    ++ip;
    if (ip > all_1.nn[commvl_1.ivx - 1]) {
	goto L9;
    }
L11:
    if (all_1.nodur[commvl_1.ivx + ip * 7 - 8] == 0) {
	++ip;
	goto L11;
    }
    ++nreal;
    nodue[nreal - 1] = all_1.nodur[commvl_1.ivx + ip * 7 - 8];
    short__[nreal - 1] = nodue[nreal - 1] < 16 && ! bit_test(all_1.irest[
	    commvl_1.ivx + ip * 7 - 8],0) && ! bit_test(all_1.islur[
	    commvl_1.ivx + ip * 7 - 8],18);
/* ++  Rule out notes that have 'alone'-flag set */
    ipr[nreal - 1] = ip;
    itr[nreal - 1] = all_1.list[((255 & all_1.ipl[commvl_1.ivx + ip * 7 - 8]) 
	    << 2) - 2];
    if (nodue[nreal - 1] == 1) {
	if (all_1.list[((255 & all_1.ipl[commvl_1.ivx + ip * 7 - 8]) << 2) - 
		2] % 2 == 0) {

/*  Start of 32nd gap, lump with following note */

	    ++ip;
	    nodue[nreal - 1] = all_1.nodur[commvl_1.ivx + ip * 7 - 8] + 1;
	} else {

/*  End of 32nd gap, lump with preceeding note */

	    --nreal;
	    ++nodue[nreal - 1];
	}
    }
    goto L1;
L9:
    ir1 = 1;
    itseg = all_1.lenbar / *ibmrep;
    i__1 = *ibmrep;
    for (irep = 1; irep <= i__1; ++irep) {

/* Set bitmaps for all shorts neighbored by a short. Each bit represen
ts a*/
/* span of 32nd note.  maps, mapm, mape record start, full duration, a
nd end*/
/*  of consecutive span of beamable (<1/4) notes. */

	maps = 0;
	mapm = 0;
	mape = 0;
	itend = itseg * irep;
	itoff = itend - itseg;
	i__2 = nreal;
	for (ir = ir1; ir <= i__2; ++ir) {
	    it2 = itr[ir - 1] + nodue[ir - 1] - 2;
	    if (it2 >= itend) {
		ir1 = ir;
		goto L14;
	    }
/*         if (short(ir).and.((ir.gt.1.and.short(ir-1)).or.(ir.lt.
nreal */
/* Computing MAX */
	    i__3 = ir - 1;
	    if (short__[ir - 1] && (ir > 1 && short__[max(i__3,1) - 1] || ir <
		     nreal && short__[ir])) {
		ib1 = (itr[ir - 1] - itoff) / 2;
		ib2 = (it2 - itoff) / 2;
		if (max(ib1,ib2) > 47 || ir > 48 || min(ib1,ib2) < 0) {
		    return 0;
		}

/*  Must have an odd number obe beats in a long bar.  Auto-bea
m won't work */

		nip1[ib1] = ipr[ir - 1];
		nip2[ib2] = ipr[ir - 1];

/*  nip1,2(ib) = 0 unless a real note starts,ends on bit ib; t
hen = ip */

		maps = bit_set(maps,ib1);
		mape = bit_set(mape,ib2);
		i__3 = ib2;
		for (ib = ib1; ib <= i__3; ++ib) {
		    mapm = bit_set(mapm,ib);
/* L3: */
		}
	    }
/* L2: */
	}
L14:
	if (mapm == 0) {
	    goto L13;
	}

/*  Zero out bits from forced beams */

	maps &= ~ mapfb[irep];
	mapm &= ~ mapfb[irep];
	mape &= ~ mapfb[irep];

/*  Compare map with template. */

	i__2 = nummask[combeam_1.ibmtyp - 1];
	for (it = 1; it <= i__2; ++it) {
	    masknow = mask[it + combeam_1.ibmtyp * 49 - 50];
	    if ((masknow & mapm) == masknow) {

/*  Find least significant bit in the mask to check start time
 */

		mtemp = masknow;
		maskm = masknow;
		for (is1 = 0; is1 <= 47; ++is1) {
		    if ((1 & mtemp) == 1) {
			goto L6;
		    }
		    mtemp = lbit_shift(mtemp, -1L);
/* L5: */
		}
L6:
		if ((lbit_shift(1L, is1) & maps) == 0) {
		    goto L4;
		}

/*  is1 is the bit where the beam starts.  Continue shifting t
o */
/*  find most significant bit in the mask to check ending time
 */

		for (is2 = is1; is2 <= 47; ++is2) {
		    mtemp = lbit_shift(mtemp, -1L);
		    if ((1 & ~ mtemp) == 1) {
			goto L8;
		    }
/* L7: */
		}
L8:

/*  is2 is now the bit on which the beam ends. */

		if ((lbit_shift(1L, is2) & mape) == 0) {
		    goto L4;
		}

/*  Did we pick out a single note from the middle of a longer 
sequence? */

		if (nip1[is1] == nip2[is2]) {
		    goto L4;
		}

/*  We almost have a beam.  Check equality of notes if needed.
 */

		if (eqonly[it + combeam_1.ibmtyp * 49 - 50]) {
		    i__3 = nip2[is2];
		    for (ip = nip1[is1]; ip <= i__3; ++ip) {
			if (all_1.nodur[commvl_1.ivx + ip * 7 - 8] != 8) {

/*  There is a non-1/8th note in this beam. Exit i
f not 2 quarters */

			    if (is2 - is1 != 15) {
				goto L4;
			    }

/*  Beam is 2 quarters long.  Check if can split i
n half. */

			    ithalf = 0;
			    i__4 = nip2[is2];
			    for (iip = nip1[is1]; iip <= i__4; ++iip) {
				ithalf += all_1.nodur[commvl_1.ivx + iip * 7 
					- 8];
				if (ithalf > 16) {
				    goto L4;
				}
				if (ithalf == 16) {
				    goto L21;
				}
/* L20: */
			    }
			    s_wsle(&io___561);
			    do_lio(&c__9, &c__1, "Problem in findbeam, pleas\
e call Dr. Don", 40L);
			    e_wsle();
			    goto L4;
L21:

/* Otherwise, split in half by keeping only the fi
rst half.  Other half will*/
/*  be picked up later, assuming masks are listed 
longest first. */

			    is2 = is1 + 7;

/*  Reset maskm (since only used part of mask), us
ed later to zero out */
/*  bits that contain beams */

			    maskm = 0;
			    i__4 = is2;
			    for (is = is1; is <= i__4; ++is) {
				maskm = bit_set(maskm,is);
/* L15: */
			    }
			    goto L16;
			}
/* L10: */
		    }
		}
L16:

/*  This is a beam.  If last "effective" ends on odd 64th, add
 1 more */

		if ((all_1.list[((255 & all_1.ipl[commvl_1.ivx + nip2[is2] * 
			7 - 8]) << 2) - 2] + all_1.nodur[commvl_1.ivx + nip2[
			is2] * 7 - 8]) % 2 != 0) {
		    ++nip2[is2];
		}
		++numbms[commvl_1.ivx];
		numnew = numbms[commvl_1.ivx];
		logbeam_(&numnew, &nip1[is1], &nip2[is2]);

/*  Zero out the appropriate bits so these notes don't get use
d again */

		mapm &= ~ maskm;
		if (mapm == 0) {
		    goto L13;
		}
		maps &= ~ maskm;
		mape &= ~ maskm;
	    }
L4:
	    ;
	}
L13:
	;
    }
    return 0;
} /* findbeam_ */

/* Subroutine */ int logbeam_(numnew, nip1, nip2)
integer *numnew, *nip1, *nip2;
{
    /* System generated locals */
    integer i__1, i__2;
    real r__1;
    char ch__1[1];

    /* Builtin functions */
    double log();

    /* Local variables */
    static integer iiip;
    extern /* Character */ VOID ulfq_();
    extern integer igetbits_(), ncmid_();
    static integer multx, ib;
    static real elskbm;
    static integer nrests, numnow;
    static logical isxtup;
    static integer iip;
    static real sum;
    static integer iip1;
    extern integer log2_();

    all_1.ibm1[commvl_1.ivx + *numnew * 7 - 8] = *nip1;
    all_1.ibm2[commvl_1.ivx + *numnew * 7 - 8] = *nip2;
    numnow = *numnew;
    if (*numnew > 1) {

/*  If it starts before any others, must put it in order */

	for (ib = *numnew - 1; ib >= 1; --ib) {
	    if (all_1.ibm1[commvl_1.ivx + ib * 7 - 8] < *nip1) {
		goto L12;
	    }
	    all_1.ibm1[commvl_1.ivx + (ib + 1) * 7 - 8] = all_1.ibm1[
		    commvl_1.ivx + ib * 7 - 8];
	    all_1.ibm2[commvl_1.ivx + (ib + 1) * 7 - 8] = all_1.ibm2[
		    commvl_1.ivx + ib * 7 - 8];
	    *(unsigned char *)&all_1.ulq[commvl_1.ivx + (ib + 1) * 7 - 8] = *(
		    unsigned char *)&all_1.ulq[commvl_1.ivx + ib * 7 - 8];
	    all_1.ibm1[commvl_1.ivx + ib * 7 - 8] = *nip1;
	    all_1.ibm2[commvl_1.ivx + ib * 7 - 8] = *nip2;
	    numnow = ib;
/* L11: */
	}
L12:
	;
    }
    sum = (float)0.;
    elskbm = (float)0.;

/* Beam has non-xtup within */

    nrests = 0;
    isxtup = FALSE_;
    i__1 = *nip2;
    for (iip = *nip1; iip <= i__1; ++iip) {
	if (bit_test(all_1.islur[commvl_1.ivx + *nip1 * 7 - 8],21)) {

/*  Forced multiplicity */

	    all_1.mult[commvl_1.ivx + iip * 7 - 8] = igetbits_(&all_1.islur[
		    commvl_1.ivx + *nip1 * 7 - 8], &c__3, &c__22);
	} else if (! isxtup) {
	    if (all_1.nodur[commvl_1.ivx + iip * 7 - 8] > 0) {
		all_1.mult[commvl_1.ivx + iip * 7 - 8] = 4 - log2_(&
			all_1.nodur[commvl_1.ivx + iip * 7 - 8]);
	    } else {

/*  Start xtup within forced beam */

		isxtup = TRUE_;
		iip1 = iip;
	    }
	} else if (isxtup && all_1.nodur[commvl_1.ivx + iip * 7 - 8] > 0) {

/*  End of xtup within forced beam */

	    multx = (integer) ((log(iip + (float)1. - iip1) * (float).952 - 
		    log(all_1.nodur[commvl_1.ivx + iip * 7 - 8] / (float)2.)) 
		    / (float).69315 + (float)13.429) - 10;
	    i__2 = iip;
	    for (iiip = iip1; iiip <= i__2; ++iiip) {
		all_1.mult[commvl_1.ivx + iiip * 7 - 8] = multx;
/* L74: */
	    }
	    isxtup = FALSE_;
	}
	if (bit_test(all_1.irest[commvl_1.ivx + iip * 7 - 8],0)) {
	    ++nrests;
	} else {
	    sum += all_1.nolev[commvl_1.ivx + iip * 7 - 8];
	}
/* L9: */
    }

/*  Set beam up-down-ness */

    if (comfb_1.ifb > 0 && *(unsigned char *)&comfb_1.ulfbq[commvl_1.ivx + 
	    max(1,comfb_1.ifb) * 7 - 8] != 'x') {
	*(unsigned char *)&all_1.ulq[commvl_1.ivx + comfb_1.ifb * 7 - 8] = *(
		unsigned char *)&comfb_1.ulfbq[commvl_1.ivx + comfb_1.ifb * 7 
		- 8];

/*  This probably works only because forced beams are done first, so t
hey */
/*  don't have to be re-sorted within each voice. ???? */

    } else if (commvl_1.nvmx[all_1.iv - 1] == 2) {

/*  Multi-voice per staff */

	if (commvl_1.ivx <= all_1.nv) {
	    *(unsigned char *)&all_1.ulq[commvl_1.ivx + numnow * 7 - 8] = 'l';
	} else {
	    *(unsigned char *)&all_1.ulq[commvl_1.ivx + numnow * 7 - 8] = 'u';
	}
    } else {

/*  Defaults */

	r__1 = sum / (*nip2 - *nip1 + 1 - nrests);
	i__1 = ncmid_(&all_1.iv, nip1);
	ulfq_(ch__1, 1L, &r__1, &i__1);
	*(unsigned char *)&all_1.ulq[commvl_1.ivx + numnow * 7 - 8] = *(
		unsigned char *)&ch__1[0];
/*    *      ulfq(sum/(nip2-nip1+1),ncmid(iv,nip1)) */
    }
    return 0;
} /* logbeam_ */

/* Character */ VOID ulfq_(ret_val, ret_val_len, xnolev, ncm)
char *ret_val;
ftnlen ret_val_len;
real *xnolev;
integer *ncm;
{
    static real test;


/*  Stem directions */

    test = *xnolev - *ncm;
    if (test < (float)-.001 || test < (float).001 && combc_1.bcspec && *ncm ==
	     23) {
	*(unsigned char *)ret_val = 'u';
    } else {
	*(unsigned char *)ret_val = 'l';
    }
    return ;
} /* ulfq_ */

/* Character */ VOID udfq_(ret_val, ret_val_len, nolev, ncm)
char *ret_val;
ftnlen ret_val_len;
integer *nolev, *ncm;
{
    static integer ntest;


/*  Slur directions */

    ntest = *nolev - *ncm;
    if (ntest < 0 || ntest == 0 && combc_1.bcspec && *ncm == 23) {
	*(unsigned char *)ret_val = 'd';
    } else {
	*(unsigned char *)ret_val = 'u';
    }
    return ;
} /* udfq_ */

/* Subroutine */ int topfile_(basenameq, lbase, nv, clefq, noinst, musicsize, 
	xinstf1, mtrnmp, mtrdnp, vshrink, fbar, basenameq_len, clefq_len)
char *basenameq;
integer *lbase, *nv;
char *clefq;
integer *noinst, *musicsize;
real *xinstf1;
integer *mtrnmp, *mtrdnp;
logical *vshrink;
real *fbar;
ftnlen basenameq_len;
ftnlen clefq_len;
{
    /* System generated locals */
    address a__1[3], a__2[2], a__3[4], a__4[6], a__5[10], a__6[8];
    integer i__1[3], i__2[2], i__3[4], i__4, i__5[6], i__6, i__7[10], i__8[8];
    char ch__1[30], ch__2[15], ch__3[10], ch__4[17], ch__5[16], ch__6[14], 
	    ch__7[21], ch__8[7], ch__9[19], ch__10[12], ch__11[1], ch__12[1], 
	    ch__13[33], ch__14[8], ch__15[81], ch__16[18], ch__17[11], ch__18[
	    57], ch__19[44], ch__20[62], ch__21[34], ch__22[47];

    /* Builtin functions */
    integer s_wsfe(), do_fio(), e_wsfe();
    /* Subroutine */ int s_cat();
    integer s_wsfi(), e_wsfi();
    /* Subroutine */ int s_copy();

    /* Local variables */
    static char fmtq[24];
    static integer k;
    static char fbarq[5];
    static integer lname, lfmtq, iinst, iv;
    static char sq[1];
    static integer ipi;
    extern integer numclef_();
    extern /* Subroutine */ int wgmeter_();
    static integer nstaves;

    /* Fortran I/O blocks */
    static cilist io___577 = { 0, 11, 0, "(a)", 0 };
    static cilist io___578 = { 0, 11, 0, "(a)", 0 };
    static cilist io___579 = { 0, 11, 0, "(a)", 0 };
    static cilist io___580 = { 0, 11, 0, "(a)", 0 };
    static cilist io___581 = { 0, 11, 0, "(a)", 0 };
    static cilist io___582 = { 0, 11, 0, "(a)", 0 };
    static cilist io___583 = { 0, 11, 0, "(a)", 0 };
    static cilist io___584 = { 0, 11, 0, "(a)", 0 };
    static cilist io___585 = { 0, 11, 0, "(a)", 0 };
    static cilist io___586 = { 0, 11, 0, "(a)", 0 };
    static icilist io___588 = { 0, fbarq, 0, "(f5.3)", 5, 1 };
    static cilist io___589 = { 0, 11, 0, "(a)", 0 };
    static cilist io___590 = { 0, 11, 0, "(a)", 0 };
    static cilist io___591 = { 0, 11, 0, "(a7,i3,a2)", 0 };
    static cilist io___592 = { 0, 11, 0, "(a7,i3,a2)", 0 };
    static cilist io___593 = { 0, 11, 0, "(a)", 0 };
    static cilist io___594 = { 0, 11, 0, "(a19,i1,a1)", 0 };
    static cilist io___598 = { 0, 11, 0, "(a)", 0 };
    static cilist io___602 = { 0, 11, 0, "(a)", 0 };
    static cilist io___604 = { 0, 11, 0, "(a8,i1,a)", 0 };
    static cilist io___605 = { 0, 11, 0, "(a18,i2,a2)", 0 };
    static cilist io___607 = { 0, 11, 0, "(a11,i1,a2)", 0 };
    static cilist io___608 = { 0, 11, 0, "(a11,i2,a2)", 0 };
    static cilist io___609 = { 0, 11, 0, "(a)", 0 };
    static cilist io___610 = { 0, 11, 0, fmtq, 0 };
    static cilist io___611 = { 0, 11, 0, "(a)", 0 };
    static cilist io___612 = { 0, 11, 0, "(a)", 0 };
    static cilist io___613 = { 0, 11, 0, "(a)", 0 };
    static cilist io___614 = { 0, 11, 0, "(a)", 0 };


    /* Parameter adjustments */
    --clefq;

    /* Function Body */
    *(unsigned char *)sq = '\\';
    s_wsfe(&io___577);
    do_fio(&c__1, "%%%%%%%%%%%%%%%%%", 17L);
    e_wsfe();
    s_wsfe(&io___578);
    do_fio(&c__1, "%", 1L);
    e_wsfe();
    s_wsfe(&io___579);
/* Writing concatenation */
    i__1[0] = 2, a__1[0] = "% ";
    i__1[1] = *lbase, a__1[1] = basenameq;
    i__1[2] = 4, a__1[2] = ".tex";
    s_cat(ch__1, a__1, i__1, &c__3, 30L);
    do_fio(&c__1, ch__1, *lbase + 6);
    e_wsfe();
    s_wsfe(&io___580);
    do_fio(&c__1, "%", 1L);
    e_wsfe();
    s_wsfe(&io___581);
    do_fio(&c__1, "%%%%%%%%%%%%%%%%", 16L);
    e_wsfe();
    s_wsfe(&io___582);
/* Writing concatenation */
    i__2[0] = 1, a__2[0] = sq;
    i__2[1] = 14, a__2[1] = "input musixtex";
    s_cat(ch__2, a__2, i__2, &c__2, 15L);
    do_fio(&c__1, ch__2, 15L);
    e_wsfe();
    s_wsfe(&io___583);
/* Writing concatenation */
    i__2[0] = 1, a__2[0] = sq;
    i__2[1] = 9, a__2[1] = "input pmx";
    s_cat(ch__3, a__2, i__2, &c__2, 10L);
    do_fio(&c__1, ch__3, 10L);
    e_wsfe();
    s_wsfe(&io___584);
/* Writing concatenation */
    i__2[0] = 1, a__2[0] = sq;
    i__2[1] = 14, a__2[1] = "input musixmad";
    s_cat(ch__2, a__2, i__2, &c__2, 15L);
    do_fio(&c__1, ch__2, 15L);
    e_wsfe();

/* Need to input musixmad to permit more slurs. */

    if (*musicsize == 20) {
	s_wsfe(&io___585);
/* Writing concatenation */
	i__2[0] = 1, a__2[0] = sq;
	i__2[1] = 16, a__2[1] = "normalmusicsize%";
	s_cat(ch__4, a__2, i__2, &c__2, 17L);
	do_fio(&c__1, ch__4, 17L);
	e_wsfe();
    } else {
	s_wsfe(&io___586);
/* Writing concatenation */
	i__2[0] = 1, a__2[0] = sq;
	i__2[1] = 15, a__2[1] = "smallmusicsize%";
	s_cat(ch__5, a__2, i__2, &c__2, 16L);
	do_fio(&c__1, ch__5, 16L);
	e_wsfe();
    }
    s_wsfi(&io___588);
    do_fio(&c__1, (char *)&(*fbar), (ftnlen)sizeof(real));
    e_wsfi();
    s_wsfe(&io___589);
/* Writing concatenation */
    i__2[0] = 1, a__2[0] = sq;
    i__2[1] = 13, a__2[1] = "nopagenumbers";
    s_cat(ch__6, a__2, i__2, &c__2, 14L);
    do_fio(&c__1, ch__6, 14L);
    e_wsfe();
    s_wsfe(&io___590);
/* Writing concatenation */
    i__3[0] = 1, a__3[0] = sq;
    i__3[1] = 14, a__3[1] = "tracingstats=2";
    i__3[2] = 1, a__3[2] = sq;
    i__3[3] = 5, a__3[3] = "relax";
    s_cat(ch__7, a__3, i__3, &c__4, 21L);
    do_fio(&c__1, ch__7, 21L);
    e_wsfe();
    s_wsfe(&io___591);
/* Writing concatenation */
    i__2[0] = 1, a__2[0] = sq;
    i__2[1] = 6, a__2[1] = "hsize=";
    s_cat(ch__8, a__2, i__2, &c__2, 7L);
    do_fio(&c__1, ch__8, 7L);
    i__4 = (integer) (comtop_1.widthpt + (float).1);
    do_fio(&c__1, (char *)&i__4, (ftnlen)sizeof(integer));
    do_fio(&c__1, "pt", 2L);
    e_wsfe();
    s_wsfe(&io___592);
/* Writing concatenation */
    i__2[0] = 1, a__2[0] = sq;
    i__2[1] = 6, a__2[1] = "vsize=";
    s_cat(ch__8, a__2, i__2, &c__2, 7L);
    do_fio(&c__1, ch__8, 7L);
    i__4 = (integer) (comtop_1.height + (float).1);
    do_fio(&c__1, (char *)&i__4, (ftnlen)sizeof(integer));
    do_fio(&c__1, "pt", 2L);
    e_wsfe();

/* The default  raisebarno=3.5 internote, set in pmx.tex.  Increase to 4.5
 if*/
/*  3 sharps and treble clef, to avoid vertical clash with top space g# */

    if (comtop_1.isig == 3 && *(unsigned char *)&clefq[*nv] == 't') {
	s_wsfe(&io___593);
/* Writing concatenation */
	i__5[0] = 1, a__4[0] = sq;
	i__5[1] = 3, a__4[1] = "def";
	i__5[2] = 1, a__4[2] = sq;
	i__5[3] = 14, a__4[3] = "raisebarno{4.5";
	i__5[4] = 1, a__4[4] = sq;
	i__5[5] = 10, a__4[5] = "internote}";
	s_cat(ch__1, a__4, i__5, &c__6, 30L);
	do_fio(&c__1, ch__1, 30L);
	e_wsfe();
    }
    s_wsfe(&io___594);
/* Writing concatenation */
    i__3[0] = 1, a__3[0] = sq;
    i__3[1] = 3, a__3[1] = "def";
    i__3[2] = 1, a__3[2] = sq;
    i__3[3] = 14, a__3[3] = "nbinstruments{";
    s_cat(ch__9, a__3, i__3, &c__4, 19L);
    do_fio(&c__1, ch__9, 19L);
    i__4 = abs(*noinst);
    do_fio(&c__1, (char *)&i__4, (ftnlen)sizeof(integer));
    do_fio(&c__1, "}", 1L);
    e_wsfe();
    iv = 0;
    i__4 = abs(*noinst);
    for (iinst = 1; iinst <= i__4; ++iinst) {
	if (*noinst > 0) {

/*  The old way, only inst #1 can have >1 voice. */

	    if (*noinst == *nv || iinst > 1) {
		nstaves = 1;
	    } else {
		nstaves = *nv - *noinst + 1;
	    }
	} else {

/*  The new way */

	    nstaves = comnvi_1.nvi[iinst - 1];
	}
	s_wsfe(&io___598);
/* Writing concatenation */
	i__3[0] = 1, a__3[0] = sq;
	i__3[1] = 9, a__3[1] = "setstaffs";
	*(unsigned char *)&ch__11[0] = iinst + 48;
	i__3[2] = 1, a__3[2] = ch__11;
	*(unsigned char *)&ch__12[0] = nstaves + 48;
	i__3[3] = 1, a__3[3] = ch__12;
	s_cat(ch__10, a__3, i__3, &c__4, 12L);
	do_fio(&c__1, ch__10, 12L);
	e_wsfe();
	++iv;
	if (nstaves == 1) {
	    *(unsigned char *)&ch__11[0] = numclef_(clefq + iv, 1L) + 48;
	    s_copy(fmtq, ch__11, 24L, 1L);
	    lfmtq = 1;
	} else {
/* Writing concatenation */
	    i__2[0] = 1, a__2[0] = "{";
	    *(unsigned char *)&ch__11[0] = numclef_(clefq + iv, 1L) + 48;
	    i__2[1] = 1, a__2[1] = ch__11;
	    s_cat(fmtq, a__2, i__2, &c__2, 24L);
	    lfmtq = 2;
	    i__6 = nstaves;
	    for (k = 2; k <= i__6; ++k) {
		++iv;
/* Writing concatenation */
		i__2[0] = lfmtq, a__2[0] = fmtq;
		*(unsigned char *)&ch__11[0] = numclef_(clefq + iv, 1L) + 48;
		i__2[1] = 1, a__2[1] = ch__11;
		s_cat(fmtq, a__2, i__2, &c__2, 24L);
		++lfmtq;
/* L2: */
	    }
/* Writing concatenation */
	    i__2[0] = lfmtq, a__2[0] = fmtq;
	    i__2[1] = 1, a__2[1] = "}";
	    s_cat(fmtq, a__2, i__2, &c__2, 24L);
	    ++lfmtq;
	}
	s_wsfe(&io___602);
/* Writing concatenation */
	i__3[0] = 1, a__3[0] = sq;
	i__3[1] = 7, a__3[1] = "setclef";
	*(unsigned char *)&ch__11[0] = iinst + 48;
	i__3[2] = 1, a__3[2] = ch__11;
	i__3[3] = lfmtq, a__3[3] = fmtq;
	s_cat(ch__13, a__3, i__3, &c__4, 33L);
	do_fio(&c__1, ch__13, lfmtq + 9);
	e_wsfe();
	for (lname = 79; lname >= 2; --lname) {
	    if (*(unsigned char *)&comtop_1.inameq[(iinst - 1) * 79 + (lname 
		    - 1)] != ' ') {
		goto L4;
	    }
/* L3: */
	}
L4:
	s_wsfe(&io___604);
/* Writing concatenation */
	i__2[0] = 1, a__2[0] = sq;
	i__2[1] = 7, a__2[1] = "setname";
	s_cat(ch__14, a__2, i__2, &c__2, 8L);
	do_fio(&c__1, ch__14, 8L);
	do_fio(&c__1, (char *)&iinst, (ftnlen)sizeof(integer));
/* Writing concatenation */
	i__1[0] = 1, a__1[0] = "{";
	i__1[1] = lname, a__1[1] = comtop_1.inameq + (iinst - 1) * 79;
	i__1[2] = 1, a__1[2] = "}";
	s_cat(ch__15, a__1, i__1, &c__3, 81L);
	do_fio(&c__1, ch__15, lname + 2);
	e_wsfe();
/* L1: */
    }
    s_wsfe(&io___605);
/* Writing concatenation */
    i__2[0] = 1, a__2[0] = sq;
    i__2[1] = 17, a__2[1] = "generalsignature{";
    s_cat(ch__16, a__2, i__2, &c__2, 18L);
    do_fio(&c__1, ch__16, 18L);
    do_fio(&c__1, (char *)&comtop_1.isig, (ftnlen)sizeof(integer));
    do_fio(&c__1, "}%", 2L);
    e_wsfe();
    wgmeter_(mtrnmp, mtrdnp);
    ipi = comtop_1.fracindent * comtop_1.widthpt + (float).1;
    if (ipi < 10) {
	s_wsfe(&io___607);
/* Writing concatenation */
	i__2[0] = 1, a__2[0] = sq;
	i__2[1] = 10, a__2[1] = "parindent ";
	s_cat(ch__17, a__2, i__2, &c__2, 11L);
	do_fio(&c__1, ch__17, 11L);
	do_fio(&c__1, (char *)&ipi, (ftnlen)sizeof(integer));
	do_fio(&c__1, "pt", 2L);
	e_wsfe();
    } else {
	s_wsfe(&io___608);
/* Writing concatenation */
	i__2[0] = 1, a__2[0] = sq;
	i__2[1] = 10, a__2[1] = "parindent ";
	s_cat(ch__17, a__2, i__2, &c__2, 11L);
	do_fio(&c__1, ch__17, 11L);
	do_fio(&c__1, (char *)&ipi, (ftnlen)sizeof(integer));
	do_fio(&c__1, "pt", 2L);
	e_wsfe();
    }
    s_wsfe(&io___609);
/* Writing concatenation */
    i__7[0] = 1, a__5[0] = sq;
    i__7[1] = 11, a__5[1] = "elemskip1pt";
    i__7[2] = 1, a__5[2] = sq;
    i__7[3] = 13, a__5[3] = "afterruleskip";
    i__7[4] = 5, a__5[4] = fbarq;
    i__7[5] = 2, a__5[5] = "pt";
    i__7[6] = 1, a__5[6] = sq;
    i__7[7] = 17, a__5[7] = "beforeruleskip0pt";
    i__7[8] = 1, a__5[8] = sq;
    i__7[9] = 5, a__5[9] = "relax";
    s_cat(ch__18, a__5, i__7, &c__10, 57L);
    do_fio(&c__1, ch__18, 57L);
    e_wsfe();
    *vshrink = *xinstf1 > (float)20.;
    if (! (*vshrink)) {
	if (*xinstf1 < (float)9.95) {
	    s_copy(fmtq, "(a,f3.1,a)", 24L, 10L);
	} else {
	    s_copy(fmtq, "(a,f4.1,a)", 24L, 10L);
	}
	s_wsfe(&io___610);
/* Writing concatenation */
	i__5[0] = 1, a__4[0] = sq;
	i__5[1] = 15, a__4[1] = "stafftopmarg0pt";
	i__5[2] = 1, a__4[2] = sq;
	i__5[3] = 15, a__4[3] = "staffbotmarg0pt";
	i__5[4] = 1, a__4[4] = sq;
	i__5[5] = 11, a__4[5] = "interstaff{";
	s_cat(ch__19, a__4, i__5, &c__6, 44L);
	do_fio(&c__1, ch__19, 44L);
	do_fio(&c__1, (char *)&(*xinstf1), (ftnlen)sizeof(real));
/* Writing concatenation */
	i__1[0] = 1, a__1[0] = "}";
	i__1[1] = 1, a__1[1] = sq;
	i__1[2] = 5, a__1[2] = "relax";
	s_cat(ch__8, a__1, i__1, &c__3, 7L);
	do_fio(&c__1, ch__8, 7L);
	e_wsfe();
	comarp_1.xinsnow = *xinstf1;
    } else {
	s_wsfe(&io___611);
/* Writing concatenation */
	i__7[0] = 1, a__5[0] = sq;
	i__7[1] = 15, a__5[1] = "stafftopmarg0pt";
	i__7[2] = 1, a__5[2] = sq;
	i__7[3] = 13, a__5[3] = "staffbotmarg5";
	i__7[4] = 1, a__5[4] = sq;
	i__7[5] = 10, a__5[5] = "Interligne";
	i__7[6] = 1, a__5[6] = sq;
	i__7[7] = 14, a__5[7] = "interstaff{10}";
	i__7[8] = 1, a__5[8] = sq;
	i__7[9] = 5, a__5[9] = "relax";
	s_cat(ch__20, a__5, i__7, &c__10, 62L);
	do_fio(&c__1, ch__20, 62L);
	e_wsfe();
	comarp_1.xinsnow = (float)10.;
    }
    if (*nv == 1) {
	s_wsfe(&io___612);
/* Writing concatenation */
	i__2[0] = 1, a__2[0] = sq;
	i__2[1] = 11, a__2[1] = "nostartrule";
	s_cat(ch__10, a__2, i__2, &c__2, 12L);
	do_fio(&c__1, ch__10, 12L);
	e_wsfe();
    }
    s_wsfe(&io___613);
/* Writing concatenation */
    i__3[0] = 1, a__3[0] = sq;
    i__3[1] = 8, a__3[1] = "readmod{";
    i__3[2] = *lbase, a__3[2] = basenameq;
    i__3[3] = 1, a__3[3] = "}";
    s_cat(ch__21, a__3, i__3, &c__4, 34L);
    do_fio(&c__1, ch__21, *lbase + 10);
    e_wsfe();
    s_wsfe(&io___614);
/* Writing concatenation */
    i__8[0] = 1, a__6[0] = sq;
    i__8[1] = 11, a__6[1] = "startmuflex";
    i__8[2] = 1, a__6[2] = sq;
    i__8[3] = 10, a__6[3] = "startpiece";
    i__8[4] = 1, a__6[4] = sq;
    i__8[5] = 8, a__6[5] = "addspace";
    i__8[6] = 1, a__6[6] = sq;
    i__8[7] = 14, a__6[7] = "afterruleskip%";
    s_cat(ch__22, a__6, i__8, &c__8, 47L);
    do_fio(&c__1, ch__22, 47L);
    e_wsfe();
    return 0;
} /* topfile_ */

integer numclef_(clefq, clefq_len)
char *clefq;
ftnlen clefq_len;
{
    /* System generated locals */
    integer ret_val;

    /* Builtin functions */
    integer i_indx();

    if (*(unsigned char *)clefq < 55) {
	ret_val = *(unsigned char *)clefq - 48;
    } else {
	ret_val = i_indx("tsmanrb", clefq, 7L, 1L) - 1;
    }
    return ret_val;
} /* numclef_ */

integer ni_(x)
real *x;
{
    /* System generated locals */
    integer ret_val;

    if (*x >= (float)0.) {
	ret_val = *x + (float).5001;
    } else {
	ret_val = *x - (float).5001;
    }
    return ret_val;
} /* ni_ */

integer nindxf_(nspace)
integer *nspace;
{
    /* System generated locals */
    integer ret_val;

    /* Builtin functions */
    double log();

    ret_val = log(*nspace * (float)1.) * 2 / (float).69315 + (float)1.3;
    return ret_val;
} /* nindxf_ */

doublereal feon_(time)
real *time;
{
    /* System generated locals */
    real ret_val;
    doublereal d__1, d__2;

    /* Builtin functions */
    double sqrt(), pow_dd();

/*       feon = max(1.8,1.+alog(time/2)/.69315) */
/*       feon = sqrt(time/2) */
    d__1 = (doublereal) sqrt(*time / 2);
    d__2 = (doublereal) ((float)1. - comeon_1.eonk);
    ret_val = pow_dd(&d__1, &d__2) * comeon_1.ewmxk;
    return ret_val;
} /* feon_ */

/* Subroutine */ int setmeter_(mtrnuml, mtrdenl, ibmtyp, ibmrep)
integer *mtrnuml, *mtrdenl, *ibmtyp, *ibmrep;
{

/*  Sets last 2 args depending on 1st 2, (logical) num, denom. */
/*  ibmtyp = 1, 2, or 3 defines set of masks for beam groupings. */
/*  1: all duple meters */
/*  2: triple w/ denom=4, subdivide in groups of 2 8ths */
/*  3: triple w/ denom=8, subdivide in groups of 3 8ths */
/*  Note that lenbar is set at top or when 'm' symbol is read in getnote 
*/

    if (*mtrdenl == 4) {
	if (*mtrnuml % 3 == 0) {
	    *ibmtyp = 2;
	    *ibmrep = *mtrnuml / 3;
	} else {
	    *ibmtyp = 1;
	    *ibmrep = *mtrnuml / 2;
	}
    } else if (*mtrdenl == 2) {
	*ibmtyp = 1;
	if (*mtrnuml == 3) {
	    *ibmrep = 3;
	} else {
	    *ibmrep = (*mtrnuml << 1) / *mtrdenl;
	}
    } else {

/*  Assumes mtrdenl=8 and 3/8, 6/8, 9/8, or 12/8 */

	*ibmtyp = 3;
	*ibmrep = *mtrnuml / 3;
    }

/*  Reset so we don't keep writing new meters */

    *mtrnuml = 0;

/* Prevent ibmrep=0.  Needed for odd bars, e.g. 1/8, where beams don't mat
ter*/

    *ibmrep = max(*ibmrep,1);
    return 0;
} /* setmeter_ */

/* Subroutine */ int wgmeter_(mtrnmp, mtrdnp)
integer *mtrnmp, *mtrdnp;
{
    /* System generated locals */
    address a__1[4];
    integer i__1[4], i__2;
    char ch__1[25], ch__2[26], ch__3[21], ch__4[24];

    /* Builtin functions */
    integer s_wsfe();
    /* Subroutine */ int s_cat();
    integer do_fio(), e_wsfe();

    /* Local variables */
    static char sq[1];

    /* Fortran I/O blocks */
    static cilist io___616 = { 0, 11, 0, "(a25,i1,a2,i1,a3)", 0 };
    static cilist io___617 = { 0, 11, 0, "(a25,i1,a2,i2,a3)", 0 };
    static cilist io___618 = { 0, 11, 0, "(a25,i2,a2,i1,a3)", 0 };
    static cilist io___619 = { 0, 11, 0, "(a25,i2,a2,i2,a3)", 0 };
    static cilist io___620 = { 0, 11, 0, "(a26,i1,a2,i1,a3)", 0 };
    static cilist io___621 = { 0, 11, 0, "(a21,i1,a2)", 0 };
    static cilist io___622 = { 0, 11, 0, "(a)", 0 };
    static cilist io___623 = { 0, 11, 0, "(a)", 0 };
    static cilist io___624 = { 0, 11, 0, "(a)", 0 };


    if (*mtrdnp == 0) {
	return 0;
    }
    *(unsigned char *)sq = '\\';
    if (*mtrnmp > 0 && *mtrnmp <= 9) {
	if (*mtrdnp < 10) {
	    s_wsfe(&io___616);
/* Writing concatenation */
	    i__1[0] = 1, a__1[0] = sq;
	    i__1[1] = 13, a__1[1] = "generalmeter{";
	    i__1[2] = 1, a__1[2] = sq;
	    i__1[3] = 10, a__1[3] = "meterfrac{";
	    s_cat(ch__1, a__1, i__1, &c__4, 25L);
	    do_fio(&c__1, ch__1, 25L);
	    do_fio(&c__1, (char *)&(*mtrnmp), (ftnlen)sizeof(integer));
	    do_fio(&c__1, "}{", 2L);
	    do_fio(&c__1, (char *)&(*mtrdnp), (ftnlen)sizeof(integer));
	    do_fio(&c__1, "}}%", 3L);
	    e_wsfe();
	} else {
	    s_wsfe(&io___617);
/* Writing concatenation */
	    i__1[0] = 1, a__1[0] = sq;
	    i__1[1] = 13, a__1[1] = "generalmeter{";
	    i__1[2] = 1, a__1[2] = sq;
	    i__1[3] = 10, a__1[3] = "meterfrac{";
	    s_cat(ch__1, a__1, i__1, &c__4, 25L);
	    do_fio(&c__1, ch__1, 25L);
	    do_fio(&c__1, (char *)&(*mtrnmp), (ftnlen)sizeof(integer));
	    do_fio(&c__1, "}{", 2L);
	    do_fio(&c__1, (char *)&(*mtrdnp), (ftnlen)sizeof(integer));
	    do_fio(&c__1, "}}%", 3L);
	    e_wsfe();
	}
    } else if (*mtrnmp >= 10) {
	if (*mtrdnp < 10) {
	    s_wsfe(&io___618);
/* Writing concatenation */
	    i__1[0] = 1, a__1[0] = sq;
	    i__1[1] = 13, a__1[1] = "generalmeter{";
	    i__1[2] = 1, a__1[2] = sq;
	    i__1[3] = 10, a__1[3] = "meterfrac{";
	    s_cat(ch__1, a__1, i__1, &c__4, 25L);
	    do_fio(&c__1, ch__1, 25L);
	    do_fio(&c__1, (char *)&(*mtrnmp), (ftnlen)sizeof(integer));
	    do_fio(&c__1, "}{", 2L);
	    do_fio(&c__1, (char *)&(*mtrdnp), (ftnlen)sizeof(integer));
	    do_fio(&c__1, "}}%", 3L);
	    e_wsfe();
	} else {
	    s_wsfe(&io___619);
/* Writing concatenation */
	    i__1[0] = 1, a__1[0] = sq;
	    i__1[1] = 13, a__1[1] = "generalmeter{";
	    i__1[2] = 1, a__1[2] = sq;
	    i__1[3] = 10, a__1[3] = "meterfrac{";
	    s_cat(ch__1, a__1, i__1, &c__4, 25L);
	    do_fio(&c__1, ch__1, 25L);
	    do_fio(&c__1, (char *)&(*mtrnmp), (ftnlen)sizeof(integer));
	    do_fio(&c__1, "}{", 2L);
	    do_fio(&c__1, (char *)&(*mtrdnp), (ftnlen)sizeof(integer));
	    do_fio(&c__1, "}}%", 3L);
	    e_wsfe();
	}
    } else if (*mtrnmp < 0) {
	s_wsfe(&io___620);
/* Writing concatenation */
	i__1[0] = 1, a__1[0] = sq;
	i__1[1] = 13, a__1[1] = "generalmeter{";
	i__1[2] = 1, a__1[2] = sq;
	i__1[3] = 11, a__1[3] = "meterfracS{";
	s_cat(ch__2, a__1, i__1, &c__4, 26L);
	do_fio(&c__1, ch__2, 26L);
	i__2 = -(*mtrnmp);
	do_fio(&c__1, (char *)&i__2, (ftnlen)sizeof(integer));
	do_fio(&c__1, "}{", 2L);
	do_fio(&c__1, (char *)&(*mtrdnp), (ftnlen)sizeof(integer));
	do_fio(&c__1, "}}%", 3L);
	e_wsfe();
    } else if (*mtrdnp <= 4) {
	s_wsfe(&io___621);
/* Writing concatenation */
	i__1[0] = 1, a__1[0] = sq;
	i__1[1] = 13, a__1[1] = "generalmeter{";
	i__1[2] = 1, a__1[2] = sq;
	i__1[3] = 6, a__1[3] = "meterN";
	s_cat(ch__3, a__1, i__1, &c__4, 21L);
	do_fio(&c__1, ch__3, 21L);
	do_fio(&c__1, (char *)&(*mtrdnp), (ftnlen)sizeof(integer));
	do_fio(&c__1, "}%", 2L);
	e_wsfe();
    } else if (*mtrdnp == 5) {
	s_wsfe(&io___622);
/* Writing concatenation */
	i__1[0] = 1, a__1[0] = sq;
	i__1[1] = 12, a__1[1] = "generalmeter";
	i__1[2] = 1, a__1[2] = sq;
	i__1[3] = 10, a__1[3] = "allabreve%";
	s_cat(ch__4, a__1, i__1, &c__4, 24L);
	do_fio(&c__1, ch__4, 24L);
	e_wsfe();
    } else if (*mtrdnp == 6) {
	s_wsfe(&io___623);
/* Writing concatenation */
	i__1[0] = 1, a__1[0] = sq;
	i__1[1] = 12, a__1[1] = "generalmeter";
	i__1[2] = 1, a__1[2] = sq;
	i__1[3] = 7, a__1[3] = "meterC%";
	s_cat(ch__3, a__1, i__1, &c__4, 21L);
	do_fio(&c__1, ch__3, 21L);
	e_wsfe();
    } else if (*mtrdnp == 7) {
	s_wsfe(&io___624);
/* Writing concatenation */
	i__1[0] = 1, a__1[0] = sq;
	i__1[1] = 12, a__1[1] = "generalmeter";
	i__1[2] = 1, a__1[2] = sq;
	i__1[3] = 10, a__1[3] = "meterIIIS%";
	s_cat(ch__4, a__1, i__1, &c__4, 24L);
	do_fio(&c__1, ch__4, 24L);
	e_wsfe();
    }
    return 0;
} /* wgmeter_ */

integer lc_(stringq, leng, stringq_len)
char *stringq;
integer *leng;
ftnlen stringq_len;
{
    /* System generated locals */
    integer ret_val;

    /* Local variables */
    static integer kc;

    for (kc = *leng; kc >= 1; --kc) {
	if (*(unsigned char *)&stringq[kc - 1] != ' ') {
	    ret_val = kc;
	    return ret_val;
	}
/* L1: */
    }
    ret_val = 0;
    return ret_val;
} /* lc_ */

/* Character */ VOID upcaseq_(ret_val, ret_val_len, chq, chq_len)
char *ret_val;
ftnlen ret_val_len;
char *chq;
ftnlen chq_len;
{
    /* System generated locals */
    address a__1[2];
    integer i__1[2];
    char ch__2[53];

    /* Builtin functions */
    integer s_wsle();
    /* Subroutine */ int s_cat();
    integer do_lio(), e_wsle();
    /* Subroutine */ int s_stop();

    /* Fortran I/O blocks */
    static cilist io___626 = { 0, 6, 0, 0, 0 };


    if (*(unsigned char *)chq >= 61 && *(unsigned char *)chq < 122) {
	*(unsigned char *)ret_val = (char) (*(unsigned char *)chq - 32);
    } else {
	*(unsigned char *)ret_val = *(unsigned char *)chq;
	s_wsle(&io___626);
/* Writing concatenation */
	i__1[0] = 52, a__1[0] = "Warning, upcaseq was called with improper a\
rgument: ";
	i__1[1] = 1, a__1[1] = chq;
	s_cat(ch__2, a__1, i__1, &c__2, 53L);
	do_lio(&c__9, &c__1, ch__2, 53L);
	e_wsle();
	s_stop("", 0L);
    }
    return ;
} /* upcaseq_ */

/* Subroutine */ int addblank_(noteq, lnoten, noteq_len)
char *noteq;
integer *lnoten;
ftnlen noteq_len;
{
    /* System generated locals */
    address a__1[2];
    integer i__1[2];

    /* Builtin functions */
    /* Subroutine */ int s_copy(), s_cat();

    /* Local variables */
    static char tchar[1];

    s_copy(tchar, noteq, 1L, 8L);
/* Writing concatenation */
    i__1[0] = 1, a__1[0] = " ";
    i__1[1] = 1, a__1[1] = tchar;
    s_cat(noteq, a__1, i__1, &c__2, 8L);
    *lnoten = 2;
    return 0;
} /* addblank_ */

/* Subroutine */ int doslur_(nolev, isdat1, isdat2, nsdat, ip, iv, nv, beamon,
	 ncm, soutq, lsout, ulq, islur, ipl, iornq, islhgt, soutq_len, 
	ulq_len)
integer *nolev, *isdat1, *isdat2, *nsdat, *ip, *iv, *nv;
logical *beamon;
integer *ncm;
char *soutq;
integer *lsout;
char *ulq;
integer *islur, *ipl, *iornq, *islhgt;
ftnlen soutq_len;
ftnlen ulq_len;
{
    /* System generated locals */
    address a__1[2], a__2[3];
    integer i__1, i__2, i__3[2], i__4[3];
    char ch__1[1], ch__2[6];
    icilist ici__1;

    /* Builtin functions */
    integer s_wsle(), do_lio(), e_wsle();
    /* Subroutine */ int s_stop(), s_cat();
    integer s_wsfi(), do_fio(), e_wsfi();
    /* Subroutine */ int s_copy();

    /* Local variables */
    extern /* Character */ VOID udfq_(), udqq_();
    static integer ivoffinc;
    extern integer igetbits_(), lfmt1_();
    static integer j, ihoff;
    static logical iscrd;
    static integer isdat, ivoff;
    static real shift;
    static integer iupdn, lform, lnote;
    static char noteq[8];
    static logical tmove;
    static integer idcode, isdata;
    extern /* Subroutine */ int addstr_();
    static integer isdats, isdatt;
    extern /* Subroutine */ int notefq_();
    static logical sfound, tfound;
    static integer lnoten, nolevs, nolevt;
    static logical stemup;
    static char notexq[79];
    extern /* Subroutine */ int setbits_();
    extern integer log2_();
    static integer numdrop;
    static char slurudq[1];

    /* Fortran I/O blocks */
    static cilist io___645 = { 0, 6, 0, 0, 0 };
    static cilist io___653 = { 0, 6, 0, 0, 0 };



/*  Called once per main note. */


/*  Bits in isdat1: */
/*  0-2      ivx */
/*  3-10     ip */
/*  11       start/stop switch */
/*  19-25    ichar(code$) */
/*  26       force direction? */
/*  27       forced dir'n = up if on, set in sslur; also */
/*          final direction, set in doslur when beam is started, used on t
erm.*/
/*  28-31    ndxslur, set in doslur when beam is started, used on term. */

/*  Bits in isdat2 */
/*  0        Chord switch.  Not set on main note. */
/*  1-2      left/right notehead shift.  Set only for chord note. */
/*  3        tie positioning */
/*  6-11     voff1 1-63  =>  -31...+31 */
/*  12-18    hoff1 1-127 => -6.3...+6.3 */
/*  19-25    nolev */

/*  In listslur bit ib is on if slur index ib is in use, ib=0-8. */
/*  ndxslur = slur index */
/* Height of slur is nole+ivoff+iupdn.  iupdn is +/-1 if t&s slurs on same
 note,*/
/*  s-slur is blank (idcode=32), t-slur is idcode=1. */
/* ivoff is user-defined shift or shift due to . or _ , or chord adjustmen
t.*/
/*  Ivoff will be set for ./_ only if no user-defined shift is specified. 
*/
/*  If highest note has upslur, save slur height in islhgt in case */
/*  ornament must be moved. */

    /* Parameter adjustments */
    --isdat2;
    --isdat1;

    /* Function Body */
    *islhgt = 0;
    if (*beamon) {
	stemup = *(unsigned char *)ulq == 'u';
    } else if (commvl_1.nvmx[*iv - 1] == 2) {
	stemup = commvl_1.ivx > *nv;
    } else {
	udqq_(ch__1, 1L, nolev, ncm, islur, &commvl_1.nvmx[*iv - 1], &
		commvl_1.ivx, nv);
	stemup = *(unsigned char *)&ch__1[0] == 'u';
    }
    iscrd = bit_test(*ipl,10);
    if (bit_test(*islur,1)) {

/* 't'-slur (idcode=1) somewhere on this note.  Find it, check height 
against*/
/*    's'-slur (idcode=32) */

	sfound = FALSE_;
	tfound = FALSE_;
	tmove = FALSE_;
	i__1 = *nsdat;
	for (isdat = 1; isdat <= i__1; ++isdat) {
	    if (commvl_1.ivx == (7 & isdat1[isdat]) && *ip == igetbits_(&
		    isdat1[isdat], &c__8, &c__3)) {
		if (! tfound) {
		    tfound = igetbits_(&isdat1[isdat], &c__7, &c__19) == 1;
		    if (tfound) {
			nolevt = igetbits_(&isdat2[isdat], &c__7, &c__19);
			isdatt = isdat;
			if (sfound) {
			    goto L6;
			}
		    }
		}
		if (! sfound) {
		    sfound = igetbits_(&isdat1[isdat], &c__7, &c__19) == 32;
		    if (sfound) {
			nolevs = igetbits_(&isdat2[isdat], &c__7, &c__19);
			isdats = isdat;
			if (tfound) {
			    goto L6;
			}
		    }
		}
	    }
/* L5: */
	}

/* Will come thru here if there is a t with no s, so comment out the f
ollowing*/
/*        print*,'Did not find s+t-slurs in doslur' */

L6:
	if (sfound && tfound) {
	    tmove = nolevs == nolevt && (bit_test(isdat1[isdats],11) && 
		    bit_test(isdat1[isdatt],11) || ! bit_test(isdat1[isdats],
		    11) && ! bit_test(isdat1[isdatt],11));
	}

/*  Check if 2 starts or two stops */


/* This is a flag for later changing slur level, after we know slur di
r'n.*/

    }
    i__1 = *nsdat;
    for (isdat = 1; isdat <= i__1; ++isdat) {
	isdata = isdat1[isdat];
/*     call report(nsdat,isdat1,isdat2) */
	if (commvl_1.ivx == (7 & isdata) && *ip == igetbits_(&isdata, &c__8, &
		c__3)) {
	    idcode = igetbits_(&isdata, &c__7, &c__19);
	    ivoff = igetbits_(&isdat2[isdat], &c__6, &c__6) - 32;
	    ihoff = igetbits_(&isdat2[isdat], &c__7, &c__12) - 64;
	    iupdn = 0;
	    *(unsigned char *)slurudq = 'd';
	    nolevs = igetbits_(&isdat2[isdat], &c__7, &c__19);
	    if (bit_test(isdata,11)) {

/*  Turnon, so get slur direction */

		if (bit_test(isdata,26)) {

/*  Force slur direction */

		    if (bit_test(isdata,27)) {
			*(unsigned char *)slurudq = 'u';
		    }
		} else if (commvl_1.nvmx[*iv - 1] == 1) {

/*  Only one voice per line */

		    if (! (*beamon)) {

/*  Separate note. */

			udfq_(ch__1, 1L, nolev, ncm);
			*(unsigned char *)slurudq = *(unsigned char *)&ch__1[
				0];
		    } else {

/*  In a beam */

			if (*(unsigned char *)ulq != 'u') {
			    *(unsigned char *)slurudq = 'u';
			}
		    }
		    if (iscrd) {
/* c */
/* c  For single voice, check top & bottom note of cho
rd */
/* c */
/*                if (nolevs .eq. maxlev) then */
/*                  slurudq = 'u' */
/*                else if (nolevs .eq.minlev) then */
/*                  slurudq = 'd' */
/*                end if */
			if (nolevs > *ncm) {
			    *(unsigned char *)slurudq = 'u';
			} else {
			    *(unsigned char *)slurudq = 'd';
			}
		    }
		} else {

/*  Two voices per line.  Get default */

		    if (commvl_1.ivx > *nv) {
			*(unsigned char *)slurudq = 'u';
		    }

/*  Upper voice of the two, so up slur */

		}

/*  Save up/down-ness for use at termination */

		if (*(unsigned char *)slurudq == 'u') {
		    isdata = bit_set(isdata,27);
		}

/*  End of section for setting slur direction, still in "Turno
n" if-block. */

		if (idcode == 1 && tmove) {
		    iupdn = 1;
		    if (*(unsigned char *)slurudq == 'd') {
			iupdn = -1;
		    }
		}
/*            if ((btest(iornq,11).or.btest(iornq,12)) */
/*     *                              .and. ivoff.eq.0) then 
*/
		if (bit_test(*iornq,11) || bit_test(*iornq,12)) {

/* Raise or lower slur by one unit provided . or _ is on s
ame side as slur*/

		    if (stemup && *(unsigned char *)slurudq == 'd' || ! 
			    stemup && *(unsigned char *)slurudq == 'u') {

/*  Must move the slur for _ or . */

			if (stemup) {
/*                  ivoff = -1 */
			    ivoffinc = -1;
			} else {
/*                  ivoff = 1 */
			    ivoffinc = 1;
			}
			if ((stemup && *nolev >= *ncm - 2 || ! stemup && *
				nolev <= *ncm + 2) && (i__2 = *ncm - *nolev, 
				abs(i__2)) % 2 == 0) {
			    ivoffinc <<= 1;
			}
/*     *                mod(abs(ncm-nolev),2).eq.0) iv
off = 2*ivoff */
			ivoff += ivoffinc;
		    }
		}
		if (comslur_1.listslur == 511) {
		    s_wsle(&io___645);
		    do_lio(&c__9, &c__1, "You defined the tenth slur, one to\
o many!", 41L);
		    e_wsle();
		    s_stop("", 0L);
		}

/*  Get index of next slur not in use, starting from 8 down */

		i__2 = 511 - comslur_1.listslur;
		comslur_1.ndxslur = log2_(&i__2);

/*  Record slur index */

		comslur_1.listslur = bit_set(comslur_1.listslur,
			comslur_1.ndxslur);

/*  Save for use on termination */

		setbits_(&isdata, &c__4, &c__28, &comslur_1.ndxslur);

/*  Shift for stem? */

		if (stemup && *(unsigned char *)slurudq == 'u') {
		    ihoff += 8;
		}
		if (bit_test(isdat2[isdat],3)) {

/*  Tie spacing, (slur start) */

		    if (*(unsigned char *)slurudq == 'd') {
			++ivoff;
			ihoff += 8;
		    } else if (*(unsigned char *)slurudq == 'u') {
			--ivoff;
			if (! stemup) {
			    ihoff += 8;
			}

/*  (already shifted if stemup and slurudq='u') */

		    }
		}
		if (iscrd) {

/*  Shift slur starts for chord? */

/*              if (nolevs.gt.minlev .and. slurudq.eq.'d')
 then */
/*                ivoff = ivoff+1 */
/*                ihoff = ihoff+8 */
/*              else if (nolevs.lt.maxlev .and. slurudq.eq
.'u') then */
/*                ivoff = ivoff-1 */
/*                if (.not.stemup) ihoff = ihoff+8 */
/*              end if */

/*  Additional horiz shifts for h-shifted noteheads? */

		    if (bit_test(isdat2[isdat],1)) {

/*  Slur start on left-shifted chord notehead.  ASSUME
 downstem. */

			if (nolevs == comtrill_1.minlev && *(unsigned char *)
				slurudq == 'd') {
			    ihoff += -2;
			} else {
			    ihoff += -10;
			}
		    } else if (bit_test(isdat2[isdat],2)) {

/*  Right shifted chord notehead.  ASSUME upstem. */

			if (nolevs == comtrill_1.maxlev && *(unsigned char *)
				slurudq == 'u') {
			    ihoff += 2;
			} else {
			    ihoff += 10;
			}
		    }
		}
		if (ihoff == 0) {

/*  Write stuff for non-shifted start */

/* Writing concatenation */
		    i__3[0] = 6, a__1[0] = "\\islur";
		    i__3[1] = 1, a__1[1] = slurudq;
		    s_cat(notexq, a__1, i__3, &c__2, 79L);
		    lnote = 7;
		} else {
/* Writing concatenation */
		    i__3[0] = 3, a__1[0] = "\\is";
		    i__3[1] = 1, a__1[1] = slurudq;
		    s_cat(notexq, a__1, i__3, &c__2, 79L);
		    lnote = 4;
		}

/*  Add slur index to string */

/* Writing concatenation */
		i__3[0] = lnote, a__1[0] = notexq;
		*(unsigned char *)&ch__1[0] = comslur_1.ndxslur + 48;
		i__3[1] = 1, a__1[1] = ch__1;
		s_cat(notexq, a__1, i__3, &c__2, 79L);
		++lnote;

/*  Add note name to string */

		i__2 = nolevs + iupdn + ivoff;
		notefq_(noteq, &lnoten, &i__2, ncm, 8L);
/* Writing concatenation */
		i__3[0] = lnote, a__1[0] = notexq;
		i__3[1] = lnoten, a__1[1] = noteq;
		s_cat(notexq, a__1, i__3, &c__2, 79L);
		lnote += lnoten;

/* Save height (for ornament and barnobox interference) if top
most slur is up*/

		if (*(unsigned char *)slurudq == 'u' && (! bit_test(isdat2[
			isdat],0) || nolevs == comtrill_1.maxlev)) {
		    *islhgt = nolevs + iupdn + ivoff;

/*  Save height & idcode if top voice and slur start */

		    if (commvl_1.ivx == commvl_1.ivmx[*nv + commvl_1.nvmx[*nv 
			    - 1] * 7 - 8] && *islhgt > comsln_1.is1n1) {
			comsln_1.is1n1 = *islhgt;
			comsln_1.is2n1 = idcode;
		    }
		}
		if ((real) ihoff != (float)0.) {
		    shift = ihoff * (float).1;
/* Writing concatenation */
		    i__3[0] = lnote, a__1[0] = notexq;
		    i__3[1] = 1, a__1[1] = "{";
		    s_cat(notexq, a__1, i__3, &c__2, 79L);
		    ++lnote;
		    lform = lfmt1_(&shift);
		    i__2 = lnote;
		    ici__1.icierr = 0;
		    ici__1.icirnum = 1;
		    ici__1.icirlen = lnote + lform - i__2;
		    ici__1.iciunit = notexq + i__2;
/* Writing concatenation */
		    i__4[0] = 2, a__2[0] = "(f";
		    *(unsigned char *)&ch__1[0] = lform + 48;
		    i__4[1] = 1, a__2[1] = ch__1;
		    i__4[2] = 3, a__2[2] = ".1)";
		    ici__1.icifmt = (s_cat(ch__2, a__2, i__4, &c__3, 6L), 
			    ch__2);
		    s_wsfi(&ici__1);
		    do_fio(&c__1, (char *)&shift, (ftnlen)sizeof(real));
		    e_wsfi();
		    lnote += lform;
/* Writing concatenation */
		    i__3[0] = lnote, a__1[0] = notexq;
		    i__3[1] = 1, a__1[1] = "}";
		    s_cat(notexq, a__1, i__3, &c__2, 79L);
		    ++lnote;
		}
		addstr_(notexq, &lnote, soutq, lsout, 79L, 80L);

/*  Zero out ip1 to avoid problems if slur goes to next input 
blk. */

		setbits_(&isdata, &c__8, &c__3, &c__0);
	    } else {

/*  Slur is ending.  Back thru list to find starting slur */

		for (j = isdat - 1; j >= 1; --j) {
		    if (commvl_1.ivx == igetbits_(&isdat1[j], &c__3, &c__0)) {
			if (idcode == igetbits_(&isdat1[j], &c__7, &c__19)) {
			    comslur_1.ndxslur = igetbits_(&isdat1[j], &c__4, &
				    c__28);
			    if (bit_test(isdat1[j],27)) {
				*(unsigned char *)slurudq = 'u';
			    }
			    goto L4;
			}
		    }
/* L3: */
		}
		s_wsle(&io___653);
		do_lio(&c__9, &c__1, "Bad place in doslur", 19L);
		e_wsle();
		s_stop("1", 1L);
L4:

/*  Shift slur ending for stem on any note? */

		if (! stemup && *(unsigned char *)slurudq == 'd') {
		    ihoff += -8;
		}
		if (bit_test(isdat2[isdat],3)) {

/*  Shift ending for tie spacing */

		    if (*(unsigned char *)slurudq == 'u') {
			ihoff += -8;
			--ivoff;
		    } else if (*(unsigned char *)slurudq == 'd') {
			++ivoff;
			if (stemup) {
			    ihoff += -8;
			}
		    }
		}
		if (iscrd) {

/*  Shift for chord? */

/*              if (nolevs.lt.maxlev .and. slurudq.eq.'u')
 then */
/*                ihoff = ihoff-8 */
/*                ivoff = ivoff-1 */
/*              else if (nolevs.gt.minlev .and.  slurudq.e
q.'d') then */
/*                ivoff = ivoff+1 */
/*                if (stemup) ihoff = ihoff-8 */
/*              end if */

/*  Shift termination for shifted notehead? */

		    if (bit_test(isdat2[isdat],1)) {

/*  Left-shifted chord notehead.  ASSUME downstem. */

			if (nolevs == comtrill_1.minlev && *(unsigned char *)
				slurudq == 'd') {
			    ihoff += -2;
			} else {
			    ihoff += -10;
			}
		    } else if (bit_test(isdat2[isdat],2)) {

/*  Right shifted chord notehead.  ASSUME upstem. */

			if (nolevs == comtrill_1.maxlev && *(unsigned char *)
				slurudq == 'u') {
			    ihoff += 2;
			} else {
			    ihoff += 10;
			}
		    }
		}
		if (ihoff == 0) {
		    s_copy(notexq, "\\tslur", 79L, 6L);
		    lnote = 6;
		} else {

/*  Shift needed */

		    s_copy(notexq, "\\ts", 79L, 3L);
		    lnote = 3;
		}
/* Writing concatenation */
		i__3[0] = lnote, a__1[0] = notexq;
		*(unsigned char *)&ch__1[0] = comslur_1.ndxslur + 48;
		i__3[1] = 1, a__1[1] = ch__1;
		s_cat(notexq, a__1, i__3, &c__2, 79L);
		++lnote;
		if (bit_test(*iornq,11) || bit_test(*iornq,12)) {

/* Raise or lower slur by one unit provided . or _ is on s
ame side as slur*/

		    if (stemup && *(unsigned char *)slurudq == 'd' || ! 
			    stemup && *(unsigned char *)slurudq == 'u') {
			if (stemup) {
			    ivoffinc = -1;
			} else {
			    ivoffinc = 1;
			}
			if ((stemup && *nolev >= *ncm - 2 || ! stemup && *
				nolev <= *ncm + 2) && (i__2 = *ncm - *nolev, 
				abs(i__2)) % 2 == 0) {
			    ivoffinc <<= 1;
			}
		    }
		    ivoff += ivoffinc;
		}
		if (idcode == 1 && tmove) {

/*  t-slur height adjustment */

		    iupdn = 1;
		    if (*(unsigned char *)slurudq == 'd') {
			iupdn = -1;
		    }
		}
		i__2 = nolevs + iupdn + ivoff;
		notefq_(noteq, &lnoten, &i__2, ncm, 8L);
		if (*(unsigned char *)slurudq == 'u' && (! bit_test(isdat2[
			isdat],0) || nolevs == comtrill_1.maxlev)) {
		    *islhgt = nolevs + iupdn + ivoff;

/* If topvoice, upslur, and idcode checks, no more need to
 keep hgt for barno.*/

		    if (commvl_1.ivx == commvl_1.ivmx[*nv + commvl_1.nvmx[*nv 
			    - 1] * 7 - 8] && comsln_1.is1n1 > 0) {
			if (idcode == comsln_1.is2n1) {
			    comsln_1.is1n1 = 0;
			}
		    }
		}
/* Writing concatenation */
		i__3[0] = lnote, a__1[0] = notexq;
		i__3[1] = lnoten, a__1[1] = noteq;
		s_cat(notexq, a__1, i__3, &c__2, 79L);
		lnote += lnoten;
		if (ihoff != 0) {
		    shift = ihoff * (float).1;
/* Writing concatenation */
		    i__3[0] = lnote, a__1[0] = notexq;
		    i__3[1] = 1, a__1[1] = "{";
		    s_cat(notexq, a__1, i__3, &c__2, 79L);
		    ++lnote;
		    lform = lfmt1_(&shift);
		    i__2 = lnote;
		    ici__1.icierr = 0;
		    ici__1.icirnum = 1;
		    ici__1.icirlen = lnote + lform - i__2;
		    ici__1.iciunit = notexq + i__2;
/* Writing concatenation */
		    i__4[0] = 2, a__2[0] = "(f";
		    *(unsigned char *)&ch__1[0] = lform + 48;
		    i__4[1] = 1, a__2[1] = ch__1;
		    i__4[2] = 3, a__2[2] = ".1)";
		    ici__1.icifmt = (s_cat(ch__2, a__2, i__4, &c__3, 6L), 
			    ch__2);
		    s_wsfi(&ici__1);
		    do_fio(&c__1, (char *)&shift, (ftnlen)sizeof(real));
		    e_wsfi();
		    lnote += lform;
/* Writing concatenation */
		    i__3[0] = lnote, a__1[0] = notexq;
		    i__3[1] = 1, a__1[1] = "}";
		    s_cat(notexq, a__1, i__3, &c__2, 79L);
		    ++lnote;
		}
		addstr_(notexq, &lnote, soutq, lsout, 79L, 80L);

/*  Clear the bit from list of slurs in use */

		comslur_1.listslur = bit_clear(comslur_1.listslur,
			comslur_1.ndxslur);

/*  Zero out the entire strings for start and stop */

		isdata = 0;
		isdat2[isdat] = 0;
		isdat1[j] = 0;
		isdat2[j] = 0;
	    }
	    isdat1[isdat] = isdata;
	}
/* L1: */
    }

/*  Clear and collapse the slur data list */

    numdrop = 0;
/*      call report(nsdat,isdat1,isdat2) */
    i__1 = *nsdat;
    for (isdat = 1; isdat <= i__1; ++isdat) {
	if (isdat1[isdat] == 0) {
	    ++numdrop;
	} else if (numdrop > 0) {
	    isdat1[isdat - numdrop] = isdat1[isdat];
	    isdat2[isdat - numdrop] = isdat2[isdat];
	    isdat1[isdat] = 0;
	    isdat2[isdat] = 0;
	}
/* L2: */
    }
    *nsdat -= numdrop;
/*      call report(nsdat,isdat1,isdat2) */
    return 0;
} /* doslur_ */

/* Subroutine */ int addfb_(nfb, iv, itnew, it1fb, it2fb, ulfbq, ifbadd, 
	ulfbq_len)
integer *nfb, *iv, *itnew, *it1fb, *it2fb;
char *ulfbq;
integer *ifbadd;
ftnlen ulfbq_len;
{
    static integer ifb;

    /* Parameter adjustments */
    ulfbq -= 8;
    it2fb -= 8;
    it1fb -= 8;
    --nfb;

    /* Function Body */
    *ifbadd = 1;
    ++nfb[*iv];
    for (ifb = nfb[*iv] - 1; ifb >= 1; --ifb) {
	if (*itnew < it1fb[*iv + ifb * 7]) {
	    it1fb[*iv + (ifb + 1) * 7] = it1fb[*iv + ifb * 7];
	    it2fb[*iv + (ifb + 1) * 7] = it2fb[*iv + ifb * 7];
	    *(unsigned char *)&ulfbq[*iv + (ifb + 1) * 7] = *(unsigned char *)
		    &ulfbq[*iv + ifb * 7];
	} else {
	    *ifbadd = ifb + 1;
	    goto L2;
	}
/* L1: */
    }
L2:
    it1fb[*iv + *ifbadd * 7] = *itnew;
    *(unsigned char *)&ulfbq[*iv + *ifbadd * 7] = 'x';
    return 0;
} /* addfb_ */

/* Subroutine */ int addasx_(ip, iv, wasxn, elasxn, fixednew, scaldold, 
	isuxsp)
integer *ip, *iv;
real *wasxn, *elasxn, *fixednew, *scaldold;
logical *isuxsp;
{
    /* System generated locals */
    integer i__1;

    /* Builtin functions */
    integer s_wsle(), do_lio(), e_wsle();
    /* Subroutine */ int s_stop();

    /* Local variables */
    static integer iuxsp;

    /* Fortran I/O blocks */
    static cilist io___657 = { 0, 6, 0, 0, 0 };


    if (*isuxsp) {

/*  Find which uxsp we're dealing with */

	i__1 = comudsp_1.nuxsp;
	for (iuxsp = 1; iuxsp <= i__1; ++iuxsp) {
	    if (*ip == comudsp_1.ipuxsp[iuxsp - 1] && *iv == comudsp_1.ivuxsp[
		    iuxsp - 1]) {
		goto L2;
	    }
/* L1: */
	}
	s_wsle(&io___657);
	do_lio(&c__9, &c__1, "You should not BEEE here in addasx!", 35L);
	e_wsle();
	s_stop("1", 1L);
L2:

/* Fixednew and scaldold must not be changed, since uxsp's are already
 included*/
/* in fsyst from pmxa, and uxsp don't involve scaled space (? implemen
t in pmxa)*/

	if (comas1_1.nasxb > 0 && comas1_1.ipasx[comas1_1.nasxb - 1] == *ip &&
		 comas1_1.ivasx[comas1_1.nasxb - 1] == *iv) {

/*  Must add user-defined space to what's here already. */

	    comas1_1.wasx[comas1_1.nasxb - 1] += comudsp_1.uxsp[iuxsp - 1];
	} else {

/*  This place has no other space. */

	    ++comas1_1.nasxb;
	    comas1_1.ipasx[comas1_1.nasxb - 1] = *ip;
	    comas1_1.ivasx[comas1_1.nasxb - 1] = *iv;
	    comas1_1.wasx[comas1_1.nasxb - 1] = comudsp_1.uxsp[iuxsp - 1];
	    comas1_1.elasx[comas1_1.nasxb - 1] = (float)0.;
	}
    } else {

/*  Non-uxsp processing */

	++comas1_1.nasxb;
	comas1_1.ipasx[comas1_1.nasxb - 1] = *ip;
	comas1_1.ivasx[comas1_1.nasxb - 1] = *iv;
	comas1_1.wasx[comas1_1.nasxb - 1] = *wasxn;
	comas1_1.elasx[comas1_1.nasxb - 1] = *elasxn;
	*fixednew += *wasxn;
	*scaldold += *elasxn;
    }
    return 0;
} /* addasx_ */

/* Subroutine */ int addask_(itaskn, waskn, elaskn, fixednew, scaldold, 
	itglp1, isudsp)
integer *itaskn;
real *waskn, *elaskn, *fixednew, *scaldold;
integer *itglp1;
logical *isudsp;
{
    /* System generated locals */
    integer i__1;

    /* Builtin functions */
    integer s_wsle(), do_lio(), e_wsle();
    /* Subroutine */ int s_stop();

    /* Local variables */
    static integer iudsp;

    /* Fortran I/O blocks */
    static cilist io___659 = { 0, 6, 0, 0, 0 };


    if (*isudsp) {

/*  Find which udsp we're dealing with */

	i__1 = comudsp_1.nudsp;
	for (iudsp = 1; iudsp <= i__1; ++iudsp) {
	    if (*itaskn + *itglp1 == comudsp_1.itudsp[iudsp - 1]) {
		goto L2;
	    }
/* L1: */
	}
	s_wsle(&io___659);
	do_lio(&c__9, &c__1, "You should note BEEE here in addask!", 36L);
	e_wsle();
	s_stop("1", 1L);
L2:

/* Fixednew and scaldold must not be changed, since udsp's are already
 included*/
/*  in fsyst from pmxa, and udsp don't involve scaled space.. */

	if (comas1_1.naskb > 0 && *itaskn == comas1_1.itask[comas1_1.naskb - 
		1]) {

/*  Must add user-defined space to what's there already. */

	    comas1_1.wask[comas1_1.naskb - 1] += comudsp_1.udsp[iudsp - 1];
	} else {

/*  This place has no other space. */

	    ++comas1_1.naskb;
	    comas1_1.itask[comas1_1.naskb - 1] = *itaskn;
	    comas1_1.wask[comas1_1.naskb - 1] = comudsp_1.udsp[iudsp - 1];
	    comas1_1.elask[comas1_1.naskb - 1] = (float)0.;
	}
    } else {

/*  This is a normal space, no effect if smaller than existing space 
*/

	if (comas1_1.naskb > 0 && *itaskn == comas1_1.itask[comas1_1.naskb - 
		1]) {

/*  We already put in some space at this time */
/*  Check if new one needs more space than old one at same time */

	    if (*waskn > comas1_1.wask[comas1_1.naskb - 1]) {
		--comas1_1.naskb;
	    } else {
		return 0;
	    }
	}
	++comas1_1.naskb;
	comas1_1.itask[comas1_1.naskb - 1] = *itaskn;
	comas1_1.wask[comas1_1.naskb - 1] = *waskn;
	comas1_1.elask[comas1_1.naskb - 1] = *elaskn;
	*fixednew += *waskn;
	*scaldold += *elaskn;
    }
    return 0;
} /* addask_ */

/* Subroutine */ int askfig_(pathnameq, lpath, basenameq, lbase, figbass, 
	istype0, pathnameq_len, basenameq_len)
char *pathnameq;
integer *lpath;
char *basenameq;
integer *lbase;
logical *figbass, *istype0;
ftnlen pathnameq_len;
ftnlen basenameq_len;
{
    /* System generated locals */
    address a__1[3], a__2[2];
    integer i__1[3], i__2[2], i__3;
    char ch__1[68], ch__2[15], ch__3[5], ch__4[4];
    olist o__1;
    cllist cl__1;
    alist al__1;

    /* Builtin functions */
    /* Subroutine */ int s_cat();
    integer f_open(), f_rew(), f_clos(), s_wsfe(), do_fio(), e_wsfe(), s_rsfe(
	    ), e_rsfe(), s_cmp(), s_wsfi(), e_wsfi(), i_indx();

    /* Local variables */
    static logical done;
    extern integer llen_();
    static char outq[129];
    static integer il;
    static char sq[1];
    extern /* Subroutine */ int moveln_();
    static integer lenout;
    extern /* Subroutine */ int putast_();
    static integer ihs, indxask, indxasx;

    /* Fortran I/O blocks */
    static cilist io___663 = { 0, 12, 0, "(a)", 0 };
    static cilist io___665 = { 0, 11, 1, "(a129)", 0 };
    static icilist io___667 = { 0, outq+11, 0, "(f4.1)", 4, 1 };
    static cilist io___671 = { 0, 12, 0, "(a)", 0 };
    static cilist io___672 = { 0, 16, 1, "(a129)", 0 };
    static cilist io___673 = { 0, 12, 0, "(a)", 0 };


    *(unsigned char *)sq = '\\';
    o__1.oerr = 0;
    o__1.ounit = 12;
    o__1.ofnmlen = *lpath + *lbase + 4;
/* Writing concatenation */
    i__1[0] = *lpath, a__1[0] = pathnameq;
    i__1[1] = *lbase, a__1[1] = basenameq;
    i__1[2] = 4, a__1[2] = ".tex";
    s_cat(ch__1, a__1, i__1, &c__3, 68L);
    o__1.ofnm = ch__1;
    o__1.orl = 0;
    o__1.osta = 0;
    o__1.oacc = 0;
    o__1.ofm = 0;
    o__1.oblnk = 0;
    f_open(&o__1);

/*  Transfer first 5 lines of main internal TeX file */

    for (il = 1; il <= 5; ++il) {
	moveln_(&c__11, &c__12, &done);
/* L11: */
    }
    if (*istype0) {

/*  Transfer literal TeX stuff from special scratch file */

	al__1.aerr = 0;
	al__1.aunit = 17;
	f_rew(&al__1);
L10:
	moveln_(&c__17, &c__12, &done);
	if (! done) {
	    goto L10;
	}
	cl__1.cerr = 0;
	cl__1.cunit = 17;
	cl__1.csta = 0;
	f_clos(&cl__1);
    }

/*  Transfer next 2 lines from main scratch file */

    for (il = 1; il <= 2; ++il) {
	moveln_(&c__11, &c__12, &done);
/* L3: */
    }
    if (compoi_1.ispoi) {
	s_wsfe(&io___663);
/* Writing concatenation */
	i__2[0] = 1, a__2[0] = sq;
	i__2[1] = 14, a__2[1] = "input musixpoi";
	s_cat(ch__2, a__2, i__2, &c__2, 15L);
	do_fio(&c__1, ch__2, 15L);
	e_wsfe();
    }
    if (*figbass) {

/*  Transfer .fig data from scratch (unit 14) into external .tex (unit
 12) */

L4:
	moveln_(&c__14, &c__12, &done);
	if (! done) {
	    goto L4;
	}
	cl__1.cerr = 0;
	cl__1.cunit = 14;
	cl__1.csta = 0;
	f_clos(&cl__1);
    }
    comas3_1.iask = 0;
    comas3_1.iasx = 0;
    ihs = 0;
L1:
    i__3 = s_rsfe(&io___665);
    if (i__3 != 0) {
	goto L999;
    }
    i__3 = do_fio(&c__1, outq, 129L);
    if (i__3 != 0) {
	goto L999;
    }
    i__3 = e_rsfe();
    if (i__3 != 0) {
	goto L999;
    }

/*  Hardspaces. */

/* Writing concatenation */
    i__2[0] = 1, a__2[0] = sq;
    i__2[1] = 4, a__2[1] = "xard";
    s_cat(ch__3, a__2, i__2, &c__2, 5L);
    if (s_cmp(outq, ch__3, 5L, 5L) == 0) {
	++ihs;
	*(unsigned char *)&outq[1] = 'h';
	s_wsfi(&io___667);
	do_fio(&c__1, (char *)&comhsp_1.hpttot[ihs - 1], (ftnlen)sizeof(real))
		;
	e_wsfi();
	lenout = 19;
	goto L9;
    }

/*  This part hard-wires ask's into new .tex file as ast's */

L2:
/* Writing concatenation */
    i__2[0] = 1, a__2[0] = sq;
    i__2[1] = 3, a__2[1] = "ask";
    s_cat(ch__4, a__2, i__2, &c__2, 4L);
    indxask = i_indx(outq, ch__4, 129L, 4L);
    if (indxask != 0) {
	++comas3_1.iask;
	putast_(&comas3_1.ask[comas3_1.iask - 1], &indxask, outq, 129L);
	goto L2;
    }

/*  Now same deal for asx's */

L6:
/* Writing concatenation */
    i__2[0] = 1, a__2[0] = sq;
    i__2[1] = 3, a__2[1] = "asx";
    s_cat(ch__4, a__2, i__2, &c__2, 4L);
    indxasx = i_indx(outq, ch__4, 129L, 4L);
    if (indxasx != 0) {
	++comas3_1.iasx;
	putast_(&comas3_1.asx[comas3_1.iasx - 1], &indxasx, outq, 129L);
	goto L6;
    }
    lenout = llen_(outq, &c__129, 129L);
L9:
    s_wsfe(&io___671);
    do_fio(&c__1, outq, lenout);
    e_wsfe();

/*  If this is the line with "readmod", check for topmods. */

    if (comas3_1.topmods && s_cmp(outq + 1, "readmod", 7L, 7L) == 0) {
	comas3_1.topmods = FALSE_;
	al__1.aerr = 0;
	al__1.aunit = 16;
	f_rew(&al__1);
	for (il = 1; il <= 1000; ++il) {
	    i__3 = s_rsfe(&io___672);
	    if (i__3 != 0) {
		goto L8;
	    }
	    i__3 = do_fio(&c__1, outq, 129L);
	    if (i__3 != 0) {
		goto L8;
	    }
	    i__3 = e_rsfe();
	    if (i__3 != 0) {
		goto L8;
	    }
	    lenout = llen_(outq, &c__129, 129L);
/*         write(12,'(a)')outq(1:lenout)//'%' */

/* We inserted the '%' in subroutine littex, to guarantee includin
g blank.*/

	    s_wsfe(&io___673);
	    do_fio(&c__1, outq, lenout);
	    e_wsfe();
/* L7: */
	}
L8:
	cl__1.cerr = 0;
	cl__1.cunit = 16;
	cl__1.csta = 0;
	f_clos(&cl__1);
    }
    goto L1;
L999:
    cl__1.cerr = 0;
    cl__1.cunit = 11;
    cl__1.csta = 0;
    f_clos(&cl__1);
    cl__1.cerr = 0;
    cl__1.cunit = 12;
    cl__1.csta = 0;
    f_clos(&cl__1);
    return 0;
} /* askfig_ */

integer llen_(strq, n, strq_len)
char *strq;
integer *n;
ftnlen strq_len;
{
    /* System generated locals */
    integer ret_val;

/*        character strq */
    for (ret_val = *n; ret_val >= 0; --ret_val) {
	if (*(unsigned char *)&strq[ret_val - 1] != ' ') {
	    return ret_val;
	}
/* L1: */
    }
    return ret_val;
} /* llen_ */

/* Subroutine */ int putast_(elask, indxask, outq, outq_len)
real *elask;
integer *indxask;
char *outq;
ftnlen outq_len;
{
    /* System generated locals */
    address a__1[3];
    integer i__1, i__2[3];
    icilist ici__1;

    /* Builtin functions */
    integer s_wsfi(), do_fio(), e_wsfi();
    /* Subroutine */ int s_copy(), s_cat();

    /* Local variables */
    static char fmtq[9];
    static integer lp;
    static char tag[129];

    /* Fortran I/O blocks */
    static icilist io___676 = { 0, fmtq, 0, "(a5,i1,a3)", 9, 1 };


    if (*elask >= (float)0.) {
	if (*elask < (float).995) {
	    lp = 3;
	} else if (*elask < (float)9.995) {
	    lp = 4;
	} else {
	    lp = 5;
	}
	s_wsfi(&io___676);
	do_fio(&c__1, "(a2,f", 5L);
	do_fio(&c__1, (char *)&lp, (ftnlen)sizeof(integer));
	do_fio(&c__1, ".2)", 3L);
	e_wsfi();
    } else {
	lp = 5;
	s_copy(fmtq, "(a2,f5.1)", 9L, 9L);
    }

/*  Overwrite as follows:  ...xyz*ask     *lmnop... -> */
/*                         ...xyz*ast{.nn}*lmnop... */
/*                         ...xyz*ast{n.nn}*lmnop... */
/*                         ...xyz*ast{nn.nn}*lmnop... */
/*  or for negative,       ...xyz*ast{-nn.n}*lmnop... */
    i__1 = *indxask + 8;
    s_copy(tag, outq + i__1, 129L, 129 - i__1);
/*       write(outq(indxask+3:),fmtq)'t{',dim(elask,0.) */
    i__1 = *indxask + 2;
    ici__1.icierr = 0;
    ici__1.icirnum = 1;
    ici__1.icirlen = 129 - i__1;
    ici__1.iciunit = outq + i__1;
    ici__1.icifmt = fmtq;
    s_wsfi(&ici__1);
    do_fio(&c__1, "t{", 2L);
    do_fio(&c__1, (char *)&(*elask), (ftnlen)sizeof(real));
    e_wsfi();
/* Writing concatenation */
    i__2[0] = *indxask + 4 + lp, a__1[0] = outq;
    i__2[1] = 1, a__1[1] = "}";
    i__2[2] = 129, a__1[2] = tag;
    s_cat(outq, a__1, i__2, &c__3, 129L);
    return 0;
} /* putast_ */

logical blkstart_(list, in, itstart, nodurm1)
integer *list, *in, *itstart, *nodurm1;
{
    /* System generated locals */
    logical ret_val;

    /* Parameter adjustments */
    list -= 5;

    /* Function Body */
    ret_val = *itstart == list[(*in << 2) + 3] && (*in == 1 || *nodurm1 != 0);
    return ret_val;
} /* blkstart_ */

/* Subroutine */ int sslur_(lineq, iccount, ivx, ip, isdat1, isdat2, nsdat, 
	notcrd, nolev, lineq_len)
char *lineq;
integer *iccount, *ivx, *ip, *isdat1, *isdat2, *nsdat;
logical *notcrd;
integer *nolev;
ftnlen lineq_len;
{
    /* System generated locals */
    integer i__1;

    /* Builtin functions */
    integer i_indx();

    /* Local variables */
    static real fnum;
    static char dumq[1], durq[1];
    extern integer igetbits_();
    static integer ihoff, isdat, ivoff, idcode, nolevc;
    static logical invoff, turnon;
    extern /* Subroutine */ int getchar_(), readnum_(), setbits_();


/* Reads in slur data.  Record all h/v-shifts for non-chords, user-specifi
ed*/
/*c  ones for chords.  Auto-shifts in chords done after last crd note, in 
slurcrd*/
/*  ones for chords. */

    /* Parameter adjustments */
    --isdat2;
    --isdat1;

    /* Function Body */
    invoff = FALSE_;
    turnon = TRUE_;
    ivoff = 0;
    ihoff = 0;
    ++(*nsdat);
    setbits_(&isdat1[*nsdat], &c__3, &c__0, ivx);
    setbits_(&isdat1[*nsdat], &c__8, &c__3, ip);

/*  Get id letter */

    if (*(unsigned char *)&lineq[*iccount - 1] == 't') {

/*  Old-style t-slur. Use special idcode = 1 */

	idcode = 1;
    } else {
	getchar_(lineq, iccount, durq, 128L, 1L);
	if (i_indx("uldt+- ", durq, 7L, 1L) > 0) {

/*  Null id */

	    idcode = 32;
	    --(*iccount);
	} else {
	    idcode = *(unsigned char *)durq;
	}
    }
    setbits_(&isdat1[*nsdat], &c__7, &c__19, &idcode);

/*  Set start/stop: look thru list from end for same idcode & ivx */

    for (isdat = *nsdat - 1; isdat >= 1; --isdat) {
	if (idcode == igetbits_(&isdat1[isdat], &c__7, &c__19) && *ivx == (7 &
		 isdat1[isdat])) {

/* Matched idcode & ivx.  On/off?.  If on, new is turnoff, leave b
it 11 at 0.*/

	    if (bit_test(isdat1[isdat],11)) {
		goto L3;
	    }

/*  Found slur is a turnoff, so new one is a turnon.  Jump down to
 set bit */

	    goto L4;
	}
/* L2: */
    }

/*  If here, this is turnon. */

L4:
    isdat1[*nsdat] = bit_set(isdat1[*nsdat],11);
L3:

/* Now done with initial turnon- or turnoff-specifics.  Loop for rest of i
nput*/

L1:
    getchar_(lineq, iccount, durq, 128L, 1L);
    if (i_indx("uld", durq, 3L, 1L) > 0) {

/*  Force direction */

	isdat1[*nsdat] = bit_set(isdat1[*nsdat],26);
	if (*(unsigned char *)durq == 'u') {
	    isdat1[*nsdat] = bit_set(isdat1[*nsdat],27);
	}
	goto L1;
    } else if (i_indx("+-", durq, 2L, 1L) > 0) {
	if (! invoff) {

/*  Vertical offset */

	    invoff = TRUE_;
	    ++(*iccount);
	    readnum_(lineq, iccount, dumq, &fnum, 128L, 1L);
	    --(*iccount);
	    ivoff = (integer) (fnum + (float).5);
	    if (*(unsigned char *)durq == '-') {
		ivoff = -ivoff;
	    }
	} else {

/*  Horizontal offset */

	    ++(*iccount);
	    readnum_(lineq, iccount, dumq, &fnum, 128L, 1L);
	    --(*iccount);

/*  fnum is abs(hshift), must be 0 to 6.3 */

	    ihoff = fnum * 10 + (float).5;
	    if (*(unsigned char *)durq == '-') {
		ihoff = -ihoff;
	    }

/*  Later will set bits to 1...127 to represent -6.3,...+6.3 */

	}
	goto L1;
    } else if (*(unsigned char *)durq == 't') {
	isdat2[*nsdat] = bit_set(isdat2[*nsdat],3);
	goto L1;
    }

/*  Record shifts */

    i__1 = ivoff + 32;
    setbits_(&isdat2[*nsdat], &c__6, &c__6, &i__1);
    i__1 = ihoff + 64;
    setbits_(&isdat2[*nsdat], &c__7, &c__12, &i__1);

/*  Record chord flag, note level, notehead shift */

    if (*notcrd) {
	setbits_(&isdat2[*nsdat], &c__7, &c__19, nolev);
    } else {
	nolevc = igetbits_(&comtrill_1.icrdat[comtrill_1.ncrd - 1], &c__7, &
		c__12);
	setbits_(&isdat2[*nsdat], &c__7, &c__19, &nolevc);
	isdat2[*nsdat] = bit_set(isdat2[*nsdat],0);
	i__1 = igetbits_(&comtrill_1.icrdat[comtrill_1.ncrd - 1], &c__2, &
		c__23);
	setbits_(&isdat2[*nsdat], &c__2, &c__1, &i__1);
    }
/*     call report(nsdat,isdat1,isdat2) */
    return 0;
} /* sslur_ */

/* Subroutine */ int setupb_(xelsk, nnb, sumx, sumy, ipb, islope, smed, 
	nolev1, epns)
real *xelsk;
integer *nnb;
real *sumx, *sumy;
integer *ipb, *islope;
real *smed;
integer *nolev1;
real *epns;
{
    /* System generated locals */
    integer i__1, i__2;
    real r__1, r__2;

    /* Builtin functions */
    integer s_wsle(), do_lio(), e_wsle();
    /* Subroutine */ int s_stop();
    integer i_sign();
    double sqrt();

    /* Local variables */
    static real beta;
    extern doublereal feon_();
    static real smin, elsperns;
    static integer i__, j;
    static real t;
    extern integer ncmid_();
    static real ybeam, xboff, slope[800];
    static integer n1, n2;
    static real ynote;
    extern /* Subroutine */ int setbm2_();
    static integer in;
    extern integer ni_();
    static integer nscmid, iiasxb;
    static real dnolev;
    static integer nolevo;
    static real yb1;
    static logical isxtup;
    static integer ibc, inb, jnb;
    static real off, xnolev2;
    static integer iin, iip, nsc;
    static real deficit;
    static integer iul;
    static real syb, ssq;
    static logical xtended;
    static real off1, off2;
    static logical l1ng, l2ng;
    static real elsksum;
    static logical endxtup;

    /* Fortran I/O blocks */
    static cilist io___700 = { 0, 6, 0, 0, 0 };


/*    *                  islope,smed,nolev1,nornb,epns) */

/* The outer combo algorithm */

/*     integer ipb(24),nornb(nm) */
    /* Parameter adjustments */
    --ipb;
    --xelsk;

    /* Function Body */
    ibc = all_1.ibmcnt[commvl_1.ivx - 1];
    n1 = 255 & all_1.ipl[commvl_1.ivx + all_1.ibm1[commvl_1.ivx + ibc * 7 - 8]
	     * 7 - 8];
    n2 = 255 & all_1.ipl[commvl_1.ivx + all_1.ibm2[commvl_1.ivx + ibc * 7 - 8]
	     * 7 - 8];

/*Figure how many elemskips to each note. Use the list, counting only non-
rests.*/

    elsksum = (float)0.;
    iiasxb = comas1_1.iasxb;
    *nnb = 0;
    *sumx = (float)0.;
    *sumy = (float)0.;
    isxtup = FALSE_;
    endxtup = FALSE_;
    i__1 = n2;
    for (in = n1; in <= i__1; ++in) {
	if (all_1.list[(in << 2) - 4] == commvl_1.ivx && ! bit_test(
		all_1.irest[commvl_1.ivx + all_1.list[(in << 2) - 3] * 7 - 8],
		0)) {
	    ++(*nnb);
	    ipb[*nnb] = all_1.list[(in << 2) - 3];
	    xelsk[*nnb] = elsksum;
	    *sumx += xelsk[*nnb];
	    *sumy += all_1.nolev[commvl_1.ivx + ipb[*nnb] * 7 - 8];
	}
	if (in < n2) {
	    if (endxtup) {
		if (all_1.list[(in << 2) - 4] != commvl_1.ivx) {
		    goto L2;
		}
		endxtup = FALSE_;
	    }

/*  Don't do anything until coming to next note in main voice. */

	    if (all_1.nodur[commvl_1.ivx + ipb[*nnb] * 7 - 8] > 0) {

/*  Non-xtup or last note of xtup. */

		if (! isxtup) {
		    if (all_1.list[(in << 2) - 1] != 0) {
			r__1 = (real) all_1.list[(in << 2) - 1];
			elsperns = feon_(&r__1) * comxtup_2.xtupfac[
				commvl_1.ivx - 1];
		    }
		} else {

/* Last note of xtup. Set flag so no more skips until next
 note in same voice.*/

		    endxtup = TRUE_;
		    comxtup_2.eloff = (xelsk[*nnb] - comxtup_2.eloff) / (
			    float)2.;
		}
	    } else {

/*  Since nodur=0, this is start or middle of xtup */

		if (! isxtup) {

/*  Start of xtup */

		    isxtup = TRUE_;

/* Save xelsk for number location computation. Won't work 
if >1 xtup at once?*/

		    comxtup_2.eloff = xelsk[*nnb];
		    xtended = FALSE_;
		    for (iin = in + 1; iin <= 100; ++iin) {
			if (! xtended && all_1.list[(iin << 2) - 4] == 
				commvl_1.ivx) {
			    if (all_1.nodur[commvl_1.ivx + all_1.list[(iin << 
				    2) - 3] * 7 - 8] > 0) {
				xtended = TRUE_;
				iip = all_1.list[(iin << 2) - 3];
				if (all_1.list[(iin << 2) - 1] > 0) {
				    goto L3;
				}
			    }
			} else if (xtended) {
			    if (all_1.list[(iin << 2) - 1] > 0) {
				goto L3;
			    }
			}
/* L1: */
		    }
		    s_wsle(&io___700);
		    do_lio(&c__9, &c__1, "Trouble.  Call Dr. Don!", 23L);
		    e_wsle();
		    s_stop("", 0L);
L3:

/*At this point iip is ip# of last note of xtup, and iin i
s last list pos'n*/
/*   before jump to next time position (sets nspace) */

/*  xtupfac may not be defined if xtup doesn't start the b
eam? */

		    if (*nnb == 1) {

/*  Xtup starts the beam */

/*                 elsperns = feon(float(nodur(ivx,iip
)))*xtupfac(ivx) */
			r__1 = (real) all_1.list[(iin << 2) - 1];
			elsperns = feon_(&r__1) * comxtup_2.xtupfac[
				commvl_1.ivx - 1];
		    } else {

/*  *Assumes* that xtup defines spacing! */

			r__1 = (real) all_1.nodur[commvl_1.ivx + iip * 7 - 8] 
				/ (iip - ipb[*nnb] + 1);
			elsperns = feon_(&r__1);
		    }
		}
	    }
	    if (all_1.list[(in << 2) - 1] > 0 || isxtup) {
		elsksum += elsperns;

/*  Add in space for for skips if needed */

		if (isxtup && iiasxb <= comas1_1.nasxb && all_1.list[(in << 2)
			 - 3] + 1 == comas1_1.ipasx[iiasxb - 1] && all_1.list[
			(in << 2) - 4] == comas1_1.ivasx[iiasxb - 1]) {

/*  add in approximate space for xtup accid skip */

		    elsksum = elsksum + comas1_1.wasx[iiasxb - 1] / 
			    comask_1.poenom - comas1_1.elasx[iiasxb - 1];
		    ++iiasxb;
		}
/* cccccccccccccccccccccccccccccccc */

/*  Insert check for ask here ???. */

/* cccccccccccccccccccccccccccccccc */
		if (endxtup) {
		    isxtup = FALSE_;
		}
	    }
	}
L2:
	;
    }
    if (ipb[*nnb] > 1) {
	if (all_1.nodur[commvl_1.ivx + (ipb[*nnb] - 1) * 7 - 8] == 0) {
	    comxtup_2.eloff = (xelsk[*nnb] - comxtup_2.eloff) / (float)2.;
	}
    }
    *epns = elsperns;
    *smed = (float)0.;
    if (! bit_test(all_1.islur[commvl_1.ivx + ipb[1] * 7 - 8],2)) {

/* No forced 0 slope */

	if (*nnb == 1) {
	    goto L6;
	}
	nsc = 0;
	i__1 = *nnb - 1;
	for (inb = 1; inb <= i__1; ++inb) {
	    i__2 = *nnb;
	    for (jnb = inb + 1; jnb <= i__2; ++jnb) {
		++nsc;
		slope[nsc - 1] = (all_1.nolev[commvl_1.ivx + ipb[jnb] * 7 - 8]
			 - all_1.nolev[commvl_1.ivx + ipb[inb] * 7 - 8]) / (
			xelsk[jnb] - xelsk[inb]);
		if ((r__1 = slope[nsc - 1], dabs(r__1)) < (float)1e-4) {
		    ++nsc;
		    slope[nsc - 1] = slope[nsc - 2];
		    ++nsc;
		    slope[nsc - 1] = slope[nsc - 2];
		}
/* L5: */
	    }
	}
	if (nsc == 1) {
	    *smed = slope[0];
	    goto L6;
	}
	nscmid = nsc / 2 + 1;
	i__2 = nscmid;
	for (i__ = 1; i__ <= i__2; ++i__) {
	    i__1 = nsc;
	    for (j = i__ + 1; j <= i__1; ++j) {
		if (slope[j - 1] < slope[i__ - 1]) {
		    t = slope[j - 1];
		    slope[j - 1] = slope[i__ - 1];
		    slope[i__ - 1] = t;
		}
/* L7: */
	    }
	}
	*smed = slope[nscmid - 1];
	if (nsc == nsc / 2 << 1 && (r__1 = slope[nscmid - 2], dabs(r__1)) < (
		r__2 = slope[nscmid - 1], dabs(r__2))) {
	    *smed = slope[nscmid - 2];
	}
L6:
	r__1 = *smed * (float).5 * all_1.slfac;
	*islope = ni_(&r__1);
	if (abs(*islope) > 9) {
	    *islope = i_sign(&c__9, islope);
	}
    } else {
	*islope = 0;
    }
    beta = (*sumy - *islope / all_1.slfac * *sumx) / *nnb;
    *nolev1 = beta + (float).5;

/*  Check if any stems are too short */

    smin = (float)100.;
    iul = -1;
    if (*(unsigned char *)&all_1.ulq[commvl_1.ivx + ibc * 7 - 8] == 'u') {
	iul = 1;
    }
    ssq = (float)0.;
    syb = (float)0.;
    yb1 = *nolev1 + iul * (all_1.stemlen + combmh_1.bmhgt * (all_1.mult[
	    commvl_1.ivx + ipb[1] * 7 - 8] - 1));
    i__1 = *nnb;
    for (inb = 1; inb <= i__1; ++inb) {
	ybeam = yb1 + *islope * xelsk[inb] / all_1.slfac - iul * 
		combmh_1.bmhgt * (all_1.mult[commvl_1.ivx + ipb[inb] * 7 - 8] 
		- 1);
	syb += ybeam;
	ynote = (real) all_1.nolev[commvl_1.ivx + ipb[inb] * 7 - 8];
	off = ybeam - ynote;
	if (inb == 1) {
	    off1 = off;
	} else if (inb == *nnb) {
	    off2 = off;
	}
	ssq += off * off;
/* Computing MIN */
	r__1 = smin, r__2 = iul * off;
	smin = dmin(r__1,r__2);
/* L4: */
    }
    dnolev = (float)0.;
    if (smin < all_1.stemmin) {
	deficit = all_1.stemmin - smin;
	nolevo = *nolev1;
	r__1 = *nolev1 + iul * deficit;
	*nolev1 = ni_(&r__1);
	dnolev = (real) (*nolev1 - nolevo);
	off1 += dnolev;
	off2 += dnolev;
    }
/* Computing 2nd power */
    r__1 = dnolev;
    ssq = ssq + dnolev * 2 * (syb - *sumy) + r__1 * r__1;
    if (! comxtup_2.vxtup[commvl_1.ivx - 1] && sqrt(ssq / *nnb) > 
	    all_1.stemmax && (dabs(off1) < all_1.stemmax || dabs(off2) < 
	    all_1.stemmax) && ! bit_test(all_1.islur[commvl_1.ivx + ipb[1] * 
	    7 - 8],2)) {

/*  The first check is to save trouble of putting xtup's in setbm2. */
/* The penultimate check is that first and last stems aren't both exce
ssive.*/
/*  The last check is that a 0 slope has not been forced */

	setbm2_(&xelsk[1], nnb, sumx, sumy, &ipb[1], islope, nolev1);
    }

/*  Check if beam starts or ends too high or low. */

    xboff = combmh_1.bmhgt * (all_1.mult[commvl_1.ivx + ipb[1] * 7 - 8] - 1);
    l1ng = iul * (*nolev1 - ncmid_(&all_1.iv, &ipb[1])) + xboff + 7 < (float)
	    0.;
    xnolev2 = *nolev1 + *islope / all_1.slfac * xelsk[*nnb];
    l2ng = iul * (xnolev2 - ncmid_(&all_1.iv, &ipb[*nnb])) + xboff + 7 < (
	    float)0.;
    if (l1ng || l2ng) {

/*  Need to correct start or stop, also slope */

	if (l1ng) {
	    r__1 = ncmid_(&all_1.iv, &ipb[1]) - (xboff + (float)7.) * iul;
	    *nolev1 = ni_(&r__1);
	}
	if (l2ng) {
	    r__1 = ncmid_(&all_1.iv, &ipb[*nnb]) - (xboff + (float)7.) * iul;
	    xnolev2 = (real) ni_(&r__1);
	}

/*  Since one or the other end has changed, need to change slope */

	if (! bit_test(all_1.islur[commvl_1.ivx + ipb[1] * 7 - 8],2)) {
	    r__1 = all_1.slfac * (xnolev2 - *nolev1) / xelsk[*nnb];
	    *islope = ni_(&r__1);
	}
    }
    return 0;
} /* setupb_ */

/* Subroutine */ int setbm2_(xelsk, nnb, sumx, sumy, ipb, islope, nolev1)
real *xelsk;
integer *nnb;
real *sumx, *sumy;
integer *ipb, *islope, *nolev1;
{
    /* System generated locals */
    integer i__1;
    real r__1, r__2;

    /* Builtin functions */
    integer i_sign();

    /* Local variables */
    static real beta, smin, delta, ybeam;
    static integer n1, n2;
    static real ynote, sumxx, sumxy, em;
    extern integer ni_();
    static integer nolevo, ibc, inb;
    static real deficit;
    static integer iul;


/* The MEAN SQUARE slope algorithm */

    /* Parameter adjustments */
    --ipb;
    --xelsk;

    /* Function Body */
    ibc = all_1.ibmcnt[commvl_1.ivx - 1];
    n1 = 255 & all_1.ipl[commvl_1.ivx + all_1.ibm1[commvl_1.ivx + ibc * 7 - 8]
	     * 7 - 8];
    n2 = 255 & all_1.ipl[commvl_1.ivx + all_1.ibm2[commvl_1.ivx + ibc * 7 - 8]
	     * 7 - 8];
    sumxx = (float)0.;
    sumxy = (float)0.;
    i__1 = *nnb;
    for (inb = 1; inb <= i__1; ++inb) {
/* Computing 2nd power */
	r__1 = xelsk[inb];
	sumxx += r__1 * r__1;
	sumxy += xelsk[inb] * all_1.nolev[commvl_1.ivx + ipb[inb] * 7 - 8];
/* L2: */
    }
    delta = *nnb * sumxx - *sumx * *sumx;
    em = (*nnb * sumxy - *sumx * *sumy) / delta;
    r__1 = em * (float).5 * all_1.slfac;
    *islope = ni_(&r__1);
    if (abs(*islope) > 9) {
	*islope = i_sign(&c__9, islope);
    }
    beta = (*sumy - *islope / all_1.slfac * *sumx) / *nnb;
    *nolev1 = beta + (float).5;

/*   Check if any stems are too short */

    smin = (float)100.;
    iul = -1;
    if (*(unsigned char *)&all_1.ulq[commvl_1.ivx + ibc * 7 - 8] == 'u') {
	iul = 1;
    }
    i__1 = *nnb;
    for (inb = 1; inb <= i__1; ++inb) {
	ybeam = *nolev1 + iul * all_1.stemlen + *islope * xelsk[inb] / 
		all_1.slfac;
	ynote = (real) all_1.nolev[commvl_1.ivx + ipb[inb] * 7 - 8];
/* Computing MIN */
	r__1 = smin, r__2 = iul * (ybeam - ynote);
	smin = dmin(r__1,r__2);
/* L4: */
    }
    if (smin < all_1.stemmin) {
	deficit = all_1.stemmin - smin;
	nolevo = *nolev1;
	r__1 = *nolev1 + iul * deficit;
	*nolev1 = ni_(&r__1);
    }
    return 0;
} /* setbm2_ */


/*  meter space (pts) = xb4mbr = musicsize*facmtr */


integer ncmid_(iv, ip)
integer *iv, *ip;
{
    /* System generated locals */
    integer ret_val;

    /* Builtin functions */
    integer s_wsle(), do_lio(), e_wsle();
    /* Subroutine */ int s_stop();

    /* Local variables */
    static integer itime, icc;

    /* Fortran I/O blocks */
    static cilist io___744 = { 0, 6, 0, 0, 0 };


    if (comcc_1.ncc[*iv - 1] == 1) {
	ret_val = comcc_1.ncmidcc[*iv - 1];
    } else {
	itime = all_2.list[((255 & all_2.ipl[commvl_1.ivx + *ip * 7 - 8]) << 
		2) - 2];
	for (icc = comcc_1.ncc[*iv - 1]; icc >= 1; --icc) {
	    if (itime >= comcc_1.itcc[*iv + icc * 7 - 8]) {
		ret_val = comcc_1.ncmidcc[*iv + icc * 7 - 8];
		return ret_val;
	    }
/* L1: */
	}
	s_wsle(&io___744);
	do_lio(&c__9, &c__1, "Problem in ncmid()", 18L);
	e_wsle();
	s_stop("", 0L);
    }
    return ret_val;
} /* ncmid_ */

/*      subroutine defnotes(iemin,iemax) */
/* Subroutine */ int defnotes_(ieneed)
integer *ieneed;
{
    /* System generated locals */
    address a__1[2], a__2[4], a__3[3];
    integer i__1, i__2[2], i__3[4], i__4[3];
    real r__1;
    char ch__1[90];
    icilist ici__1;

    /* Builtin functions */
    integer pow_ii();
    /* Subroutine */ int s_cat();
    integer s_wsfi(), do_fio(), e_wsfi(), s_wsfe(), e_wsfe();

    /* Local variables */
    extern doublereal feon_();
    static real time;
    static integer index, lnote;
    static char notexq[79];

    /* Fortran I/O blocks */
    static cilist io___749 = { 0, 11, 0, "(a)", 0 };



/* note  64 .64  32 .32  16 .16  8  .8   4   .4   2  .2   0  .0  00 */
/* index 1   2   3   4   5   6   7   8   9   10  11  12  13  14  15 */
/* time  1   x   2   3   4   6   8   12  16  24  32  48  64  96 128 */

    for (index = 1; index <= 15; ++index) {
	if (bit_test(*ieneed,index)) {
	    if (index % 2 == 1) {
		i__1 = (index - 1) / 2;
		time = (real) pow_ii(&c__2, &i__1);
	    } else {
		i__1 = index / 2;
		time = (real) pow_ii(&c__2, &i__1) * (float).75;
	    }
/* Writing concatenation */
	    i__2[0] = 5, a__1[0] = "\\def\\";
	    i__2[1] = 6, a__1[1] = comstart_1.nstartq + (index - 1) * 6;
	    s_cat(notexq, a__1, i__2, &c__2, 79L);
	    lnote = comstart_1.lstart[index - 1] + 5;
/* Writing concatenation */
	    i__3[0] = lnote, a__2[0] = notexq;
	    i__3[1] = 1, a__2[1] = "{";
	    i__3[2] = 1, a__2[2] = "\\";
	    i__3[3] = 6, a__2[3] = "vnotes";
	    s_cat(notexq, a__2, i__3, &c__4, 79L);
	    lnote += 12;
	    i__1 = lnote - 4;
	    ici__1.icierr = 0;
	    ici__1.icirnum = 1;
	    ici__1.icirlen = lnote - i__1;
	    ici__1.iciunit = notexq + i__1;
	    ici__1.icifmt = "(f4.2)";
	    s_wsfi(&ici__1);
	    r__1 = feon_(&time);
	    do_fio(&c__1, (char *)&r__1, (ftnlen)sizeof(real));
	    e_wsfi();
	    s_wsfe(&io___749);
/* Writing concatenation */
	    i__4[0] = lnote, a__3[0] = notexq;
	    i__4[1] = 1, a__3[1] = "\\";
	    i__4[2] = 10, a__3[2] = "elemskip}%";
	    s_cat(ch__1, a__3, i__4, &c__3, 90L);
	    do_fio(&c__1, ch__1, lnote + 11);
	    e_wsfe();
	}
/* L2: */
    }
    return 0;
} /* defnotes_ */

/* Subroutine */ int clefsym_(isl, notexq, lnote, nclef, notexq_len)
integer *isl;
char *notexq;
integer *lnote, *nclef;
ftnlen notexq_len;
{
    /* System generated locals */
    address a__1[3];
    integer i__1[3];
    char ch__1[1], ch__2[1];

    /* Builtin functions */
    integer lbit_shift();
    /* Subroutine */ int s_cat();

    /* Local variables */
    static integer nlev;

    *nclef = lbit_shift(*isl, -12L) & 7;
    if (*nclef == 0) {
	nlev = 2;
    } else if (*nclef < 5) {
	nlev = (*nclef << 1) - 2;
    } else {
	nlev = (*nclef << 1) - 6;
    }
/* Writing concatenation */
    i__1[0] = 8, a__1[0] = "\\pmxclef";
    *(unsigned char *)&ch__1[0] = *nclef + 48;
    i__1[1] = 1, a__1[1] = ch__1;
    *(unsigned char *)&ch__2[0] = nlev + 48;
    i__1[2] = 1, a__1[2] = ch__2;
    s_cat(notexq, a__1, i__1, &c__3, notexq_len);
    *lnote = 10;
    return 0;
} /* clefsym_ */

/*     character*2 function acsymq(accq) */
/* Subroutine */ int accsym_(accq, acsymq, lacc, accq_len, acsymq_len)
char *accq, *acsymq;
integer *lacc;
ftnlen accq_len;
ftnlen acsymq_len;
{
    /* Builtin functions */
    /* Subroutine */ int s_copy();
    integer s_wsle(), do_lio(), e_wsle();

    /* Fortran I/O blocks */
    static cilist io___751 = { 0, 6, 0, 0, 0 };


    if (*(unsigned char *)accq == 'f' || *(unsigned char *)accq == 'F') {
	s_copy(acsymq, "fl", 3L, 2L);
	*lacc = 2;
    } else if (*(unsigned char *)accq == 's' || *(unsigned char *)accq == 'S')
	     {
	s_copy(acsymq, "sh", 3L, 2L);
	*lacc = 2;
    } else if (*(unsigned char *)accq == 'n' || *(unsigned char *)accq == 'N')
	     {
	s_copy(acsymq, "na", 3L, 2L);
	*lacc = 2;
    } else if (*(unsigned char *)accq == 'g' || *(unsigned char *)accq == 'G')
	     {
	s_copy(acsymq, "dfl", 3L, 3L);
	*lacc = 3;
    } else if (*(unsigned char *)accq == 't' || *(unsigned char *)accq == 'T')
	     {
	s_copy(acsymq, "dsh", 3L, 3L);
	*lacc = 3;
    } else {
	s_wsle(&io___751);
	do_lio(&c__9, &c__1, "bad accidental: ", 16L);
	do_lio(&c__9, &c__1, accq, 1L);
	e_wsle();
/*        stop */
    }
    return 0;
} /* accsym_ */

/* Subroutine */ int littex_(islur, nnl, iv, topmods, lineq, iccount, 
	lineq_len)
integer *islur, *nnl, *iv;
logical *topmods;
char *lineq;
integer *iccount;
ftnlen lineq_len;
{
    /* System generated locals */
    address a__1[2], a__2[3];
    integer i__1[2], i__2[3];
    char ch__1[129];
    olist o__1;

    /* Builtin functions */
    /* Subroutine */ int s_cat();
    integer s_wsfe(), do_fio(), e_wsfe(), f_open();

    /* Local variables */
    static char durq[1];
    static integer itype;
    extern /* Subroutine */ int getchar_();

    /* Fortran I/O blocks */
    static cilist io___754 = { 0, 11, 0, "(a)", 0 };
    static cilist io___755 = { 0, 16, 0, "(a)", 0 };


    /* Parameter adjustments */
    islur -= 8;

    /* Function Body */
    ++comgrace_1.nlit;
    comgrace_1.ivlit[comgrace_1.nlit - 1] = *iv;
    comgrace_1.iplit[comgrace_1.nlit - 1] = *nnl;
    itype = 1;
L17:
    getchar_(lineq, iccount, durq, 128L, 1L);
    if (*(unsigned char *)durq == '\\') {
	++itype;
	goto L17;
    }
/* Writing concatenation */
    i__1[0] = 1, a__1[0] = "\\";
    i__1[1] = 1, a__1[1] = durq;
    s_cat(comgrace_1.litq + (comgrace_1.nlit - 1 << 7), a__1, i__1, &c__2, 
	    128L);
    comgrace_1.lenlit[comgrace_1.nlit - 1] = 2;
L18:
    getchar_(lineq, iccount, durq, 128L, 1L);
    if (*(unsigned char *)durq == '\\') {
	getchar_(lineq, iccount, durq, 128L, 1L);
	if (*(unsigned char *)durq != ' ') {

/*  Starting a new tex command within the string */

/* Writing concatenation */
	    i__2[0] = comgrace_1.lenlit[comgrace_1.nlit - 1], a__2[0] = 
		    comgrace_1.litq + (comgrace_1.nlit - 1 << 7);
	    i__2[1] = 1, a__2[1] = "\\";
	    i__2[2] = 1, a__2[2] = durq;
	    s_cat(comgrace_1.litq + (comgrace_1.nlit - 1 << 7), a__2, i__2, &
		    c__3, 128L);
	    comgrace_1.lenlit[comgrace_1.nlit - 1] += 2;
	    goto L18;
	}
    } else {
/* Writing concatenation */
	i__1[0] = comgrace_1.lenlit[comgrace_1.nlit - 1], a__1[0] = 
		comgrace_1.litq + (comgrace_1.nlit - 1 << 7);
	i__1[1] = 1, a__1[1] = durq;
	s_cat(comgrace_1.litq + (comgrace_1.nlit - 1 << 7), a__1, i__1, &c__2,
		 128L);
	++comgrace_1.lenlit[comgrace_1.nlit - 1];
	goto L18;
    }

/*  If here, just read backslash-blank so string is done */

    if (itype == 1) {
	islur[*iv + *nnl * 7] = bit_set(islur[*iv + *nnl * 7],16);
    } else {
	if (itype == 3) {

/*  Write the string NOW */

	    s_wsfe(&io___754);
/* Writing concatenation */
	    i__1[0] = comgrace_1.lenlit[comgrace_1.nlit - 1], a__1[0] = 
		    comgrace_1.litq + (comgrace_1.nlit - 1 << 7);
	    i__1[1] = 1, a__1[1] = "%";
	    s_cat(ch__1, a__1, i__1, &c__2, 129L);
	    do_fio(&c__1, ch__1, comgrace_1.lenlit[comgrace_1.nlit - 1] + 1);
	    e_wsfe();
	} else {

/*  Must go at top */

	    if (! (*topmods)) {
		*topmods = TRUE_;
		o__1.oerr = 0;
		o__1.ounit = 16;
		o__1.ofnm = 0;
		o__1.orl = 0;
		o__1.osta = "SCRATCH";
		o__1.oacc = 0;
		o__1.ofm = 0;
		o__1.oblnk = 0;
		f_open(&o__1);
	    }
/*         write(16,'(a)')litq(nlit)(1:lenlit(nlit)) */

/*  Must write '%' here rather than later, in case string ends wit
h blank. */

	    s_wsfe(&io___755);
/* Writing concatenation */
	    i__1[0] = comgrace_1.lenlit[comgrace_1.nlit - 1], a__1[0] = 
		    comgrace_1.litq + (comgrace_1.nlit - 1 << 7);
	    i__1[1] = 1, a__1[1] = "%";
	    s_cat(ch__1, a__1, i__1, &c__2, 129L);
	    do_fio(&c__1, ch__1, comgrace_1.lenlit[comgrace_1.nlit - 1] + 1);
	    e_wsfe();
	}
	--comgrace_1.nlit;
    }
    return 0;
} /* littex_ */

/* Subroutine */ int putfig_(ifig, offnsk, figcheck, soutq, lsout, soutq_len)
integer *ifig;
real *offnsk;
logical *figcheck;
char *soutq;
integer *lsout;
ftnlen soutq_len;
{
    /* System generated locals */
    address a__1[2], a__2[3], a__3[6];
    integer i__1[2], i__2[3], i__3, i__4[6];
    real r__1;
    char ch__1[1], ch__2[12], ch__3[20], ch__4[19], ch__5[18], ch__6[17];

    /* Builtin functions */
    /* Subroutine */ int s_cat();
    integer s_wsfi(), do_fio(), e_wsfi();
    /* Subroutine */ int s_copy();

    /* Local variables */
    static integer nofa;
    static char figq[6];
    static integer lnof;
    static char nofq[2];
    static integer lnofa;
    static char nofaq[2];
    static integer lnote, ic;
    static char sq[1];
    extern /* Subroutine */ int addstr_();
    static char notexq[80];
    static integer nof;
    static char ch1q[1], ch2q[1];

    /* Fortran I/O blocks */
    static icilist io___758 = { 0, notexq+5, 0, "(f6.2)", 6, 1 };
    static icilist io___760 = { 0, notexq+5, 0, "(f5.2)", 5, 1 };
    static icilist io___761 = { 0, notexq+5, 0, "(f4.2)", 4, 1 };
    static icilist io___762 = { 0, notexq+5, 0, "(f3.2)", 3, 1 };
    static icilist io___773 = { 0, notexq+5, 0, "(f6.2)", 6, 1 };
    static icilist io___774 = { 0, notexq+5, 0, "(f5.2)", 5, 1 };
    static icilist io___775 = { 0, notexq+5, 0, "(f4.2)", 4, 1 };
    static icilist io___776 = { 0, notexq+5, 0, "(f3.2)", 3, 1 };


    *(unsigned char *)sq = '\\';
    if (dabs(*offnsk) > (float)1e-4) {

/*  Write offset for floating figure, to two decimal places */

/* Writing concatenation */
	i__1[0] = 1, a__1[0] = sq;
	i__1[1] = 4, a__1[1] = "off{";
	s_cat(notexq, a__1, i__1, &c__2, 80L);
/*          if (-offnsk .lt. -9.95) then */
/*            write(notexq(6:10),'(f5.1)')-offnsk */
/*            lnote = 10 */
/*          else if (-offnsk.lt.-.95 .or. -offnsk.gt.9.95) then */
/*            write(notexq(6:9),'(f4.1)')-offnsk */
/*            lnote = 9 */
/*          else if (-offnsk.lt.-.001 .or. -offnsk.gt..95) then */
/*            write(notexq(6:8),'(f3.1)')-offnsk */
/*            lnote = 8 */
/*          else */
/*            write(notexq(6:7),'(f2.1)')-offnsk */
/*            lnote = 7 */
	if (-(*offnsk) < (float)-9.995) {
	    s_wsfi(&io___758);
	    r__1 = -(*offnsk);
	    do_fio(&c__1, (char *)&r__1, (ftnlen)sizeof(real));
	    e_wsfi();
	    lnote = 11;
	} else if (-(*offnsk) < (float)-.995 || -(*offnsk) > (float)9.995) {
	    s_wsfi(&io___760);
	    r__1 = -(*offnsk);
	    do_fio(&c__1, (char *)&r__1, (ftnlen)sizeof(real));
	    e_wsfi();
	    lnote = 10;
	} else if (-(*offnsk) < (float)-1e-4 || -(*offnsk) > (float).995) {
	    s_wsfi(&io___761);
	    r__1 = -(*offnsk);
	    do_fio(&c__1, (char *)&r__1, (ftnlen)sizeof(real));
	    e_wsfi();
	    lnote = 9;
	} else {
	    s_wsfi(&io___762);
	    r__1 = -(*offnsk);
	    do_fio(&c__1, (char *)&r__1, (ftnlen)sizeof(real));
	    e_wsfi();
	    lnote = 8;
	}
/* Writing concatenation */
	i__2[0] = lnote, a__2[0] = notexq;
	i__2[1] = 1, a__2[1] = sq;
	i__2[2] = 9, a__2[2] = "noteskip}";
	s_cat(notexq, a__2, i__2, &c__3, 80L);
	i__3 = lnote + 10;
	addstr_(notexq, &i__3, soutq, lsout, 80L, 80L);
    }
    s_copy(figq, comfig_2.figqq + (*ifig - 1) * 6, 6L, 6L);
    ic = 1;
    nof = 0;
    nofa = -1;

/*  Beginning of loop */

L1:
    *(unsigned char *)ch1q = *(unsigned char *)&figq[ic - 1];

/*  Exit when first blank is encountered */

    if (*(unsigned char *)ch1q == ' ') {
	goto L2;
    }

/*  Just starting or not yet finished.  Set up vertical offset. */

    lnof = 1;
    *(unsigned char *)&ch__1[0] = nof + 48;
    s_copy(nofq, ch__1, 2L, 1L);
    if (nof > 9) {
	lnof = 2;
/* Writing concatenation */
	i__1[0] = 1, a__1[0] = "1";
	*(unsigned char *)&ch__1[0] = nof + 38;
	i__1[1] = 1, a__1[1] = ch__1;
	s_cat(nofq, a__1, i__1, &c__2, 2L);
    }
    if (nofa == -1) {
	lnofa = 2;
	s_copy(nofaq, "-1", 2L, 2L);
    } else if (nofa < 10) {
	lnofa = 1;
	*(unsigned char *)&ch__1[0] = nofa + 48;
	s_copy(nofaq, ch__1, 2L, 1L);
    } else {
	lnofa = 2;
/* Writing concatenation */
	i__1[0] = 1, a__1[0] = "1";
	*(unsigned char *)&ch__1[0] = nofa + 38;
	i__1[1] = 1, a__1[1] = ch__1;
	s_cat(nofaq, a__1, i__1, &c__2, 2L);
    }
    if (*(unsigned char *)ch1q == '0') {

/*  Continuation figure.  Next digit is length (in noteskips) */

	++ic;
	*(unsigned char *)ch2q = *(unsigned char *)&figq[ic - 1];
/* Writing concatenation */
	i__4[0] = 1, a__3[0] = sq;
	i__4[1] = 5, a__3[1] = "Cont{";
	i__4[2] = lnof, a__3[2] = nofq;
	i__4[3] = 2, a__3[3] = "}{";
	i__4[4] = 1, a__3[4] = ch2q;
	i__4[5] = 1, a__3[5] = "}";
	s_cat(ch__2, a__3, i__4, &c__6, 12L);
	i__3 = lnof + 10;
	addstr_(ch__2, &i__3, soutq, lsout, lnof + 10, 80L);
    } else if (*(unsigned char *)ch1q == '#' || *(unsigned char *)ch1q == '-' 
	    || *(unsigned char *)ch1q == 'n') {
	++ic;
	*(unsigned char *)ch2q = *(unsigned char *)&figq[ic - 1];
	if (*(unsigned char *)ch2q == ' ') {

/*  Figure is a stand-alone accidental, so must be centered */

	    if (*(unsigned char *)ch1q == '#') {
/* Writing concatenation */
		i__4[0] = 1, a__3[0] = sq;
		i__4[1] = 5, a__3[1] = "Figu{";
		i__4[2] = lnofa, a__3[2] = nofaq;
		i__4[3] = 2, a__3[3] = "}{";
		i__4[4] = 1, a__3[4] = sq;
		i__4[5] = 9, a__3[5] = "sharpfig}";
		s_cat(ch__3, a__3, i__4, &c__6, 20L);
		i__3 = lnofa + 18;
		addstr_(ch__3, &i__3, soutq, lsout, lnofa + 18, 80L);
	    } else if (*(unsigned char *)ch1q == '-') {
/* Writing concatenation */
		i__4[0] = 1, a__3[0] = sq;
		i__4[1] = 5, a__3[1] = "Figu{";
		i__4[2] = lnofa, a__3[2] = nofaq;
		i__4[3] = 2, a__3[3] = "}{";
		i__4[4] = 1, a__3[4] = sq;
		i__4[5] = 8, a__3[5] = "flatfig}";
		s_cat(ch__4, a__3, i__4, &c__6, 19L);
		i__3 = lnofa + 17;
		addstr_(ch__4, &i__3, soutq, lsout, lnofa + 17, 80L);
	    } else if (*(unsigned char *)ch1q == 'n') {
/* Writing concatenation */
		i__4[0] = 1, a__3[0] = sq;
		i__4[1] = 5, a__3[1] = "Figu{";
		i__4[2] = lnofa, a__3[2] = nofaq;
		i__4[3] = 2, a__3[3] = "}{";
		i__4[4] = 1, a__3[4] = sq;
		i__4[5] = 7, a__3[5] = "natfig}";
		s_cat(ch__5, a__3, i__4, &c__6, 18L);
		i__3 = lnofa + 16;
		addstr_(ch__5, &i__3, soutq, lsout, lnofa + 16, 80L);
	    }
	    goto L2;
	} else {

/*  Figure is an accidental followed by a number */
/*  First put the accidental (offset to the left) */

	    if (*(unsigned char *)ch1q == '#') {
/* Writing concatenation */
		i__4[0] = 1, a__3[0] = sq;
		i__4[1] = 5, a__3[1] = "Figu{";
		i__4[2] = lnofa, a__3[2] = nofaq;
		i__4[3] = 2, a__3[3] = "}{";
		i__4[4] = 1, a__3[4] = sq;
		i__4[5] = 6, a__3[5] = "fsmsh}";
		s_cat(ch__6, a__3, i__4, &c__6, 17L);
		i__3 = lnofa + 15;
		addstr_(ch__6, &i__3, soutq, lsout, lnofa + 15, 80L);
	    } else if (*(unsigned char *)ch1q == '-') {
/* Writing concatenation */
		i__4[0] = 1, a__3[0] = sq;
		i__4[1] = 5, a__3[1] = "Figu{";
		i__4[2] = lnofa, a__3[2] = nofaq;
		i__4[3] = 2, a__3[3] = "}{";
		i__4[4] = 1, a__3[4] = sq;
		i__4[5] = 6, a__3[5] = "fsmfl}";
		s_cat(ch__6, a__3, i__4, &c__6, 17L);
		i__3 = lnofa + 15;
		addstr_(ch__6, &i__3, soutq, lsout, lnofa + 15, 80L);
	    } else if (*(unsigned char *)ch1q == 'n') {
/* Writing concatenation */
		i__4[0] = 1, a__3[0] = sq;
		i__4[1] = 5, a__3[1] = "Figu{";
		i__4[2] = lnofa, a__3[2] = nofaq;
		i__4[3] = 2, a__3[3] = "}{";
		i__4[4] = 1, a__3[4] = sq;
		i__4[5] = 6, a__3[5] = "fsmna}";
		s_cat(ch__6, a__3, i__4, &c__6, 17L);
		i__3 = lnofa + 15;
		addstr_(ch__6, &i__3, soutq, lsout, lnofa + 15, 80L);
	    }

/*  Now put the number */

/* Writing concatenation */
	    i__4[0] = 1, a__3[0] = sq;
	    i__4[1] = 5, a__3[1] = "Figu{";
	    i__4[2] = lnof, a__3[2] = nofq;
	    i__4[3] = 2, a__3[3] = "}{";
	    i__4[4] = 1, a__3[4] = ch2q;
	    i__4[5] = 1, a__3[5] = "}";
	    s_cat(ch__2, a__3, i__4, &c__6, 12L);
	    i__3 = lnof + 10;
	    addstr_(ch__2, &i__3, soutq, lsout, lnof + 10, 80L);
	}
    } else if (*(unsigned char *)ch1q == '_') {

/*  Placeholder only (for lowering a figure).  Don't do anything! */

/*          call addstr(sq//'Figu{'//nofq(1:lnof)//'}{ }', */
/*     *           10+lnof,soutq,lsout) */
    } else {

/*  Figure is a single number */

/* Writing concatenation */
	i__4[0] = 1, a__3[0] = sq;
	i__4[1] = 5, a__3[1] = "Figu{";
	i__4[2] = lnof, a__3[2] = nofq;
	i__4[3] = 2, a__3[3] = "}{";
	i__4[4] = 1, a__3[4] = ch1q;
	i__4[5] = 1, a__3[5] = "}";
	s_cat(ch__2, a__3, i__4, &c__6, 12L);
	i__3 = lnof + 10;
	addstr_(ch__2, &i__3, soutq, lsout, lnof + 10, 80L);
    }
    if (ic >= 6) {
	goto L2;
    }
    ++ic;
    nof += 4;
    nofa += 4;
    goto L1;
L2:
    if (dabs(*offnsk) > (float)1e-4) {
/* Writing concatenation */
	i__1[0] = 1, a__1[0] = sq;
	i__1[1] = 4, a__1[1] = "off{";
	s_cat(notexq, a__1, i__1, &c__2, 80L);
/*        if (offnsk .lt. -9.95) then */
/*          write(notexq(6:10),'(f5.1)')offnsk */
/*          lnote = 10 */
/*        else if (offnsk.lt.-.95 .or. offnsk.gt.9.95) then */
/*          write(notexq(6:9),'(f4.1)')offnsk */
/*          lnote = 9 */
/*        else if (offnsk.lt.-.001 .or. offnsk.gt..95) then */
/*          write(notexq(6:8),'(f3.1)')offnsk */
/*          lnote = 8 */
/*        else */
/*          write(notexq(6:7),'(f2.1)')offnsk */
/*          lnote = 7 */
	if (*offnsk < (float)-9.995) {
	    s_wsfi(&io___773);
	    do_fio(&c__1, (char *)&(*offnsk), (ftnlen)sizeof(real));
	    e_wsfi();
	    lnote = 11;
	} else if (*offnsk < (float)-.995 || *offnsk > (float)9.995) {
	    s_wsfi(&io___774);
	    do_fio(&c__1, (char *)&(*offnsk), (ftnlen)sizeof(real));
	    e_wsfi();
	    lnote = 10;
	} else if (*offnsk < (float)-1e-4 || *offnsk > (float).995) {
	    s_wsfi(&io___775);
	    do_fio(&c__1, (char *)&(*offnsk), (ftnlen)sizeof(real));
	    e_wsfi();
	    lnote = 9;
	} else {
	    s_wsfi(&io___776);
	    do_fio(&c__1, (char *)&(*offnsk), (ftnlen)sizeof(real));
	    e_wsfi();
	    lnote = 8;
	}
/* Writing concatenation */
	i__2[0] = lnote, a__2[0] = notexq;
	i__2[1] = 1, a__2[1] = sq;
	i__2[2] = 9, a__2[2] = "noteskip}";
	s_cat(notexq, a__2, i__2, &c__3, 80L);
	i__3 = lnote + 10;
	addstr_(notexq, &i__3, soutq, lsout, 80L, 80L);
    }
    if (*ifig < comfig_2.nfigs) {
	++(*ifig);
    } else {
	comfig_2.nfigs = 0;
	*figcheck = FALSE_;
    }
    return 0;
} /* putfig_ */

/* Subroutine */ int writflot_(x, notexq, lenline, notexq_len)
real *x;
char *notexq;
integer *lenline;
ftnlen notexq_len;
{
    /* System generated locals */
    integer i__1;
    icilist ici__1;

    /* Builtin functions */
    integer s_wsfi(), do_fio(), e_wsfi();

    if (*x < (float).95) {
	i__1 = *lenline;
	ici__1.icierr = 0;
	ici__1.icirnum = 1;
	ici__1.icirlen = *lenline + 2 - i__1;
	ici__1.iciunit = notexq + i__1;
	ici__1.icifmt = "(f2.1)";
	s_wsfi(&ici__1);
	do_fio(&c__1, (char *)&(*x), (ftnlen)sizeof(real));
	e_wsfi();
	*lenline += 2;
    } else if (*x < (float)9.95) {
	i__1 = *lenline;
	ici__1.icierr = 0;
	ici__1.icirnum = 1;
	ici__1.icirlen = *lenline + 3 - i__1;
	ici__1.iciunit = notexq + i__1;
	ici__1.icifmt = "(f3.1)";
	s_wsfi(&ici__1);
	do_fio(&c__1, (char *)&(*x), (ftnlen)sizeof(real));
	e_wsfi();
	*lenline += 3;
    } else {
	i__1 = *lenline;
	ici__1.icierr = 0;
	ici__1.icirnum = 1;
	ici__1.icirlen = *lenline + 4 - i__1;
	ici__1.iciunit = notexq + i__1;
	ici__1.icifmt = "(f4.1)";
	s_wsfi(&ici__1);
	do_fio(&c__1, (char *)&(*x), (ftnlen)sizeof(real));
	e_wsfi();
	*lenline += 4;
    }
    return 0;
} /* writflot_ */

/* Subroutine */ int readmeter_(lineq, iccount, mtrnum, mtrden, lineq_len)
char *lineq;
integer *iccount, *mtrnum, *mtrden;
ftnlen lineq_len;
{
    /* System generated locals */
    address a__1[3];
    integer i__1, i__2[3];
    char ch__1[4], ch__2[1];
    icilist ici__1;

    /* Builtin functions */
    integer i_indx();
    /* Subroutine */ int s_cat();
    integer s_rsfi(), do_fio(), e_rsfi();

    /* Local variables */
    static char durq[1];
    static integer ns;
    extern /* Subroutine */ int getchar_();

    i__1 = *iccount;
    if (i_indx(lineq + i__1, "/", *iccount + 3 - i__1, 1L) == 0) {

/*  No slashes, so use old method */

	getchar_(lineq, iccount, durq, 128L, 1L);
	if (*(unsigned char *)durq == '-') {

/*  Negative numerator is used only to printed; signals vertical s
lash */

	    getchar_(lineq, iccount, durq, 128L, 1L);
	    *mtrnum = -(*(unsigned char *)durq - 48);
	} else if (*(unsigned char *)durq == 'o') {

/*  Numerator is EXACTLY 1 */

	    *mtrnum = 1;
	} else {
	    *mtrnum = *(unsigned char *)durq - 48;
	    if (*mtrnum == 1) {

/*  Numerator is >9 */

		getchar_(lineq, iccount, durq, 128L, 1L);
		*mtrnum = *(unsigned char *)durq - 38;
	    }
	}
	getchar_(lineq, iccount, durq, 128L, 1L);
	if (*(unsigned char *)durq == 'o') {
	    *mtrden = 1;
	} else {
	    *mtrden = *(unsigned char *)durq - 48;
	    if (*mtrden == 1) {
		getchar_(lineq, iccount, durq, 128L, 1L);
		*mtrden = *(unsigned char *)durq - 38;
	    }
	}
    } else {

/* Expect the form m[n1]/[n2]/[n3]/[n4] . Advance iccount by one from 
'/' or 'm'*/

	++(*iccount);
	ns = i_indx(lineq + (*iccount - 1), "/", 128 - (*iccount - 1), 1L);
	ici__1.icierr = 0;
	ici__1.iciend = 0;
	ici__1.icirnum = 1;
	ici__1.icirlen = *iccount + ns - 2 - (*iccount - 1);
	ici__1.iciunit = lineq + (*iccount - 1);
/* Writing concatenation */
	i__2[0] = 2, a__1[0] = "(i";
	*(unsigned char *)&ch__2[0] = ns + 48;
	i__2[1] = 1, a__1[1] = ch__2;
	i__2[2] = 1, a__1[2] = ")";
	ici__1.icifmt = (s_cat(ch__1, a__1, i__2, &c__3, 4L), ch__1);
	s_rsfi(&ici__1);
	do_fio(&c__1, (char *)&(*mtrnum), (ftnlen)sizeof(integer));
	e_rsfi();

/*  Reset iccount to start of second integer */

	*iccount += ns;

/*  There must be either a slash or a blank at pos'n 2 or 3 */

	ns = i_indx(lineq + (*iccount - 1), "/", 3L, 1L);
	if (ns == 0) {
	    ns = i_indx(lineq + (*iccount - 1), " ", 3L, 1L);
	}
	ici__1.icierr = 0;
	ici__1.iciend = 0;
	ici__1.icirnum = 1;
	ici__1.icirlen = *iccount + ns - 2 - (*iccount - 1);
	ici__1.iciunit = lineq + (*iccount - 1);
/* Writing concatenation */
	i__2[0] = 2, a__1[0] = "(i";
	*(unsigned char *)&ch__2[0] = ns + 48;
	i__2[1] = 1, a__1[1] = ch__2;
	i__2[2] = 1, a__1[2] = ")";
	ici__1.icifmt = (s_cat(ch__1, a__1, i__2, &c__3, 4L), ch__1);
	s_rsfi(&ici__1);
	do_fio(&c__1, (char *)&(*mtrden), (ftnlen)sizeof(integer));
	e_rsfi();

/*  Set iccount to last character used */

	*iccount = *iccount + ns - 1;
    }
    return 0;
} /* readmeter_ */

/* Subroutine */ int readnum_(lineq, iccount, durq, fnum, lineq_len, durq_len)
char *lineq;
integer *iccount;
char *durq;
real *fnum;
ftnlen lineq_len;
ftnlen durq_len;
{
    /* System generated locals */
    address a__1[3];
    integer i__1[3];
    char ch__1[27], ch__2[6], ch__3[1];
    icilist ici__1;

    /* Builtin functions */
    integer i_indx(), s_wsle();
    /* Subroutine */ int s_cat();
    integer do_lio(), e_wsle();
    /* Subroutine */ int s_stop();
    integer s_rsfi(), do_fio(), e_rsfi();

    /* Local variables */
    static integer i1, i2, icf;
    extern /* Subroutine */ int getchar_();

    /* Fortran I/O blocks */
    static cilist io___781 = { 0, 6, 0, 0, 0 };



/* This reads a number starting at position iccount.  Remember that on exi
t,*/
/*  getchar leaves iccount at the last character retrieved.  So must only 
*/
/*  call this routine *after* detecting a number or decimal. */
/*  On exit, durq is next character after end of number. */
    i1 = *iccount;
L1:
    getchar_(lineq, iccount, durq, 128L, 1L);
    if (i_indx("0123456789.", durq, 11L, 1L) > 0) {
	goto L1;
    }
    i2 = *iccount - 1;
    if (i2 < i1) {
	s_wsle(&io___781);
/* Writing concatenation */
	i__1[0] = 7, a__1[0] = "Found \"";
	i__1[1] = 1, a__1[1] = durq;
	i__1[2] = 19, a__1[2] = "\" instead of number";
	s_cat(ch__1, a__1, i__1, &c__3, 27L);
	do_lio(&c__9, &c__1, ch__1, 27L);
	e_wsle();
	s_stop("", 0L);
    }
    icf = i2 - i1 + 49;
    ici__1.icierr = 0;
    ici__1.iciend = 0;
    ici__1.icirnum = 1;
    ici__1.icirlen = i2 - (i1 - 1);
    ici__1.iciunit = lineq + (i1 - 1);
/* Writing concatenation */
    i__1[0] = 2, a__1[0] = "(f";
    *(unsigned char *)&ch__3[0] = icf;
    i__1[1] = 1, a__1[1] = ch__3;
    i__1[2] = 3, a__1[2] = ".0)";
    ici__1.icifmt = (s_cat(ch__2, a__1, i__1, &c__3, 6L), ch__2);
    s_rsfi(&ici__1);
    do_fio(&c__1, (char *)&(*fnum), (ftnlen)sizeof(real));
    e_rsfi();
    return 0;
} /* readnum_ */

/* Subroutine */ int dotrill_(iv, ip, iornq, noteq, lnoten, notexq, lnote, 
	noteq_len, notexq_len)
integer *iv, *ip, *iornq;
char *noteq;
integer *lnoten;
char *notexq;
integer *lnote;
ftnlen noteq_len;
ftnlen notexq_len;
{
    /* System generated locals */
    address a__1[3], a__2[2];
    integer i__1, i__2[3], i__3[2];
    char ch__1[6], ch__2[1];
    icilist ici__1;

    /* Builtin functions */
    integer s_wsle(), do_lio(), e_wsle();
    /* Subroutine */ int s_stop(), s_copy(), s_cat();
    integer s_wsfi(), do_fio(), e_wsfi();

    /* Local variables */
    static integer nfmt;
    static logical tronly;
    static integer itr;

    /* Fortran I/O blocks */
    static cilist io___784 = { 0, 6, 0, 0, 0 };


    i__1 = comtrill_1.ntrill;
    for (itr = 1; itr <= i__1; ++itr) {
	if (*iv == comtrill_1.ivtrill[itr - 1] && *ip == comtrill_1.iptrill[
		itr - 1]) {
	    goto L2;
	}
/* L1: */
    }
    s_wsle(&io___784);
    do_lio(&c__9, &c__1, "Problem in dotrill.  Call Dr. Don", 33L);
    e_wsle();
    s_stop("", 0L);
L2:
    tronly = comtrill_1.xnsktr[itr - 1] < (float).01;
    if (tronly) {
	s_copy(notexq, "\\zcharnote", 79L, 10L);
	*lnote = 10;
/*     else if (ornq .eq. 'T') then */
/* Bits 1-13: stmgx+Tupf._)  14: Down fermata, was F  15: Trill w/o "t
r", was U*/
    } else if (bit_test(*iornq,7)) {
	s_copy(notexq, "\\Trille", 79L, 7L);
	*lnote = 7;
    } else {
	s_copy(notexq, "\\trille", 79L, 7L);
	*lnote = 7;
    }
/* Writing concatenation */
    i__2[0] = *lnote, a__1[0] = notexq;
    i__2[1] = *lnoten, a__1[1] = noteq;
    i__2[2] = 1, a__1[2] = "{";
    s_cat(notexq, a__1, i__2, &c__3, 79L);
    *lnote = *lnote + *lnoten + 1;

/*  Write trill duration to nearest tenth of a noteskip */

    if (tronly) {
/* Writing concatenation */
	i__2[0] = *lnote, a__1[0] = notexq;
	i__2[1] = 1, a__1[1] = "\\";
	i__2[2] = 6, a__1[2] = "it tr}";
	s_cat(notexq, a__1, i__2, &c__3, 79L);
	*lnote += 7;
	return 0;
    }
    if (comtrill_1.xnsktr[itr - 1] < (float).95) {
	nfmt = 2;
    } else if (comtrill_1.xnsktr[itr - 1] < (float)9.95) {
	nfmt = 3;
    } else {
	nfmt = 4;
    }
    i__1 = *lnote;
    ici__1.icierr = 0;
    ici__1.icirnum = 1;
    ici__1.icirlen = *lnote + nfmt - i__1;
    ici__1.iciunit = notexq + i__1;
/* Writing concatenation */
    i__2[0] = 2, a__1[0] = "(f";
    *(unsigned char *)&ch__2[0] = nfmt + 48;
    i__2[1] = 1, a__1[1] = ch__2;
    i__2[2] = 3, a__1[2] = ".1)";
    ici__1.icifmt = (s_cat(ch__1, a__1, i__2, &c__3, 6L), ch__1);
    s_wsfi(&ici__1);
    do_fio(&c__1, (char *)&comtrill_1.xnsktr[itr - 1], (ftnlen)sizeof(real));
    e_wsfi();
    *lnote += nfmt;
/* Writing concatenation */
    i__3[0] = *lnote, a__2[0] = notexq;
    i__3[1] = 1, a__2[1] = "}";
    s_cat(notexq, a__2, i__3, &c__2, 79L);
    ++(*lnote);
    return 0;
} /* dotrill_ */

/* Subroutine */ int docrd_(ivx, ip, nodu, ncm, iv, itnow, soutq, lsout, ulq, 
	ibmcnt, islur, nvmx, nv, beamon, nolevm, ihornb, nornb, stemlen, 
	soutq_len, ulq_len)
integer *ivx, *ip, *nodu, *ncm, *iv, *itnow;
char *soutq;
integer *lsout;
char *ulq;
integer *ibmcnt, *islur, *nvmx, *nv;
logical *beamon;
integer *nolevm, *ihornb, *nornb;
real *stemlen;
ftnlen soutq_len;
ftnlen ulq_len;
{
    /* Initialized data */

    static char accstrq[13+1] = "naflshdfl dsh";

    /* System generated locals */
    address a__1[2], a__2[4];
    integer i__1, i__2, i__3[2], i__4[4];

    /* Builtin functions */
    integer lbit_shift(), pow_ii();
    /* Subroutine */ int s_copy(), s_cat();

    /* Local variables */
    static integer lacc;
    extern /* Subroutine */ int addblank_();
    static integer icrd, i2acc, lout, lsym;
    static char outq[79];
    extern integer igetbits_();
    static integer lnote, nolev;
    static char noteq[8];
    extern /* Subroutine */ int addstr_();
    static logical isleft;
    extern /* Subroutine */ int notefq_();
    static real updotc, rtdotc;
    static integer lnoten;
    extern /* Subroutine */ int dotmov_(), putarp_();
    static char notexq[79], nosymq[4];
    extern /* Subroutine */ int putorn_();
    static logical isright;
    extern /* Subroutine */ int setbits_();
    extern integer log2_();
    static integer iacc;

    /* Parameter adjustments */
    --nornb;
    ihornb -= 8;
    ulq -= 8;

    /* Function Body */

/* This subr. once produced notexq for entire chord.  10/18/97 altered to 
write*/
/*    chord notes as we go.  10/22/97 find range of icrd first. */
/*    2/25/98 moved rangefinding to precrd so done before slurs, so now */
/*    on entry, icrd1, icrd2 define range of icrd for this chord. */

    i__1 = comtrill_1.icrd2;
    for (icrd = comtrill_1.icrd1; icrd <= i__1; ++icrd) {
	lnote = 0;
	nolev = lbit_shift(comtrill_1.icrdat[icrd - 1], -12L) & 127;

/*  Lower dot for lower-voice notes?.  Conditions are: */
/*   1. Dotted time value */
/*   2. Lower voice of two */
/*   3. Note is on a line */
/*   4. Not a rest (cannot be a rest in a chord!) */
/* .  5. Flag (lowdot) is set to true */

	if (comarp_1.lowdot && *nvmx == 2 && *ivx <= *nv) {
	    i__2 = log2_(nodu);
	    if (pow_ii(&c__2, &i__2) != *nodu && (nolev - *ncm) % 2 == 0) {
		if (bit_test(comtrill_1.icrdat[icrd - 1],26)) {

/*  Note already in movdot list.  Drop by 2. */

		    i__2 = igetbits_(&comtrill_1.icrdot[icrd - 1], &c__7, &
			    c__0) - 20;
		    setbits_(&comtrill_1.icrdot[icrd - 1], &c__7, &c__0, &
			    i__2);
		} else {

/*  Not in list so just move it right now */

		    dotmov_(&c_b792, &c_b159, soutq, lsout, 80L);
		}
	    }
	}
	if (bit_test(comtrill_1.icrdat[icrd - 1],26)) {

/*  Move the dot. */

	    updotc = ((127 & comtrill_1.icrdot[icrd - 1]) - 64) * (float).1;
	    rtdotc = ((127 & lbit_shift(comtrill_1.icrdot[icrd - 1], -7L)) - 
		    64) * (float).1;
	    dotmov_(&updotc, &rtdotc, soutq, lsout, 80L);
	}
	isleft = bit_test(comtrill_1.icrdat[icrd - 1],23);
	isright = bit_test(comtrill_1.icrdat[icrd - 1],24);

/*  Check for ornament in chord. */

	if (comtrill_1.icrdorn[icrd - 1] > 0) {
	    putorn_(&comtrill_1.icrdorn[icrd - 1], &nolev, nolevm, nodu, &
		    nornb[1], ulq + 8, ibmcnt, ivx, ncm, islur, nvmx, nv, &
		    ihornb[8], stemlen, outq, &lout, ip, &c__0, beamon, &
		    c_true, 1L, 79L);

/*     subroutin putorn(iornq,nolev,nolevm,nodur,nornb,ulq,ibmcnt,
ivx, */
/*    *     ncm,islur,nvmx,nv,ihornb,stemlen,outq,lout,ip,islhgt, 
*/
/*    *     notcrd,beamon,iscrd) */

	    addstr_(outq, &lout, soutq, lsout, 79L, 80L);
	}

/*  Get first letters in chord-note symbol */

	if (isleft) {
	    s_copy(nosymq, "\\l", 4L, 2L);
	} else if (isright) {
	    s_copy(nosymq, "\\r", 4L, 2L);
	} else {
	    s_copy(nosymq, "\\z", 4L, 2L);
	}
	if (*nodu >= 64) {
/* Writing concatenation */
	    i__3[0] = 2, a__1[0] = nosymq;
	    i__3[1] = 1, a__1[1] = "w";
	    s_cat(nosymq, a__1, i__3, &c__2, 4L);
	} else if (*nodu >= 32) {
/* Writing concatenation */
	    i__3[0] = 2, a__1[0] = nosymq;
	    i__3[1] = 1, a__1[1] = "h";
	    s_cat(nosymq, a__1, i__3, &c__2, 4L);
	} else {
/* Writing concatenation */
	    i__3[0] = 2, a__1[0] = nosymq;
	    i__3[1] = 1, a__1[1] = "q";
	    s_cat(nosymq, a__1, i__3, &c__2, 4L);
	}
	i__2 = log2_(nodu);
	if (pow_ii(&c__2, &i__2) == *nodu) {
	    lsym = 3;
	} else {
/* Writing concatenation */
	    i__3[0] = 3, a__1[0] = nosymq;
	    i__3[1] = 1, a__1[1] = "p";
	    s_cat(nosymq, a__1, i__3, &c__2, 4L);
	    lsym = 4;
	}

/*  Check for accidental */

	if (bit_test(comtrill_1.icrdat[icrd - 1],19)) {

/*  Get note name */

	    notefq_(noteq, &lnoten, &nolev, ncm, 8L);
	    if (lnoten == 1) {
		addblank_(noteq, &lnoten, 8L);
	    }
	    iacc = (7 & lbit_shift(comtrill_1.icrdat[icrd - 1], -20L)) - 1;
	    if (iacc < 3) {
		lacc = 2;
	    } else {
		iacc = (iacc << 1) - 7;
		lacc = 3;
	    }
	    iacc = (iacc << 1) + 1;
	    i2acc = iacc + lacc - 1;
/* Writing concatenation */
	    i__4[0] = 1, a__2[0] = "\\";
	    i__4[1] = i2acc - (iacc - 1), a__2[1] = accstrq + (iacc - 1);
	    i__4[2] = lnoten, a__2[2] = noteq;
	    i__4[3] = 4, a__2[3] = nosymq;
	    s_cat(notexq, a__2, i__4, &c__4, 79L);
	    lnote = lacc + 1 + lnoten;
	} else {
	    s_copy(notexq, nosymq, 79L, 4L);
	}
	lnote += lsym;

/*  Get note name (again if accid, due to possible octave jump) */

	notefq_(noteq, &lnoten, &nolev, ncm, 8L);
	if (lnoten == 1) {
	    addblank_(noteq, &lnoten, 8L);
	}

/*  Put in note name */

/* Writing concatenation */
	i__3[0] = lnote, a__1[0] = notexq;
	i__3[1] = 8, a__1[1] = noteq;
	s_cat(notexq, a__1, i__3, &c__2, 79L);
	lnote += lnoten;
	if (bit_test(comtrill_1.icrdat[icrd - 1],25)) {

/*  Arpeggio signal */

	    putarp_(itnow, iv, &nolev, ncm, soutq, lsout, 80L);
	}
	addstr_(notexq, &lnote, soutq, lsout, 79L, 80L);
/* L5: */
    }
    return 0;
} /* docrd_ */

/* Subroutine */ int dograce_(ivx, ip, ptgr, soutq, lsout, ncm, acciq, ig, 
	ipl, farend, soutq_len, acciq_len)
integer *ivx, *ip;
real *ptgr;
char *soutq;
integer *lsout, *ncm;
char *acciq;
integer *ig, *ipl;
logical *farend;
ftnlen soutq_len;
ftnlen acciq_len;
{
    /* System generated locals */
    address a__1[2], a__2[3], a__3[4];
    integer i__1, i__2[2], i__3[3], i__4[4], i__5;
    real r__1;
    char ch__1[6], ch__2[2], ch__3[1], ch__4[5], ch__5[11], ch__6[7], ch__7[9]
	    , ch__8[15], ch__9[16], ch__10[26], ch__11[29], ch__12[87], 
	    ch__13[4], ch__14[13], ch__15[82], ch__16[3];
    icilist ici__1;

    /* Builtin functions */
    integer s_wsle(), do_lio(), e_wsle();
    /* Subroutine */ int s_stop(), s_cat();
    integer s_wsfi(), do_fio(), e_wsfi(), i_sign();

    /* Local variables */
    static integer lacc;
    static real beta;
    extern /* Subroutine */ int addblank_();
    extern integer igetbits_();
    static real sumx, sumy;
    static integer i__;
    static real x, y, delta, ptoff;
    static integer lnote;
    static char noteq[8];
    static real sumxx, sumxy, sumyy;
    static integer nolev1, mg;
    static real em;
    extern integer ni_();
    static char sq[1];
    static logical isgaft;
    extern /* Subroutine */ int accsym_(), addstr_();
    static integer islope;
    static logical iswaft;
    static char acsymq[3];
    extern /* Subroutine */ int notefq_();
    static integer lnoten, niptgr;
    static logical normsp;
    static char notexq[79];
    static integer ing, ngs;
    extern integer log2_();

    /* Fortran I/O blocks */
    static cilist io___809 = { 0, 6, 0, 0, 0 };
    static cilist io___812 = { 0, 6, 0, 0, 0 };
    static icilist io___815 = { 0, notexq, 0, "(i2)", 2, 1 };
    static cilist io___816 = { 0, 6, 0, 0, 0 };
    static icilist io___836 = { 0, notexq+18, 0, "(a1,f4.1)", 5, 1 };
    static icilist io___837 = { 0, notexq+18, 0, "(f4.1)", 4, 1 };
    static icilist io___839 = { 0, notexq+5, 0, "(f3.1)", 3, 1 };



/*  ip will be one LESS than current note, for way-after's before bar-end,
 */
/*    It is only used to find ig. */
/* ig is returned to makeabar in case there's a slur that needs to be ende
d*/

/*      common /comslur/ listslur,ndxslur(nm,2),upslur(nm,2) */
    /* Parameter adjustments */
    --ptgr;

    /* Function Body */
    *(unsigned char *)sq = '\\';
    isgaft = bit_test(*ipl,29);
    iswaft = bit_test(*ipl,31);
    normsp = ! isgaft;

/*  Find ig. */

    i__1 = comgrace_1.ngrace;
    for (*ig = 1; *ig <= i__1; ++(*ig)) {
	if (comgrace_1.ipg[*ig - 1] == *ip && comgrace_1.ivg[*ig - 1] == *ivx)
		 {
	    goto L121;
	}
/* L120: */
    }
    s_wsle(&io___809);
    do_lio(&c__9, &c__1, "Problem finding grace index in dograce", 38L);
    e_wsle();
    s_stop("", 0L);
L121:
    ngs = comgrace_1.ngstrt[*ig - 1];
    mg = comgrace_1.multg[*ig - 1];

/*  For way-after-graces at end of bar, must set the octave. */

    if (*farend) {
	comoct_1.noctup = 0;
	if (*ncm == 23) {
	    comoct_1.noctup = -2;
	}
    }
    if (comgrace_1.slurg[*ig - 1] && ! iswaft && ! isgaft) {
	if (comslur_1.listslur == 511) {
	    s_wsle(&io___812);
	    do_lio(&c__9, &c__1, "You defined the tenth slur, one too many!", 
		    41L);
	    e_wsle();
	    s_stop("1", 1L);
	}

/* Slur on fore-grace.  Get index of next slur not in use, starting fr
om 8 down.*/

	i__1 = 511 - comslur_1.listslur;
	comslur_1.ndxslur = log2_(&i__1);
    }
    if (comgrace_1.nng[*ig - 1] == 1) {

/*  Single grace. */

	if (normsp) {

/*  Anything but GA */

/* Writing concatenation */
	    i__2[0] = 1, a__1[0] = sq;
	    i__2[1] = 5, a__1[1] = "shlft";
	    s_cat(ch__1, a__1, i__2, &c__2, 6L);
	    addstr_(ch__1, &c__6, soutq, lsout, 6L, 80L);
	    niptgr = ni_(&ptgr[*ig]);
	    if (niptgr < 10) {
/* Writing concatenation */
		*(unsigned char *)&ch__3[0] = niptgr + 48;
		i__2[0] = 1, a__1[0] = ch__3;
		i__2[1] = 1, a__1[1] = "{";
		s_cat(ch__2, a__1, i__2, &c__2, 2L);
		addstr_(ch__2, &c__2, soutq, lsout, 2L, 80L);
	    } else if (niptgr < 100) {
		s_wsfi(&io___815);
		do_fio(&c__1, (char *)&niptgr, (ftnlen)sizeof(integer));
		e_wsfi();
/* Writing concatenation */
		i__3[0] = 1, a__2[0] = "{";
		i__3[1] = 2, a__2[1] = notexq;
		i__3[2] = 2, a__2[2] = "}{";
		s_cat(ch__4, a__2, i__3, &c__3, 5L);
		addstr_(ch__4, &c__5, soutq, lsout, 5L, 80L);
	    } else {
		s_wsle(&io___816);
		do_lio(&c__9, &c__1, "Call Dr. Don if you really want grace \
note group > 99 pt", 56L);
		e_wsle();
		s_stop("", 0L);
	    }
	} else {
/* Writing concatenation */
	    i__2[0] = 1, a__1[0] = sq;
	    i__2[1] = 10, a__1[1] = "gaft{1.5}{";
	    s_cat(ch__5, a__1, i__2, &c__2, 11L);
	    addstr_(ch__5, &c__11, soutq, lsout, 11L, 80L);

/*  GA.  Compute aftshft, for later use. */

	    comgrace_1.aftshft = spfacs_1.grafac;
	    if (*(unsigned char *)&comgrace_1.accgq[comgrace_1.ngstrt[*ig - 1]
		     - 1] != 'x') {
		comgrace_1.aftshft += spfacs_1.agc1fac;
	    }
	    comgrace_1.aftshft *= comask_1.wheadpt;
	}
	if (comgrace_1.slurg[*ig - 1] && ! isgaft && ! iswaft) {

/* Start slur on pre-grace.  No accounting needed since will be en
ded very soon.*/

	    notefq_(noteq, &lnoten, &comgrace_1.nolevg[ngs - 1], ncm, 8L);
	    if (comgrace_1.upg[*ig - 1]) {
/* Writing concatenation */
		i__2[0] = 1, a__1[0] = sq;
		i__2[1] = 6, a__1[1] = "islurd";
		s_cat(ch__6, a__1, i__2, &c__2, 7L);
		addstr_(ch__6, &c__7, soutq, lsout, 7L, 80L);
	    } else {
/* Writing concatenation */
		i__2[0] = 1, a__1[0] = sq;
		i__2[1] = 6, a__1[1] = "isluru";
		s_cat(ch__6, a__1, i__2, &c__2, 7L);
		addstr_(ch__6, &c__7, soutq, lsout, 7L, 80L);
	    }
/* Writing concatenation */
	    *(unsigned char *)&ch__3[0] = comslur_1.ndxslur + 48;
	    i__2[0] = 1, a__1[0] = ch__3;
	    i__2[1] = lnoten, a__1[1] = noteq;
	    s_cat(ch__7, a__1, i__2, &c__2, 9L);
	    i__1 = lnoten + 1;
	    addstr_(ch__7, &i__1, soutq, lsout, lnoten + 1, 80L);
	}
	if (*(unsigned char *)&comgrace_1.accgq[ngs - 1] != 'x') {
	    notefq_(noteq, &lnoten, &comgrace_1.nolevg[ngs - 1], ncm, 8L);
	    if (lnoten == 1) {
		addblank_(noteq, &lnoten, 8L);
	    }
	    accsym_(comgrace_1.accgq + (ngs - 1), acsymq, &lacc, 1L, 3L);
/* Writing concatenation */
	    i__4[0] = 1, a__3[0] = sq;
	    i__4[1] = 3, a__3[1] = "big";
	    i__4[2] = lacc, a__3[2] = acsymq;
	    i__4[3] = lnoten, a__3[3] = noteq;
	    s_cat(ch__8, a__3, i__4, &c__4, 15L);
	    i__1 = lacc + 4 + lnoten;
	    addstr_(ch__8, &i__1, soutq, lsout, lacc + 4 + lnoten, 80L);
	}
	if (comgrace_1.slashg[*ig - 1]) {
/* Writing concatenation */
	    i__2[0] = 1, a__1[0] = sq;
	    i__2[1] = 3, a__1[1] = "grc";
	    s_cat(notexq, a__1, i__2, &c__2, 79L);
	    lnote = 4;
	} else if (mg == 0) {
/* Writing concatenation */
	    i__2[0] = 1, a__1[0] = sq;
	    i__2[1] = 2, a__1[1] = "zq";
	    s_cat(notexq, a__1, i__2, &c__2, 79L);
	    lnote = 3;
	} else {
/* Writing concatenation */
	    i__2[0] = 1, a__1[0] = sq;
	    i__2[1] = 2, a__1[1] = "zc";
	    s_cat(notexq, a__1, i__2, &c__2, 79L);
	    i__1 = mg;
	    for (i__ = 2; i__ <= i__1; ++i__) {
/* Writing concatenation */
		i__2[0] = i__ + 1, a__1[0] = notexq;
		i__2[1] = 1, a__1[1] = "c";
		s_cat(notexq, a__1, i__2, &c__2, 79L);
/* L61: */
	    }
	    lnote = mg + 2;
	}
	if (comgrace_1.upg[*ig - 1]) {
/* Writing concatenation */
	    i__2[0] = lnote, a__1[0] = notexq;
	    i__2[1] = 1, a__1[1] = "u";
	    s_cat(notexq, a__1, i__2, &c__2, 79L);
	} else {
/* Writing concatenation */
	    i__2[0] = lnote, a__1[0] = notexq;
	    i__2[1] = 1, a__1[1] = "l";
	    s_cat(notexq, a__1, i__2, &c__2, 79L);
	}
	i__1 = lnote + 1;
	addstr_(notexq, &i__1, soutq, lsout, 79L, 80L);
	notefq_(noteq, &lnoten, &comgrace_1.nolevg[ngs - 1], ncm, 8L);
	if (lnoten == 1) {
	    addblank_(noteq, &lnoten, 8L);
	}
	addstr_(noteq, &lnoten, soutq, lsout, 8L, 80L);
	if (comgrace_1.slashg[*ig - 1]) {
/* Writing concatenation */
	    i__4[0] = 1, a__3[0] = sq;
	    i__4[1] = 5, a__3[1] = "off{-";
	    i__4[2] = 1, a__3[2] = sq;
	    i__4[3] = 9, a__3[3] = "noteskip}";
	    s_cat(ch__9, a__3, i__4, &c__4, 16L);
	    addstr_(ch__9, &c__16, soutq, lsout, 16L, 80L);
	}

/*  Above code needed since slashg causes spacing */

	if (comgrace_1.slurg[*ig - 1] && (iswaft || isgaft)) {

/*  Terminate slur on single after-grace */

	    comslur_1.ndxslur = igetbits_(ipl, &c__4, &c__23);
	    notefq_(noteq, &lnoten, &comgrace_1.nolevg[ngs - 1], ncm, 8L);
/* Writing concatenation */
	    i__2[0] = 1, a__1[0] = sq;
	    i__2[1] = 5, a__1[1] = "tslur";
	    s_cat(ch__1, a__1, i__2, &c__2, 6L);
	    addstr_(ch__1, &c__6, soutq, lsout, 6L, 80L);
/* Writing concatenation */
	    *(unsigned char *)&ch__3[0] = comslur_1.ndxslur + 48;
	    i__2[0] = 1, a__1[0] = ch__3;
	    i__2[1] = lnoten, a__1[1] = noteq;
	    s_cat(ch__7, a__1, i__2, &c__2, 9L);
	    i__1 = lnoten + 1;
	    addstr_(ch__7, &i__1, soutq, lsout, lnoten + 1, 80L);
	    comgrace_1.slurg[*ig - 1] = FALSE_;
	    comslur_1.listslur = bit_clear(comslur_1.listslur,
		    comslur_1.ndxslur);
	}
	addstr_("}", &c__1, soutq, lsout, 1L, 80L);
    } else {

/*  Multiple grace.  Put in literally.  Compute beam stuff */

	sumx = (float)0.;
	sumy = (float)0.;
	sumxy = (float)0.;
	sumxx = (float)0.;
	sumyy = (float)0.;
	x = (float)0.;
	i__1 = ngs + comgrace_1.nng[*ig - 1] - 1;
	for (ing = ngs; ing <= i__1; ++ing) {
	    if (ing > ngs && *(unsigned char *)&comgrace_1.accgq[ing - 1] != 
		    'x') {
		x += spfacs_1.acgfac;
	    }
	    y = (real) comgrace_1.nolevg[ing - 1];
	    sumx += x;
	    sumy += y;
	    sumxy += x * y;
	    sumxx += x * x;
	    sumyy += y * y;
	    x += spfacs_1.emgfac;
/* L118: */
	}
	delta = comgrace_1.nng[*ig - 1] * sumxx - sumx * sumx;
	em = (comgrace_1.nng[*ig - 1] * sumxy - sumx * sumy) / delta;
	r__1 = em * (float).5 * spfacs_1.gslfac;
	islope = ni_(&r__1);
	if (abs(islope) > 9) {
	    islope = i_sign(&c__9, &islope);
	}
	beta = (sumy - islope / spfacs_1.gslfac * sumx) / comgrace_1.nng[*ig 
		- 1];
	nolev1 = beta + (float).5;

/*  Back up */

/* Writing concatenation */
	i__4[0] = 1, a__3[0] = sq;
	i__4[1] = 12, a__3[1] = "tinynotesize";
	i__4[2] = 1, a__3[2] = sq;
	i__4[3] = 4, a__3[3] = "off{";
	s_cat(notexq, a__3, i__4, &c__4, 79L);
	if (normsp) {
	    s_wsfi(&io___836);
	    do_fio(&c__1, "-", 1L);
	    do_fio(&c__1, (char *)&ptgr[*ig], (ftnlen)sizeof(real));
	    e_wsfi();
/* Writing concatenation */
	    i__2[0] = 23, a__1[0] = notexq;
	    i__2[1] = 3, a__1[1] = "pt}";
	    s_cat(ch__10, a__1, i__2, &c__2, 26L);
	    addstr_(ch__10, &c__26, soutq, lsout, 26L, 80L);
	} else {
	    comgrace_1.aftshft = comask_1.wheadpt * (float)1.33;
	    if (*(unsigned char *)&comgrace_1.accgq[comgrace_1.ngstrt[*ig - 1]
		     - 1] != 'x') {
		comgrace_1.aftshft += comask_1.wheadpt * (float).5;
	    }
	    s_wsfi(&io___837);
	    do_fio(&c__1, (char *)&comgrace_1.aftshft, (ftnlen)sizeof(real));
	    e_wsfi();
/* Writing concatenation */
	    i__4[0] = 22, a__3[0] = notexq;
	    i__4[1] = 3, a__3[1] = "pt}";
	    i__4[2] = 1, a__3[2] = sq;
	    i__4[3] = 3, a__3[3] = "bsk";
	    s_cat(ch__11, a__3, i__4, &c__4, 29L);
	    addstr_(ch__11, &c__29, soutq, lsout, 29L, 80L);
	}

/*  Start the beam */

/* Writing concatenation */
	i__2[0] = 1, a__1[0] = sq;
	i__2[1] = 2, a__1[1] = "ib";
	s_cat(notexq, a__1, i__2, &c__2, 79L);
	i__1 = mg;
	for (ing = 2; ing <= i__1; ++ing) {
/* Writing concatenation */
	    i__2[0] = ing + 1, a__1[0] = notexq;
	    i__2[1] = 1, a__1[1] = "b";
	    s_cat(notexq, a__1, i__2, &c__2, 79L);
/* L119: */
	}
	if (comgrace_1.upg[*ig - 1]) {
/* Writing concatenation */
	    i__2[0] = mg + 2, a__1[0] = notexq;
	    i__2[1] = 1, a__1[1] = "u";
	    s_cat(notexq, a__1, i__2, &c__2, 79L);
	} else {
/* Writing concatenation */
	    i__2[0] = mg + 2, a__1[0] = notexq;
	    i__2[1] = 1, a__1[1] = "l";
	    s_cat(notexq, a__1, i__2, &c__2, 79L);
	}
/* Writing concatenation */
	i__2[0] = mg + 3, a__1[0] = notexq;
	i__2[1] = 1, a__1[1] = "0";
	s_cat(notexq, a__1, i__2, &c__2, 79L);

/*  Get starting note for beam */

	notefq_(noteq, &lnoten, &nolev1, ncm, 8L);
/* Writing concatenation */
	i__2[0] = mg + 4, a__1[0] = notexq;
	i__2[1] = lnoten, a__1[1] = noteq;
	s_cat(ch__12, a__1, i__2, &c__2, 87L);
	i__1 = mg + 4 + lnoten;
	addstr_(ch__12, &i__1, soutq, lsout, mg + 4 + lnoten, 80L);

/*  Put in the slope */

	if (islope >= 0) {
	    *(unsigned char *)&ch__3[0] = islope + 48;
	    addstr_(ch__3, &c__1, soutq, lsout, 1L, 80L);
	} else {
/* Writing concatenation */
	    i__3[0] = 2, a__2[0] = "{-";
	    *(unsigned char *)&ch__3[0] = 48 - islope;
	    i__3[1] = 1, a__2[1] = ch__3;
	    i__3[2] = 1, a__2[2] = "}";
	    s_cat(ch__13, a__2, i__3, &c__3, 4L);
	    addstr_(ch__13, &c__4, soutq, lsout, 4L, 80L);
	}

/*  Start a slur on fore-grace */

	if (comgrace_1.slurg[*ig - 1] && ! isgaft && ! iswaft) {
	    notefq_(noteq, &lnoten, &comgrace_1.nolevg[ngs - 1], ncm, 8L);
	    if (comgrace_1.upg[*ig - 1]) {
/* Writing concatenation */
		i__2[0] = 1, a__1[0] = sq;
		i__2[1] = 6, a__1[1] = "islurd";
		s_cat(ch__6, a__1, i__2, &c__2, 7L);
		addstr_(ch__6, &c__7, soutq, lsout, 7L, 80L);
	    } else {
/* Writing concatenation */
		i__2[0] = 1, a__1[0] = sq;
		i__2[1] = 6, a__1[1] = "isluru";
		s_cat(ch__6, a__1, i__2, &c__2, 7L);
		addstr_(ch__6, &c__7, soutq, lsout, 7L, 80L);
	    }
/* Writing concatenation */
	    *(unsigned char *)&ch__3[0] = comslur_1.ndxslur + 48;
	    i__2[0] = 1, a__1[0] = ch__3;
	    i__2[1] = lnoten, a__1[1] = noteq;
	    s_cat(ch__7, a__1, i__2, &c__2, 9L);
	    i__1 = lnoten + 1;
	    addstr_(ch__7, &i__1, soutq, lsout, lnoten + 1, 80L);
	}

/*  Put in first note.  Call notefq again in case octave changed */

	notefq_(noteq, &lnoten, &comgrace_1.nolevg[ngs - 1], ncm, 8L);
	if (*(unsigned char *)&comgrace_1.accgq[ngs - 1] == 'x') {
/* Writing concatenation */
	    i__3[0] = 1, a__2[0] = sq;
	    i__3[1] = 4, a__2[1] = "zqb0";
	    i__3[2] = lnoten, a__2[2] = noteq;
	    s_cat(notexq, a__2, i__3, &c__3, 79L);
	    lnote = lnoten + 5;
	} else {
	    if (lnoten == 1) {
		addblank_(noteq, &lnoten, 8L);
	    }
	    accsym_(comgrace_1.accgq + (ngs - 1), acsymq, &lacc, 1L, 3L);
/* Writing concatenation */
	    i__4[0] = 1, a__3[0] = sq;
	    i__4[1] = 3, a__3[1] = "big";
	    i__4[2] = lacc, a__3[2] = acsymq;
	    i__4[3] = lnoten, a__3[3] = noteq;
	    s_cat(notexq, a__3, i__4, &c__4, 79L);
	    lnote = lacc + 4 + lnoten;
	    notefq_(noteq, &lnoten, &comgrace_1.nolevg[ngs - 1], ncm, 8L);
/* Writing concatenation */
	    i__4[0] = lnote, a__3[0] = notexq;
	    i__4[1] = 1, a__3[1] = sq;
	    i__4[2] = 4, a__3[2] = "zqb0";
	    i__4[3] = lnoten, a__3[3] = noteq;
	    s_cat(notexq, a__3, i__4, &c__4, 79L);
	    lnote = lnote + 5 + lnoten;
	}
	addstr_(notexq, &lnote, soutq, lsout, 79L, 80L);
	i__1 = ngs + comgrace_1.nng[*ig - 1] - 1;
	for (ing = ngs + 1; ing <= i__1; ++ing) {

/*  Skip */

	    ptoff = comask_1.wheadpt * spfacs_1.emgfac;
	    if (*(unsigned char *)&comgrace_1.accgq[ing - 1] != 'x') {
		ptoff += comask_1.wheadpt * spfacs_1.acgfac;
	    }
	    if (isgaft && ! iswaft) {
		comgrace_1.aftshft += ptoff;
	    }
/* Writing concatenation */
	    i__2[0] = 1, a__1[0] = sq;
	    i__2[1] = 4, a__1[1] = "off{";
	    s_cat(notexq, a__1, i__2, &c__2, 79L);
	    s_wsfi(&io___839);
	    do_fio(&c__1, (char *)&ptoff, (ftnlen)sizeof(real));
	    e_wsfi();
/* Writing concatenation */
	    i__2[0] = 8, a__1[0] = notexq;
	    i__2[1] = 3, a__1[1] = "pt}";
	    s_cat(ch__5, a__1, i__2, &c__2, 11L);
	    addstr_(ch__5, &c__11, soutq, lsout, 11L, 80L);
	    if (ing == ngs + comgrace_1.nng[*ig - 1] - 1) {

/*  Terminate beam if needed */

		if (comgrace_1.upg[*ig - 1]) {
/* Writing concatenation */
		    i__2[0] = 1, a__1[0] = sq;
		    i__2[1] = 4, a__1[1] = "tbu0";
		    s_cat(ch__4, a__1, i__2, &c__2, 5L);
		    addstr_(ch__4, &c__5, soutq, lsout, 5L, 80L);
		} else {
/* Writing concatenation */
		    i__2[0] = 1, a__1[0] = sq;
		    i__2[1] = 4, a__1[1] = "tbl0";
		    s_cat(ch__4, a__1, i__2, &c__2, 5L);
		    addstr_(ch__4, &c__5, soutq, lsout, 5L, 80L);
		}

/*  Terminate after slur if needed */

		if ((isgaft || iswaft) && comgrace_1.slurg[*ig - 1]) {
		    if (iswaft) {
			comslur_1.ndxslur = igetbits_(ipl, &c__4, &c__23);
		    }
		    notefq_(noteq, &lnoten, &comgrace_1.nolevg[ing - 1], ncm, 
			    8L);
/* Writing concatenation */
		    i__2[0] = 1, a__1[0] = sq;
		    i__2[1] = 5, a__1[1] = "tslur";
		    s_cat(ch__1, a__1, i__2, &c__2, 6L);
		    addstr_(ch__1, &c__6, soutq, lsout, 6L, 80L);
/* Writing concatenation */
		    *(unsigned char *)&ch__3[0] = comslur_1.ndxslur + 48;
		    i__2[0] = 1, a__1[0] = ch__3;
		    i__2[1] = lnoten, a__1[1] = noteq;
		    s_cat(ch__7, a__1, i__2, &c__2, 9L);
		    i__5 = lnoten + 1;
		    addstr_(ch__7, &i__5, soutq, lsout, lnoten + 1, 80L);

/*  Stop slur terminator after exit from this subroutine 
*/

		    if (iswaft) {
			comslur_1.listslur = bit_clear(comslur_1.listslur,
				comslur_1.ndxslur);
		    }
		    comgrace_1.slurg[*ig - 1] = FALSE_;
		}
	    }

/*  Accidental if needed */

	    if (*(unsigned char *)&comgrace_1.accgq[ing - 1] != 'x') {
		notefq_(noteq, &lnoten, &comgrace_1.nolevg[ing - 1], ncm, 8L);
		if (lnoten == 1) {
		    addblank_(noteq, &lnoten, 8L);
		}
		accsym_(comgrace_1.accgq + (ing - 1), acsymq, &lacc, 1L, 3L);
/* Writing concatenation */
		i__4[0] = 1, a__3[0] = sq;
		i__4[1] = 3, a__3[1] = "big";
		i__4[2] = lacc, a__3[2] = acsymq;
		i__4[3] = lnoten, a__3[3] = noteq;
		s_cat(ch__8, a__3, i__4, &c__4, 15L);
		i__5 = lacc + 4 + lnoten;
		addstr_(ch__8, &i__5, soutq, lsout, lacc + 4 + lnoten, 80L);
	    }

/*  Put in the (beamed) grace note */

	    notefq_(noteq, &lnoten, &comgrace_1.nolevg[ing - 1], ncm, 8L);
/* Writing concatenation */
	    i__3[0] = 1, a__2[0] = sq;
	    i__3[1] = 4, a__2[1] = "zqb0";
	    i__3[2] = lnoten, a__2[2] = noteq;
	    s_cat(ch__14, a__2, i__3, &c__3, 13L);
	    i__5 = lnoten + 5;
	    addstr_(ch__14, &i__5, soutq, lsout, lnoten + 5, 80L);
/* L127: */
	}

/*  Terminate the grace */

/* Writing concatenation */
	i__4[0] = 1, a__3[0] = sq;
	i__4[1] = 14, a__3[1] = "normalnotesize";
	i__4[2] = 1, a__3[2] = sq;
	i__4[3] = 4, a__3[3] = "off{";
	s_cat(notexq, a__3, i__4, &c__4, 79L);
	lnote = 20;
	ptoff = comask_1.wheadpt * spfacs_1.emgfac;
	if (*(unsigned char *)acciq != 'x') {
	    ptoff += comask_1.wheadpt * spfacs_1.accfac;
	}
/*       if (isgaft) then */
	if (isgaft && ! iswaft) {
/* Writing concatenation */
	    i__2[0] = 20, a__1[0] = notexq;
	    i__2[1] = 1, a__1[1] = "-";
	    s_cat(notexq, a__1, i__2, &c__2, 79L);
	    lnote = 21;
	    ptoff = comgrace_1.aftshft;
	}
	if (ptoff < (float)9.95) {
/*         write(notexq(21:23),'(f3.1)')ptoff */
	    i__1 = lnote;
	    ici__1.icierr = 0;
	    ici__1.icirnum = 1;
	    ici__1.icirlen = lnote + 3 - i__1;
	    ici__1.iciunit = notexq + i__1;
	    ici__1.icifmt = "(f3.1)";
	    s_wsfi(&ici__1);
	    do_fio(&c__1, (char *)&ptoff, (ftnlen)sizeof(real));
	    e_wsfi();
	    lnote += 3;
	} else {
/*         write(notexq(21:24),'(f4.1)')ptoff */
	    i__1 = lnote;
	    ici__1.icierr = 0;
	    ici__1.icirnum = 1;
	    ici__1.icirlen = lnote + 4 - i__1;
	    ici__1.iciunit = notexq + i__1;
	    ici__1.icifmt = "(f4.1)";
	    s_wsfi(&ici__1);
	    do_fio(&c__1, (char *)&ptoff, (ftnlen)sizeof(real));
	    e_wsfi();
	    lnote += 4;
	}
/* Writing concatenation */
	i__2[0] = lnote, a__1[0] = notexq;
	i__2[1] = 3, a__1[1] = "pt}";
	s_cat(ch__15, a__1, i__2, &c__2, 82L);
	i__1 = lnote + 3;
	addstr_(ch__15, &i__1, soutq, lsout, lnote + 3, 80L);
	if (isgaft && ! iswaft) {
/* Writing concatenation */
	    i__2[0] = 1, a__1[0] = sq;
	    i__2[1] = 2, a__1[1] = "sk";
	    s_cat(ch__16, a__1, i__2, &c__2, 3L);
	    addstr_(ch__16, &c__3, soutq, lsout, 3L, 80L);
	}
    }
    return 0;
} /* dograce_ */

/* Subroutine */ int wsclef_(iv, nv, noinst, clefq, nclef, clefq_len)
integer *iv, *nv, *noinst;
char *clefq;
integer *nclef;
ftnlen clefq_len;
{
    /* System generated locals */
    address a__1[2], a__2[3];
    integer i__1, i__2[2], i__3[3];
    char ch__1[1], ch__2[11], ch__3[22];

    /* Builtin functions */
    integer s_wsle(), e_wsle(), do_lio();
    /* Subroutine */ int s_stop(), s_cat();
    integer s_wsfe(), do_fio(), e_wsfe();

    /* Local variables */
    static integer ltem;
    static char temq[20];
    static integer iinst, iv1, iv2, iiv;
    extern integer numclef_();

    /* Fortran I/O blocks */
    static cilist io___843 = { 0, 6, 0, 0, 0 };
    static cilist io___844 = { 0, 6, 0, 0, 0 };
    static cilist io___846 = { 0, 11, 0, "(a)", 0 };
    static cilist io___849 = { 0, 11, 0, "(a)", 0 };



/*  \setclef for instrument containing voice iv */

    /* Parameter adjustments */
    --clefq;

    /* Function Body */
    *(unsigned char *)&clefq[*iv] = (char) (*nclef + 48);
    if (*noinst > 0) {

/*  The old way.  Only inst #1 can have >1 voice */

	if (*nv == *noinst || *iv > *nv - *noinst + 1) {
	    iinst = *iv + *noinst - *nv;
	    iv1 = *iv;
	    iv2 = *iv;
	} else {
	    iinst = 1;
	    iv1 = 1;
	    iv2 = *nv - *noinst + 1;
	}
    } else {

/*  The new way. */

	iv1 = 1;
	i__1 = -(*noinst);
	for (iinst = 1; iinst <= i__1; ++iinst) {
	    if (*iv < iv1 + comnvi_1.nvi[iinst - 1]) {
		goto L2;
	    }
	    iv1 += comnvi_1.nvi[iinst - 1];
/* L1: */
	}
	s_wsle(&io___843);
	e_wsle();
	s_wsle(&io___844);
	do_lio(&c__9, &c__1, "Should not be here in wsclef!", 29L);
	e_wsle();
	s_stop("1", 1L);
L2:
	iv2 = iv1 + comnvi_1.nvi[iinst - 1] - 1;
    }
/* Writing concatenation */
    i__2[0] = 8, a__1[0] = "\\setclef";
    *(unsigned char *)&ch__1[0] = iinst + 48;
    i__2[1] = 1, a__1[1] = ch__1;
    s_cat(temq, a__1, i__2, &c__2, 20L);
    if (iv1 == iv2) {
	s_wsfe(&io___846);
/* Writing concatenation */
	i__3[0] = 9, a__2[0] = temq;
	i__3[1] = 1, a__2[1] = clefq + *iv;
	i__3[2] = 1, a__2[2] = "%";
	s_cat(ch__2, a__2, i__3, &c__3, 11L);
	do_fio(&c__1, ch__2, 11L);
	e_wsfe();
    } else {
/* Writing concatenation */
	i__2[0] = 9, a__1[0] = temq;
	i__2[1] = 1, a__1[1] = "{";
	s_cat(temq, a__1, i__2, &c__2, 20L);
	ltem = 10;
	i__1 = iv2;
	for (iiv = iv1; iiv <= i__1; ++iiv) {
/* Writing concatenation */
	    i__2[0] = ltem, a__1[0] = temq;
	    *(unsigned char *)&ch__1[0] = numclef_(clefq + iiv, 1L) + 48;
	    i__2[1] = 1, a__1[1] = ch__1;
	    s_cat(temq, a__1, i__2, &c__2, 20L);
	    ++ltem;
/* L3: */
	}
	s_wsfe(&io___849);
/* Writing concatenation */
	i__2[0] = ltem, a__1[0] = temq;
	i__2[1] = 2, a__1[1] = "}%";
	s_cat(ch__3, a__1, i__2, &c__2, 22L);
	do_fio(&c__1, ch__3, ltem + 2);
	e_wsfe();
    }
    return 0;
} /* wsclef_ */

/* Subroutine */ int endslur_(stemup, upslur, nolev, iupdn, ndxslur, ivoff, 
	ncm, soutq, lsout, soutq_len)
logical *stemup, *upslur;
integer *nolev, *iupdn, *ndxslur, *ivoff, *ncm;
char *soutq;
integer *lsout;
ftnlen soutq_len;
{
    /* System generated locals */
    address a__1[2];
    integer i__1[2], i__2;
    char ch__1[1];

    /* Builtin functions */
    /* Subroutine */ int s_copy(), s_cat();

    /* Local variables */
    static logical shift;
    static integer lnote;
    static char noteq[8];
    extern /* Subroutine */ int addstr_(), notefq_();
    static integer lnoten;
    static char notexq[79];

    shift = ! (*stemup) && ! (*upslur);
    if (! shift) {

/*  No shift needed */

	s_copy(notexq, "\\tslur", 79L, 6L);
	lnote = 6;
    } else {

/*  Shift needed */

	s_copy(notexq, "\\ts", 79L, 3L);
	lnote = 3;
    }
/* Writing concatenation */
    i__1[0] = lnote, a__1[0] = notexq;
    *(unsigned char *)&ch__1[0] = *ndxslur + 48;
    i__1[1] = 1, a__1[1] = ch__1;
    s_cat(notexq, a__1, i__1, &c__2, 79L);
    ++lnote;
    i__2 = *nolev + *iupdn + *ivoff;
    notefq_(noteq, &lnoten, &i__2, ncm, 8L);
/* Writing concatenation */
    i__1[0] = lnote, a__1[0] = notexq;
    i__1[1] = lnoten, a__1[1] = noteq;
    s_cat(notexq, a__1, i__1, &c__2, 79L);
    lnote += lnoten;
    if (shift) {
/* Writing concatenation */
	i__1[0] = lnote, a__1[0] = notexq;
	i__1[1] = 5, a__1[1] = "{-.6}";
	s_cat(notexq, a__1, i__1, &c__2, 79L);
	lnote += 5;
    }
    addstr_(notexq, &lnote, soutq, lsout, 79L, 80L);
    return 0;
} /* endslur_ */

/* Subroutine */ int getfig_(itoff, charq, lineq, iccount, isfig, itfig, 
	itsofar, nodur, figq, ivx, nfigs, charq_len, lineq_len, figq_len)
integer *itoff;
char *charq, *lineq;
integer *iccount;
logical *isfig;
integer *itfig, *itsofar, *nodur;
char *figq;
integer *ivx, *nfigs;
ftnlen charq_len;
ftnlen lineq_len;
ftnlen figq_len;
{
    /* System generated locals */
    address a__1[2];
    integer i__1[2];
    icilist ici__1;

    /* Builtin functions */
    integer s_rsfi(), do_fio(), e_rsfi();
    /* Subroutine */ int s_copy(), s_cat();

    /* Local variables */
    static integer lfig, loff, noff;
    extern /* Subroutine */ int getchar_();
    extern integer ifnodur_();

    if (*ivx != 1) {

/*  Read past the figure */

L6:
	getchar_(lineq, iccount, charq, 128L, 1L);
	if (*(unsigned char *)charq != ' ') {
	    goto L6;
	}
	return 0;
    }
    ++(*nfigs);
    *itoff = 0;
    if (*(unsigned char *)charq == 'x') {

/*  Floating figure. */

	getchar_(lineq, iccount, charq, 128L, 1L);
	ici__1.icierr = 0;
	ici__1.iciend = 0;
	ici__1.icirnum = 1;
	ici__1.icirlen = 1;
	ici__1.iciunit = charq;
	ici__1.icifmt = "(i1)";
	s_rsfi(&ici__1);
	do_fio(&c__1, (char *)&noff, (ftnlen)sizeof(integer));
	e_rsfi();
	getchar_(lineq, iccount, charq, 128L, 1L);
	ici__1.icierr = 0;
	ici__1.iciend = 0;
	ici__1.icirnum = 1;
	ici__1.icirlen = 1;
	ici__1.iciunit = charq;
	ici__1.icifmt = "(i1)";
	s_rsfi(&ici__1);
	do_fio(&c__1, (char *)&loff, (ftnlen)sizeof(integer));
	e_rsfi();
	*itoff = noff * ifnodur_(&loff, "x", 1L);
	getchar_(lineq, iccount, charq, 128L, 1L);
    } else {

/*  Figure on a note */

	*isfig = TRUE_;
    }
    *itfig = *itsofar + *itoff - *nodur;
    lfig = 1;
    s_copy(figq, charq, 6L, 1L);
L5:
    getchar_(lineq, iccount, charq, 128L, 1L);
    if (*(unsigned char *)charq != ' ') {
/* Writing concatenation */
	i__1[0] = lfig, a__1[0] = figq;
	i__1[1] = 1, a__1[1] = charq;
	s_cat(figq, a__1, i__1, &c__2, 6L);
	++lfig;
	goto L5;
    }
    return 0;
} /* getfig_ */

/* Subroutine */ int eskb4_(ip, ivx, in, ib, nspace, itstart, fbar, itrpt, 
	esk)
integer *ip, *ivx, *in, *ib, *nspace, *itstart;
real *fbar;
integer *itrpt;
real *esk;
{
    /* System generated locals */
    real r__1;

    /* Builtin functions */
    integer s_wsle(), do_lio(), e_wsle();
    /* Subroutine */ int s_stop();

    /* Local variables */
    extern doublereal feon_();
    static integer itnd, nnsk, itprev, iib;

    /* Fortran I/O blocks */
    static cilist io___862 = { 0, 6, 0, 0, 0 };



/* Get elemskips to previous note.  Called only for graces, no xtups invol
ved.*/

    /* Parameter adjustments */
    --itstart;
    --nspace;

    /* Function Body */
    itnd = all_1.list[(*in << 2) - 2];
    if (*ip == 1 || itnd == *itrpt) {

/*  Start of bar or after rpt. */

	*esk = *fbar;
	return 0;
    } else {
	*esk = (float)0.;
	itprev = itnd - all_1.nodur[*ivx + (*ip - 1) * 7 - 8];
	for (iib = *ib; iib >= 1; --iib) {
	    if (itstart[iib] <= itprev) {

/*  This is the block */

		nnsk = (itnd - itprev) / nspace[iib];
		r__1 = (real) nspace[iib];
		*esk += nnsk * feon_(&r__1);
		return 0;
	    } else {
		nnsk = (itnd - itstart[iib]) / nspace[iib];
		r__1 = (real) nspace[iib];
		*esk += nnsk * feon_(&r__1);
		itnd = itstart[iib];
	    }
/* L1: */
	}
    }
    s_wsle(&io___862);
    do_lio(&c__9, &c__1, "Problem in eskb4.  Send files to Dr. Don", 40L);
    e_wsle();
    s_stop("", 0L);
} /* eskb4_ */

/* Subroutine */ int putorn_(iornq, nolev, nolevm, nodur, nornb, ulq, ibmcnt, 
	ivx, ncm, islur, nvmx, nv, ihornb, stemlin, outq, lout, ip, islhgt, 
	beamon, iscrd, ulq_len, outq_len)
integer *iornq, *nolev, *nolevm, *nodur, *nornb;
char *ulq;
integer *ibmcnt, *ivx, *ncm, *islur, *nvmx, *nv, *ihornb;
real *stemlin;
char *outq;
integer *lout, *ip, *islhgt;
logical *beamon, *iscrd;
ftnlen ulq_len;
ftnlen outq_len;
{
    /* System generated locals */
    address a__1[2], a__2[3];
    integer i__1, i__2, i__3[2], i__4[3];
    real r__1, r__2;
    char ch__1[1];

    /* Builtin functions */
    integer pow_ii(), i_indx();
    /* Subroutine */ int s_cat();
    integer lbit_shift(), i_dim();
    /* Subroutine */ int s_copy();

    /* Local variables */
    extern /* Subroutine */ int addblank_();
    static integer ioff, ibit;
    extern /* Character */ VOID udqq_();
    static integer ihorn, lnote;
    static char noteq[8];
    static integer iornt;
    static char ulpzq[1];
    extern integer ni_();
    static char sq[1];
    extern /* Subroutine */ int notefq_();
    static integer lnoten, iudorn;
    static char notexq[79];
    static integer ioffinc;
    static logical usebmht;
    static real stemlen;
    extern /* Subroutine */ int dotrill_();
    extern integer log2_();


/* All args are individual array element *values* except nornb,ihornb,ulq.
*/
/*  notcrd = .true. if ornament is on main note. */
/*    nolevm is level of main note (for chords) */

    /* Parameter adjustments */
    ihornb -= 8;
    ulq -= 8;
    --nornb;

    /* Function Body */
    *(unsigned char *)sq = '\\';
    *lout = 0;
    usebmht = FALSE_;
    if (*nodur < 64) {
	stemlen = *stemlin;
    } else {
	stemlen = (float)0.;
    }

/* Get up-downness. ulpzq is opposite from stem direction for both beams a
nd*/
/*    non beams.  Can use in name of ornament [ . or _ ] */

    if (*beamon) {
	if (*(unsigned char *)&ulq[*ivx + *ibmcnt * 7] == 'u') {
	    *(unsigned char *)ulpzq = 'l';
	} else {
	    *(unsigned char *)ulpzq = 'u';
	}
    } else {
	udqq_(ch__1, 1L, nolevm, ncm, islur, nvmx, ivx, nv);
	if (*(unsigned char *)&ch__1[0] == 'l') {
	    *(unsigned char *)ulpzq = 'u';
	} else {
	    *(unsigned char *)ulpzq = 'l';
	}
    }

/*  To enable >1 ornament on a note, next line is top of manual loop. */

L2:

/*  Bit # of last ornament (last of bits 0-21) */

    i__1 = *iornq & 4194303;
    ibit = log2_(&i__1);
    iornt = pow_ii(&c__2, &ibit);

/*  Begin routine to set height.  Bits 0-13: (stmgx+Tupf._) */
/*  14: Down fermata, was F  15: Trill w/o "tr", was U, 16-18: edit. s,f,n
 */
/*  19: > */

    if (bit_test(*iornq,22)) {

/* Height is set by special beam stuff.  Following block leaves ihorn 
set for*/
/*  later orns on same note. */

	if (! usebmht) {
	    ihorn = ihornb[*ivx + nornb[*ivx] * 7];
	    if ((iornt & 6144) > 0) {

/* Fine-tune for _ or .  Note flaw: for later normal orn here,
 ht. is wrong.*/

		ihorn = ihorn + 1 - (i_indx("l", ulpzq, 1L, 1L) << 1);
		*(unsigned char *)ulpzq = (char) (225 - *(unsigned char *)
			ulpzq);
	    } else if (*(unsigned char *)ulpzq == 'u') {
		ihorn += -2;
	    }
	    ++nornb[*ivx];
	    usebmht = TRUE_;
	}
    } else if (ibit == 14) {

/*  Down fermata.  Don't worry about upper chord notes. */

	if (*(unsigned char *)ulpzq == 'l') {
/* Computing MIN */
	    i__1 = *nolev, i__2 = *ncm - 3;
	    ihorn = min(i__1,i__2);
	} else {
/* Computing MIN */
	    r__1 = *nolev - stemlen, r__2 = *ncm - (float)3.;
	    ihorn = dmin(r__1,r__2);
	}
    } else if (bit_test(iornt,13) || bit_test(iornt,0)) {

/*  ( or ) */

	ihorn = *nolev;
    } else if ((iornt & 6144) > 0) {

/* Staccato . or tenuto _ , but not special beam stuff.  Need up-down 
info*/

	if (! (*iscrd) || comtrill_1.maxlev != *nolev && *(unsigned char *)
		ulpzq == 'l' || comtrill_1.minlev != *nolev && *(unsigned 
		char *)ulpzq == 'u') {
	    ihorn = *nolev;
	} else if (comtrill_1.maxlev == *nolev) {
	    *(unsigned char *)ulpzq = 'u';
/* Computing MAX */
	    r__1 = *nolev + stemlen, r__2 = *ncm + (float)3.;
	    ihorn = dmax(r__1,r__2);
	} else {
	    *(unsigned char *)ulpzq = 'l';
/* Computing MIN */
	    r__1 = *nolev - stemlen, r__2 = *ncm - (float)3.;
	    ihorn = dmin(r__1,r__2);
	}
    } else if (*iscrd && *nolev == comtrill_1.minlev) {
	if (*(unsigned char *)ulpzq == 'l') {
/* Computing MIN */
	    i__1 = *nolev - 3, i__2 = *ncm - 6;
	    ihorn = min(i__1,i__2);
	} else {
/* Computing MIN */
	    i__1 = *nolev - ni_(&stemlen) - 3, i__2 = *ncm - 6;
	    ihorn = min(i__1,i__2);
	}
    } else if (*(unsigned char *)ulpzq == 'l') {

/*  (iscrd and nolev=maxlev) or (.not.iscrd) */

/* Computing MAX */
	r__1 = *nolev + stemlen + 2, r__2 = *ncm + (float)5.;
	ihorn = dmax(r__1,r__2);
    } else {
/* Computing MAX */
	i__1 = *nolev + 2, i__2 = *ncm + 5;
	ihorn = max(i__1,i__2);
    }
    ioff = 0;

/*  Begin routine to set name.  Bits 0-13: (stmgx+Tupf._) */
/*  14: Down fermata, was F  15: Trill w/o "tr", was U, 16-18: edit. s,f,n
 */

    if (bit_test(iornt,2)) {
/* Writing concatenation */
	i__3[0] = 1, a__1[0] = sq;
	i__3[1] = 5, a__1[1] = "shake";
	s_cat(notexq, a__1, i__3, &c__2, 79L);
	lnote = 6;
    } else if (bit_test(iornt,3)) {
/* Writing concatenation */
	i__3[0] = 1, a__1[0] = sq;
	i__3[1] = 7, a__1[1] = "mordent";
	s_cat(notexq, a__1, i__3, &c__2, 79L);
	lnote = 8;
    } else if (bit_test(iornt,1)) {
/* Writing concatenation */
	i__3[0] = 1, a__1[0] = sq;
	i__3[1] = 3, a__1[1] = "mtr";
	s_cat(notexq, a__1, i__3, &c__2, 79L);
	lnote = 4;
    } else if (bit_test(iornt,5)) {
/* Writing concatenation */
	i__3[0] = 1, a__1[0] = sq;
	i__3[1] = 3, a__1[1] = "xtr";
	s_cat(notexq, a__1, i__3, &c__2, 79L);
	lnote = 4;
    } else if (bit_test(iornt,6)) {
/* Writing concatenation */
	i__3[0] = 1, a__1[0] = sq;
	i__3[1] = 3, a__1[1] = "ptr";
	s_cat(notexq, a__1, i__3, &c__2, 79L);
	lnote = 4;
    } else if (bit_test(iornt,13)) {
/* Writing concatenation */
	i__3[0] = 1, a__1[0] = sq;
	i__3[1] = 3, a__1[1] = "rpn";
	s_cat(notexq, a__1, i__3, &c__2, 79L);
	lnote = 4;
    } else if (bit_test(iornt,0)) {
/* Writing concatenation */
	i__3[0] = 1, a__1[0] = sq;
	i__3[1] = 3, a__1[1] = "lpn";
	s_cat(notexq, a__1, i__3, &c__2, 79L);
	lnote = 4;
    } else if (bit_test(iornt,12)) {
/* Writing concatenation */
	i__4[0] = 1, a__2[0] = sq;
	i__4[1] = 1, a__2[1] = ulpzq;
	i__4[2] = 2, a__2[2] = "st";
	s_cat(notexq, a__2, i__4, &c__3, 79L);
	lnote = 4;
    } else if (bit_test(iornt,11)) {
/* Writing concatenation */
	i__4[0] = 1, a__2[0] = sq;
	i__4[1] = 1, a__2[1] = ulpzq;
	i__4[2] = 2, a__2[2] = "pz";
	s_cat(notexq, a__2, i__4, &c__3, 79L);
	lnote = 4;
    } else if (bit_test(iornt,8)) {
/* Writing concatenation */
	i__3[0] = 1, a__1[0] = sq;
	i__3[1] = 3, a__1[1] = "upz";
	s_cat(notexq, a__1, i__3, &c__2, 79L);
	lnote = 4;
	ioff = -2;
    } else if (bit_test(iornt,9)) {
/* Writing concatenation */
	i__3[0] = 1, a__1[0] = sq;
	i__3[1] = 4, a__1[1] = "uppz";
	s_cat(notexq, a__1, i__3, &c__2, 79L);
	lnote = 5;
	ioff = -2;
    } else if (bit_test(iornt,10)) {
	if (*nodur < 48) {
/* Writing concatenation */
	    i__3[0] = 1, a__1[0] = sq;
	    i__3[1] = 9, a__1[1] = "fermataup";
	    s_cat(notexq, a__1, i__3, &c__2, 79L);
	} else {
/* Writing concatenation */
	    i__3[0] = 1, a__1[0] = sq;
	    i__3[1] = 9, a__1[1] = "Fermataup";
	    s_cat(notexq, a__1, i__3, &c__2, 79L);
	}
	lnote = 10;
	ioff = -2;
    } else if (bit_test(iornt,14)) {
	if (*nodur < 48) {
/* Writing concatenation */
	    i__3[0] = 1, a__1[0] = sq;
	    i__3[1] = 11, a__1[1] = "fermatadown";
	    s_cat(notexq, a__1, i__3, &c__2, 79L);
	} else {
/* Writing concatenation */
	    i__3[0] = 1, a__1[0] = sq;
	    i__3[1] = 11, a__1[1] = "Fermatadown";
	    s_cat(notexq, a__1, i__3, &c__2, 79L);
	}
	lnote = 12;
    } else if (bit_test(iornt,16)) {
/* Writing concatenation */
	i__3[0] = 1, a__1[0] = sq;
	i__3[1] = 6, a__1[1] = "esharp";
	s_cat(notexq, a__1, i__3, &c__2, 79L);
	lnote = 7;
	ioff = 2;
    } else if (bit_test(iornt,17)) {
/* Writing concatenation */
	i__3[0] = 1, a__1[0] = sq;
	i__3[1] = 5, a__1[1] = "eflat";
	s_cat(notexq, a__1, i__3, &c__2, 79L);
	lnote = 6;
	ioff = 1;
    } else if (bit_test(iornt,18)) {
/* Writing concatenation */
	i__3[0] = 1, a__1[0] = sq;
	i__3[1] = 4, a__1[1] = "enat";
	s_cat(notexq, a__1, i__3, &c__2, 79L);
	lnote = 5;
	ioff = 2;
    } else if (bit_test(iornt,19)) {
/* Writing concatenation */
	i__3[0] = 1, a__1[0] = sq;
	i__3[1] = 3, a__1[1] = "usf";
	s_cat(notexq, a__1, i__3, &c__2, 79L);
	lnote = 4;
	ioff = -2;
    } else if (bit_test(iornt,20)) {
/* Writing concatenation */
	i__3[0] = 1, a__1[0] = sq;
	i__3[1] = 4, a__1[1] = "usfz";
	s_cat(notexq, a__1, i__3, &c__2, 79L);
	lnote = 5;
	ioff = -2;
    }

/*  User-defined level shift of ornament from default? */

    if (bit_test(*iornq,25)) {

/*  Find which (if any) element of kudorn has the shift. */

	i__1 = comtrill_1.nudorn;
	for (iudorn = 1; iudorn <= i__1; ++iudorn) {
	    if (*ip + (*ivx << 8) + (*nolev << 12) + (ibit << 19) == (
		    33554431 & comtrill_1.kudorn[iudorn - 1])) {
		goto L4;
	    }
/* L3: */
	}

/*  Nothing shifted on this note; exit this loop */

	goto L5;
L4:
/*        ioff = ioff+iand(63,ishft(kudorn(iudorn),-25))-32 */
	ioffinc = (63 & lbit_shift(comtrill_1.kudorn[iudorn - 1], -25L)) - 32;
	if (ibit == 19 && ioffinc < -7) {

/* Convert usf to lsf.  The reason has to do with positioning bein
g impossile*/
/*  for some mysterious reason when you drop \usf below the staff 
*/

/* Writing concatenation */
	    i__3[0] = 1, a__1[0] = sq;
	    i__3[1] = 3, a__1[1] = "lsf";
	    s_cat(notexq, a__1, i__3, &c__2, 79L);
	    ioffinc += 6;
	}
	ioff += ioffinc;
    }
L5:

/*  Shift level to avoid slur.  Conditions are */
/*   1.  There is a slur */
/* c   2.  No user-defined shift (btest(iornq,24)) */
/*   2.  No user-defined orn height shift (btest(iornq,25)) */
/*   3.  upslur (islhgt>0) */
/*  4.  ornament is not segno(4), ._)(11-13), down ferm(14) or "(" (0) Bin
=30737*/
/*   5.  islhgt+3 >=  height already computed. */

/*      if (iand(islur,15).gt.0 .and. .not.btest(iornq,24) .and. */
/*     *                islhgt.gt.0 .and. iand(iornt,30737).eq.0) */
/*      if (.not.btest(iornq,24) .and. */
    if (! bit_test(*iornq,25) && *islhgt > 0 && (iornt & 30737) == 0) {
	i__1 = *islhgt + 3;
	ioff += i_dim(&i__1, &ihorn);
    }
/*     *  ioff = ioff+dim(islhgt+3,ihorn+ioff) */
    i__1 = ihorn + ioff;
    notefq_(noteq, &lnoten, &i__1, ncm, 8L);
    if (lnoten == 1) {
	addblank_(noteq, &lnoten, 8L);
    }
    if ((iornt & 32896) > 0) {

/*  T-trill or trill w/o "tr" */

	dotrill_(ivx, ip, &iornt, noteq, &lnoten, notexq, &lnote, 8L, 79L);
    } else {
/* Writing concatenation */
	i__3[0] = lnote, a__1[0] = notexq;
	i__3[1] = lnoten, a__1[1] = noteq;
	s_cat(notexq, a__1, i__3, &c__2, 79L);
	lnote += lnoten;
    }

/*  Zero out the bit for ornament just dealt with. */

/*     if (notcrd) then */
    *iornq = bit_clear(*iornq,ibit);
/*     else */

/*  Deal with this later */

/*       continue */
/*     end if */
    if (*lout == 0) {
	s_copy(outq, notexq, 79L, lnote);
    } else {
/* Writing concatenation */
	i__3[0] = *lout, a__1[0] = outq;
	i__3[1] = lnote, a__1[1] = notexq;
	s_cat(outq, a__1, i__3, &c__2, 79L);
    }
    *lout += lnote;

/*  Check bits 0-21, go back if any are still set */

    if ((*iornq & 4194303) > 0) {
	goto L2;
    }
    return 0;
} /* putorn_ */

/* Subroutine */ int putxtn_(ntupv, iflop, multb, iud, wheadpt, poenom, 
	nolev1, islope, slfac, xnlmid, islur, lnote, notexq, ncmid, nlnum, 
	eloff, iup, irest, notexq_len)
integer *ntupv, *iflop, *multb, *iud;
real *wheadpt, *poenom;
integer *nolev1, *islope;
real *slfac, *xnlmid;
integer *islur, *lnote;
char *notexq;
integer *ncmid, *nlnum;
real *eloff;
integer *iup, *irest;
ftnlen notexq_len;
{
    /* System generated locals */
    address a__1[3], a__2[2];
    integer i__1[3], i__2, i__3[2];
    real r__1;
    icilist ici__1;

    /* Builtin functions */
    integer lbit_shift();
    /* Subroutine */ int s_copy();
    integer s_wsfi(), do_fio(), e_wsfi();
    /* Subroutine */ int s_cat();

    /* Local variables */
    static integer ioff;
    static char noteq[8];
    extern integer ni_();
    extern /* Subroutine */ int notefq_();
    static integer lnoten;


/*  Places digit for xtuplet. */

    ioff = (*ntupv + 1) / 2;
    if (*iflop != 0 && *multb > 0) {

/* Number goes on beam side, move R/L by .5 wheadpt for upper/lower */

	*eloff -= *iud * (float).5 * *wheadpt / *poenom;

/*  Number goes on beam side, must use beam parameters to set pos'n */

	*nlnum = *nolev1 + *islope / *slfac * *eloff + *iup * (*multb + 8);
	if (*multb >= 2) {
	    *nlnum += *iup;
	}
    } else {
	r__1 = *xnlmid - 1 + *iud * 3 + *iflop * 11 + (float).1;
	*nlnum = ni_(&r__1);
    }
    if (! bit_test(*islur,31)) {

/*  Only print number when wanted.  First check vert, horiz offset */

	if (bit_test(*irest,1)) {
	    *nlnum = *nlnum + (31 & lbit_shift(*irest, -2L)) - 16;
	}
	if (bit_test(*irest,7)) {
	    *eloff += ((31 & lbit_shift(*irest, -9L)) * (float).1 - (float)
		    1.6) * *wheadpt / *poenom;
	}
	s_copy(notexq, "\\xnum{", 79L, 6L);
	*lnote = 10;
	if (*eloff < (float).995) {
	    ici__1.icierr = 0;
	    ici__1.icirnum = 1;
	    ici__1.icirlen = 4;
	    ici__1.iciunit = notexq + 6;
	    ici__1.icifmt = "(i1,f3.2)";
	    s_wsfi(&ici__1);
	    do_fio(&c__1, (char *)&c__0, (ftnlen)sizeof(integer));
	    do_fio(&c__1, (char *)&(*eloff), (ftnlen)sizeof(real));
	    e_wsfi();
	} else if (*eloff < (float)9.995) {
	    ici__1.icierr = 0;
	    ici__1.icirnum = 1;
	    ici__1.icirlen = 4;
	    ici__1.iciunit = notexq + 6;
	    ici__1.icifmt = "(f4.2)";
	    s_wsfi(&ici__1);
	    do_fio(&c__1, (char *)&(*eloff), (ftnlen)sizeof(real));
	    e_wsfi();
	} else {
	    ici__1.icierr = 0;
	    ici__1.icirnum = 1;
	    ici__1.icirlen = 5;
	    ici__1.iciunit = notexq + 6;
	    ici__1.icifmt = "(f5.2)";
	    s_wsfi(&ici__1);
	    do_fio(&c__1, (char *)&(*eloff), (ftnlen)sizeof(real));
	    e_wsfi();
	    *lnote = 11;
	}
	notefq_(noteq, &lnoten, nlnum, ncmid, 8L);
/* Writing concatenation */
	i__1[0] = *lnote, a__1[0] = notexq;
	i__1[1] = 1, a__1[1] = "}";
	i__1[2] = lnoten, a__1[2] = noteq;
	s_cat(notexq, a__1, i__1, &c__3, 79L);
	*lnote = *lnote + 1 + lnoten;
	if (*ntupv < 10) {
	    i__2 = *lnote;
	    ici__1.icierr = 0;
	    ici__1.icirnum = 1;
	    ici__1.icirlen = *lnote + 1 - i__2;
	    ici__1.iciunit = notexq + i__2;
	    ici__1.icifmt = "(i1)";
	    s_wsfi(&ici__1);
	    do_fio(&c__1, (char *)&(*ntupv), (ftnlen)sizeof(integer));
	    e_wsfi();
	    ++(*lnote);
	} else {
/* Writing concatenation */
	    i__3[0] = *lnote, a__2[0] = notexq;
	    i__3[1] = 1, a__2[1] = "{";
	    s_cat(notexq, a__2, i__3, &c__2, 79L);
	    i__2 = *lnote + 1;
	    ici__1.icierr = 0;
	    ici__1.icirnum = 1;
	    ici__1.icirlen = *lnote + 3 - i__2;
	    ici__1.iciunit = notexq + i__2;
	    ici__1.icifmt = "(i2)";
	    s_wsfi(&ici__1);
	    do_fio(&c__1, (char *)&(*ntupv), (ftnlen)sizeof(integer));
	    e_wsfi();
/* Writing concatenation */
	    i__3[0] = *lnote + 3, a__2[0] = notexq;
	    i__3[1] = 1, a__2[1] = "}";
	    s_cat(notexq, a__2, i__3, &c__2, 79L);
	    *lnote += 4;
	}
    }
    return 0;
} /* putxtn_ */

/* Subroutine */ int mrec1_(lineq, iccount, ndxm, lineq_len)
char *lineq;
integer *iccount, *ndxm;
ftnlen lineq_len;
{
    /* System generated locals */
    integer i__1;
    olist o__1;

    /* Builtin functions */
    integer f_open(), i_indx(), s_wsfe(), do_fio(), e_wsfe();

    /* Fortran I/O blocks */
    static cilist io___880 = { 0, 0, 0, "(a)", 0 };
    static cilist io___881 = { 0, 0, 0, "(a)", 0 };



/*  This is called when (a) macro recording is just starting and */
/*  (b) at the start of a new line, if recording is on */

    if (! commac_1.mrecord) {

/*  Starting the macro */

	o__1.oerr = 0;
	o__1.ounit = commac_1.macnum + 20;
	o__1.ofnm = 0;
	o__1.orl = 0;
	o__1.osta = "SCRATCH";
	o__1.oacc = 0;
	o__1.ofm = 0;
	o__1.oblnk = 0;
	f_open(&o__1);
	commac_1.mrecord = TRUE_;
    }
    if (*iccount < 128) {
	i__1 = *iccount;
	*ndxm = i_indx(lineq + i__1, "M", 128 - i__1, 1L);
	if (*ndxm > 0) {

/*  This line ends the macro. */

	    if (*ndxm > 1) {
		io___880.ciunit = commac_1.macnum + 20;
		s_wsfe(&io___880);
		i__1 = *iccount;
		do_fio(&c__1, lineq + i__1, *iccount + *ndxm - 1 - i__1);
		e_wsfe();
	    }
	    commac_1.mrecord = FALSE_;
	} else {

/*  This line just continues the macro */

	    io___881.ciunit = commac_1.macnum + 20;
	    s_wsfe(&io___881);
	    i__1 = *iccount;
	    do_fio(&c__1, lineq + i__1, 128 - i__1);
	    e_wsfe();
	}
    }
    return 0;
} /* mrec1_ */

/* Subroutine */ int read10_(string, lenstr, lastchar, string_len)
char *string;
integer *lenstr;
logical *lastchar;
ftnlen string_len;
{
    /* System generated locals */
    integer i__1;

    /* Builtin functions */
    integer s_rsfe(), do_fio(), e_rsfe();

    /* Fortran I/O blocks */
    static cilist io___882 = { 0, 10, 1, "(a)", 0 };
    static cilist io___883 = { 0, 0, 1, "(a)", 0 };


    if (! commac_1.mplay) {
	i__1 = s_rsfe(&io___882);
	if (i__1 != 0) {
	    goto L999;
	}
	i__1 = do_fio(&c__1, string, (*lenstr));
	if (i__1 != 0) {
	    goto L999;
	}
	i__1 = e_rsfe();
	if (i__1 != 0) {
	    goto L999;
	}
	return 0;
L999:
	*lastchar = TRUE_;
	return 0;
    } else {
	io___883.ciunit = commac_1.macnum + 20;
	i__1 = s_rsfe(&io___883);
	if (i__1 != 0) {
	    goto L998;
	}
	i__1 = do_fio(&c__1, string, string_len);
	if (i__1 != 0) {
	    goto L998;
	}
	i__1 = e_rsfe();
	if (i__1 != 0) {
	    goto L998;
	}
	return 0;
L998:
	commac_1.mplay = FALSE_;
	commac_1.endmac = TRUE_;
	return 0;
    }
} /* read10_ */

/* Subroutine */ int getset_(nv, noinst, mtrnuml, mtrdenl, mtrnmp, mtrdnp, 
	xmtrnum0, npages, nsyst, musicsize, fracindent, istype0, inameq, 
	clefq, sepsymq, pathnameq, lpath, isig0, inameq_len, clefq_len, 
	sepsymq_len, pathnameq_len)
integer *nv, *noinst, *mtrnuml, *mtrdenl, *mtrnmp, *mtrdnp;
real *xmtrnum0;
integer *npages, *nsyst, *musicsize;
real *fracindent;
logical *istype0;
char *inameq, *clefq, *sepsymq, *pathnameq;
integer *lpath, *isig0;
ftnlen inameq_len;
ftnlen clefq_len;
ftnlen sepsymq_len;
ftnlen pathnameq_len;
{
    /* System generated locals */
    integer i__1, i__2;
    olist o__1;

    /* Builtin functions */
    integer s_rsfe(), do_fio(), e_rsfe(), s_cmp(), f_open(), s_wsfe(), e_wsfe(
	    ), i_indx();

    /* Local variables */
    static real xdum;
    static integer i__, nline;
    static char lineq[128];
    static integer iinst, nvtot, nstaf1, iv;
    extern doublereal readin_();
    static integer iin, ivi, iccount;

    /* Fortran I/O blocks */
    static cilist io___885 = { 0, 10, 0, "(a)", 0 };
    static cilist io___887 = { 0, 10, 0, "(a)", 0 };
    static cilist io___888 = { 0, 17, 0, "(a)", 0 };
    static cilist io___893 = { 0, 10, 0, "(a79)", 0 };
    static cilist io___894 = { 0, 10, 0, "(a)", 0 };
    static cilist io___900 = { 0, 10, 0, "(a)", 0 };



/*  Get the first line */

    /* Parameter adjustments */
    --sepsymq;
    --clefq;
    inameq -= 79;

    /* Function Body */
    iccount = 0;
L9:
    s_rsfe(&io___885);
    do_fio(&c__1, lineq, 128L);
    e_rsfe();
    if (*(unsigned char *)lineq == '%') {
	goto L9;
    }
    *istype0 = s_cmp(lineq, "---", 3L, 3L) == 0;
    if (*istype0) {

/* Have TeX input until next line that starts with '---'.  Save in scr
atch.*/

	o__1.oerr = 0;
	o__1.ounit = 17;
	o__1.ofnm = 0;
	o__1.orl = 0;
	o__1.osta = "SCRATCH";
	o__1.oacc = 0;
	o__1.ofm = 0;
	o__1.oblnk = 0;
	f_open(&o__1);
L3:
	s_rsfe(&io___887);
	do_fio(&c__1, lineq, 128L);
	e_rsfe();
	if (s_cmp(lineq, "---", 3L, 3L) != 0) {
	    s_wsfe(&io___888);
	    do_fio(&c__1, lineq, 128L);
	    e_wsfe();
	    goto L3;
	}

/*  Force a new line read on first call to readin */

	iccount = 128;
    }

/*  Here, lineq is first line w/ numerical setup data. */

    *nv = readin_(lineq, &iccount, &nline, 128L) + (float).1;
    *noinst = readin_(lineq, &iccount, &nline, 128L) + (float).1;

/*  If noinst<0 , will have to read in nvi for each instrument */

    if (*noinst <= 0) {
	--(*noinst);
	i__1 = -(*noinst);
	for (iin = 1; iin <= i__1; ++iin) {
	    comnvi_1.nvi[iin - 1] = readin_(lineq, &iccount, &nline, 128L) + (
		    float).1;
/* L2: */
	}
    }
    *mtrnuml = readin_(lineq, &iccount, &nline, 128L) + (float).1;
    *mtrdenl = readin_(lineq, &iccount, &nline, 128L) + (float).1;
    *mtrnmp = readin_(lineq, &iccount, &nline, 128L) + (float).1;
    *mtrdnp = readin_(lineq, &iccount, &nline, 128L) + (float).1;
    *xmtrnum0 = readin_(lineq, &iccount, &nline, 128L);

/* Original key sig (before any trnasposition) in next position.  Transpos
ed*/
/*  sig for topfile was transferred thru pmxtex.dat.  Need isig0 for key 
*/
/*  changes if transposed. */

    xdum = readin_(lineq, &iccount, &nline, 128L);
    *isig0 = xdum + (float).1;
    if (xdum < (float)0.) {
	*isig0 = xdum - (float).1;
    }
    *npages = readin_(lineq, &iccount, &nline, 128L) + (float).1;
    *nsyst = readin_(lineq, &iccount, &nline, 128L) + (float).1;
    *musicsize = readin_(lineq, &iccount, &nline, 128L) + (float).1;
    *fracindent = readin_(lineq, &iccount, &nline, 128L);

/*  Next noinst non-comment lines are names of instruments. */

    i__1 = abs(*noinst);
    for (i__ = 1; i__ <= i__1; ++i__) {
L5:
	s_rsfe(&io___893);
	do_fio(&c__1, inameq + i__ * 79, 79L);
	e_rsfe();
	if (*(unsigned char *)&inameq[i__ * 79] == '%') {
	    goto L5;
	}
/* L4: */
    }

/*  Mext non-comment line has nv clef names */

L6:
    s_rsfe(&io___894);
    do_fio(&c__1, lineq, 128L);
    e_rsfe();
    if (*(unsigned char *)lineq == '%') {
	goto L6;
    }
    if (*noinst > 0) {

/*  Old way */

	nstaf1 = *nv - *noinst + 1;
	i__1 = *nv;
	for (iv = 1; iv <= i__1; ++iv) {
	    *(unsigned char *)&clefq[iv] = *(unsigned char *)&lineq[iv - 1];
	    if (iv < nstaf1) {
		*(unsigned char *)&sepsymq[iv] = '|';
	    } else {
		*(unsigned char *)&sepsymq[iv] = '&';
	    }
/* L7: */
	}
    } else {

/*  New way */

	iv = 0;
	nvtot = 0;
	i__1 = -(*noinst);
	for (iinst = 1; iinst <= i__1; ++iinst) {
	    nvtot += comnvi_1.nvi[iinst - 1];
	    i__2 = comnvi_1.nvi[iinst - 1];
	    for (ivi = 1; ivi <= i__2; ++ivi) {
		++iv;
		*(unsigned char *)&clefq[iv] = *(unsigned char *)&lineq[iv - 
			1];
		if (iv == nvtot) {
		    *(unsigned char *)&sepsymq[iv] = '&';
		} else {
		    *(unsigned char *)&sepsymq[iv] = '|';
		}
/* L10: */
	    }
/* L1: */
	}
    }

/*  Mext non-comment line has path name */

L8:
    s_rsfe(&io___900);
    do_fio(&c__1, pathnameq, 40L);
    e_rsfe();
    if (*(unsigned char *)pathnameq == '%') {
	goto L8;
    }
    *lpath = i_indx(pathnameq, " ", 40L, 1L) - 1;
    return 0;
} /* getset_ */

doublereal readin_(lineq, iccount, nline, lineq_len)
char *lineq;
integer *iccount, *nline;
ftnlen lineq_len;
{
    /* System generated locals */
    address a__1[3];
    integer i__1[3];
    real ret_val;
    char ch__1[27], ch__2[6], ch__3[1];
    icilist ici__1;

    /* Builtin functions */
    integer s_rsfe(), do_fio(), e_rsfe(), i_indx(), s_wsle();
    /* Subroutine */ int s_cat();
    integer do_lio(), e_wsle();
    /* Subroutine */ int s_stop();
    integer s_rsfi(), e_rsfi();

    /* Local variables */
    static char durq[1];
    static integer i1, i2, icf;
    extern /* Subroutine */ int getchar_();

    /* Fortran I/O blocks */
    static cilist io___901 = { 0, 10, 0, "(a)", 0 };
    static cilist io___905 = { 0, 6, 0, 0, 0 };



/*  Reads a piece of setup data from file lineq, gets a new lineq from */
/*  file 10 (jobname.pmx) and increments nline if needed,  passes over */
/*  comment lines */

L4:
    if (*iccount == 128) {
L1:
	s_rsfe(&io___901);
	do_fio(&c__1, lineq, 128L);
	e_rsfe();
	++(*nline);
	if (*(unsigned char *)lineq == '%') {
	    goto L1;
	}
	*iccount = 0;
    }
    ++(*iccount);

/*  Find next non-blank or end of line */

    for (*iccount = *iccount; *iccount <= 127; ++(*iccount)) {
	if (*(unsigned char *)&lineq[*iccount - 1] != ' ') {
	    goto L3;
	}
/* L2: */
    }

/*  If here, need to get a new line */

    *iccount = 128;
    goto L4;
L3:

/*  iccount now points to start of number to read */

    i1 = *iccount;
L5:
    getchar_(lineq, iccount, durq, 128L, 1L);

/*  Remember that getchar increments iccount, then reads a character. */

    if (i_indx("0123456789.-", durq, 12L, 1L) > 0) {
	goto L5;
    }
    i2 = *iccount - 1;
    if (i2 < i1) {
	s_wsle(&io___905);
/* Writing concatenation */
	i__1[0] = 7, a__1[0] = "Found \"";
	i__1[1] = 1, a__1[1] = durq;
	i__1[2] = 19, a__1[2] = "\" instead of number";
	s_cat(ch__1, a__1, i__1, &c__3, 27L);
	do_lio(&c__9, &c__1, ch__1, 27L);
	e_wsle();
	s_stop("1", 1L);
    }
    icf = i2 - i1 + 49;
    ici__1.icierr = 0;
    ici__1.iciend = 0;
    ici__1.icirnum = 1;
    ici__1.icirlen = i2 - (i1 - 1);
    ici__1.iciunit = lineq + (i1 - 1);
/* Writing concatenation */
    i__1[0] = 2, a__1[0] = "(f";
    *(unsigned char *)&ch__3[0] = icf;
    i__1[1] = 1, a__1[1] = ch__3;
    i__1[2] = 3, a__1[2] = ".0)";
    ici__1.icifmt = (s_cat(ch__2, a__1, i__1, &c__3, 6L), ch__2);
    s_rsfi(&ici__1);
    do_fio(&c__1, (char *)&ret_val, (ftnlen)sizeof(real));
    e_rsfi();
    return ret_val;
} /* readin_ */

/* Subroutine */ int moveln_(iuin, iuout, done)
integer *iuin, *iuout;
logical *done;
{
    /* System generated locals */
    integer i__1;

    /* Builtin functions */
    integer s_rsfe(), do_fio(), e_rsfe(), s_wsfe(), e_wsfe();

    /* Local variables */
    extern integer llen_();
    static char outq[129];
    static integer lenout;

    /* Fortran I/O blocks */
    static cilist io___907 = { 0, 0, 1, "(a)", 0 };
    static cilist io___910 = { 0, 0, 0, "(a)", 0 };


    *done = FALSE_;
    io___907.ciunit = *iuin;
    i__1 = s_rsfe(&io___907);
    if (i__1 != 0) {
	goto L1;
    }
    i__1 = do_fio(&c__1, outq, 129L);
    if (i__1 != 0) {
	goto L1;
    }
    i__1 = e_rsfe();
    if (i__1 != 0) {
	goto L1;
    }
    lenout = llen_(outq, &c__129, 129L);
    io___910.ciunit = *iuout;
    s_wsfe(&io___910);
    do_fio(&c__1, outq, lenout);
    e_wsfe();
    return 0;
L1:
    *done = TRUE_;
    return 0;
} /* moveln_ */

/* Subroutine */ int putarp_(itnow, iv, nolev, ncm, soutq, lsout, soutq_len)
integer *itnow, *iv, *nolev, *ncm;
char *soutq;
integer *lsout;
ftnlen soutq_len;
{
    /* Initialized data */

    static char symq[8*2+1] = "raisearparpeggio";

    /* System generated locals */
    address a__1[3], a__2[2];
    integer i__1, i__2[3], i__3[2];
    real r__1;
    char ch__1[1], ch__2[80];
    icilist ici__1;

    /* Builtin functions */
    integer s_wsle(), do_lio(), e_wsle(), s_wsfe(), do_fio(), e_wsfe();
    /* Subroutine */ int s_cat();
    integer s_wsfi(), e_wsfi();

    /* Local variables */
    static integer iarp, isym, lnote;
    extern integer ni_();
    extern /* Subroutine */ int addstr_();
    static integer levbot, ilvert, invert;
    static char notexq[79];

    /* Fortran I/O blocks */
    static cilist io___915 = { 0, 6, 0, 0, 0 };
    static cilist io___916 = { 0, 6, 0, "(f5.1,5i5)", 0 };
    static icilist io___921 = { 0, notexq+10, 0, "(i2,a1)", 3, 1 };
    static icilist io___922 = { 0, notexq+10, 0, "(i3,a1)", 4, 1 };



/*  Find which iarp, if any */

    i__1 = comarp_1.narp;
    for (iarp = 1; iarp <= i__1; ++iarp) {
	if (*itnow == comarp_1.itar[iarp - 1]) {
	    goto L2;
	}
/* L1: */
    }

/*  If here, this is the *first* call for this arp. */

    ++comarp_1.narp;
    comarp_1.itar[comarp_1.narp - 1] = *itnow;
    comarp_1.ivar1[comarp_1.narp - 1] = *iv;
    comarp_1.levar1[comarp_1.narp - 1] = *nolev;
    comarp_1.ncmar1[comarp_1.narp - 1] = *ncm;
    return 0;
L2:

/* If here, this is second call at this time, iarp points to values from 1
st.*/

    if (*iv == comarp_1.ivar1[iarp - 1]) {

/*  Arp is in a single staff. */

/* Computing MIN */
	i__1 = comarp_1.levar1[iarp - 1];
	levbot = min(i__1,*nolev) - *ncm + 3;
	invert = (i__1 = comarp_1.levar1[iarp - 1] - *nolev, abs(i__1)) + 1;
    } else {

/* Arp covers >1 staff.  Lower staff has to be the first, upper is cur
rent and*/
/*  is where the symbol will be written. */

	r__1 = comarp_1.xinsnow * 2;
	levbot = -ni_(&r__1) + 3 + comarp_1.levar1[iarp - 1] - 
		comarp_1.ncmar1[iarp - 1];
	invert = -levbot + 4 + *nolev - *ncm;
	s_wsle(&io___915);
	do_lio(&c__9, &c__1, "xinsnow,levar1,ncmar1,levbot,nolev,ncm:", 39L);
	e_wsle();
	s_wsfe(&io___916);
	do_fio(&c__1, (char *)&comarp_1.xinsnow, (ftnlen)sizeof(real));
	do_fio(&c__1, (char *)&comarp_1.levar1[iarp - 1], (ftnlen)sizeof(
		integer));
	do_fio(&c__1, (char *)&comarp_1.ncmar1[iarp - 1], (ftnlen)sizeof(
		integer));
	do_fio(&c__1, (char *)&levbot, (ftnlen)sizeof(integer));
	do_fio(&c__1, (char *)&(*nolev), (ftnlen)sizeof(integer));
	do_fio(&c__1, (char *)&(*ncm), (ftnlen)sizeof(integer));
	e_wsfe();
    }

/* isym will be (1,2) if invert is (even,odd).  If even, raise .5\internot
e*/

    isym = invert % 2 + 1;
    ilvert = (invert + 1) / 2;
    if (levbot >= 0 && levbot <= 9) {

/*  Single digit */

/* Writing concatenation */
	i__2[0] = 1, a__1[0] = "\\";
	i__2[1] = 8, a__1[1] = symq + (isym - 1 << 3);
	*(unsigned char *)&ch__1[0] = levbot + 48;
	i__2[2] = 1, a__1[2] = ch__1;
	s_cat(notexq, a__1, i__2, &c__3, 79L);
	lnote = 10;
    } else {
/* Writing concatenation */
	i__2[0] = 1, a__1[0] = "\\";
	i__2[1] = 8, a__1[1] = symq + (isym - 1 << 3);
	i__2[2] = 1, a__1[2] = "{";
	s_cat(notexq, a__1, i__2, &c__3, 79L);
	if (levbot >= -9) {

/*  Need two spaces for number */

	    s_wsfi(&io___921);
	    do_fio(&c__1, (char *)&levbot, (ftnlen)sizeof(integer));
	    do_fio(&c__1, "}", 1L);
	    e_wsfi();
	    lnote = 13;
	} else {
	    s_wsfi(&io___922);
	    do_fio(&c__1, (char *)&levbot, (ftnlen)sizeof(integer));
	    do_fio(&c__1, "}", 1L);
	    e_wsfi();
	    lnote = 14;
	}
    }
    if (ilvert <= 9) {
/* Writing concatenation */
	i__3[0] = lnote, a__2[0] = notexq;
	*(unsigned char *)&ch__1[0] = ilvert + 48;
	i__3[1] = 1, a__2[1] = ch__1;
	s_cat(ch__2, a__2, i__3, &c__2, 80L);
	i__1 = lnote + 1;
	addstr_(ch__2, &i__1, soutq, lsout, lnote + 1, 80L);
    } else {
	i__1 = lnote;
	ici__1.icierr = 0;
	ici__1.icirnum = 1;
	ici__1.icirlen = lnote + 4 - i__1;
	ici__1.iciunit = notexq + i__1;
	ici__1.icifmt = "(a1,i2,a1)";
	s_wsfi(&ici__1);
	do_fio(&c__1, "{", 1L);
	do_fio(&c__1, (char *)&ilvert, (ftnlen)sizeof(integer));
	do_fio(&c__1, "}", 1L);
	e_wsfi();
	i__1 = lnote + 4;
	addstr_(notexq, &i__1, soutq, lsout, lnote + 4, 80L);
    }

/*  cancel out the stored time, to permit two arps at same time! */

    comarp_1.itar[iarp - 1] = -1;
    return 0;
} /* putarp_ */

/* Subroutine */ int chkarp_(found1, ncrd, icrdat, ivx, ip, isacc, isarp)
logical *found1;
integer *ncrd, *icrdat, *ivx, *ip;
logical *isacc, *isarp;
{
    /* System generated locals */
    integer i__1;

    /* Builtin functions */
    integer lbit_shift();

    /* Local variables */
    static integer icrd;

    /* Parameter adjustments */
    --icrdat;

    /* Function Body */
    *found1 = FALSE_;
    i__1 = *ncrd;
    for (icrd = 1; icrd <= i__1; ++icrd) {
	if ((255 & icrdat[icrd]) == *ip && (15 & lbit_shift(icrdat[icrd], -8L)
		) == *ivx) {
	    if (! (*found1)) {
		*found1 = TRUE_;
	    }
	    *isacc = *isacc || bit_test(icrdat[icrd],19);
	    *isarp = *isarp || bit_test(icrdat[icrd],25);
	} else if (*found1) {
/*             go to 19 */
	    return 0;
	}
/* L18: */
    }
    return 0;
} /* chkarp_ */

/* Subroutine */ int putshft_(ivx, onoff, soutq, lsout, soutq_len)
integer *ivx;
logical *onoff;
char *soutq;
integer *lsout;
ftnlen soutq_len;
{
    /* System generated locals */
    address a__1[3], a__2[4];
    integer i__1[3], i__2[4], i__3;
    real r__1;
    char ch__1[6], ch__2[1], ch__3[88];
    icilist ici__1;

    /* Builtin functions */
    double r_sign();
    /* Subroutine */ int s_cat();
    integer s_wsfi(), do_fio(), e_wsfi();

    /* Local variables */
    static integer ifmt;
    static real xoff;
    static char sq[1];
    extern /* Subroutine */ int addstr_();
    static char notexq[80];

    *(unsigned char *)sq = '\\';

/*  Start user-defined offsets X(...): or X(...)S */

    if (*onoff) {
	++comudsp_1.nudoff[*ivx - 1];
    }

/*  Xoff is in pts.  Round off to nearest .1.  Will use at end of shift. 
*/

    xoff = comudsp_1.udoff[*ivx + comudsp_1.nudoff[*ivx - 1] * 7 - 8];
    r__1 = (integer) (dabs(xoff) * (float)10. + (float).5) / (float)10.;
    xoff = r_sign(&r__1, &xoff);
    if (! (*onoff)) {
	xoff = -xoff;
    }
    if (xoff < (float)-9.95) {
	ifmt = 5;
    } else if (xoff < (float)-.95 || xoff > (float)9.95) {
	ifmt = 4;
    } else {
	ifmt = 3;
    }
    ici__1.icierr = 0;
    ici__1.icirnum = 1;
    ici__1.icirlen = 80;
    ici__1.iciunit = notexq;
/* Writing concatenation */
    i__1[0] = 2, a__1[0] = "(f";
    *(unsigned char *)&ch__2[0] = ifmt + 48;
    i__1[1] = 1, a__1[1] = ch__2;
    i__1[2] = 3, a__1[2] = ".1)";
    ici__1.icifmt = (s_cat(ch__1, a__1, i__1, &c__3, 6L), ch__1);
    s_wsfi(&ici__1);
    do_fio(&c__1, (char *)&xoff, (ftnlen)sizeof(real));
    e_wsfi();
/* Writing concatenation */
    i__2[0] = 1, a__2[0] = sq;
    i__2[1] = 4, a__2[1] = "off{";
    i__2[2] = ifmt, a__2[2] = notexq;
    i__2[3] = 3, a__2[3] = "pt}";
    s_cat(ch__3, a__2, i__2, &c__4, 88L);
    i__3 = ifmt + 8;
    addstr_(ch__3, &i__3, soutq, lsout, ifmt + 8, 80L);
    return 0;
} /* putshft_ */

/* Subroutine */ int outbar_(i__, jlast)
integer *i__, *jlast;
{
    /* System generated locals */
    address a__1[3];
    integer i__1[3];
    real r__1;
    char ch__1[9], ch__2[1], ch__3[11];
    cilist ci__1;

    /* Builtin functions */
    double r_lg10();
    /* Subroutine */ int s_cat();
    integer s_wsfe(), do_fio(), e_wsfe();

    /* Local variables */
    static integer nfmt;

    r__1 = *i__ + (float).5;
    nfmt = r_lg10(&r__1) + 2;
    if (*jlast + 5 + nfmt < 80) {
	ci__1.cierr = 0;
	ci__1.ciunit = 6;
/* Writing concatenation */
	i__1[0] = 5, a__1[0] = "(a5,i";
	*(unsigned char *)&ch__2[0] = nfmt + 48;
	i__1[1] = 1, a__1[1] = ch__2;
	i__1[2] = 3, a__1[2] = ",$)";
	ci__1.cifmt = (s_cat(ch__1, a__1, i__1, &c__3, 9L), ch__1);
	s_wsfe(&ci__1);
	do_fio(&c__1, "  Bar", 5L);
	do_fio(&c__1, (char *)&(*i__), (ftnlen)sizeof(integer));
	e_wsfe();
	*jlast = *jlast + 5 + nfmt;
    } else {
	ci__1.cierr = 0;
	ci__1.ciunit = 6;
/* Writing concatenation */
	i__1[0] = 7, a__1[0] = "(/,a5,i";
	*(unsigned char *)&ch__2[0] = nfmt + 48;
	i__1[1] = 1, a__1[1] = ch__2;
	i__1[2] = 3, a__1[2] = ",$)";
	ci__1.cifmt = (s_cat(ch__3, a__1, i__1, &c__3, 11L), ch__3);
	s_wsfe(&ci__1);
	do_fio(&c__1, "  Bar", 5L);
	do_fio(&c__1, (char *)&(*i__), (ftnlen)sizeof(integer));
	e_wsfe();
	*jlast = nfmt + 5;
    }
    return 0;
} /* outbar_ */

/* Subroutine */ int dotmov_(updot, rtdot, soutq, lsout, soutq_len)
real *updot, *rtdot;
char *soutq;
integer *lsout;
ftnlen soutq_len;
{
    /* System generated locals */
    address a__1[5], a__2[8], a__3[3];
    integer i__1[5], i__2[8], i__3[3];
    char ch__1[22], ch__2[1], ch__3[1], ch__4[37], ch__5[14];
    icilist ici__1;

    /* Builtin functions */
    /* Subroutine */ int s_cat();
    integer s_wsfi(), do_fio(), e_wsfi();

    /* Local variables */
    extern integer lfmt1_();
    static integer lnote;
    static char sq[1];
    extern /* Subroutine */ int addstr_();
    static integer lfmtup, lfmtrt;
    static char notexq[80];

    *(unsigned char *)sq = '\\';
    lfmtup = lfmt1_(updot);
    lfmtrt = lfmt1_(rtdot);
    ici__1.icierr = 0;
    ici__1.icirnum = 1;
    ici__1.icirlen = 80;
    ici__1.iciunit = notexq;
/* Writing concatenation */
    i__1[0] = 6, a__1[0] = "(a37,f";
    *(unsigned char *)&ch__2[0] = lfmtup + 48;
    i__1[1] = 1, a__1[1] = ch__2;
    i__1[2] = 7, a__1[2] = ".1,a2,f";
    *(unsigned char *)&ch__3[0] = lfmtrt + 48;
    i__1[3] = 1, a__1[3] = ch__3;
    i__1[4] = 7, a__1[4] = ".1,a14)";
    ici__1.icifmt = (s_cat(ch__1, a__1, i__1, &c__5, 22L), ch__1);
    s_wsfi(&ici__1);
/* Writing concatenation */
    i__2[0] = 1, a__2[0] = sq;
    i__2[1] = 12, a__2[1] = "makeatletter";
    i__2[2] = 1, a__2[2] = sq;
    i__2[3] = 3, a__2[3] = "def";
    i__2[4] = 1, a__2[4] = sq;
    i__2[5] = 12, a__2[5] = "C@Point#1#2{";
    i__2[6] = 1, a__2[6] = sq;
    i__2[7] = 6, a__2[7] = "PMXpt{";
    s_cat(ch__4, a__2, i__2, &c__8, 37L);
    do_fio(&c__1, ch__4, 37L);
    do_fio(&c__1, (char *)&(*updot), (ftnlen)sizeof(real));
    do_fio(&c__1, "}{", 2L);
    do_fio(&c__1, (char *)&(*rtdot), (ftnlen)sizeof(real));
/* Writing concatenation */
    i__3[0] = 2, a__3[0] = "}}";
    i__3[1] = 1, a__3[1] = sq;
    i__3[2] = 11, a__3[2] = "makeatother";
    s_cat(ch__5, a__3, i__3, &c__3, 14L);
    do_fio(&c__1, ch__5, 14L);
    e_wsfi();

/*   Example of string just created: */
/*   \makeatletter\def\C@Point#1#2{\PMXpt{.5}{.5}}\makeatother\ */

    lnote = lfmtup + 53 + lfmtrt;
    addstr_(notexq, &lnote, soutq, lsout, lnote, 80L);
    return 0;
} /* dotmov_ */

integer lfmt1_(x)
real *x;
{
    /* System generated locals */
    integer ret_val;
    real r__1;

    /* Builtin functions */
    double r_sign(), r_lg10();


/*  Computes total length of an "f" format with one decimal place. */
/*  First round to nearest 0.1 */

    if (dabs(*x) < (float).001) {
	ret_val = 2;
    } else {
	r__1 = (integer) (dabs(*x) * 10 + (float).5) * (float).1;
	*x = r_sign(&r__1, x);
	r__1 = dabs(*x) * 1000 + (float).001;
	ret_val = (integer) r_lg10(&r__1);
	if (*x < (float)0.) {
	    ++ret_val;
	}
    }
    return ret_val;
} /* lfmt1_ */

/* Subroutine */ int getorn_(lineq, iccount, iornq, iornq1, ornrpt, noffseg, 
	ip, ivx, noxtup, notcrd, nole, lineq_len)
char *lineq;
integer *iccount, *iornq, *iornq1;
logical *ornrpt;
integer *noffseg, *ip, *ivx;
logical *noxtup, *notcrd;
integer *nole;
ftnlen lineq_len;
{
    /* System generated locals */
    real r__1;

    /* Builtin functions */
    integer i_indx(), s_wsle(), do_lio(), e_wsle();
    /* Subroutine */ int s_stop();

    /* Local variables */
    static real fnum;
    static integer korn;
    static char durq[1], charq[1];
    static integer iorni;
    extern integer ni_();
    static logical negseg;
    extern /* Subroutine */ int getchar_(), readnum_();
    static integer iofforn;
    static real xofforn;

    /* Fortran I/O blocks */
    static cilist io___940 = { 0, 6, 0, 0, 0 };



/*  iornq: Main note.  Do not alter if chord note, except turn on bit 23 
*/
/*  iornq1: Prior note, in case orn rpt toggle is on */
/*  iorni: Internal use, 1st 21 bits of iornq or icrdorn, dep. on notcrd. 
*/
/*  noffseg: horiz. offset for segno */
/* nole: level of note w/ orn, used to ID the note/orn if there's a level 
shift.*/


/* Bits 0-13: (stmgx+Tupf._), 14: Down fermata, was F, 15: Trill w/o "tr",
 was U*/
/*  16-18 Editorial sharp, flat, natural "oes,f,n"; 19-20: >^, 21 TBD */

/* Set signal on main note that some note at this time has ornament.  ONLY
 used*/
/*  in beamstrt to activate further tests fo whether ihornb is needed. */

    *iornq = bit_set(*iornq,23);

/*  Isolate 21 bits defining exisiting ornaments */

    if (*notcrd) {
	iorni = 4194303 & *iornq;
    } else {
	iorni = 4194303 & comtrill_1.icrdorn[comtrill_1.ncrd - 1];
    }
    getchar_(lineq, iccount, charq, 128L, 1L);
    korn = i_indx("stmgx+Tupf._)e:XXX>^", charq, 20L, 1L);
    if (korn != 15) {
	iorni = bit_set(iorni,korn);
    }

/* Note that korn=0 => charq='(', and we set bit 0.  if "e" (14), alter la
ter.*/
/*  When this if-block is done, korn will = bit# of actual ornament.= */

    if (korn == 15) {

/* Turn off repeated ornament ('o:'), Replicate bits 0-3,5-15,19-20 pr
ev iornq*/

	iorni |= *iornq1 & 1638383;
	*ornrpt = FALSE_;
	getchar_(lineq, iccount, durq, 128L, 1L);

/*  durq will be ' ' */

    } else if (korn == 14) {

/*  Editorial accidental */

	getchar_(lineq, iccount, durq, 128L, 1L);
	korn = i_indx("sfn", durq, 3L, 1L) + 15;
	iorni = bit_set(bit_clear(iorni,14),korn);
	getchar_(lineq, iccount, durq, 128L, 1L);
    } else if (korn == 4 && *noxtup) {

/* segno. Check in pmxa for just 1/block & notcrd.  Get horiz. offset 
in points*/

	*noffseg = 0;
	negseg = FALSE_;
	getchar_(lineq, iccount, durq, 128L, 1L);
	if (*(unsigned char *)durq != ' ') {

/*  Segno shift is specified */

	    if (*(unsigned char *)durq == '-') {
		negseg = TRUE_;
		getchar_(lineq, iccount, durq, 128L, 1L);
	    }
	    readnum_(lineq, iccount, durq, &fnum, 128L, 1L);
	    *noffseg = fnum + (float).1;
	    if (negseg) {
		*noffseg = -(*noffseg);
	    }
	}
    } else if (korn == 7) {

/* Trill.  Check in pmxa for notcrd.  Default is 1 noteskip long, with
 "tr"*/

	++comtrill_1.ntrill;
	comtrill_1.ivtrill[comtrill_1.ntrill - 1] = *ivx;
	comtrill_1.iptrill[comtrill_1.ntrill - 1] = *ip;
	comtrill_1.xnsktr[comtrill_1.ntrill - 1] = (float)1.;
	getchar_(lineq, iccount, durq, 128L, 1L);
	if (*(unsigned char *)durq == 't') {

/*  Convert to new internal symbol for non-'"tr" trill */

	    korn = 15;
	    iorni = bit_set(bit_clear(iorni,7),15);
	    getchar_(lineq, iccount, durq, 128L, 1L);
	}
	if (i_indx("0123456789.", durq, 11L, 1L) > 0) {

/*  We have a number for the length */

	    readnum_(lineq, iccount, durq, &comtrill_1.xnsktr[
		    comtrill_1.ntrill - 1], 128L, 1L);
	}
    } else if (korn == 10 && *noxtup) {

/*  Fermata */

	getchar_(lineq, iccount, durq, 128L, 1L);
	if (*(unsigned char *)durq == 'd') {
	    korn = 14;
	    iorni = bit_set(bit_clear(iorni,10),14);
	    getchar_(lineq, iccount, durq, 128L, 1L);
	}
    } else {
	getchar_(lineq, iccount, durq, 128L, 1L);
    }
    if (i_indx("+- :", durq, 4L, 1L) == 0) {
	s_wsle(&io___940);
	do_lio(&c__9, &c__1, "Unexpected character at end of ornament: ", 41L)
		;
	do_lio(&c__9, &c__1, durq, 1L);
	e_wsle();
	s_stop("1", 1L);
    }
    if (i_indx("+-", durq, 2L, 1L) > 0) {

/*  Shift ornament up or down */

	++comtrill_1.nudorn;

/*  Set bit 25 in iorni as a signal.  This may not really be necessary
. */

	iorni = bit_set(iorni,25);

/* Assemble info to put in kudorn(nudorn) Bits 0-7:ip, 8-11:ivx, 12-18
:nolev,*/
/*     19-24: type of ornament to be shifted, 25-30: shift+32 */

	xofforn = (real) (44 - *(unsigned char *)durq);
	++(*iccount);
	readnum_(lineq, iccount, durq, &fnum, 128L, 1L);
	r__1 = xofforn * fnum;
	iofforn = ni_(&r__1);
	comtrill_1.kudorn[comtrill_1.nudorn - 1] = *ip + (*ivx << 8) + (*nole 
		<< 12) + (korn << 19) + (iofforn + 32 << 25);
    } else if (*(unsigned char *)durq == ':') {

/*  Turn on  repeated ornaments */

	*ornrpt = TRUE_;
    }
    if (*notcrd) {
	*iornq |= iorni;
    } else {
	comtrill_1.icrdorn[comtrill_1.ncrd - 1] |= iorni;
    }
    return 0;
} /* getorn_ */

/*      subroutine report(nsdat,isdat1,isdat2) */
/*      integer*4 isdat1(202),isdat2(202) */
/*      write(*,'(a)') */
/*     *  ' isd on? ivx  ip  id ud1 ud2 ndx ivo iho lev crd lhd rhd' */
/*      do 1 isdat = 1 , nsdat */
/*        isdata = isdat1(isdat) */
/*        ionoff = igetbits(isdata,1,11) */
/*        ivx = iand(7,isdata) */
/*        ip = igetbits(isdata,8,3) */
/*        idcode = igetbits(isdata,7,19) */
/*        iud1 = igetbits(isdata,1,26) */
/*        iud2 = igetbits(isdata,1,27) */
/*        ndxslur = igetbits(isdata,4,28) */
/*        isdatb = isdat2(isdat) */
/*        ivo = igetbits(isdatb,6,6)-32 */
/*        iho = igetbits(isdatb,7,12)-64 */
/*        lev = igetbits(isdatb,7,19) */
/*        icrd = igetbits(isdatb,1,0) */
/*        lhd = igetbits(isdatb,1,1) */
/*        irhd = igetbits(isdatb,7,2) */
/*        write(*,'(16i4)') isdat,ionoff,ivx,ip,idcode,iud1,iud2,ndxslur, */
/*     *                     ivo,iho,lev,icrd,lhd,irhd */
/* 1     continue */
/*      print* */
/*      return */
/*      end */
integer igetbits_(isdata, iwidbit, ishift)
integer *isdata, *iwidbit, *ishift;
{
    /* System generated locals */
    integer ret_val;

    /* Builtin functions */
    integer pow_ii(), lbit_shift();


/* Extracts integer given by iwidbit bits of isdata, shifted by ishift, an
d*/
/*  then added to ioff */

    ret_val = pow_ii(&c__2, iwidbit) - 1 & lbit_shift(*isdata, -(*ishift));
    return ret_val;
} /* igetbits_ */

/* Subroutine */ int setbits_(isdata, iwidbit, ishift, ivalue)
integer *isdata, *iwidbit, *ishift, *ivalue;
{
    /* Builtin functions */
    integer pow_ii(), s_wsle(), do_lio(), e_wsle(), lbit_shift();

    /* Local variables */
    static integer ibase;

    /* Fortran I/O blocks */
    static cilist io___944 = { 0, 6, 0, 0, 0 };



/*  Sets iwidbits of isdata, shifted by ishift, to ivalue */

    ibase = pow_ii(&c__2, iwidbit) - 1;
    if (*ivalue > ibase) {
	s_wsle(&io___944);
	do_lio(&c__9, &c__1, "WARNING in setbits: ivalue > ibase", 34L);
	e_wsle();
    }
    *isdata = ~ lbit_shift(ibase, *ishift) & *isdata;
    *isdata |= lbit_shift(*ivalue, *ishift);
    return 0;
} /* setbits_ */

/* Subroutine */ int precrd_(ivx, ip, nolevm)
integer *ivx, *ip, *nolevm;
{
    /* System generated locals */
    integer i__1;

    /* Builtin functions */
    integer lbit_shift(), s_wsle(), e_wsle(), do_lio();
    /* Subroutine */ int s_stop();

    /* Local variables */
    extern integer igetbits_();
    static integer nolev;

    /* Fortran I/O blocks */
    static cilist io___945 = { 0, 6, 0, 0, 0 };
    static cilist io___946 = { 0, 6, 0, 0, 0 };
    static cilist io___948 = { 0, 6, 0, 0, 0 };
    static cilist io___949 = { 0, 6, 0, 0, 0 };



/* Analyzes chords, data to be used with slurs on chords and plain chords.
*/

    i__1 = comtrill_1.ncrd;
    for (comtrill_1.icrd1 = 1; comtrill_1.icrd1 <= i__1; ++comtrill_1.icrd1) {
	if ((255 & comtrill_1.icrdat[comtrill_1.icrd1 - 1]) == *ip && (15 & 
		lbit_shift(comtrill_1.icrdat[comtrill_1.icrd1 - 1], -8L)) == *
		ivx) {
	    goto L2;
	}
/* L1: */
    }
    s_wsle(&io___945);
    e_wsle();
    s_wsle(&io___946);
    do_lio(&c__9, &c__1, "Failed to find first chord note!", 32L);
    e_wsle();
    s_stop("", 0L);
L2:
    comtrill_1.maxlev = *nolevm;
    comtrill_1.minlev = *nolevm;
    i__1 = comtrill_1.ncrd;
    for (comtrill_1.icrd2 = comtrill_1.icrd1; comtrill_1.icrd2 <= i__1; 
	    ++comtrill_1.icrd2) {

/*  Exit loop if last note in this chord */

	nolev = igetbits_(&comtrill_1.icrdat[comtrill_1.icrd2 - 1], &c__7, &
		c__12);
	comtrill_1.maxlev = max(comtrill_1.maxlev,nolev);
	comtrill_1.minlev = min(comtrill_1.minlev,nolev);
	if (comtrill_1.icrd2 == comtrill_1.ncrd) {
	    goto L4;
	}
	if (igetbits_(&comtrill_1.icrdat[comtrill_1.icrd2], &c__8, &c__0) != *
		ip || igetbits_(&comtrill_1.icrdat[comtrill_1.icrd2], &c__4, &
		c__8) != *ivx) {
	    goto L4;
	}
/* L3: */
    }
    s_wsle(&io___948);
    e_wsle();
    s_wsle(&io___949);
    do_lio(&c__9, &c__1, "Failed to find last chord note!", 31L);
    e_wsle();
    s_stop("", 0L);
L4:

/*  Now icrd1, icrd2 define range of icrd for this chord. */

    return 0;
} /* precrd_ */

