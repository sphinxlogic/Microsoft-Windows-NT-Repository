/* pmxa.f -- translated by f2c (version 19961017).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/

#include "f2c.h"

/* Common Block Declarations */

struct {
    integer nnodur;
    real wminnh[500];
    integer nnpd[2000];
    real durb[2000];
    integer nptr[500], ibarcnt, ieminb[500], iemaxb[500], mbrest, ibarmbr, 
	    ibaroff;
    real udsp[500], wheadpt;
} comnotes_;

#define comnotes_1 comnotes_

struct compage_1_ {
    real widthpt, ptheight;
    integer nsyst, nflb, ibarflb[41], isysflb[41], npages, nfpb, ipagfpb[11], 
	    isysfpb[11];
    logical usefig;
    real fintstf, gintstf;
};

#define compage_1 (*(struct compage_1_ *) &compage_)

struct {
    integer nkeys, ibrkch[14], newkey[14];
    logical iskchb;
    integer idsig, isig1;
    logical kchmid[14], ornrpt, shifton, barend;
} comkeys_;

#define comkeys_1 comkeys_

struct {
    logical lastchar, fbon, issegno;
    integer ihead;
    logical isheadr;
    integer nline;
    logical isvolt, inchord;
} comget_;

#define comget_1 comget_

struct {
    integer iv, list[800]	/* was [4][200] */, nnl[7], nv, ibar, ipl[
	    1400]	/* was [7][200] */, mtrnuml, nodur[1400]	/* 
	    was [7][200] */, jn, lenbar, iccount, nbars, itsofar[7], nib[105]	
	    /* was [7][15] */, nn[7];
    logical rest[1400]	/* was [7][200] */;
    integer lenbr0, lenbr1;
    logical firstline, newmeter;
} all_;

#define all_1 all_

struct {
    real elskb;
} linecom_;

#define linecom_1 linecom_

struct cblock_1_ {
    real etatop, etabot, etait, etatc, etacs1, hgtin, hgtti, hgtco, xilbn, 
	    xilbtc, xilhdr, xilfig, a, b;
    integer inbothd, inhnoh;
};

#define cblock_1 (*(struct cblock_1_ *) &cblock_)

struct {
    integer nvmx[7], ivmx[14]	/* was [7][2] */, ivx;
    real fbar;
} commvl_;

#define commvl_1 commvl_

struct {
    integer macnum;
    logical mrecord, mplay;
    integer macuse, icchold;
    char lnholdq[128];
    logical endmac;
} commac_;

#define commac_1 commac_

/* Initialized data */

struct {
    real e_1[2];
    integer fill_2[111];
    } compage_ = { (float)524., (float)740. };

struct {
    real e_1[14];
    integer e_2[2];
    } cblock_ = { (float).5, (float).25, (float).4, (float).4, (float).2, (
	    float)12., (float)21., (float)12., (float)4., (float)1.6, (float)
	    5., (float)5.7, (float)1.071, (float)2.714, 16, 16 };


/* Table of constant values */

static integer c__9 = 9;
static integer c__1 = 1;
static integer c__2 = 2;
static integer c__3 = 3;
static integer c__4 = 4;
static integer c__128 = 128;
static integer c_n1 = -1;
static real c_b681 = (float)2.;
static integer c__5 = 5;
static integer c__0 = 0;

/* ccccccccccccccccccccccccccccccccccccccccccccccc */
/* c                                            cc */
/* c pmxa.for Version 1.3.6 4/3/98              cc */
/* c                                            cc */
/* c A production of Dr. Don's PC and           cc */
/* c Harpsichord Emporium (dsimons@logicon.com) cc */
/* c                                            cc */
/* c This is noware: No fee, no guarantee.      cc */
/* c                                            cc */
/* ccccccccccccccccccccccccccccccccccccccccccccccc */
/* c */
/* c  Need to consider X spaces in xtuplets when getting poenom, and */
/* c      maybe fbar? */
/* c */
/* c  Known changes since pmxa. Version 1.1b (see pmxb for longer list) */
/* c */
/* c  Check ID codes for slurs. */
/* c  Redefine iemin to include ALL notes groups as bitmap. */
/* c  Version 1.24 still does not have details for spacing/positioning */
/*c    arpeggios if there are accidentals or shifted notes or crowded scores.
*/
/* c  Fix problem in 1.22 with arpeggios across multi-line staves */
/* c  Fix problem in 1.22 with flat key signatures */
/* c  Read setup data as strings */
/* c  Warning for octave designation plus +/- */
/* c  Don't pause for volta warning, */
/* c  Macros */
/* c  Correct fsyst to account for transposition and key changes. */
/* c  Check for nbars > nsyst */
/* c */
/* cccccccccccccccccccccccccccccccccc */
/* Main program */ MAIN__()
{
    /* Initialized data */

    static real a20 = (float).3;
    static real whead20 = (float).3;
    static real abig20 = (float).38;
    static real wtimesig = (float).72;
    static real wclef = (float).8;
    static real wkeysig = (float).28;

    /* System generated locals */
    address a__1[2];
    integer i__1[2], i__2, i__3, i__4, i__5, i__6, i__7;
    real r__1, r__2, r__3, r__4;
    doublereal d__1, d__2;
    char ch__1[28];
    olist o__1;
    cllist cl__1;

    /* Builtin functions */
    integer s_wsle(), do_lio(), e_wsle(), s_rsfe(), do_fio(), e_rsfe(), 
	    i_indx();
    /* Subroutine */ int s_copy(), s_cat();
    integer f_open();
    /* Subroutine */ int s_stop();
    integer s_wsfe(), e_wsfe();
    double pow_dd();
    integer f_clos();

    /* Local variables */
    static integer nacc;
    static real diff;
    static integer iflb, ifig, ifpb;
    extern /* Subroutine */ int makeabar_();
    static integer ioff;
    extern doublereal feon_();
    static real eonk, elsk[500];
    static integer idot, ikey;
    static real elss[125];
    static logical loop;
    static real xmtrnum0, heightil, wdpt;
    static integer iptr;
    static real diff1;
    static integer ibar1;
    static real elsstarg, c__, d__;
    static integer j, ipage, lbase;
    static real celsk[501];
    static logical newmb[500];
    static char basenameq[24];
    static integer ibars, iemin;
    static real dtmin, dtmax, xelsk, ewmxk, wmins;
    static integer ibarb4;
    static real fsyst;
    static integer isyst;
    static real elmin0, elmin1;
    static integer musicsize, ip, nomnsystp, kv;
    static real abigpt, xn, omegag, facins, glueil;
    static integer nbarss[125];
    extern /* Subroutine */ int getset_();
    static real fracindent;
    static integer jprntb;
    extern /* Subroutine */ int outbar_();
    static real poenom;
    static integer mtrdnp, noinst, mtrnmp, nshort;
    static real wminpt, celskb4, xiltxt;
    static integer nsystp;
    static real wsyspt, apt;
    static integer lenbeat, nns, lastbar[126];
    static real xilfrac;
    static logical bottreb;
    static integer mtrdenl;
    extern integer ifnodur_();
    extern /* Subroutine */ int getnote_();
    static real elssold;
    static integer lenmult;
    static real sumelsk;
    static integer key1, key2, nsystpp;

    /* Fortran I/O blocks */
    static cilist io___2 = { 0, 6, 0, 0, 0 };
    static cilist io___3 = { 0, 5, 0, "(a)", 0 };
    static cilist io___21 = { 0, 6, 0, 0, 0 };
    static cilist io___30 = { 0, 6, 0, "(/,a19,i4,a1,i4)", 0 };
    static cilist io___35 = { 0, 6, 0, 0, 0 };
    static cilist io___37 = { 0, 6, 0, 0, 0 };
    static cilist io___38 = { 0, 6, 0, 0, 0 };
    static cilist io___39 = { 0, 6, 0, 0, 0 };
    static cilist io___41 = { 0, 12, 0, "(a)", 0 };
    static cilist io___42 = { 0, 12, 0, 0, 0 };
    static cilist io___43 = { 0, 12, 0, "(8f10.5/f10.5,3i5)", 0 };
    static cilist io___44 = { 0, 12, 0, 0, 0 };
    static cilist io___58 = { 0, 12, 0, 0, 0 };
    static cilist io___74 = { 0, 12, 0, "(i5)", 0 };
    static cilist io___94 = { 0, 6, 0, 0, 0 };
    static cilist io___95 = { 0, 6, 0, 0, 0 };
    static cilist io___97 = { 0, 12, 0, "(1pe12.5/i5,4e12.3,i9)", 0 };
    static cilist io___98 = { 0, 13, 0, "(i5)", 0 };
    static cilist io___99 = { 0, 6, 0, "(/,a)", 0 };


    jprntb = 81;
    commac_1.macuse = 0;
    comkeys_1.ornrpt = FALSE_;
    commac_1.mrecord = FALSE_;
    commac_1.mplay = FALSE_;
    comget_1.lastchar = FALSE_;
    for (comnotes_1.ibarcnt = 1; comnotes_1.ibarcnt <= 500; 
	    ++comnotes_1.ibarcnt) {
	comnotes_1.udsp[comnotes_1.ibarcnt - 1] = (float)0.;
	comnotes_1.wminnh[comnotes_1.ibarcnt - 1] = (float)-1.;
/* L42: */
    }
    s_wsle(&io___2);
    do_lio(&c__9, &c__1, "Please type a basename (<9 characters, no dots): ", 
	    49L);
    e_wsle();
    s_rsfe(&io___3);
    do_fio(&c__1, basenameq, 24L);
    e_rsfe();
    idot = i_indx(basenameq, ".", 24L, 1L);
    if (idot != 0) {
	s_copy(basenameq, basenameq, 24L, idot - 1);
    }
    lbase = i_indx(basenameq, " ", 24L, 1L) - 1;
    o__1.oerr = 0;
    o__1.ounit = 10;
    o__1.ofnmlen = lbase + 4;
/* Writing concatenation */
    i__1[0] = lbase, a__1[0] = basenameq;
    i__1[1] = 4, a__1[1] = ".pmx";
    s_cat(ch__1, a__1, i__1, &c__2, 28L);
    o__1.ofnm = ch__1;
    o__1.orl = 0;
    o__1.osta = 0;
    o__1.oacc = 0;
    o__1.ofm = 0;
    o__1.oblnk = 0;
    f_open(&o__1);
    getset_(&all_1.nv, &noinst, &all_1.mtrnuml, &mtrdenl, &mtrnmp, &mtrdnp, &
	    xmtrnum0, comkeys_1.newkey, &compage_1.npages, &compage_1.nsyst, &
	    musicsize, &fracindent, &bottreb);

/*  isig1 will be changed in getnote if there is a transposition */

    comkeys_1.isig1 = comkeys_1.newkey[0];
    if (compage_1.npages > compage_1.nsyst) {
	s_wsle(&io___21);
	do_lio(&c__9, &c__1, "npages > nsyst in input.  Please fix the input."
		, 47L);
	e_wsle();
	s_stop("1", 1L);
    }

/*  fbar = afterruleskip/elemskip */
/*  apt = width of small accidental + space in points (= 6 at 20pt) */
/*  abigpt = width of big accidental + space in points (= 7.6 at 20pt) */

    commvl_1.fbar = (float)1.;
    apt = a20 * musicsize;
    abigpt = abig20 * musicsize;
    comnotes_1.wheadpt = whead20 * musicsize;
    ifig = 0;
    compage_1.usefig = TRUE_;
    lenbeat = ifnodur_(&mtrdenl, "x", 1L);
    lenmult = 1;
    if (mtrdenl == 2) {
	lenbeat = 16;
	lenmult = 2;
    }
    all_1.lenbr1 = lenmult * all_1.mtrnuml * lenbeat;
    all_1.lenbr0 = lenmult * xmtrnum0 * lenbeat + (float).1;
    all_1.mtrnuml = 0;
    if (all_1.lenbr0 != 0) {
	comnotes_1.ibaroff = 1;
	all_1.lenbar = all_1.lenbr0;
    } else {
	comnotes_1.ibaroff = 0;
	all_1.lenbar = all_1.lenbr1;
    }
    comnotes_1.ibarcnt = 0;
    comnotes_1.nptr[0] = 1;
    all_1.iccount = 128;
    compage_1.nflb = 0;
    compage_1.nfpb = 0;
    compage_1.ipagfpb[0] = 1;
    compage_1.isysfpb[0] = 1;
    compage_1.ibarflb[0] = 1;
    compage_1.isysflb[0] = 1;

/*  Initialize for loop over lines */

    comkeys_1.nkeys = 1;
    comkeys_1.ibrkch[0] = 1;
    comkeys_1.shifton = FALSE_;
    all_1.firstline = TRUE_;
    all_1.newmeter = FALSE_;
    comget_1.inchord = FALSE_;
    comget_1.ihead = 0;
    comget_1.isheadr = FALSE_;
    comkeys_1.idsig = 0;
    compage_1.fintstf = (float)-1.;
    compage_1.gintstf = (float)1.;
L30:
    loop = TRUE_;
    comkeys_1.iskchb = FALSE_;
    comget_1.issegno = FALSE_;
    all_1.nbars = 0;
    comnotes_1.ibarmbr = 0;
/* L3: */
    i__2 = all_1.nv;
    for (all_1.iv = 1; all_1.iv <= i__2; ++all_1.iv) {
	commvl_1.nvmx[all_1.iv - 1] = 1;
	commvl_1.ivmx[all_1.iv - 1] = all_1.iv;
	all_1.itsofar[all_1.iv - 1] = 0;
	all_1.nnl[all_1.iv - 1] = 0;
	for (j = 1; j <= 200; ++j) {
	    all_1.rest[all_1.iv + j * 7 - 8] = FALSE_;
/* L5: */
	}
/* L4: */
    }
    all_1.iv = 1;
    commvl_1.ivx = 1;
    comget_1.fbon = FALSE_;
    comkeys_1.barend = FALSE_;
    comget_1.isvolt = FALSE_;
L2:
    if (loop) {

/* Within this short loop, nv voices are filled up for the duration of
 a block.*/
/*  On exit (loop=.false.) the following are set: nnl(nv),itsofar(nv) 
*/
/*  nodur(..),rest(..).  nnl will later be */
/*  increased and things slid around as accidental skips are added. */

	getnote_(&loop, &ifig);
	if (comget_1.lastchar) {
	    goto L20;
	}
	goto L2;
    }
    i__2 = all_1.nbars;
    for (all_1.ibar = 1; all_1.ibar <= i__2; ++all_1.ibar) {
	++comnotes_1.ibarcnt;
	comnotes_1.nptr[comnotes_1.ibarcnt] = comnotes_1.nptr[
		comnotes_1.ibarcnt - 1];
	newmb[comnotes_1.ibarcnt - 1] = FALSE_;
	if (all_1.newmeter && all_1.ibar == 1) {
	    newmb[comnotes_1.ibarcnt - 1] = TRUE_;
	}

/* Above is only for spacing calcs later on.  Remember new meter can o
nly occur*/
/*  at START of a new input line (ibar = 1) */

	if (all_1.ibar != comnotes_1.ibarmbr) {
/*         print*,'Now processing bar #',ibarcnt-ibaroff */
	    i__3 = comnotes_1.ibarcnt - comnotes_1.ibaroff;
	    outbar_(&i__3, &jprntb);
	} else {
/*         write(*,'(a19,i4,a1,i4)')' Multibar rest, bars', */
	    s_wsfe(&io___30);
	    do_fio(&c__1, " Multibar rest, bars", 20L);
	    i__3 = comnotes_1.ibarcnt - comnotes_1.ibaroff;
	    do_fio(&c__1, (char *)&i__3, (ftnlen)sizeof(integer));
	    do_fio(&c__1, "-", 1L);
	    i__4 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
		    comnotes_1.mbrest - 1;
	    do_fio(&c__1, (char *)&i__4, (ftnlen)sizeof(integer));
	    e_wsfe();
	    comnotes_1.ibaroff = comnotes_1.ibaroff - comnotes_1.mbrest + 1;

	    jprntb = 0;

	}
	if (all_1.firstline && all_1.lenbr0 != 0) {
	    if (all_1.ibar == 1) {
		all_1.lenbar = all_1.lenbr0;
	    } else {
		all_1.lenbar = all_1.lenbr1;
	    }
	}
	if (all_1.ibar > 1) {

/*  For bars after first, slide all stuff down to beginning of arr
ays */

	    i__3 = all_1.nv;
	    for (all_1.iv = 1; all_1.iv <= i__3; ++all_1.iv) {
		i__4 = commvl_1.nvmx[all_1.iv - 1];
		for (kv = 1; kv <= i__4; ++kv) {
		    commvl_1.ivx = commvl_1.ivmx[all_1.iv + kv * 7 - 8];
		    ioff = all_1.nib[commvl_1.ivx + (all_1.ibar - 1) * 7 - 8];
		    i__5 = all_1.nib[commvl_1.ivx + all_1.ibar * 7 - 8] - 
			    ioff;
		    for (ip = 1; ip <= i__5; ++ip) {
			all_1.nodur[commvl_1.ivx + ip * 7 - 8] = all_1.nodur[
				commvl_1.ivx + (ip + ioff) * 7 - 8];
			all_1.rest[commvl_1.ivx + ip * 7 - 8] = all_1.rest[
				commvl_1.ivx + (ip + ioff) * 7 - 8];
/* L12: */
		    }
/* L11: */
		}
	    }
	}
	i__4 = all_1.nv;
	for (all_1.iv = 1; all_1.iv <= i__4; ++all_1.iv) {
	    i__3 = commvl_1.nvmx[all_1.iv - 1];
	    for (kv = 1; kv <= i__3; ++kv) {
		ioff = 0;
		if (all_1.ibar > 1) {
		    ioff = all_1.nib[commvl_1.ivmx[all_1.iv + kv * 7 - 8] + (
			    all_1.ibar - 1) * 7 - 8];
		}
/* L67: */
	    }
	}
	makeabar_();
	elsk[comnotes_1.ibarcnt - 1] = linecom_1.elskb;
/* L10: */
    }
    all_1.firstline = FALSE_;
    all_1.newmeter = FALSE_;
    goto L30;
L20:

/* Vertical analysis. */

    if (compage_1.npages == 0) {
	if (compage_1.nsyst == 0) {
	    s_wsle(&io___35);
	    do_lio(&c__9, &c__1, "When npages=0, must set nsyst=bars/syst, n\
ot 0", 46L);
	    e_wsle();
	    s_stop("1", 1L);
	}
	compage_1.nsyst = (comnotes_1.ibarcnt - 1) / compage_1.nsyst + 1;
	if (all_1.nv == 1) {
	    nsystpp = 12;
	} else if (all_1.nv == 2) {
	    nsystpp = 7;
	} else if (all_1.nv == 3) {
	    nsystpp = 5;
	} else if (all_1.nv == 4) {
	    nsystpp = 3;
	} else {
	    nsystpp = 2;
	}
	compage_1.npages = (compage_1.nsyst - 1) / nsystpp + 1;
    }

/*  Check nsyst vs ibarcnt */

    if (compage_1.nsyst > comnotes_1.ibarcnt) {
	s_wsle(&io___37);
	e_wsle();
	s_wsle(&io___38);
	do_lio(&c__9, &c__1, "nsyst,ibarcnt:", 14L);
	do_lio(&c__3, &c__1, (char *)&compage_1.nsyst, (ftnlen)sizeof(integer)
		);
	do_lio(&c__3, &c__1, (char *)&comnotes_1.ibarcnt, (ftnlen)sizeof(
		integer));
	e_wsle();
	s_wsle(&io___39);
	do_lio(&c__9, &c__1, "There are more systems than bars.", 33L);
	e_wsle();
	s_stop("1", 1L);
    }
    ++compage_1.nflb;
    compage_1.ibarflb[compage_1.nflb] = comnotes_1.ibarcnt + 1;
    compage_1.isysflb[compage_1.nflb] = compage_1.nsyst + 1;
    heightil = compage_1.ptheight * (float)4. / musicsize;

/*  Set up dummy forced page after last real one */

    ++compage_1.nfpb;
    compage_1.ipagfpb[compage_1.nfpb] = compage_1.npages + 1;
    compage_1.isysfpb[compage_1.nfpb] = compage_1.nsyst + 1;
    o__1.oerr = 0;
    o__1.ounit = 12;
    o__1.ofnmlen = 10;
    o__1.ofnm = "pmxtex.dat";
    o__1.orl = 0;
    o__1.osta = 0;
    o__1.oacc = 0;
    o__1.ofm = 0;
    o__1.oblnk = 0;
    f_open(&o__1);
    s_wsfe(&io___41);
    do_fio(&c__1, basenameq, lbase);
    e_wsfe();
    s_wsle(&io___42);
    do_lio(&c__3, &c__1, (char *)&lbase, (ftnlen)sizeof(integer));
    e_wsle();

/* Pass to pmxb the initial signature, including effect of transposition. 
*/

    s_wsfe(&io___43);
    do_fio(&c__1, (char *)&commvl_1.fbar, (ftnlen)sizeof(real));
    do_fio(&c__1, (char *)&apt, (ftnlen)sizeof(real));
    do_fio(&c__1, (char *)&abigpt, (ftnlen)sizeof(real));
    do_fio(&c__1, (char *)&comnotes_1.wheadpt, (ftnlen)sizeof(real));
    do_fio(&c__1, (char *)&cblock_1.etait, (ftnlen)sizeof(real));
    do_fio(&c__1, (char *)&cblock_1.etatc, (ftnlen)sizeof(real));
    do_fio(&c__1, (char *)&cblock_1.etacs1, (ftnlen)sizeof(real));
    do_fio(&c__1, (char *)&cblock_1.etatop, (ftnlen)sizeof(real));
    do_fio(&c__1, (char *)&cblock_1.etabot, (ftnlen)sizeof(real));
    do_fio(&c__1, (char *)&cblock_1.inbothd, (ftnlen)sizeof(integer));
    do_fio(&c__1, (char *)&cblock_1.inhnoh, (ftnlen)sizeof(integer));
    do_fio(&c__1, (char *)&comkeys_1.isig1, (ftnlen)sizeof(integer));
    e_wsfe();
    s_wsle(&io___44);
    do_lio(&c__3, &c__1, (char *)&compage_1.npages, (ftnlen)sizeof(integer));
    do_lio(&c__4, &c__1, (char *)&compage_1.widthpt, (ftnlen)sizeof(real));
    do_lio(&c__4, &c__1, (char *)&compage_1.ptheight, (ftnlen)sizeof(real));
    do_lio(&c__3, &c__1, (char *)&compage_1.nsyst, (ftnlen)sizeof(integer));
    e_wsle();
    i__2 = compage_1.nfpb;
    for (ifpb = 1; ifpb <= i__2; ++ifpb) {

/*  Each time thru this loop is like a single score with several pages
 */

	compage_1.npages = compage_1.ipagfpb[ifpb] - compage_1.ipagfpb[ifpb - 
		1];
	compage_1.nsyst = compage_1.isysfpb[ifpb] - compage_1.isysfpb[ifpb - 
		1];
	nomnsystp = (compage_1.nsyst - 1) / compage_1.npages + 1;
	nshort = nomnsystp * compage_1.npages - compage_1.nsyst;
	i__3 = compage_1.npages;
	for (ipage = 1; ipage <= i__3; ++ipage) {
	    nsystp = nomnsystp;
	    if (ipage <= nshort) {
		--nsystp;
	    }
	    xilfrac = (float)0.;
	    xiltxt = (float)0.;
	    if (ipage == 1 && comget_1.ihead > 0) {

/* Needn't zero out ihead after printing titles if we only all
ow titles at top?*/

		if ((comget_1.ihead & 1) == 1) {
		    xiltxt += cblock_1.hgtin * 4 / musicsize;
		    xilfrac += cblock_1.etait;
		}
		if ((comget_1.ihead & 2) == 2) {
		    xiltxt += cblock_1.hgtti * 4 / musicsize;
		    xilfrac += cblock_1.etatc;
		}
		if ((comget_1.ihead & 4) == 4) {
		    xiltxt += cblock_1.hgtco * 4 / musicsize;
		    xilfrac += cblock_1.etacs1;
		} else {

/* Use double the title-composer space if there is no comp
oser */

		    xilfrac += cblock_1.etatc;
		}
	    }
	    d__ = xilfrac + nsystp - 1 + cblock_1.etatop + cblock_1.etabot;
	    c__ = (real) (nsystp * (all_1.nv - 1));
	    xn = heightil - xiltxt - (nsystp << 2) * all_1.nv - (nsystp - 1) *
		     cblock_1.xilbn;
	    if (bottreb) {
		xn -= (nsystp - 1) * cblock_1.xilbtc;
	    }
	    if (comget_1.ihead == 0 && comget_1.isheadr) {
		xn -= cblock_1.xilhdr;
	    }
	    if (ifig == 1) {
		xn -= nsystp * cblock_1.xilfig;
	    }
	    glueil = (xn - cblock_1.b * c__) / (d__ + cblock_1.a * c__);
	    omegag = (cblock_1.b * d__ + cblock_1.a * xn) / (d__ + cblock_1.a 
		    * c__);

/*  G = N/(D + omega * C) = glueil,   (1) */
/* N = scaleable height (\interlignes) = height - htext - staff he
ights - xil*/
/*  xil = extra interliges = (nsy-1)*xilbn + 10 if header and no t
itles */
/*                          + (nsy-1)*xiltcb    for treble clef bo
ttoms */
/*                          + nsy*xilfig        for figures */
/*  D = omega-indep factors for scalable height = nsy-1 (intersyst
em glue) */
/*      + etatop + etabot + etatxt + */
/*  C*omega = nsy*(nv-1)*omega (\interstaff part) */
/*  But (empirically)  omega*G = a*G + b (2) */
/*      with a=1.071 and b=2.714 */
/*  Solving (1) and (2) gives */
/*      G = (N-b*C)/(D+a*C) , omega*G = (b*D+a*N)/(D+a*C) */
/*  Pass to pmxb    omega*G (=\interstaff-4) */
/*                  (etatop,bot,it,tc,cx)*G as inputs to \titles 
*/

/*       glueil = (heightil-xiltxt-nsystp*(xil+4*nv)) */
/*    *             /(nsystp*(1+gfact*(nv-1))-1+etatop+etabot+xilf
rac) */
/*       xnsttop = glueil*etatop */
/*       xintstaff = 4+gfact*glueil */

/* Only the first page will get local adjustment now if needed, ot
hers in pmxb*/

	    if (ifpb == 1 && ipage == 1 && compage_1.fintstf > (float)0.) {
		facins = compage_1.fintstf;
		compage_1.fintstf = (float)-1.;
	    } else {

/*  gintstf = 1.0 by default, but may be changed with AI<x> */

		facins = compage_1.gintstf;
	    }
	    s_wsle(&io___58);
	    do_lio(&c__3, &c__1, (char *)&nsystp, (ftnlen)sizeof(integer));
/* Computing MAX */
	    r__2 = (float)0., r__3 = cblock_1.etatop * glueil;
	    r__1 = dmax(r__2,r__3);
	    do_lio(&c__4, &c__1, (char *)&r__1, (ftnlen)sizeof(real));
	    r__4 = facins * (omegag + 4);
	    do_lio(&c__4, &c__1, (char *)&r__4, (ftnlen)sizeof(real));
	    e_wsle();
	    comget_1.ihead = 0;
	    comget_1.isheadr = FALSE_;
/* L7: */
	}
/* L8: */
    }

/*  Done with vertical, now do horizontals */

    celsk[1] = elsk[0];
    i__2 = comnotes_1.ibarcnt;
    for (all_1.ibar = 2; all_1.ibar <= i__2; ++all_1.ibar) {
	celsk[all_1.ibar] = celsk[all_1.ibar - 1] + elsk[all_1.ibar - 1];
/* L21: */
    }
    lastbar[0] = 0;
    ibar1 = 1;
    wmins = (float)-1.;
    iflb = 1;
    ikey = 1;

/*  Return nsyst to its *total* value */

    compage_1.nsyst = compage_1.isysfpb[compage_1.nfpb] - 1;
    i__2 = compage_1.nsyst;
    for (isyst = 1; isyst <= i__2; ++isyst) {
	if (isyst == compage_1.isysflb[iflb]) {
	    ++iflb;
	}
	ibarb4 = lastbar[isyst - 1];
	if (isyst == 1) {
/*         elsstarg = celsk(ibarcnt)/(nsyst-fracindent)*(1-fracind
ent) */
	    elssold = celsk[comnotes_1.ibarcnt] / (compage_1.nsyst - 
		    fracindent) * (1 - fracindent);
	    elsstarg = celsk[compage_1.ibarflb[1] - 1] / (compage_1.isysflb[1]
		     - 1 - fracindent) * (1 - fracindent);
	    celskb4 = (float)0.;
	} else {
	    celskb4 = celsk[ibarb4];
/*         elsstarg = (celsk(ibarcnt)-celskb4)/(nsyst-isyst+1) */
	    elssold = (celsk[comnotes_1.ibarcnt] - celskb4) / (
		    compage_1.nsyst - isyst + 1);
	    elsstarg = (celsk[compage_1.ibarflb[iflb] - 1] - celskb4) / (
		    compage_1.isysflb[iflb] - isyst);
	}
	diff1 = (r__1 = elsstarg - elsk[ibarb4], dabs(r__1));
	i__3 = comnotes_1.ibarcnt;
	for (all_1.ibar = ibarb4 + 2; all_1.ibar <= i__3; ++all_1.ibar) {
	    diff = elsstarg - (celsk[all_1.ibar] - celskb4);
	    if (dabs(diff) >= diff1) {
		goto L24;
	    }
	    diff1 = dabs(diff);
/* L23: */
	}
L24:
	--all_1.ibar;
	lastbar[isyst] = all_1.ibar;
	nbarss[isyst - 1] = all_1.ibar - ibarb4;

/* elss is # of elemskip in the syst. from notes, not ruleskips, ask's
, afterrs*/

	elss[isyst - 1] = celsk[all_1.ibar] - celskb4;
	s_wsfe(&io___74);
	i__3 = lastbar[isyst - 1] + 1;
	do_fio(&c__1, (char *)&i__3, (ftnlen)sizeof(integer));
	e_wsfe();

/*  Transposed sigs are isig1, newkey(2,3,...). */

	if (ikey == 1) {
	    key1 = comkeys_1.isig1;
	} else {
	    key1 = comkeys_1.newkey[ikey - 1];
	}
	fsyst = wclef + abs(key1) * wkeysig + (float)2. / musicsize;
	xelsk = (float)0.;
L1:
	if (ikey < comkeys_1.nkeys) {
	    if (comkeys_1.ibrkch[ikey] <= lastbar[isyst]) {

/*  Add space for all key changes */

		++ikey;
		key2 = comkeys_1.newkey[ikey - 1];
/* Computing MAX */
/* Computing MAX */
		i__6 = abs(key1), i__7 = abs(key2);
		i__4 = (i__3 = key2 - key1, abs(i__3)), i__5 = max(i__6,i__7);
		nacc = max(i__4,i__5);
		fsyst += nacc * wkeysig;

/*  Account for afterruleskips (fbar) */

		xelsk += commvl_1.fbar / 2;
		if (comkeys_1.ibrkch[ikey - 1] < lastbar[isyst] && ! 
			comkeys_1.kchmid[ikey - 1]) {
		    xelsk += (float)-1.;
		}
		key1 = key2;
		goto L1;
	    }
	}

/*  Add extra fixed space for double bar */

	if (isyst == compage_1.nsyst) {
	    fsyst += (float)4.5 / musicsize;
	}

/*  Add extra fixed space for initial time signature */

	if (isyst == 1) {
	    fsyst += wtimesig;
	}

/*  Add extra fixed space for time signature changes & user-defined sp
aces */

	i__3 = lastbar[isyst];
	for (ibars = ibarb4 + 1; ibars <= i__3; ++ibars) {
	    if (newmb[ibars - 1]) {
		fsyst += wtimesig;
	    }
	    fsyst += comnotes_1.udsp[ibars - 1] / musicsize;
/* L26: */
	}
	wdpt = compage_1.widthpt;
	if (isyst == 1) {
	    wdpt = compage_1.widthpt * (1 - fracindent);
	}
	wsyspt = wdpt - fsyst * musicsize - nbarss[isyst - 1] * (float).4;

/*  Checks for min spacing */
/*  Get range of NOtes def'ns required, also min allowable space */

/*        iemin = 1000 */
	iemin = 0;
/*        iemax = 0 */
	i__3 = ibar1 + nbarss[isyst - 1] - 1;
	for (all_1.ibar = ibar1; all_1.ibar <= i__3; ++all_1.ibar) {
/*          iemin = min(iemin,ieminb(ibar)) */
	    iemin |= comnotes_1.ieminb[all_1.ibar - 1];
/*          iemax = max(iemax,iemaxb(ibar)) */
	    if (comnotes_1.wminnh[all_1.ibar - 1] >= (float)0.) {
		wmins = comnotes_1.wminnh[all_1.ibar - 1];
	    }
/* L45: */
	}
	if (wmins < (float)0.) {
	    wmins = (float).3;
	}
	wminpt = (wmins + 1) * (float).3 * musicsize;

/*  Find min,max actual duration for this system & # of notes */

	dtmin = (float)1e3;
	dtmax = (float)0.;
	nns = 0;
	i__3 = comnotes_1.nptr[ibar1 + nbarss[isyst - 1] - 1] - 1;
	for (iptr = comnotes_1.nptr[ibar1 - 1]; iptr <= i__3; ++iptr) {
/* Computing MIN */
	    r__1 = dtmin, r__2 = comnotes_1.durb[iptr - 1];
	    dtmin = dmin(r__1,r__2);
/* Computing MAX */
	    r__1 = dtmax, r__2 = comnotes_1.durb[iptr - 1];
	    dtmax = dmax(r__1,r__2);
	    nns += comnotes_1.nnpd[iptr - 1];
/* L43: */
	}
/*       elmin0 = wsyspt*feon(dtmin)/(elss(isyst)+fbar*nbarss(isyst)) 
*/
	elmin0 = wsyspt * feon_(&dtmin) / (elss[isyst - 1] + commvl_1.fbar * 
		nbarss[isyst - 1] + xelsk);
	if (elmin0 >= wminpt) {
	    sumelsk = elss[isyst - 1];
	    eonk = (float)0.;
	    ewmxk = (float)1.;
	} else {
/*         elmin1 = wsyspt/(fbar*nbarss(isyst)/feon(dtmax)+nns) */
	    elmin1 = wsyspt / ((commvl_1.fbar * nbarss[isyst - 1] + xelsk) / 
		    feon_(&dtmax) + nns);
	    if (elmin1 <= wminpt) {
		s_wsle(&io___94);
		e_wsle();
		s_wsle(&io___95);
		do_lio(&c__9, &c__1, "In system #", 11L);
		do_lio(&c__3, &c__1, (char *)&isyst, (ftnlen)sizeof(integer));
		do_lio(&c__9, &c__1, " cannot meet min. space rqmt", 28L);
		e_wsle();
		eonk = (float).9;
	    } else {
/* Computing MIN */
		r__1 = (float).9, r__2 = (wminpt - elmin0) / (elmin1 - elmin0)
			;
		eonk = dmin(r__1,r__2);
	    }
	    d__1 = (doublereal) feon_(&dtmax);
	    d__2 = (doublereal) eonk;
	    ewmxk = pow_dd(&d__1, &d__2);

/*  Recompute poenom! */

	    sumelsk = (float)0.;
	    i__3 = comnotes_1.nptr[ibar1 + nbarss[isyst - 1] - 1] - 1;
	    for (iptr = comnotes_1.nptr[ibar1 - 1]; iptr <= i__3; ++iptr) {
		d__1 = (doublereal) feon_(&comnotes_1.durb[iptr - 1]);
		d__2 = (doublereal) (1 - eonk);
		sumelsk += comnotes_1.nnpd[iptr - 1] * pow_dd(&d__1, &d__2) * 
			ewmxk;
/* L44: */
	    }
	}
	poenom = wsyspt / (sumelsk + commvl_1.fbar * nbarss[isyst - 1] + 
		xelsk);
/*        write(12,'(1pe12.5/i5,4e12.3,2i5)') poenom,nbarss(isyst), */
/*     *       sumelsk,fsyst,eonk,ewmxk,iemin,iemax */
	s_wsfe(&io___97);
	do_fio(&c__1, (char *)&poenom, (ftnlen)sizeof(real));
	do_fio(&c__1, (char *)&nbarss[isyst - 1], (ftnlen)sizeof(integer));
	do_fio(&c__1, (char *)&sumelsk, (ftnlen)sizeof(real));
	do_fio(&c__1, (char *)&fsyst, (ftnlen)sizeof(real));
	do_fio(&c__1, (char *)&eonk, (ftnlen)sizeof(real));
	do_fio(&c__1, (char *)&ewmxk, (ftnlen)sizeof(real));
	do_fio(&c__1, (char *)&iemin, (ftnlen)sizeof(integer));
	e_wsfe();
	ibar1 += nbarss[isyst - 1];
/* L22: */
    }
    cl__1.cerr = 0;
    cl__1.cunit = 12;
    cl__1.csta = 0;
    f_clos(&cl__1);
    o__1.oerr = 0;
    o__1.ounit = 13;
    o__1.ofnmlen = 10;
    o__1.ofnm = "pmxtex.fig";
    o__1.orl = 0;
    o__1.osta = 0;
    o__1.oacc = 0;
    o__1.ofm = 0;
    o__1.oblnk = 0;
    f_open(&o__1);
    s_wsfe(&io___98);
    do_fio(&c__1, (char *)&ifig, (ftnlen)sizeof(integer));
    e_wsfe();
    cl__1.cerr = 0;
    cl__1.cunit = 13;
    cl__1.csta = 0;
    f_clos(&cl__1);
/*     print*,'Done with first pass.  Now run pmxb.' */
    s_wsfe(&io___99);
    do_fio(&c__1, " Done with first pass.  Now run pmxb.", 37L);
    e_wsfe();
} /* MAIN__ */

/* Subroutine */ int getnote_(loop, ifig)
logical *loop;
integer *ifig;
{
    /* Initialized data */

    static char literq[51*2+1] = "Literal TeX string cannot start with 4 bac\
kslashes!TeX string must have <129 char, end with backslash!";

    /* System generated locals */
    integer i__1, i__2, i__3;

    /* Builtin functions */
    integer s_wsle(), do_lio(), e_wsle();
    /* Subroutine */ int s_stop();
    integer s_cmp(), i_indx(), pow_ii(), s_rsfe(), do_fio(), e_rsfe();

    /* Local variables */
    static real fnum;
    static char dumq[1], dotq[1], durq[1];
    static integer itup;
    static real snum;
    static integer ntup, idotform, j;
    extern /* Subroutine */ int read10_();
    static real dimen;
    static char charq[1];
    static integer indxb;
    static char lineq[128];
    static integer iposn;
    extern /* Subroutine */ int readmeter_();
    static integer ic, icclhw;
    static char charlq[1];
    extern /* Subroutine */ int setmac_(), chklit_();
    static logical fulbrp;
    extern /* Subroutine */ int errmsg_();
    static integer literr, mtrdnp;
    static real sysflb;
    static integer mtrnmp, numnum;
    static real fnsyst;
    static integer igr;
    static real dum;
    extern /* Subroutine */ int getchar_();
    static integer ngr, lenbeat, iiv;
    extern /* Subroutine */ int readnum_();
    extern integer ifnodur_();
    static integer mtrdenl, lenmult, numshft;
    static logical isvshft, plusmin;
    static integer num1, num2;

    /* Fortran I/O blocks */
    static cilist io___104 = { 0, 6, 0, 0, 0 };
    static cilist io___112 = { 0, 6, 0, 0, 0 };
    static cilist io___113 = { 0, 6, 0, 0, 0 };
    static cilist io___114 = { 0, 6, 0, 0, 0 };
    static cilist io___117 = { 0, 6, 0, 0, 0 };
    static cilist io___118 = { 0, 6, 0, 0, 0 };
    static cilist io___119 = { 0, 6, 0, 0, 0 };
    static cilist io___131 = { 0, 6, 0, 0, 0 };
    static cilist io___132 = { 0, 6, 0, 0, 0 };
    static cilist io___133 = { 0, 6, 0, 0, 0 };
    static cilist io___141 = { 0, 6, 0, 0, 0 };
    static cilist io___142 = { 0, 6, 0, 0, 0 };
    static cilist io___143 = { 0, 6, 0, 0, 0 };
    static cilist io___144 = { 0, 6, 0, 0, 0 };
    static cilist io___145 = { 0, 6, 0, 0, 0 };
    static cilist io___148 = { 0, 6, 0, 0, 0 };
    static cilist io___149 = { 0, 6, 0, 0, 0 };
    static cilist io___150 = { 0, 6, 0, 0, 0 };
    static cilist io___155 = { 0, 6, 0, 0, 0 };
    static cilist io___156 = { 0, 6, 0, 0, 0 };
    static cilist io___157 = { 0, 5, 0, "(a)", 0 };


L1:
    getchar_(lineq, &all_1.iccount, charq, 128L, 1L);
    if (*(unsigned char *)charq != ' ') {
	*(unsigned char *)charlq = *(unsigned char *)charq;
    }
    if (comget_1.lastchar) {
	if (*(unsigned char *)charlq != '/') {
	    s_wsle(&io___104);
	    do_lio(&c__9, &c__1, "Last non-blank character is \"", 29L);
	    do_lio(&c__9, &c__1, charlq, 1L);
	    do_lio(&c__9, &c__1, "\", not \"/\"", 10L);
	    e_wsle();
	    s_stop("1", 1L);
	}
	return 0;
    }
    if (*(unsigned char *)charq == ' ') {
	goto L1;
    } else if (*(unsigned char *)charq == '%' && all_1.iccount == 1) {
	all_1.iccount = 128;
	goto L1;
    } else if (*(unsigned char *)charq >= 97 && *(unsigned char *)charq <= 
	    103 || *(unsigned char *)charq == 'r') {

/*  This is a note/rest.  Setup, increase note count, then loop 'til b
lank */

	idotform = 0;
	numnum = 0;
	plusmin = FALSE_;
	comget_1.inchord = FALSE_;
L28:
	++all_1.nnl[commvl_1.ivx - 1];
	if (all_1.nnl[commvl_1.ivx - 1] > 200) {
	    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &all_1.iccount, &i__1, ">200 notes in line of mus\
ic. Use smaller blocks!", 128L, 48L);
	    s_stop("1", 1L);
	}
	*(unsigned char *)dotq = 'x';

/*  Check if this is 'r ' and previous note was full-bar-pause */

	i__1 = all_1.iccount;
	fulbrp = *(unsigned char *)charq == 'r' && s_cmp(lineq + i__1, " ", 
		all_1.iccount + 1 - i__1, 1L) == 0 && all_1.nnl[commvl_1.ivx 
		- 1] > 1 && all_1.rest[commvl_1.ivx + (all_1.nnl[commvl_1.ivx 
		- 1] - 1) * 7 - 8] && all_1.nodur[commvl_1.ivx + (all_1.nnl[
		commvl_1.ivx - 1] - 1) * 7 - 8] == all_1.lenbar;
L2:
	getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	ic = *(unsigned char *)durq;
	if (ic <= 57 && ic >= 48) {

/*  Digit */

	    if (numnum == 0) {
		comnotes_1.nnodur = ic - 48;
		numnum = 1;
		goto L2;
	    } else if (numnum == 1) {
		if (*(unsigned char *)charq == 'r') {
		    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
			    all_1.nbars + 1;
		    errmsg_(lineq, &all_1.iccount, &i__1, "Only one digit al\
lowed after rest symbol \"r\"!", 128L, 45L);
		    s_stop("1", 1L);
		}
		numnum = 2;
		if (plusmin) {
		    s_wsle(&io___112);
		    e_wsle();
		    s_wsle(&io___113);
		    do_lio(&c__9, &c__1, "*********WARNING*********", 25L);
		    e_wsle();
		    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
			    all_1.nbars + 1;
		    errmsg_(lineq, &all_1.iccount, &i__1, "Before version 1.\
2, +/- was ignored if octave was!", 128L, 50L);
		    s_wsle(&io___114);
		    do_lio(&c__9, &c__1, "explicitly specified.  May need to\
 edit old editions", 52L);
		    e_wsle();
		}
		goto L2;
	    } else {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, ">2 digits in note sym\
bol!", 128L, 25L);
		s_stop("1", 1L);
	    }
	} else if (*(unsigned char *)durq == 'd') {
	    *(unsigned char *)dotq = *(unsigned char *)durq;
	    i__1 = all_1.iccount;
	    if (i_indx("+-", lineq + i__1, 2L, all_1.iccount + 1 - i__1) > 0) 
		    {

/*  move a dot, provided a number follows. */

		getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
		getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
		if (i_indx("0123456789-.", durq, 12L, 1L) == 0) {

/*  Backup, exit the loop normally */

		    all_1.iccount += -2;
		    goto L2;
/*             call errmsg(lineq,iccount,ibarcnt-ibaroff+n
bars+1, */
/*    *         'Expected a number after +/- after "d" (ra
ise dot)!') */
/*             stop 1 */
		}
		readnum_(lineq, &all_1.iccount, dumq, &fnum, 128L, 1L);
		if (i_indx("+-", dumq, 2L, 1L) > 0) {

/*  Vertical shift also */

		    getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
		    if (i_indx("0123456789-.", durq, 12L, 1L) == 0) {
			i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
				all_1.nbars + 1;
			errmsg_(lineq, &all_1.iccount, &i__1, "Expected numb\
er after 2nd +/- (shift dot)!", 128L, 42L);
			s_stop("1", 1L);
		    }
		    readnum_(lineq, &all_1.iccount, durq, &fnum, 128L, 1L);
		}
		--all_1.iccount;
	    }
	    goto L2;
	} else if (i_indx("+-", durq, 2L, 1L) > 0) {
	    if (*(unsigned char *)charq != 'r') {
		plusmin = TRUE_;
		if (numnum == 2) {
		    s_wsle(&io___117);
		    e_wsle();
		    s_wsle(&io___118);
		    do_lio(&c__9, &c__1, "*********WARNING*********", 25L);
		    e_wsle();
		    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
			    all_1.nbars + 1;
		    errmsg_(lineq, &all_1.iccount, &i__1, "Before version 1.\
2, +/- was ignored if octave was!", 128L, 50L);
		    s_wsle(&io___119);
		    do_lio(&c__9, &c__1, "explicitly specified.  May need to\
 edit old editions", 52L);
		    e_wsle();
		}
		goto L2;
/*         end if */

/* It's a rest containing +|- .  Must refer to a vertical shif
t.  Read past.*/

	    } else {
		getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
		readnum_(lineq, &all_1.iccount, durq, &dum, 128L, 1L);
		--all_1.iccount;
		goto L2;
	    }
	} else if (i_indx("fsnulare", durq, 8L, 1L) > 0) {
	    goto L2;
	} else if (*(unsigned char *)durq == 'p') {
	    fulbrp = *(unsigned char *)charq == 'r';
	    if (! fulbrp) {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "You entered \"p\"; I \
expected \"rp\"!", 128L, 33L);
		s_stop("1", 1L);
	    } else /* if(complicated condition) */ {
		i__1 = all_1.iccount;
		if (s_cmp(lineq + i__1, " ", all_1.iccount + 1 - i__1, 1L) != 
			0) {
		    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
			    all_1.nbars + 1;
		    errmsg_(lineq, &all_1.iccount, &i__1, "You entered \"r\
p\" followed by non-blank!", 128L, 39L);
		    s_stop("1", 1L);
		}
	    }
	    goto L2;
	} else if (*(unsigned char *)durq == 'b') {
	    if (*(unsigned char *)charq != 'r') {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "You entered \"b\"; I \
expected \"rb\"!", 128L, 33L);
		s_stop("1", 1L);
	    } else if (numnum == 2) {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "You entered \"r\" &\
 \"b\" with two numbers!", 128L, 39L);
	    }
	    goto L2;
	} else if (*(unsigned char *)durq == 'x') {

/*  xtuplet: Set all durations to 0 except last one. */

	    if (*(unsigned char *)charq == 'r') {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "Xtuplets currently ma\
y not start with a rest!", 128L, 45L);
		s_stop("1", 1L);
	    }
	    getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	    if (i_indx("123456789", durq, 9L, 1L) == 0) {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "First char after \"\
x\" in xtuplet must be \"1\"-\"9\"!", 128L, 48L);
		s_stop("1", 1L);
	    }
	    readnum_(lineq, &all_1.iccount, durq, &fnum, 128L, 1L);
	    if (fnum > (float)99.) {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "Xtuplet cannot have m\
ore than 99 notes!", 128L, 39L);
		s_stop("1", 1L);
	    } else if (i_indx(" n", durq, 2L, 1L) == 0) {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "Only legal characters\
 here are \" \" or \"n\"!", 128L, 42L);
		s_stop("1", 1L);
	    }
	    if (*(unsigned char *)durq == 'n') {

/*  Number alteration stuff */

		numshft = 0;
L30:
		getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
		if (*(unsigned char *)durq == 'f') {
		    goto L30;
		} else if (i_indx("+-", durq, 2L, 1L) > 0) {
		    ++numshft;
		    if (numshft == 3) {
			i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
				all_1.nbars + 1;
			errmsg_(lineq, &all_1.iccount, &i__1, "Only 2 number\
s are allowed after \"n\" in xtup!", 128L, 45L);
			s_stop("1", 1L);
		    }
		    getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
		    if (i_indx("0123456789.", durq, 11L, 1L) == 0) {
			i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
				all_1.nbars + 1;
			errmsg_(lineq, &all_1.iccount, &i__1, "This characte\
r should be a digit or \".\"!", 128L, 40L);
			s_stop("1", 1L);
		    }
		    readnum_(lineq, &all_1.iccount, durq, &snum, 128L, 1L);
		    --all_1.iccount;
		    if (numshft == 1 && snum > (float)15.1 || numshft == 2 && 
			    snum > (float)1.51) {
			i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
				all_1.nbars + 1;
			errmsg_(lineq, &all_1.iccount, &i__1, "Number after\
 \"n\" in xtup is out of range!", 128L, 41L);
			s_stop("1", 1L);
		    }
		    goto L30;
		} else if (*(unsigned char *)durq != ' ') {
		    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
			    all_1.nbars + 1;
		    errmsg_(lineq, &all_1.iccount, &i__1, "Illegal character\
 after \"n\" in xtup!", 128L, 36L);
		    s_stop("1", 1L);
		}
	    }
	    ntup = (integer) (fnum + (float).1);
	    i__1 = ntup;
	    for (itup = 2; itup <= i__1; ++itup) {
		all_1.nodur[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 
			8] = 0;
		++all_1.nnl[commvl_1.ivx - 1];
L110:
		getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
		if (*(unsigned char *)durq == ' ') {
		    goto L110;
		} else if (*(unsigned char *)durq == 'o') {

/*  Ornament in xtup.  "o" symbol must come AFTER the affe
cted note */

		    getchar_(lineq, &all_1.iccount, dumq, 128L, 1L);
		    if (i_indx("(stmx+Tup._)e:>^", dumq, 16L, 1L) == 0) {
			if (i_indx("fg", dumq, 2L, 1L) > 0) {
			    i__2 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
				    all_1.nbars + 1;
			    errmsg_(lineq, &all_1.iccount, &i__2, "Fermata o\
r segno not allowed in xtuplet!", 128L, 40L);
			} else {
			    i__2 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
				    all_1.nbars + 1;
			    errmsg_(lineq, &all_1.iccount, &i__2, "Illegal o\
rnament!", 128L, 17L);
			}
			s_stop("1", 1L);
		    }
		    if (*(unsigned char *)dumq == 'T') {

/*  Trill.  may be followed by 't' and/or number.  rea
d 'til blank */

L29:
			getchar_(lineq, &all_1.iccount, dumq, 128L, 1L);
			if (*(unsigned char *)dumq != ' ') {
			    goto L29;
			}
		    } else if (*(unsigned char *)dumq == 'e') {
			getchar_(lineq, &all_1.iccount, dumq, 128L, 1L);
			if (i_indx("sfn", dumq, 3L, 1L) == 0) {
			    i__2 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
				    all_1.nbars + 1;
			    errmsg_(lineq, &all_1.iccount, &i__2, "Illegal c\
haracter after \"e\" in edit. accid. symbol!", 128L, 51L);
			    s_stop("1", 1L);
			}
			getchar_(lineq, &all_1.iccount, dumq, 128L, 1L);
		    } else if (*(unsigned char *)dumq == ':') {
			i__2 = all_1.iccount;
			if (s_cmp(lineq + i__2, " ", all_1.iccount + 1 - i__2,
				 1L) != 0) {
			    i__2 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
				    all_1.nbars + 1;
			    errmsg_(lineq, &all_1.iccount, &i__2, "\":\" mus\
t be followed by blank in \"o: \"!", 128L, 39L);
			    s_stop("1", 1L);
			} else if (! comkeys_1.ornrpt) {
			    i__2 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
				    all_1.nbars + 1;
			    errmsg_(lineq, &all_1.iccount, &i__2, "Turned of\
f repeated ornaments before they were on!", 128L, 50L);
			    s_stop("1", 1L);
			}
			comkeys_1.ornrpt = FALSE_;
		    } else {
			getchar_(lineq, &all_1.iccount, dumq, 128L, 1L);
		    }
		    if (i_indx("+- :", dumq, 4L, 1L) == 0) {
			i__2 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
				all_1.nbars + 1;
			errmsg_(lineq, &all_1.iccount, &i__2, "Illegal chara\
cter in ornament symbol!", 128L, 37L);
			s_stop("1", 1L);
		    }
		    if (*(unsigned char *)dumq == ':') {
			if (comkeys_1.ornrpt) {
			    i__2 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
				    all_1.nbars + 1;
			    errmsg_(lineq, &all_1.iccount, &i__2, "Turned on\
 repeated ornaments but already on!", 128L, 44L);
			    s_stop("1", 1L);
			}
			comkeys_1.ornrpt = TRUE_;
		    }
		    if (i_indx("+-", dumq, 2L, 1L) > 0) {
			readnum_(lineq, &all_1.iccount, durq, &fnum, 128L, 1L)
				;
		    }
		    goto L110;
		} else if (i_indx("st()", durq, 4L, 1L) > 0) {
		    iposn = 0;
		    isvshft = FALSE_;
L15:
		    getchar_(lineq, &all_1.iccount, dumq, 128L, 1L);
		    ++iposn;
		    if (i_indx("udlt", dumq, 4L, 1L) > 0) {
			goto L15;
		    } else if (i_indx("+-", dumq, 2L, 1L) > 0) {
			++all_1.iccount;
			readnum_(lineq, &all_1.iccount, durq, &fnum, 128L, 1L)
				;
			if (! isvshft) {
			    isvshft = TRUE_;
			    if ((integer) (fnum + (float).5) > 15) {
				i__2 = comnotes_1.ibarcnt - 
					comnotes_1.ibaroff + all_1.nbars + 1;
				errmsg_(lineq, &all_1.iccount, &i__2, "Magni\
tude of slur height adjustment cannot exceed 15!", 128L, 53L);
				s_stop("1", 1L);
			    }
			} else {
			    if (dabs(fnum) > (float)6.3) {
				i__2 = all_1.iccount - 1;
				i__3 = comnotes_1.ibarcnt - 
					comnotes_1.ibaroff + all_1.nbars + 1;
				errmsg_(lineq, &i__2, &i__3, "Slur horiz shi\
ft must be in the range (-6.3,6.3)!", 128L, 49L);
				s_stop("1", 1L);
			    }
			}
			--all_1.iccount;
			goto L15;
		    } else if (*(unsigned char *)dumq != ' ') {
			ic = *(unsigned char *)dumq;
			if (ic >= 48 && ic <= 57 || ic >= 65 && ic <= 90) {
			    if (iposn == 1) {
				goto L15;
			    }
			    i__2 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
				    all_1.nbars + 1;
			    errmsg_(lineq, &all_1.iccount, &i__2, "Slur ID m\
ust be 2nd character in slur symbol!", 128L, 45L);
			    s_stop("1", 1L);
			}
			i__2 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
				all_1.nbars + 1;
			errmsg_(lineq, &all_1.iccount, &i__2, "Illegal chara\
cter in slur symbol!", 128L, 33L);
			s_stop("1", 1L);
		    }
		    goto L110;
		} else if (i_indx("0123456789#-nx_", durq, 15L, 1L) > 0) {

/*  We have a figure.  Only allow on 1st note of xtup */

		    if (itup != 2) {
			i__2 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
				all_1.nbars + 1;
			errmsg_(lineq, &all_1.iccount, &i__2, "Figure in xtu\
p only allowed on 1st note!", 128L, 40L);
			s_stop("1", 1L);
		    } else if (*(unsigned char *)durq == 'x') {
			i__2 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
				all_1.nbars + 1;
			errmsg_(lineq, &all_1.iccount, &i__2, "No floating f\
igures in xtuplets!", 128L, 32L);
			s_stop("1", 1L);
		    }
		    if (compage_1.usefig && commvl_1.ivx == 1) {
			*ifig = 1;
		    }
L26:
		    getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
		    if (i_indx("0123456789#-n_", durq, 14L, 1L) > 0) {
			goto L26;
		    } else if (*(unsigned char *)durq != ' ') {
			i__2 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
				all_1.nbars + 1;
			errmsg_(lineq, &all_1.iccount, &i__2, "Illegal chara\
cter in figure in xtuplet!", 128L, 39L);
			s_stop("1", 1L);
		    }
		    goto L110;
		} else if (*(unsigned char *)durq == '\\') {
		    chklit_(lineq, &all_1.iccount, &literr, 128L);
		    if (literr > 0) {
			i__2 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
				all_1.nbars + 1;
			errmsg_(lineq, &all_1.iccount, &i__2, literq + (
				literr - 1) * 51, 128L, 51L);
			s_stop("1", 1L);
		    }
		    goto L110;
		} else if (*(unsigned char *)durq == 'M') {

/*  Temporary trap until I get around putting this in pmxb
 */

		    i__2 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
			    all_1.nbars + 1;
		    errmsg_(lineq, &all_1.iccount, &i__2, "Macros not yet al\
lowed in xtuplets!", 128L, 35L);
		    s_stop("1", 1L);
		} else if (*(unsigned char *)durq == 'X') {

/*  Assume hardspace, not shift, for now */

		    getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
		    if (i_indx("+-", durq, 2L, 1L) > 0) {
			++all_1.iccount;
		    }
		    readnum_(lineq, &all_1.iccount, durq, &fnum, 128L, 1L);
		    --all_1.iccount;
		    goto L110;
		} else if (*(unsigned char *)durq == 'z') {

/*  Chord note in xtup.  Read past for now. */

L33:
		    getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
		    if (*(unsigned char *)durq != ' ') {
			goto L33;
		    }
		    goto L110;
		}
		if (i_indx("abcdefg", durq, 7L, 1L) == 0) {
		    i__2 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
			    all_1.nbars + 1;
		    errmsg_(lineq, &all_1.iccount, &i__2, "In xtup, this cha\
racter is not allowed!", 128L, 39L);
		    s_stop("1", 1L);
		}
L7:
		getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
		if (i_indx("+-sfn", durq, 5L, 1L) > 0) {
		    goto L7;
		}
/* L6: */
	    }

/*  6==End of loop for xtuplet input */

	} else if (*(unsigned char *)durq == 'm') {

/*  Multi-bar rest: next 1 or two digits are # of bars. */

	    if (all_1.iv > 1) {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "Cannot have multibar \
rest if nv>1!", 128L, 34L);
		s_stop("1", 1L);
	    } else if (all_1.itsofar[all_1.iv - 1] % all_1.lenbar != 0) {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "Multibar rest must st\
art at beginning of bar!", 128L, 45L);
		s_stop("1", 1L);
	    } else if (comnotes_1.ibarmbr > 0) {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "Only one multibar res\
t allowed per block!", 128L, 41L);
		s_stop("1", 1L);
	    }

/*  For some purposes, pretend its one bar only */

	    all_1.nodur[all_1.iv + all_1.nnl[all_1.iv - 1] * 7 - 8] = 
		    all_1.lenbar;
	    comnotes_1.ibarmbr = all_1.nbars + 1;
	    comnotes_1.mbrest = 0;
L20:
	    getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	    if (*(unsigned char *)durq >= 48 && *(unsigned char *)durq <= 57) 
		    {
		comnotes_1.mbrest = comnotes_1.mbrest * 10 + *(unsigned char *
			)durq - 48;
		goto L20;
	    }
	    if (*(unsigned char *)durq != ' ') {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "Illegal character aft\
er \"rm\"!", 128L, 29L);
		s_stop("1", 1L);
	    }
	} else if (*(unsigned char *)durq == '.') {

/*  Dotted pattern.  Close out note.  Mult time by 3/4. */
/*  Set time for next note to 1/4.  Start the note. */

	    idotform = 1;
	} else if (*(unsigned char *)durq == ',') {
	    idotform = 3;

/*  Now flow to duration setting, is if durq=' ' */

	} else if (*(unsigned char *)durq != ' ') {
	    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &all_1.iccount, &i__1, "Illegal character!", 128L, 
		    18L);
	    s_stop("1", 1L);
	}

/*  Set the duration */

	if (idotform > 0) {
	    if (idotform == 1) {
		all_1.nodur[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 
			8] = ifnodur_(&comnotes_1.nnodur, dotq, 1L) * 3 / 2;
	    } else if (idotform == 2) {
		all_1.nodur[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 
			8] = all_1.nodur[commvl_1.ivx + (all_1.nnl[
			commvl_1.ivx - 1] - 1) * 7 - 8] / 3;
	    } else if (idotform == 3) {
		all_1.nodur[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 
			8] = ifnodur_(&comnotes_1.nnodur, dotq, 1L);
	    } else if (idotform == 4) {
		all_1.nodur[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 
			8] = all_1.nodur[commvl_1.ivx + (all_1.nnl[
			commvl_1.ivx - 1] - 1) * 7 - 8] / 2;
	    }
	} else if (comnotes_1.ibarmbr != all_1.nbars + 1 && ! fulbrp) {
	    all_1.nodur[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 8] = 
		    ifnodur_(&comnotes_1.nnodur, dotq, 1L);
	} else if (fulbrp) {
	    all_1.nodur[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 8] = 
		    all_1.lenbar;
	    fulbrp = FALSE_;
	}
/*     print*,'ivx,nnl(ivx),nodur:',ivx,nnl(ivx),nodur(ivx,nnl(ivx)) 
*/
	if (*(unsigned char *)charq == 'r') {
	    all_1.rest[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 8] = 
		    TRUE_;
	}

/*  If inside forced beam, check if note is beamable */

	if (comget_1.fbon) {
	    if (all_1.nodur[commvl_1.ivx + all_1.nnl[commvl_1.ivx - 1] * 7 - 
		    8] < 16) {
		goto L120;
	    }
	    if (all_1.nnl[commvl_1.ivx - 1] > 1) {
		if (all_1.nodur[commvl_1.ivx + (all_1.nnl[commvl_1.ivx - 1] - 
			1) * 7 - 8] == 0) {
		    goto L120;
		}
	    }
	    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &all_1.iccount, &i__1, "Unbeamable thing in force\
d beam!", 128L, 32L);
	    s_stop("1", 1L);
	}
L120:
	all_1.itsofar[commvl_1.ivx - 1] += all_1.nodur[commvl_1.ivx + 
		all_1.nnl[commvl_1.ivx - 1] * 7 - 8];
	if (all_1.itsofar[commvl_1.ivx - 1] % all_1.lenbar == 0) {
	    ++all_1.nbars;
	    if (comkeys_1.shifton) {
		comkeys_1.barend = TRUE_;
	    }

/*  Will check barend when 1st note of next bar is entered. */

	    if (all_1.nbars > 15) {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "Cannot have more than\
 15 bars in an input block!", 128L, 48L);
		s_stop("1", 1L);
	    }
	    all_1.nib[commvl_1.ivx + all_1.nbars * 7 - 8] = all_1.nnl[
		    commvl_1.ivx - 1];
	    if (all_1.firstline && all_1.lenbar != all_1.lenbr1) {

/*  Just finished the pickup bar for this voice. */

		if (all_1.itsofar[commvl_1.ivx - 1] != all_1.lenbr0) {
		    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
			    all_1.nbars + 1;
		    errmsg_(lineq, &all_1.iccount, &i__1, "Pickup bar length\
 disagrees with mtrnum0!", 128L, 41L);
		    s_stop("1", 1L);
		}
		all_1.lenbar = all_1.lenbr1;
		all_1.itsofar[commvl_1.ivx - 1] = 0;
	    }
	} else if (comkeys_1.barend) {
	    if (comkeys_1.shifton) {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "Bar ended with user-d\
efined shift still on!", 128L, 43L);
		s_stop("1", 1L);
	    }
	    comkeys_1.barend = FALSE_;
	}
	if (idotform == 1) {
	    getchar_(lineq, &all_1.iccount, charq, 128L, 1L);
	    idotform = 2;
	    numnum = 1;
	    goto L28;
	} else if (idotform == 3) {
	    getchar_(lineq, &all_1.iccount, charq, 128L, 1L);
	    idotform = 4;
	    numnum = 1;
	    goto L28;
	}

/*  End of sub block for note-rest */

    } else if (*(unsigned char *)charq == 'z') {
	comget_1.inchord = TRUE_;
	getchar_(lineq, &all_1.iccount, charq, 128L, 1L);
L25:
	getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	if (i_indx("nfs+-.0123456789dre", durq, 19L, 1L) > 0) {
	    goto L25;
	}
	if (*(unsigned char *)durq != ' ' || i_indx("abcdefg", charq, 7L, 1L) 
		== 0) {
	    i__1 = all_1.iccount - 1;
	    i__2 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &i__1, &i__2, "Illegal character in chord note!", 
		    128L, 32L);
	    s_stop("1", 1L);
	}
    } else if (*(unsigned char *)charq == 'G') {
	ngr = 1;
L9:
	getchar_(lineq, &all_1.iccount, charq, 128L, 1L);
	if (i_indx("123456789", charq, 9L, 1L) > 0) {
	    readnum_(lineq, &all_1.iccount, durq, &fnum, 128L, 1L);
	    ngr = (integer) (fnum + (float).1);
	    --all_1.iccount;
	    goto L9;
	} else if (i_indx("AWulxs", charq, 6L, 1L) > 0) {
	    goto L9;
	} else if (*(unsigned char *)charq == 'm') {
	    getchar_(lineq, &all_1.iccount, charq, 128L, 1L);
	    if (i_indx("01234", charq, 5L, 1L) == 0) {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "A digit less than 5 m\
ust follow \"m\" in a grace note!", 128L, 52L);
		s_stop("1", 1L);
	    }
	    goto L9;
	}

/*  At this point, charq is first note name in rest (grace?) */

	i__1 = ngr;
	for (igr = 1; igr <= i__1; ++igr) {
	    numnum = 0;
/*          if (igr .gt. 1) call getchar(lineq,iccount,charq) */
/* ++ */
	    if (igr > 1) {
/*            if (charq .ne. ' ') then */
/*              call errmsg(lineq,iccount,ibarcnt-ibaroff+nbar
s+1, */
/*     *             'In multiple grace, expected blank!') */
/*              stop 1 */
/*            end if */
L55:
		getchar_(lineq, &all_1.iccount, charq, 128L, 1L);
		if (*(unsigned char *)charq == ' ') {
		    goto L55;
		}
	    }
/* ++ */
	    if (i_indx("abcdefg", charq, 7L, 1L) == 0) {
		i__2 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__2, "In grace, expected\
 \"a\"-\"g\"!", 128L, 27L);
		s_stop("1", 1L);
	    }
L18:
	    getchar_(lineq, &all_1.iccount, charq, 128L, 1L);
	    if (*(unsigned char *)charq != ' ') {
		if (i_indx("+-1234567", charq, 9L, 1L) > 0) {
		    if (numnum == 1) {
			i__2 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
				all_1.nbars + 1;
			errmsg_(lineq, &all_1.iccount, &i__2, "Only one of\
 \"+-1234567\" allowed here in grace!", 128L, 46L);
			s_stop("1", 1L);
		    }
		    numnum = 1;
		    goto L18;
		} else if (i_indx("nfs", charq, 3L, 1L) > 0) {
		    goto L18;
		}

/*  Digits are possible octave numbers */

		i__2 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__2, "Illegal character aft\
er note name in grace!", 128L, 43L);
		s_stop("1", 1L);
	    }
/* L19: */
	}
    } else if (*(unsigned char *)charq == '\\') {
	chklit_(lineq, &all_1.iccount, &literr, 128L);
	if (literr > 0) {
	    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &all_1.iccount, &i__1, literq + (literr - 1) * 51, 
		    128L, 51L);
	    s_stop("1", 1L);
	}
    } else if (*(unsigned char *)charq == 'o') {

/*  "o" symbol must come AFTER the affected note */

	getchar_(lineq, &all_1.iccount, dumq, 128L, 1L);
	if (i_indx("(stmgx+Tupf._)e:>^", dumq, 18L, 1L) == 0) {
	    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &all_1.iccount, &i__1, "Illegal ornament!", 128L, 
		    17L);
	    s_stop("1", 1L);
	}
	if (*(unsigned char *)dumq == ':') {
	    getchar_(lineq, &all_1.iccount, dumq, 128L, 1L);
	    if (*(unsigned char *)dumq != ' ') {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "Expected blank after\
 \"o:\"!", 128L, 26L);
		s_stop("1", 1L);
	    } else if (! comkeys_1.ornrpt) {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "Turned off repeated o\
rnaments before they were on!", 128L, 50L);
		s_stop("1", 1L);
	    }
	    comkeys_1.ornrpt = FALSE_;
	} else if (*(unsigned char *)dumq == 'g') {
	    if (comget_1.issegno) {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "Sorry, only one \"seg\
no\" per input block!", 128L, 40L);
		s_stop("1", 1L);
	    } else if (commvl_1.ivx != 1) {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "segno can only be in \
voice 1!", 128L, 29L);
		s_stop("1", 1L);
	    }
	    comget_1.issegno = TRUE_;
L12:
	    getchar_(lineq, &all_1.iccount, dumq, 128L, 1L);
	    if (*(unsigned char *)dumq == '-' || *(unsigned char *)dumq >= 48 
		    && *(unsigned char *)dumq <= 58) {
		goto L12;
	    }
	    if (*(unsigned char *)dumq != ' ') {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "Illegal character in \
segno ornament symbol!", 128L, 43L);
		s_stop("1", 1L);
	    }
	} else if (*(unsigned char *)dumq == 'T') {

/*  Trill.  may be followed by 't' and/or number.  read 'til blank
 */

L22:
	    getchar_(lineq, &all_1.iccount, dumq, 128L, 1L);
	    if (*(unsigned char *)dumq == ':') {
		i__1 = all_1.iccount;
		if (s_cmp(lineq + i__1, " ", all_1.iccount + 1 - i__1, 1L) != 
			0) {
		    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
			    all_1.nbars + 1;
		    errmsg_(lineq, &all_1.iccount, &i__1, "Expected blank af\
ter \":\"!", 128L, 25L);
		    s_stop("1", 1L);
		}
		goto L32;
	    } else if (*(unsigned char *)dumq != ' ') {
		goto L22;
	    }
	} else if (*(unsigned char *)dumq == 'f') {
	    getchar_(lineq, &all_1.iccount, dumq, 128L, 1L);
	    if (i_indx(" d+-:", dumq, 5L, 1L) == 0) {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "Illegal character aft\
er \"f\" in fermata ornament symbol!", 128L, 55L);
		s_stop("1", 1L);
	    }
	    if (*(unsigned char *)dumq == 'd') {
		getchar_(lineq, &all_1.iccount, dumq, 128L, 1L);
	    }
	    if (*(unsigned char *)dumq == ':') {
		goto L32;
	    }
	} else if (*(unsigned char *)dumq == 'e') {
	    getchar_(lineq, &all_1.iccount, dumq, 128L, 1L);
	    if (i_indx("sfn", dumq, 3L, 1L) == 0) {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "Illegal character aft\
er \"e\" in edit. accid. symbol!", 128L, 51L);
		s_stop("1", 1L);
	    }
	    getchar_(lineq, &all_1.iccount, dumq, 128L, 1L);
	} else {
	    getchar_(lineq, &all_1.iccount, dumq, 128L, 1L);
	}
	if (i_indx("+- :", dumq, 4L, 1L) == 0) {
	    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &all_1.iccount, &i__1, "Illegal character in orna\
ment symbol!", 128L, 37L);
	    s_stop("1", 1L);
	}
	if (i_indx("+-", dumq, 2L, 1L) > 0) {
	    readnum_(lineq, &all_1.iccount, durq, &fnum, 128L, 1L);
	}
L32:
	if (*(unsigned char *)dumq == ':') {
	    if (comkeys_1.ornrpt) {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "Turned on repeated or\
naments but already on!", 128L, 44L);
		s_stop("1", 1L);
	    }
	    comkeys_1.ornrpt = TRUE_;
	}
/*      else if (charq .eq. 's' .or. charq .eq. 't') then */
    } else if (i_indx("st()", charq, 4L, 1L) > 0) {
	isvshft = FALSE_;
	iposn = 0;
L8:
	getchar_(lineq, &all_1.iccount, dumq, 128L, 1L);
	++iposn;
	if (i_indx("udlt+- ", dumq, 7L, 1L) == 0) {

/*  Check for explicit ID code. */

	    ic = *(unsigned char *)dumq;
	    if (ic < 48 || ic > 57 && ic < 65 || ic > 90) {

/*  Not 0-9 or A-Z, so exit */

		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "Illegal character in \
slur symbol!", 128L, 33L);
		s_stop("1", 1L);
	    } else {

/*  It is a possible ID code.  Right place? */

		if (iposn != 1) {

/*  Slur ID is not 2nd! */

		    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
			    all_1.nbars + 1;
		    errmsg_(lineq, &all_1.iccount, &i__1, "Slur ID must be s\
econd character in slur symbol!", 128L, 48L);
		    s_stop("1", 1L);
		}
	    }

/*  Slur ID is OK. */

	    goto L8;
	}
	if (i_indx("udlt", dumq, 4L, 1L) > 0) {
	    goto L8;
	} else if (i_indx("+-", dumq, 2L, 1L) > 0) {
	    if (*(unsigned char *)charq == 't') {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "\"+|-\" for slur heig\
ht only allowed in \"s\"-slurs!", 128L, 48L);
		s_stop("1", 1L);
	    }
	    ++all_1.iccount;
	    readnum_(lineq, &all_1.iccount, durq, &fnum, 128L, 1L);
	    if (! isvshft) {
		isvshft = TRUE_;
		if ((integer) (fnum + (float).5) > 15) {
		    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
			    all_1.nbars + 1;
		    errmsg_(lineq, &all_1.iccount, &i__1, "Magnitude of slur\
 height adjustment cannot exceed 15!", 128L, 53L);
		    s_stop("1", 1L);
		}
	    } else {
		if (dabs(fnum) > (float)6.3) {
		    i__1 = all_1.iccount - 1;
		    i__2 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
			    all_1.nbars + 1;
		    errmsg_(lineq, &i__1, &i__2, "Slur horiz shift must be i\
n range (-6.3,6.3)!", 128L, 45L);
		    s_stop("1", 1L);
		}
	    }
	    --all_1.iccount;
	    goto L8;
	}
    } else if (*(unsigned char *)charq == '?') {
    } else if (*(unsigned char *)charq >= 48 && *(unsigned char *)charq <= 57 
	    || i_indx("#-nx_", charq, 5L, 1L) > 0) {

/*  We have a figure.  Must come AFTER the note it goes under */

	if (all_1.itsofar[commvl_1.ivx - 1] == 0 && (! all_1.firstline || 
		all_1.lenbr0 == 0 || all_1.lenbar == all_1.lenbr0)) {

/*  Figure before first note in block */

	    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &all_1.iccount, &i__1, "Cannot put figure before \
first note in block!", 128L, 45L);
	    s_stop("1", 1L);
	}
	if (*(unsigned char *)charq == 'x') {
	    indxb = i_indx(lineq + (all_1.iccount - 1), " ", 128 - (
		    all_1.iccount - 1), 1L);
	    if (indxb < 5) {
		i__1 = all_1.iccount + indxb - 1;
		i__2 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &i__1, &i__2, "Cannot have a blank here in fl\
oating figure!", 128L, 44L);
		s_stop("1", 1L);
	    }
	}
	if (compage_1.usefig) {
	    *ifig = 1;
	}
L5:
	getchar_(lineq, &all_1.iccount, charq, 128L, 1L);
	if (*(unsigned char *)charq != ' ') {
	    goto L5;
	}
    } else if (*(unsigned char *)charq == '[') {
	if (comget_1.fbon) {
	    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &all_1.iccount, &i__1, "Started forced beam while\
 another was open!", 128L, 43L);
	    s_stop("1", 1L);
	}
	comget_1.fbon = TRUE_;
L17:
	getchar_(lineq, &all_1.iccount, charq, 128L, 1L);
	if (i_indx("uljh", charq, 4L, 1L) > 0) {
	    goto L17;
	} else if (i_indx("+-", charq, 2L, 1L) > 0) {
	    ++all_1.iccount;
	    readnum_(lineq, &all_1.iccount, durq, &fnum, 128L, 1L);
	    --all_1.iccount;
	    goto L17;
	} else if (*(unsigned char *)charq == 'm') {

/*  Forced multiplicity, next char should be 1-4 */

	    getchar_(lineq, &all_1.iccount, charq, 128L, 1L);
	    if (i_indx("1234", charq, 4L, 1L) == 0) {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "Forced multiplicity f\
or a beam must be 1, 2, 3, or 4!", 128L, 53L);
		s_stop("1", 1L);
	    }
	    goto L17;
	} else if (*(unsigned char *)charq != ' ') {
	    if (i_indx("0123456789", charq, 10L, 1L) > 0) {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "After \"[\", digits m\
ust now be preceeded by \"+\" or \"-\"!", 128L, 54L);
		s_wsle(&io___131);
		do_lio(&c__9, &c__1, "You will have to edit older sources to\
 meet this rqmt,", 54L);
		e_wsle();
		s_wsle(&io___132);
		do_lio(&c__9, &c__1, "but it was needed to allow 2-digit hei\
ght adjustments.", 54L);
		e_wsle();
		s_wsle(&io___133);
		do_lio(&c__9, &c__1, "Sorry for the inconvenience.  --The Ma\
nagement", 46L);
		e_wsle();
	    } else {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "Illegal character aft\
er [!", 128L, 26L);
	    }
	    s_stop("1", 1L);
	}
    } else if (*(unsigned char *)charq == ']') {
	getchar_(lineq, &all_1.iccount, charq, 128L, 1L);
/*       if (charq .eq. ' ') then */
	if (i_indx("j ", charq, 2L, 1L) > 0) {
	    if (comget_1.fbon) {
		comget_1.fbon = FALSE_;
	    } else {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "Forced beam stop with\
 no corresponding start!", 128L, 45L);
		s_stop("1", 1L);
	    }
	} else if (*(unsigned char *)charq == '[') {
	    if (! comget_1.fbon) {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "\"][\" can only go in\
 forced beam!", 128L, 32L);
		s_stop("1", 1L);
	    }
/*       else */
	} else if (*(unsigned char *)charq != 'j') {
	    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &all_1.iccount, &i__1, "\"]\" must be followed by\
 blank, \"j\", or \"[\"!", 128L, 43L);
	    s_stop("1", 1L);
	}
    } else if (i_indx("lhw", charq, 3L, 1L) > 0) {

/*  Save position for later check */

	icclhw = all_1.iccount;
	getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	if (i_indx("0123456789.+- ", durq, 14L, 1L) == 0) {
	    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &all_1.iccount, &i__1, "Illegal character after\
 \"l\", \"w\", or \"h\"!", 128L, 41L);
	    s_stop("1", 1L);
	}
	comget_1.isheadr = comget_1.isheadr || *(unsigned char *)charq == 'h';
	if (i_indx(" +-", durq, 3L, 1L) > 0) {

/*  There is a header (or lower string?) */

	    if (i_indx("+-", durq, 2L, 1L) > 0) {

/*  User-defined vert offset (\internote). */

		if (*(unsigned char *)charq != 'h') {
		    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
			    all_1.nbars + 1;
		    errmsg_(lineq, &all_1.iccount, &i__1, "\"+\" or \"-\" no\
t permitted here!", 128L, 30L);
		    s_stop("1", 1L);
		}

/*  Have "h" followed by +/- .  Check for digit. */
/*     Can blow durq since not using fnum for now, but... */

		getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
		if (i_indx("123456789", durq, 9L, 1L) == 0) {
		    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
			    all_1.nbars + 1;
		    errmsg_(lineq, &all_1.iccount, &i__1, "There must be a d\
igit here!", 128L, 27L);
		    s_stop("1", 1L);
		}

/* Have "h" followed by +/- followed by a digit.  No need to g
et the number.*/

/*           call readnum(lineq,iccount,durq,fnum) */
	    }
	    if (*(unsigned char *)charq != 'w') {

/*  Header or lower string. */

/*           if (iccount .ne. 2) then */
		if (icclhw != 1) {
		    i__1 = all_1.iccount - 1;
		    i__2 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
			    all_1.nbars + 1;
		    errmsg_(lineq, &i__1, &i__2, "\"h\" or \"l\" must be fir\
st character in line!", 128L, 43L);
		    s_stop("1", 1L);
		}

/*  Read past the next line, which has the string. */

/*           read(10,'(a)')charq */
		read10_(charq, &c__1, &comget_1.lastchar, 1L);
		++comget_1.nline;
		all_1.iccount = 128;
	    } else {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "Symbol \"w\" (width) \
must be followed by a digit!", 128L, 47L);
		s_stop("1", 1L);
	    }
	} else {

/*  Height or width change spec.  Check if at start of piece. */

	    if (comnotes_1.ibarcnt > 0) {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "Symbol must go at top\
 of first input block!", 128L, 43L);
		s_stop("1", 1L);
	    }
	    readnum_(lineq, &all_1.iccount, durq, &dimen, 128L, 1L);

/*  Check units.  Convert to points */

	    if (*(unsigned char *)durq == ' ' || *(unsigned char *)durq == 
		    'p') {
		dimen += (float).5;
	    } else if (*(unsigned char *)durq == 'i') {
		dimen = dimen * 72 + (float).5;
	    } else if (*(unsigned char *)durq == 'm') {
		dimen = dimen / (float)25.4 * 72 + (float).5;
	    } else {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "Illegal unit; must \
be \"p\",\"i\",or\"m\"!", 128L, 36L);
		s_stop("1", 1L);
	    }
	    if (*(unsigned char *)charq == 'h') {
		compage_1.ptheight = (real) ((integer) dimen);
	    } else {
		compage_1.widthpt = (real) ((integer) dimen);
	    }
	}
    } else if (*(unsigned char *)charq == 'm') {

/*  Time signature change.  Only allow at beginning of block. */
/*    mtrnuml, mtrdenl (logical) and p (printable) will be input. */
/*    mtrnuml=0 initially. (In common) */

/*  Check whether at beginning of a block */

	if (commvl_1.ivx != 1 || all_1.nnl[0] != 0) {
	    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &all_1.iccount, &i__1, "Meter change only OK in v\
oice 1, at start of block!", 128L, 51L);
	    s_stop("1", 1L);
	}
	all_1.newmeter = TRUE_;
	readmeter_(lineq, &all_1.iccount, &all_1.mtrnuml, &mtrdenl, 128L);
	if (all_1.mtrnuml == 0) {
	    i__1 = all_1.iccount - 1;
	    i__2 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &i__1, &i__2, "Digit 0 not allowed here!", 128L, 
		    25L);
	    s_stop("1", 1L);
	}
	readmeter_(lineq, &all_1.iccount, &mtrnmp, &mtrdnp, 128L);

/*  Read past printed time signature; not used in pmxa. */

	lenbeat = ifnodur_(&mtrdenl, "x", 1L);
	lenmult = 1;
	if (mtrdenl == 2) {
	    lenbeat = 16;
	    lenmult = 2;
	}
	all_1.lenbar = lenmult * all_1.mtrnuml * lenbeat;
	all_1.mtrnuml = 0;
    } else if (*(unsigned char *)charq == 'C') {
	getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	if (! (i_indx("tsmanrb", durq, 7L, 1L) > 0 || *(unsigned char *)durq 
		>= 48 && *(unsigned char *)durq <= 54)) {
	    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &all_1.iccount, &i__1, "Must have t,s,m,a,n,r,b o\
r 1-6 after C!", 128L, 39L);
	    s_stop("1", 1L);
	}
    } else if (*(unsigned char *)charq == 'R') {
	if (commvl_1.ivx != 1) {
	    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &all_1.iccount, &i__1, "Repeats can only go in vo\
ice 1!", 128L, 31L);
	    s_stop("1", 1L);
	}
L10:
	getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	if (i_indx("lrdD", durq, 4L, 1L) > 0) {
	    goto L10;
	}
	if (*(unsigned char *)durq != ' ') {
	    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &all_1.iccount, &i__1, "Illegal character after\
 \"R\" (repeat/double bar)!", 128L, 48L);
	    s_stop("1", 1L);
	}
    } else if (*(unsigned char *)charq == 'V') {

/*  Ending */

	if (all_1.iv != 1) {
	    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &all_1.iccount, &i__1, "Voltas are only allowed i\
n voice #1!", 128L, 36L);
	    s_stop("1", 1L);
	} else if (comget_1.isvolt) {
	    s_wsle(&io___141);
	    e_wsle();
	    s_wsle(&io___142);
	    do_lio(&c__9, &c__1, "*******WARNING********", 22L);
	    e_wsle();
	    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &all_1.iccount, &i__1, "There is more than one vo\
lta in this input block.!", 128L, 50L);
	    s_wsle(&io___143);
	    do_lio(&c__9, &c__1, "This may work in a score, but WILL NOT wor\
k in parts.", 53L);
	    e_wsle();
	    s_wsle(&io___144);
	    do_lio(&c__9, &c__1, "Safest to have only 1 volta per block, at \
the start of the block", 64L);
	    e_wsle();
	}
	comget_1.isvolt = TRUE_;
L11:
	getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	if (*(unsigned char *)durq != ' ') {
	    goto L11;
	}
    } else if (*(unsigned char *)charq == 'B') {
    } else if (*(unsigned char *)charq == 'P') {
	if (commvl_1.ivx != 1 || all_1.nnl[0] != 0) {
	    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &all_1.iccount, &i__1, "Only allowed at beginning\
 of block!", 128L, 35L);
	    s_stop("1", 1L);
	}
L16:
	getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	if (*(unsigned char *)durq == 'l' || *(unsigned char *)durq == 'r' || 
		*(unsigned char *)durq >= 48 && *(unsigned char *)durq <= 57) 
		{
	    goto L16;
	}
	if (*(unsigned char *)durq != ' ') {
	    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &all_1.iccount, &i__1, "Only \"l\", \"r\", or dig\
it allowed after \"P\"!", 128L, 42L);
	    s_stop("1", 1L);
	}
    } else if (*(unsigned char *)charq == 'W') {
	getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	if (*(unsigned char *)durq != '.') {
	    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &all_1.iccount, &i__1, "Next char after \" W\" mu\
st be \".\"!", 128L, 33L);
	    s_stop("1", 1L);
	}
	getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	if (*(unsigned char *)durq >= 48 || *(unsigned char *)durq <= 57) {
	    comnotes_1.wminnh[comnotes_1.ibarcnt + all_1.nbars] = (*(unsigned 
		    char *)durq - 48) * (float).1;
	} else {
	    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &all_1.iccount, &i__1, "Next char after \" W.\" m\
ust be 0-9!", 128L, 34L);
	    s_stop("1", 1L);
	}
    } else if (*(unsigned char *)charq == 'T') {

/*  Titles */

	getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	if (i_indx("itc", durq, 3L, 1L) == 0) {
	    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &all_1.iccount, &i__1, "Must put \"i\", \"t\", \
or \"c\" after \"T\"!", 128L, 36L);
	    s_stop("1", 1L);
	}
	i__1 = i_indx("itc", durq, 3L, 1L) - 1;
	comget_1.ihead += pow_ii(&c__2, &i__1);

/* Maybe a number after 'Tt', but ignore here.  Read past string on ne
xt line.*/

/*       read(10,'(a)')charq */
	read10_(charq, &c__1, &comget_1.lastchar, 1L);
	++comget_1.nline;
	all_1.iccount = 128;
    } else if (*(unsigned char *)charq == 'A') {
L27:
	getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	if (i_indx("rbsd", durq, 4L, 1L) > 0) {
	    goto L27;
	} else if (*(unsigned char *)durq == 'a') {
	    getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	    readnum_(lineq, &all_1.iccount, durq, &commvl_1.fbar, 128L, 1L);
	    --all_1.iccount;
	    goto L27;
	} else if (*(unsigned char *)durq == 'i') {
	    getchar_(lineq, &all_1.iccount, durq, 128L, 1L);

/* Local interstaff correction.  Set to -1. if not specifiec, or a
fter use*/

	    readnum_(lineq, &all_1.iccount, durq, &compage_1.fintstf, 128L, 
		    1L);
	    s_wsle(&io___145);
	    do_lio(&c__9, &c__1, "fintstf set to", 14L);
	    do_lio(&c__4, &c__1, (char *)&compage_1.fintstf, (ftnlen)sizeof(
		    real));
	    e_wsle();
	    --all_1.iccount;
	    goto L27;
	} else if (*(unsigned char *)durq == 'I') {

/*  Global interstaff correction.  Use in place of fintstf if fint
stf<0 */

	    getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	    readnum_(lineq, &all_1.iccount, durq, &compage_1.gintstf, 128L, 
		    1L);
	    --all_1.iccount;
	    goto L27;
	} else if (*(unsigned char *)durq != ' ') {
	    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &all_1.iccount, &i__1, "The only legal entries af\
ter \"A\" are \"r,s,b,a,i,I,d\"!", 128L, 53L);
	    s_stop("1", 1L);
	}
    } else if (*(unsigned char *)charq == 'K') {

/*  Rules and function of K command */

/* Only 1 K +/-n +/-m  allowed per block if n.ne.0 (transposition).  i
sig1 is*/
/* initial sig, and must be passed to pmxb because it is needed when t
opfile*/
/* is called, which is before the K+n+m command is read in pmxb.  Also
, we*/
/* compute and save ibrkch and newkey for each syst, accounting for ke
y changes,*/
/*  then adjust fbar to make poenom much more accurate. */

	getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	if (i_indx("+-", durq, 2L, 1L) == 0) {
	    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &all_1.iccount, &i__1, "\"K\" (transpose or key c\
hange) must be followed by \"+,-\"!", 128L, 56L);
	    s_stop("1", 1L);
	}
	++all_1.iccount;
	num1 = 44 - *(unsigned char *)durq;

/*  num1= +1 or -1 */

	readnum_(lineq, &all_1.iccount, durq, &fnum, 128L, 1L);
	num1 = (integer) (fnum + (float).1) * num1;
	if (i_indx("+-", durq, 2L, 1L) == 0) {
	    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &all_1.iccount, &i__1, "1st number after \"K\" mu\
st be followed by \"+,-\"!", 128L, 47L);
	    s_stop("1", 1L);
	}
	++all_1.iccount;
	num2 = 44 - *(unsigned char *)durq;
	readnum_(lineq, &all_1.iccount, durq, &fnum, 128L, 1L);
	num2 *= (integer) (fnum + (float).1);
	if (num1 == 0) {

/*  Key change, only one per block allowed */

	    if (comkeys_1.iskchb) {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "Only one key change a\
llowed per input block!", 128L, 44L);
		s_stop("1", 1L);
	    }
	    comkeys_1.iskchb = TRUE_;
	    ++comkeys_1.nkeys;
	    comkeys_1.kchmid[comkeys_1.nkeys - 1] = all_1.itsofar[
		    commvl_1.ivx - 1] % all_1.lenbar != 0;

/* Make ibrkch = barnum-1 if at start of bar, so fsyst advances ok
 at linebreak.*/

	    comkeys_1.ibrkch[comkeys_1.nkeys - 1] = comnotes_1.ibarcnt + 
		    all_1.nbars;
	    if (comkeys_1.kchmid[comkeys_1.nkeys - 1]) {
		++comkeys_1.ibrkch[comkeys_1.nkeys - 1];
	    }
	    comkeys_1.newkey[comkeys_1.nkeys - 1] = num2 + comkeys_1.idsig;
	} else {

/*  Transposition */

	    if (comnotes_1.ibarcnt > 0) {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "Transposition must be\
 at top of first input block!", 128L, 50L);
		s_stop("1", 1L);
	    }
	    comkeys_1.isig1 = num2;
	    comkeys_1.idsig = comkeys_1.isig1 - comkeys_1.newkey[0];

/* idsig is the difference between sig after transposition, and si
g in setup.*/
/*  It may alter # of accid's in key changes if there is transposi
tion. */

	}
    } else if (*(unsigned char *)charq == '|') {

/*  Optional bar symbol */

	if (all_1.itsofar[commvl_1.ivx - 1] % all_1.lenbar != 0) {
	    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &all_1.iccount, &i__1, "Bar line marker out of pl\
ace!", 128L, 29L);
	    s_stop("1", 1L);
	} else if (comkeys_1.shifton) {
	    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &all_1.iccount, &i__1, "Bar ended with user-defin\
ed shift still on!", 128L, 43L);
	    s_stop("1", 1L);
	}
    } else if (*(unsigned char *)charq == '/') {
	if (comget_1.fbon) {
	    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &all_1.iccount, &i__1, "Block ended with forced b\
eam open!", 128L, 34L);
	    s_stop("1", 1L);
	} else if (comkeys_1.shifton) {
	    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &all_1.iccount, &i__1, "Bar ended with user-defin\
ed shift still on!", 128L, 43L);
	    s_stop("1", 1L);
	}
	comkeys_1.barend = FALSE_;

/*  Perform time checks */

	if (all_1.itsofar[commvl_1.ivx - 1] % all_1.lenbar != 0) {
	    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &all_1.iccount, &i__1, "Block duration not divisi\
ble by lenbar!", 128L, 39L);
	    s_wsle(&io___148);
	    do_lio(&c__9, &c__1, "lenbar is ", 10L);
	    do_lio(&c__3, &c__1, (char *)&all_1.lenbar, (ftnlen)sizeof(
		    integer));
	    e_wsle();
	    s_stop("1", 1L);
	} else if (commvl_1.ivx > 1 && all_1.itsofar[commvl_1.ivx - 1] != 
		all_1.itsofar[0]) {
	    s_wsle(&io___149);
	    e_wsle();
	    s_wsle(&io___150);
	    do_lio(&c__9, &c__1, "# of bars in voice 1, current voice:", 36L);
	    i__1 = all_1.itsofar[0] / all_1.lenbar;
	    do_lio(&c__3, &c__1, (char *)&i__1, (ftnlen)sizeof(integer));
	    i__2 = all_1.itsofar[commvl_1.ivx - 1] / all_1.lenbar;
	    do_lio(&c__3, &c__1, (char *)&i__2, (ftnlen)sizeof(integer));
	    e_wsle();
	    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &all_1.iccount, &i__1, "Block duration not equal \
to voice 1!", 128L, 36L);
	    s_stop("1", 1L);
	}
	getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	if (*(unsigned char *)durq == ' ' && all_1.iv == all_1.nv) {

/*  End of input block */

	    *loop = FALSE_;
	} else {

/*  Start a new voice */

	    if (all_1.lenbr0 != 0 && all_1.firstline) {
		all_1.lenbar = all_1.lenbr0;
	    }
	    all_1.nbars = 0;
	    if (*(unsigned char *)durq == ' ') {

/*  New voice is on next staff */

		++all_1.iv;
		commvl_1.ivx = all_1.iv;
	    } else {

/*  New voice is on same staff.  Set up for it */

		commvl_1.ivx = all_1.nv + 1;
		i__1 = all_1.nv;
		for (iiv = 1; iiv <= i__1; ++iiv) {
		    if (commvl_1.nvmx[iiv - 1] == 2) {
			++commvl_1.ivx;
		    }
/* L23: */
		}
		commvl_1.nvmx[all_1.iv - 1] = 2;
		commvl_1.ivmx[all_1.iv + 6] = commvl_1.ivx;
		all_1.itsofar[commvl_1.ivx - 1] = 0;
		all_1.nnl[commvl_1.ivx - 1] = 0;
		for (j = 1; j <= 200; ++j) {
		    all_1.rest[commvl_1.ivx + j * 7 - 8] = FALSE_;
/* L24: */
		}
	    }
	}
	all_1.iccount = 128;
    } else if (*(unsigned char *)charq == 'S') {

/* New nsyst: for use with partmaker scor2prt, for parts w/ diff # of 
systs.*/

	if (comnotes_1.ibarcnt > 0) {
	    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &all_1.iccount, &i__1, "\"S\" can only be in firs\
t input block!", 128L, 37L);
	    s_stop("1", 1L);
	}
	getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	readnum_(lineq, &all_1.iccount, durq, &fnsyst, 128L, 1L);
	compage_1.nsyst = (integer) (fnsyst + (float).1);
	if (*(unsigned char *)durq == 'P') {

/*  New npages for parts.  Assuming <10. */

	    getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	    if (i_indx("123456789", durq, 9L, 1L) == 0) {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "Symbol after \"P\" mu\
st be a digit!", 128L, 33L);
		s_stop("1", 1L);
	    }
	    compage_1.npages = *(unsigned char *)durq - 48;
	}
    } else if (*(unsigned char *)charq == 'L') {
	++compage_1.nflb;
	compage_1.ibarflb[compage_1.nflb] = comnotes_1.ibarcnt + all_1.nbars 
		+ 1;
	getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	if (i_indx("123456789", durq, 9L, 1L) == 0) {
	    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &all_1.iccount, &i__1, "Need integer to define fo\
rced line break!", 128L, 41L);
	    s_stop("1", 1L);
	}
	readnum_(lineq, &all_1.iccount, durq, &sysflb, 128L, 1L);
	compage_1.isysflb[compage_1.nflb] = (integer) (sysflb + (float).1);
	if (compage_1.nflb > 1) {

/*  Check if new number is > prior one */

	    if (compage_1.isysflb[compage_1.nflb] <= compage_1.isysflb[
		    compage_1.nflb - 1]) {
		i__1 = all_1.iccount - 1;
		i__2 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &i__1, &i__2, "You already forced a line brea\
k at a later line!", 128L, 48L);
		s_stop("1", 1L);
	    }
	}
	if (compage_1.npages == 0) {
	    s_wsle(&io___155);
	    e_wsle();
	    s_wsle(&io___156);
	    do_lio(&c__9, &c__1, "WARNING! You forced a line break at line ", 
		    41L);
	    do_lio(&c__3, &c__1, (char *)&compage_1.isysflb[compage_1.nflb], (
		    ftnlen)sizeof(integer));
	    do_lio(&c__9, &c__1, " but npage = 0.  Continue?", 26L);
	    e_wsle();
	    s_rsfe(&io___157);
	    do_fio(&c__1, charq, 1L);
	    e_rsfe();
	    if (i_indx("yY", charq, 2L, 1L) == 0) {
		s_stop("1", 1L);
	    }
	} else if (compage_1.isysflb[compage_1.nflb] > compage_1.nsyst) {
	    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &all_1.iccount, &i__1, "Forced line break at line\
 num > nsyst!", 128L, 38L);
	    s_stop("1", 1L);
	} else if (i_indx(" PM", durq, 3L, 1L) == 0) {
	    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &all_1.iccount, &i__1, "Must have \" \", \"P\", o\
r \"M\" here!", 128L, 32L);
	    s_stop("1", 1L);
	}
	if (*(unsigned char *)durq == 'P') {

/*  Forced page break here, get page number. */

	    getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
	    if (i_indx("23456789", durq, 8L, 1L) == 0) {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "Need integer to defin\
e forced page break!", 128L, 41L);
		s_stop("1", 1L);
	    }
	    readnum_(lineq, &all_1.iccount, durq, &fnum, 128L, 1L);
	    ++compage_1.nfpb;
	    compage_1.ipagfpb[compage_1.nfpb] = fnum + (float).1;
	    compage_1.isysfpb[compage_1.nfpb] = compage_1.isysflb[
		    compage_1.nflb];
	}
	if (i_indx(" M", durq, 2L, 1L) == 0) {
	    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &all_1.iccount, &i__1, "Illegal character in line\
break symbol!", 128L, 38L);
	    s_stop("1", 1L);
	} else if (*(unsigned char *)durq == 'M') {
	    getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
L31:
	    if (*(unsigned char *)durq == '+') {

/*  Vertical spacing, read past number. */

		getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
		if (i_indx("123456789", durq, 9L, 1L) == 0) {
		    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
			    all_1.nbars + 1;
		    errmsg_(lineq, &all_1.iccount, &i__1, "Integer required \
here!", 128L, 22L);
		    s_stop("1", 1L);
		}
		readnum_(lineq, &all_1.iccount, durq, &fnum, 128L, 1L);
		goto L31;
	    } else if (*(unsigned char *)durq == 'i') {

/*  Change indentation, read past number */

		getchar_(lineq, &all_1.iccount, durq, 128L, 1L);
		if (i_indx(".123456789", durq, 10L, 1L) == 0) {
		    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
			    all_1.nbars + 1;
		    errmsg_(lineq, &all_1.iccount, &i__1, "Decimal number re\
quired here!", 128L, 29L);
		    s_stop("1", 1L);
		}
		readnum_(lineq, &all_1.iccount, durq, &fnum, 128L, 1L);
		goto L31;
	    } else if (*(unsigned char *)durq != ' ') {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "Illegal character aft\
er Movement break symbol!", 128L, 46L);
		s_stop("1", 1L);
	    }
	}
    } else if (*(unsigned char *)charq == 'F') {
	compage_1.usefig = FALSE_;
    } else if (*(unsigned char *)charq == 'X') {
	getchar_(lineq, &all_1.iccount, charq, 128L, 1L);
	if (*(unsigned char *)charq == ':') {
	    if (! comkeys_1.shifton) {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "You ended a 1-voice s\
hift without starting one!", 128L, 47L);
		s_stop("1", 1L);
	    } else /* if(complicated condition) */ {
		i__1 = all_1.iccount;
		if (s_cmp(lineq + i__1, " ", all_1.iccount + 1 - i__1, 1L) != 
			0) {
		    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
			    all_1.nbars + 1;
		    errmsg_(lineq, &all_1.iccount, &i__1, "\":\" (end shift)\
 must be followed by a blank here!", 128L, 49L);
		    s_stop("1", 1L);
		}
	    }
	    comkeys_1.shifton = FALSE_;
	} else if (i_indx("0123456789.-", charq, 12L, 1L) == 0) {
	    i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	    errmsg_(lineq, &all_1.iccount, &i__1, "This character must be\
 \".\" , \"-\" , or a digit!", 128L, 46L);
	    s_stop("1", 1L);
	} else {
	    if (*(unsigned char *)charq == '-') {
		++all_1.iccount;
	    }
	    readnum_(lineq, &all_1.iccount, durq, &fnum, 128L, 1L);
	    if (*(unsigned char *)charq == '-') {
		fnum = -fnum;
	    }
	    if (i_indx(":Sp ", durq, 4L, 1L) == 0) {
		i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars 
			+ 1;
		errmsg_(lineq, &all_1.iccount, &i__1, "This must be \":\" ,\
 \"S\" , \"p\" , or blank!", 128L, 40L);
		s_stop("1", 1L);
	    } else /* if(complicated condition) */ {
		i__1 = all_1.iccount;
		if (i_indx(":Sp", durq, 3L, 1L) > 0 && s_cmp(lineq + i__1, 
			" ", all_1.iccount + 1 - i__1, 1L) != 0) {
		    i__1 = all_1.iccount + 1;
		    i__2 = comnotes_1.ibarcnt - comnotes_1.ibaroff + 
			    all_1.nbars + 1;
		    errmsg_(lineq, &i__1, &i__2, "There must be a blank here!"
			    , 128L, 27L);
		    s_stop("1", 1L);
		}
	    }
	    if (*(unsigned char *)durq == ':') {
		comkeys_1.shifton = TRUE_;
	    } else {
		if (*(unsigned char *)durq != 'p') {
		    fnum *= comnotes_1.wheadpt;
		}
		comnotes_1.udsp[comnotes_1.ibarcnt + all_1.nbars] += fnum;
	    }
	}
    } else if (*(unsigned char *)charq == 'M') {
	setmac_(lineq, &all_1.iccount, &comnotes_1.ibarcnt, &
		comnotes_1.ibaroff, &all_1.nbars, charq, durq, 128L, 1L, 1L);
    } else {
	i__1 = comnotes_1.ibarcnt - comnotes_1.ibaroff + all_1.nbars + 1;
	errmsg_(lineq, &all_1.iccount, &i__1, "Illegal character!", 128L, 18L)
		;
	s_stop("1", 1L);
    }
    return 0;
} /* getnote_ */

/* Subroutine */ int getchar_(lineq, iccount, charq, lineq_len, charq_len)
char *lineq;
integer *iccount;
char *charq;
ftnlen lineq_len;
ftnlen charq_len;
{
    /* Builtin functions */
    /* Subroutine */ int s_copy();

    /* Local variables */
    static integer ndxm;
    extern /* Subroutine */ int mrec1_(), read10_();
    static integer nbars, ibaroff, ibarcnt;


/* Gets the next character out of lineq*128.  If pointer iccount=128 on en
try,*/
/* then reads in a new line.  Resets iccount.  Ends program if no more inp
ut.*/

    if (*iccount == 128) {
	read10_(lineq, &c__128, &comget_1.lastchar, 128L);
	if (comget_1.lastchar) {
	    return 0;
	}
	if (! commac_1.endmac) {
	    *iccount = 0;
	    if (! commac_1.mplay) {
		++comget_1.nline;
	    }
	} else {
	    commac_1.endmac = FALSE_;
	    *iccount = commac_1.icchold;
	    s_copy(lineq, commac_1.lnholdq, 128L, 128L);
	}
	if (commac_1.mrecord) {
	    mrec1_(lineq, iccount, &ibarcnt, &ibaroff, &nbars, &ndxm, 128L);
	}
    }
    ++(*iccount);
    *(unsigned char *)charq = *(unsigned char *)&lineq[*iccount - 1];
    return 0;
} /* getchar_ */

integer ifnodur_(idur, dotq, dotq_len)
integer *idur;
char *dotq;
ftnlen dotq_len;
{
    /* System generated locals */
    integer ret_val;

    /* Builtin functions */
    integer s_wsle(), e_wsle(), do_lio();
    /* Subroutine */ int s_stop();

    /* Fortran I/O blocks */
    static cilist io___162 = { 0, 6, 0, 0, 0 };
    static cilist io___163 = { 0, 6, 0, 0, 0 };


    if (*idur == 6) {
	ret_val = 1;
    } else if (*idur == 3) {
	ret_val = 2;
    } else if (*idur == 1) {
	ret_val = 4;
    } else if (*idur == 8) {
	ret_val = 8;
    } else if (*idur == 4) {
	ret_val = 16;
    } else if (*idur == 2) {
	ret_val = 32;
    } else if (*idur == 0) {
	ret_val = 64;
    } else if (*idur == 16) {

/*  Only used for denominator of time signatures, not for notes */

	ret_val = 4;
    } else if (*idur == 9) {
	ret_val = 128;
    } else {
	s_wsle(&io___162);
	e_wsle();
	s_wsle(&io___163);
	do_lio(&c__9, &c__1, "You entered an invalid note-length value:", 41L)
		;
	do_lio(&c__3, &c__1, (char *)&(*idur), (ftnlen)sizeof(integer));
	e_wsle();
	s_stop("1", 1L);
    }
    if (*(unsigned char *)dotq == 'd') {
	ret_val = ret_val * 3 / 2;
    }
    return ret_val;
} /* ifnodur_ */

/* Subroutine */ int makeabar_()
{
    /* System generated locals */
    integer i__1, i__2, i__3, i__4;
    real r__1;

    /* Builtin functions */
    integer pow_ii();
    double r_dim();

    /* Local variables */
    static integer ilnc;
    extern doublereal feon_();
    extern /* Subroutine */ int catspace_();
    static integer nnsk, iptr, ntot, ntup;
    static real elsperns;
    static integer itxstart, ltime, itmin, iiptr, istop[20];
    static logical intup;
    static integer ntupm, lxtup, ib, nb, in, it[7], kv, nspace[20];
    extern integer kindxf_();
    static integer nindex[20], ixtend, itminn;
    static logical herext;
    static integer istart[20], ivnext;
    static real elxtup;
    static integer iib, cnn[7], nsk;
    static real elother;
    static integer itstart[20];

    linecom_1.elskb = (float)0.;
/*      ieminb(ibarcnt) = 1000 */
    comnotes_1.ieminb[comnotes_1.ibarcnt - 1] = 0;
/*      iemaxb(ibarcnt) = 0 */
    i__1 = all_1.nv;
    for (all_1.iv = 1; all_1.iv <= i__1; ++all_1.iv) {
	i__2 = commvl_1.nvmx[all_1.iv - 1];
	for (kv = 1; kv <= i__2; ++kv) {
	    commvl_1.ivx = commvl_1.ivmx[all_1.iv + kv * 7 - 8];
	    if (all_1.ibar > 1) {
		all_1.nn[commvl_1.ivx - 1] = all_1.nib[commvl_1.ivx + 
			all_1.ibar * 7 - 8] - all_1.nib[commvl_1.ivx + (
			all_1.ibar - 1) * 7 - 8];
	    } else {
		all_1.nn[commvl_1.ivx - 1] = all_1.nib[commvl_1.ivx + 
			all_1.ibar * 7 - 8];
	    }
/* L1: */
	}
    }

/* initialize list note counter, time(iv), curr. note(iv) */

    ilnc = 1;
    i__2 = all_1.nv;
    for (all_1.iv = 1; all_1.iv <= i__2; ++all_1.iv) {
	i__1 = commvl_1.nvmx[all_1.iv - 1];
	for (kv = 1; kv <= i__1; ++kv) {
	    commvl_1.ivx = commvl_1.ivmx[all_1.iv + kv * 7 - 8];
	    cnn[commvl_1.ivx - 1] = 1;
L2:
	    all_1.list[(ilnc << 2) - 4] = commvl_1.ivx;
	    all_1.list[(ilnc << 2) - 3] = cnn[commvl_1.ivx - 1];
	    all_1.list[(ilnc << 2) - 2] = 0;
	    it[commvl_1.ivx - 1] = all_1.nodur[commvl_1.ivx + cnn[
		    commvl_1.ivx - 1] * 7 - 8];
	    if (all_1.nodur[commvl_1.ivx + cnn[commvl_1.ivx - 1] * 7 - 8] == 
		    0) {

/*  To keep all notes of xtup together, get another note from 
this voice */

		++ilnc;
		++cnn[commvl_1.ivx - 1];
		goto L2;
	    }
	    if (it[commvl_1.ivx - 1] == all_1.lenbar) {
		it[commvl_1.ivx - 1] = 1000;
	    }
	    ++ilnc;
/* L4: */
	}
    }

/*  Build the list */

L5:

/*  Determine which voice comes next from end of notes done so far. */
/*  itmin is the earliest ending time of notes done so far */

    itmin = 1000;
    i__1 = all_1.nv;
    for (all_1.iv = 1; all_1.iv <= i__1; ++all_1.iv) {
	i__2 = commvl_1.nvmx[all_1.iv - 1];
	for (kv = 1; kv <= i__2; ++kv) {
	    commvl_1.ivx = commvl_1.ivmx[all_1.iv + kv * 7 - 8];
/* Computing MIN */
	    i__3 = itmin, i__4 = it[commvl_1.ivx - 1];
	    itminn = min(i__3,i__4);
	    if (itminn < itmin) {
		itmin = itminn;
		ivnext = commvl_1.ivx;
	    }
/* L6: */
	}
    }
    if (itmin == 1000) {
	goto L7;
    }
    all_1.list[(ilnc << 2) - 4] = ivnext;
    ++cnn[ivnext - 1];
    all_1.list[(ilnc << 2) - 3] = cnn[ivnext - 1];
    all_1.list[(ilnc << 2) - 2] = itmin;

/*  Check if this voice is done */

    if (cnn[ivnext - 1] == all_1.nn[ivnext - 1]) {
	it[ivnext - 1] = 1000;
    } else {
	it[ivnext - 1] += all_1.nodur[ivnext + cnn[ivnext - 1] * 7 - 8];
    }
    ++ilnc;
    goto L5;
L7:
    ntot = ilnc - 1;
    i__2 = ntot - 1;
    for (in = 1; in <= i__2; ++in) {
	all_1.list[(in << 2) - 1] = all_1.list[(in + 1 << 2) - 2] - 
		all_1.list[(in << 2) - 2];
/* L8: */
    }
    all_1.list[(ntot << 2) - 1] = all_1.nodur[all_1.list[(ntot << 2) - 4] + 
	    all_1.list[(ntot << 2) - 3] * 7 - 8];

/*  Debug writes */

/*     write(*,'(26i3)')(list(1,in),in=1,ntot) */
/*     write(*,'(26i3)')(list(2,in),in=1,ntot) */
/*     write(*,'(26i3)')(list(3,in),in=1,ntot) */
/*     write(*,'(26i3)')(list(4,in),in=1,ntot) */
/*     write(*,'(26i3)')(nodur(list(1,in),list(2,in)),in=1,ntot) */

/*  Done w/ list.  A kluged up loop for building note blocks: */

    ib = 1;
    istart[0] = 1;
    nspace[0] = 0;
    in = 1;
L9:
    if (in == ntot) {
	if (nspace[ib - 1] == 0) {
	    nspace[ib - 1] = all_1.list[(in << 2) - 1];
	}
	istop[ib - 1] = ntot;

/* Now we flow out of this if and into block-building */

    } else if (nspace[ib - 1] == 0) {

/* nspace hasn't been set yet, so tentatively set: */

	nspace[ib - 1] = all_1.list[(in << 2) - 1];
	if (nspace[ib - 1] == 0) {
	    ++in;
	} else {
	    istop[ib - 1] = in;
	}
	goto L9;
    } else if (all_1.list[(in + 1 << 2) - 1] == 0) {

/* This is not the last note in the group, so */

	++in;
	goto L9;
    } else if (all_1.list[(in + 1 << 2) - 1] == nspace[ib - 1]) {

/* Keep spacing the same, update tentative stop point */

	++in;
	istop[ib - 1] = in;
	goto L9;
    }

/* At this point istart and istop are good, so close out block */

    itstart[ib - 1] = all_1.list[(istart[ib - 1] << 2) - 2];
    nindex[ib - 1] = kindxf_(&nspace[ib - 1]);
    comnotes_1.ieminb[comnotes_1.ibarcnt - 1] |= pow_ii(&c__2, &nindex[ib - 1]
	    );
/*        iemaxb(ibarcnt) = max(iemaxb(ibarcnt),nindex(ib)) */
    r__1 = (real) nspace[ib - 1];
    elsperns = feon_(&r__1);
    if (istop[ib - 1] == ntot) {
	nnsk = (all_1.lenbar - itstart[ib - 1]) / nspace[ib - 1];
    } else {
	nnsk = (all_1.list[(istop[ib - 1] + 1 << 2) - 2] - itstart[ib - 1]) / 
		nspace[ib - 1];
    }
    linecom_1.elskb += elsperns * nnsk;
    if (comnotes_1.nptr[comnotes_1.ibarcnt] > comnotes_1.nptr[
	    comnotes_1.ibarcnt - 1]) {
	r__1 = (real) nspace[ib - 1];
	catspace_(&r__1, &nnsk);
    } else {

/*  This is the first entry for this bar */

	comnotes_1.nnpd[comnotes_1.nptr[comnotes_1.ibarcnt - 1] - 1] = nnsk;
	comnotes_1.durb[comnotes_1.nptr[comnotes_1.ibarcnt - 1] - 1] = (real) 
		nspace[ib - 1];
	++comnotes_1.nptr[comnotes_1.ibarcnt];
    }
    if (istop[ib - 1] == ntot) {
	goto L15;
    }

/*  End of spatial accounting for now */

    ++ib;
    istart[ib - 1] = istop[ib - 2] + 1;
    in = istart[ib - 1];

/* Set tentative block space for new block */

    nspace[ib - 1] = all_1.list[(in << 2) - 1];
    istop[ib - 1] = in;
    goto L9;
L15:
    nb = ib;
/*     write(*,'(24i3)')(istart(ib),istop(ib),ib=1,nb) */

/*  Run through blocks, correcting elskb as needed for xtuplets */

    i__2 = nb;
    for (ib = 1; ib <= i__2; ++ib) {
	herext = FALSE_;
	intup = FALSE_;
	i__1 = istop[ib - 1];
	for (in = istart[ib - 1]; in <= i__1; ++in) {
	    if (all_1.nodur[all_1.list[(in << 2) - 4] + all_1.list[(in << 2) 
		    - 3] * 7 - 8] == 0) {
		if (! herext) {

/*  New window with some number of xtups starts here. */

		    ntupm = 0;
		    herext = TRUE_;
		    itxstart = all_1.list[(in << 2) - 2];
		}
		if (! intup) {

/*  New xtup starts here */

		    ntup = 0;
		    intup = TRUE_;
		}
		++ntup;
		goto L101;
	    } else if (intup) {

/*  xtup ends here */

		++ntup;
		lxtup = all_1.nodur[all_1.list[(in << 2) - 4] + all_1.list[(
			in << 2) - 3] * 7 - 8];
		if (ntup >= ntupm) {
		    ntupm = ntup;
		}
		intup = FALSE_;
	    }
	    if (herext && (in == istop[ib - 1] || all_1.list[(in + 1 << 2) - 
		    2] != itxstart)) {

/*  Finished with all notes starting where xtup starts, so clo
se out. */

		ixtend = itxstart + lxtup;

/*  Compute "natural" length (in *elemskips) of xtuplet */

		r__1 = lxtup / (float)1. / ntupm;
		elxtup = ntupm * feon_(&r__1);

/*  Compute natural lengths of other stuff spanning same time 
interval */

		if (ixtend <= all_1.list[(istop[ib - 1] << 2) - 2] + 
			all_1.list[(istop[ib - 1] << 2) - 1]) {

/*  xtup is contained in a single block */

		    nsk = lxtup / nspace[ib - 1];
		    r__1 = lxtup / (float)1. / nsk;
		    elother = nsk * feon_(&r__1);
		} else {

/*  xtup spills over to next block */

		    ltime = itstart[ib] - itxstart;
		    nsk = ltime / nspace[ib - 1];
		    r__1 = (real) nspace[ib - 1];
		    elother = nsk * feon_(&r__1);
		    i__3 = nb;
		    for (iib = ib + 1; iib <= i__3; ++iib) {
			if (ixtend <= all_1.list[(istop[iib - 1] << 2) - 2] + 
				all_1.list[(istop[iib - 1] << 2) - 1]) {
			    ltime = ixtend - itstart[iib - 1];
			    nsk = ltime / nspace[iib - 1];
			    r__1 = (real) nspace[iib - 1];
			    elother += nsk * feon_(&r__1);
			    goto L104;
			} else {
			    ltime = all_1.list[(istop[iib - 1] << 2) - 2] + 
				    all_1.list[(istop[iib - 1] << 2) - 1] - 
				    itstart[iib - 1];
			    nsk = ltime / nspace[iib - 1];
			    r__1 = (real) nspace[iib - 1];
			    elother += nsk * feon_(&r__1);
			}
/* L103: */
		    }
		}
L104:
		linecom_1.elskb += r_dim(&elxtup, &elother);
		if (elxtup > elother) {

/*  Need to adjust catalog of tspaces */

		    r__1 = (real) lxtup / ntupm;
		    catspace_(&r__1, &ntupm);
		    r__1 = (real) lxtup;
		    catspace_(&r__1, &c_n1);
		}
		herext = FALSE_;
		ntupm = 0;
	    }
L101:
	    ;
	}
/* L100: */
    }

/* Eliminate any zeroes in nnpd.  Manual loop since upper limit may change
.*/

    iptr = comnotes_1.nptr[comnotes_1.ibarcnt - 1];
L105:
    if (iptr > comnotes_1.nptr[comnotes_1.ibarcnt] - 1) {
	goto L106;
    }
    if (comnotes_1.nnpd[iptr - 1] == 0) {
	--comnotes_1.nptr[comnotes_1.ibarcnt];
	i__2 = comnotes_1.nptr[comnotes_1.ibarcnt] - 1;
	for (iiptr = iptr; iiptr <= i__2; ++iiptr) {
	    comnotes_1.nnpd[iiptr - 1] = comnotes_1.nnpd[iiptr];
	    comnotes_1.durb[iiptr - 1] = comnotes_1.durb[iiptr];
/* L107: */
	}
    } else {
	++iptr;
    }
    goto L105;
L106:
    return 0;
} /* makeabar_ */

doublereal feon_(time)
real *time;
{
    /* System generated locals */
    real ret_val;

    /* Builtin functions */
    double sqrt();

/*       feon = max(1.8,1.+alog(time/2)/.69315) */
    ret_val = sqrt(*time / 2);
    return ret_val;
} /* feon_ */

integer kindxf_(nspace)
integer *nspace;
{
    /* System generated locals */
    integer ret_val;

    /* Builtin functions */
    double log();

    ret_val = log(*nspace * (float)1.) * 2 / (float).69315 + (float)1.3;
    return ret_val;
} /* kindxf_ */

doublereal tspace_(ie)
integer *ie;
{
    /* System generated locals */
    integer i__1;
    real ret_val;

    /* Builtin functions */
    double pow_ri(), sqrt();

    if (*ie % 2 == 0) {
	i__1 = *ie / 2;
	ret_val = pow_ri(&c_b681, &i__1) * (float).75;
    } else {
	i__1 = *ie - 1;
	ret_val = sqrt(pow_ri(&c_b681, &i__1));
    }
    return ret_val;
} /* tspace_ */

/* Subroutine */ int catspace_(tspace, nnsk)
real *tspace;
integer *nnsk;
{
    /* System generated locals */
    integer i__1, i__2;
    real r__1;

    /* Local variables */
    static integer iptr, jptr;

    i__1 = comnotes_1.nptr[comnotes_1.ibarcnt] - 1;
    for (iptr = comnotes_1.nptr[comnotes_1.ibarcnt - 1]; iptr <= i__1; ++iptr)
	     {
	if ((r__1 = *tspace - comnotes_1.durb[iptr - 1], dabs(r__1)) < (float)
		.001) {

/*  Must increment old entry */

	    comnotes_1.nnpd[iptr - 1] += *nnsk;
	    return 0;
	}
/* L16: */
    }

/*  Didn't find current duration, must add a new entry */

    i__1 = comnotes_1.nptr[comnotes_1.ibarcnt] - 1;
    for (iptr = comnotes_1.nptr[comnotes_1.ibarcnt - 1]; iptr <= i__1; ++iptr)
	     {
	if (*tspace < comnotes_1.durb[iptr - 1]) {

/*  New entry will go at this iptr.  Bump up the rest */

	    i__2 = iptr;
	    for (jptr = comnotes_1.nptr[comnotes_1.ibarcnt] - 1; jptr >= i__2;
		     --jptr) {
		comnotes_1.nnpd[jptr] = comnotes_1.nnpd[jptr - 1];
		comnotes_1.durb[jptr] = comnotes_1.durb[jptr - 1];
/* L19: */
	    }
	    comnotes_1.nnpd[iptr - 1] = *nnsk;
	    comnotes_1.durb[iptr - 1] = *tspace;
	    ++comnotes_1.nptr[comnotes_1.ibarcnt];
	    return 0;
	}
/* L18: */
    }

/*  New entry goes at the end */

    comnotes_1.nnpd[comnotes_1.nptr[comnotes_1.ibarcnt] - 1] = *nnsk;
    comnotes_1.durb[comnotes_1.nptr[comnotes_1.ibarcnt] - 1] = *tspace;
    ++comnotes_1.nptr[comnotes_1.ibarcnt];
    return 0;
} /* catspace_ */

/* Subroutine */ int chklit_(lineq, iccount, literr, lineq_len)
char *lineq;
integer *iccount, *literr;
ftnlen lineq_len;
{
    static char charq[1];
    static integer itype, lenlit;
    extern /* Subroutine */ int getchar_();

    *literr = 0;
    itype = 1;
L17:
    getchar_(lineq, iccount, charq, 128L, 1L);
    if (*(unsigned char *)charq == '\\') {
	++itype;
	if (itype > 3) {
	    *literr = 1;
	    return 0;
	}
	goto L17;
    }
    lenlit = itype;
L18:
    getchar_(lineq, iccount, charq, 128L, 1L);
    if (*(unsigned char *)charq == '\\') {
	getchar_(lineq, iccount, charq, 128L, 1L);
	if (*(unsigned char *)charq != ' ') {

/*  Starting a new tex command withing the string */

	    lenlit += 2;
	    if (lenlit > 128) {
		*literr = 2;
		return 0;
/*           print*,'TeX string must have <80 char, end w/ " '
 */
/*    *         //char(92)//'"' */
/*           stop */
	    }
	    goto L18;
	}
    } else {
	++lenlit;
	if (lenlit > 128) {
	    *literr = 2;
	    return 0;
	}
	goto L18;
    }
    return 0;
} /* chklit_ */

/* Subroutine */ int readnum_(lineq, iccount, durq, fnum, lineq_len, durq_len)
char *lineq;
integer *iccount;
char *durq;
real *fnum;
ftnlen lineq_len;
ftnlen durq_len;
{
    /* System generated locals */
    address a__1[3];
    integer i__1[3];
    char ch__1[27], ch__2[6], ch__3[1];
    icilist ici__1;

    /* Builtin functions */
    integer i_indx(), s_wsle();
    /* Subroutine */ int s_cat();
    integer do_lio(), e_wsle();
    /* Subroutine */ int s_stop();
    integer s_rsfi(), do_fio(), e_rsfi();

    /* Local variables */
    static integer i1, i2, icf;
    extern /* Subroutine */ int getchar_();

    /* Fortran I/O blocks */
    static cilist io___203 = { 0, 6, 0, 0, 0 };


    i1 = *iccount;
L1:
    getchar_(lineq, iccount, durq, 128L, 1L);
    if (i_indx("0123456789.", durq, 11L, 1L) > 0) {
	goto L1;
    }
    i2 = *iccount - 1;
    if (i2 < i1) {
	s_wsle(&io___203);
/* Writing concatenation */
	i__1[0] = 7, a__1[0] = "Found \"";
	i__1[1] = 1, a__1[1] = durq;
	i__1[2] = 19, a__1[2] = "\" instead of number";
	s_cat(ch__1, a__1, i__1, &c__3, 27L);
	do_lio(&c__9, &c__1, ch__1, 27L);
	e_wsle();
	s_stop("1", 1L);
    }
    icf = i2 - i1 + 49;
    ici__1.icierr = 0;
    ici__1.iciend = 0;
    ici__1.icirnum = 1;
    ici__1.icirlen = i2 - (i1 - 1);
    ici__1.iciunit = lineq + (i1 - 1);
/* Writing concatenation */
    i__1[0] = 2, a__1[0] = "(f";
    *(unsigned char *)&ch__3[0] = icf;
    i__1[1] = 1, a__1[1] = ch__3;
    i__1[2] = 3, a__1[2] = ".0)";
    ici__1.icifmt = (s_cat(ch__2, a__1, i__1, &c__3, 6L), ch__2);
    s_rsfi(&ici__1);
    do_fio(&c__1, (char *)&(*fnum), (ftnlen)sizeof(real));
    e_rsfi();
    return 0;
} /* readnum_ */

/* Subroutine */ int readmeter_(lineq, iccount, mtrnum, mtrden, lineq_len)
char *lineq;
integer *iccount, *mtrnum, *mtrden;
ftnlen lineq_len;
{
    /* System generated locals */
    address a__1[3];
    integer i__1, i__2[3];
    char ch__1[4], ch__2[1];
    icilist ici__1;

    /* Builtin functions */
    integer i_indx();
    /* Subroutine */ int s_cat();
    integer s_rsfi(), do_fio(), e_rsfi();

    /* Local variables */
    static char durq[1];
    static integer ns;
    extern /* Subroutine */ int getchar_();

    i__1 = *iccount;
    if (i_indx(lineq + i__1, "/", *iccount + 3 - i__1, 1L) == 0) {

/*  No slashes, so use old method */

	getchar_(lineq, iccount, durq, 128L, 1L);
	if (*(unsigned char *)durq == '-') {

/*  Negative numerator is used only to printed; signals vertical s
lash */

	    getchar_(lineq, iccount, durq, 128L, 1L);
	    *mtrnum = -(*(unsigned char *)durq - 48);
	} else if (*(unsigned char *)durq == 'o') {

/*  Numerator is EXACTLY 1 */

	    *mtrnum = 1;
	} else {
	    *mtrnum = *(unsigned char *)durq - 48;
	    if (*mtrnum == 1) {

/*  Numerator is >9 */

		getchar_(lineq, iccount, durq, 128L, 1L);
		*mtrnum = *(unsigned char *)durq - 38;
	    }
	}
	getchar_(lineq, iccount, durq, 128L, 1L);
	if (*(unsigned char *)durq == 'o') {
	    *mtrden = 1;
	} else {
	    *mtrden = *(unsigned char *)durq - 48;
	    if (*mtrden == 1) {
		getchar_(lineq, iccount, durq, 128L, 1L);
		*mtrden = *(unsigned char *)durq - 38;
	    }
	}
    } else {

/* Expect the form m[n1]/[n2]/[n3]/[n4] . Advance iccount by one from 
'/' or 'm'*/

	++(*iccount);
	ns = i_indx(lineq + (*iccount - 1), "/", 128 - (*iccount - 1), 1L);
	ici__1.icierr = 0;
	ici__1.iciend = 0;
	ici__1.icirnum = 1;
	ici__1.icirlen = *iccount + ns - 2 - (*iccount - 1);
	ici__1.iciunit = lineq + (*iccount - 1);
/* Writing concatenation */
	i__2[0] = 2, a__1[0] = "(i";
	*(unsigned char *)&ch__2[0] = ns + 48;
	i__2[1] = 1, a__1[1] = ch__2;
	i__2[2] = 1, a__1[2] = ")";
	ici__1.icifmt = (s_cat(ch__1, a__1, i__2, &c__3, 4L), ch__1);
	s_rsfi(&ici__1);
	do_fio(&c__1, (char *)&(*mtrnum), (ftnlen)sizeof(integer));
	e_rsfi();

/*  Reset iccount to start of second integer */

	*iccount += ns;

/*  There must be either a slash or a blank at pos'n 2 or 3 */

	ns = i_indx(lineq + (*iccount - 1), "/", 3L, 1L);
	if (ns == 0) {
	    ns = i_indx(lineq + (*iccount - 1), " ", 3L, 1L);
	}
	ici__1.icierr = 0;
	ici__1.iciend = 0;
	ici__1.icirnum = 1;
	ici__1.icirlen = *iccount + ns - 2 - (*iccount - 1);
	ici__1.iciunit = lineq + (*iccount - 1);
/* Writing concatenation */
	i__2[0] = 2, a__1[0] = "(i";
	*(unsigned char *)&ch__2[0] = ns + 48;
	i__2[1] = 1, a__1[1] = ch__2;
	i__2[2] = 1, a__1[2] = ")";
	ici__1.icifmt = (s_cat(ch__1, a__1, i__2, &c__3, 4L), ch__1);
	s_rsfi(&ici__1);
	do_fio(&c__1, (char *)&(*mtrden), (ftnlen)sizeof(integer));
	e_rsfi();

/*  Set iccount to last character used */

	*iccount = *iccount + ns - 1;
    }
    return 0;
} /* readmeter_ */

/* Subroutine */ int errmsg_(lineq, iccount, ibarno, msgq, lineq_len, 
	msgq_len)
char *lineq;
integer *iccount, *ibarno;
char *msgq;
ftnlen lineq_len;
ftnlen msgq_len;
{
    /* System generated locals */
    address a__1[2], a__2[5], a__3[4];
    integer i__1[2], i__2, i__3, i__4[5], i__5[4];
    real r__1;
    char ch__1[18], ch__2[1], ch__3[1], ch__4[130], ch__5[7];
    cilist ci__1;

    /* Builtin functions */
    /* Subroutine */ int s_copy(), s_cat();
    integer s_wsle(), e_wsle();
    double r_lg10();
    integer i_indx(), s_wsfe(), do_fio(), e_wsfe(), do_lio();

    /* Local variables */
    static char outq[78];
    static integer iposn, i1, i10, ndigbn, ndignl, lenmsg;

    /* Fortran I/O blocks */
    static cilist io___209 = { 0, 6, 0, 0, 0 };
    static cilist io___215 = { 0, 6, 0, 0, 0 };


    if (*iccount <= 78) {
	s_copy(outq, lineq, 78L, 78L);
	iposn = *iccount;
    } else {
/* Writing concatenation */
	i__1[0] = 4, a__1[0] = "... ";
	i__1[1] = 74, a__1[1] = lineq + 54;
	s_cat(outq, a__1, i__1, &c__2, 78L);
	iposn = *iccount - 50;
    }
    s_wsle(&io___209);
    e_wsle();
/* Computing MAX */
    r__1 = *ibarno + (float).1;
    i__2 = 1, i__3 = (integer) (r_lg10(&r__1) + 1);
    ndigbn = max(i__2,i__3);
    r__1 = comget_1.nline + (float).1;
    ndignl = (integer) (r_lg10(&r__1) + 1);
    lenmsg = i_indx(msgq, "!", 128L, 1L) - 1;
/*     write(*,'(a15,i'//char(48+ndignl)//',a6,i'//char(48+ndigbn)// */
    ci__1.cierr = 0;
    ci__1.ciunit = 6;
/* Writing concatenation */
    i__4[0] = 8, a__2[0] = "(/,a15,i";
    *(unsigned char *)&ch__2[0] = ndignl + 48;
    i__4[1] = 1, a__2[1] = ch__2;
    i__4[2] = 5, a__2[2] = ",a6,i";
    *(unsigned char *)&ch__3[0] = ndigbn + 48;
    i__4[3] = 1, a__2[3] = ch__3;
    i__4[4] = 3, a__2[4] = ",a)";
    ci__1.cifmt = (s_cat(ch__1, a__2, i__4, &c__5, 18L), ch__1);
    s_wsfe(&ci__1);
    do_fio(&c__1, " ERROR in line ", 15L);
    do_fio(&c__1, (char *)&comget_1.nline, (ftnlen)sizeof(integer));
    do_fio(&c__1, ", bar ", 6L);
    do_fio(&c__1, (char *)&(*ibarno), (ftnlen)sizeof(integer));
/* Writing concatenation */
    i__1[0] = 2, a__1[0] = ": ";
    i__1[1] = lenmsg, a__1[1] = msgq;
    s_cat(ch__4, a__1, i__1, &c__2, 130L);
    do_fio(&c__1, ch__4, lenmsg + 2);
    e_wsfe();
    i10 = iposn / 10;
    i1 = iposn - i10 * 10;
/*     write(*,'('//char(48+i10)//char(48+i1)//'x,a)')char(25) */
    ci__1.cierr = 0;
    ci__1.ciunit = 6;
/* Writing concatenation */
    i__5[0] = 1, a__3[0] = "(";
    *(unsigned char *)&ch__2[0] = i10 + 48;
    i__5[1] = 1, a__3[1] = ch__2;
    *(unsigned char *)&ch__3[0] = i1 + 48;
    i__5[2] = 1, a__3[2] = ch__3;
    i__5[3] = 4, a__3[3] = "x,a)";
    ci__1.cifmt = (s_cat(ch__5, a__3, i__5, &c__4, 7L), ch__5);
    s_wsfe(&ci__1);
    do_fio(&c__1, "v", 1L);
    e_wsfe();
    s_wsle(&io___215);
    do_lio(&c__9, &c__1, outq, 78L);
    e_wsle();
/*     write(*,'('//char(48+i10)//char(48+i1)//'x,a)')char(24) */
    ci__1.cierr = 0;
    ci__1.ciunit = 6;
/* Writing concatenation */
    i__5[0] = 1, a__3[0] = "(";
    *(unsigned char *)&ch__2[0] = i10 + 48;
    i__5[1] = 1, a__3[1] = ch__2;
    *(unsigned char *)&ch__3[0] = i1 + 48;
    i__5[2] = 1, a__3[2] = ch__3;
    i__5[3] = 4, a__3[3] = "x,a)";
    ci__1.cifmt = (s_cat(ch__5, a__3, i__5, &c__4, 7L), ch__5);
    s_wsfe(&ci__1);
    do_fio(&c__1, "^", 1L);
    e_wsfe();
    return 0;
} /* errmsg_ */


/* Subroutine */ int mrec1_(lineq, iccount, ibarcnt, ibaroff, nbars, ndxm, 
	lineq_len)
char *lineq;
integer *iccount, *ibarcnt, *ibaroff, *nbars, *ndxm;
ftnlen lineq_len;
{
    /* System generated locals */
    integer i__1, i__2;
    olist o__1;

    /* Builtin functions */
    integer f_open(), i_indx(), s_cmp();
    /* Subroutine */ int s_stop();
    integer s_wsfe(), do_fio(), e_wsfe();

    /* Local variables */
    extern /* Subroutine */ int errmsg_();

    /* Fortran I/O blocks */
    static cilist io___216 = { 0, 0, 0, "(a)", 0 };
    static cilist io___217 = { 0, 0, 0, "(a)", 0 };



/*  This is called when (a) macro recording is just starting and */
/*  (b) at the start of a new line, if recording is on */

    if (! commac_1.mrecord) {

/*  Starting the macro */

	o__1.oerr = 0;
	o__1.ounit = commac_1.macnum + 20;
	o__1.ofnm = 0;
	o__1.orl = 0;
	o__1.osta = "SCRATCH";
	o__1.oacc = 0;
	o__1.ofm = 0;
	o__1.oblnk = 0;
	f_open(&o__1);
	commac_1.mrecord = TRUE_;
    }
    if (*iccount < 128) {
	i__1 = *iccount;
	*ndxm = i_indx(lineq + i__1, "M", 128 - i__1, 1L);
	if (*ndxm > 0) {

/*  This line ends the macro. */

	    i__1 = *iccount + *ndxm;
	    if (s_cmp(lineq + i__1, " ", *iccount + *ndxm + 1 - i__1, 1L) != 
		    0) {
		i__1 = *iccount + *ndxm + 1;
		i__2 = *ibarcnt - *ibaroff + *nbars + 1;
		errmsg_(lineq, &i__1, &i__2, "Improper macro termination!", 
			128L, 27L);
		s_stop("1", 1L);
	    }
/*         if (iccount.gt.0) then */

/*  Check that M is not the only character in the line */

/*         if (iccount.ne.1) then */
	    if (*ndxm > 1) {
		io___216.ciunit = commac_1.macnum + 20;
		s_wsfe(&io___216);
		i__1 = *iccount;
		do_fio(&c__1, lineq + i__1, *iccount + *ndxm - 1 - i__1);
		e_wsfe();
	    }
	    commac_1.mrecord = FALSE_;
	} else {

/*  This line just continues the macro */

	    io___217.ciunit = commac_1.macnum + 20;
	    s_wsfe(&io___217);
	    i__1 = *iccount;
	    do_fio(&c__1, lineq + i__1, 128 - i__1);
	    e_wsfe();
	}
    }
    return 0;
} /* mrec1_ */

/* Subroutine */ int read10_(string, lenstr, lastchar, string_len)
char *string;
integer *lenstr;
logical *lastchar;
ftnlen string_len;
{
    /* System generated locals */
    integer i__1;

    /* Builtin functions */
    integer s_rsfe(), do_fio(), e_rsfe();

    /* Fortran I/O blocks */
    static cilist io___218 = { 0, 10, 1, "(a)", 0 };
    static cilist io___219 = { 0, 0, 1, "(a)", 0 };


    if (! commac_1.mplay) {
	i__1 = s_rsfe(&io___218);
	if (i__1 != 0) {
	    goto L999;
	}
	i__1 = do_fio(&c__1, string, (*lenstr));
	if (i__1 != 0) {
	    goto L999;
	}
	i__1 = e_rsfe();
	if (i__1 != 0) {
	    goto L999;
	}
	return 0;
L999:
	*lastchar = TRUE_;
	return 0;
    } else {
	io___219.ciunit = commac_1.macnum + 20;
	i__1 = s_rsfe(&io___219);
	if (i__1 != 0) {
	    goto L998;
	}
	i__1 = do_fio(&c__1, string, string_len);
	if (i__1 != 0) {
	    goto L998;
	}
	i__1 = e_rsfe();
	if (i__1 != 0) {
	    goto L998;
	}
	return 0;
L998:
	commac_1.mplay = FALSE_;
	commac_1.endmac = TRUE_;
	return 0;
    }
} /* read10_ */

/* Subroutine */ int setmac_(lineq, iccount, ibarcnt, ibaroff, nbars, charq, 
	durq, lineq_len, charq_len, durq_len)
char *lineq;
integer *iccount, *ibarcnt, *ibaroff, *nbars;
char *charq, *durq;
ftnlen lineq_len;
ftnlen charq_len;
ftnlen durq_len;
{
    /* System generated locals */
    integer i__1, i__2;
    cllist cl__1;
    alist al__1;

    /* Builtin functions */
    integer i_indx();
    /* Subroutine */ int s_stop();
    integer s_wsle(), e_wsle(), do_lio(), f_clos(), s_rsfe(), do_fio(), 
	    e_rsfe(), f_rew();
    /* Subroutine */ int s_copy();

    /* Local variables */
    static real fnum;
    static integer ndxm;
    extern /* Subroutine */ int mrec1_(), errmsg_(), getchar_(), readnum_();

    /* Fortran I/O blocks */
    static cilist io___221 = { 0, 6, 0, 0, 0 };
    static cilist io___222 = { 0, 6, 0, 0, 0 };
    static cilist io___224 = { 0, 10, 0, "(a)", 0 };



/*  Macro action */

    getchar_(lineq, iccount, charq, 128L, 1L);
    if (i_indx("RSP ", charq, 4L, 1L) == 0) {
	i__1 = *ibarcnt - *ibaroff + *nbars + 1;
	errmsg_(lineq, iccount, &i__1, "Illegal character after \"M\" (macro\
)!", 128L, 36L);
	s_stop("1", 1L);
    } else if (*(unsigned char *)charq != ' ') {

/*  Record or playback a macro.  Get the number of the macro. */

	getchar_(lineq, iccount, durq, 128L, 1L);
	if (i_indx("123456789", durq, 9L, 1L) == 0) {
	    i__1 = *ibarcnt - *ibaroff + *nbars + 1;
	    errmsg_(lineq, iccount, &i__1, "Must input number after \"MR\" o\
r \"MP\"", 128L, 36L);
	    s_stop("1", 1L);
	}
	readnum_(lineq, iccount, durq, &fnum, 128L, 1L);
	commac_1.macnum = fnum + (float).1;
	if (*(unsigned char *)durq != ' ') {
	    i__1 = *ibarcnt - *ibaroff + *nbars + 1;
	    errmsg_(lineq, iccount, &i__1, "Macro number must be followed by\
 a blank!", 128L, 41L);
	    s_stop("1", 1L);
	}
/*       if (charq .eq. 'R') then */
	if (i_indx("RS", charq, 2L, 1L) > 0) {

/*  Record or save a macro */

	    if (commac_1.macnum < 1 || commac_1.macnum > 20) {
		i__1 = *iccount - 1;
		i__2 = *ibarcnt - *ibaroff + *nbars + 1;
		errmsg_(lineq, &i__1, &i__2, "Macro number not in range 1-20!"
			, 128L, 31L);
		s_stop("1", 1L);
	    } else if (bit_test(commac_1.macuse,commac_1.macnum)) {
		s_wsle(&io___221);
		e_wsle();
		s_wsle(&io___222);
		do_lio(&c__9, &c__1, "WARNING: Redefined macro # ", 27L);
		do_lio(&c__3, &c__1, (char *)&commac_1.macnum, (ftnlen)sizeof(
			integer));
		e_wsle();
		cl__1.cerr = 0;
		cl__1.cunit = commac_1.macnum + 20;
		cl__1.csta = 0;
		f_clos(&cl__1);
	    }
	    commac_1.macuse = bit_set(commac_1.macuse,commac_1.macnum);
	    if (*(unsigned char *)charq == 'R') {
		mrec1_(lineq, iccount, ibarcnt, ibaroff, nbars, &ndxm, 128L);
	    } else if (*(unsigned char *)charq == 'S') {

/*  Save (Record but don't activate) */

L1:
		mrec1_(lineq, iccount, ibarcnt, ibaroff, nbars, &ndxm, 128L);
		if (commac_1.mrecord) {
		    s_rsfe(&io___224);
		    do_fio(&c__1, lineq, 128L);
		    e_rsfe();
		    *iccount = 0;
		    goto L1;
		}
/*           iccount = ndxm */
		*iccount = *iccount + ndxm + 1;
	    }
	} else {

/*  Playback the macro */

	    if (! bit_test(commac_1.macuse,commac_1.macnum)) {
		i__1 = *iccount - 1;
		i__2 = *ibarcnt - *ibaroff + *nbars + 1;
		errmsg_(lineq, &i__1, &i__2, "Cannot play a macro that has n\
ot been recorded!", 128L, 47L);
		s_stop("1", 1L);
	    }
	    al__1.aerr = 0;
	    al__1.aunit = commac_1.macnum + 20;
	    f_rew(&al__1);
	    commac_1.icchold = *iccount;
	    s_copy(commac_1.lnholdq, lineq, 128L, 128L);
	    *iccount = 128;
	    commac_1.mplay = TRUE_;
	}
    }
    return 0;
} /* setmac_ */

/* Subroutine */ int getset_(nv, noinst, mtrnuml, mtrdenl, mtrnmp, mtrdnp, 
	xmtrnum0, newkey, npages, nsyst, musicsize, fracindent, bottreb)
integer *nv, *noinst, *mtrnuml, *mtrdenl, *mtrnmp, *mtrdnp;
real *xmtrnum0;
integer *newkey, *npages, *nsyst, *musicsize;
real *fracindent;
logical *bottreb;
{
    /* System generated locals */
    integer i__1;
    real r__1;

    /* Builtin functions */
    integer s_rsfe(), do_fio(), e_rsfe(), s_cmp(), s_wsle(), do_lio(), e_wsle(
	    );
    /* Subroutine */ int s_stop();
    integer i_indx();

    /* Local variables */
    static real xdum;
    static integer i__;
    static char lineq[128];
    static integer lpath, iinst;
    extern integer ni_();
    static integer iv;
    extern doublereal readin_();
    extern /* Subroutine */ int errmsg_();
    static integer iccount;

    /* Fortran I/O blocks */
    static cilist io___226 = { 0, 10, 0, "(a)", 0 };
    static cilist io___228 = { 0, 10, 1, "(a)", 0 };
    static cilist io___229 = { 0, 6, 0, 0, 0 };
    static cilist io___232 = { 0, 6, 0, 0, 0 };
    static cilist io___234 = { 0, 10, 0, "(a)", 0 };
    static cilist io___235 = { 0, 10, 0, "(a)", 0 };
    static cilist io___237 = { 0, 10, 0, "(a128)", 0 };



/*  Get the first line */

    iccount = 0;
    comget_1.nline = 1;
L9:
    s_rsfe(&io___226);
    do_fio(&c__1, lineq, 128L);
    e_rsfe();
    if (*(unsigned char *)lineq == '%') {
	++comget_1.nline;
	goto L9;
    }
    if (s_cmp(lineq, "---", 3L, 3L) == 0) {

/*  Have TeX input until next line that starts with '---' */

L3:
	++comget_1.nline;
	i__1 = s_rsfe(&io___228);
	if (i__1 != 0) {
	    goto L1;
	}
	i__1 = do_fio(&c__1, lineq, 128L);
	if (i__1 != 0) {
	    goto L1;
	}
	i__1 = e_rsfe();
	if (i__1 != 0) {
	    goto L1;
	}
	goto L2;
L1:
	s_wsle(&io___229);
	do_lio(&c__9, &c__1, "You did not terminate type 0 TeX input with \"\
---\"", 49L);
	e_wsle();
	s_stop("1", 1L);
L2:
	if (s_cmp(lineq, "---", 3L, 3L) != 0) {
	    goto L3;
	}

/*  Force a new line read on first call to readin */

	iccount = 128;
    }

/*  Here, lineq and nline are first non-TeX lines. */

    *nv = readin_(lineq, &iccount, &comget_1.nline, 128L) + (float).1;
    *noinst = readin_(lineq, &iccount, &comget_1.nline, 128L) + (float).1;
    if (*noinst <= 0) {
	--(*noinst);
	i__1 = -(*noinst);
	for (iinst = 1; iinst <= i__1; ++iinst) {
	    xdum = readin_(lineq, &iccount, &comget_1.nline, 128L);
/* L10: */
	}
    }
    *mtrnuml = readin_(lineq, &iccount, &comget_1.nline, 128L) + (float).1;
    *mtrdenl = readin_(lineq, &iccount, &comget_1.nline, 128L) + (float).1;
    *mtrnmp = readin_(lineq, &iccount, &comget_1.nline, 128L) + (float).1;
    *mtrdnp = readin_(lineq, &iccount, &comget_1.nline, 128L) + (float).1;
    *xmtrnum0 = readin_(lineq, &iccount, &comget_1.nline, 128L);
    r__1 = readin_(lineq, &iccount, &comget_1.nline, 128L);
    *newkey = ni_(&r__1);
    *npages = readin_(lineq, &iccount, &comget_1.nline, 128L) + (float).1;
    *nsyst = readin_(lineq, &iccount, &comget_1.nline, 128L) + (float).1;
    *musicsize = readin_(lineq, &iccount, &comget_1.nline, 128L) + (float).1;
    *fracindent = readin_(lineq, &iccount, &comget_1.nline, 128L);
    if (*npages > *nsyst) {
	s_wsle(&io___232);
	do_lio(&c__9, &c__1, "Error in input file: npages > nsyst", 35L);
	e_wsle();
	s_stop("1", 1L);
    }

/*  Next noinst non-comment lines are names of instruments. */

    i__1 = abs(*noinst);
    for (i__ = 1; i__ <= i__1; ++i__) {
L5:
	s_rsfe(&io___234);
	do_fio(&c__1, lineq, 128L);
	e_rsfe();
	++comget_1.nline;
	if (*(unsigned char *)lineq == '%') {
	    goto L5;
	}
/* L4: */
    }

/*  Mext non-comment line has nv clef names */

L6:
    s_rsfe(&io___235);
    do_fio(&c__1, lineq, 128L);
    e_rsfe();
    ++comget_1.nline;
    if (*(unsigned char *)lineq == '%') {
	goto L6;
    }
    i__1 = *nv;
    for (iv = 1; iv <= i__1; ++iv) {
	if (i_indx("brnamst0123456", lineq + (iv - 1), 14L, 1L) == 0) {
	    errmsg_(lineq, &iv, &c__0, "There should be a clef symbol here!", 
		    128L, 35L);
	    s_stop("1", 1L);
	}
/* L7: */
    }
    i__1 = *nv;
    if (s_cmp(lineq + i__1, " ", *nv + 1 - i__1, 1L) != 0) {
	i__1 = *nv + 1;
	errmsg_(lineq, &i__1, &c__0, "There should be a blank here!", 128L, 
		29L);
	s_stop("1", 1L);
    }

/* Set flag if voice 1 is treble, since it affects vertical spacing */

    *bottreb = *(unsigned char *)lineq == 't';

/*  Mext non-comment line has path name */

L8:
    s_rsfe(&io___237);
    do_fio(&c__1, lineq, 128L);
    e_rsfe();
    ++comget_1.nline;
    if (*(unsigned char *)lineq == '%') {
	goto L8;
    }
    lpath = i_indx(lineq, " ", 128L, 1L) - 1;
    if (*(unsigned char *)&lineq[lpath - 1] != '/' && *(unsigned char *)&
	    lineq[lpath - 1] != '\\') {
	errmsg_(lineq, &lpath, &c__0, "Last character of pathname is not / o\
r \\!", 128L, 41L);
	s_stop("1", 1L);
    }
    return 0;
} /* getset_ */

doublereal readin_(lineq, iccount, nline, lineq_len)
char *lineq;
integer *iccount, *nline;
ftnlen lineq_len;
{
    /* System generated locals */
    address a__1[3];
    integer i__1[3];
    real ret_val;
    char ch__1[27], ch__2[6], ch__3[1];
    icilist ici__1;

    /* Builtin functions */
    integer s_rsfe(), do_fio(), e_rsfe(), i_indx(), s_wsle();
    /* Subroutine */ int s_cat();
    integer do_lio(), e_wsle();
    /* Subroutine */ int s_stop();
    integer s_rsfi(), e_rsfi();

    /* Local variables */
    static char durq[1];
    static integer i1, i2, icf;
    extern /* Subroutine */ int getchar_();

    /* Fortran I/O blocks */
    static cilist io___239 = { 0, 10, 0, "(a)", 0 };
    static cilist io___243 = { 0, 6, 0, 0, 0 };



/*  Reads a piece of setup data from file lineq, gets a new lineq from */
/*  file 10 (jobname.pmx) and increments nline if needed,  passes over */
/*  comment lines */

L4:
    if (*iccount == 128) {
L1:
	s_rsfe(&io___239);
	do_fio(&c__1, lineq, 128L);
	e_rsfe();
	++(*nline);
	if (*(unsigned char *)lineq == '%') {
	    goto L1;
	}
	*iccount = 0;
    }
    ++(*iccount);

/*  Find next non-blank or end of line */

    for (*iccount = *iccount; *iccount <= 127; ++(*iccount)) {
	if (*(unsigned char *)&lineq[*iccount - 1] != ' ') {
	    goto L3;
	}
/* L2: */
    }

/*  If here, need to get a new line */

    *iccount = 128;
    goto L4;
L3:

/*  iccount now points to start of number to read */

    i1 = *iccount;
L5:
    getchar_(lineq, iccount, durq, 128L, 1L);

/*  Remember that getchar increments iccount, then reads a character. */

    if (i_indx("0123456789.-", durq, 12L, 1L) > 0) {
	goto L5;
    }
    i2 = *iccount - 1;
    if (i2 < i1) {
	s_wsle(&io___243);
/* Writing concatenation */
	i__1[0] = 7, a__1[0] = "Found \"";
	i__1[1] = 1, a__1[1] = durq;
	i__1[2] = 19, a__1[2] = "\" instead of number";
	s_cat(ch__1, a__1, i__1, &c__3, 27L);
	do_lio(&c__9, &c__1, ch__1, 27L);
	e_wsle();
	s_stop("1", 1L);
    }
    icf = i2 - i1 + 49;
    ici__1.icierr = 0;
    ici__1.iciend = 0;
    ici__1.icirnum = 1;
    ici__1.icirlen = i2 - (i1 - 1);
    ici__1.iciunit = lineq + (i1 - 1);
/* Writing concatenation */
    i__1[0] = 2, a__1[0] = "(f";
    *(unsigned char *)&ch__3[0] = icf;
    i__1[1] = 1, a__1[1] = ch__3;
    i__1[2] = 3, a__1[2] = ".0)";
    ici__1.icifmt = (s_cat(ch__2, a__1, i__1, &c__3, 6L), ch__2);
    s_rsfi(&ici__1);
    do_fio(&c__1, (char *)&ret_val, (ftnlen)sizeof(real));
    e_rsfi();
    return ret_val;
} /* readin_ */

integer ni_(x)
real *x;
{
    /* System generated locals */
    integer ret_val;

    if (*x >= (float)0.) {
	ret_val = *x + (float).5001;
    } else {
	ret_val = *x - (float).5001;
    }
    return ret_val;
} /* ni_ */

/* Subroutine */ int outbar_(i__, jlast)
integer *i__, *jlast;
{
    /* System generated locals */
    address a__1[3];
    integer i__1[3];
    real r__1;
    char ch__1[9], ch__2[1], ch__3[11];
    cilist ci__1;

    /* Builtin functions */
    double r_lg10();
    /* Subroutine */ int s_cat();
    integer s_wsfe(), do_fio(), e_wsfe();

    /* Local variables */
    static integer nfmt;

    r__1 = *i__ + (float).5;
    nfmt = r_lg10(&r__1) + 2;
    if (*jlast + 5 + nfmt < 80) {
	ci__1.cierr = 0;
	ci__1.ciunit = 6;
/* Writing concatenation */
	i__1[0] = 5, a__1[0] = "(a5,i";
	*(unsigned char *)&ch__2[0] = nfmt + 48;
	i__1[1] = 1, a__1[1] = ch__2;
	i__1[2] = 3, a__1[2] = ",$)";
	ci__1.cifmt = (s_cat(ch__1, a__1, i__1, &c__3, 9L), ch__1);
	s_wsfe(&ci__1);
	do_fio(&c__1, "  Bar", 5L);
	do_fio(&c__1, (char *)&(*i__), (ftnlen)sizeof(integer));
	e_wsfe();
	*jlast = *jlast + 5 + nfmt;
    } else {
	ci__1.cierr = 0;
	ci__1.ciunit = 6;
/* Writing concatenation */
	i__1[0] = 7, a__1[0] = "(/,a5,i";
	*(unsigned char *)&ch__2[0] = nfmt + 48;
	i__1[1] = 1, a__1[1] = ch__2;
	i__1[2] = 3, a__1[2] = ",$)";
	ci__1.cifmt = (s_cat(ch__3, a__1, i__1, &c__3, 11L), ch__3);
	s_wsfe(&ci__1);
	do_fio(&c__1, "  Bar", 5L);
	do_fio(&c__1, (char *)&(*i__), (ftnlen)sizeof(integer));
	e_wsfe();
	*jlast = nfmt + 5;
    }
    return 0;
} /* outbar_ */

