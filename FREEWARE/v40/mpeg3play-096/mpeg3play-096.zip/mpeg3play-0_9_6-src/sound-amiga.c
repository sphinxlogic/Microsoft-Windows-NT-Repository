#include "common.h"

int sound_init(int audiofd, layer *info, int stereo) {
    /* Initialize audio device */

    return 0;
}

int sound_open() {
    return 0;
}

int sound_close(int audiofd) {
    return 0;
}

int sound_write(int audiofd, const void *buffer, size_t count) {
    return(write(audiofd, buffer, count));
}

