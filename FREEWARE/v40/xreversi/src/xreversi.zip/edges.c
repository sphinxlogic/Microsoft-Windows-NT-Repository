/*
 *	edgescores.c
 */

#include	"min_reversi.h"

scoreT edgescores [4][4][4][4][4][4][4][4] = {
# include "edges.data"
};
