#define YYNEWLINE 10
#define INITIAL 0
#define YY_LA_SIZE 19

static unsigned short yy_la_act[] = {
 0, 43, 1, 43, 38, 43, 38, 43, 38, 43, 38, 43, 38, 43, 38, 43,
 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 36, 37, 43, 38,
 43, 39, 43, 40, 43, 41, 43, 43, 43, 42, 37, 35, 34, 33, 32, 31,
 30, 29, 28, 27, 26, 25, 20, 24, 23, 22, 21, 18, 19, 16, 17, 15,
 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2,
};

static unsigned char yy_look[] = {
 0
};

static short yy_final[] = {
 0, 0, 2, 4, 6, 8, 10, 12, 14, 16, 17, 18, 19, 20, 21, 22,
 23, 24, 25, 26, 27, 28, 29, 31, 33, 35, 37, 39, 40, 41, 41, 42,
 43, 43, 44, 44, 44, 44, 45, 45, 45, 46, 47, 47, 47, 47, 47, 47,
 47, 48, 48, 48, 49, 49, 50, 50, 50, 50, 50, 50, 50, 51, 51, 51,
 52, 52, 52, 53, 53, 53, 54, 54, 55, 55, 55, 55, 55, 56, 56, 56,
 56, 57, 57, 57, 58, 58, 58, 59, 60, 60, 60, 60, 60, 61, 62, 62,
 62, 63, 63, 63, 63, 64, 64, 64, 65, 65, 65, 65, 65, 65, 66, 66,
 67, 67, 68, 68, 68, 68, 69, 69, 70, 70, 70, 70, 71, 71, 71, 71,
 72, 73, 73, 73, 73, 74, 74, 74, 74, 74, 74, 74, 75, 75, 75, 75,
 76, 76, 76, 77
};
typedef unsigned char yy_state_t;
#define	yy_endst 147
#define	yy_nxtmax 380

static yy_state_t yy_begin[] = {
 0, 0, 0
};

static yy_state_t yy_next[] = {
 28, 28, 28, 28, 2, 28, 28, 28, 28, 1, 21, 28, 28, 28, 28, 28,
 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28,
 1, 28, 27, 28, 28, 28, 28, 28, 28, 28, 28, 28, 25, 28, 28, 28,
 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 28, 26, 28, 28, 28, 28,
 28, 24, 24, 24, 24, 24, 24, 24, 24, 28, 28, 28, 28, 28, 28, 28,
 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28,
 28, 23, 3, 4, 5, 23, 6, 7, 8, 9, 28, 28, 10, 11, 12, 28,
 13, 14, 15, 16, 17, 18, 28, 19, 28, 20, 28, 28, 28, 28, 28, 28,
 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29,
 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29,
 29, 29, 30, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29,
 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29,
 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29,
 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29,
 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29,
 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29,
 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 32, 33, 34, 35, 36, 37,
 38, 39, 40, 41, 42, 45, 43, 46, 44, 47, 48, 49, 50, 51, 52, 53,
 54, 55, 57, 58, 56, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69,
 70, 72, 73, 76, 77, 78, 79, 80, 75, 81, 71, 82, 83, 74, 84, 85,
 86, 88, 89, 90, 91, 92, 93, 95, 96, 97, 98, 99, 100, 101, 102, 87,
 94, 103, 104, 107, 108, 109, 105, 110, 111, 112, 113, 114, 116, 117, 118, 119,
 120, 122, 106, 123, 124, 126, 127, 128, 129, 121, 125, 130, 115, 131, 132, 133,
 134, 135, 136, 137, 138, 139, 140, 142, 143, 141, 144, 145, 146,
};

static yy_state_t yy_check[] = {
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27,
 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27,
 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27,
 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27,
 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27,
 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27,
 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27,
 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27,
 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 20, 32, 19, 34, 35, 36,
 18, 38, 39, 17, 16, 44, 16, 45, 16, 46, 47, 43, 49, 50, 42, 52,
 15, 54, 56, 57, 54, 58, 59, 55, 61, 62, 14, 64, 65, 13, 67, 68,
 12, 71, 71, 75, 74, 77, 78, 79, 71, 73, 12, 81, 82, 71, 72, 84,
 85, 70, 88, 89, 90, 91, 11, 94, 95, 10, 97, 98, 99, 9, 101, 70,
 11, 102, 8, 106, 107, 108, 8, 105, 110, 104, 112, 7, 115, 116, 114, 118,
 6, 121, 8, 122, 120, 125, 126, 124, 5, 6, 120, 129, 7, 130, 131, 4,
 133, 134, 135, 136, 137, 138, 3, 141, 142, 3, 140, 144, 145,
};

static yy_state_t yy_default[] = {
 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147,
 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 27, 147, 22,
 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147,
 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147,
 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147,
 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147,
 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147,
 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147,
 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147, 147,
 147, 147, 147,
};

static short yy_base[] = {
 0, 381, 381, 266, 256, 259, 247, 250, 237, 223, 228, 225, 203, 193, 181, 187,
 179, 164, 162, 164, 155, 381, 208, 381, 381, 381, 381, 128, 381, 381, 381, 381,
 150, 381, 164, 154, 170, 381, 173, 163, 381, 381, 168, 172, 178, 168, 171, 182,
 381, 170, 184, 381, 186, 381, 177, 187, 174, 194, 179, 178, 381, 199, 176, 381,
 194, 184, 381, 205, 182, 381, 216, 202, 204, 212, 209, 206, 381, 198, 196, 210,
 381, 207, 204, 381, 214, 220, 381, 381, 206, 219, 223, 211, 381, 381, 209, 227,
 381, 212, 230, 224, 381, 218, 226, 381, 237, 233, 230, 243, 231, 381, 228, 381,
 234, 381, 241, 243, 249, 381, 250, 381, 248, 242, 246, 381, 258, 242, 242, 381,
 381, 265, 248, 263, 381, 259, 257, 253, 255, 271, 259, 381, 281, 259, 272, 381,
 280, 273, 381, 381
};


#line 1 "/usr/etc/yylex.c"
/*
*****************************************************************************
**									    *
**  Copyright � Digital Equipment Corporation, 1990, 1991, 1992, 1993  	    *
**  All Rights Reserved.  Unpublished rights reserved under  the  copyright *
**  laws of the United States.						    *
**									    *
**  The software contained on this media is proprietary to and embodies the *
**  confidential  technology of Digital Equipment Corporation.  Possession, *
**  use,  duplication  or  dissemination  of  the  software  and  media  is *
**  authorized  only  pursuant  to  a  valid  written  license from Digital *
**  Equipment Corporation.						    *
**									    *
**  RESTRICTED RIGHTS LEGEND   Use, duplication, or disclosure by the  U.S. *
**  Government  is  subject  to  restrictions  as set forth in Subparagraph *
**  (c)(1)(ii) of DFARS 252.227-7013, or in FAR 52.227-19, as applicable.   *
**									    *
*****************************************************************************
*/

/*
 * Copyright 1988, 1990 by Mortice Kern Systems Inc.  All rights reserved.
 *
 * This Software is unpublished, valuable, confidential property of
 * Mortice Kern Systems Inc.  Use is authorized only in accordance
 * with the terms and conditions of the source licence agreement
 * protecting this Software.  Any unauthorized use or disclosure of
 * this Software is strictly prohibited and will result in the
 * termination of the licence agreement.
 *
 * If you have any questions, please consult your supervisor.
 * 
 * All rights reserved.
 */
#include <stdio.h>
/*
 * Define gettext() to an appropriate function for internationalized messages
 * or custom processing.
 */
/*
#ifndef I18N             <<< modified!
*/
#define gettext(s)	(s)
/*
#endif                   <<< modified!
*/
/*
 * Include string.h to get definition of memmove() and size_t.
 * If you do not have string.h or it does not declare memmove
 * or size_t, you will have to declare them here.
 */
#include <string.h>
/* Uncomment next line if memmove() is not declared in string.h */
/*extern char * memmove();*/
/* Uncomment next line if size_t is not available in stdio.h or string.h */
/*typedef unsigned size_t;*/
/* Drop this when LATTICE provides memmove */
#ifdef LATTICE
#define memmove	memcopy
#endif

/*
 * YY_STATIC determines the scope of variables and functions
 * declared by the lex scanner. It must be set with a -DYY_STATIC
 * option to the compiler (it cannot be defined in the lex program).
 */
#ifdef	YY_STATIC
/* define all variables as static to allow more than one lex scanner */
#define	YY_DECL	static
#else
/* define all variables as global to allow other modules to access them */
#define	YY_DECL	
#endif

#ifdef __STDC__
#define	YY_ARGS(_args_)	_args_
#else
#define	YY_ARGS(_args_)	()
#endif

/*
 * the following can be redefined by the user.
 */
#define	ECHO		fputs(yytext, yyout)
#define	yygetc()	getc(yyin) 	/* yylex input source */
#define	output(c)	putc((c), yyout) /* yylex sink for unmatched chars */
#define	YY_FATAL(msg)	{ fprintf(stderr, "yylex: %s\n", msg); exit(1); }
#define	YY_INTERACTIVE	1		/* save micro-seconds if 0 */
#define	YYLMAX		100		/* token and pushback buffer size */

/*
 * the following must not be redefined.
 */
#define	yy_tbuf	yytext		/* token string */

#define	BEGIN		yy_start =
#define	REJECT		goto yy_reject
#define	NLSTATE		(yy_lastc = YYNEWLINE)
#define	YY_INIT		(yy_start = 0, yyleng = yy_end = 0, yy_lastc = YYNEWLINE)
#define	yymore()	goto yy_more
#define	yyless(n)	if ((n) < 0 || (n) > yy_end) ; \
			else { YY_SCANNER; yyleng = (n); YY_USER; }

YY_DECL	int	input	YY_ARGS((void));
YY_DECL	int	unput	YY_ARGS((int c));

/* functions defined in libl.lib */
extern	int	yywrap	YY_ARGS((void));
extern	void	yyerror	YY_ARGS((char *fmt, ...));
extern	void	yycomment	YY_ARGS((char *term));
extern	int	yymapch	YY_ARGS((int delim, int escape));

#line 1 "ulex.l"

/*
 *	ulex.l 
 *
 *	lexer for the user interface
 */
#ifdef VMS
#include	"ytab.h"
#else
#include	"y.tab.h"
#endif /* VMS */

extern int	yylval;
extern char	sbuf[];
#undef input
#define input()	lexgetc()
#undef unput
#define unput(c)	lexungetc(c)

#line 113 "/usr/etc/yylex.c"


#ifdef	YY_DEBUG
#undef	YY_DEBUG
#define	YY_DEBUG(fmt, a1, a2)	fprintf(stderr, fmt, a1, a2)
#else
#define	YY_DEBUG(fmt, a1, a2)
#endif

/*
 * The declaration for the lex scanner can be changed by
 * redefining YYLEX or YYDECL. This must be done if you have
 * more than one scanner in a program.
 */
#ifndef	YYLEX
#define	YYLEX yylex			/* name of lex scanner */
#endif

#ifndef YYDECL
#define	YYDECL	int YYLEX YY_ARGS((void))	/* declaration for lex scanner */
#endif

/* stdin and stdout may not neccessarily be constants */
YY_DECL	FILE   *yyin = NULL;
YY_DECL	FILE   *yyout = NULL;
YY_DECL	int	yylineno = 1;		/* line number */
YY_DECL	int	yyleng = 0;		/* yytext token length */

/*
 * yy_tbuf is an alias for yytext.
 * yy_sbuf[0:yyleng-1] contains the states corresponding to yy_tbuf.
 * yy_tbuf[0:yyleng-1] contains the current token.
 * yy_tbuf[yyleng:yy_end-1] contains pushed-back characters.
 * When the user action routine is active,
 * yy_save contains yy_tbuf[yyleng], which is set to '\0'.
 * Things are different when YY_PRESERVE is defined. 
 */

YY_DECL	unsigned char yy_tbuf [YYLMAX+1]; /* text buffer (really yytext) */
static	yy_state_t yy_sbuf [YYLMAX+1];	/* state buffer */

static	int	yy_end = 0;		/* end of pushback */
static	int	yy_start = 0;		/* start state */
static	int	yy_lastc = YYNEWLINE;	/* previous char */

#ifndef YY_PRESERVE	/* the efficient default push-back scheme */

static	unsigned char yy_save;	/* saved yytext[yyleng] */

#define	YY_USER	{ /* set up yytext for user */ \
		yy_save = yytext[yyleng]; \
		yytext[yyleng] = 0; \
	}
#define	YY_SCANNER { /* set up yytext for scanner */ \
		yytext[yyleng] = yy_save; \
	}

#else		/* not-so efficient push-back for yytext mungers */

static	unsigned char yy_save [YYLMAX];
static	unsigned char *yy_push = yy_save+YYLMAX;

#define	YY_USER { \
		size_t n = yy_end - yyleng; \
		yy_push = yy_save+YYLMAX - n; \
		if (n > 0) \
			memmove(yy_push, yytext+yyleng, n); \
		yytext[yyleng] = 0; \
	}
#define	YY_SCANNER { \
		size_t n = yy_save+YYLMAX - yy_push; \
		if (n > 0) \
			memmove(yytext+yyleng, yy_push, n); \
		yy_end = yyleng + n; \
	}

#endif

/*
 * The actual lex scanner (usually yylex(void)).
 */
YYDECL {
	register int c, i, yyst, yybase;
	int yyfmin, yyfmax;		/* yy_la_act indices of final states */
	int yyoldi, yyoleng;		/* base i, yyleng before look-ahead */


#line 199 "/usr/etc/yylex.c"

	if (yyin == NULL)		/* for silly compilers (yes, I know)*/
		yyin = stdin;
	if (yyout == NULL)
		yyout = stdout;
	i = yyleng;
	YY_SCANNER;

  yy_again:
	yyleng = i;
	/* determine previous char. */
	if (i > 0)
		yy_lastc = yytext[i-1];
	/* scan previously accepted token adjusting yylineno */
	while (i > 0)
		if (yytext[--i] == YYNEWLINE)
			yylineno++;
	/* adjust pushback */
	if (yy_end >= yyleng)
		yy_end -= yyleng;
	else
		yy_end = 0;
	memmove(yytext, yytext+yyleng, (size_t) yy_end);
	i = 0;

  yy_contin:
	yyoldi = i;

	/* run the state machine until it jams */
	for (yy_sbuf[i] = yyst = yy_begin[yy_start + (yy_lastc == YYNEWLINE)];
	     !(yyst == yy_endst || YY_INTERACTIVE && yy_base[yyst] > yy_nxtmax && yy_default[yyst] == yy_endst);
	     yy_sbuf[++i] = yyst) {
		YY_DEBUG(gettext("<state %d, i = %d>\n"), yyst, i);
		if (i >= YYLMAX)
			YY_FATAL(gettext("Token buffer overflow"));

		/* get input char */
		if (i < yy_end)
			c = yy_tbuf[i];		/* get pushback char */
		else if ((c = yygetc()) != EOF) {
			yy_end = i+1;
			yy_tbuf[i] = c = (unsigned char) c;
		} else /* c == EOF */ {
			if (i == yyoldi)	/* no token */
				if (yywrap())
					return 0;
				else
					goto yy_again;
			else
				break;
		}
		YY_DEBUG(gettext("<input %d = 0x%02x>\n"), c, c);

		/* look up next state */
		while ((yybase = yy_base[yyst]+c) > yy_nxtmax || yy_check[yybase] != yyst) {
			if (yyst == yy_endst)
				goto yy_jammed;
			yyst = yy_default[yyst];
		}
		yyst = yy_next[yybase];
	  yy_jammed: ;
	}
	YY_DEBUG(gettext("<stopped %d, i = %d>\n"), yyst, i);
	if (yyst != yy_endst)
		++i;

  yy_search:
	/* search backward for a final state */
	while (--i > yyoldi) {
		yyst = yy_sbuf[i];
		if ((yyfmin = yy_final[yyst]) < (yyfmax = yy_final[yyst+1]))
			goto yy_found;	/* found final state(s) */
	}
	/* no match, default action */
	i = yyoldi + 1;
	output(yy_tbuf[yyoldi]);
	goto yy_again;

  yy_found:
	YY_DEBUG(gettext("<final state %d, i = %d>\n"), yyst, i);
	yyoleng = i;		/* save length for REJECT */
	
	/* pushback look-ahead RHS */
	if ((c = (int)(yy_la_act[yyfmin]>>9) - 1) >= 0) { /* trailing context? */
		unsigned char *bv = yy_look + c*YY_LA_SIZE;
		static unsigned char bits [8] = {
			1<<0, 1<<1, 1<<2, 1<<3, 1<<4, 1<<5, 1<<6, 1<<7
		};
		while (1) {
			if (--i < yyoldi) {	/* no / */
				i = yyoleng;
				break;
			}
			yyst = yy_sbuf[i];
			if (bv[(unsigned)yyst/8] & bits[(unsigned)yyst%8])
				break;
		}
	}

	/* perform action */
	yyleng = i;
	YY_USER;
	switch (yy_la_act[yyfmin] & 0777) {
	case 0:
#line 16 "ulex.l"
	;
	break;
	case 1:
#line 17 "ulex.l"
	return EOG;
	break;
	case 2:
#line 18 "ulex.l"
	{ yylval = -1; return BL; }
	break;
	case 3:
#line 19 "ulex.l"
	return BOTH;
	break;
	case 4:
#line 20 "ulex.l"
	return COMPUTER;
	break;
	case 5:
#line 21 "ulex.l"
	return DEBUG;
	break;
	case 6:
#line 22 "ulex.l"
	return FILEe;
	break;
	case 7:
#line 23 "ulex.l"
	return FIRST;
	break;
	case 8:
#line 24 "ulex.l"
	return FROM;
	break;
	case 9:
#line 25 "ulex.l"
	return GAME;
	break;
	case 10:
#line 26 "ulex.l"
	return GRID;
	break;
	case 11:
#line 27 "ulex.l"
	return HELP;
	break;
	case 12:
#line 28 "ulex.l"
	return HINT;
	break;
	case 13:
#line 29 "ulex.l"
	return HUMAN;
	break;
	case 14:
#line 30 "ulex.l"
	return INTO;
	break;
	case 15:
#line 31 "ulex.l"
	return LEVEL;
	break;
	case 16:
#line 32 "ulex.l"
	return HUMAN;
	break;
	case 17:
#line 33 "ulex.l"
	return MOVE;
	break;
	case 18:
#line 34 "ulex.l"
	return NEW;
	break;
	case 19:
#line 35 "ulex.l"
	return NEITHER;
	break;
	case 20:
#line 36 "ulex.l"
	return NO;
	break;
	case 21:
#line 37 "ulex.l"
	return NOGRID;
	break;
	case 22:
#line 38 "ulex.l"
	return NOHELP;
	break;
	case 23:
#line 39 "ulex.l"
	return NOSCORE;
	break;
	case 24:
#line 40 "ulex.l"
	return NONE;
	break;
	case 25:
#line 41 "ulex.l"
	return PLAY;
	break;
	case 26:
#line 42 "ulex.l"
	return QUIT;
	break;
	case 27:
#line 43 "ulex.l"
	return REPLAY;
	break;
	case 28:
#line 44 "ulex.l"
	return RESTART;
	break;
	case 29:
#line 45 "ulex.l"
	return SAVE;
	break;
	case 30:
#line 46 "ulex.l"
	return SCORE;
	break;
	case 31:
#line 47 "ulex.l"
	return SECOND;
	break;
	case 32:
#line 48 "ulex.l"
	return TO;
	break;
	case 33:
#line 49 "ulex.l"
	return UNDO;
	break;
	case 34:
#line 50 "ulex.l"
	{ yylval =  1; return WH; }
	break;
	case 35:
#line 51 "ulex.l"
	return COMPUTER;
	break;
	case 36:
#line 52 "ulex.l"
	return NL;
	break;
	case 37:
#line 53 "ulex.l"
	{ yylval = atoi (yytext); return NUMBER; }
	break;
	case 38:
#line 54 "ulex.l"
	{ yylval = *yytext; return LETTER; }
	break;
	case 39:
#line 55 "ulex.l"
	{ yylval = *yytext + 'a' - 'A'; return LETTER; }
	break;
	case 40:
#line 56 "ulex.l"
	return COMMA;
	break;
	case 41:
#line 57 "ulex.l"
	return SEMI;
	break;
	case 42:
#line 58 "ulex.l"
	{ strcpy (sbuf, yytext+1); sbuf[yyleng-2]='\0'; return STRING; }
	break;
	case 43:
#line 59 "ulex.l"
	return ERR;
	break;

#line 302 "/usr/etc/yylex.c"

	}
	YY_SCANNER;
	i = yyleng;
	goto yy_again;			/* action fell though */

  yy_reject:
	YY_SCANNER;
	i = yyoleng;			/* restore original yytext */
	if (++yyfmin < yyfmax)
		goto yy_found;		/* another final state, same length */
	else
		goto yy_search;		/* try shorter yytext */

  yy_more:
	YY_SCANNER;
	i = yyleng;
	if (i > 0)
		yy_lastc = yytext[i-1];
	goto yy_contin;
}

/*
 * user callable input/unput functions.
 */

/* get input char with pushback */
YY_DECL int
input()
{
	int c;
#ifndef YY_PRESERVE
	if (yy_end > yyleng) {
		yy_end--;
		memmove(yytext+yyleng, yytext+yyleng+1,
			(size_t) (yy_end-yyleng));
		c = yy_save;
		YY_USER;
#else
	if (yy_push < yy_save+YYLMAX) {
		c = *yy_push++;
#endif
	} else
		c = yygetc();
	yy_lastc = c;
	if (c == YYNEWLINE)
		yylineno++;
	return c;
}

/* pushback char */
YY_DECL int
unput(c)
	int c;
{
#ifndef YY_PRESERVE
	if (yy_end >= YYLMAX)
		YY_FATAL(gettext("Push-back buffer overflow"));
	if (yy_end > yyleng) {
		yytext[yyleng] = yy_save;
		memmove(yytext+yyleng+1, yytext+yyleng,
			(size_t) (yy_end-yyleng));
		yytext[yyleng] = 0;
	}
	yy_end++;
	yy_save = c;
#else
	if (yy_push <= yy_save)
		YY_FATAL(gettext("Push-back buffer overflow"));
	*--yy_push = c;
#endif
	if (c == YYNEWLINE)
		yylineno--;
	return c;
}

