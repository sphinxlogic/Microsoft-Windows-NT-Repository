/*
   crypt.c (dummy version) by Info-ZIP.      Last revised:  11 Sep 92

   This is a non-functional version of Info-ZIP's crypt.c encryption/
   decryption code for Zip, ZipCloak, UnZip and FUnZip.  This file is
   not copyrighted and may be distributed freely. :-)  See the "Where"
   file for sites from which to obtain the full encryption/decryption
   sources (zcrypt20.zip or later).
 */

int dummy_crypt; /* avoid warning about empty translation unit */
