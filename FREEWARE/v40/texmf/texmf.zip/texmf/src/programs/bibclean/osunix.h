/* -*-C-*- osunix.h */
/*-->osunix*/
/**********************************************************************/
/******************************** osunix ******************************/
/**********************************************************************/

#ifndef OSUNIX_H_DEFINED_
#define OSUNIX_H_DEFINED_

/* $Id: osunix.h,v 1.4 1992/10/08 01:42:01 beebe Exp beebe $
 * $Log: osunix.h,v $
 * Revision 1.4  1992/10/08  01:42:01  beebe
 * Update for C++.
 *
 * Revision 1.3  1992/03/10  14:13:53  beebe
 * *** empty log message ***
 *
 * Revision 1.2  1992/02/29  19:42:20  beebe
 * Update for version 3.0.114 [29-Feb-1992] following two-month
 * major overhaul and compilation testing on numerous machines.
 *
 * Revision 1.2  1992/02/29  19:42:20  beebe
 * Update for version 3.0.114 [29-Feb-1992] following two-month
 * major overhaul and compilation testing on numerous machines.
 *
 * Revision 1.1  1992/02/29  19:13:21  beebe
 * Initial revision
 *
 * Revision 1.1  1992/02/29  19:13:21  beebe
 * Initial revision
 *
 */

#if    UNIX_ATT				/* 14-character filename limit */
#if MAXPATHLEN < 25			/* some systems have short names*/
					/* but HP-UX supports long ones */
#ifdef DVIPREFIX
#undef DVIPREFIX
#endif /* DVIPREFIX */

#define DVIPREFIX	""
#endif /* MAXPATHLEN < 25 */

#ifdef NAME_MAX
#if NAME_MAX < 25
#ifdef DVIPREFIX
#undef DVIPREFIX
#endif /* DVIPREFIX */

#define DVIPREFIX	""
#endif /* NAME_MAX < 25 */
#endif /* NAME_MAX */

#ifdef _POSIX_NAME_MAX
#if _POSIX_NAME_MAX < 25
#ifdef DVIPREFIX
#undef DVIPREFIX
#endif /* DVIPREFIX */

#define DVIPREFIX	""
#endif /* _POSIX_NAME_MAX < 25 */
#endif /* _POSIX_NAME_MAX */
#endif /* UNIX_ATT */

#define DVIHELP "man dvi\nor\napropos dvi\nor\nvisit Emacs info node dvi"

#ifndef ENV_SYSPATH			/* can override at compile time */
#define ENV_SYSPATH	"PATH"
#endif /* ENV_SYSPATH */

#ifndef FONTFMT				/* can be set at compile time */
#define FONTFMT		"%n.%dpk;%n.%dgf;%n.%mpxl;%n.vf;%n.tfm"
#endif /* FONTFMT */

#ifndef FSMAPFILE			/* can be set at compile time */
#define FSMAPFILE	"texfiles.map"
#endif /* FSMAPFILE */

#define HOST_WORD_SIZE	32	/* must be 32 or larger -- used in */
				/* signex to pack 8-bit bytes back */
				/* into integer values, and in dispchar */
				/* and fillrect for managing character */
				/* raster storage. */

#ifndef PSMAPFILE			/* can be set at compile time */
#define PSMAPFILE	"psfonts.map"
#endif /* PSMAPFILE */

#ifndef PS_MAXWIDTH
#define PS_MAXWIDTH	72
#endif /* PS_MAXWIDTH */

#ifndef PS_SHORTLINES
#define PS_SHORTLINES	1       /* some UNIX utilities fail with long lines */
#endif /* PS_SHORTLINES */

#define SEP_COMP " ;:,|" /* separators between filename components */
#define SEP_PATH "/"	/* separators between directory path and filename */

#if    UNIXPC
#define special	specupc		/* avoid name conflict with library routine */
#endif /* UNIXPC */

#ifndef SUBEXT				/* can be set at compile time */
#define SUBEXT		".sub"
#endif /* SUBEXT */

#ifndef SUBNAME				/* can be set at compile time */
#define SUBNAME		"texfonts"
#endif /* SUBNAME */

#ifndef TEXFONTS			/* can be set at compile time */
#define TEXFONTS	"/usr/local/lib/tex/fonts:/usr/lib/tex/fonts"
#endif /* TEXFONTS */

#ifndef TEXINPUTS			/* can be set at compile time */
#define TEXINPUTS	".:/usr/local/lib/tex/macros:/usr/lib/tex/macros"
#endif /* TEXINPUTS */

#ifndef TFMFMT				/* can be set at compile time */
#define TFMFMT		"%n.tfm"
#endif /* TFMFMT */

#endif /* OSUNIX_H_DEFINED_ */
