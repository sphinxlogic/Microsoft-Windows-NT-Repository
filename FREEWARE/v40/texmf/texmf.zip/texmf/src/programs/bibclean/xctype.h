/* -*-C-*- ctype.h */
/**********************************************************************/
/******************************* ctype ********************************/
/**********************************************************************/

/* $Id: xctype.h,v 1.4 1992/10/08 01:42:01 beebe Exp beebe $
 * $Log: xctype.h,v $
 * Revision 1.4  1992/10/08  01:42:01  beebe
 * Update for C++.
 *
 * Revision 1.3  1992/03/06  14:58:06  beebe
 * Complete two-month long development of version 3.0.114.  See
 * 00revhst.txt for details.
 *
 * Revision 1.2  1992/02/29  19:42:20  beebe
 * Update for version 3.0.114 [29-Feb-1992] following two-month
 * major overhaul and compilation testing on numerous machines.
 *
 * Revision 1.2  1992/02/29  19:42:20  beebe
 * Update for version 3.0.114 [29-Feb-1992] following two-month
 * major overhaul and compilation testing on numerous machines.
 *
 */

#ifndef XCTYPE_H_DEFINED_
#define XCTYPE_H_DEFINED_

#include <ctype.h>

#if !__cplusplus
#if sun
/* Some systems (e.g. SunOS 4.1) fail to declare Standard C functions in
ctype.h */

#ifndef toupper
int		toupper ARGS((int c_));
#endif /* toupper */

#ifndef tolower
int		tolower ARGS((int c_));
#endif /* tolower */
#endif /* sun */
#endif /* !__cplusplus */

#endif /* XCTYPE_H_DEFINED_ */
