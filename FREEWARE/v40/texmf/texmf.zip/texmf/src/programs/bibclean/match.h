typedef struct s_pattern
{
    const char *pattern;
    const char *message;
} MATCH_PATTERN;

YESorNO		match_pattern ARGS((const char *s_, const char *pattern_));
