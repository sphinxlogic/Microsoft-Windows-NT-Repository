/* -*-C-*- ospcdos.h */
/*-->ospcdos*/
/**********************************************************************/
/******************************* ospcdos ******************************/
/**********************************************************************/

#ifndef OSPCDOS_H_DEFINED_
#define OSPCDOS_H_DEFINED_

/* $Id: ospcdos.h,v 1.4 1992/10/08 01:42:01 beebe Exp beebe $
 * $Log: ospcdos.h,v $
 * Revision 1.4  1992/10/08  01:42:01  beebe
 * Update for C++.
 *
 * Revision 1.3  1992/03/10  14:13:53  beebe
 * *** empty log message ***
 *
 * Revision 1.2  1992/02/29  19:42:20  beebe
 * Update for version 3.0.114 [29-Feb-1992] following two-month
 * major overhaul and compilation testing on numerous machines.
 *
 * Revision 1.2  1992/02/29  19:42:20  beebe
 * Update for version 3.0.114 [29-Feb-1992] following two-month
 * major overhaul and compilation testing on numerous machines.
 *
 * Revision 1.1  1992/02/29  19:13:16  beebe
 * Initial revision
 *
 * Revision 1.1  1992/02/29  19:13:16  beebe
 * Initial revision
 *
 */

#if    IBM_PC_MICROSOFT

#ifdef CACHE_FONTS
#undef CACHE_FONTS
#endif /* CACHE_FONTS */

#define CACHE_FONTS	1
#endif /* IBM_PC_MICROSOFT */

#if    IBM_PC_TURBO

#ifdef CACHE_FONTS
#undef CACHE_FONTS
#endif /* CACHE_FONTS */

#define CACHE_FONTS	0
#endif /* IBM_PC_TURBO */

#define DVIHELP		"type d:\\tex\\dvi.hlp"

#ifdef DVIPREFIX
#undef DVIPREFIX
#endif /* DVIPREFIX */

#define DVIPREFIX	""

#ifndef ENV_SYSPATH			/* can override at compile time */
#define ENV_SYSPATH	"PATH"
#endif /* ENV_SYSPATH */

#ifndef FONTFMT				/* can be set at compile time */
#define FONTFMT		"%d\\%n.pk;%d\\%n.gf;%m\\%n.pxl;%n.vf;%n.tfm"
#endif /* FONTFMT */

#ifndef FSMAPFILE		/* can be set at compile time */
#define FSMAPFILE	"texfiles.map"
#endif /* FSMAPFILE */

#define HOST_WORD_SIZE	32	/* must be 32 or larger -- used in */
				/* signex to pack 8-bit bytes back */
				/* into integer values, and in dispchar */
				/* and fillrect for managing character */
				/* raster storage. */

#if    IBM_PC_MICROSOFT
/*
Argument type checking in MSC Version 4.0 is selected by LINT_ARGS.
MSC Version 5.0 has it selected by default.
*/
#define LINT_ARGS	1

#ifdef MALLOC
#undef MALLOC
#endif /* MALLOC */

#define MALLOC(n)	calloc(n,1)
#endif /* IBM_PC_MICROSOFT */

#ifdef MAXOPENFONTS
#undef MAXOPENFONTS
#endif /* MAXOPENFONTS */

#define MAXOPENFONTS	5		/* limit on number of open font files */
					/* (small, to reduce memory needs) */

#ifndef PSMAPFILE			/* can be set at compile time */
#define PSMAPFILE	"psfonts.map"
#endif /* PSMAPFILE */

#ifndef PS_MAXWIDTH
#define PS_MAXWIDTH	72
#endif /* PS_MAXWIDTH */

#ifndef PS_SHORTLINES
#define PS_SHORTLINES	1
#endif /* PS_SHORTLINES */

#ifdef SEGMEM
#undef SEGMEM
#endif /* SEGMEM */

#define SEGMEM		1

#define SEP_COMP " ;,|"	/* separators between filename components */
#define SEP_PATH "\\"	/* separators between directory path and filename */

#ifndef SUBEXT				/* can be set at compile time */
#define SUBEXT		".sub"
#endif /* SUBEXT */

#ifndef SUBNAME				/* can be set at compile time */
#define SUBNAME		"texfonts"
#endif /* SUBNAME */

#ifndef	TEXFONTS			/* can be set at compile time */
#define TEXFONTS	"d:\\tex\\fonts"
#endif /* TEXFONTS */

#ifndef	TEXINPUTS			/* can be set at compile time */
#define TEXINPUTS	".;d:\\tex\\inputs"
#endif /* TEXINPUTS */

#ifndef TFMFMT				/* can be set at compile time */
#define TFMFMT		"%n.tfm"
#endif /* TFMFMT */

#endif /* OSPCDOS_H_DEFINED_ */
