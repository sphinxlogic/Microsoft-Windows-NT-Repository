/* -*-C-*- xerrno.h */
/**********************************************************************/
/******************************* xerrno *******************************/
/**********************************************************************/

/* $Id: xerrno.h,v 1.6 1992/10/08 01:42:01 beebe Exp beebe $ 
 * $Log: xerrno.h,v $
 * Revision 1.6  1992/10/08  01:42:01  beebe
 * Update for C++.
 *
 * Revision 1.5  1992/07/10  18:05:28  beebe
 * Add comment on #else.
 *
 * Revision 1.4  1992/03/10  14:13:53  beebe
 * *** empty log message ***
 *
 * Revision 1.3  1992/03/06  14:56:35  beebe
 * Complete two-month long development of version 3.0.114.  See
 * 00revhst.txt for details.
 *
 * Revision 1.3  1992/03/06  14:56:35  beebe
 * Complete two-month long development of version 3.0.114.  See
 * 00revhst.txt for details.
 *
 * Revision 1.2  1992/02/29  19:42:20  beebe
 * Update for version 3.0.114 [29-Feb-1992] following two-month
 * major overhaul and compilation testing on numerous machines.
 *
 * Revision 1.1  1992/02/29  19:13:29  beebe
 * Initial revision
 *
 * Revision 1.1  1992/02/29  19:13:29  beebe
 * Initial revision
 *
 */

#ifndef XERRNO_H_DEFINED_
#define XERRNO_H_DEFINED_

/***********************************************************************
This file includes the system errno.h file, which often lacks
definitions of errno and sys_nerr.
***********************************************************************/

#if HAVE_ERRNO_H
#include <errno.h>
#endif /* HAVE_ERRNO_H */

#if    !__cplusplus
#if    ardent
extern int sys_nerr;
extern char *sys_errlist[];
#endif /* ardent */

#if    OS_VAXVMS
extern noshare int 	errno;
extern noshare int 	sys_nerr;
extern noshare char	*sys_errlist[];
#endif  /* OS_VAXVMS */

#if    (OS_ATARI)
extern int		errno;
#endif /* OS_ATARI */

#if    OS_TOPS20
#if    KCC_20
extern int sys_nerr;
extern char *sys_errlist[];
#endif /* KCC_20 */

#if    PCC_20
int sys_nerr = 0;
char *sys_errlist[] = {"?"};
#endif /* PCC_20 */
#endif /* OS_TOPS20 */

#if _AIX||sun||(hp300 && __GNUC__)||__hpux||(ultrix && __LCC__)||UNIX_BSD
extern int		errno;
extern int		sys_nerr;
extern char		*sys_errlist[];
#endif /*_AIX||sun||(hp300 && __GNUC__)||__hpux||(ultrix && __LCC__)||UNIX_BSD*/

#if __sgi				/* Assume compilation with -ansiposix */
#define sys_nerr	_sys_nerr	
#define sys_errlist	_sys_errlist
#endif /* __sgi */

#ifndef ENOSPC				/* some errno.h files don't have it */
#define	ENOSPC		28		/* UNIX: No space left on device */
#endif /* ENOSPC */
#endif /* !__cplusplus */
#endif /* XERRNO_H_DEFINED_ */
