/* -*-C-*- xpwd.h */
/**********************************************************************/
/******************************* xpwd ********************************/
/**********************************************************************/

/* $Id: xpwd.h,v 1.6 1992/10/08 01:42:01 beebe Exp beebe $ 
 * $Log: xpwd.h,v $
 * Revision 1.6  1992/10/08  01:42:01  beebe
 * Update for C++.
 *
 * Revision 1.5  1992/03/10  14:13:53  beebe
 * *** empty log message ***
 *
 * Revision 1.4  1992/03/06  14:56:35  beebe
 * Complete two-month long development of version 3.0.114.  See
 * 00revhst.txt for details.
 *
 * Revision 1.4  1992/03/06  14:56:35  beebe
 * Complete two-month long development of version 3.0.114.  See
 * 00revhst.txt for details.
 *
 * Revision 1.3  1992/03/01  01:28:38  beebe
 * *** empty log message ***
 *
 * Revision 1.2  1992/02/29  19:42:20  beebe
 * Update for version 3.0.114 [29-Feb-1992] following two-month
 * major overhaul and compilation testing on numerous machines.
 *
 * Revision 1.1  1992/02/29  19:13:31  beebe
 * Initial revision
 *
 * Revision 1.1  1992/02/29  19:13:31  beebe
 * Initial revision
 *
 */

#ifndef XPWD_H_DEFINED_
#define XPWD_H_DEFINED_

/***********************************************************************
This file includes the system pwd.h file and supplies missing prototypes.
***********************************************************************/

#ifndef OS_H_DEFINED_
#include "os.h"
#endif /* OS_H_DEFINED_ */

#include "xtypes.h"

#if HAVE_PWD_H
#include <pwd.h>
#endif /* HAVE_PWD_H */

#if !__cplusplus
#if !HAVE_GETLOGIN_DCL
char			*getlogin ARGS((void));
#endif /* HAVE_GETLOGIN_DCL */

#if !HAVE_GETPWNAM_DCL
struct passwd		*getpwnam ARGS((const char* name_));
					/* missing in host pwd.h */
#endif /* !HAVE_GETPWNAM_DCL */

#if !HAVE_GETPWUID_DCL
struct passwd		*getpwuid ARGS((int uid_));
#endif /* HAVE_GETPWUID_DCL */

#if !HAVE_GETUID_DCL
int			getuid ARGS((void));
#endif /* !HAVE_GETUID_DCL */
#endif /* !__cplusplus */

#if __GNUC__ && __cplusplus
#if !HAVE_GETUID_DCL
extern "C" 
{
int			getuid ARGS((void));
};
#endif /*  __GNUC__ && __cplusplus */
#endif /* !HAVE_GETUID_DCL */

#endif /* XPWD_H_DEFINED_ */
