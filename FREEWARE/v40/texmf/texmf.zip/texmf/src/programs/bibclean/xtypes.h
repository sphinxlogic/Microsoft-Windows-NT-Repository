/* -*-C-*- xtypes.h */
/**********************************************************************/
/****************************** xtypes ********************************/
/**********************************************************************/

/* $Id: xtypes.h,v 1.6 1992/10/08 01:42:01 beebe Exp beebe $
 * $Log: xtypes.h,v $
 * Revision 1.6  1992/10/08  01:42:01  beebe
 * Update for C++.
 *
 * Revision 1.5  1992/07/10  18:09:20  beebe
 * Add use of HAVE_TYPES_H.
 *
 * Revision 1.4  1992/03/10  14:13:53  beebe
 * *** empty log message ***
 *
 * Revision 1.3  1992/03/06  14:56:35  beebe
 * Complete two-month long development of version 3.0.114.  See
 * 00revhst.txt for details.
 *
 * Revision 1.3  1992/03/06  14:56:35  beebe
 * Complete two-month long development of version 3.0.114.  See
 * 00revhst.txt for details.
 *
 * Revision 1.2  1992/02/29  19:42:20  beebe
 * Update for version 3.0.114 [29-Feb-1992] following two-month
 * major overhaul and compilation testing on numerous machines.
 *
 */

#ifndef XTYPES_H_DEFINED_
#define XTYPES_H_DEFINED_

/***********************************************************************
This file includes the system types.h file, which does not have
a standard location.  Primos does not even have one.
***********************************************************************/

#ifndef OS_H_DEFINED_
#include "os.h"
#endif /* OS_H_DEFINED_ */

#if HAVE_TYPES_H
#if HAVE_SYS_DIR
#include <sys/types.h>
#else /* NOT HAVE_SYS_DIR */
#include <types.h>
#endif /* HAVE_SYS_DIR */
#endif /* HAVE_TYPES_H */

#endif /* XTYPES_H_DEFINED_ */
