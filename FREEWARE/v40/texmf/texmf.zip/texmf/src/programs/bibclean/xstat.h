/* -*-C-*- xstat.h */
/**********************************************************************/
/******************************** stat ********************************/
/**********************************************************************/

/* $Id: xstat.h,v 1.6 1992/10/08 01:42:01 beebe Exp beebe $
 * $Log: xstat.h,v $
 * Revision 1.6  1992/10/08  01:42:01  beebe
 * Update for C++.
 *
 * Revision 1.5  1992/07/10  18:06:46  beebe
 * Add use of HAVE_STAT_H.
 *
 * Revision 1.4  1992/03/06  19:38:15  beebe
 * *** empty log message ***
 *
 * Revision 1.3  1992/03/06  14:58:06  beebe
 * Complete two-month long development of version 3.0.114.  See
 * 00revhst.txt for details.
 *
 * Revision 1.2  1992/02/29  19:42:20  beebe
 * Update for version 3.0.114 [29-Feb-1992] following two-month
 * major overhaul and compilation testing on numerous machines.
 *
 * Revision 1.2  1992/02/29  19:42:20  beebe
 * Update for version 3.0.114 [29-Feb-1992] following two-month
 * major overhaul and compilation testing on numerous machines.
 *
 */

#ifndef XSTAT_H_DEFINED_
#define XSTAT_H_DEFINED_

/***********************************************************************
This file includes the system stat.h file, which does not have a
standard location.

On ULTRIX and System V, the system stat.h cannot be included more than
once, because the compilers raise errors about duplicate (although
identical) definitions of struct stat; the code here prevents that
from happening.
***********************************************************************/

#ifndef OS_H_DEFINED_
#include "os.h"
#endif /* OS_H_DEFINED_ */

#include "xtypes.h"

#if HAVE_STAT_H
#if HAVE_SYS_DIR
#include <sys/stat.h>
#else /* NOT HAVE_SYS_DIR */
#include <stat.h>
#endif /* HAVE_SYS_DIR */
#endif /* HAVE_STAT_H */

#if !__cplusplus
#if ultrix && (mips || __LCC__)		/* supply missing prototypes */
int		fstat ARGS((int file_desc_, struct stat *buffer_));
#endif /* ultrix && (mips || __LCC__) */
#endif /* !__cplusplus */

#endif /* XSTAT_H_DEFINED_ */
