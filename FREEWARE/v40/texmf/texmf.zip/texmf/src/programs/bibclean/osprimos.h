/* -*-C-*- osprimos.h */
/*-->osprimos*/
/**********************************************************************/
/******************************* osprimos *****************************/
/**********************************************************************/

#ifndef OSPRIMOS_H_DEFINED_
#define OSPRIMOS_H_DEFINED_

/* $Id: osprimos.h,v 1.4 1992/10/08 01:42:01 beebe Exp beebe $
 * $Log: osprimos.h,v $
 * Revision 1.4  1992/10/08  01:42:01  beebe
 * Update for C++.
 *
 * Revision 1.3  1992/03/10  14:13:53  beebe
 * *** empty log message ***
 *
 * Revision 1.2  1992/02/29  19:42:20  beebe
 * Update for version 3.0.114 [29-Feb-1992] following two-month
 * major overhaul and compilation testing on numerous machines.
 *
 * Revision 1.2  1992/02/29  19:42:20  beebe
 * Update for version 3.0.114 [29-Feb-1992] following two-month
 * major overhaul and compilation testing on numerous machines.
 *
 * Revision 1.1  1992/02/29  19:13:17  beebe
 * Initial revision
 *
 * Revision 1.1  1992/02/29  19:13:17  beebe
 * Initial revision
 *
 */

/**********************************************************************
Full  support for Prime 50-series machines   provided  by  Jon Warbrick,
Plymouth Polytechnic Computing Service, Plymouth, UK.	Some of the work
is based on an earlier port of part of the family by Marc  Furon, Office
of Computing	and Communications   Resources,	   The	California State
University.
***********************************************************************/

#ifdef DISKFULL
#undef DISKFULL
#endif /* DISKFULL */

#define DISKFULL(fp)	ferror(fp)	/* Primos does not admit why */

#define DVIHELP		"help dvixxx (where dvixxx is the name of this driver)"

#ifdef DVIPREFIX
#undef DVIPREFIX
#endif /* DVIPREFIX */

#define DVIPREFIX	""		/* no long extensions */

#ifndef ENV_SYSPATH			/* can override at compile time */
#define ENV_SYSPATH	"PATH"
#endif /* ENV_SYSPATH */

#ifdef FSEEK
#undef FSEEK
#endif /* FSEEK */

#define FSEEK		primos_fseek	/* local routine to avoid library bug */

#ifndef FSMAPFILE			/* can be set at compile time */
#define FSMAPFILE	"texfiles.map"
#endif /* FSMAPFILE */

#define HOST_WORD_SIZE	32

#ifndef PSMAPFILE			/* can be set at compile time */
#define PSMAPFILE	"psfonts.map"
#endif /* PSMAPFILE */

#ifndef PS_SHORTLINES
#define PS_SHORTLINES	1	/* some utilities fail with long lines */
#endif /* PS_SHORTLINES */

#ifdef SEGMEM
#undef SEGMEM
#endif /* SEGMEM */

#define SEGMEM		1

#define SEP_COMP " :"	/* separators between filename components */
#define SEP_PATH ">"	/* separators between directory path and filename */

#ifndef SUBEXT				/* can be set at compile time */
#define SUBEXT		".sub"
#endif /* SUBEXT */

#ifndef SUBNAME				/* can be set at compile time */
#define SUBNAME		"texfonts"
#endif /* SUBNAME */

#ifndef TEXFONTS			/* can be set at compile time */
#define TEXFONTS	"TeX>pxlp>"
#endif /* TEXFONTS */

#ifndef TEXFONTS			/* can be set at compile time */
#define TEXFONTS	"TEXFONTS"
#endif /* TEXFONTS */

#ifndef TEXINPUTS			/* can be set at compile time */
#define TEXINPUTS	"*>:TeX>inputs>"
					/* current directory and tex>inputs> */
#endif /* TEXINPUTS */

#ifndef TEXINPUTS			/* can be set at compile time */
#define TEXINPUTS	"TEXINPUTS"
#endif /* TEXINPUTS */

#ifndef TFMFMT				/* can be set at compile time */
#define TFMFMT		"%n.tfm"
#endif /* TFMFMT */

#endif /* OSPRIMOS_H_DEFINED_ */
