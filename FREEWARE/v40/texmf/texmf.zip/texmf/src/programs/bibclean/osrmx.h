/* -*-C-*- osrmx.h */
/*-->osrmx*/
/**********************************************************************/
/******************************** osrmx *******************************/
/**********************************************************************/

#ifndef OSRMX_H_DEFINED_
#define OSRMX_H_DEFINED_

/* $Id: osrmx.h,v 1.4 1992/10/08 01:42:01 beebe Exp beebe $
 * $Log: osrmx.h,v $
 * Revision 1.4  1992/10/08  01:42:01  beebe
 * Update for C++.
 *
 * Revision 1.3  1992/03/10  14:13:53  beebe
 * *** empty log message ***
 *
 * Revision 1.2  1992/02/29  19:42:20  beebe
 * Update for version 3.0.114 [29-Feb-1992] following two-month
 * major overhaul and compilation testing on numerous machines.
 *
 * Revision 1.2  1992/02/29  19:42:20  beebe
 * Update for version 3.0.114 [29-Feb-1992] following two-month
 * major overhaul and compilation testing on numerous machines.
 *
 * Revision 1.1  1992/02/29  19:13:18  beebe
 * Initial revision
 *
 * Revision 1.1  1992/02/29  19:13:18  beebe
 * Initial revision
 *
 */

#define DVIHELP		":Home:Tex20/dvijep/dviman"

#ifdef DVIPREFIX
#undef DVIPREFIX
#endif /* DVIPREFIX */

#define DVIPREFIX	""

#ifndef ENV_SYSPATH			/* can override at compile time */
#define ENV_SYSPATH	"PATH"
#endif /* ENV_SYSPATH */

#ifndef FONTFMT				/* can be set at compile time */
#define FONTFMT		"%d/%n.pk;%d/%n.gf;%m/%n.pxl;%n.vf;%n.tfm"
#endif /* FONTFMT */

#ifndef FSMAPFILE			/* can be set at compile time */
#define FSMAPFILE	"texfiles.map"
#endif /* FSMAPFILE */

#define HOST_WORD_SIZE	32	/* must be 32 or larger -- used in */
				/* signex to pack 8-bit bytes back */
				/* into integer values, and in dispchar */
				/* and fillrect for managing character */
				/* raster storage. */

#ifndef PSMAPFILE			/* can be set at compile time */
#define PSMAPFILE	"psfonts.map"
#endif /* PSMAPFILE */

#ifdef SEGMEM
#undef SEGMEM
#endif /* SEGMEM */

#define SEGMEM		1

#define SEP_COMP " ;,|"	/* separators between filename components */
#define SEP_PATH "/"	/* separators between directory path and filename */

#ifndef SUBEXT				/* can be set at compile time */
#define SUBEXT		".sub"
#endif /* SUBEXT */

#ifndef SUBNAME				/* can be set at compile time */
#define SUBNAME		"texfonts"
#endif /* SUBNAME */

#ifndef TEXFONTS			/* can be set at compile time */
#define TEXFONTS	":TeXpixels:"
#endif /* TEXFONTS */

#ifndef    TEXINPUTS			/* can be set at compile time */
#define TEXINPUTS	":TeXinputs:"
#endif /* TEXINPUTS */

#define TEXFONTS	":TeXfonts:"

#define register			/* compiler has problems with this */

#ifndef TFMFMT				/* can be set at compile time */
#define TFMFMT		"%n.tfm"
#endif /* TFMFMT */

#endif /* OSRMX_H_DEFINED_ */
