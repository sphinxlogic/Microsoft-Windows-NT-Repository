/* -*-C-*- osvmcms.h */
/*-->osvmcms*/
/**********************************************************************/
/******************************* osvmcms ******************************/
/**********************************************************************/

#ifndef OSVMCMS_H_DEFINED_
#define OSVMCMS_H_DEFINED_

/* $Id: osvmcms.h,v 1.4 1992/10/08 01:42:01 beebe Exp beebe $
 * $Log: osvmcms.h,v $
 * Revision 1.4  1992/10/08  01:42:01  beebe
 * Update for C++.
 *
 * Revision 1.3  1992/03/10  14:13:53  beebe
 * *** empty log message ***
 *
 * Revision 1.2  1992/02/29  19:42:20  beebe
 * Update for version 3.0.114 [29-Feb-1992] following two-month
 * major overhaul and compilation testing on numerous machines.
 *
 * Revision 1.2  1992/02/29  19:42:20  beebe
 * Update for version 3.0.114 [29-Feb-1992] following two-month
 * major overhaul and compilation testing on numerous machines.
 *
 * Revision 1.1  1992/02/29  19:13:23  beebe
 * Initial revision
 *
 * Revision 1.1  1992/02/29  19:13:23  beebe
 * Initial revision
 *
 */

/***********************************************************************
** Several standard UNIX library functions do not work properly with CMS
** C (Waterloo C), or are not implemented:
**
** ??	exit()		-- wrong conventions for return code
** ??	fseek()		-- fails on record-oriented files, returns
**			   record number, instead of 0, on success
** ??	ftell()		-- fails on record-oriented files
** ??	getchar()	-- waits for <CR> to be typed
**	getenv()	-- not implemented
** ??	tell()		-- not implemented
**	ungetc()	-- fails for any character with high-order bit set
**	unlink()	-- not implemented (equivalent available)-is now
**	DISKFULL should be just ferror
***********************************************************************/

#ifdef ARITHRSHIFT
#undef ARITHRSHIFT
#endif /* ARITHRSHIFT */

#define ARITHRSHIFT	0

#define BUFSIZE		1024		/* lrecl for dvi and font files */
#define ctime		asctime

#ifdef CACHE_FONTS
#undef CACHE_FONTS
#endif /* CACHE_FONTS */

#define CACHE_FONTS	0		/* cannot support this yet */

#ifdef DISKFULL
#undef DISKFULL
#endif /* DISKFULL */

#define DISKFULL(fp)	ferror(fp)

#ifdef DVIEXT
#undef DVIEXT
#endif /* DVIEXT */

#define DVIEXT          " dvi *"

#define DVIHELP		"help dvi"

#ifdef DVIPREFIX
#undef DVIPREFIX
#endif /* DVIPREFIX */

#define DVIPREFIX	""

#ifndef ENV_SYSPATH			/* can override at compile time */
#define ENV_SYSPATH	""
#endif /* ENV_SYSPATH */

#ifdef ERRSUFFIX
#undef ERRSUFFIX
#endif /* ERRSUFFIX */

#define ERRSUFFIX	"err a"		/* CMS uses "file err a" instead */

#ifdef EXTSEPARATOR
#undef EXTSEPARATOR
#endif /* EXTSEPARATOR */

#define EXTSEPARATOR	" "		/* CMS uses "file ext" instead */

#ifndef FONTFMT
/* Search paths are handled externally by CMS; it looks in all the
user's attached minidisks automatically to find the named files.
Because of a bug in the current version of Waterloo C, the closing ")"
has to be omitted, sigh... */
#define FONTFMT		"%n %dpk *(bin recfm f lrecl 1024;\
%n %dgf *(bin recfm f lrecl 1024;\
%n %mpxl *(bin recfm f lrecl 1024;\
%n vf *(bin recfm f lrecl 1024;\
%n tfm *(bin recfm f lrecl 1024;"
#endif /* FONTFMT */

#ifdef FSEEK
#undef FSEEK
#endif /* FSEEK */

#define FSEEK(fp,offset,pos) ((fseek((fp),(offset),(pos)) == EOF) ? EOF : 0)

#ifndef FSMAPFILE			/* can be set at compile time */
#define FSMAPFILE	"texfiles map"
#endif /* FSMAPFILE */

#define GETENV(name)	((char*)NULL)	/* no getenv() available */
#define HOST_WORD_SIZE  32	/* must be 32 or larger -- used in */
				/* signex to pack 8-bit bytes back */
				/* into integer values, and in dispchar */
				/* and fillrect for managing character */
				/* raster storage. */

#ifndef PSMAPFILE		/* can be set at compile time */
#define PSMAPFILE	"psfonts map"
#endif /* PSMAPFILE */

#ifdef REWIND
#undef REWIND
#endif /* REWIND */

#define REWIND(fp)      (void)rewind(fp)

/* !!! NB: Installers note: these need to be reset to something sensible. !!! */
#define SEP_COMP " ;,|"	/* separators between filename components */
#define SEP_PATH ":]"	/* separators between directory path and filename */
			/* first char is what we default to */

#ifndef SUBEXT				/* can be set at compile time */
#define SUBEXT		" sub"
#endif /* SUBEXT */

#ifndef SUBNAME				/* can be set at compile time */
#define SUBNAME		"texfonts"
#endif /* SUBNAME */

#ifndef TEXFONTS			/* can be set at compile time */
#define TEXFONTS	""
#endif /* TEXFONTS */

#ifndef TEXINPUTS			/* can be set at compile time */
#define TEXINPUTS	""
#endif /* TEXINPUTS */

#ifdef TFMEXT
#undef TFMEXT
#endif /* TFMEXT */

#define TFMEXT          " tfm *"

#ifndef TFMFMT
#define TFMFMT          "%n tfm *"
#endif /* TFMFMT */

#define time		localtime

#endif /* OSVMCMS_H_DEFINED_ */
