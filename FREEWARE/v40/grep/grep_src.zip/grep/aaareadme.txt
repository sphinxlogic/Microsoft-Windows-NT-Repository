GNU grep v2.0 (July 4, 1993, VMS version 16-DEC-1993 07:07)

This version was taken from prep.ai.mit.edu and modified to run under VMS. 
It compiles under OpenVMS VAX using VAX C and GNU C (GCC) and under OpenVMS
AXP using DEC C.  It was tested with VAX C v3.2 under VMS v5.5, and with
DEC C V1.3A under OpenVMS AXP V1.5.

Thanks to Roland Roberts <roberts@nsrl31.nsrl.rochester.edu> for the GCC
mods.

As supplied, VMSMAKE.COM also compiles SHELL_MUNG.C, which will allow grep
to handle wildcarded file specs.

egrep and fgrep can be created by either copying the GREP.EXE to EGREP.EXE
and FGREP.EXE or by defining the commands as shown below.

ggrep can also be created that way.  ggrep is egrep as used by the Gopher
server for VMS.

To install:

	$ @VMSMAKE.COM			!or just $ MMS
	$ GREP :== $dev:[dir]GREP.EXE
	$ EGREP :== $dev:[dir]GREP.EXE """-E"""
	$ FGREP :== $dev:[dir]GREP.EXE """-F"""
	$ LIBRARY/HELP/INSERT library GREP
	$ SET DEFAULT [.TESTS]
	$ @VMSREGRESS.COM		!To test it out

New to this distribution:

	VMSMAKE.COM			DCL command procedure to build grep
	DESCRIP.MMS			MMS file to build grep
	GREP.CLD			Command definition file for e?grep
	GREP.EXAMPLES			grep commands equiv. to SEARCH commands
	GREP.RNH			RUNOFF source for on-line VMS help
	SHELL_MUNG.C			Emulate UNIX shell
	GREP.C				Modified for VMS
	[.TESTS]VMSSCRIPTGEN.AWK	GNU awk program to create testing .COM
	[.TESTS]VMSREGRESS.COM		DCL command procedure to test egrep

This version of grep also includes a few VMS-specific (bracketed by #ifdef VMS)
changes.  Specifically:

    1.  Added call to shell_mung
    2.  References to sys_errlist[errno] were causing grep to stack dump.
        I modified it to call strerror instead.
    3.  The exit statuses were changed to better fit VMS:
            Meaning                  UNIX       VMS
            -------                  ----       ---
            matches found               0         1
            no matches found            1         3
            error                       2        44 (SS$_ABORT)
    4.  Modified print_line to use puts when printing lines instead of
        putchar.  Much faster output on VMS.

I also modified SHELL_MUNG.C to allow it to be compiled by GNU C.

Any suggestions/comments/etc. can be sent to the address below.

Hunter Goatley, VAX Systems Programmer      E-mail: goathunter@WKUVX1.WKU.EDU
Academic Computing, STH 226                 Voice:  (502) 745-5251
Western Kentucky University
Bowling Green, KY 42101
