#include "snd.h"

void reflect_play_stop (snd_info *sp) 
{
  Widget pl;
  if (sp->grouping)
    stop_group_play(sp);
  else
    {
      pl = snd_widget(sp,W_snd_play);
      if (pl) XmToggleButtonSetState(pl,FALSE,FALSE);
      set_file_browser_play_button(sp->shortname,0);
    }
}

static Boolean run_dac(XtPointer dacData) 
{
  return(feed_dac((dac_manager *)dacData));
}

void set_play_in_progress (snd_state *ss, dac_manager *dac_m) 
{
  XtAppAddWorkProc(XtWidgetToApplicationContext(main_PANE(ss)),run_dac,(XtPointer)dac_m);
}
