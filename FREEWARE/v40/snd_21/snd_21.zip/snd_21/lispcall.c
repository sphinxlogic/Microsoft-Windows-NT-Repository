long lisp_call(int index) {return(0);}

