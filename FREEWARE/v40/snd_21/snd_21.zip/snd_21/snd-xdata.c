#include "snd.h"


Widget main_SHELL(void *w) 
{
  snd_state *sp;
  if ((sp = main_STATE(w))) return((sp->sgx)->mainshell); else return(NULL);
}

Widget main_PANE(void *w) 
{
  snd_state *sp;
  sp = main_STATE(w);
  if (sp) return((sp->sgx)->mainpane); else return(NULL);
}

Widget sound_PANE(void *w) 
{
  snd_state *sp;
  sp = main_STATE(w);
  if (sp) return((sp->sgx)->soundpane); else return(NULL);
}

XtAppContext main_APP(void *w)
{
  snd_state *sp;
  if ((sp = main_STATE(w))) return((sp->sgx)->mainapp); 
  else return(NULL);
}

#if 0
int event_pending(void *w)
{
  return(XtAppPending(main_APP(w)));
}
#endif

Display *main_DISPLAY(void *w) 
{
  snd_state *sp;
  if ((sp = main_STATE(w))) return((sp->sgx)->mdpy); else return(NULL);
}

Time main_TIME(snd_state *ss)
{
  return(XtLastTimestampProcessed((ss->sgx)->mdpy) - ss->play_start_time);
}

int main_SCREEN(void *w) 
{
  Display *dpy;
  if ((dpy = main_DISPLAY(w))) return(DefaultScreen(dpy)); else return(0);
}

XmFontList button_FONT(void *w) 
{
  snd_state *sp;
  if ((sp = main_STATE(w))) return((sp->sgx)->button_fontlist); else return(NULL);
}

XmFontList bold_button_FONT(void *w) 
{
  snd_state *sp;
  if ((sp = main_STATE(w))) return((sp->sgx)->bold_button_fontlist); else return(NULL);
}

XmFontList help_text_FONT(void *w) 
{
  snd_state *sp;
  if ((sp = main_STATE(w))) return((sp->sgx)->help_text_fontlist); else return(NULL);
}

XFontStruct *peak_numbers_FONTSTRUCT(void *w) 
{
  snd_state *sp;
  if ((sp = main_STATE(w))) return((sp->sgx)->button_fontstruct); else return(NULL);
}

XFontStruct *bold_peak_numbers_FONTSTRUCT(void *w) 
{
  snd_state *sp;
  if ((sp = main_STATE(w))) return((sp->sgx)->bold_button_fontstruct); else return(NULL);
}

XFontStruct *axis_label_FONTSTRUCT(void *w) 
{
  snd_state *sp;
  if ((sp = main_STATE(w))) return((sp->sgx)->axis_label_fontstruct); else return(NULL);
}

XFontStruct *axis_numbers_FONTSTRUCT(void *w) 
{
  snd_state *sp;
  if ((sp = main_STATE(w))) return((sp->sgx)->axis_numbers_fontstruct); else return(NULL);
}


