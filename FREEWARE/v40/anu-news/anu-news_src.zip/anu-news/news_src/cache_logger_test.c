/*
**++
**  FACILITY:
**      CACHE_LOGGER_TEST.C
**
**  ABSTRACT:
**      Program to test shareable log file code.
**      Link with CACHE_LOGGER.OBJ.
**
**  AUTHOR:
**      Bill Teahan, University of Waikato, Hamilton, New Zealand
**
**  COPYRIGHT:
**      Copyright � 1991
**--
**/

#ifdef vaxc
#module LOGGER_TEST "V1.0"
#endif

main()
{
	int i;

	open_log_file("fred.lis");
	for (i=0; i<20; i++) {
	    write_log_file( "To be or not to be." );
	    write_log_file( "To be or not to be." );
	}
	close_log_file();
}
/*
 * Cache Message Id utility for caching for News.
 */

#include stdio
#include descrip
#include "cachedefine.h"

main()
{
 	int finished = 0;
	int found;
	char reply[2];

	CACHE_ID id;

	cache_debug_cache( 1, 0 );
	while (!finished) { */
	    printf( "Id? " );
	    gets( id );
	    found = cache_check( id );
	    if (found)
		printf( "Found in cache list\n" );
	    else
		printf( "Not found in cache list\n" );
	}
}
