/*
 * Cache Message Id utility for caching for News.
 */

#include <stdio.h>
#include <descrip.h>

#include "cachedefine.h"

main()
{
 	int finished = 0;
	int found;
	char reply[2];

	CACHE_ID id;

	cache_debug_cache( 1, 0 );
	while (!finished) { */
	    printf( "Id? " );
	    gets( id );
	    found = cache_check( id );
	    if (found)
		printf( "Found in cache list\n" );
	    else
		printf( "Not found in cache list\n" );
	}
}
