typedef union
{
  char str[64];
  long integer;
  float real;
  unsigned long tval;
  NODE *node;
} YYSTYPE;
#define	REAL	258
#define	INTEGER	259
#define	FRACTION	260
#define	ID	261
#define	PARAM	262
#define	LOCAL	263
#define	STRING	264
#define	EVENT	265
#define	AT	266
#define	PLAYSCORE	267
#define	SCORE	268
#define	INSTRUMENT	269
#define	END	270
#define	SPEED	271
#define	AMP	272
#define	TRANS	273
#define	WAVE	274
#define	TIMES	275
#define	INSTANCE	276
#define	OF	277
#define	SCALE	278
#define	NOTE	279
#define	DURADD	280
#define	SAMPLE	281
#define	FORMAT	282
#define	FILETOK	283
#define	PITCH	284
#define	SAMPRATE	285
#define	FROM	286
#define	TO	287
#define	RAMP	288
#define	SIGNATURE	289
#define	TEMPO	290
#define	CHANS	291


extern YYSTYPE yylval;
