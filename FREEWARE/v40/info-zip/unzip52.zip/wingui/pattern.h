#define IDM_PATTERN_PATTERN  101

#define IDM_PATTERN_TEXT            100
#define IDM_PATTERN_SELECT          102
#define IDM_PATTERN_CANCEL          103
#define IDM_PATTERN_HELP            104
#define IDM_PATTERN_DESELECT        105
