f77 -c -O4 -i4 analy.for
/usr/5bin/cc -c cinterface.c
f77 analy.o cinterface.o -L/usr/5lib -lcurses -Bstatic
mv a.out analy
