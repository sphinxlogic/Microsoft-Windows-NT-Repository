/* definitions used by ZT "server" programs calling ZTSERVER */
/***** these definitions must match ZTDEF.MAR & ZTSERVER *****/

/*	Version 0.99A		*/
/*	wjm 3-feb-1995: (1.01) added media.ub (ZTDEF unchanged)
 */

typedef struct ZTmsg {
#if defined(__alpha)	/* goes with definition of EVAX in MACRO programs */
	union {
		unsigned char ub[8];
		short w[4];
		unsigned short uw[4];
		unsigned int ul[2];
	} media;
	unsigned int devdepend;
	int record;
	unsigned int ucbsts;
	unsigned int devchar;
	unsigned int func;
	unsigned int bcnt;
	unsigned int iosts;
	unsigned int iobct;
#else
	unsigned short iosts;
	unsigned short iobct;
	unsigned int devdepend;
	int record;
	unsigned short ucbsts;
	unsigned short fill1;
	unsigned int devchar;
	unsigned short func;
	unsigned short bcnt;
	union {
		unsigned char ub[8];
		short w[4];
		unsigned short uw[4];
		unsigned int ul[2];
	} media;
#endif
} ZTmsg;
globalref struct {
	unsigned short l;
	unsigned short fill1;
	ZTmsg *p;
} ZT_MSGDSC;

globalref struct {
	unsigned int bct;
	unsigned char *addr;
} ZT_BUFDSC;
