use ExtUtils::MakeMaker;
WriteMakefile(
    NAME => 'Opcode',
    VERSION_FROM => 'Opcode.pm',
    MAN3PODS 	=> ' '
);
