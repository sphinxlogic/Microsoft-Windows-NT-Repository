use ExtUtils::MakeMaker;

WriteMakefile(
	      NAME => 'OS2::REXX',
	      VERSION => '0.2',
	      XSPROTOARG => '-noprototypes',
);
