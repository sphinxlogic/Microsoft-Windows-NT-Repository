use ExtUtils::MakeMaker;

WriteMakefile( 'VERSION_FROM' => 'Stdio.pm' );
