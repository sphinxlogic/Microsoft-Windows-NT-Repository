/* @(#)vms.c	1.6 00/12/05 joerg */
#ifndef lint
static	char sccsid[] =
	"@(#)vms.c	1.6 00/12/05 joerg";

#endif
/*
 * File vms.c - assorted bletcherous hacks for VMS.
 *
 * Written by Eric Youngdale (1993).
 *
 */

#ifdef __VMS
#include <mconfig.h>
#include "mkisofs.h"
#include <rms.h>
#include <descrip.h>
#include <ssdef.h>
#include <starlet.h>

static struct RAB	*rab;		/* used for external mailfiles */
static int		rms_status;

static
error_exit(char *text)
{
	fprintf(stderr, "%s\n", text);
	exit(33);
}


void
vms_path_fixup(char *name)
{
	char		*pnt1;

	pnt1 = name + strlen(name) - 6;

	/* First strip the .DIR;1 */
	if (strcmp(pnt1, ".DIR;1") == 0)
		*pnt1 = 0;

	pnt1 = (char *) strrchr(name, ']');
	if (pnt1) {
		if (pnt1[1] == 0)
			return;
		*pnt1 = '.';
		strcat(name, "]");
		return;
	};
	pnt1 = (char *) strrchr(name, '>');
	if (pnt1) {
		if (pnt1[1] == 0)
			return;
		*pnt1 = '.';
		strcat(name, ">");
		return;
	};
}

static
open_file(char *fn)
{
/* this routine initializes a rab and  fab required to get the
   correct definition of the external data file used by mail */
	struct FAB	*fab;

	rab = (struct RAB *) e_malloc(sizeof(struct RAB));
	fab = (struct FAB *) e_malloc(sizeof(struct FAB));

	*rab = cc$rms_rab;	/* initialize RAB */
	rab->rab$l_fab = fab;

	*fab = cc$rms_fab;	/* initialize FAB */
	fab->fab$l_fna = fn;
	fab->fab$b_fns = strlen(fn);
	fab->fab$w_mrs = 512;
	fab->fab$b_fac = FAB$M_BIO | FAB$M_GET;
	fab->fab$b_org = FAB$C_SEQ;
	fab->fab$b_rfm = FAB$C_FIX;
	fab->fab$l_xab = (char *) 0;

	rms_status = sys$open(rab->rab$l_fab);
	if (rms_status != RMS$_NORMAL && rms_status != RMS$_CREATED)
		error_exit("$OPEN");
	rms_status = sys$connect(rab);
	if (rms_status != RMS$_NORMAL)
		error_exit("$CONNECT");
	return 1;
}

static
close_file(struct RAB * prab)
{
	rms_status = sys$close(prab->rab$l_fab);
	free(prab->rab$l_fab);
	free(prab);
	if (rms_status != RMS$_NORMAL)
		error_exit("$CLOSE");
}

#define NSECT 16
extern unsigned int last_extent_written;

void
vms_write_one_file(char *filename, int size, FILE * outfile)
{
	int		status,
			i;
	char		buffer[SECTOR_SIZE * NSECT];
	int		count;
	int		use;
	int		remain;

	open_file(filename);

	remain = size;

	while (remain > 0) {
		use = (remain > SECTOR_SIZE * NSECT - 1 ? NSECT * SECTOR_SIZE : remain);
		use = ISO_ROUND_UP(use);	/* Round up to nearest sector boundary */
		memset(buffer, 0, use);
		rab->rab$l_ubf = buffer;
		rab->rab$w_usz = sizeof(buffer);
		status = sys$read(rab);
		fwrite(buffer, 1, use, outfile);
		last_extent_written += use / SECTOR_SIZE;
		if ((last_extent_written % 1000) < use / SECTOR_SIZE)
			fprintf(stderr, "%d..", last_extent_written);
		remain -= use;
	};

	close_file(rab);
        return;
}

#endif /* __VMS */
