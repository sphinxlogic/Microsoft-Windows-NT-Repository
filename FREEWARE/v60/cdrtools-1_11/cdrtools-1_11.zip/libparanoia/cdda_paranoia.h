/* @(#)cdda_paranoia.h	1.15 02/04/10 J. Schilling from cdparanoia-III-alpha9.8 */
/*
 *	Modifications to make the code portable Copyright (c) 2002 J. Schilling
 */
/***
 * CopyPolicy: GNU Public License 2 applies
 * Copyright (C) by Monty (xiphmont@mit.edu)
 *
 ***/

#ifndef	_CDROM_PARANOIA_
#define	_CDROM_PARANOIA_

#ifndef	__GNUC__
#define	inline
#endif

#define	CD_FRAMESIZE_RAW		2352
#define	CD_FRAMEWORDS			(CD_FRAMESIZE_RAW/2)

/*
 * Second parameter of the callback function
 */
#define	PARANOIA_CB_READ		 0
#define	PARANOIA_CB_VERIFY		 1
#define	PARANOIA_CB_FIXUP_EDGE		 2
#define	PARANOIA_CB_FIXUP_ATOM		 3
#define	PARANOIA_CB_SCRATCH		 4
#define	PARANOIA_CB_REPAIR		 5
#define	PARANOIA_CB_SKIP		 6
#define	PARANOIA_CB_DRIFT		 7
#define	PARANOIA_CB_BACKOFF		 8
#define	PARANOIA_CB_OVERLAP		 9
#define	PARANOIA_CB_FIXUP_DROPPED	10
#define	PARANOIA_CB_FIXUP_DUPED		11
#define	PARANOIA_CB_READERR		12

/*
 * Cdparanoia modes to be set with paranoia_modeset()
 */
#define	PARANOIA_MODE_FULL		 0xFF
#define	PARANOIA_MODE_DISABLE		 0

#define	PARANOIA_MODE_VERIFY		 1
#define	PARANOIA_MODE_FRAGMENT		 2
#define	PARANOIA_MODE_OVERLAP		 4
#define	PARANOIA_MODE_SCRATCH		 8
#define	PARANOIA_MODE_REPAIR		16
#define	PARANOIA_MODE_NEVERSKIP		32


#ifndef	CDP_COMPILE
typedef	void    cdrom_paranoia;
#endif

extern cdrom_paranoia	*paranoia_init	__PR((void * d, int nsectors));
extern void	paranoia_modeset	__PR((cdrom_paranoia * p, int mode));
extern long	paranoia_seek		__PR((cdrom_paranoia * p, long seek, int mode));
extern Int16_t	*paranoia_read		__PR((cdrom_paranoia * p, void (*callback) (long, int)));
extern Int16_t	*paranoia_read_limited	__PR((cdrom_paranoia * p, void (*callback) (long, int), int maxretries));
extern void	paranoia_free		__PR((cdrom_paranoia * p));
extern void	paranoia_overlapset	__PR((cdrom_paranoia * p, long overlap));

#endif
