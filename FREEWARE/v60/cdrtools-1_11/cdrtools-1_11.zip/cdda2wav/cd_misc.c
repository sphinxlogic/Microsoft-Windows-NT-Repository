*** This file is a link to ../cdrecord/cd_misc.c
