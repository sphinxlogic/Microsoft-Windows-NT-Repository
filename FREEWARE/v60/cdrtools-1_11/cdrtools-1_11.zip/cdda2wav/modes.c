*** This file is a link to ../cdrecord/modes.c
