*** This file is a link to ../cdrecord/scsi_cdr.c
