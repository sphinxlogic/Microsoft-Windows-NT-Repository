*** This file is a link to ../cdrecord/misc.c
