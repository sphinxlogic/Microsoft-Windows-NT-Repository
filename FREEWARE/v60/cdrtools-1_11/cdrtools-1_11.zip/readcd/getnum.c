*** This file is a link to ../cdrecord/getnum.c
