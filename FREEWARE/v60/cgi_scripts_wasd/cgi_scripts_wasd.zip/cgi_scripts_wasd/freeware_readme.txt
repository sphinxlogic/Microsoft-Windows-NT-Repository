SCRIPTS WASD, UTILITIES, WASD CGI scripts ported to other server environments

A small collection of VMS-useful "WASD Hypertext Services" CGI scripts package
(also on this freeware CD) ported to the CSWS V1.3 (OpenVMS Apache 1.3.26),
OSU (DECthreads, 3.10), Purveyor and other VMS CGI server environments.

  *  CONAN is used to access VMS Help and text libraries.

  *  HYPERSHELF is used to navigate BNU or Bookreader shelves.

  *  HYPERREADER is the book reader.

  *  HYPERSPI is a system performance monitor (of sorts!)

  *  HYPERSPI++ is hyperSPI plus more items plus better graphics

  *  QDLogStats provides elementary Web server access log statistics

  *  QUERY/EXTRACT is an ad hoc plain/HTML text search facility

  *  VMSeti is an interface for monitoring VMS SETI@home processing

  *  WWWCount is Muhammad A.Muquit's graphical Web page hit counter

  *  yahMAIL allows Web access to user's VMS mail

See FREEWARE_DEMO.TXT for installation instructions.

Access the HTML documentation using a browser on the local system.  First
ensure the freeware CD is mounted /SYSTEM, then enter

  file:///cd-device/cgi_scripts_wasd/

into the "Location:" field of the browser.

Mark.Daniel@wasd.vsm.com.au
(Mark.Daniel@dsto.defence.gov.au)
July 2003

http://wasd.vsm.com.au/
http://wasd.vsm.com.au/wasd/
ftp://ftp.vsm.com.au/wasd/index.html
