/* Emacs ioctl emulation for VMS */
