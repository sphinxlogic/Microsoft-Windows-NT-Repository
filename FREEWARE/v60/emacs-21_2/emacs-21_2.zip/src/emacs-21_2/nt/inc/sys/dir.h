/*
 * map sys\dir.h to ..\..\..\src\ndir.h
 */

#include "..\..\..\src\ndir.h"
