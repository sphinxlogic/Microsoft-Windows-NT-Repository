/* null version of <netinet/in.h> - <sys/socket.h> has everything */
