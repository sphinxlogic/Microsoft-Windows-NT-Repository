//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by VisVile.rc
//
#define IDS_VISVILE_LONGNAME            1
#define IDS_VISVILE_DESCRIPTION         2
#define IDS_CMD_STRING                  3
#define IDS_CMD_CONFIG                  4
#define IDS_CMD_ENABLE                  5
#define IDS_CMD_DISABLE                 6
#define IDS_CMD_LOAD                    7
#define IDR_TOOLBAR_MEDIUM              128
#define IDR_TOOLBAR_LARGE               129
#define IDD_DIALOG1                     132
#define IDC_CLOSE_DOC                   1000
#define IDC_ENABLED                     1001
#define IDC_CHDIR                       1002
#define IDC_ERRBUF                      1003
#define IDC_WRITE_BUFFERS               1004
#define IDC_KEY_REDIR                   1005
#define ID_BUTTON32771                  32771
#define ID_BUTTON32772                  32772
#define ID_BUTTON32773                  32773
#define ID_BUTTON32774                  32774
#define ID_BUTTON32779                  32779
#define ID_BUTTON32780                  32780
#define ID_BUTTON32781                  32781
#define ID_BUTTON32782                  32782

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32783
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
