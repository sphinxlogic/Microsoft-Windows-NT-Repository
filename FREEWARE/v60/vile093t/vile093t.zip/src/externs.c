/*
 * This is just a place holder -- a place in which to pull in edef.h alone
 *
 * $Header: /usr/build/vile/vile/RCS/externs.c,v 1.8 2001/09/18 09:49:27 tom Exp $
 *
 */

#include	"estruct.h"	/* function declarations */

#define real_CMDFUNCS
#include	"nefunc.h"	/* function declarations */
#include	"nebind.h"	/* default key bindings */
#include	"nename.h"	/* name table */

EXTERN_CONST int nametblsize = TABLESIZE(nametbl);

