README_bindos.txt for version 6.1 of Vim: Vi IMproved.

See "README.txt" for general information about Vim.
See "README_dos.txt" for installation instructions for MS-DOS and MS-Windows.
These files are in the runtime archive (vim60rt.zip).


There are several binary distributions of Vim for the PC.  You would normally
pick only one of them, but it's also possible to install several.
These ones are available (the version number may differ):
	vim60d16.zip	16 bit DOS version
	vim60d32.zip	32 bit DOS version
	vim60w32.zip	Windows 95/98/NT/etc. console version
	gvim60.zip	Windows 95/98/NT/etc. GUI version
	gvim60ole.zip	Windows 95/98/NT/etc. GUI version with OLE
	gvim60_s.zip	Windows 3.1 GUI version

You MUST also get the runtime archive (vim60rt.zip).
The sources are also available (vim60src.zip).
