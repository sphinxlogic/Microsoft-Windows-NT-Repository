// Incomplete YEncoder for VMS, for making a test file for YDecoder
// standard headers
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stat.h>
#include <ctype.h>
#include <errno.h>
#include <unistd.h>

// how about a nice error message before giving up?
static void fatal(char* reason)
{
   // no error number, just give the reason
   if (errno == 0)
   {
      fprintf(stderr,"%s\n",reason);
      exit(1);
   }

   // there's an error number, use it
   perror(reason);

   // C RTL I/O errors are pretty vague, add
   // the original message
   if (errno == EIO)
   {
      errno = EVMSERR;
      perror("");
   }

   // stop
   exit(1);
}

void addChar(char c, FILE* outFile)
{
   static int len = 0;

   putc(c,outFile);
   len++;
   if (len == 128) 
   {
      putc('\n',outFile);
      len = 0;
   }
}

// encode a character
static char encodeChar(int character, char* special)
{
   // some of the following are not always escaped, but I will
   // 	    	     	      CR, LF, NULL, ESC,  >,  TAB,  SP,  =
   static const char bad[] = {13, 10,    0,  27, '>',   9, ' ', '='};

//   if (character == 0x13) lib$signal(SS$_DEBUG);

   int result = character + 42;
   *special = FALSE;

   for (int i = 0; i < sizeof bad; i++)
      if ((result % 256) == bad[i]) 
      {
      	 result += 64;
      	 *special = TRUE;
      	 return result % 256;
      }

   return result % 256;
}

/**
 * This function does all of the encoding work.
 *
 * args:
 * outFile    destination file
 * inFilename   file to read from
 */
static void encode(FILE* outFile, char* inFilename)
{
   FILE* inFile = fopen(inFilename, "r");
   if (inFile == NULL) fatal(inFilename);

   // output the input file name line
   struct stat stat_buf;
   stat(inFilename, &stat_buf);
      
   fprintf(outFile,"=ybegin line=128 size=%d name=%s\n",
      stat_buf.st_size,inFilename);

   // no multi-part   

   /* Encode the file */
   int character;
   char special = FALSE;

   while ((character = fgetc(inFile)) != EOF)
   {
       if (ferror(inFile)) fatal("can't read input");

       character = encodeChar(character, &special);
       if (special) addChar('=',outFile);
       addChar(character,outFile);
   }
  
   // the end of file line
   fprintf(outFile,"\n=yend %d\n",stat_buf.st_size);
   fclose(outFile);
}

/**
 * To Run:
 *  yencoder FileToEncode DestinationFile
 *
 * argv   Command line argument(s)
 *     	  FileToEncode:    input file
 *     	  DestinationFile: output file
 */
void main (char argc, char* argv[])
{
    if (argc != 3) 
    {
        // print usage and exit
        fprintf(stderr,"Usage: yencoder fileIn fileOut\n");
      	exit(1);
    }

    FILE* file = fopen(argv[2],"w");
    if (file == NULL) fatal(argv[2]);
   
    encode(file, argv[1]);
}
