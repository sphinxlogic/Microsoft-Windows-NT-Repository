// YDecoder for VMS, based on YDecoder.java by Alex Rass sashasemail@yahoo.com
// His original source is protected by GPL.

// Uses $filescan and $parse to parse filenames before fixing them
// to meet VMS specs.  These won't parse some things that a person 
// might try to parse.  For example [foo,4] looks a lot like a directory, 
// but is not parseable that way.  Instead of trying to out think $filescan
// and $parse for all such cases I only try the most obvious fixes.
//
// Using these VMS routines for fixing VMS filenames reduces the
// possibility of some legal combination falling through (how about
// [foo.]<bar>) and increases the likelyhood that this code will work
// when/if another enhancement is introduced.  (I'm tired of fixing code
// that only does ODS-2, doesn't know about <>, ...).

// if I look real hard I bet I could find a memory leak or two, but this
// program won't stick around long so image run down will catch all that.

/**
 * Implementation of the decoder for YEncoding project.
 * 
 * This program is to be used to decode files encoded with yenc
 * See www.yenc.org for details.
 * 
 * To run the project, use one of:
 *    A) a foreign command:  
 *    	 ydecoder == "$dev:[dir.subdir]ydecoder
 *    	 ydecoder fileIn [fileOut]
 *    B) the DCL path
 *    	 define dcl$path dev:[dir.subdir]
 *    	 ydecoder fileIn [fileOut]
 *    C) the MCR command
 *    	 mcr dev:[dir.suibdir]ydecoder fileIn [fileOut]
 *
 * Known limitations:
 * 
 *     The CRC is not checked (inherited from YDecoder.java)
 * 
 * YDecoder.java author:
 * Alex Rass sashasemail@yahoo.com
 * Version 2
 * Copywrite by Alex Rass 2002.
 * This software is to be distributed in accordance with the GNU public license.
 */

// the VMS file name fixing is a bit overkill since I'm not expecting
// any paths in the =ybegin name, but I always wanted to do it this way

// standard headers
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stat.h>
#include <ctype.h>
#include <errno.h>
#include <unistd.h>

// VMS headers
#include <fscndef.h>
#include <dvidef.h>
// Files 11 ODS-5 might not be defined IFF on a VAX
// ($getdvi will return this value on a VAX on an ODS-5
//  disk served by an Alpha)
#if !defined(DVI$C_ACP_F11V5) && defined(__vax)
   #define DVI$C_ACP_F11V5 11
#endif
#include <descrip.h>
#include <stsdef.h>
#include <lib$routines.h>
#include <starlet.h>
#include <rms.h>

// deal with NAM vs. NAML differences
#if !defined(NAML$C_MAXRSS) && defined(__vax)
   #define MAXRSS NAM$C_MAXRSS
   #define NAMTYPE NAM
   #define FAB_NAM fab$l_nam
   #define DECC_NAM cc$rms_nam
   #define EXPAND_A nam$l_esa
   #define EXPAND_ALLOC nam$b_ess
   #define EXPAND_LEN nam$b_esl
   #define DEV_A nam$l_dev
   #define DEV_LEN nam$b_dev
   #define NAME_A nam$l_name
   #define NAME_LEN nam$b_name
   #define QUOTED_FLAG nam$v_quoted
#else
   #define MAXRSS NAML$C_MAXRSS
   #define NAMTYPE NAML
   #define FAB_NAM fab$l_naml
   #define DECC_NAM cc$rms_naml
   #define EXPAND_A naml$l_long_expand
   #define EXPAND_ALLOC naml$l_long_expand_alloc
   #define EXPAND_LEN naml$l_long_expand_size
   #define DEV_A naml$l_long_dev
   #define DEV_LEN naml$l_long_dev_size
   #define NAME_A naml$l_long_name
   #define NAME_LEN naml$l_long_name_size
   #define QUOTED_FLAG naml$v_quoted
#endif

// standard VMS structures
typedef struct
{
  unsigned short length;
  unsigned short code;
  void* buffer;
} itmlst2;

typedef struct
{
  unsigned short length;
  unsigned short code;
  void* buffer;
  void* retlenadr;
} itmlst3;

// array index of parts according to $filescan
static enum parts {NODE = 0, DEVICE, ROOT, DIR, NAME, TYPE, VERSION};

// fix .. at begining of line? (known browser bug)
static int fixDot = TRUE;

// how about a nice error message before giving up?
static void fatal(char* reason)
{
   // no error number, just give the reason
   if (errno == 0)
   {
      fprintf(stderr,"%s\n",reason);
      exit(1);
   }

   // there's an error number, use it
   perror(reason);

   // C RTL I/O errors are pretty vague, add
   // the original message
   if (errno == EIO)
   {
      errno = EVMSERR;
      perror("");
   }

   // stop
   exit(1);
}

// must parse form left to right
static char* parseForName (char* line, char* param) 
{
   char* indexStart, * indexEnd, * hold;

   int paramLen = strlen(param) + 2;
   hold = malloc(paramLen);
   if (hold == NULL) fatal("memory allocation");

   strcpy(hold,param);
   strcat(hold,"=");
   paramLen--;
   indexStart = strstr(line,hold);

   if (indexStart == NULL) return NULL;
   indexStart += paramLen;

   // find the next parameter, if any
   indexEnd = strchr(indexStart,'=');
   if (indexEnd != NULL) 
   {
      indexEnd = indexStart + strlen(indexStart);
      *indexEnd = 0;

      // back up to the space between parameters
      indexEnd = strrchr(indexStart,' ');

      // back up over trailing spaces
      if (indexEnd != NULL) 
      {
      	 while (isspace(*(indexEnd--)));
         indexEnd++;

      	 *indexEnd = 0;
      }
   }

   free(hold);

   return indexStart;
}

// create a quoted name for DECnet or ANSI labled tape
char* quoted_name(itmlst2* name_parts)
{
   // notes: caller frees hold
   static char* hold = NULL;

   int total = name_parts[NODE].length + name_parts[DEVICE].length + 
      name_parts[NAME].length + name_parts[TYPE].length +
      name_parts[VERSION].length + 3;

   hold = malloc(total);
   if (hold == NULL) fatal("memory allocation");

   strncpy(hold,name_parts[NODE].buffer,name_parts[NODE].length);
   hold[name_parts[NODE].length] = 0;
   strncat(hold,name_parts[DEVICE].buffer,name_parts[DEVICE].length);

   // quote, but don't double quote
   if (((char*) name_parts[NAME].buffer)[0] != '"') strcat(hold,"\"");

   strncat(hold,name_parts[NAME].buffer,name_parts[NAME].length);
   strncat(hold,name_parts[TYPE].buffer,name_parts[TYPE].length);
   strncat(hold,name_parts[VERSION].buffer,name_parts[VERSION].length);

   // quote, but don't double quote
   if (hold[strlen(hold) - 1] != '"') strcat(hold,"\"");

   return hold;
}

// fix up a random string according to ODS-1 rules,
// some other parser has determined that the string is
// part of a file name without delimiters
// (tested via LDDRIVER)
char* ods_1_string(itmlst2* name)
{
   // notes: caller frees hold
   static char* hold;
   char* in, * out;

   // space for worst case: every character represented in hex
   hold = malloc((name->length * 3) + 1);
   if (hold == NULL) fatal("memory allocation");

   // translate each character
   in = name->buffer;
   out = hold;
   for (int i = 0; i < name->length; in++, out++, i++)
   {
      char temp[3];

      if (isprint(*in))
      {
         switch (*in)
         {
      	 // characters that cannot be represented, encode like Multinet
         case ' ':
      	 case ',':
      	 case ';':
      	 case '[':
      	 case ']':
      	 case '%':
      	 case '^':
      	 case '&':
      	 case '"':
      	 case '*':
      	 case '\\':
      	 case ':':
      	 case '<':
      	 case '>':
      	 case '/':
      	 case '?':
      	 case '|':
      	    *out++ = '$';
      	    if (sprintf(temp,"%2.2X",*in) != 2) fatal("can't fix name");
      	    *out++ = temp[0];
      	    *out = temp[1];
      	    break;

      	 // comonly used substitution
      	 case '.':
      	    *out = '_';
      	    break;

      	 // all other characters are OK as is
      	 default:
      	    *out = *in;
         }
      }
      else  // not a printable character
      {
      	 // characters that cannot be represented, encode like Multinet
      	 *out++ = '$';
      	 if (sprintf(temp,"%2.2X",*in) != 2)  fatal("can't fix name");
      	 *out++ = temp[0];
      	 *out = temp[1];
      }
   }
   *out = 0;

   return hold;
}

// fix up a random string according to ODS-2 rules,
// some other parser has determined that the string is
// part of a file name without delimiters
char* ods_2_string(itmlst2* name)
{
   // notes: caller frees hold
   static char* hold;
   char* in, * out;

   // space for worst case: every character represented in hex
   hold = malloc((name->length * 3) + 1);
   if (hold == NULL) fatal("memory allocation");

   in = name->buffer;
   out = hold;
   for (int i = 0; i < name->length; in++, out++, i++)
   {
      char temp[3];

      if (isprint(*in))
      {
         switch (*in)
         {
      	 // characters that cannot be represented, encode like Multinet
         case ' ':
      	 case ',':
      	 case ';':
      	 case '[':
      	 case ']':
      	 case '%':
      	 case '^':
      	 case '&':
      	 case '"':
      	 case '*':
      	 case '\\':
      	 case ':':
      	 case '<':
      	 case '>':
      	 case '/':
      	 case '?':
      	 case '|':
      	    *out++ = '$';
      	    if (sprintf(temp,"%2.2X",*in) != 2)  fatal("can't fix name");
      	    *out++ = temp[0];
      	    *out = temp[1];
      	    break;

      	 // commonly used substitution
      	 case '.':
      	    *out = '_';
      	    break;

      	 // all other characters are OK as is
      	 default:
      	    *out = *in;
         }
      }
      else  // not a printable character
      {
      	 // characters that cannot be represented, encode like Multinet
      	 *out++ = '$';
      	 if (sprintf(temp,"%2.2X",*in) != 2)  fatal("can't fix name");
      	 *out++ = temp[0];
      	 *out = temp[1];
      }
   }
   *out = 0;

   return hold;
}

// no direct ODS-5 support on a VAX, so don't bother compiling this
#ifndef __vax

// fix up a random string according to ODS-5 rules,
// some other parser has determined that the string is
// part of a file name without delimiters
char* ods_5_string(itmlst2* name, int allowDot)
{
   // notes: caller frees hold
   static char* hold;
   char* in, * out;

   // space for worst case: every character represented in hex
   hold = malloc((name->length * 3) + 1);
   if (hold == NULL) fatal("memory allocation");

   in = name->buffer;
   out = hold;
   for (int i = 0; i < name->length; in++, out++, i++)
   {
      char temp[3];

      if (isprint(*in))
      {
         switch (*in)
         {
         // characters that must be escaped with ^
         case ' ':
      	 case ',':
      	 case ';':
      	 case '[':
      	 case ']':
      	 case '%':
      	 case '^':
      	 case '&':
      	 case '!':
      	    *out++ = '^';
      	    *out = *in;
      	    break;

      	 // characters that cannot be represented, encode like Multinet
      	 case '"':
      	 case '*':
      	 case '\\':
      	 case ':':
      	 case '<':
      	 case '>':
      	 case '/':
      	 case '?':
      	 case '|':
      	    *out++ = '$';
            if (sprintf(temp,"%2.2X",*in) != 2)  fatal("can't fix name");
            *out++ = temp[0];
            *out = temp[1];
      	    break;

      	 // multiple dots OK in a name, but not in a type
      	 case '.':
      	    if (allowDot)
      	    {
      	       *out++ = '^';
      	       *out = *in;
      	    }
      	    else
      	    {
      	       *out++ = '$';
               if (sprintf(temp,"%2.2X",*in) != 2)  fatal("can't fix name");
               *out++ = temp[0];
               *out = temp[1];
      	    }
      	    break;

      	 // all other characters are OK as is
      	 default:
      	    *out = *in;
         }
      }
      else
      {
      	 // characters that cannot be represented, encode like Multinet
      	 if (*in <= 0x1f)
      	    *out++ = '$';

      	 else
      	    // characters that can be represented in hex escaped with ^
      	    *out++ = '^';

      	 // add hex encoding
      	 if (sprintf(temp,"%2.2X",*in) != 2)  fatal("can't fix name");
      	 *out++ = temp[0];
      	 *out = temp[1];
      }
   }
   *out = 0;

   return hold;
}
#endif

// fix up a numeric style directory name
// some other parser has determined that the string is
// a numeric directory name
char* uic_pair(itmlst2 *dir)
{
   // notes: caller frees hold
   static char* hold;

   // UIC pairs in the form [ggg,mmm]
   hold = malloc(dir->length + 1);
   if (hold == NULL) fatal("memory allocation");

   // drop enclosing []
   strncpy(hold,&(((char*) dir->buffer)[1]),dir->length - 2);
   hold[dir->length - 2] = 0;

   // find the separator
   char* comma = strchr(hold,',');
   if (comma == NULL)
   {
      // can't fix this, use default
      strcpy(hold,"[]");
      return hold;
   }

   // non-octal entries will be replaced with 0
   *comma = 0;
   int group, member;
   if (sscanf(hold,"%o",&group) != 1) group = 0;
   comma++;
   if (sscanf(comma,"%o",&member) != 1) member = 0;

   // limit to 3 digit pairs
   if (group > 0777) group = 0777;
   if (member > 0777) member = 0777;
   free(hold);

   hold = malloc(10);
   if (hold == NULL) fatal("memory allocation");
   if (sprintf(hold,"[%3.3o,%3.3o]",group,member) != 9)
      fatal("can't fix directory");

   return hold;
}

// ANSI C doesn't seem to think we need this one
// search part of a string for a character
char* strnchr(char* one, char two, size_t len)
{
   for(int i = 0; *one && (i < len); i++, one++)
     if (*one == two) return one;

   return NULL;
}

// ANSI C doesn't seem to think we need this one
// search part of a string until finding a substring
char* strnspn(char* one, char* two, size_t len)
{
   for(int i = 0; *one && (i < len); i++, one++)
     for (int j = 0; two[j] && j < len; j++)
     	 if (*one == two[j]) return one;

   return NULL;
}

// fix a directory name, may contain a root or normal
// directory list, but not both
char* fixDir(itmlst2* dir, int ods_level)
{
   // notes: caller frees hold
   static char* hold;
   static char* const ifNone = "[]";
   char* dirname = dir->buffer, * sep, * hold3;
   int sepCount = 0;
   itmlst2 temp;

   if (dir->buffer == NULL) return ifNone;

   // handle supported device types
   switch (ods_level)
   {
   // Files-11 ODS-5 (most flexible)
   case DVI$C_ACP_F11V5:
   // VAX has no direct support for ODS-5
   #ifndef __vax
      // if there are any "," assume uic pair notation
      if ((strnchr(dirname,',',dir->length) != NULL) ||
          (strnspn(dirname,"^,",dir->length) != NULL))
         return uic_pair(dir);
   
      // drop enclosing [] or <>
      hold = malloc(dir->length - 1);
      strncpy(hold,&(dirname[1]),dir->length - 2);
      hold[dir->length - 2] = 0;
   
      // subdirs separated by . but not ^.
      // find ordinary . separators
      sep = hold;              
      sep = strchr(sep,'.');
      while (sep != NULL)
      {
         if (*(sep - 1) != '^') sepCount++;
   
         sep = strchr(sep + 1,'.');
      }
   
      // everything between . separators needs to be valid ODS-5 names
      sep = hold;
      hold3 = malloc((dir->length * 3) + 1);
      hold3[0] = 0;
      for (int i = 0; i < sepCount; i++)
      {
         char* sep2 = strchr(sep,'.');
         while (*(sep2 - 1) == '^') sep2 = strchr(sep2 + 1,'.');
         int len = (int) (sep2 - sep);
         temp.buffer = sep;
         temp.length = len;
         strcat(hold3,ods_5_string(&temp,TRUE));
         strcat(hold3,".");
         free(hold);
         sep = sep2 + 1;
      }
      temp.buffer = sep;
      temp.length = strlen(sep);
      strcat(hold3,ods_5_string(&temp,TRUE));
      break;
   #endif   // real ODS-5 code if not VAX

   // for VAX the ODS-5 case falls through to here
   // Files-11 ODS-2 (most common)
   case DVI$C_ACP_F11V2:
      // if there are any "," assume uic pair notation
      if (strnchr(dirname,',',dir->length) != NULL)
      	 return uic_pair(dir);

      // drop enclosing [] or <>
      hold = malloc(dir->length - 1);
      strncpy(hold,&(dirname[1]),dir->length - 2);
      hold[dir->length - 2] = 0;

      // subdirs separated by .
      // find . separators
      sep = hold;
      sep = strchr(sep,'.');
      while (sep != NULL)
      {
      	 sepCount++;
      	 sep = strchr(sep + 1,'.');
      }

      // everything between . separators needs to be valid ODS-2 names
      sep = hold;
      hold3 = malloc((dir->length * 3) + 1);
      hold3[0] = 0;
      for (int i = 0; i < sepCount; i++)
      {
      	 char* sep2;
      	 sep2 = strchr(sep,'.');
      	 int len = (int) (sep2 - sep);
      	 temp.buffer = sep;
      	 temp.length = len;
      	 strcat(hold3,ods_2_string(&temp));
      	 strcat(hold3,".");
      	 sep = sep2 + 1;
      }
      temp.buffer = sep;
      temp.length = strlen(sep);
      strcat(hold3,ods_2_string(&temp));
      break;

   // Files-11 ODS-1 (like RSX)
   case DVI$C_ACP_F11V1:
      // if there are any "," assume uic pair notation
      if (strnchr(dirname,',',dir->length) != NULL)
      	 return uic_pair(dir);

      // drop enclosing [] or <>
      hold = malloc(dir->length - 1);
      strncpy(hold,&(dirname[1]),dir->length - 2);
      hold[dir->length - 2] = 0;

      // subdirs separated by .
      // find . separators
      sep = hold;
      sep = strchr(sep,'.');
      while (sep != NULL)
      {
      	 sepCount++;
      	 sep = strchr(sep + 1,'.');
      }

      // everything between . separators needs to be valid ODS-2 names
      sep = hold;
      hold3 = malloc((dir->length * 3) + 1);
      hold3[0] = 0;
      for (int i = 0; i < sepCount; i++)
      {
      	 char* sep2;
      	 sep2 = strchr(sep,'.');
      	 int len = (int) (sep2 - sep);
      	 temp.buffer = sep;
      	 temp.length = len;
      	 strcat(hold3,ods_1_string(&temp));
      	 strcat(hold3,".");
      	 sep = sep2 + 1;
      }
      temp.buffer = sep;
      temp.length = strlen(sep);
      strcat(hold3,ods_1_string(&temp));
      break;
   }

   // put back enclosing [], even if it was originally <>
   free(hold);
   hold = malloc(strlen(hold3) + 3);
   strcpy(hold,"[");
   strcat(hold,hold3);
   strcat(hold,"]");
   free(hold3);

   return hold;
}

// fix a file name
char* fixName(itmlst2* name, int ods_level, int allowDot)
{
   static char* const ifNone = "";
   if (name->buffer == NULL) return ifNone;

   // handle supported device types
   switch (ods_level)
   {
   // Files-11 ODS-1 (like RSX)
   case DVI$C_ACP_F11V1:
      return ods_1_string(name);

   // Files-11 ODS-5 (most flexible)
   case DVI$C_ACP_F11V5:
   // no direct support for ODS-5 on VAX
   #ifndef __vax
      return ods_5_string(name, allowDot);
   #endif

   // for VAX the ODS-5 case falls through to here
   // Files-11 ODS-2 (most common)
   case DVI$C_ACP_F11V2:
      return ods_2_string(name);
   }
}

// fix a file type (extension)
char* fixType(itmlst2* name, int ods_level)
{
   // notes: caller frees hold
   static char* hold;
   static char* const ifNone = ".";

   if (name->buffer == NULL) return ifNone;

   itmlst2 temp = *name;

   // remove leading .
   temp.length--;
   temp.buffer = &(((char*) name->buffer)[1]);

   // now it can be processed like a name, except ODS-5 won't let
   // it have another .
   char* hold2 = fixName(&temp, ods_level, FALSE);

   hold = malloc(strlen(hold2) + 2);
   if (hold == NULL) fatal("memory allocation");

   // put back leading .
   hold[0] = '.';
   hold[1] = 0;
   strcat(hold,hold2);
   
   free(hold2);
   return hold;
}

// fix a file version
char* fixVersion(itmlst2* ver, int ods_level)
{
   // notes: caller frees hold
   static char* hold;
   static char* const ifNone = ";";

   if (ver->buffer == NULL) return ifNone;

   // worst case ;-32767 decimal
   int i, len = ver->length;
   if (len < 7) len = 7;
   hold = malloc(len + 1);
   if (hold == NULL) fatal("memory allocation");

   // watch out for empty version number (just ;)
   if (ver->length == 1)
   {
      hold[0] = '0';
      hold[1] = 0;
   }
   else
   {
      // skip leading ; and any trailing stuff
      char* version = ver->buffer;
      strncpy(hold,&(version[1]),len - 1);
      hold[len - 1] = 0;
   }

   // handle supported device types, allow relative version numbers,
   // any wildcards will become ;0
   switch (ods_level)
   {
   // Files-11 ODS-1, ODS-2, or ODS-5
   case DVI$C_ACP_F11V1:
   case DVI$C_ACP_F11V2:
   case DVI$C_ACP_F11V5:
      if (sscanf(hold,"%d",&i) != 1) i = 0;
      if (i > 32767) i = 32767;
      if (i < -32767) i = -32767;
      if (sprintf(hold,";%d",i) <= 0) hold = ";0";
      return hold;
   }
}

// truncate to maximum lengths
char* fixLength(itmlst2 *name_parts, char* root, char* dir, char* name, 
   char* type, char* version, int ods_level)
{
   // notes: caller frees hold
   static char* hold;
   int namelen = (name == NULL) ? 0 : strlen(name);
   int typelen = (type == NULL) ? 0 : strlen(type);
   int total, len;

   // handle supported disk types
   switch (ods_level)
   {
   // Files-11 ODS-1 (like RSX)
   case DVI$C_ACP_F11V1:
      // 9.3
      if (namelen > 9) namelen = 9;
      if (typelen > 4) typelen = 4;    // includes .

      // no rooted directories
      total = name_parts[NODE].length + name_parts[DEVICE].length + 
      	    	strlen(dir) + namelen + typelen + strlen(version) + 1;
      hold = malloc(total);
      // since fixParts doesn't fix node and device names, they're not
      // null terminated strings
      strncpy(hold, name_parts[NODE].buffer, name_parts[NODE].length);
      hold[name_parts[NODE].length] = 0;
      strncat(hold, name_parts[DEVICE].buffer, name_parts[DEVICE].length);
      strcat(hold,dir);
      strncat(hold,name,namelen);
      strncat(hold,type,typelen);
      strcat(hold,version);
      if (strlen(hold) > NAM$C_MAXRSS) hold[NAM$C_MAXRSS] = 0;
      return hold;

   // Files-11 ODS-2
   case DVI$C_ACP_F11V2:
   #ifdef __vax
      case DVI$C_ACP_F11V5:   	 // must handle like ODS-2
   #endif
      // 49.49
      if (namelen > 49) namelen = 49;
      if (typelen > 50) typelen = 50;    // includes .

      total = name_parts[NODE].length + name_parts[DEVICE].length + 
      	    	strlen(root) + strlen(dir) + namelen + typelen + 
      	    	strlen(version) + 1;
      if (total > (NAM$C_MAXRSS + 1)) total = NAM$C_MAXRSS + 1;
      hold = malloc(total);
      // since fixParts doesn't fix node and device names, they're not
      // null terminated strings
      strncpy(hold, name_parts[NODE].buffer, name_parts[NODE].length);
      hold[name_parts[NODE].length] = 0;
      strncat(hold, name_parts[DEVICE].buffer, name_parts[DEVICE].length);
      strcat(hold,root);
      strcat(hold,dir);
      len = strlen(hold);
      len += namelen;
      if (len > NAM$C_MAXRSS) namelen -= (len - NAM$C_MAXRSS);
      strncat(hold,name,namelen);
      len = strlen(hold);
      len += typelen;
      if (len > NAM$C_MAXRSS) typelen -= (len - NAM$C_MAXRSS);
      strncat(hold,type,typelen);
      strcat(hold,version);
      if (strlen(hold) > NAM$C_MAXRSS) hold[NAM$C_MAXRSS] = 0;
      return hold;

   #ifndef __vax
      // Files-11 ODS-5 
      case DVI$C_ACP_F11V5:
         total = name_parts[NODE].length + name_parts[DEVICE].length + 
      	    	    strlen(root) + strlen(dir) + namelen + 
      	    	    typelen + strlen(version) + 1;
         if (total > (MAXRSS + 1)) total = MAXRSS + 1;
         hold = malloc(total);
      	 // since fixParts doesn't fix node and device names, they're not
      	 // null terminated strings
      	 strncpy(hold, name_parts[NODE].buffer, name_parts[NODE].length);
      	 hold[name_parts[NODE].length] = 0;
      	 strncat(hold, name_parts[DEVICE].buffer, name_parts[DEVICE].length);
         strcat(hold, root);
         strcat(hold, dir);
         strcat(hold, name);
         strcat(hold, type);
         strcat(hold, version);
      	 if (strlen(hold) > NAML$C_MAXRSS) hold[NAML$C_MAXRSS] = 0;
         return hold;
      #endif
   }
}

// fix each part of a file spec
char* fixParts(itmlst2* name_parts, int ods_level)
{
   // notes:
   // 1. if we got here, we don't have a node
   // 2. caller frees hold

   static char* hold;
   char* root;

   // handling for network or unrecognized device types
   switch (ods_level)
   {
   // Files-11 ODS-1, ODS-2, or ODS-5 
   case DVI$C_ACP_F11V1:
   case DVI$C_ACP_F11V2:
   case DVI$C_ACP_F11V5:
      // there is no fix for device names

      // fix the rooted directory
      root = fixDir(&(name_parts[ROOT]), ods_level);
      if (!strcmp(root,"[]"))
      {
      	 free(root);
      	 root = "";
      }

      // fix the directory
      char* dir = fixDir(&(name_parts[DIR]), ods_level);
      
      // fix the name
      char* name = fixName(&(name_parts[NAME]), ods_level, TRUE);
      
      // fix the type
      char* type = fixType(&(name_parts[TYPE]), ods_level);
      
      // fix the version
      char* version = fixVersion(&(name_parts[VERSION]), ods_level);
      
      // fix the length
      hold = fixLength(name_parts, root, dir, name, type, version, ods_level);

      free(root);
      free(dir);
      free(name);
      free(type);
      free(version);

      return hold;

   // Files-11 ODS-3 and ODS-4 are CDROM formats, assume
   // we're not writing to one of those since INITIALIZE can't
   // handle them (it can be done, but not so easily)

   // DECnet (Phase IV) or ISO/OSI network, could be anything
   // at the other end, quote so RMS won't parse and let the
   // remote system tell us how we're doing
   // Files-11 magtape structure is ANSI/ASCII magtape labeling,
   // which can handle almost anything, again don't let RMS parse
   case DVI$C_ACP_NET:
   case DVI$C_ACP_MTA:
      return quoted_name(name_parts);

   // not file structured, just keep the device
   case 0:
      hold = malloc(name_parts[DEVICE].length + 1);
      if (hold == NULL) fatal("memory allocation");
      strncpy(hold, name_parts[DEVICE].buffer, name_parts[DEVICE].length);
      hold[name_parts[DEVICE].length] = 0;
      return hold;

   // something I haven't planned on
   default:
      fprintf(stderr,
      	 "YDecoder cannot process output files to that type of device\n");
      exit(0);
   }
}

// check assumptions (the DEC C optimizer is smart enough
// not to even bother calling this routnie when the
// assumptions are true)
#define ASSUME(x) assume(x,__LINE__)
void assume(int x, int line)
{
   if (!x) 
   {
      fprintf(stderr,"assumption failed at line %d\n",line);
      fatal("");
   }
}

// fix a given string to be a valid VMS file spec based
// on the capabilities of the device it's going to
char* fixVMS(char* fileName)
{
   int status, ods_level;

   struct
   {
      itmlst2 part[VERSION + 1];
      int mbz;
   } name_parts, parse_parts;

   struct
   {
      itmlst3 level;
      int mbz;
   } get_level;

   typedef struct
   {
      unsigned status;
      unsigned unused;
   } Iosb;

   Iosb iosb;

   struct FAB file_fab;
   struct NAMTYPE file_nam;

   struct dsc$descriptor asis_desc;
   asis_desc.dsc$b_class = DSC$K_CLASS_S;
   asis_desc.dsc$b_dtype = DSC$K_DTYPE_T;
   asis_desc.dsc$w_length = strlen(fileName);
   asis_desc.dsc$a_pointer = fileName;

   name_parts.part[NODE].code = FSCN$_NODE;
   name_parts.part[DEVICE].code = FSCN$_DEVICE;
   name_parts.part[ROOT].code = FSCN$_ROOT;
   name_parts.part[DIR].code = FSCN$_DIRECTORY;
   name_parts.part[NAME].code = FSCN$_NAME;
   name_parts.part[TYPE].code = FSCN$_TYPE;
   name_parts.part[VERSION].code = FSCN$_VERSION;
   name_parts.mbz = 0;

   // need a device name to determine the ODS level, usually won't 
   // be one in the fileName, if not then use the currect device

   // parse for a device name
   status = sys$filescan(&asis_desc,&name_parts,0,0,0);
   if (!$VMS_STATUS_SUCCESS(status)) lib$signal(status);

   // if there is only a name, only a node, or nothing $filescan
   // can recognize then take everything except the node as a name
   // to be fixed
   int totalFixUp = FALSE;
   if ((name_parts.part[DEVICE].length + name_parts.part[ROOT].length + 
        name_parts.part[DIR].length + name_parts.part[TYPE].length + 
        name_parts.part[VERSION].length) == 0)
   {
      name_parts.part[NAME].buffer = fileName + name_parts.part[NODE].length;
      name_parts.part[NAME].length = 
      	 strlen(fileName) - name_parts.part[NODE].length;
      totalFixUp = TRUE;
   }
      
   // if there is a node name we can't assume we know anything about
   // the remote file name (you can get DECnet for almost any system), 
   // but we can make sure it's in quotes so that RMS won't try to parse it
   if (name_parts.part[NODE].length != 0)
      return quoted_name(name_parts.part);

   // default to sys$disk:[]
   file_fab = cc$rms_fab;
   char* const ifNone = "sys$disk:[]";
   file_fab.fab$l_dna = ifNone;
   file_fab.fab$b_dns = strlen(ifNone);
   file_fab.FAB_NAM = &file_nam;
   file_fab.fab$l_fop = FAB$M_OFP;
   
   // if there is a device name, that starts the name string 
   // (and it will have to be valid), pick up any directory name, too
   // as it will most likely be different
   parse_parts = name_parts;
   if (parse_parts.part[DEVICE].length != 0)
   {
      file_fab.fab$l_fna = parse_parts.part[DEVICE].buffer;
      file_fab.fab$b_fns = parse_parts.part[DEVICE].length +
      	 parse_parts.part[DIR].length;
   }
   else  // use the the default name string
   {
      file_fab.fab$l_fna = file_fab.fab$l_dna;
      file_fab.fab$b_fns = file_fab.fab$b_dns;
   }

   char full_name[MAXRSS + 1];
   struct dsc$descriptor name_desc;
   name_desc.dsc$b_class = DSC$K_CLASS_S;
   name_desc.dsc$b_dtype = DSC$K_DTYPE_T;
   name_desc.dsc$w_length = MAXRSS;
   name_desc.dsc$a_pointer = full_name;

   file_nam = DECC_NAM;
   file_nam.EXPAND_A = full_name;
   file_nam.EXPAND_ALLOC = MAXRSS;

   // parse the given and default name to get a name that
   // WILL have a device name
   for (int i = 0; i < 3; i++)
   {
      // increasingly restrictive order
      int level[] = {DVI$C_ACP_F11V5, DVI$C_ACP_F11V2, DVI$C_ACP_F11V1};

      status = sys$parse(&file_fab, 0, 0);
      switch (lib$match_cond(&status, &RMS$_NORMAL, &RMS$_DNF, &RMS$_SYN))
      {
      // an error we can't deal with
      case 0:
      	 lib$signal(status,file_fab.fab$l_stv);

      // success
      case 1:
      	 goto parseOK;

      // invalid directory, try fixing the directory name
      // IFF one was supplied
      case 2:
      case 3:
      	 if ((parse_parts.part[DEVICE].length != 0) &&
      	     (parse_parts.part[DIR].length != 0))
      	 {
      	    char* hold = fixDir(&name_parts.part[DIR], level[i]);
      	    int len = parse_parts.part[DEVICE].length +	strlen(hold);    
      	    file_fab.fab$l_fna = malloc(len + 1);

      	    strncpy(file_fab.fab$l_fna, parse_parts.part[DEVICE].buffer,
      	    	  parse_parts.part[DEVICE].length);
      	    ((char*) file_fab.fab$l_fna)[parse_parts.part[DEVICE].length] = 0;
      	    strcat(file_fab.fab$l_fna, hold);
      	    free(hold);
      	    file_fab.fab$b_fns = len;
      	 }
      	 else
      	    break;
      }
   }

   // if we fell out of the loop, we can't fix it
   lib$signal(status,file_fab.fab$l_stv);

parseOK:
   free(file_fab.fab$l_fna);

   get_level.level.length = sizeof ods_level;
   get_level.level.code = DVI$_ACPTYPE;
   get_level.level.buffer = &ods_level;
   get_level.level.retlenadr = NULL;
   get_level.mbz = 0;

   // end string after device name
   name_desc.dsc$w_length = file_nam.DEV_LEN;

   // get the device type
   status = sys$getdviw(0,0,&name_desc,(itmlst3 *) &get_level,&iosb,0,0,0L);
   if (!$VMS_STATUS_SUCCESS(status)) exit(status);
   if (!$VMS_STATUS_SUCCESS(iosb.status)) exit(iosb.status);

   // now that we know the structure level, we can fix up the name,
   // first need to compensate: $filescan will ignore stuff that isn't
   // valid, so fix up the parts (but we know there's no node)
   int total = 0;
   int endAt = VERSION + 1;

   for (int i = DEVICE, j = i + 1; (i < endAt) && (j < endAt); i++)
   {
      // if the address is 0, then the length is correctly 0
      if (name_parts.part[i].buffer)
      {
         int realLen;
         if (i < VERSION)
         {
      	    for (j = i + 1; !name_parts.part[j].buffer && (j < endAt); j++);
      	    if (j < endAt)
      	    {
      	       realLen = (int) ((char*) name_parts.part[j].buffer - 
                             	(char*) name_parts.part[i].buffer);
               name_parts.part[i].length = realLen;
      	       total += realLen;
      	    }
         }

      	 if ((i == VERSION) || (j > VERSION))
      	 {
            realLen = strlen(fileName) - total;
            name_parts.part[i].length = realLen;
         }
      }
   }

   // now handle each part
   return fixParts(name_parts.part, ods_level);
}

// when $parse is done on a quoted file name an erroneous directory will
// be added, and an empty name, type, and version (punctuation only) will 
// be appended, the good parts will be located as device and name
void refix_quoted(struct NAMTYPE* quoted_nam)
{

   // the good parts will be smaller than ESS
   int total = quoted_nam->DEV_LEN + quoted_nam->NAME_LEN + 1;

   char* hold = malloc(total);
   if (hold == NULL) fatal("memory allocation");

   // copy the device
   strncpy(hold, quoted_nam->DEV_A, quoted_nam->DEV_LEN);
   hold[quoted_nam->DEV_LEN] = 0;

   // copy the quoted name
   strncat(hold, quoted_nam->NAME_A, quoted_nam->NAME_LEN);

   // refill the esa
   strcpy(quoted_nam->EXPAND_A, hold);
   quoted_nam->EXPAND_LEN = total - 1;

   free(hold);
}

// decode a character
static int decodeChar(int character, char special)
{
    int result;
    if (special)
      character = character-64;

    result = character-42;

    if (result<0)
      result += 256;

    return result;
}

/**
 * This function does all of the decoding work.
 *
 * args:
 * file   takes a file to read from
 * folder destination file
 *        File will be created based on the name provided by the header,
 *    	  unless folder is provided (which can actually be a full file
 *    	  specification). If there is an error in the header and the name
 *        can not be obtained, "Unknown.blob" is used.
 */
static void decode(FILE* file, char* folder)
{
  /* Get initial parameters */
   #define MAXLEN 132	// is supposed to be 128 characters
   char line[MAXLEN];

   do
   {
      fgets(line, MAXLEN, file);
      if (ferror(file) && !feof(file)) fatal("file read");
   }
   while (!feof(file) && strncmp("=ybegin",line,7));

   if (feof(file)) return;

   int lineLen = strlen(line);
   if (line[lineLen - 1] == '\n') line[lineLen - 1] = 0;

   // get the output file name
   char* fileName = parseForName(line, "name");

   fileName = fixVMS(fileName);

   if (fileName == NULL)
      fileName = "Unknown.blob";

   // get the input line length
   char* length = parseForName(line, "line");
   int maxLen;
   if (sscanf(length,"%d",&maxLen) != 1) maxLen = MAXLEN;

   maxLen += 2;  // allow for leading .. problem from some news readers
   char* inLine = malloc(maxLen);
   if (inLine == NULL) fatal("memory allocation");

   // folder specified on command line?
   char full_name[MAXRSS + 1];
   if (folder != NULL)
   {
      // merge the filename with the folder name, folder overrides filename
      // so parse with filename as DNS and folder as FNS
      struct FAB file_fab = cc$rms_fab;
      struct NAMTYPE file_nam = DECC_NAM;

      file_fab.fab$l_dna = fileName;
      file_fab.fab$b_dns = strlen(fileName);
      file_fab.fab$l_fna = folder;
      file_fab.fab$b_fns = strlen(folder);
      file_fab.FAB_NAM = &file_nam;
      file_fab.fab$l_fop = FAB$M_OFP;

      file_nam.EXPAND_A = full_name;
      file_nam.EXPAND_ALLOC = MAXRSS;

      int status = sys$parse(&file_fab, 0, 0);
      if (!$VMS_STATUS_SUCCESS(status)) lib$signal(status,file_fab.fab$l_stv);

      full_name[file_nam.EXPAND_LEN] = 0;

      // $parse will do strange things to a quoted string name
      if (file_nam.QUOTED_FLAG) refix_quoted(&file_nam);

      // free on unallocated heap is a nop, so OK
      free(fileName);
      fileName = full_name;
   }
   
   FILE* fileOut;
   char* partNo = parseForName(line, "part");
   int part = 0;

   /* Handle Multi-part */
   if (partNo != NULL)
      if (sscanf(partNo,"%d",&part) != 1)
      {
         fprintf(stderr,"can't parse part number, will handle as new file\n");
         partNo = NULL;
      }
      else
      	 printf("unpacking part %d\n",part);

   if (partNo != NULL) {


      // try to open for adding parts, if that fails then open
      // as a new file
      fileOut = fopen(fileName, "r+");
      if (fileOut == NULL) fileOut = fopen(fileName, "w+");
      if (fileOut == NULL) fatal(fileName);

      while (!feof(file) && strncmp("=ypart",line,6)) 
      {
         fgets(line, MAXLEN, file);
      	 if (ferror(file) && !feof(file)) fatal("file read");
      }
      if (feof(file)) return;

      lineLen = strlen(line);
      if (line[lineLen - 1] == '\n') line[lineLen - 1] = 0;

      /* Get part-related parameters */
      long begin;
      char *beg = parseForName(line, "begin");
      if (sscanf(beg,"%d",&begin) != 1) begin = 1;
      begin--;

      struct stat stat_buf;
      stat(fileName, &stat_buf);
      
      fseek(fileOut, begin, SEEK_SET);
  } else {

      // no parts, or part 1: open as a new file
      fileOut = fopen(fileName, "w");
      if (fileOut == NULL) fatal(fileName);
  }

  /* Decode the file */
  int character;
  char special = FALSE;

  fgets(inLine, maxLen, file);
  if (ferror(file) && !feof(file)) fatal("file read");

  lineLen = strlen(inLine);
  if (inLine[lineLen - 1] == '\n') inLine[lineLen - 1] = 0;

  while (!feof(file) && strncmp("=yend",inLine,5))
  {
      for (int lcv=0; lcv < strlen(inLine); lcv++)
      {
      	// watch for leading .. problem from some news readers
      	if ((lcv == 1) && (character == '.') && (inLine[lcv] == '.') && fixDot)
      	    lcv++;

        character = inLine[lcv];
        if (character != 61) 
      	{
            character = decodeChar(character, special);
      	    putc(character,fileOut);
            special = FALSE;
        } else
            special = TRUE;
      }
      fgets(inLine, maxLen, file);
      if (ferror(file) && !feof(file)) fatal("file read");
      lineLen = strlen(inLine);
      if (inLine[lineLen - 1] == '\n') inLine[lineLen - 1] = 0;
  }
  fclose(fileOut);

  free(inLine);
  free(fileName);
}

/**
 * Provides a way to find out which version this decoding engine is up to.
 *
 */
static int getVersionNumber()
{
    return 2;
}

/**
 * To Run:
 *  ydecoder FileToDecode [DestinationFolder]
 *
 * argv   Command line argument(s)
 *    	  [-nofix]    : don't fix .. at begining of line (known browser bug)
 *     	  fileIn      : input Yenc file
 *     	  [folderOut] : output file path, overrides part or all of name
 *    	    	     	encoded inside file
 */
void main (char argc, char* argv[])
{
   char* infile = NULL, * folder = NULL;

   fprintf(stderr,"Decoder for YEnc.org project.  Version %d\n",
      getVersionNumber());

    if (argc < 2) 
    {
        // print usage and exit
        fprintf(stderr,"Usage: ydecoder [-nofix] fileIn [folderOut]\n");
      	exit(1);
    }

   // parse the options
   int c = getopt(argc, argv, "n:");
   if (c  != -1)
   {
      if (!strcmp(optarg,"ofix")) fixDot = FALSE;
      else 
      {
         fprintf(stderr,"Usage: ydecoder [-nofix] fileIn [folderOut]\n");
         exit(0);
      }
   }
   infile = argv[optind];
   if (argc > optind) folder = argv[optind + 1];

   if (infile == NULL)
   {
      fprintf(stderr,"Usage: ydecoder [-nofix] fileIn [folderOut]\n");
      exit(0);
   }

   // default to .yenc
   static char* const defType = ".yenc";
   struct FAB file_fab = cc$rms_fab;
   struct NAMTYPE file_nam = DECC_NAM;
   
   file_fab.fab$l_fna = infile;
   file_fab.fab$b_fns = strlen(infile);
   file_fab.fab$l_dna = defType;
   file_fab.fab$b_dns = strlen(defType);
   file_fab.FAB_NAM = &file_nam;
   file_fab.fab$l_fop = FAB$M_OFP;
   
   char full_name[MAXRSS + 1];
   file_nam.EXPAND_A = full_name;
   file_nam.EXPAND_ALLOC = MAXRSS;
   
   int status = sys$parse(&file_fab, 0, 0);
   if (!$VMS_STATUS_SUCCESS(status)) lib$signal(status,file_fab.fab$l_stv);
   
   full_name[file_nam.EXPAND_LEN] = 0;
   
   FILE* file = fopen(full_name,"r");
   if (file == NULL) fatal(argv[1]);
   
   decode(file, folder);
}
