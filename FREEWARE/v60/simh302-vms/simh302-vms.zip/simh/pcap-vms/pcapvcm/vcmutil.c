//***************************************************************************
//*                                                                         *
//*  � Copyright 2003 Hewlett-Packard Development Company, L.P.             *
//*								            *
//*  Confidential computer software.  Valid license from HP and/or          *
//*  its subsidiaries required for possession, use, or copying.             *
//*                                                                         *
//*  Consistent with FAR 12.211 and 12.212, Commercial Computer Software,   *
//*  Computer Software Documentation, and Technical Data for Commercial     *
//*  Items are licensed to the U.S. Government under vendor's standard      *
//*  commercial license.                                                    *
//*                                                                         *
//*  Neither HP nor any of its subsidiaries shall be liable for technical   *
//*  or editorial errors or omissions contained herein.  The information    *
//*  in this document is provided "as is" without warranty of any kind and  *
//*  is subject to change without notice.  The warranties for HP products   *
//*  are set forth in the express limited warranty statements accompanying  *
//*  such products.  Nothing herein should be construed as constituting an  *
//*  additional warranty.                                                   *
//*                                                                         *
//***************************************************************************
//
//
// FACILITY:
//
//      Dynamic Loadable Execlet for PCAP
//
//
// ABSTRACT:
//
//	This module contains helper routines for the PCAP VCM.
//
// AUTHOR:
//
//	Ankan
//
//  CREATION DATE:  21-Mar-2003
//
//  DESIGN ISSUES:
//
//      {@tbs@}
//
// REVISION HISTORY:
//
//      X-1     Ankan			Anders Ahgren		21-Mar-2003
//              Initial version.
//
#include <string.h>
#include <stdlib.h>
#include "pcapvcm.h"

void add_lil_item(LILDEF *lil, int len, int tag, char *value)
{
    LILITEM *lilitm;

    lilitm = (LILITEM *)lil->lil$a_listadr + lil->lil$l_listlen;
    lilitm->len = len + 4;  // Includes len and tag!
    lilitm->tag = tag;
    memcpy((char *)&lilitm->val, value, len);
    lil->lil$l_listlen = len + 4; // 4 is len+tag
}

void add_lil_addr_value(LILDEF *lil, int len, int tag, char *value)
{
    LILITEM *lilitm;
    char **foo;
    char *tmp;

    lilitm = (LILITEM *) lil->lil$a_listadr + lil->lil$l_listlen;
    lilitm->len = len + 4; // Includes len and tag!
    lilitm->tag = tag;
    foo = (char **) &lilitm->val;
    *foo = (char *) &lilitm->val + sizeof(char *);
    tmp = *foo;
    memcpy(tmp, value, len);
    lil->lil$l_listlen = len + 4 + sizeof(char *); // 4 is len+tag
}

/* 
** Ethernet device setup helper routines
*/
char *add_int_value(char *buf, short code, int value)
{
    char *tmpptr = buf;
    short *sptr;
    int *iptr;

    sptr = (short *)tmpptr;
    *sptr = (short) code;
    tmpptr += 2;
    iptr = (int *) tmpptr;
    *iptr = 0;
    *iptr = (int) value;
    tmpptr += 4;
    return tmpptr;
}


char *add_counted_value(char *buf, short code, short len, char *value)
{
    char *tmpptr = buf;
    short *sptr;
    
    sptr = (short *)tmpptr;
    *sptr = (short) code;
    tmpptr += 2;
    sptr = (short *) tmpptr;
    *sptr = (short) len;
    tmpptr += 2;
    memcpy(tmpptr,value,len);
    tmpptr += len;
    return tmpptr;
}


int find_value(int buflen, char *buf, short code, char *retbuf)
{
    int i = 0;
    int item;
    char *tmpbuf = buf;
    int value;
    int status = 0;

    while (i < buflen) {
	item = (tmpbuf[i] + (tmpbuf[i+1]<<8));
	if (0x1000 & item) {
	    if ((item & 0xFFF) == code) {
		memcpy(retbuf, &tmpbuf[i+4],6);
		status = 1;
		break;
	    }
	    i += (tmpbuf[i+2] + (tmpbuf[i+3]<<8)) + 4;
	} else {
	    // A value, ours?
	    if ((item & 0xFFF) == code) {
		// Yep, return it
		memcpy(retbuf, &tmpbuf[i+2], 4);
		status = 1;
		break;
	    }
	    i += 6;
	}
    }
    return status;
}


