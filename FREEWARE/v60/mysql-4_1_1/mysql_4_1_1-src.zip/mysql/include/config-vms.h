/* Copyright (C) 2000 MySQL AB

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

/* Defines for OpenVMS to make it compatible for MySQL */
#ifndef __config_vms
#define __config_vms

#ifdef __cplusplus
extern "C" {
#endif

// Large file support
#define _LARGFILE 1

#include <builtins.h>
//#include <ints.h>
#include <pthread.h>
#include <math.h>			/* Because of rint() */
#include <fcntl.h>
#include <iodef.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <in.h>
#include <inet.h>
#include <signal.h>
#include <unixlib.h>

#define SYSTEM_TYPE	"OpenVMS"
#define INVALID_SOCKET -1

#define MACHINE_TYPE	"alpha"		/* Define to machine type name */

// What we have on VMS
//#define HAVE_ALLOCA 1
#define HAVE_BOOL 1
#define HAVE_GLIBC2_STYLE_GETHOSTBYNAME_R 1
#define HAVE_INT_8_16_32 1
#define HAVE_INNOBASE_DB 1
#define HAVE_ISAM 1
#define HAVE_LSTAT 1
#define HAVE_POSIX_SIGNALS 1
#define HAVE_READDIR_R 1
#define HAVE_QUERY_CACHE 1
#define HAVE_TZNAME 1                        
#define HAVE_UCHAR 1
#define HAVE_UINT 1
#define HAVE_VIO 1
#define HAVE_ALARM 1
#define HAVE_ARPA_INET_H 1
#define HAVE_BCMP 1
#define HAVE_BITYPES_H 1
#define HAVE_BZERO 1
#define HAVE_CURSES_H 1
#define HAVE_CUSERID 1
#define HAVE_DIRENT_H 1
#define HAVE_DLERROR 1
#define HAVE_DLOPEN 1
#define HAVE_FCNTL 1
#define HAVE_FCNTL_H 1
#define HAVE_FINITE 1
#define HAVE_FLOAT_H 1
#define HAVE_FSEEKO 1
#define HAVE_FTRUNCATE 1
#define HAVE_GETCWD 1
#define HAVE_GETPAGESIZE 1
#define HAVE_GETPWNAM 1
#define HAVE_GETPWUID 1
#define HAVE_INDEX 1
#define HAVE_INTTYPES_H 1
#define HAVE_ISNAN 1
#define HAVE_LIMITS_H 1
#define HAVE_LOCALE_H 1
#define HAVE_LOCALTIME_R 1
#define HAVE_LONGJMP 1
#define HAVE_LRAND48 1
#define HAVE_LSTAT 1
#define HAVE_MEMCPY 1
#define HAVE_MEMMOVE 1
#define HAVE_MEMORY_H 1
#define HAVE_MKSTEMP 1
#define HAVE_MMAP 1
#define HAVE_NETINET_IN_H 1
#define HAVE_PERROR 1
//#define HAVE_PTHREAD_ATTR_SETSCOPE 1
#define HAVE_PTHREAD_YIELD_ZERO_ARG 1
#define HAVE_PTHREAD_ATTR_SETSCHEDPARAM 1
#define HAVE_PTHREAD_ATTR_SETSTACKSIZE 1
#define HAVE_PTHREAD_ATTR_GETSTACKSIZE 1
#define HAVE_PTHREAD_CONDATTR_CREATE 1
#define HAVE_PTHREAD_GETSEQUENCE_NP 1
#define HAVE_PTHREAD_RWLOCK_RDLOCK 1
#define HAVE_PTHREAD_SETSCHEDPARAM 1
#define HAVE_RWLOCK_INIT 1
#define HAVE_PUTENV 1
#define HAVE_PWD_H 1
//#define HAVE_READLINK 1
#define HAVE_RENAME 1
#define HAVE_RESTARTABLE_SYSCALLS 1
#define HAVE_RINT 1
#define HAVE_SELECT 1
#define HAVE_SETENV 1
#define HAVE_SETLOCALE 1
#define HAVE_SOCKET 1
#define HAVE_STDARG_H 1
#define HAVE_STDDEF_H 1
#define HAVE_STDLIB_H 1
#define HAVE_STRCASECMP 1
#define HAVE_STRCOLL 1
#define HAVE_STRERROR 1
#define HAVE_STRINGS_H 1
#define HAVE_STRING_H 1
#define HAVE_STRNLEN 1
#define HAVE_STRPBRK 1
#define HAVE_STRSTR 1
#define HAVE_STRTOK_R 1
#define HAVE_STRTOL 1
#define HAVE_STRTOLL 1
#define HAVE_STRTOUL 1
#define HAVE_STRTOULL 1
#define HAVE_STRUCT_STAT_ST_RDEV 1
#define HAVE_ST_RDEV 1
#define HAVE_SYS_FILE_H 1
#define HAVE_SYS_IOCTL_H 1
#define HAVE_SYS_MMAN_H 1
#define HAVE_SYS_SOCKET_H 1
#define HAVE_SYS_STAT_H 1
#define HAVE_SYS_STREAM_H 1
#define HAVE_SYS_TIMEB_H 1
#define HAVE_SYS_TYPES_H 1
#define HAVE_SYS_WAIT_H 1
#define HAVE_TEMPNAM 1
#define HAVE_UNISTD_H 1
#define HAVE_UTIME_NULL 1
#define HAVE_VARARGS_H 1
#define HAVE_VPRINTF 1
#define HAVE_CLOSE_SERVER_SOCK 1
#define HAVE_GMTIME_R 1
// Define if you have SSL installed
//#define HAVE_OPENSSL 1
#define HAVE_COMPRESS 1
// End of what we have on VMS

// ints and stuff, VMS has most of them already defined
//#define HAVE_INT_8_16_32 1
//#define HAVE_LONG_LONG 1

#define ENABLED_LOCAL_INFILE 1
// Directory stuff
//#define FN_C_AFTER_DIR ']'
//#define FN_C_AFTER_DIR_2 '>'
//#define FN_C_BEFORE_DIR '['
//#define FN_C_BEFORE_DIR_2 '<'
//#define FN_C_DIR_SEP '.'
//#define FN_C_ROOT_DIR "[000000]"
//#define FN_C_PARENT_DIR "[-]"
/* File and lock constants */

// Command line reader for VMS
int my_vms_create_keyboard(void);
int my_vms_readline(int kbd, char *line, short line_len, char *prompt);

#define F_EXCLUSIVE	1		/* We have only exclusive locking */
#define F_TO_EOF	(INT_MAX32/2)	/* size for lock of all file */
#define F_OK		0		/* parameter to access() */

#define S_IROTH		S_IREAD		/* for my_lib */

#undef SAFE_MUTEX			/* Can't be used on windows */

#define LONGLONG_MIN	((__int64) 0x8000000000000000)
#define LONGLONG_MAX	((__int64) 0x7FFFFFFFFFFFFFFF)
#define LL(A)		((__int64) A)

/* Type information */

typedef unsigned short	ushort;
typedef unsigned int	uint;
typedef unsigned __int64 ulonglong;	/* Microsofts 64 bit types */
typedef __int64 longlong;
//typedef int sigset_t;
#define longlong_defined 1

#define Socket_defined
#define my_socket int
#define bool int
//#define SIGPIPE SIGINT
#define RETQSORTTYPE void
#define QSORT_TYPE_IS_VOID 1
//#define qsort vms_qsort
#define RETSIGTYPE void
#define SOCKET_SIZE_TYPE size_t
#define my_socket_defined
#define bool_defined
//#define byte_defined
#define HUGE_PTR
#define STDCALL 	    /* Used by libmysql.dll */
//#define isnan(X) _isnan(X)
//#define finite(X) _finite(X)

#define THREAD
#define VOID_SIGHANDLER
#define SIZEOF_CHAR		1
#define SIZEOF_LONG		4
#define SIZEOF_LONG_LONG	8
#define SIZEOF_OFF_T		8
//#define HAVE_BROKEN_NETINET_INCLUDES 1
// What we have on VMS
//#define HAVE_POSIX_SIGNALS 1
//#define HAVE_CLOSE_SERVER_SOCK 1
//#define HAVE_PTHREAD_ATTR_SETSCOPE 1
//#define HAVE_PTHREAD_ATTR_CREATE 1
//#define HAVE_PTHREAD_GETSEQUENCE_NP 1
//#define HAVE_PTHREAD_ATTR_SETSCHEDPARAM 1
//#define HAVE_PTHREAD_ATTR_SETSTACKSIZE 1
//#define HAVE_PTHREAD_CONDATTR_CREATE 1
//#define HAVE_PTHREAD_YIELD_ZERO_ARG 1
//#define HAVE_PTHREAD_RWLOCK_RDLOCK 1
//#define HAVE_PTHREAD_SETSCHEDPARAM 1
//#undef HAVE_PTHREAD_SETPRIO
//#undef HAVE_PTHREAD_SIGMASK
//#undef HAVE_PTHREAD_KILL
//#undef HAVE_PTHREAD_ATTR_SETPRIO
//#undef HAVE_READLINK 
#define pthread_kill(A,B) pthread_dummy(0)
#define pthread_sigmask(A,B,C) sigprocmask((A),(B),(C))
#define pthread_yield pthread_yield_np
//#define HAVE_RESTARTABLE_SYSCALLS 1
//#define HAVE_LOCALTIME_R 1
//#define HAVE_FCNTL 1
//#define HAVE_PUTENV 1
//#define HAVE_RENAME 1
//#define HAVE_SELECT 1
//#define HAVE_SETLOCALE 1
//#define HAVE_SIGHOLD 1
//#define HAVE_SOCKET 1
//#define HAVE_SIGSET 1
//#define HAVE_STDARG_H 1
//#define HAVE_STDDEF_H 1
//#define HAVE_STDLIB_H 1
//#define HAVE_STRCOLL 1
//#define HAVE_STRCASECMP 1
//#define HAVE_STRINGS_H 1
//#define HAVE_STRING_H 1
//#define HAVE_STRNLEN 1
//#define HAVE_STRPBRK 1
//#define HAVE_STRSTR 1
//#define HAVE_STRTOK_R 1
//#define HAVE_STRTOL 1
//#define HAVE_STRTOLL 1
//#define HAVE_STRTOUL 1
//#define HAVE_STRTOULL 1
//#define HAVE_SYS_FILE_H 1
//#define HAVE_SYS_IOCTL_H 1
//#define HAVE_TEMPNAM 1
//#define HAVE_SYS_TYPES_H 1
//#define HAVE_SYS_TIMEB_H 1
//#define HAVE_SYS_STAT_H 1
//#define HAVE_UNISTD_H 1
//#define HAVE_UTIME_H 1
//#define HAVE_VARARGS_H 1
//#define HAVE_DIRENT_H 1

#define PACKAGE "mysql"
/* Define to the full name and version of this package. */
#define PACKAGE_STRING ""

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME ""

/* Define to the version of this package. */
#define PACKAGE_VERSION ""

/* Define as the return type of signal handlers (`int' or `void'). */
#define RETSIGTYPE void

/* The size of a `char', as computed by sizeof. */
#define SIZEOF_CHAR 1

/* The size of a `char*', as computed by sizeof. */
#define SIZEOF_CHARP 4

/* The size of a `int', as computed by sizeof. */
#define SIZEOF_INT 4

/* The size of a `long', as computed by sizeof. */
#define SIZEOF_LONG 4

/* The size of a `long long', as computed by sizeof. */
#define SIZEOF_LONG_LONG 8

/* Define to 1 if the `S_IS*' macros in <sys/stat.h> do not work properly. */
/* #undef STAT_MACROS_BROKEN */

/* Define to 1 if you have the ANSI C header files. */
#define STDC_HEADERS 1

/* Define to 1 if you can safely include both <sys/time.h> and <time.h>. */
#define TIME_WITH_SYS_TIME 1

/* Define to 1 if your <sys/time.h> declares `struct tm'. */
/* #undef TM_IN_SYS_TIME */

/* Version number of package */
#define VERSION "4.1.1-alpha"

/* Define to 1 if your processor stores words with the most significant byte
   first (like Motorola and SPARC, unlike Intel and VAX). */
/* #undef WORDS_BIGENDIAN */

/* Number of bits in a file offset, on hosts where this is settable. */
#define _FILE_OFFSET_BITS 64

/* Define to make fseeko etc. visible, on some hosts. */
/* #undef _LARGEFILE_SOURCE */

/* Define for large files, on AIX-style hosts. */
/* #undef _LARGE_FILES */

/* Define to empty if `const' does not conform to ANSI C. */
/* #undef const */

/* Define as `__inline' if that's what the C compiler calls it, or to nothing
   if it is not supported. */
/* #undef inline */

/* Define to `long' if <sys/types.h> does not define. */
/* #undef off_t */

/* Define to `unsigned' if <sys/types.h> does not define. */
/* #undef size_t */

// What we don't have
//#undef HAVE_SIGWAIT 
//#undef HAVE_GETRUSAGE
//#undef HAVE_POLL
//#undef HAVE_REALPATH
//#undef HAVE_OPENSSL
//#undef HAVE_SELECT_H
//#undef HAVE_SYS_SELECT_H
//#undef HAVE_SYS_UN_H
//#undef HAVE_SNPRINTF
//#undef HAVE_BERKELEY_DB
//#undef HAVE_CRYPT
//#undef HAVE_CRYPT_H
//#undef HAVE_ATOMIC_ADD


/* Use all character sets in MySQL */
#define USE_MB 1
#define USE_MB_IDENT 1
#define USE_STRCOLL 1

/* Convert some simple functions to Posix */
#define _POSIX_PATH_MAX         255

//#define sigset(A,B) signal((A),(B))
//#define finite(A) _finite(A)
//#define sleep(A)  Sleep((A)*1000)

#if defined(__cplusplus)

inline double rint(double nr)
{
  double f = floor(nr);
  double c = ceil(nr);
  return (((c-nr) >= (nr-f)) ? f :c);
}

#ifdef _alpha
#define ulonglong2double(A) ((double) (A))
#define my_off_t2double(A)  ((double) (A))

#else
inline double ulonglong2double(ulonglong value)
{
  longlong nr=(longlong) value;
  if (nr >= 0)
    return (double) nr;
  return (18446744073709551616.0 + (double) nr);
}
#define my_off_t2double(A) ulonglong2double(A)
#endif /* alpha */
#else
#define inline __inline
#endif /* __cplusplus */

#if SIZEOF_OFF_T > 4
//#define lseek(A,B,C) _lseeki64((A),(longlong) (B),(C))
//#define tell(A) _telli64(A)
#endif

#define STACK_DIRECTION -1

/* Optimized store functions for Alpha */

#define sint2korr(A)	(*((int16 *) (A)))
#define sint3korr(A)	((int32) ((((uchar) (A)[2]) & 128) ? \
				  (((uint32) 255L << 24) | \
				   (((uint32) (uchar) (A)[2]) << 16) |\
				   (((uint32) (uchar) (A)[1]) << 8) | \
				   ((uint32) (uchar) (A)[0])) : \
				  (((uint32) (uchar) (A)[2]) << 16) |\
				  (((uint32) (uchar) (A)[1]) << 8) | \
				  ((uint32) (uchar) (A)[0])))
#define sint4korr(A)	(*((long *) (A)))
#define uint2korr(A)	(*((uint16 *) (A)))
#define uint3korr(A)	(long) (*((unsigned long *) (A)) & 0xFFFFFF)
#define uint4korr(A)	(*((unsigned long *) (A)))
#define uint5korr(A)	((ulonglong)(((uint32) ((uchar) (A)[0])) +\
				    (((uint32) ((uchar) (A)[1])) << 8) +\
				    (((uint32) ((uchar) (A)[2])) << 16) +\
				    (((uint32) ((uchar) (A)[3])) << 24)) +\
				    (((ulonglong) ((uchar) (A)[4])) << 32))
#define uint8korr(A)	(*((ulonglong *) (A)))
#define sint8korr(A)	(*((longlong *) (A)))
#define int2store(T,A)	*((uint16*) (T))= (uint16) (A)
#define int3store(T,A)		{ *(T)=  (uchar) ((A));\
				  *(T+1)=(uchar) (((uint) (A) >> 8));\
				  *(T+2)=(uchar) (((A) >> 16)); }
#define int4store(T,A)	*((long *) (T))= (long) (A)
#define int5store(T,A)	{ *(T)= (uchar)((A));\
			  *((T)+1)=(uchar) (((A) >> 8));\
			  *((T)+2)=(uchar) (((A) >> 16));\
			  *((T)+3)=(uchar) (((A) >> 24)); \
			  *((T)+4)=(uchar) (((A) >> 32)); }
#define int8store(T,A)	*((ulonglong *) (T))= (ulonglong) (A)

#define doubleget(V,M)	{ *((long *) &V) = *((long*) M); \
			  *(((long *) &V)+1) = *(((long*) M)+1); }
#define doublestore(T,V) { *((long *) T) = *((long*) &V); \
			   *(((long *) T)+1) = *(((long*) &V)+1); }
#define float4get(V,M) { *((long *) &(V)) = *((long*) (M)); }
#define float8get(V,M) doubleget((V),(M))
#define float4store(V,M) memcpy((byte*) V,(byte*) (&M),sizeof(float))
#define float8store(V,M) doublestore((V),(M))


//#define HAVE_PERROR
//#define HAVE_VFPRINT
//#undef HAVE_CHSIZE		// VMS does not have chsize
//#define HAVE_CHSIZE		/* System has chsize() function */
//#define HAVE_RENAME		/* Have rename() as function */
//#define HAVE_BINARY_STREAMS	/* Have "b" flag in streams */
//#define HAVE_LONG_JMP		/* Have long jump function */
//#undef HAVE_LOCKING		/* have locking() call */
//#define HAVE_LOCKING		/* have locking() call */
//#define HAVE_ERRNO_AS_DEFINE	/* errno is a define */
//#define HAVE_STDLIB		/* everything is include in this file */
//#define HAVE_MEMCPY
//#define HAVE_MEMMOVE
//#define HAVE_GETCWD
//#undef HAVE_TELL
//#define HAVE_TELL
//#define HAVE_TZNAME
//#define HAVE_PUTENV
//#define HAVE_SELECT
//#define HAVE_SETLOCALE
//#define HAVE_SOCKET		/* Giangi */
//#define HAVE_FLOAT_H
//#define HAVE_LIMITS_H
//#define HAVE_STDDEF_H
//#define HAVE_RINT		/* defined in this file */
//#define NO_FCNTL_NONBLOCK	/* No FCNTL */
//#define HAVE_ALLOCA
//#define HAVE_STRPBRK
//#define HAVE_STRSTR

//#undef HAVE_COMPRESS
//#define HAVE_COMPRESS 1
//#undef HAVE_CREATESEMAPHORE
//#define HAVE_CREATESEMAPHORE
//#undef HAVE_ISNAN
//#define HAVE_ISNAN
//#undef HAVE_FINITE
//#define HAVE_ISAM		/* We want to have support for ISAM in 4.0 */
//#define HAVE_QUERY_CACHE
//#define SPRINTF_RETURNS_INT

//#ifdef NOT_USED
//#define HAVE_SNPRINTF		/* Gave link error */
//#define _snprintf snprintf
//#endif

//#define HAVE_LDIV		/* The optimizer breaks in zortech for ldiv */
//#define HAVE_ANSI_INCLUDE
//#define HAVE_SYS_UTIME_H
//#define HAVE_STRTOUL

#define my_reinterpret_cast(A) reinterpret_cast <A>
#define my_const_cast(A) const_cast<A>

/* MYSQL OPTIONS */

#ifdef _CUSTOMCONFIG_
#include <custom_conf.h>
#else
#define DEFAULT_MYSQL_HOME	"/mysql_root/mysql"
#define PACKAGE			"mysql"
#define DEFAULT_BASEDIR		"/mysql_root/"
#define SHAREDIR		"share"
#define DEFAULT_CHARSET_HOME	"/mysql_root/mysql/"
#define MYSQL_DEFAULT_CHARSET_NAME "latin1"
#define MYSQL_DEFAULT_COLLATION_NAME "latin1_swedish_ci"

#endif

/* File name handling */

//#define FN_LIBCHAR	']'
//#define FN_ROOTDIR	"[."
//#define FN_NETWORK_DRIVES	/* Uses \\ to indicate network drives */
#define FN_NO_CASE_SENCE 1	/* Files are not case-sensitive */
#define MY_NFILE	1024
#define thread_safe_add(V,C,L) \
	pthread_mutex_lock((L)); (V)+=(C); pthread_mutex_unlock((L));
#define thread_safe_sub(V,C,L) \
	pthread_mutex_lock((L)); (V)-=(C); pthread_mutex_unlock((L));
#define statistic_add(V,C,L)	 (V)+=(C)
#define statistic_increment(V,L) (V)+=1

#ifdef __cplusplus
}
#endif

#endif /* __config_vms */
