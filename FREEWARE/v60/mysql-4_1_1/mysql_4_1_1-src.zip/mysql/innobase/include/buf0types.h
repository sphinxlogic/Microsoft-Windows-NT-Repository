/******************************************************
The database buffer pool global types for the directory

(c) 1995 Innobase Oy

Created 11/17/1995 Heikki Tuuri
*******************************************************/

#ifndef buf0types_h
#define buf0types_h

typedef	struct buf_block_struct		buf_block_t;
typedef	struct buf_pool_struct		buf_pool_t;

/* The 'type' used of a buffer frame */
typedef	byte	buf_frame_t;


#endif

