FIXUP_IMAGE can edit the shareable image match control information in an
executable image file.  This can be used to avoid the dreaded:

%DCL-W-ACTIMAGE, error activating image VAXCRTL
-CLI-E-IMGNAME, image file DKA0:[SYS0.SYSCOMMON.][SYSLIB]VAXCRTL.EXE
-SYSTEM-F-SHRIDMISMAT, ident mismatch with shareable image

FIXUP_IMAGE does this by editing the match control information in the image
header to match a target SYS$LIBRARY.  By default, this is the SYS$LIBRARY of
the running system.

FIXUP_IMAGE will edit the match control information if it is "compatible" with
the dependent shareable image.  The match control information is "compatible"
between an image and a dependent shareable image if:

1) The match control value must exactly match.
2) The major version must exactly match.
3) The minor version in the dependent shareable image must be less than the
   minor version in image.

If all of these conditions are met, FIXUP_IMAGE will change the minor version in
the image to match the minor version in the dependent shareable image.


FIXUP_IMAGE can also trim references to unused shareable images.  Through a
quirk of the VAX/VMS linker, if image A is dependent on image B, and image B is
dependent on image C, image A will also be made dependent on image C.

This extra dependency is unnecessary.  It can also cause problems, particularly
when trying to run image A on a system where image C does not exist.

For example, this can occur when you try to run an image linked under VMS V6 or
later on a VMS V5 system:

%DCL-W-ACTIMAGE, error activating image CMA$TIS_SHR
-CLI-E-IMAGEFNF, image file not found DKA0:[SYS0.SYSCOMMON.][SYSLIB]CMA$TIS_SHR.EXE;

This happens because the VAXCRTL that comes with VMS V6 is dependent on
CMA$TIS_SHR.  The VAXCRTL that comes with VMS V5 is not dependent on
CMA$TIS_SHR.  (CMA$TIS_SHR does not normally exist on VMS V5.)  Any program
linked against VAXCRTL on VAX/VMS V6 or later will be made dependent on
CMA$TIS_SHR, even if it never calls CMA$TIS_SHR directly.  This will cause
the ACTIMAGE error listed above, preventing the program from executing on a
VMS V5 system.

FIXUP_IMAGE can analyze an image, identifying and removing these unnecessary
dependencies.  If the image is otherwise compatible with the target system, this
may allow the image to execute on the target system.

FIXUP_IMAGE identifies unnecessarily dependent images as:

1) The image must not be a based image.
2) The image must not be referenced by any fixup vectors.  (Fixup vectors are
   used to define the references between one image and another.)

In addition, since VMS V4.4, shareable images may have initialization code.  It
is possible for a shareable image with initialization code to affect the
execution of an image through side effects even if there are no direct calls
from the image to the shareable image.  For this reason, FIXUP_IMAGE can be told
not to trim shareable images that have initialization code.


FIXUP_IMAGE V2.0 only supports VAX executables.

The FIXUP_IMAGE.EXE file included with this kit has been fixed against
VAX/VMS V4.0.

--------------------------------------------------------------------------------
DISCLAIMERS

FIXUP_IMAGE is not a replacement for testing!

The shareable image match information is included in the image file to prevent
you from shooting yourself in the foot.  FIXUP_IMAGE removes this protection,
so watch your foot carefully!

Just because FIXUP_IMAGE can edit the image so it will execute on a particular
system doesn't mean that the image will work correctly.  Many images will work
correctly, but some won't.

If the image required one or more of the capabilities added in a later version
of a shareable image, running with an earlier version may cause problems.

--------------------------------------------------------------------------------
			! ! !   W A R N I N G   ! ! !

FIXUP_IMAGE edits the .EXE file.  The resulting file may be  different from
the file created by the linker.  CHECKSUM/IMAGE may report different checksums
for an executable after running FIXUP_IMAGE on it.

To ensure that your executable is not modified in an undesirable way (such as
a virus), it is strongly recommended that you read the source files for
FIXUP_IMAGE to ensure that no undesirable code has been added and build
your own copy of FIXUP_IMAGE.

			! ! !   W A R N I N G   ! ! !
--------------------------------------------------------------------------------
ENHANCEMENTS

Enhancements to FIXUP_IMAGE are welcome.  Please send any code updates for
enhancements (or requests) to FIXUP_IMAGE@applied-synergy.com.

Such enhancements/requests may be used or ignored, but any enhancments which
are used will be credited in the source.

One obvious enhancement is the addition of support for Alpha executables.
Trimming of shareable images does not seem to be necessary on the Alpha, but
editing the match control information would be useful.

--------------------------------------------------------------------------------
COPYRIGHT NOTICE

This software is COPYRIGHT �2001, Applied Synergy, Inc. ALL RIGHTS RESERVED.
Permission is granted for not-for-profit redistribution, provided all source
and object code remain unchanged from the original distribution, and that all
copyright notices remain intact.

DISCLAIMER

This software is provided "AS IS".  The author and Applied Synergy, Inc. make
no representations or warranties with respect to the software and specifically
disclaim any implied warranties of merchantability or fitness for any
particular purpose.
