	CDRECORD readme file for the Open Sources Tools CD

CDRECORD is a free software package, which was used to provide support for
writing Compact Disk media on OpenVMS.

The CDRECORD package is copyrighted by Jorg Schilling, and its use is
governed by GNU General Public License version 2.  A copy of this license
is named COPYING, and is included with the sources, as required.

The origin of the sources used on VMS is cdrtools-1.10 from the website:

 ftp://ftp.fokus.gmd.de/pub/unix/cdrecord/

The sources included on the cd are the sources used to build the 
CDRECORD executable shipped with OpenVMS V7.3-1.  Any include files that may
not be included are shipped with this version of OpenVMS.

Only the cdrecord portion of the package was used, and some minor
modifications to the package were made.  The modifications were primarily
in the scsi-vms.c module, in order to "map" the unix -dev=m,n,o 
specification into a vms "DQ" device.  The CDRECORD.COM procedure 
first does the reverse mapping of accepting a VMS "DQcu" device, and converting
it into a -dev=m,n,o CDRECORD.EXE switch.  The scsi-vms.c module parses the
-dev=m,n,o information, and converts it to the VMS "DQcu" device name
to be opened. 

The existing package build procedure was changed to be similar to the OpenVMS
build procedure.  See procedures BUILD_SETUP.COM, BUILD_ALL.COM, and 
BUILD_ALL_DEBUG.COM.

 
