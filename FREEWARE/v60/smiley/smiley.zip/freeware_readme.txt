Smiley server, Miscellaneous, Print and explain smileys :-)

Installation

To build the Smiley program just execute make_vms.com. Since the program 
only consists of very few source files no attempt at any sophistication 
has been made. If you do feel there is a need for options to the build 
procedure sent me a note and I shall look into it.

Environment variables

If the logical name "SMILEY" is defined a call to smiley with option -e (like 
explain) will try to find the definition of this Smiley.

The latest version of the OpenVMS port of the Smiley server should always be 
accessible via 

http://www.decus.de:8080/www/vms/sw/smiley.htmlx
