#ifndef LYCGI_H
#define LYCGI_H

#ifndef HTUTILS_H
#include <HTUtils.h>
#endif

extern void add_lynxcgi_environment PARAMS((CONST char *variable_name));

#endif /* LYGETFILE_H */
