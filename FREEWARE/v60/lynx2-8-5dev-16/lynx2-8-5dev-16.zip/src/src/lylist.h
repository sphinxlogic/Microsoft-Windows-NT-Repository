#ifndef LYLIST_H
#define LYLIST_H

#include <LYStructs.h>

extern int showlist PARAMS((DocInfo *newdoc, BOOLEAN titles));
extern void printlist PARAMS((FILE *fp, BOOLEAN titles));

#endif /* LYLIST_H */
