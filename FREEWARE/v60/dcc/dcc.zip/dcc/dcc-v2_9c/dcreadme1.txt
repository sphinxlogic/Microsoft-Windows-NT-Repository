/* DCREADME1.TXT */

File 'dcreadme.txt' is obtained from file 'dcreadme.pod' via program
'pod2Text.pl' (which underlines headlines). This program is to be used as follow:
	perl pod2Text.pl dcreadme.pod > dcreadme.txt

'dcreadme.pod' can also be translated to HTML via 'pod2html', to HLP via
'pod2hlp', to MAN, to PS, etc. All these utilities are in the 'perl' package
(Practical Extraction and Report Language, cf <patrick.m.ryan@gsfc.nasa.gov>).

You can consult the following site:

	http://nucwww.chem.sunysb.edu/info/dcc.htmlx

which provides (among other things) a message board for dcc.

/* End DCREADME1.TXT */
