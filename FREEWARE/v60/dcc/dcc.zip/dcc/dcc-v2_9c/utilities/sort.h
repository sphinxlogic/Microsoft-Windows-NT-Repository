#ifndef _SORT_H
#define _SORT_H

#include "bool.th"

typedef int SortStatus;
#define SORT_OK			(SortStatus)0
#define SORT_FILE_OPEN_FAIL 	(SortStatus)1
#define SORT_FILE_CLOSE_FAIL	SORT_FILE_OPEN_FAIL + 1
#define SORT_MEM_EXHAUST	SORT_FILE_CLOSE_FAIL + 1
#define SORT_OUTPUT_ERR		SORT_MEM_EXHAUST + 1

typedef enum {SORT_EMPTY_OPTION=0, SORT_BIG_LINE=1, SORT_NOOUTPUT=2,
              SORT_REV_ORDER=4, SORT_NO_DUPL=8, SORT_DISORDER=16} SortOption;

extern SortStatus sort(const char *inFileName, const char *outFileName,
								    SortOption);
#endif
