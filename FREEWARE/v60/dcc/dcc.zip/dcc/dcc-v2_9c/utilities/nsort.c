/*  nsort: portable 'sort'.
    Sends to stdout lines (of file(s)) sorted.

    Call: nsort [option(s)] [fileName(s)]

          If no file name given, input is taken from stdin.

          Possible options :
          -c  check if sorted; output only if not,
          -r  sort in descending order,
          -u  remove duplicate lines,
          -y  accept lines of any length (default is 256, '\0' included),
          -z  do not output open failure messages.

    Returns same exit status as sort.
*/

#include <stdlib.h>
#include <stdio.h>
#include "sort.h"

int main(int argc, const char *const argv[])
{
  const char *const *ptrArg;
  SortOption option = SORT_EMPTY_OPTION;
  bool outputErrMsg = True;
  SortStatus result = SORT_OK;

  for (ptrArg = &argv[0]; *++ptrArg!=NULL && **ptrArg == '-'; ) {
    argc--;
    if (*(*ptrArg + (2)) == '\0') switch (*(*ptrArg + 1)) {
      case 'c': option |= SORT_DISORDER; continue;
      case 'r': option |= SORT_REV_ORDER; continue;
      case 'u': option |= SORT_NO_DUPL; continue;
      case 'y': option |= SORT_BIG_LINE; continue;
      case 'z': outputErrMsg = False; continue;
      /*~NoDefault*/}
    fprintf(stderr, ">>>nsort: option '%s' unimplemented\n", *ptrArg + 1);}
  do {
    SortStatus status;

    status = sort(*ptrArg, NULL, (--argc > 1)? option | SORT_NOOUTPUT : option);
    if (status > 0) {
      result = status;
      if (outputErrMsg) {
        if (status == SORT_FILE_OPEN_FAIL) fprintf(stderr,
				">>>nsort: open failure on file %s\n", *ptrArg);
        else if (status == SORT_MEM_EXHAUST) fprintf(stderr,
						">>>nsort: memory exhausted\n");
        else if (status==SORT_OUTPUT_ERR || status==SORT_FILE_CLOSE_FAIL
			   ) fprintf(stderr, ">>>nsort: output file error\n");}}
    option &= ~SORT_DISORDER;
  } while (*ptrArg++!=NULL && *ptrArg!=NULL);
#ifdef VMS
  return (result == 0)? EXIT_SUCCESS : EXIT_FAILURE;
#else
  return result;
#endif
}
