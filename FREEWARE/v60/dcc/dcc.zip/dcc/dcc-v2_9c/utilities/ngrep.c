/*  ngrep: portable 'grep' (and more powerful too...: see '`&' below).
    Sends to stdout all lines (of a file) that matches a pattern.

    Use : ngrep [option(s)] pattern [fileName(s)]

          If no file name given, input is taken from stdin; if several file
          names are given, each file name is output (on stderr) before proces-
          sing it.

          See grep.c for a description of the pattern.

          Possible options :
          -s  silent mode (nothing is outputted, except possible error messa-
              ges),
          -v  output lines that do NOT match,
          -y  accept lines of any length (default is 256, '\0' included),
          -z  do not output open failure messages.

    Returns same exit status as grep; for VMS, returns informational status in
    case no match is found.
*/

#include <stdlib.h>
#include <stdio.h>
#include "grep.h"

#ifdef VMS
#define EXIT_INFO	0x10000003
#endif

int main(int argc, const char *const argv[])
{
  const char *const *ptrArg, *const *ptrPat;
  GrepOption option = GREP_EMPTY_OPTION;
  bool outputErrMsg = True;
  Status result = NOT_MATCHING;

  for (ptrArg = &argv[0]; *++ptrArg!=NULL && **ptrArg == '-'; ) {
    argc--;
    if (*(*ptrArg + (2)) == '\0') switch (*(*ptrArg + 1)) {
      case 's': option |= GREP_NO_OUTPUT; continue;
      case 'v': option |= GREP_OUTPUT_LINE_NM; continue;
      case 'y': option |= GREP_BIG_LINE; continue;
      case 'z': outputErrMsg = False; continue;
      /*~NoDefault*/}
    fprintf(stderr, ">>>ngrep: option '%s' unimplemented\n", *ptrArg + 1);}
  if (argc <= 1) {
    fputs(">>>ngrep: pattern missing\n", stderr);
    result = GREP_FILE_OPEN_FAIL + 1;}
  else {
    ptrPat = ptrArg++;
    do {
      Status status;

      if (argc>(3) && !(option & GREP_NO_OUTPUT)) fprintf(stderr, "%s:\n",
								       *ptrArg);
      status = grep(*ptrPat, NULL, *ptrArg, NULL, option);
      if (status > 0) {
        result = status;
        if (status == GREP_FILE_OPEN_FAIL) {
          if (outputErrMsg) fprintf(stderr,
			       ">>>ngrep: open failure on file %s\n", *ptrArg);}
        else if (status == GREP_MEM_EXHAUST) {
          if (outputErrMsg) fprintf(stderr, ">>>ngrep: memory exhausted\n");}
        else {
          fprintf(stderr, ">>>ngrep: bad pattern (error #%d)\n", status);
          break;}}
      else if (status!=NOT_MATCHING && result==NOT_MATCHING) result = MATCH;
    } while (*ptrArg++!=NULL && *ptrArg!=NULL);}
#ifdef VMS
  return (result < 0)? EXIT_SUCCESS
			   : (result == NOT_MATCHING)? EXIT_INFO : EXIT_FAILURE;
#else
  return (result <= 0)? result + 1 : (2);
#endif
}
