#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "sedp.h"

#define MAX_LINE_SIZE   256

static void print()
{
  typedef FILE *Stream;
  Stream in = fopen("bid.res", "r");
  char string[MAX_LINE_SIZE + 1];

  if (in != NULL) {
    while (fgets(string, MAX_LINE_SIZE + 1, in) != NULL) {
      size_t lgt = strlen(string);

      if (lgt>0 && string[lgt - 1]=='\n') string[lgt - 1] = '\0';
      printf("%s\n", string);}
    (void)fclose(in);}
}

int main ()
{
  Status status;
  char pattern[MAX_LINE_SIZE + 1];

  while (fputs("pattern? :", stdout), fgets(pattern, MAX_LINE_SIZE + 1, stdin)
					  !=NULL && strcmp(pattern, "`\n")!=0) {
    char string[MAX_LINE_SIZE + 1];
    size_t lgt = strlen(pattern);

    if (lgt>0 && pattern[lgt - 1]=='\n') pattern[lgt - 1] = '\0';
    while (fputs("Big Line? :", stdout), fgets(string, MAX_LINE_SIZE + 1, stdin)
					    !=NULL && strcmp(string, "\n")!=0) {
      lgt = strlen(string);
      if (lgt!=(2) || string[0]!='o' && string[0]!='n') continue;
      status = sedp(pattern, NULL, "tstsedp.dat", "bid.res", (string[0] ==
					  'o')? SEDP_BIG_LINE : SEDP_OUT_MATCH);
      if (status > 0)
        if (status == SEDP_FILE_OPEN_FAIL) printf("\nNo input file.\n");
        else printf("\nSyntax error #%d in pattern.\n", status);
      else {
        printf("\n%s\n", (status == MATCH)? "MATCH" : "NOT MATCHING");
        print();}}}
  {
    static const char *listS[] = {NULL, "P", "p", "f", "F"};

    status = sedp("`#1`{1`*`}`#4`{0`*`}`>`#3`{0 `#2`{1",
                  listS, "tstsedp.dat", "bid.res", SEDP_EMPTY_OPTION);
    if (status > 0)
      if (status == SEDP_FILE_OPEN_FAIL) printf("\nNo input file.\n");
      else printf("\nSyntax error #%d in pattern.\n", status);
    else {
      printf("\n%s\n", (status == MATCH)? "MATCH" : "NOT MATCHING");
      print();}}
  return EXIT_SUCCESS;
}
