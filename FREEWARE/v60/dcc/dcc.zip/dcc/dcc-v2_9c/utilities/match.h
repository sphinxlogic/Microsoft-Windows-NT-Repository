#ifndef _MATCH_H
#define _MATCH_H

#include <stddef.h>
#include "bool.th"

typedef int Status;
#define MATCH		(Status)(-1)
#define NOT_MATCHING	(Status)(0)
/* Error codes are supposed to be >0 (see coding) */
#define BAD_LBRA	(Status)(1)
#define BAD_RBRA	(Status)(2)
#define BAD_ESC		(Status)(3)
#define MSNG_RBRA	(Status)(4)
#define BAD_RSBR	(Status)(5)
#define MSNG_RSBR	(Status)(6)
#define LIST_TOO_LONG	(Status)(7)
#define BAD_INTERV	(Status)(8)
#define END_MATCH_ERRS	BAD_INTERV  /* for others functions' error codes */

typedef struct {
  const char *begAddr;
  size_t lgt;
} Zone;  /* description of a 'zone' (see description of match() in "match.c" */

extern char *catenate(const Zone zones[]);
extern Status match(const char *pattern, const char *const *paramPattern,
	const char*string, Zone *zones, bool syntaxCheck, const char **ptrStop);
#endif
