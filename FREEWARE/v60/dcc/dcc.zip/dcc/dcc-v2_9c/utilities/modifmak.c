/* modifMak.c modifies file 'makefile', so as to add the '!' needed in front of
   an 'include' directive for Borland's make (I thought Borland was a serious
   editor, but there exists disillusions...). */

#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include "basics.h"
#include "sedp.h"

#define MAKEFILE "makefile"
#define TMPFILE  "bid.tmp"

int main()
{
  Status result = sedp("`{1include`b`*`}`>!`{1"
                       "`|"
                       "`{0`*`}`b-o`b`{2`*`}`>`{0 -e`{2",
                       NULL, MAKEFILE, TMPFILE, SEDP_EMPTY_OPTION);

  if (result == SEDP_FILE_OPEN_FAIL) {
    printf(">>> File \"" MAKEFILE "\" can't be opened; quit\n");
    return EXIT_FAILURE;}
  if (result > 0) {printf(">>>modifmak: Problem"); return EXIT_FAILURE;}
  if (result == MATCH) copyAppend(TMPFILE, MAKEFILE, Txt, Copy);
  remove(TMPFILE);
  return EXIT_SUCCESS;
}
