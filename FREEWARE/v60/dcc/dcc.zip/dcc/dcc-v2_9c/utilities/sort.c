#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sort.h"

#define MAX_LINE_SIZ	255

typedef FILE *Stream;

typedef struct _linkedLine LinkedLine;
struct _linkedLine {
  LinkedLine *next;
  char line[1];  /* stub */};

SortStatus sort(const char *inFileName, const char *outFileName, SortOption
									 option)
/* 
   Sorts (by insertion) inFile, and output the result to outFile.
   inFileName NULL => inFile is stdin; outFileName NULL => outFile is stdout.
   Option SORT_NOOUTPUT tells not to output (and reset) the sorting area (to be
   used in case of multi-file sorting, for all files save last).
   Option SORT_BIG_LINE tells to manage the most economically possible (memory-
   wise) lines of any size; otherwise, a fixed-size area is allocated for each
   line (MAX_LINE_SIZ).
*/
{
  static LinkedLine *begLink = NULL;
  static bool sOutOfOrder = True;
  bool outOfOrder = sOutOfOrder;
  Stream input, output;
  bool bigLine = option & SORT_BIG_LINE;
  bool noDupl = option & SORT_NO_DUPL;
  bool reverse = option & SORT_REV_ORDER;
  SortStatus result = SORT_OK;

  if (option & SORT_DISORDER) outOfOrder = False;
  if ((input = (inFileName != NULL)? fopen(inFileName, "r") : stdin) == NULL
						 ) result = SORT_FILE_OPEN_FAIL;
  else {
    for (;;)
ignore:
    {
      size_t lineSize = MAX_LINE_SIZ + 1;
      LinkedLine *newLink = malloc(sizeof(LinkedLine) - 1 + lineSize);

      if (newLink == NULL) {result = SORT_MEM_EXHAUST; break;}
      if (fgets(newLink->line, (int)lineSize, input) == NULL) {free(newLink)
								       ; break;}
      if (bigLine) {
        while (newLink->line[strlen(newLink->line) - 1] != '\n') {
          if ((newLink = realloc(newLink, sizeof(LinkedLine) - 1 + (lineSize +=
			   MAX_LINE_SIZ))) == NULL) {result = SORT_MEM_EXHAUST
							     ; goto exitInsert;}
          if (fgets(&newLink->line[lineSize - (MAX_LINE_SIZ + 1)], MAX_LINE_SIZ
						    + 1, input) == NULL) break;}
        newLink = realloc(newLink, sizeof(LinkedLine) + strlen(newLink->line));}
				       /* allocate memory chunk of exact size */
      {
        LinkedLine *prevLink = NULL, *curLink;

        /* Find insertion position */
        for (curLink = begLink; curLink != NULL; curLink = curLink->next) {
          int w = strcmp(curLink->line, newLink->line);

          if (w==0 && noDupl) {free(newLink); goto ignore /*~BackBranch*/;}
          if (w>=0 && !reverse || w<=0 && reverse) {
            if (w != 0) outOfOrder = (bool)w;/* True (so done for efficiency) */
            break;}
          prevLink = curLink;}
        /* Insert */
        newLink->next = curLink;
        *((prevLink == NULL)? &begLink : &prevLink->next) = newLink;}}
exitInsert:
    if (inFileName != NULL) (void)fclose(input);}
  if (! (option & SORT_NOOUTPUT)) {
    /* Output lines if asked for, and free memory */
    LinkedLine *curLink, *nextLink;

    if (outOfOrder && (output = (outFileName != NULL)? fopen(outFileName, "w")
	  : stdout) == NULL) {result = SORT_FILE_OPEN_FAIL; outOfOrder = False;}
    for (curLink = begLink; curLink != NULL; curLink = nextLink) {
      if (outOfOrder && fputs(curLink->line, output) < 0) result =
								SORT_OUTPUT_ERR;
      nextLink = curLink->next;
      free(curLink);}
    begLink = NULL;  /* no more linked lines in memory */
    if (outOfOrder && outFileName!=NULL && fclose(output)!=0) result =
							   SORT_FILE_CLOSE_FAIL;
    outOfOrder = True;}
  sOutOfOrder = outOfOrder;
  return result;
}
