/*  ncopy: portable 'copy'/append utility.

    Call: ncopy [option(s)] inFileName [outFileName]

          If no out file name given, output goes to stdout.

          Possible options :
          -a  append mode (default mode : copy),
          -b  binary file (default: text file).

    Returns same exit status as copy.
*/

#include <stdlib.h>
#include <stdio.h>
#include "basics.h"

int main(int argc, const char *const argv[])
{
  const char *const *ptrArg;
  CopyMode mode = Txt;
  CopySort sort = Copy;

  for (ptrArg = &argv[0]; *++ptrArg!=NULL && **ptrArg == '-'; ) {
    argc--;
    if (*(*ptrArg + (2)) == '\0') switch (*(*ptrArg + 1)) {
      case 'a': sort = Append; continue;
      case 'b': mode = Bin; continue;
      /*~NoDefault*/}
    fprintf(stderr, ">>>ngrep: option '%s' unimplemented\n", *ptrArg + 1);}
  if (argc <= 1) {
    fputs(">>>ncopy: no input filename\n", stderr);
    return EXIT_FAILURE;}
  else {
    return (copyAppend(*ptrArg, *(ptrArg + 1), mode, sort))? EXIT_SUCCESS :
								  EXIT_FAILURE;}
}
