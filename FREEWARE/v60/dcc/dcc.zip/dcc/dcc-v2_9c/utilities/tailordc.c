/***************************************************************************/
/* Program to tailor dcc to local platform.				   */
/* Written in C so that does not have to rely on shell language (or PERL,  */
/* or similar), as these are not always available on MS-DOS/WindowsXX      */
/* platforms.								   */
/* Has to be compiled by local compiler (because make use of predefined    */
/* symbols, such as __BORLANDC__ or VMS).				   */
/***************************************************************************/

#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef _MSC_VER
# include <Io.h>
#elif defined(__BORLANDC__)
# include <dir.h>  /* for 'chdir' */
#else
# define StrEq(x, y)	(strcmp(x, y) == 0)
# include <unistd.h>
# ifdef VMS
#  include <utsname.h>
# else
#  include <sys/utsname.h>
# endif
#endif
#include "basics.h"
#include "grep.h"
#include "match.h"
#include "sedp.h"
#include "sort.h"

#define LINE_SIZE	255
#define DELTA_BUF_SIZE	128
#define DEFINE_MACRO	" -D"
#define DEFINE_INCL	" -I"
#define DEFINE_DIR	"#define " 

#define LitLen(x)       (sizeof(x) - 1)
#define DCMSG		"dcmsg."

#ifdef VMS
/*#  define UP_DIR	"-"*/
#else
#  define UP_DIR	".."
#endif
#define DCC_FILES_MNG	"dccFiles.mng"
/* Symbols defined in val(DCC_FILES_MNG) */
#define DFLT_PREF	"PrefixDCCDFLTS"
#define SYS_HDR_DIR	"SysHdrDir"
#define STARTER_FILE	"starter.dcc"
#define TMP_FILE	"zzz.bid"

int main()
{
  static char line[LINE_SIZE + 1 + LitLen(DCMSG)] = DCMSG;
  bool gccCompiler;

  /****************************************************/
  /* ChooseMsgLanguage (choose language for messages) */
  /****************************************************/
  fputs("\n", stdout);
  do {
    fputs("Language for messages (\"eng\"lish or \"fre\"nch) : ", stdout);
  } while (fgets(&line[LitLen(DCMSG)], LINE_SIZE, stdin) == NULL);
  snipLF(line);
  remove(DCMSG "txt");
  copyAppend(line, DCMSG "txt", Txt, Copy);

  /**************************************************************************/
  /* ChooseStarterFile (find correct starter file for current platform; see */
  /* description of starter files in "dcreadme.pod", paragraph "Execution   */
  /* files").								    */
  /**************************************************************************/
  if (   grep(STARTER_FILE      , NULL, DCC_FILES_MNG, NULL, GREP_NO_OUTPUT)==
								 NOT_MATCHING
      || grep(SYS_HDR_DIR "`*\"", NULL, DCC_FILES_MNG, NULL, GREP_NO_OUTPUT)==
								 NOT_MATCHING
      || grep(DFLT_PREF "`*\""  , NULL, DCC_FILES_MNG, NULL, GREP_NO_OUTPUT)==
								 NOT_MATCHING) {
    fputs(">>> Bad \"" DCC_FILES_MNG "\" file; quit.\n", stdout);
    return EXIT_FAILURE;}
#ifndef VMS
  chdir("DccExecFiles");
#endif
  {
#ifdef _MSC_VER
    if (fileExist(STARTER_FILE "ClWin32"))
      copyAppend(STARTER_FILE "ClWin32", STARTER_FILE, Txt, Copy);
#elif defined(__BORLANDC__)
    if (fileExist(STARTER_FILE "BccWin32"))
      copyAppend(STARTER_FILE "BccWin32", STARTER_FILE, Txt, Copy);
#else
    struct utsname buf;

    (void)uname(&buf);
    if (StrEq(buf.sysname, "ULTRIX") && StrEq(buf.machine, "RISC"))
      copyAppend(STARTER_FILE "GccMipsSkel", STARTER_FILE, Txt, Copy);
    else if (StrEq(buf.sysname, "OSF1") && StrEq(buf.machine, "alpha"))
      copyAppend(STARTER_FILE "GccAlphaSkel", STARTER_FILE, Txt, Copy);
    else if (StrEq(buf.sysname, "HP-UX") && StrEq(buf.machine, "9000/715"))
      copyAppend(STARTER_FILE "CcHP715", STARTER_FILE, Txt, Copy);
    else if (StrEq(buf.sysname, "HP-UX"))
      copyAppend(STARTER_FILE "GccHPUXSkel", STARTER_FILE, Txt, Copy);
    else if (StrEq(buf.sysname, "SunOS"))
      copyAppend(STARTER_FILE "GccSunosSkel", STARTER_FILE, Txt, Copy);
    else if (StrEq(buf.sysname, "Linux"))
      copyAppend(STARTER_FILE "GccLinuxSkel", STARTER_FILE, Txt, Copy);
    else if (StrEq(buf.sysname, "FreeBSD"))
      copyAppend(STARTER_FILE "GccFreeBSDSkel", STARTER_FILE, Txt, Copy);
    else if (StrEq(buf.sysname, "AIX"))
      copyAppend(STARTER_FILE "XlcAix", STARTER_FILE, Txt, Copy);
#endif
    else if (! fileExist(STARTER_FILE)) {
      fputs(">>> Unsupported platform (as of now); try adapting one of the\n",
									stdout);
      fputs(">>> supplied \"starter.*\" files, and copy it to \"" STARTER_FILE
							       "\".\n", stdout);
      return EXIT_FAILURE;}}

  /********************************************************************/
  /* Add to (skeleton) starter file macros defined by chosen compiler */
  /********************************************************************/
  if (gccCompiler = (grep("__dcc`z\"`zgcc", NULL, STARTER_FILE, NULL,
						    GREP_NO_OUTPUT) == MATCH)) {
    Stream out;

    if (   (out = fopen("zzzBid.c", "w"))==NULL
        || fputs("main(){}", out)==EOF
        || fclose(out)!=0
        || system(NULL)==0
        || ((void)system("gcc -v - zzzBid.c 2>zzzBid.inf > /dev/null"),
						       remove("zzzBid.c")!=0)) {
      fputs(">>> Problem with temporary file and/or 'system'; quit.\n", stdout);
      return EXIT_FAILURE;}
    if (grep("`b-D", NULL, "zzzBid.inf", "zzzBid.mac", GREP_BIG_LINE)==MATCH) {
      /* Create a file with '#define' directives for all '-D' compiler options*/
      size_t bufSize = DELTA_BUF_SIZE + 1;
      char *buffer = malloc(bufSize);
      Stream in;

      if (buffer == NULL) {
        fputs(">>> Memory overflow; quit.\n", stdout);
        return EXIT_FAILURE;}
      if ((in = fopen("zzzBid.mac", "r"))==NULL || (out = fopen("zzzBid.def",
								  "w"))==NULL) {
        fputs(">>> Problem with temporary files; quit.\n", stdout);
        return EXIT_FAILURE;}
      while (getLineOfAnyLgt(&buffer, &bufSize, DELTA_BUF_SIZE, in)) {
        const char *ptrBuf;
        static char line[LINE_SIZE + 1] = DEFINE_DIR;

        for (ptrBuf = buffer; (ptrBuf = strstr(ptrBuf, DEFINE_MACRO)) !=
									NULL;) {
          const char *ptrName = ptrBuf + LitLen(DEFINE_MACRO);
          const char *ptrVal = strpbrk(ptrName, " \t=");
  
          ptrBuf = strpbrk(ptrVal, " \t");
          strncpy(&line[LitLen(DEFINE_DIR)], ptrName, (size_t)(ptrVal
								    - ptrName));
          if (ptrBuf != ptrVal) {
            strcpy(&line[LitLen(DEFINE_DIR) + (size_t)(ptrVal - ptrName)], " ");
            strncpy(&line[LitLen(DEFINE_DIR) + LitLen(" ") + (size_t)(ptrVal
			- ptrName)], ptrVal + 1, (size_t)(ptrBuf - ptrVal - 1));
            strcpy(&line[LitLen(DEFINE_DIR) + (size_t)(ptrBuf - ptrName)],
									 "\n");}
          else strcpy(&line[LitLen(DEFINE_DIR) + (size_t)(ptrBuf - ptrName)],
									" 1\n");
          if (fputs(line, out) < 0) {
            fputs(">>> Problem with temporary file; quit.\n", stdout);
            return EXIT_FAILURE;}}}
      free(buffer);
      (void)fclose(in);
      if (fclose(out) != 0) {
        fputs(">>> Problem with temporary file; quit.\n", stdout);
        return EXIT_FAILURE;}
      (void)sort("zzzBid.def", "zzzBid1.def", SORT_NO_DUPL);
      (void)remove("zzzBid.def");
      copyAppend("zzzBid1.def", STARTER_FILE, Txt, Append);
      (void)remove("zzzBid1.def");}
    (void)remove("zzzBid.mac");}
  else {
    /* Insert here a sequence similar to previous one for other compilers */
    /* giving list of predefined macros.				  */
    printf(">>> Chosen C compiler does not tell predefined macros;\n"
	    ">>> \"" STARTER_FILE "\" file may have to be adapted by hand.\n");}

  /**********************************************************************/
  /* CreateLocalFilesMngFile (define value of symbols SysHdrDir/Prefix- */
  /* DCCDFLTS in file val(DCC_FILES_MNG) ).				*/
  /**********************************************************************/
  {
    char answ[(3)], *sysIncl = NULL;

    for (;;) {
      fputs("Default dcc option(s) ?  For example:\n", stdout);
      fputs(" -zgpr        (less checking of \"good programming practices\")"
								  "\n", stdout);
      fputs(" +zrhw -zlvl2 (report only errors or highest level warnings, and"
							  " prevent\n", stdout);
      fputs("               compilation if level >= 2)\n", stdout);
      fputs("See 'dcreadme.pod' for options. If several options, separate "
						   "them by spaces.\n", stdout);
      fputs(": ", stdout);
      if (fgets(line, sizeof(line), stdin) == NULL) continue;
      do {
        fputs("OK ? (y/n): ", stdout);
      } while (fgets(answ, sizeof(answ), stdin)==NULL
               || answ[0]!='y' && answ[0]!='n');
      if (answ[0] == 'y') break;}
    snipLF(line);
    if (gccCompiler) {
      /* Add -I<directory> options at end of default command line */
      size_t bufSize = DELTA_BUF_SIZE + 1;
      char *buffer = malloc(bufSize);
      Stream in;

      if (buffer == NULL) {}
      in = fopen("zzzBid.inf", "r");
      while (getLineOfAnyLgt(&buffer, &bufSize, DELTA_BUF_SIZE, in) && match(
		       "`z#`zinclude`z<`*", NULL, buffer, NULL, False, NULL)==
								NOT_MATCHING) {}
      while (getLineOfAnyLgt(&buffer, &bufSize, DELTA_BUF_SIZE, in) && match(
		 "End of`*", NULL, buffer, NULL, False, NULL) == NOT_MATCHING) {
        strcat(line, DEFINE_INCL);
        snipLF(buffer);
        strcat(line, buffer + strspn(buffer, " \t"));
        if (strlen(line) >= sizeof(line)) {
          fputs(">>> Overflow; increase value of symbol LINE_SIZE in "
				       "'tailorDc.c', and recompile\n", stdout);
          return EXIT_FAILURE;}}
      free(buffer);
      (void)fclose(in);
      (void)remove("zzzBid.inf");
      if ((sysIncl = strrchr(line, ' ')) != NULL) {
        *sysIncl = '\0';
        sysIncl += LitLen(DEFINE_INCL);}}  /* main 'system include' directory */
#ifndef VMS
    chdir(UP_DIR);  /* back to main directory */
#endif
    {
      const char *modif[1];

      modif[0] = &line[0];
      (void)sedp("`{0`z#`zdefine`b" DFLT_PREF "`z\"`*`}`{1\"`*`}"
                 "`>"
                 "`{0`#0 `{1",
		 modif,
		 DCC_FILES_MNG,
		 (sysIncl == NULL)? "locdcFil.mng" : TMP_FILE,
		 SEDP_EMPTY_OPTION);
      if (sysIncl != NULL) {
        modif[0] = sysIncl;
        (void)sedp("`{0`z#`zdefine`b" SYS_HDR_DIR "`z\"`}`*`{1\"`*`}"
                   "`>"
                   "`{0`#0`{1",
		   modif,
		   TMP_FILE,
		   "locdcFil.mng",
		   SEDP_EMPTY_OPTION);
        (void)remove(TMP_FILE);}}}
  return EXIT_SUCCESS;
}
