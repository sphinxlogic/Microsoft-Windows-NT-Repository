#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "match.h"

#define MAX_LINE_SIZE   80

static Zone charRuns['9' - '0' + 1];

static void clrRuns()
{
  register Zone *pz;

  for (pz = &charRuns[0]; pz <= &charRuns['9' - '0']; pz++) {
    pz->begAddr = NULL;
    pz->lgt = 0;}
}

static void print()
{
  Zone *pz;

  for (pz = &charRuns[0]; pz <= &charRuns[('9' - '0')]; pz++)
    if (pz->begAddr != NULL) {
      printf("%d:", pz - &charRuns[0]);
      while (pz->lgt-- != 0) printf("%c", *pz->begAddr++);
      printf("\n");}
}

int main ()
{
  char pattern[MAX_LINE_SIZE + 1];
  Status status;

  while (fputs("pattern? :", stdout), fgets(pattern, MAX_LINE_SIZE + 1, stdin)
					  !=NULL && strcmp(pattern, "`\n")!=0) {
    char string[MAX_LINE_SIZE + 1];
    size_t lgt = strlen(pattern);

    if (lgt>0 && pattern[lgt - 1]=='\n') pattern[lgt - 1] = '\0';
    while (fputs("string? :", stdout), fgets(string, MAX_LINE_SIZE + 1, stdin)
					   !=NULL && strcmp(string, "`\n")!=0) {

      lgt = strlen(string);
      if (lgt>0 && string[lgt - 1]=='\n') string[lgt - 1] = '\0';
      clrRuns();
      status = match(pattern, NULL, string, charRuns, True, NULL);
      if (status > 0) printf("\nSyntax error #%d in pattern.\n", status);
      else printf("\n%s\n", (status == MATCH)? "match" : "not matching");
      print();}}
  {
    static const char *stringList[] = {"`#1", "", "X``"}, pattern[] =
					     "`#1`{9`#2a`#0b`#1`#1`}", *ptrStop;

    clrRuns();
    status = match(pattern, stringList, "X``a`#1b", charRuns, True, &ptrStop);
    if (ptrStop != &pattern[sizeof(pattern)/sizeof(pattern[0]) - 1]) printf(
							  "\nBad 'ptrStop'.\n");
    if (status > 0) printf("\nSyntax error #%d in pattern.\n", status);
    else printf("\n%s\n", (status == MATCH)? "match" : "not matching");
    print();}
  return EXIT_SUCCESS;
}
