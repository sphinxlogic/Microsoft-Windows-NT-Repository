#include <limits.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "grep.h"
#include "match.h"

#define MAX_LINE_SIZ	255
#define LgtEscSeq	2
#define LitLen(x)       (sizeof(x) - 1)
/*~zif LgtEscSeq != LitLen("`&") "Pb !"*/

typedef FILE *Stream;

#define ADD_AG		1
#define ADD_AGST	(ADD_AG << 1)
#define SIGN_BIT        ~INT_MAX

Status grep(const char *grepPattern, const char *const *paramPattern, const
		   char *inFileName, const char *outFileName, GrepOption option)
/* 
   'grepPattern' adapted to fit match() requirements (overflow not checked).
   Additional possible escape sequences in pattern are :
   - '`&' and '`|', meaning AND and OR of matching (processed from left to right
     without priority),
   - '`^' and '`$', only recognized at beginning/end of (sub)pattern, and match-
     ing beginning/end of string.
*/
{
  bool severalPatterns = False;
  char pattern[MAX_LINE_SIZ + 1];
  char *ptrPattern = &pattern[0];
  int addToPattern = ADD_AGST;
  Status result;

  /* Transfert pattern and adapt it:
     for each sub-pattern
     - except if it starts by '`^', prefix it with '`*'
     - except if it ends with '`$', suffix it by '`*' */
  do {
    if (*grepPattern == '`') switch(*++grepPattern) {
      case '^':
        if (addToPattern != 0) {addToPattern = 0; grepPattern++; continue;}
        /*~ NoBreak */
      case '\0': return BAD_ESC;
      case '$':
        if (*++grepPattern =='\0') goto noFinalSuffix;
        if (! (*grepPattern=='`' && (*++grepPattern=='&' || *grepPattern=='|')
							      )) return BAD_ESC;
        addToPattern = SIGN_BIT;
        goto endSubPattern;
      case '&':
      case '|': 
        addToPattern = SIGN_BIT | ADD_AGST;
endSubPattern:
        severalPatterns = True;
        /*~ NoBreak */
      default:
        addToPattern |= ADD_AG;}
    if (addToPattern != 0) {
      if (addToPattern & ADD_AGST) {*ptrPattern++ = '`'; *ptrPattern++ = '*';}
      if (addToPattern & ADD_AG) *ptrPattern++ = '`';
      addToPattern = (addToPattern < 0)? ADD_AGST : 0;}
  } while ((*ptrPattern++ = *grepPattern++) != '\0');
  *(ptrPattern - 1) = '`';
  *ptrPattern++ = '*';
noFinalSuffix:
  *ptrPattern = '\0';
  /* Check pattern syntax */
  if ((result = match(pattern, paramPattern, "", NULL, True, NULL)) > 0) return
									 result;
  /* Do the job */
  {
    size_t lineSize = MAX_LINE_SIZ + 1;
    char *line = malloc(lineSize);
    Stream input, output;
    Status outputState = (option & GREP_OUTPUT_LINE_NM)? NOT_MATCHING : MATCH;
    bool noOutput = option & GREP_NO_OUTPUT;
    bool bigLine = option & GREP_BIG_LINE;

    if (line == NULL) return GREP_MEM_EXHAUST;
    if (noOutput) outFileName = NULL;
    if ((input = (inFileName != NULL)? fopen(inFileName, "r") : stdin)==NULL ||
	(output = (outFileName != NULL)? fopen(outFileName, "w") : stdout)
					     ==NULL) return GREP_FILE_OPEN_FAIL;
    result = NOT_MATCHING;
    for (; fgets(line, (int)lineSize, input) != NULL;) {
      while (bigLine && line[strlen(line) - 1] != '\n') {
        if ((line = realloc(line, (lineSize += MAX_LINE_SIZ))) == NULL) return
							       GREP_MEM_EXHAUST;
        if (fgets(line + lineSize - (MAX_LINE_SIZ + 1), MAX_LINE_SIZ + 1,
							 input) == NULL) break;}
      {
        const char *ptrStop;
        Status curStatus = match(pattern, paramPattern, line, NULL,
						     severalPatterns, &ptrStop);

        if (severalPatterns) {
          char stopChar;

          while ((stopChar = *ptrStop) != '\0') {
            Status status = match(ptrStop + 1, paramPattern, line, NULL, True,
								      &ptrStop);

            if  (stopChar == '&') {
              if (status == NOT_MATCHING) curStatus = NOT_MATCHING;}
            else if (status != NOT_MATCHING) curStatus = MATCH;}}
        if (curStatus == outputState) {
          result = MATCH;
          if (! noOutput) fputs(line, output);}}}
    free(line);
    if (inFileName != NULL) (void)fclose(input);
    return (outFileName!=NULL && fclose(output)!=0)? GREP_FILE_CLOSE_FAIL :
									result;}
}
