#ifndef _SEDP_H
#define _SEDP_H

#include "match.h"

#define SEDP_FILE_OPEN_FAIL	END_MATCH_ERRS + 1
#define SEDP_FILE_CLOSE_FAIL	SEDP_FILE_OPEN_FAIL + 1
#define SEDP_MEM_EXHAUST	SEDP_FILE_CLOSE_FAIL + 1
#define SEDP_NO_OPATT		SEDP_MEM_EXHAUST + 1
#define SEDP_BAD_OPATT		SEDP_NO_OPATT + 1
#define SEDP_TOOMANY_OUTPATT_ELT SEDP_BAD_OPATT + 1

typedef enum{SEDP_EMPTY_OPTION=0, SEDP_OUT_NOT_MATCH=1, SEDP_OUT_MATCH=2,
						    SEDP_BIG_LINE=4} SedpOption;

extern Status sedp(const char *pattern, const char *const *paramPattern,
		   const char *inFileName, const char *outFileName, SedpOption);
#endif
