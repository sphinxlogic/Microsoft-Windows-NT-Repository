#ifndef _GREP_H
#define _GREP_H

#include "match.h"

#define GREP_FILE_OPEN_FAIL	END_MATCH_ERRS + 1
#define GREP_FILE_CLOSE_FAIL	GREP_FILE_OPEN_FAIL + 1
#define GREP_MEM_EXHAUST	GREP_FILE_CLOSE_FAIL + 1

typedef enum{GREP_EMPTY_OPTION=0, GREP_NO_OUTPUT=1, GREP_OUTPUT_LINE_NM=2,
						    GREP_BIG_LINE=4} GrepOption;

extern Status grep(const char *grepPattern, const char *const *paramPattern,
		   const char *inFileName, const char *outFileName, GrepOption);
#endif
