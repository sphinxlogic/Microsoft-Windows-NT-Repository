#include <stdio.h>
#include <stdlib.h>

int main()
{
 printf("\n");
 printf("******************************************************************\n");
 printf("*                                                                *\n");
 printf("*                       Welcome to dcc !!!                       *\n");
 printf("*                                                                *\n");
 printf("* The first thing 'make' is about to do is to tailor dcc to your *\n");
 printf("* platform; to do so, it needs the 'uname' function. If this     *\n");
 printf("* function is not supported by your system, there will be an er- *\n");
 printf("* ror at compile or link time for the next program executed by   *\n");
 printf("* 'make': 'tailorDc'.                                            *\n");
 printf("* In such a case, either include the right library (modify the   *\n");
 printf("* command line for 'tailorDc' in \"makefile\") or, if there is no  *\n");
 printf("* such library, modify the source \"tailorDc.c\" to remove the     *\n");
 printf("* call to 'uname' (see for example the Microsoft Visual C case,  *\n");
 printf("* preprocessing symbol '_MSC_VER').                              *\n");
 printf("* In any case, please report at \"dccsupport@supelec.fr\" your so- *\n");
 printf("* lution, for it to be incorporated in next dcc release. Thank   *\n");
 printf("* you !                                                          *\n");
 printf("*                                                                *\n");
 printf("******************************************************************\n");
 printf("Press Return to continue ");
 while (getchar() != '\n') {}
 return EXIT_SUCCESS;
}
