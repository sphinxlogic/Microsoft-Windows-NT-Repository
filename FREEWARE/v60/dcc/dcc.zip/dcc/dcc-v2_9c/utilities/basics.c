/* Various basic routines */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "basics.h"

#define RECORDSIZE 256  /* arbitrary */

bool copyAppend(const char *inFile, const char *outFile, CopyMode mode,
						  CopySort sort) /*~PseudoVoid*/
/* File copying routine */
/* Returns True iff successful */
{
  Stream in, out;
  unsigned char buf[RECORDSIZE];
  size_t count;

  if ((in = fopen(inFile, (mode == Txt)? "r" : "rb")) == NULL) return
					 error("Can't open input file", inFile);
  if ((out = (outFile == NULL)
             ? stdout
             : fopen(outFile, (mode == Txt)
                              ? (sort == Copy)
                                ? "w"
                                : "a"
                              : (sort == Copy)
                                ? "wb"
                                : "ab")) == NULL) return error(
					     "Can't open output file", outFile);
  while ((count = fread(buf, 1, RECORDSIZE, in)) != 0) {
    if (ferror(in)) return error("Error while reading input", inFile);
    (void)fwrite(buf, 1, count, out);
    if (ferror(out)) return error("Error while writing output", outFile);}
  (void)fclose(in);
  if (fclose(out) != 0) return error("Error on closing output", outFile);
  return True;
}

bool error(const char *msg, const char *fileName)
{
  fprintf(stdout, ">>> %s (file \"%s\").\n", msg, fileName);
  return False;
}

bool fileExist(const char *fileName)
{
  Stream w;

  return ((w = fopen(fileName, "r")) == NULL)? False : ((void)fclose(w), True);
}

bool getLineOfAnyLgt(char **pBuffer, size_t *pBufSize, size_t deltaSize,
								      Stream in)
/* Returns True as long as no error or end-of-file hit */
{
  if (fgets(*pBuffer, (int)*pBufSize, in) == NULL) return False;
  while ((*pBuffer)[strlen(*pBuffer) - 1] != '\n') {
    if ((*pBuffer = realloc(*pBuffer, (*pBufSize += deltaSize))) == NULL) {
      fputs(">>> getLineOfAnyLgt: Memory exhausted\n", stdout);
      return False;}
    if (fgets(*pBuffer + *pBufSize - (deltaSize + 1), (int)deltaSize + 1, in)
								== NULL) break;}
  return True;
}

size_t snipLF(char line[]) /*~PseudoVoid*/
/* Snip off possible NL at end of 'line'; return (new) length of line */{
  size_t lgtLine = strlen(line);

  if (line[lgtLine - 1] == '\n') line[--lgtLine] = '\0';
  return lgtLine;
}
