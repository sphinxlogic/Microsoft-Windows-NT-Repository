/*	sedp: sort of portable 'sed' (operator copying, line by line, an 'input'
	file to an 'output' file, modifying in the process lines matching a
	given pattern).

	Call: sedp(patternsDescription, paramPattern, inputFileName
							 outputFileName, option)

	'patternsDescription' is a character string whose format is:
	  <patternsDescription> ::= <pattern>
				    <patternsDescription> `| <pattern>
	  <pattern> ::= <inPattern> `> <outPattern>
	  <inPattern>  ::= <valid pattern for the 'match' function (see
								     'match.c')>
          <outPattern> ::= <outPattElt>*
	  <outPattElt> ::= `{n		\\ see 'match'
			   `#n          \\ see 'match'
			   <character string not including "`{" nor "`#" nor
									   "`|">

	<outPattern> describes the output line if the input line matches <inPat-
	tern>; there can be a maximum of SIZE_ZONEO "`{" or "`#" escape sequence
	in it.

	<patternDescription> is explored from left to right; if an <inPattern>
	is recognized, the corresponding <outPattern> is heeded, creating the
	output line that replaces the input line, and possible following
	<pattern>s are ignored.

	'paramPattern' is either NULL or an array of strings that can be used
	to parametrize in and/or out patterns.

	'inputFileName' NULL means take input from stdin.

	'outputFileName' NULL means put output to stdout.

	'option' can be either SEDP_EMPTY_OPTION or SEDP_BIG_LINE, the latter
	meaning the line buffer is dynamically allocated (else fixed size:
	MAX_LINE_SIZ). There are also options SEDP_OUT_MATCH/SEDP_OUT_NOT_MATCH,
	telling to only output lines in case of match/non-match. Options can be
	or'ed.

	Return: values given by 'match', or values defined in sedp.h; as soon
	as a line has been found to match a pattern, it returns MATCH (barring
	any syntax error).

	Exemple :
	  call sedp("`*define`[`s`t`]*`{0`*`}`[`s`t`]*`{1`*`}`>`{1 is defined "
								    "as ```{0``"
		    "`|"
		    "`{0`*`}set`{1`*`}`>set `{0 `#0 here",
		    listS, "titi", "toto", SEDP_EMPTY_OPTION)
	  If element 0 of array 'listS' contains address of string "is used"
	  and file 'titi' exists and contains the following lines:
	    blabla
	    blue
	    tuvw    set     33+ 12
	    xyz define aBc cdef , . `
	    Pink Floyds
	  file 'toto' will get the following lines:
	    blabla
	    blue
	    set tuvw         is used here
	    cdef , . ` is defined as ``aBc``
	    Pink Floyds
	  and the value returned by 'sedp' will be MATCH.
	  Had the option been SEDP_OUT_MATCH, file 'toto' would have got
	  only:
            set tuvw         is used here
            cdef , . ` is defined as ``aBc``
	  and for option SEDP_OUT_NOT_MATCH, file 'toto' would have got:
            blabla
            blue
            Pink Floyds
*/

#include <limits.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sedp.h"
#include "match.h"

#define MAX_LINE_SIZ	255  /* arbitrary */
#define SIZE_ZONEO	10   /* arbitrary */
#define LgtEscSeq	2
#define LitLen(x)	(sizeof(x) - 1)
#define NbElt(x)	((int)(sizeof(x)/sizeof(x[0])))
/*~zif LgtEscSeq != LitLen("`&") "Pb !"*/

typedef FILE *Stream;

static bool isEscChar(char);

static const char *const *parPatt;

Status sedp(const char *pattern, const char *const *paramPattern, const char
			*inFileName, const char *outFileName, SedpOption option)
{
  Status result;
  size_t lineSize = MAX_LINE_SIZ + 1;
  char *line;
  Stream input, output;
  bool bigLine = option & SEDP_BIG_LINE;
  const char *ptrStop = pattern;

  parPatt = paramPattern;
  /* Check pattern syntax */
  if (*ptrStop != '\0') {
    char curChar;

    for (;; ptrStop++) {
      if ((result = match(ptrStop, paramPattern, "", NULL, True, &ptrStop)) > 0
								) return result;
      if (! ((curChar = *ptrStop)=='&' || curChar=='|')) break;}
    /* check 'outPattern' syntax */
    if (*ptrStop != '>') return SEDP_NO_OPATT;
    for (;;) {
      if ((curChar = *ptrStop++) == '\0') goto checkDone;
      if (curChar=='`' && isEscChar(curChar = *ptrStop)) {
        ptrStop++;
        if (curChar == '|') break;
        if (! ((curChar = *ptrStop++)>='0' && curChar<='9')) return
							      SEDP_BAD_OPATT;}}}
checkDone:
  /* Do the job */
  if ((line = malloc(lineSize)) == NULL) return SEDP_MEM_EXHAUST;
  if ((input = (inFileName != NULL)? fopen(inFileName, "r") : stdin) == NULL) {
    inFileName = NULL; goto errOpen;}
  if ((output = (outFileName != NULL)? fopen(outFileName, "w") : stdout) ==NULL)
errOpen: {
    result = SEDP_FILE_OPEN_FAIL; outFileName = NULL; goto exit;}
  result = NOT_MATCHING;
  /* Get next line (managing 'big lines', that is lines longer than
							       MAX_LINE_SIZ). */
  while (fgets(line, (int)lineSize, input) != NULL) {
    Status curStatus;
    Zone zonesO[SIZE_ZONEO + 1] /* +1 for ending NULL zone */, *ptrZone;

    while (bigLine && line[strlen(line) - 1] != '\n') {
      if ((line = realloc(line, (lineSize += MAX_LINE_SIZ))) == NULL) {result =
						   SEDP_MEM_EXHAUST; goto exit;}
      if (fgets(line + lineSize - (MAX_LINE_SIZ + 1), MAX_LINE_SIZ + 1,
							 input) == NULL) break;}
    line[strlen(line) - 1] = '\0';
    /* Search pattern(s) */
    {
      Zone zonesI[NbElt(zonesO)];

      if (*pattern != '\0') {
        char curChar;

        ptrStop = pattern;
        do {
          char stopChar;

          curStatus = match(ptrStop, paramPattern, line, zonesI, True,&ptrStop);
          while ((stopChar = *ptrStop++)=='&' || stopChar=='|') {
            Status status = match(ptrStop, paramPattern, line, zonesI, True,
								      &ptrStop);

            if  (   stopChar=='&' && status==NOT_MATCHING
                 || stopChar=='|' && status==MATCH) curStatus = status;}
          if (curStatus == MATCH) {
            result = MATCH;
            for (ptrZone = &zonesO[NbElt(zonesO)]; ptrZone > &zonesO[0];
				 		   ) (--ptrZone)->begAddr= NULL;
            while ((curChar = *ptrStop++) != '\0') {
              if (curChar=='`' && isEscChar(curChar = *ptrStop)) {
                ptrStop++;
                if (curChar == '|') goto exitDo;
                if (ptrZone == &zonesO[NbElt(zonesO) - 1]) {result =
					   SEDP_TOOMANY_OUTPATT_ELT; goto exit;}
                {
                  int i = *ptrStop++ - '0';

                  if (curChar == '{') *ptrZone++ = zonesI[i];
                  else {  /* '#' */
                    ptrZone->begAddr = paramPattern[i];
                    (ptrZone++)->lgt = strlen(paramPattern[i]);}}}
              else {
                const char *debZone = ptrStop;

                do {
                  curChar = *ptrStop++;
                } while (curChar!='\0' && !(curChar=='`' && isEscChar(*ptrStop)
									     ));
                ptrZone->begAddr = debZone - 1;
                (ptrZone++)->lgt = (size_t)(ptrStop-- - debZone);}}
exitDo:
            break;}
          else
          /* Skip rest of output pattern */
            while ((curChar = *ptrStop++) != '\0')
              if (curChar=='`' && *ptrStop=='|') {ptrStop++; break;}
        } while (curChar != '\0');}}
    if (curStatus == MATCH) {
      if (option & SEDP_OUT_NOT_MATCH) continue;
      {
        char *changedLine;

        changedLine = catenate(zonesO);
        fputs(changedLine, output);
        free(changedLine);}}
    else {
      if (option & SEDP_OUT_MATCH) continue;
      fputs(line, output);}
    fputc('\n', output);}
exit:
  free(line);
  if (inFileName != NULL) (void)fclose(input);
  return (outFileName!=NULL && fclose(output)!=0)? SEDP_FILE_CLOSE_FAIL :result;
}

static bool isEscChar(char ch)
{
  return (ch=='|' || ch=='{' || parPatt!=NULL && ch=='#');
}
