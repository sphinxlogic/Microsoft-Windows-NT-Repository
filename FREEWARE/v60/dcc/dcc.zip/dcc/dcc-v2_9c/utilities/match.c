#include <stdlib.h>
#include <string.h>
#include "match.h"

#define SIZE_LIST	127  /* arbitrary */

#define HEX_BITS	4
#define MAX_CHAR	((1 << (HEX_BITS + HEX_BITS)) - 1)
#define STOP_STORING	(Zone * /*~OddCast*/)1

#define END_STRING	(ExtChar)0
#define END_LIST	(END_STRING - 1)
#define ANY_CHAR        (END_LIST - 1)
#define ANY_STRING      (ANY_CHAR - 1)
#define LIST_CHAR	(ANY_STRING - 1)
#define LIST_CHARQ	(LIST_CHAR - 1)
#define LIST_CHARP	(LIST_CHARQ - 1)
#define LIST_CHARS	(LIST_CHARP - 1)

#define ManageSimplEsc							       \
  case 'n' : curChar = '\n'; break;					       \
  case 's' : curChar = ' ' ; break;					       \
  case 't' : curChar = '\t'; break;					       \
  case 'x' : ptrPat = qtrPat; curChar = hexVal(); qtrPat = ptrPat; break;      \
  case '`' : break;

#define NxtEChar(x)	(*pNxtEChar)(x) /* get next character in pattern */

#ifdef uint
#undef uint
#endif
#define /*~Masking*/ uint unsigned int

typedef int ExtChar;

static char hexVal(void);
static void nxtEChar(const char *), nxtEChar1(const char *);

static ExtChar curXChar;
static Zone *curZone, *zoneMet;
static char listChar[SIZE_LIST + 1];  /* array holding (expanded) character
						    list for "`[" management. */
static const char *const *parPatt, *ptrPat, *savPtrPat;
static void (*pNxtEChar)(const char *) = &nxtEChar;
static Zone *ptrZones;
static Status result;

Status match(const char *pattern,
	     const char *const *paramPattern,
	     register const char *string,
	     Zone *zones,
	     bool syntaxCheck,
	     const char **ptrStop)
/* match(...) answers whether 'string' matches 'pattern'.
   'zones' is an array of structures, each storing beginning address and number
   of characters found in 'string' between "`{n" and "`}" met in pattern (n =
   zone number; one digit only).
   Possible escape sequences in 'pattern' :
    - `b : matches any non-empty string of spaces/horizontal tabulations
    - `n : matches a linefeed
    - `s : matches a space
    - `t : matches an horizontal tabulation
    - `xhh : matches the character whose hexadecimal coding is hh
    - `z : matches any string (possibly empty) of spaces/horizontal tabulations
    - `` : matches a ` (accent grave)
    - `- : matches a - (dash)
    - `% : matches any character
    - `* : matches any set of characters
    - `[...`]x : ... is a list of characters; x indicates the sort of matching:
             ] : matches any character from the list,
             ? : matches any character from the list; else ignored,
             + : matches any set of characters from the list,
             * : matches any set of characters from the list; else ignored.
           In the list '...', the form "x1`-x2", where x1,x2 are any characters
           and x1<=x2, denotes all characters in the closed interval [x1, x2].
    - `{n : store, in 'zones' element number n, beginning address (in 'string')
            of following matched characters; n = '0'-'9'. Nothing is stored if
            'zones' is NULL.
            `{ cannot nest.
    - `}  : store number of matched characters, and close current zone.
    - `#n : authorized only if 'paramPattern' non-NULL and '0' <= n <= '9';
            (logically) replaced by string pointed by paramPattern[n - '0'].
            This string is taken literally (escape sequences disabled inside).
    - `&, `| or `> : alternate stopping characters in the pattern (beside \0).

   Example:
     Given the pattern "aBc`t`{0`*`}`{1`[()B`-Z`]+`}A`{4.`*;`} `s.\n`{3`}", the
     string "aBc\t\tabc(PU)BA.()}};  .\n" will be matched and, provided 'zones'
     is non NULL, zones[0] will describe the string "\tabc", zones[1] will des-
     cribe the string "(PU)B", zones[4] will describe the string ".()}};", and
     zones[3] will describe the string "". Other 'zones' elements are untouched.
     For ASCII character set, `[()B`-Z`]+ is equivalent to `[()`x42`-`x5A`]+.

  'paramPattern' is either NULL or an array of strings that can be used to
  parametrize the pattern.

  'syntaxCheck' tells whether to check the entire pattern for syntax (can be
  done on an empty 'string'). If False, the pattern is only checked up to the
  first non-match. If True, the checking stops on the first stopping character,
  except if 'ptrStop' (see after) is NULL, in which case it stops only on the
  final \0.

  In case of matching, or if 'syntaxCheck' is True, the pointer pointed by
  'ptrStop' (ptrStop not NULL) is set to point to the stopping character in the
  pattern.

  Result: positive => syntax error (see coding in match.h), else
          zero     => NOT_MATCHING
          -1       => MATCH
*/
{
  const char *savPPat = NULL, *savPStr;
  Zone *savCurZone;

  parPatt = paramPattern;
  ptrZones = zones;
  ptrPat = pattern;
  result = NOT_MATCHING;
  curXChar = END_STRING;
  curZone = zoneMet = NULL;  /* no storing by default */
  for (;;) {
    NxtEChar(string);
dontGetNxtChar:
    if (curXChar==(ExtChar)(unsigned char)*string || curXChar==ANY_CHAR) {
      if (*string++ != '\0') continue;
      if (curXChar < END_STRING) goto exitFalse;
      if (result == NOT_MATCHING) result = MATCH;  /* if error seen, keep it */
      goto exit;}
    if (curXChar <= LIST_CHAR) {  /* "`[...`]x" */
      ExtChar repType = curXChar - LIST_CHARP;
      const char *savString = string;

      do {
        if (*string=='\0' || strchr(listChar, *string) == NULL) {  /* current
						 character not found in list. */
          if (repType==0 && string==savString || repType==LIST_CHAR-LIST_CHARP
					   ) goto exitFalse;  /* "]+" or "]]" */
          break;}
        string++;
      } while (repType <= 0);  /* "]+" or "]*" */
      continue;}
    /* Manage "`*" */
    if (curXChar == ANY_STRING) savPPat = ptrPat;
    else {
      if (savPPat == NULL) goto exitFalse;  /* No "`*" met before */
      /* Start over one step further in string */
      string = savPStr;
      if (*string++ == '\0') goto exitFalse;
      curZone = savCurZone; ptrPat = savPPat;
      curXChar = ANY_STRING;}
    NxtEChar(string);
    if (curXChar >= 0) {
      ExtChar locXChar = curXChar;

      while ((ExtChar)(unsigned char)*string != locXChar) if (*string++ ==
							  '\0') goto exitFalse;}
    else if (curXChar <= LIST_CHAR) {
      while (strchr(listChar, *string++) == NULL) {}
      string--;}
    savPStr = string; savCurZone = curZone;  /* save attained position */
    if (zoneMet != NULL) {
      if (curZone != NULL) curZone->lgt = (size_t)(string - curZone->begAddr);
      if (zoneMet == STOP_STORING) curZone = NULL;
      else {curZone = zoneMet; curZone->begAddr = string;}
      zoneMet = NULL;}
    goto dontGetNxtChar /*~BackBranch*/;}
exitFalse:
  if (! syntaxCheck) return result;
  string--;
  while (curXChar!=END_STRING || ptrStop==NULL && *(ptrPat - 1)!='\0')
    NxtEChar(string);  /* for syntax error detection in remaining of pattern */
exit:
  if (ptrStop != NULL) *ptrStop = ptrPat - 1;
  return (zoneMet!=STOP_STORING && (zoneMet!=NULL || curZone!=NULL))?
							     MSNG_RBRA : result;
}

static void nxtEChar(const char *string)
{
  char curChar;
  register const char *qtrPat = ptrPat;

  for (;;) {
    curChar = *qtrPat++;
    if (curChar == '`') switch (curChar = *qtrPat++) {
      ManageSimplEsc
      case 'b': curXChar = LIST_CHARP; goto caseoL;
      case 'z':
        curXChar = LIST_CHARS;
caseoL:
        listChar[0] = ' ';
        listChar[1] = '\t';
        listChar[(2)] = '\0';  /* terminator */
        goto exit;
      case '-': break;
      case '*': curXChar = ANY_STRING; goto exit;
      case '%': curXChar = ANY_CHAR  ; goto exit;
      case '[': {
          char *listPtr = &listChar[0];
          static char curIChar = '\0', finalIChar = '\0';

          curXChar = LIST_CHAR;
          for (;;) {
            if (curIChar < finalIChar) curChar = ++curIChar;  /* still inside
								    interval. */
            else {
              if ((curChar = *qtrPat++) == '\0') {result = MSNG_RSBR; qtrPat--
								   ; goto exit;}
              if (curChar == '`') switch (curChar = *qtrPat++) {
                ManageSimplEsc
                case ']' : goto exitLoop;
                case '-' :  /* interval */
                  if ((curChar = *qtrPat++) == '`') switch (curChar=*qtrPat++) {
                    ManageSimplEsc
                    default:
                      qtrPat--;
                      result = BAD_ESC;}
                  if (listPtr==&listChar[0] || curChar<*(listPtr - 1)
				       ) {qtrPat--; result = BAD_INTERV; break;}
                  curIChar = *(listPtr - 1);
                  finalIChar = curChar;
                  continue;
                default:
                  qtrPat--;
                  result = BAD_ESC;}}
            if (listPtr == &listChar[SIZE_LIST]) result = LIST_TOO_LONG;
            else *listPtr++ = curChar;}
exitLoop:
          *listPtr = '\0';}
        switch (*qtrPat++) {
          case ']': break;
          case '+': curXChar = LIST_CHARP; break;
          case '?': curXChar = LIST_CHARQ; break;
          case '*': curXChar = LIST_CHARS; break;
          default : qtrPat--; result = BAD_RSBR;}
        goto exit;
      case '{':
        curChar = *qtrPat++;
        if (curChar<'0' || curChar>'9' || zoneMet!=STOP_STORING &&
		  (zoneMet!=NULL || curZone!=NULL)) {result = BAD_LBRA; break;}
        if (ptrZones != NULL)
          if (curXChar == ANY_STRING) zoneMet = &ptrZones[curChar - '0'];
          else {curZone = &ptrZones[curChar - '0']; curZone->begAddr = string;}
        continue;
      case '}':
        if (ptrZones != NULL) {
          Zone *w;

          if (zoneMet==STOP_STORING || zoneMet==NULL && curZone==NULL
						   ) {result = BAD_RBRA; break;}
          w = ((zoneMet != NULL)? zoneMet : curZone);
          w->lgt = (size_t)(string - w->begAddr);
          if (curXChar == ANY_STRING) zoneMet = STOP_STORING;
          else curZone = NULL;}
        continue;
      case '&':
      case '|':
      case '>': curChar = '\0'; break;
      case '#':
        curChar = *qtrPat++;
        if (parPatt!=NULL && curChar>='0' && curChar<='9') {
          savPtrPat = qtrPat;
          ptrPat = parPatt[curChar - '0'];
          pNxtEChar = &nxtEChar1;
          NxtEChar(string);
          return;}
        /*~NoBreak*/
      default:
        result = BAD_ESC;}
    break;}
  curXChar = (ExtChar)(unsigned char)curChar;
exit:
  ptrPat = qtrPat;
}

static void nxtEChar1(const char *string)
{
  if (*ptrPat != '\0')
    curXChar = (ExtChar)(unsigned char)*ptrPat++;
  else {
    ptrPat = savPtrPat;
    pNxtEChar = &nxtEChar;
    NxtEChar(string);}
}
    
static char hexVal(void)
{
  uint i, gottenChar = 1;

  do {
    i = (uint)(*ptrPat++ - '0');
    if (i > '9' - '0')
      if (/*~CastTo uint*/(i - (uint)('A' - '0')) <= (uint)('F' - 'A')) i -=
							   (uint)('A' -'9' - 1);
      else if (/*~CastTo uint*/(i - (uint)('a' - '0')) <= (uint)('f' - 'a')
						   ) i -= (uint)('a' - '9' - 1);
      else {result = BAD_ESC; ptrPat--; return '\xff';}
    gottenChar = gottenChar<<HEX_BITS | i;
  } while (gottenChar < MAX_CHAR);
  return (char)(gottenChar & MAX_CHAR);
}

char *catenate(const Zone zones[])
/* Dynamically allocate, and fill, the string result of concatenating all
   'zone's in 'zones' (end = zone whose 'begAddr' field is NULL). 
   Returns NULL iff memory overflow. */
{
  char *buffer, *result;
  size_t bufSize = 1;  /* for ending '\0' */
  const Zone *ptrZone;

  for (ptrZone = &zones[0]; ptrZone->begAddr != NULL;)
    bufSize += ptrZone++->lgt;
  if ((result = buffer = malloc(bufSize)) != NULL) {
    for (ptrZone = &zones[0]; ptrZone->begAddr != NULL;) {
      strncpy(buffer, ptrZone->begAddr, ptrZone->lgt);
      buffer += ptrZone++->lgt;}
    *buffer = '\0';}
  return result;
}
