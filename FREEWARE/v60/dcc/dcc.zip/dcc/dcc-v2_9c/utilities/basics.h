#ifndef _BASICS_H
#define _BASICS_H

#include <stdio.h>
#include <stddef.h>
#include "bool.th"

typedef FILE *Stream;
typedef enum {Txt, Bin} CopyMode;
typedef enum {Copy, Append} CopySort;

extern bool copyAppend(const char *inFile, const char *outFile, CopyMode,
						      CopySort) /*~PseudoVoid*/;
extern bool error(const char *msg, const char *);
extern bool fileExist(const char *fileName);
extern bool getLineOfAnyLgt(char **pBuffer, size_t *pBufSize, size_t deltaSize,
								     Stream in);
extern size_t snipLF(char line[]) /*~PseudoVoid*/;

#endif
