typedef float Coord;
extern Coord transfCoo(Coord);
extern void *useless
