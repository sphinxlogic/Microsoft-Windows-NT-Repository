/* DCMAIN.C */
/* Y.L. Noyelle, Supelec, France 1998 */
/* Entry module */
/* Manages command line, source files, character input/output, and errors */

#if defined(__GNUC__) && __GNUC__>=(3)
#  define _POSIX_C_SOURCE 1
#endif

#include <ctype.h>
#include <string.h>
#include <stdlib.h>

#ifndef EXIT_FAILURE
#  define EXIT_SUCCESS	0
#  define EXIT_FAILURE	1
#endif

#if defined(VMS) && !defined(_POSIX_C_SOURCE)
#  define _POSIX_C_SOURCE  0  /* for "fileno" function */
#  include <stdio.h>
#  include <unistd.h>
#  undef _POSIX_C_SOURCE
#elif defined(__BORLANDC__)
#  include <stdio.h>
#  include <Io.h>
#elif defined(_MSC_VER)
#  if ! defined(_POSIX_)
#    ifdef __zyzPosix
#      error Change symbol "__zyzPosix" to another (undefined) name
#    endif
#    define __zyzPosix
#    define _POSIX_
#  endif
#  include <stdio.h>
#  ifdef __zyzPosix
#    undef _POSIX_
#    undef __zyzPosix
#  endif
#  include <Io.h>
#  define isatty(x)	_isatty(x)
#elif defined(__hpux) && !defined(_INCLUDE_POSIX_SOURCE)
#  define _INCLUDE_POSIX_SOURCE
#  include <stdio.h>
#  include <unistd.h>
#  undef _INCLUDE_POSIX_SOURCE
#elif defined(__linux__) && !defined(__USE_POSIX)
#  define __USE_POSIX
#  include <stdio.h>
#  include <unistd.h>
#  undef __USE_POSIX
#else
#  include <stdio.h>
#  include <unistd.h>
#endif

#include "dcmain.h"
#include "dcmain.ph"
#include "dcblk.h"
#include "dcblk.ph"
#include "dcdecl.h"
#include "dcdecl.ph"
#include "dcdir.h"
#include "dcdir.ph"
#include "dcexp.ph"
#include "dcext.h"
#include "dcext.ph"
#include "dcinst.ph"
#include "dcprag.h"
#include "dcprag.ph"
#include "dcrec.h"
#include "dcrec.ph"
#include "dcrecdir.ph"

#ifdef VMS
#  pragma noinline (changeOutStreamTo, copyDirPrefix, createAdjFileName)
#  pragma noinline (declTypBuf, dispUsg, errExit, fmtdMsg, foundOption)
#  pragma noinline (getNxtFName, intrnErr, intrnErrT, mngOptListTok)
#  pragma noinline (mngOptMsgLimit, mngOptVerbose)
#  pragma noinline (nxtChunkOfTxt, restoInclInfoAndPopStk)
#  pragma noinline (searchNxtNL, storeDMacTxt, waitAndAnalAnswer)
#endif

#define CCOpt		"cc"
#define ComputeFileHCode(x) {						       \
  ThCode fileHCode = 0;							       \
									       \
  {register const char *p = x;; while (*p != '\0') {fileHCode +=	       \
						  (ThCode)RealChar(*p); p++;}}
#define DccOptPref	"+z"  /* could be "-z", just the same */
#define DccSymbol	"__dcc"
#define DefineStr	"define "
#define DfltOptVal	(ErrOptVal - 1)
#ifdef VMS
#define DDOpt		"/def="
#define DIOpt		"/incl="
#define DUOpt		"/undef="
#else
#define DDOpt		"-D"
#define DIOpt		"-I"
#define DUOpt		"-U"
#endif
#define EmptyDirName	((TdirName)"\0")
#define ErrDccOption(x) {						       \
  if (lastTrtdFName==NULL && !frstPass) fmtdMsg(x, parArr1);		       \
  argErrFl = True;}
#define ErrOptVal	-1
#define FCIOpt		"fci"
#define IdentHeaderSpace "  "
/*~ zif LitLen(IdentHeaderSpace) != LgtHdrId "Bad 'IdentHeaderSpace' string" */
#define InitHdrFName(x)							       \
  *x++ = (Tchar)False;  /* reset ComposingHdr flag */			       \
  *x++ = (Tchar)0;  /* no added path */					       \
  /*~zif LgtHdrAddedPath != 2 "Problem" */
#define InsidePrefixDCCDFLTS dfltArgsPtr < copDfltArgs + (LitLen(	       \
		 PrefixDCCDFLTS) + 1) /* to be able to filter all '-I'	       \
                                     options found inside PrefixDCCDFLTS. */

#define LgtD(x)		(size_t)*x
#define MinDccOptLgt	4
#define NbBitsWarn	2
#define NbSrcLinesKept	2  /* cannot be easily changed, cf. err() */
#define ResetSpaceAtEndOfLine spaceAtEndOfLine = (wrapFl)? lineSize : INT_MAX
#define SearchAdjFiles(fileName, x)                                            \
  ComputeFileHCode(fileName)						       \
    for (ptrAdjDesc = adjFilesArr; ptrAdjDesc < adjFilesArr +		       \
	 				      usedSizAdjArr; ptrAdjDesc++) {   \
      if (fileHCode==ptrAdjDesc->hCode && (StrEq(fileName,		       \
					      ptrAdjDesc->amendFName) || x)) {
#define SHIFTWARN	(INT_BIT - NbBitsWarn)
/*~zif (uint)WarnMsk>>SHIFTWARN != (1u << NbBitsWarn)-1 "Bad 'NbBitsWarn'"*/
#define SHRT_BIT	CHAR_BIT*sizeof(short)
#define SizeSrcBuffer (SizeSrcMngtBlk - (sizeof(struct {SrcBlkHdr}) + LgtHdrId \
	      + MaxLgtId + 1))  /* +1: for detection of identifiers too long */
#define TxtOptions	"'" DDOpt "', '" DUOpt "', '" DIOpt "'"
#define UndefStr	"undef "

typedef FILE *Tstream;
typedef const TdirChar *TdirName;
typedef TdirChar *TdirNameNC;

typedef struct {
  ThCode hCode;
  bool noLoadSysFile;
  Tstring amendFName;
  Tstring adjFName;
} TadjFilesDesc;

#define SrcBlkHdr							       \
  const TdirName *curInclDir;						       \
  TmngtPriv *listPriv;							       \
  Tstream srcStream;							       \
  const char *ptrS, *oldMaxPtrS, *endSrcChunk, *nxtEndSrcChunk;		       \
  TlineNb lineNb;

typedef struct {
  SrcBlkHdr
  char idPlusSrc[LgtHdrId + MaxLgtId + 1 + SizeSrcBuffer];
} TsrcMngtBlk;

typedef struct _inclStkElt TinclStkElt;
struct _inclStkElt {
  TsrcMngtBlk *srcMngtBlk;
  TundfTagElt *headUTList;
  Tstring curHdrFName;
  Tstring fileName;
  union {
    struct {
      bool _insideHdrFile:1;
      bool _insideHdrInHdr:1;
      bool _sysHdrFile:1;
      bool _diffLc:1;
      int :CHAR_BIT - 1 - 1 - 1 - 1;  /* 'portable' padding */
      int :CHAR_BIT;  /* cannot be grouped with previous one */
      TindentChk _indentIncr:SHRT_BIT;
    } s1;
    TmemoryUnit bid;
  } inclInfo;
  TinclStkElt *prev;
};
/*~zif __bitoffset(((TinclStkElt *)0)->inclInfo.s1, _indentIncr) != SHRT_BIT
				"Inefficient layout for structure 'inclInfo'" */
#define InsideHdrFile	inclInfo.s1._insideHdrFile
#define InsideHdrInHdr	inclInfo.s1._insideHdrInHdr
#define ShdrFile	inclInfo.s1._sysHdrFile
#ifdef LcEqUc
#define DiffLc		inclInfo.s1._diffLc
#endif
#define IndentIncr	inclInfo.s1._indentIncr

typedef struct _incldInBlk TincldInBlk;
struct _incldInBlk {
  Tstring includedFName, includingFName;
  TlineNb lineNb;
  TincldInBlk *prev;
};

typedef struct {
  Tstring fileName;
  TlineNb lineNb;
} TposInSrc;

typedef uint TmsgCtr;

/* Function profiles */
static TincldInBlk *allocIncldFElt(void), *freeIncldFElt(TincldInBlk *);
static TinclStkElt *allocInclStkElt(void), *freeInclStkElt(TinclStkElt *);
static const char *manageEndInclude(void);
static const char *searchNxtNL(const char *, ptrdiff_t);
/****static char *trigraph(const char *, char *);*/
static void changeOutStreamTo(Tstream), checks(void), closeSource(void),
  declTypBuf(void), dispUsg(void), emitCh(const char *, const char *),
  emitC(char), emitFName(Tstring),
  errExit(Terr, const Tstring *) /*~NeverReturns*/,
  fatalErr(Terr, Tstring) /*~NeverReturns*/,
  flushAndExit(void) /*~NeverReturns*/,
  initAdjFiles(void), initAll(void), initEmitC(void), initMain(void),
  intrnErr(Tstring, uint *), intrnErrT(Tstring, uint *),
  openSrcFile(Tstring), resetArgPtr(void), resetOptions(void),
  restoInclInfoAndPopStk(TinclStkElt *), storeDMacTxt(Tchar);
static void mngOptListTok(void), mngOptMsgLimit(void), mngOptVerbose(void);
static bool fmtdMsg(Terr n, const Tstring *parArr) /*~PseudoVoid*/,
  foundOption(Tstring, bool *), isDccOption(Tstring), isHeaderFile(Tstring),
  isSrcFName(Tstring), openSrcFile1(Tstring),
  prmtrzMsg(Tstring, const Tstring *) /*~PseudoVoid*/,
  processCUnit(Tstring, bool), recursiveInclusion(Tstring),
  waitAndAnalAnswer(void) /*~PseudoVoid*/;
static TdirName copyDirPrefix(Tstring, size_t);
static TundfTagElt *freeUndfTagElt(TundfTagElt *);
static Tstring getNxtArg(void);
#ifdef LcEqUc
static bool sameLowerCaseName(const char *, const char *, bool);
#endif
static TposInSrc srchPosInclLvl0(const TinclStkElt *);

/* Global variables */
static Tstring adjFiles;
static TadjFilesDesc *adjFilesArr = NULL;
static char *begLastTokBuf = NULL;
static bool callCompil;
static bool callCompilSeen = False;
static bool callCompilW;
static int carriagePosition = -1;
static bool chkIndent;
static bool chkPossErr;		/* check various possible errors */
static bool chkRdbl;		/* check readability */
static Tstring compilerName;
static int compilerStatus = EXIT_SUCCESS;
static TstringNC copDfltArgs, dfltArgsPtr;
static TmsgCtr ctrErr;
static uint ctrdI;
static TmsgCtr ctrIgndMsg;
static uint ctrIIB = 0;		/* number of header files included inside a
								       block. */
static uint ctrISE = 0;		/* number of '#include' stack elements */
static TmsgCtr ctrWarn;
static long cumNbLines;		/* cumulated number of lines processed */
static TsrcMngtBlk *curSrcMngtBlk = NULL;
static Tstring dccDir;
static uint dccDirLgt;
static int deltaPtrS = 0;	/* device to limit size of loaded chunk while
					searching next NL (cf searchNxtNL()). */
static Tstring dfltArgs;
static TdirName *dirArray;	/* array of directory prefixes for 'include'
								       files. */
static bool emitTrailer;
static const Tchar *endDMacBuf;
static const char *endLastTokBuf;
static const char *endSBuf;		/* end of source buffer */
static bool errSeen = False;
static bool existErr;
static bool frstPass = False;
static bool givAlwsFName;
static TincldInBlk *headListIIB = NULL; /* head of list of header files included
					inside a block (which may cause surprise
					if re-included thereafter...). */
static bool heedDccOption;
static int initMsgLimit;
static bool fullVerbose;
static bool interactivOutptDev;
static Tstring lastTrtdFName = NULL;
static size_t lgtCmdBuf;	/* length of command buffer */
static size_t lgtLastTokBuf;	/* length of "last tokens" buffer */
static int lineSize = DfltLineSize;
static bool listTok;		/* flag 'list last tokens on error' */
static uint lvlNoCompil;
static uint minMsgLvl;
static bool moreInfMsg;
static TmskFrstChId sMskFrstChId, sMskFrstChId1;
static int msgLimit;
static bool msgLimitFl;
static bool notCompiled = False;
static const char *nxtEndSrcChunk;
static Tstring oldLastTrtdFName = NULL;
static const char *oldMaxPtrS;  /* end of logical (circular) source buffer */
static bool oldMIM;
static int optionValue = DfltOptVal;
static Tstream outputStream;
static bool ovfldTokBuf;
static CreateParArr((1));
static const Tstring *pArg;
static char *pLastTokBuf;	/* pointer inside last tokens buffer */
static TposInSrc posLastInclWa;	/* position of last AlrdIncldInBlk warning */
static Tchar *pStoDMacTxt;
static TinclStkElt *pTopInclStk = NULL;
static int realCaretPosition, realCaretPosition1;
static bool reportHghsWaFl;
static bool screenMsgPass2;
static bool signalAllErr;
static int spaceAtEndOfLine = 0; /* number of remaining character slots at end
				      of current line (see 'emitC' function). */
static Tstream srcStream;
static bool stopAfterMsg;
static Tstring sysHdrDir = SysHdrDir;
static size_t totalSizAdjArr = 0;
static int transfSize;
static size_t usedSizAdjArr = 0;
static const Tstring *valInitParg;
static bool warnFl;
static bool warnSeen = False;
static bool wrapFl;
static const Ttok zSCol[] = {NoSwallowTok, SCOL, EndSTok};

/* External variables */
char *begSBuf;	/* beginning of source buffer (circular buffer) */
const char *endSrcChunk;
bool frstLineOfFile;
const char *nlPosP1;  /* 1 + position of last seen 'newline' character */
const char *savSrcPtr;
const char *srcPtr;  /* source pointer */
Tstring starterFile;
TindentChk tabSpacing = DfltTabSpacing;

int main(int argc, const Tstring *argv)
{
  Tstring lastFName = NULL;
  bool argErrFl = False;

  outputStream = MAIN_OUT_STREAM;
  initEmitC();
  valInitParg = argv;
  if (argc == 1) dispUsg();
  else {
    interactivOutptDev = isatty(fileno(MAIN_OUT_STREAM)) > 0;
    {
      Tstring w;
      TstringNC w1;
      size_t lgt;

      if ((w = getenv("DCCFILES"))==NULL || *w=='\0') w = DccExecFilesDir;
      lgt = strlen(w) + (LitLen(DirSepar) + 1);
      MyAlloc(dccDir = w1, lgt);
      strcpy(w1, w);
      if ((w1 = strchr(w1, '|')) != NULL) {
        *w1++ = '\0';
        memmove((char * /*~OddCast*/)(sysHdrDir = w1 + LitLen(DirSepar)), w1,
					      lgt - (size_t)(w1 - dccDir) + 1);}
      strcat((char * /*~OddCast*/)dccDir, DirSepar);
      MyAlloc(starterFile = w1, (dccDirLgt = (uint)strlen(dccDir)) + (LitLen(
							     StarterFile) + 1));
      strcpy(w1, dccDir);
      strcat(w1, StarterFile);
      MyAlloc(adjFiles = w1, dccDirLgt + (LitLen(AdjFiles) + 1));
      strcpy(w1, dccDir);
      strcat(w1, AdjFiles);}
    if ((dfltArgs = getenv("DCCDFLTS")) == NULL) dfltArgs = "";
    MyAlloc(copDfltArgs, strlen(dfltArgs) + (LitLen(PrefixDCCDFLTS) + 1));
    /* Search position of last file name in command line, so as to process it
       with all indicated options, even ones met after that file name. */
    {
      Tstring arg;

      resetArgPtr();
      while ((arg = getNxtArg()) != NULL) {
        if (isSrcFName(arg)) lastFName = arg;
#ifndef VMS
        else if (strcmp(arg, "-o") == 0) {
          if ((arg = getNxtArg()) == NULL) break;
          if (isSrcFName(arg) || isHeaderFile(arg)) errExit(BadOOption, NULL);}
#endif
      }}
rescanOptL:  /* back here if more than one compilation unit to process; all
						previous options re-explored. */
    initAll();
    enterBlock();
    cUnitFName = NULL;  /* for starter file */
    openSrcFile(starterFile);
    dollAlwdInId = True;
    prog();
    closeSource();
    initAdjFiles();  /* here, because uses symbol defined in starter file */
    dollAlwdInId = False;
    cUnitFName = curFileName = "";  /* for -D, -U options processing (call to
				 'manageDir', which may record these values). */
    {
      Tstring arg;

      resetArgPtr();
      ctrdI = 0;  /* number of '-I' options */
      lgtCmdBuf = 0;  /* length of command buffer */
      while ((arg = getNxtArg()) != NULL) {
        if (isDccOption(arg)) {  /* take dcc options into account immediatly,
		  because management of options -D, -U, -I may create errors. */
          bool bidFl;

          parArr1[1] = arg;
          if (foundOption("ac", &askConstFl)) {}
          else if (foundOption("ae",  &signalAllErr)) {}
          else if (foundOption("afn", &givAlwsFName)) {}
          else if (foundOption("bo",  &chkBool)) {}
          else if (foundOption(CCOpt, &callCompil)) {
            if (callCompil) compilerName = (optionValue != DfltOptVal)? (
			optionValue = DfltOptVal, arg + (LitLen(DccOptPref) +
							LitLen(CCOpt))) : NULL;}
          else if (foundOption("cin", &sameIndent)) {
            if (sameIndent) chkIndent = sameIndent;}
          else if (foundOption("cw",  &callCompilW)) {}
          else if (foundOption("dol", &dollAlwdInId)) {}
          else if (foundOption("efi", &chkEffic)) {}
          else if (foundOption("epl", &chkEmptParList)) {}
          else if (foundOption(FCIOpt, &bidFl)) {
            if (optionValue != DfltOptVal) {
              int prevGrpNb = -1, grpNb = -1;
              const Tchar *optPtr = arg + (LitLen(DccOptPref) + LitLen(FCIOpt));
              TmskFrstChId curGrpMsk;

              for (;;) {
                const Tchar curOptChar = *optPtr++, *posCh;
                static const  Tchar letterList[] = "vgefxptsmrnaq";  /* order
			  imposed by values of PMskXXX, cf. file 'dcdecl.ph". */

                if ((posCh = strchr(letterList, ToLower(curOptChar))) != NULL) {
                  grpNb = (int)(posCh - &letterList[0]);
                  if (grpNb != prevGrpNb) {  
                    if (prevGrpNb >= 0) {  /* store previous mask element */
                      TmskFrstChId *pMsk = ((prevGrpNb *= NbBitsDscId) <= (32)
			/* 'long's always at least on 32 bits */ - NbBitsDscId)
			 ? &mskFrstChId : (prevGrpNb -= PMskEnu, &mskFrstChId1);

                      *pMsk = *pMsk & ~(AllBitsFI << prevGrpNb) | (curGrpMsk
								 << prevGrpNb);}
                    if (curOptChar == '\0') {optionValue = DfltOptVal; break;}
                    prevGrpNb = grpNb;
                    curGrpMsk = (bidFl)? 0 : AllBitsFI;}
                  curGrpMsk |= (*optPtr == '/')
				? (optPtr++, BitUnd)
				: (IsUpper(curOptChar))
				   ? BitUpp
				   : BitLow;}
                else if (curOptChar == '_' && grpNb>=0) curGrpMsk |= BitUnd;
                else break;}}
            else {
              mskFrstChId = (bidFl)? DfltMskFrstChId : ~0u;
              mskFrstChId1 = (bidFl)? DfltMskFrstChId1 : ~0u;}
            if (goodPrgmg) {sMskFrstChId = mskFrstChId; sMskFrstChId1 =
								 mskFrstChId1;}}
          else if (foundOption("frt", &chkFctRetTyp)) {}
          else if (foundOption("gpr", &goodPrgmg)) {
            mskFrstChId = (chkBool = chkFctRetTyp = chkInclPos = chkNumCst =
						 goodPrgmg)? sMskFrstChId : ~0u;
            mskFrstChId1 = (goodPrgmg)? sMskFrstChId1 : ~0u;}
          else if (foundOption("inc", &chkInclPos)) {}
          else if (foundOption("ind", &chkIndent)) {}
          else if (foundOption("kwm", &kwAsMacName)) {}
          else if (foundOption("lt",  &listTok)) {
            if (optionValue >= MaxLgtId + 1) {lgtLastTokBuf = (size_t)
					 optionValue; optionValue = DfltOptVal;}
            else lgtLastTokBuf = (uint)lineSize - strlen(errTxt[LastToks]) -
			   (LitLen(Dots) - 1);  /* so that just one line used */
            mngOptListTok();}
          else if (foundOption("lvl", &bidFl)) {
            if (! bidFl) {
              if (optionValue>0 && optionValue<=(int)((uint)WarnMsk>>SHIFTWARN
									    )) {
                lvlNoCompil = (uint)optionValue;
                optionValue = DfltOptVal;}}
            else lvlNoCompil = ((uint)WarnMsk>>SHIFTWARN) + 1;}
          else if (foundOption("mcc", &verifAllPtrForConst)) {
            if (verifAllPtrForConst) askConstFl = verifAllPtrForConst;}
          else if (foundOption("mic", &moreIndexTypeChk)) {}
          else if (foundOption("mpo", &morePrtblChk)) {}
          else if (foundOption("msg", &msgLimitFl)) {
            if (optionValue >= 0) {
              initMsgLimit = optionValue;
              optionValue = DfltOptVal;}
            mngOptMsgLimit();}
          else if (foundOption("nui", &warnNUI)) {}
          else if (foundOption("nup", &warnNUP)) {}
          else if (foundOption("nw",  &noWarn)) {}
          else if (foundOption("pe",  &chkPossErr)) {}
          else if (foundOption("pnt", &chkNmdTypParFl)) {}
          else if (foundOption("po",  &chkPortbl)) {}
          else if (foundOption("rd",  &chkRdbl)) {}
          else if (foundOption("rhw", &reportHghsWaFl)) {
            if (reportHghsWaFl) signalAllErr = False;}
          else if (foundOption("rst", &bidFl)) {
            if (bidFl) resetOptions();}
          else if (foundOption("sam", &stopAfterMsg)) {
            if (! interactivOutptDev) stopAfterMsg = False;}
          else if (foundOption("sy",  &printStat)) {}
          else if (foundOption("tab", &bidFl)) {
            if (bidFl && optionValue>0) {
              tabSpacing = (TindentChk)optionValue;
              optionValue = DfltOptVal;}
            else tabSpacing = DfltTabSpacing;}
          else if (foundOption("tr",  &emitTrailer)) {}
          else if (foundOption("typ", &fullVerbose)) declTypBuf();
          else if (foundOption("uc",  &chkNumCst)) {chkArrBnd = chkNumCst;}
          else if (foundOption("udt", &chkUCTags)) {}
          else if (foundOption("usg", &bidFl)) {if (bidFl) dispUsg();}
          else if (foundOption("ve",  &moreInfMsg)) {
            oldMIM = moreInfMsg;
            mngOptVerbose();}
          else if (foundOption("vve", &bidFl)) {
            if (bidFl != fullVerbose) moreInfMsg = (bidFl)? (oldMIM =
		moreInfMsg, True) : oldMIM;  /* +zvve implies +zve, -zvve
					    returns to previous value of zve. */
            fullVerbose = bidFl;
            declTypBuf();}
          else if (foundOption("wa",  &warnFl)) {}
          else if (foundOption("wr",  &wrapFl)) {
            if (wrapFl) {
              if (optionValue < 0) lineSize = DfltLineSize;
              else if (optionValue >= MaxLgtId) {
                lineSize = optionValue;
                optionValue = DfltOptVal;}
              initEmitC();}}
          else if (foundOption(".", &bidFl)) {}
          else ErrDccOption(UnknOption)
          if (optionValue != DfltOptVal) {
            ErrDccOption(IgndCharsOpt)
            optionValue = DfltOptVal;}}
        else {
          int dOptionSeen;

          if (strncmp(arg, DIOpt, LitLen(DIOpt)) == 0) {
            ctrdI++; /* count number of '-I' options */
            if (InsidePrefixDCCDFLTS) continue;}  /* do not transmit to compiler
					'-I' options found in PrefixDCCDFLTS. */
          else if ((dOptionSeen = strncmp(arg, DDOpt, LitLen(DDOpt)))==0 ||
		  strncmp(arg, DUOpt, LitLen(DUOpt))==0) {  /* '-D/-U' option */
            for (;;) {  /* fake loop (to avoid 'goto's) */
              Tchar c, bufDef[MaxMacroLgtInCmd + LgtHdrId + 1 + 1];  /* +1 for
			EndCh, +1 for overflow detection; space for identifier
			header needed in front of any source buffer that can
			begin with an identifier and is processed via
			getTokFromTxt(). */
              register Tstring ptrInArg;

              if (dOptionSeen == 0) {
                strncpy(&bufDef[LgtHdrId], DefineStr, LitLen(DefineStr));
                pStoDMacTxt = &bufDef[LgtHdrId +LitLen(DefineStr)]/*~LocalAdr*/;
                ptrInArg = &arg[LitLen(DDOpt)];}
              else {
                strncpy(&bufDef[LgtHdrId], UndefStr, LitLen(UndefStr));
                pStoDMacTxt = &bufDef[LgtHdrId + LitLen(UndefStr)]/*~LocalAdr*/;
                ptrInArg = &arg[LitLen(DUOpt)];}
              endDMacBuf = &bufDef[NbElt(bufDef)] /*~LocalAdr*/;
              while (c = *ptrInArg++, isAlnu(c)) storeDMacTxt(c);  /* store
								  macro name. */
              if (dOptionSeen == 0) {
                if (c == '\0') {
                  storeDMacTxt(' ');
                  storeDMacTxt('1');}  /* "1" is default macro text */
                else {
                  if (c == '(') {
                    do {
                      do {storeDMacTxt(c);} while (c = *ptrInArg++, isAlnu(c));
						/* store macro parameter name */
                    } while (c == ',');
                    c = (c != ')')? '\0' : (storeDMacTxt(c), *ptrInArg++);}
                  lgtCmdBuf += (2);  /* because a pair of double quotes will
					       be put around '/DEF' argument. */
                  if (c != '=') {errWS(BadDOption | Warn2, arg); break;}
                  /* Copy macro body */
                  c = ' ';
                  do {
                    storeDMacTxt(c);
                  } while ((c = *ptrInArg++) != '\0');}}
              if (c != '\0') {errWS(BadDOption | Warn2, arg); break;}
              storeDMacTxt(EndCh);  /* 'FileClosed'=True here */
              endSrcChunk = NULL;  /* previous EndCh = end of pseudo-file */
              if (pStoDMacTxt >= endDMacBuf /* buffer overflow*/) {errWS(
					       BadDOption | Warn2, arg); break;}
              /* Prepare to print pseudo source line in case of error */
              dirLineFl = True; /* for 'manageDir()', but also allows printing
						     of source line on error. */
              nlPosP1 = srcPtr = begSBuf = &bufDef[LgtHdrId] /*~LocalAdr*/;
              frstLineOfFile = True;
              oldMaxPtrS = endDMacBuf;
              if (listTok) storeTokTxt(" #");
              manageDir();
              ClrSmshCh;
              break;}}
          lgtCmdBuf += strlen(arg) + 1;  /* +1 because of separating space */
          if (isSrcFName(arg)) {
            if (arg != lastFName) {  /* because, for last compilation unit,
		    possible following options also to be taken into account. */
              if (lastTrtdFName != NULL) {  /* skip already processed
							   compilation units. */
                if (arg == lastTrtdFName) {
                  oldLastTrtdFName = lastTrtdFName;
                  lastTrtdFName = NULL;}}
              else {  /* process new compilation unit */
                if (processCUnit(arg, False)) {
                  if (notCompiled) goto exitL;
                  lastTrtdFName = arg;
                  if (emitTrailer) {
                    uint i = (uint)lineSize/LitLen(SeparPattern);

                    for (; i > 0; i--) emitS(SeparPattern);
                    emitC('\n');}}
                goto rescanOptL /*~BackBranch*/;}}}}}
      if (! processCUnit(lastFName, True)) goto rescanOptL /*~BackBranch*/;}}
exitL:
  changeOutStreamTo(NULL);
  if (compilerStatus != EXIT_SUCCESS) return compilerStatus;
  if (argErrFl) return EXIT_ERRORS2;
  return (errSeen)
         ? (callCompilSeen)
           ? EXIT_ERRORS2
           : EXIT_ERRORS1
         : (warnSeen)
           ? (notCompiled)
             ? EXIT_WARNINGS2
             : EXIT_WARNINGS1
           : EXIT_SUCCESS;
}

static bool processCUnit(Tstring cUFName, bool lastFile)
/* Returns False iff first pass (there is a 'first pass' only if the maximum
					      warning level has to be found). */
{
  TdirName *ptrDirArray;  /* pointer in array of directories for 'include'
								       files. */
  char *cmdBuf, *ptrCmdBuf;
  register Tstring arg;
  bool fNameSeen = False;
#ifdef VMS
  int dOptFlg = 1;
#endif

  /* Determine if there is to be a 'first pass', and then if second pass is to
     report only highest level messages. */
  screenMsgPass2 = (frstPass && minMsgLvl!=0);
  frstPass = (frstPass || signalAllErr)? False : reportHghsWaFl;
  /* Get compiler name (if not given by 'zcc' option) */
  if (compilerName == NULL) {
    TlitString w;
    static char locBuf[] = IdentHeaderSpace DccSymbol ";";  /* ';' for
						     getLitString() workings. */

    getTokLvl++;  /* prevent tokens from showing in '+zlt' buffer */
    srcPtr = &locBuf[LgtHdrId];
    if (NxtTok()!=CSTST || (w = getLitString(), srcPtr != AdLastEltP1(locBuf)
						  - 1)) errExit(BadUUdcc, NULL);
    lgtCmdBuf += initGetStrLit(w);
    getTokLvl--;}
  else lgtCmdBuf += strlen(compilerName);
  /* Allocate array of directory prefixes for 'include' files */
  MyAlloc(dirArray, (ctrdI + (3))*sizeof(*dirArray));  /* +3 because of
			compilUnitFile directory, SysHdrDir, and ending NULL. */
  /* Allocate buffer for compile command (will be executed via the 'system'
								   function). */
  ptrCmdBuf = cmdBuf = allocPermSto(lgtCmdBuf);
  while ((*ptrCmdBuf = (compilerName == NULL)? nxtStrLitChar() :
		 *compilerName++) != '\0') ptrCmdBuf++;  /* put compiler name */
  if (compilerName == NULL) {resetGetStrLit(); exitBlock();}  /* because of
							    'getLitString()'. */
  cUnitFName = NULL;
  resetArgPtr();
  ptrDirArray = dirArray + 1;
  while ((arg = getNxtArg()) != NULL) {

    if (isDccOption(arg)) continue;  /* do not transmit to compiler */
    if (strncmp(arg, DIOpt, LitLen(DIOpt)) == 0) {  /* '-I' option */
      const TdirName *w;
      size_t lgtName;

      paramTxt = arg + LitLen(DIOpt);
      lgtName = strlen(paramTxt);
      for (w = dirArray + 1; w != ptrDirArray;)
        if (memcmp(*w++ + PosLgtAddedPath, paramTxt, lgtName) == 0) {err1(
					  AlrdIndicFile|Warn1|Rdbl); continue;}
      *ptrDirArray++ = copyDirPrefix(paramTxt, lgtName);
      if (InsidePrefixDCCDFLTS) continue;}  /* do not transmit to compiler '-I'
					     options found in PrefixDCCDFLTS. */
    else if ((
#ifdef VMS
              dOptFlg = 
#endif
                        strncmp(arg, DDOpt, LitLen(DDOpt)))==0
             || strncmp(arg, DUOpt, LitLen(DUOpt))==0) {}  /* '-D'/'-U' option
						       already taken care of. */
    else {
      fNameSeen = True;
      if (arg != cUFName) {
#ifdef VMS  /* else, whole command line given (once) to compiler (because of \
						       possible '-o' option). */
        if (isSrcFName(arg)) continue;  /* ignore already processed
                                                       compilation unit name. */
#endif
      }
      else {
        Tstring begOfFName;
        size_t lgtPath;

        begOfFName = skipPath(arg);
        lgtPath = (size_t)(begOfFName - arg);
        *dirArray = (lgtPath != 0)? copyDirPrefix(arg, lgtPath) :
							       &EmptyDirName[0];
        {
#ifdef VMS
          /* Add '.c' type suffix if none */
          size_t suffLgt = (SearchDot(begOfFName) == NULL)? LitLen(
					      CSuffix) /* no type suffix */ : 0;
          Tstring w;
          size_t posVersNb = (((w = strchr(begOfFName, ';')) == NULL)?
				 strlen(begOfFName) : (size_t)(w - begOfFName));
          TstringNC wm;

          wm = allocPermSto(strlen(arg) + suffLgt + (LgtHdrAddedPath + 1));
          InitHdrFName(wm)
          strncpy(wm, arg, lgtPath + posVersNb);
          if (suffLgt != 0) strcpy(wm + lgtPath + posVersNb, CSuffix);
          strcpy(wm + lgtPath + posVersNb + suffLgt, begOfFName +
					   posVersNb);  /* add version number */
          cUnitFName = wm;
          posVersNb += suffLgt;
          strpdCUnitFName = wm = allocPermSto(posVersNb + 1);
          strncpy(wm, cUnitFName + lgtPath, posVersNb);
          *(wm + posVersNb) = '\0';  /* remove possible version number (cf.
                                                          isFNameVisible() ). */
#else
          TstringNC wm;

          wm = allocPermSto(strlen(arg) + (LgtHdrAddedPath + 1));
          InitHdrFName(wm)
          strcpy(wm, arg);
          cUnitFName = wm;
          strpdCUnitFName = begOfFName;
#endif
        }}}
    /* Add argument to compiler command line */
    *ptrCmdBuf++ = ' ';  /* separating space */
#ifdef VMS
    /* Add possible double quotes around '/DEF' argument */
    {
      bool dQuote = False;

      while (*arg!= '\0') {
        *ptrCmdBuf++ = *arg++;
        if (dOptFlg==0 && !dQuote && *arg=='=') {*ptrCmdBuf++ = '='; *ptrCmdBuf
					      ++ = '\"'; arg++; dQuote = True;}}
      if (dQuote) *ptrCmdBuf++ = '\"';
    }
#else
    while (*arg!= '\0') *ptrCmdBuf++ = *arg++;
#endif
    if (cUnitFName!=NULL && !lastFile) break;}
  *ptrCmdBuf = '\0';  /* ending NUL */
  if (!fNameSeen || cUnitFName==NULL && !callCompil) errExit(NoCUName, NULL);
  *ptrDirArray++ = copyDirPrefix(sysHdrDir, strlen(sysHdrDir));
  *ptrDirArray = NULL;
  if (cUnitFName != NULL) {  /* if something to compile, do not skip to link */
    if (! chkIndent) indentIncr = 0;
    boolTypeElt.typeSort = boolCstTypeElt.typeSort = boolTypeElt1.typeSort = 
		  (chkBool)? (mskBool = Bool|BoolOpnd, Bool)
			   : (mskBool = NumEnumBool|PtrPoss|BoolOpnd, Int|Bool);
    posLastInclWa.lineNb = 0;
    cumNbLines = cumDeltaLineNb = cumNbSkippedLines = 0;  /* may have been
				    modified by 'starter' or 'initAdj' files. */
    {
      Terr err = CompHdrFile;

      if (isHeaderFile(cUnitFName) || (err = InaccFile, !openSrcFile1(
					   cUnitFName))) errWS(err, cUnitFName);
      else {
        prog();
        cumNbLines += lineNb - 1 + cumDeltaLineNb - cumNbSkippedLines;
        freeTypeCmbn();
        /* Reset list of header files included inside a block */
        while (headListIIB != NULL) headListIIB = freeIncldFElt(headListIIB);
        (void)ctrIIB;}}
    exitBlock();
    checkCondCompilStk();
    deleteRemainingMacros();
    closeSource();  /* lineNb not used any more here */ 
    checks();
  }
  free(dirArray);
  if (ctrIgndMsg == 0) frstPass = False;
  if (frstPass) {
    if (ctrIgndMsg < FrstFewMsg) minMsgLvl = 0;  /* so as to report all
								    messages. */
    lastTrtdFName = oldLastTrtdFName;
    return False;}
  changeOutStreamTo(SUMMARY_STREAM);
  if (cUnitFName != NULL) {
    bool errWa = (bool)(ctrErr | ctrWarn | ctrIgndMsg);

    if (errWa || emitTrailer) {
      CreateParArr((4)) /*~DynInit*/;

      parArr4[1] = cUnitFName;
      parArr4[2] = grstIntToS(cumNbLines);
      prmtrzMsg(errTxt[EndMsg], parArr4);
      if (errWa) {
        TnbBuf buf, buf1;

        bufGrstIntToS((TgreatestInt)ctrErr, buf);
        parArr4[1] = &buf[0];
        parArr4[2] = grstIntToS((TgreatestInt)ctrWarn);
        parArr4[3] = errTxt[IgndMsgs];
        bufGrstIntToS((TgreatestInt)ctrIgndMsg, buf1);
        parArr4[4] = &buf1[0];
        prmtrzMsg(errTxt[ErrWarn], parArr4);}
      else emitS(errTxt[NoErrWarn]);
    }}
  if (ctrWarn != 0) {warnSeen = True; if (! callCompilW) notCompiled = True;}
  if (ctrErr!=0 || existErr || minMsgLvl>=lvlNoCompil) {
    errSeen = True;
    if (callCompil) {
      callCompilSeen = True;
      if (ctrErr == 0) {
        parArr1[1] = grstIntToS((TgreatestInt)lvlNoCompil);
        prmtrzMsg(errTxt[NotCompild], parArr1);}}}
  else if (callCompil && (callCompilW || ctrWarn==0)
#ifndef VMS
						     && lastFile
#endif
								) {
    int w;

    changeOutStreamTo(NULL);
    w = system(cmdBuf);  /* call compiler */
    if (compilerStatus == EXIT_SUCCESS) compilerStatus = w;}
  changeOutStreamTo(MAIN_OUT_STREAM);
  return True;
}

void addIncldFilesToPriv(bool privToFl)
/* If *~Private* found inside 'normal' file included by header file, add
   'normal' file name(s) to list, besides adding header file name and corres-
   ponding body file name.
   Add only current file if 'privToFl' = False. */
{
  const Tchar *posDot, *nakedFName = IndicatedFName(curFileName);
  const TinclStkElt *pIncl = pTopInclStk;

  enterBlock();  /* for string storage reclaiming purpose */
  for (posDot = NULL;;) {
    register const Tchar *ptrC = nakedFName - 1;
    TlitString fileName = ptrFreeIdSpace();

    do {storeStrCh(*++ptrC);} while (ptrC!=posDot && *ptrC!='\0');
    if (posDot != NULL) {  /* creates corresponding body file name */
      ptrC = &CSuffix[0];
      do {storeStrCh(*++ptrC);} while (*ptrC != '\0');}
    processPriv(fileName, False);
    if (!privToFl || posDot!=NULL) break;
    if (nakedFName == curHdrFName) posDot = SearchDot(nakedFName);
    else {
      nakedFName = IndicatedFName(pIncl->fileName);
      pIncl = pIncl->prev;}}
  exitBlock();
}

static AllocXElt(allocIncldFElt, TincldInBlk, ctrIIB, ;)
static AllocXElt(allocInclStkElt, TinclStkElt, ctrISE, ;)

static void changeOutStreamTo(Tstream x)
{
  static bool errSeen = False;

  if (spaceAtEndOfLine < 0) {emitC('\n'); ResetSpaceAtEndOfLine;}  /* flush
								     emitC(). */
  if (!errSeen && fflush(outputStream)!=0) {errSeen = True; sysErr(ExCod2);}
  if (x != NULL) outputStream = x;
}

static void checks(void)
{
  if (nestLvl != -1) {intrnErr("nestLvl", (uint *)&nestLvl); nestLvl = -1;}
  intrnErrT("dpragNst", &dpragNst);
  if (ctrBSE > 1)  intrnErr("ctrBlkStkElt",  &ctrBSE);
  intrnErrT("ctrCaseElt",    &ctrCE);
  intrnErrT("ctrCondStkElt", &ctrCSE);
  intrnErrT("ctrDeclElt=",   &ctrDE);
  intrnErrT("ctrDescIdElt",  &ctrDIE);
  intrnErrT("ctrInclStkElt", &ctrISE);
  intrnErrT("ctrMngInitlzUsdElt", &ctrIU);
  intrnErrT("ctrMacroBlk",   &ctrMSB);
  intrnErrT("ctrMacStkElt",  &macLvl);
  intrnErrT("ctrNotInitVarElt", &ctrNI);
  if (ctrNSB > (3) /* 3 because first name block never freed, and two other
			may be kept not freed (see exitBlock() ). */
		 ) intrnErr("ctrNameStoBlk", &ctrNSB);
  intrnErrT("ctrQlfdTypesElt", &ctrQL);
  intrnErrT("ctrSemanElt",   &ctrSE);
  intrnErrT("ctrSavStrLitElt", &ctrSSL);
  intrnErrT("ctrTypCombElt", &ctrTCB);
  intrnErrT("ctrTypeElt",    &ctrTE);
  intrnErrT("ctrTagListElt", &ctrTLE);
  intrnErrT("ctrUndfTagElt", &ctrUT);
  intrnErr("", NULL);  /* flush buffer */
}

static void closeSource(void)
{
  free(curSrcMngtBlk); /* do not free curFileName, because name may still
					be used (eg. in a 'NotUsed' warning). */
  curSrcMngtBlk = NULL;
  lineNb = 0;  /* indicates "no valid source line" */
}

static TdirName copyDirPrefix(Tstring string, size_t lgt)
{
  TdirNameNC res;

  if (lgt >= UCHAR_MAXC) {parArr1[1] = string; errExit(StringTooLong, parArr1);}
  res = allocPermSto(lgt + (PosLgtAddedPath + 1));  /* +1 for ending '/' */
  memcpy(res + PosLgtAddedPath, string, lgt);
#ifdef VMS
  /*~zif LitLen(DirSepar) != 0 "Following line to be completed !!!" */
  *res = (TdirChar)lgt;
#else
  /*~zif LitLen(DirSepar) != 1 "Following lines to be amended !!!" */
  *res = (TdirChar)(lgt + 1);
  *(res + lgt + PosLgtAddedPath) = (TdirChar)DirSepar[0];
#endif
  return res;
}

static TstringNC createAdjFileName(Tstring fName)
{
  TstringNC fullAdjFileName;
  uint fnLgt = (uint)(SearchDot(fName) - fName) + 1;

  fullAdjFileName = allocPermSto(dccDirLgt + fnLgt + (LitLen(AdjSuffix) + 1));
  strcpy(fullAdjFileName, dccDir);
  strcpy(fullAdjFileName + dccDirLgt, fName);
  strcpy(fullAdjFileName + dccDirLgt + fnLgt, AdjSuffix);
  adjustFile = True;
  return fullAdjFileName;
}

static void declTypBuf(void)
{
  if (fullVerbose && !InsideInterval(optionValue, ErrOptVal,
						      (int)LitLen(Dots) - 1)) {
    initTypBuf((optionValue >= 0)? optionValue : lineSize*(2 /* arbitrary */));
    optionValue = DfltOptVal;}
  mngOptVerbose();
}

static void dispUsg(void)
{
  TnbBuf buf;
  CreateParArr((4)) /*~DynInit*/;
  bool interactive;
  uint msgNb = 0;
  static Terr msgTbl[] = {Use1, Use2, Use3};

  bufGrstIntToS(lineSize, buf);
  parArr4[1] = *valInitParg;
  parArr4[2] = grstIntToS(DfltTabSpacing);
  parArr4[3] = &buf[0];
  parArr4[4] = TxtOptions;
  interactive = (isatty(fileno(outputStream)) > 0);
  while (fmtdMsg(msgTbl[msgNb++], parArr4)) {
    if (interactive) {
      fmtdMsg(ProceedMsg, NULL);
      waitAndAnalAnswer();}}
}

#define HyphenDetec	2
static char *bufChar = NULL, *ptrBufCh;
static const char *endBufChar;
static bool partWord = False;  /* flag "previous word not complete" */

static void initEmitC(void)
{
  changeOutStreamTo(NULL);
  free(bufChar);
  MyAlloc(bufChar, (uint)lineSize + (HyphenDetec + 1 + 1));  /* +1 for ending
					     '\0', +1 for overflow detection. */
  bufChar[0] = bufChar[1] = ' ';  /* initialized because of hyphen detection */
  ptrBufCh = &bufChar[HyphenDetec];
  endBufChar = bufChar + lineSize + (HyphenDetec + 1);
  spaceAtEndOfLine = 0;
  partWord = False;
  transfSize = ((int)SizeSrcBuffer - (NbSrcLinesKept /* fors NLs */ +
				      1 /* EndCh */))/NbSrcLinesKept - lineSize;
  if (transfSize < MaxLgtId) sysErr(ExCod5);  /* lineSize too big, or
			       SizeSrcMngtBlk (file 'configdc.th') too small. */
}

static void emitC(char x)
/* Manages line wrap-around (tries to wrap only when a space or hyphen character
   is received, while avoiding lines too empty). */
{
#define MyFputs(buf) {if (fputs(buf, outputStream) == EOF) sysErr(ExCod2);}
  bool ovfl = False;

  if (x != '\n') {
    *ptrBufCh++ = x;
    if (! (x==' ' && carriagePosition<0 || x=='-' && isalpha(*(ptrBufCh - HyphenDetec
			- 1)) && isalpha(*(ptrBufCh - HyphenDetec)))) { /* dash
			supposed to be hyphen only if last but one character is
			letter (not only last because of word "d-pragma"). */
      if (ptrBufCh < endBufChar) return;  /* normal exit */
      ovfl = True;}}
  /* We come here on NL or buffer full */
  {
    char *begBuf = &bufChar[HyphenDetec];
    int nbChar;

    *((x==' ' && ptrBufCh - begBuf==spaceAtEndOfLine + 1)? --ptrBufCh :
			ptrBufCh) = '\0';  /* ending character (remove useless
						       space at end of line). */
    while ((nbChar = (int)(ptrBufCh - begBuf))>spaceAtEndOfLine || ovfl &&
		nbChar==spaceAtEndOfLine) {  /* in case of overflow, keep one
						 slot at end of line for '\'. */
      if (spaceAtEndOfLine>TolLostSpace || (partWord /* previous word not
			 completely written */ || ovfl) && spaceAtEndOfLine>0) {
        char *nxtBegBuf = begBuf + spaceAtEndOfLine - 1, c = *nxtBegBuf;

        *nxtBegBuf = '\0';  /* for fputs */
        if (*begBuf != '\0') {MyFputs(begBuf)  MyFputs("\\\n") }
        else if (partWord) MyFputs("\\\n")
        else MyFputs("\n")  /* case last character of line is space or hyphen */
        *nxtBegBuf = c;  /* restore smashed character */
        begBuf = nxtBegBuf;}
      else MyFputs("\n")
      ResetSpaceAtEndOfLine;}
    if (*begBuf != '\0') MyFputs(begBuf)  /* write (last part of) buffer */
    ptrBufCh = &bufChar[HyphenDetec];  /* buffer empty */
    if (x == '\n') spaceAtEndOfLine = -1;  /* to have NL inserted before next
								    emission. */
    else spaceAtEndOfLine -= nbChar;
    partWord = ovfl;}
#undef MyFputs
#undef HyphenDetec
}

/*~Undef bufChar, endBufChar, ptrBufCh, partWord */

static void emitCh(register const char *bStr, const char *eStr)
/* Emits all character between 'bStr' (included) and 'eStr' (excluded); tabs 
   are heeded; non-standard characters become spaces. */
{
  char c;

  while (bStr != eStr) {
    if ((c = *bStr++) == '\t' && carriagePosition>=0) {
      int w = tabSpacing - carriagePosition%tabSpacing;

      if (carriagePosition < realCaretPosition) realCaretPosition += w - 1;
					     /* -1 because tab is a character */
      carriagePosition += w;
      while (--w >= 0) emitC(' ');}
    else if (c != '\n') {
      emitC((NonStdChar(c))? ' ' : c);
      if (carriagePosition >= 0) carriagePosition++;}
    else {
      emitC(c);
      if (carriagePosition >= 0) {carriagePosition = 0; realCaretPosition =
							  realCaretPosition1;}}}
}

static void emitFName(Tstring fileName)
{
  CreateParArr((4)) /*~DynInit*/;

  parArr4[4] = fileName;
  prmtrzMsg(errTxt[File], parArr4);
}

void emitS(Tstring x)
{
  if (x != NULL) {while (*x != '\0') {emitC(*x++);}}
}

void endPrgF(register const char *ptrS)
{
  RestoSmshCh;
  ClrSmshCh;
  if (! FileClosed) ilgCharF(ptrS);
  else {
    BackUp;  /* do not go beyond EndCh */
    if (dirLineFl) {dirLineFl = False; curTok.tok = ENDDIR;}
    else {
      if (pTopInclStk != NULL) {ptrS = manageEndInclude(); curTok.tok =
								    WHITESPACE;}
      else {curTok.tok = ENDPROG; curTok.Val = 0; condDirSkip = False
							  ; noExpand = False;}}}
  srcPtr = ptrS;
}

void err(Terr n, const Tstring parArr[])
{
  Terr errNo = n & (EndErrInfoBits -1 -1);
  uint valWarn = (uint)(n & WarnMsk) >> SHIFTWARN;
  bool warn = (valWarn!=(uint)Err || InsideDPragma), noDispLine, savGAFN,
									 savMIF;

  if (warn && (!warnFl
               || sysHdrFile  /* no warning in system header file */
               || sysMacro && n&UWarn  /* no Uwarning in system macro */
               || n&PossErr && !chkPossErr
               || n&Rdbl && !chkRdbl
               || n&Effic && !chkEffic)
      || errNo==NoErrMsg
      || valWarn!=(uint)Err && noWarn) return;
  if (ignoreErr) goto ignoreWarnL;
  if (mngConc) {  /* if inside ## operator */
    if (concatErr == NoConcErr) concatErr = errNo;  /* retain first error */
    return;}
  if (curTok.tok==DPTOK && InsideInterval(errNo, BMsgAA, EMsgAA - 1)) {  /* re-
		      place error by (severe) warning on ill-placed d-pragma. */
    static Ttok currTok[] = {DPTOK};

    errWS(IlgDPrag | Warn3, dpName((Tdprag)curTok.Val));
    skipTok(currTok);  /* and skip d-pragma (to try to avoid induced errors). */
    return;}
  if (InsideMacro) {
    if (curFileName!=cUnitFName && !warn && errNo!=MacBefIncl)
      errMacBefIncl();
    if (curTok.tok==SCOL && InsideInterval(errNo, BMsgAA, EMsgAA - 1) &&
						   checkSColAtEndMac()) return;}
  if (! InsideDPragma) {
    uint msgLvl = (valWarn == (uint)Err)? (uint)WarnMsk >> SHIFTWARN : valWarn;

    if (msgLvl < minMsgLvl) {
      if (screenMsgPass2 || !allErrFl) goto ignoreWarnL;}  /* screen messages */
    else if (callCompil || frstPass) minMsgLvl = msgLvl;}
  if (frstPass)
ignoreWarnL:
    {ctrIgndMsg++; return;}
  if (ctrWarn + ctrErr >= FrstFewMsg) allErrFl = signalAllErr;
  if (msgLimit < 0)
ignoreWarnL1:
    {
      if (! warn) existErr = True;
      goto ignoreWarnL /*~BackBranch*/;}
  if (ctrWarn + ctrErr == 0) {
    emitS(errTxt[WarnErrInFile]); emitS(cUnitFName); emitS("\" *****\n");
    if (stopAfterMsg) {emitS(errTxt[StopAftMsgBanner]); waitAndAnalAnswer();}
    emitC('\n');}
  else {
    emitS(errTxt[SeparMsg]);}
  if (!stopAfterMsg && --msgLimit<0) {
    emitS(errTxt[TooManyMsg]);
    printStat = False;
    goto ignoreWarnL1 /*~BackBranch*/;}
  if (warn) ctrWarn++;
  else {
    ctrErr++;
    ignoreErr = (!allErrFl && curTok.tok!=ENDPROG);}
  noDispLine = n & NoDispLine;
  savGAFN = givAlwsFName;
  savMIF = moreInfMsg;
  do {  /* because message may be repeated */
    if (!noDispLine && (lineNb!=0 || dirLineFl)) { /* not no printing of line */
      const char *ptrS;
      const char *expl;
      ptrdiff_t distErrBegLine;  /* nb of characters between beginning of line
					       and error position (included). */
      char savInfoId[LgtHdrId];
      static char dots[] = Dots, rslashNl[] = "\\\n";

      if (adSmshCh != NULL) {   /* put back in place possible characters
				  smashed by an identifier length/name space. */
        register char *w = adSmshCh;

        savInfoId[0] = *w; *w++ = smshCh[0];
        savInfoId[1] = *w; *w = smshCh[1];}
      ptrS = (savSrcPtr != NULL)? savSrcPtr : srcPtr;
      if ((distErrBegLine = ptrS - nlPosP1) < 0) distErrBegLine += oldMaxPtrS -
				       begSBuf; /* because of circular buffer */
      carriagePosition = 0;
      if (distErrBegLine <= lineSize) {
        /* Beginning of line not very far from error position, so (end of)
           preceding line, and (beginning of) current line, can be displayed. */
        if (frstLineOfFile) expl = nlPosP1;
        else {
          /* Search beginning of preceding line; 'expl' points on it */
          int ctr;

          for (expl = nlPosP1 - 1, ctr = lineSize; ctr >= 0; ctr--) {
            if (expl == begSBuf) expl = oldMaxPtrS;
            if (*--expl == '\n') goto foundNLL;}
          /* Beginning of preceding line not visible */
          emitCh(&dots[0], &dots[LitLen(Dots)]);
          expl += LitLen(Dots);
foundNLL:
          if (++expl >= oldMaxPtrS) expl -= oldMaxPtrS - begSBuf;}
        ptrS = searchNxtNL(ptrS, distErrBegLine);}  /* (local copy of) ptrS
							moved to end of line. */
      else {
        /* Beginning of line too far from error position; only current line
           (broken into two physical lines, the first one being terminated by
           '\' to indicate logical continuation) can be displayed; 'expl' points
           on first char of second physical line. */
        const char *begErrLine;  /* pointer on 1st char of first physical
									line. */

        if (distErrBegLine <= NbSrcLinesKept*lineSize - 1) {  /* - 1 because of
								  ending '\'. */
          /* Beginning of current line visible */
          distErrBegLine -= lineSize - 1;
          begErrLine = nlPosP1;
          expl = begErrLine + (lineSize - 1);
          ptrS = searchNxtNL(ptrS, distErrBegLine);}  /* (local copy of) ptrS
							moved to end of line. */
        else {      /* beginning of current line not visible : put error
				     position at end of second physical line. */
          emitCh(&dots[0], &dots[LitLen(Dots)]);
          distErrBegLine = lineSize;
          if ((begErrLine = ptrS - (NbSrcLinesKept*lineSize - (int)LitLen(Dots)
	      - 1 /* - 1 because of ending '\' */)) < begSBuf) begErrLine +=
							   oldMaxPtrS - begSBuf;
          expl = begErrLine + lineSize - (LitLen(Dots) + 1);}
        /* Print first part of source line */
        if (expl >= oldMaxPtrS) expl -= oldMaxPtrS - begSBuf;
        if (expl < begErrLine) {emitCh(begErrLine, oldMaxPtrS); begErrLine
								     = begSBuf;}
        emitCh(begErrLine, expl);
        emitCh(&rslashNl[0], &rslashNl[LitLen(rslashNl)]);}
      /* Print (second part of) source line */
      realCaretPosition = realCaretPosition1 = (int)distErrBegLine;
      if (ptrS < expl) {emitCh(expl, oldMaxPtrS); expl = begSBuf;}
      emitCh(expl, ptrS);
      carriagePosition = -1;  /* return to initial setting (for emitC() ) */
      /* Print caret under error position */
      emitC('\n');
      while (--realCaretPosition > 0) emitC('.');
      emitS("^\n");
      if (adSmshCh != NULL) {   /* put back in place possible identifier
							   length/name space. */
        register char *w = adSmshCh;

        *w++ = savInfoId[0]; *w = savInfoId[1];}}
    if (warn) {
      emitS(errTxt[Warning]);
      emitC('0' + (int)((valWarn == (uint)Err)
	  ? ((uint)WarnMsk >> SHIFTWARN) + ((uint)Warn1 >> SHIFTWARN)
	  : valWarn));
      emitC(')');}
    else emitS(errTxt[Error]);
    if (!noDispLine || givAlwsFName) {  /* print file name/line number */
      TnbBuf bufLineNo;

      emitS(errTxt[Line]);
      bufGrstIntToS(lineNb, bufLineNo);  /* so 'grstIntToS' buffer remains
							       uncorrupted... */
      emitS(bufLineNo);
      if (curFileName!=cUnitFName || givAlwsFName) emitFName(curFileName);
      if (pTopInclStk!=NULL && givAlwsFName) {  /* give including file(s) */
        const TinclStkElt *w = pTopInclStk;

        emitS(" (");
        do {
          emitS(errTxt[IncldBy]);
          emitS(errTxt[Line]);
          bufGrstIntToS(w->srcMngtBlk->lineNb, bufLineNo);  /* so 'grstIntToS'
						buffer remains uncorrupted... */
          emitS(bufLineNo);
          emitFName(w->fileName);
          emitS(((w = w->prev) == NULL)? ")" : ", ");
        } while (w != NULL);}}
    emitS(": ");
    prmtrzMsg(errTxt[errNo], parArr);  /* parametrized error message */
    if (listTok && !noDispLine && (!stopAfterMsg || moreInfMsg)) {  /* output
				 last tokens taken into account before error. */
      emitS(errTxt[LastToks]);
      if (ovfldTokBuf) {emitS(Dots); emitCh(pLastTokBuf, endLastTokBuf);}
      emitCh(begLastTokBuf, pLastTokBuf);}
    emitC('\n');
    givAlwsFName = moreInfMsg = True;
    noDispLine = False;
  } while (stopAfterMsg && waitAndAnalAnswer());  /* explanation requested */
  givAlwsFName = savGAFN;
  moreInfMsg = savMIF;
}

void errAndSkip(Terr n) {
  err0(n);
  msgLimit = -1;  /* to prevent more output of error messages in current
							  compilation module. */
}

static void errExit(Terr n, const Tstring *parArr) /*~NeverReturns*/
{
  if (n != NoErrMsg) fmtdMsg(n, parArr);
  flushAndExit();
}

void errWFName(Terr n, TlineNb line, Tstring fileName, Tname x, Tstring y,
                                                                      Tstring z)
{
  CreateParArr((8)) /*~DynInit*/;
  TnbBuf nbBuf;
  TnameBuf nameBuf;
  Tstring cFNwPS;

  bufNameToS(x, nameBuf);
  parArr8[1] = &nameBuf[0]; parArr8[2] = y;
  parArr8[4] = fileName; parArr8[5] = z; parArr8[6] = "?";
  parArr8[3] = parArr8[7] = parArr8[8] = NULL;
  if (fileName != NULL) {
    bufGrstIntToS(line, nbBuf);
    parArr8[6] = &nbBuf[0];
    if (line > 1) parArr8[7] = errTxt[OrJustBef];
    if (fileName!=cUnitFName && !StrEq(fileName, cUnitFName)) parArr8[3] =
                                                                   errTxt[File];
    if (fileName!=curFileName && line==lineNb && StrEq(skipPath(fileName),
					    (cFNwPS = skipPath(curFileName)))) {
      if (recursiveInclusion(cFNwPS)) fatalErr(RecursiveIncld, fileName);
      parArr8[8] = errTxt[DblIncldFile];}}
  err(n, parArr8);
}

static void fatalErr(Terr n, Tstring x) /*~NeverReturns*/
{
  changeOutStreamTo(SUMMARY_STREAM);
  mngConc = ignoreErr = frstPass = False;
  errWS(n, x);
  flushAndExit();
}

static void flushAndExit(void) /*~NeverReturns*/
{
  changeOutStreamTo(NULL);
  exit(EXIT_FAILURE);
}

static bool fmtdMsg(Terr n, const Tstring *parArr) /*~PseudoVoid*/
{
  bool resul;
#ifndef VMS
  static bool frstTime = True;

  if (frstTime) {emitC('\r'); frstTime = False;}
#else

#endif
  resul = prmtrzMsg(errTxt[n], parArr);
  emitC('\n');
  return resul;
}

static bool foundOption(Tstring opt, bool *pFl)
{
  size_t lgtOpt = strlen(opt);

  if (*opt!=parArr1[1][LitLen(DccOptPref)] || strncmp(parArr1[1] + LitLen(
				     DccOptPref), opt, lgtOpt)!=0) return False;
  *pFl = (*parArr1[1] == '+');
  {
    register const Tchar *ptr = &parArr1[1][lgtOpt + LitLen(DccOptPref)];

    if (*ptr != '\0') {  /* there exist an 'appendix' to the option */
      optionValue = 0;
      do {
        if (! isdigit(*ptr)) {optionValue = ErrOptVal; break;}
        optionValue = optionValue*Base10 + (*ptr++ - '0');
      } while (*ptr != '\0');}}
  return True;
}

static FreeXElt(freeIncldFElt, TincldInBlk *, ctrIIB, ; , prev)
static FreeXElt(freeInclStkElt, TinclStkElt *, ctrISE, ; , prev)
static FreeXElt(freeUndfTagElt, TundfTagElt *, ctrUT, ; , prev)

static Tstring getNxtArg(void)
/* Gives back pointer on next argument (NULL at end) */
{
  Tstring begArg;

  while (isspace(*dfltArgsPtr)) dfltArgsPtr++;  /* skip possible starting
								     spaces. */
  if (*dfltArgsPtr == '\0' /* environment string exhausted */) return *++pArg;
  begArg = dfltArgsPtr;
  while (*++dfltArgsPtr != '\0') {  /* search end of parameter */
    if (isspace(*dfltArgsPtr)) {
      *dfltArgsPtr++ = '\0';  /* put parameter ending */
      break;}}
  return begArg;
}

static Tstring getNxtFName(void)
{
  Tchar *w;
  Tstring ptrD;
  TlitString ptrO;

  if ((ptrO = getLitString()) == NULL) ptrD = NULL;
  else {
    MyAlloc(w, initGetStrLit(ptrO));
    ptrD = w;
    while ((*w++ = nxtStrLitChar()) != '\0') {}  /* save file name in
							     contiguous area. */
    resetGetStrLit();}
  exitBlock();  /* because of 'getLitString()' */
  return ptrD;
}

static void initAdjFiles(void)
{
  if (totalSizAdjArr != 0) return;  /* already initialized */
  if (! openSrcFile1(adjFiles)) {totalSizAdjArr = 1; return;}
  while (NxtTok() != ENDPROG) {
    if (usedSizAdjArr == totalSizAdjArr) {  /* array full; extend it */
#define IncrSizeAdjArr 5
      totalSizAdjArr += IncrSizeAdjArr;
#undef IncrSizeAdjArr
      MyRealloc(adjFilesArr, sizeof(TadjFilesDesc) * totalSizAdjArr);}
    {
      Tstring w;

      adjFilesArr[usedSizAdjArr].noLoadSysFile = Found(EMARK);
      if ((w = getNxtFName()) == NULL) skipTok(zSCol);
      else {
        adjFilesArr[usedSizAdjArr].amendFName = w;
        if (! Found(COMMA)) errWS(AAExptd, ",");
        ComputeFileHCode(w);
          adjFilesArr[usedSizAdjArr].hCode = fileHCode;}
        if ((w = getNxtFName()) == NULL) skipTok(zSCol);
        else adjFilesArr[usedSizAdjArr++].adjFName = w;}}
    if (curTok.tok != SCOL) errWS(AAExptd, ";");}
  closeSource();
}

static void initAll(void)
{
  initBlk();
  initDecl();
  initDir();
  initExp();
  initExt();
  initInst();
  initMain();
  initPrag();
  initRec();
}

static void initMain(void)
{
#ifndef VMS
  static bool frstInit = True;

  if (frstInit) {
    if (setvbuf(MAIN_OUT_STREAM, NULL, (int)_IOFBF, BUFSIZ) != 0) sysErr(
									ExCod1);
    frstInit = False;}
#endif
  ctrIgndMsg = 0;
  listTok = False;  /* do not list starterFile tokens */
  allErrFl = True;
  if (! frstPass) {
    resetOptions();
    ctrErr = ctrWarn = 0;
    existErr = False;
    minMsgLvl = 0;}
}

bool insideIncldFile(void)
{
  return pTopInclStk != NULL;
}

static void intrnErr(Tstring x, uint *pCtr)
{
  static bool errSeen = False;

  if (pCtr == NULL) {
    if (errSeen) {emitC(' '); errSeen = False;}}  /* flush buffer */
  else {
    if (! frstPass) {
      emitS("\nINTERNAL PB: "); emitS(x); emitS("= "); emitS(grstIntToS(
							  (TgreatestInt)*pCtr));
      errSeen = True;}
    *pCtr = 0;}
}

static void intrnErrT(Tstring x, uint *pCtr)
{
  if (*pCtr != 0) intrnErr(x, pCtr);
}

static bool isDccOption(Tstring arg)
{
  if ((*arg=='+' || *arg=='-') && *(arg + 1)=='z' && heedDccOption) {
    if (*(arg + (2)) == '.') {heedDccOption = False; return True;}
    if (strlen(arg) >= MinDccOptLgt) return True;}
  return False;
}

static bool isHeaderFile(Tstring fileName)
{
  Tstring p = SearchDot(fileName);


  if (p == NULL) return False;
  if (strchr(p, 'h') != NULL) return True;
#ifdef LcEqUc
  if (strchr(p, 'H') != NULL) {
    if (chkPortbl) err0(LowerCaseH | Warn1);
    return True;}
#endif
  return False;
}

static bool isSrcFName(Tstring x)
{
  if (isDccOption(x) ||
#ifdef VMS
			*x=='/')
#else
			*x=='-' || !StrEq(x + strlen(x) - LitLen(CSuffix),
								       CSuffix))
#endif
    return False;
  heedDccOption = True;
  return True;
}

static const TdirName *savPtrDirArr = NULL;

static const char *manageEndInclude(void)
{
  TinclStkElt *locPTInclS = pTopInclStk;
  bool leavingHdrFile = isHeaderFile(curFileName);

  if (! adjustFile) cumNbLines += lineNb - 1;
  if (leavingHdrFile) {
    /* Check whether there remains undefined strun tags */
    while (headUndfTagsList != NULL) {
      if (! headUndfTagsList->pTagId->Defnd) errId1(TagShdBeDfnd|Warn1|Rdbl,
					 headUndfTagsList->pTagId, curFileName);
      headUndfTagsList = freeUndfTagElt(headUndfTagsList);}}
  closeSource();
  /* Search if system header file to be 'amended' */
  if (sysHdrFile) {
    Tstring nakedFName = IndicatedFName(curFileName); /* skip prefix */

    /* Search if not recursive inclusion (because adjustFiles can only be
       included at end of system file). */
    {
      const TinclStkElt *w = locPTInclS;

      while (w->ShdrFile) {
        if (StrEq(IndicatedFName(w->fileName), nakedFName)) goto recursL;
        w = w->prev;}}
    sysHdrFile = False;
    /* First look in DccExecFilesDir directory for possible adjustment file */
    if (
#ifdef LcEqUc
        sameLowerCaseName(SysHdrDir, nakedFName, False)
#else
        strncmp(nakedFName, SysHdrDir, LitLen(SysHdrDir)) == 0
#endif
		 ) nakedFName += LitLen(SysHdrDir);  /* remove redundant path */
    if (openSrcFile1(createAdjFileName(nakedFName))) return srcPtr;
    freeLastPermSto();
    /* Then search if adjustment file not elsewhere */
    {
      const TadjFilesDesc *ptrAdjDesc;
#ifdef LcEqUc
      bool diffLC = False;

      SearchAdjFiles(nakedFName, (diffLC = sameLowerCaseName(nakedFName,
						 ptrAdjDesc->amendFName, True)))
            if (diffLC) locPTInclS->DiffLc = True;
#else

      SearchAdjFiles(nakedFName, False)
#endif
            openSrcFile(ptrAdjDesc->adjFName);
            return srcPtr;}}}}
recursL:;}
  adjustFile = False;
  /* Go back to previous source file */
  curFileName = locPTInclS->fileName;
  curHdrFName = locPTInclS->curHdrFName;
  insideHdrFile = locPTInclS->InsideHdrFile;
  insideHdrInHdr = locPTInclS->InsideHdrInHdr;
  curSrcMngtBlk = locPTInclS->srcMngtBlk;
  if (leavingHdrFile) {
    headUndfTagsList = locPTInclS->headUTList;
    headListPriv = curSrcMngtBlk->listPriv;}
  oldMaxPtrS = curSrcMngtBlk->oldMaxPtrS;
  endSrcChunk = curSrcMngtBlk->endSrcChunk;
  nxtEndSrcChunk = curSrcMngtBlk->nxtEndSrcChunk;
  nlPosP1 = srcPtr = curSrcMngtBlk->ptrS;  /* because of call to err()
						      later in this function. */
  lineNb = curSrcMngtBlk->lineNb;
  srcStream = curSrcMngtBlk->srcStream;
  savPtrDirArr = curSrcMngtBlk->curInclDir;
  begSBuf = &curSrcMngtBlk->idPlusSrc[LgtHdrId + MaxLgtId];
  endSBuf = begSBuf + SizeSrcBuffer;
  restoInclInfoAndPopStk(locPTInclS);
#ifdef LcEqUc
  if (locPTInclS->DiffLc && chkPortbl) err0(ChkUcLc | Warn1);  /* call to err()
					must work anew, so have to come last. */
#endif
  return srcPtr - 1;  /* -1 to get back to nlF() */
}

void processInclude(
#ifdef VMS
		   TstringNC
#else
		   Tstring
#endif
			     fileName, bool sysFl, bool cmpsgHdr, bool inclNxt)
{
  bool headerFile = isHeaderFile(fileName), prevFileSysHdr;
  TinclStkElt *newPTIS = allocInclStkElt();
  TnstLvl locNstLvl = nestLvl;

  /* Save previous context */
  curSrcMngtBlk->ptrS= srcPtr;
  curSrcMngtBlk->oldMaxPtrS = oldMaxPtrS;
  curSrcMngtBlk->endSrcChunk = endSrcChunk;
  curSrcMngtBlk->nxtEndSrcChunk = nxtEndSrcChunk;
  curSrcMngtBlk->lineNb = lineNb;
  curSrcMngtBlk->srcStream = srcStream;
  curSrcMngtBlk->listPriv = headListPriv;
  curSrcMngtBlk->curInclDir = savPtrDirArr;
  newPTIS->srcMngtBlk = curSrcMngtBlk;
  newPTIS->fileName = curFileName;
  newPTIS->curHdrFName = curHdrFName;
  newPTIS->InsideHdrFile = insideHdrFile;
  newPTIS->InsideHdrInHdr = insideHdrInHdr;
  newPTIS->ShdrFile = prevFileSysHdr = sysHdrFile;
#ifdef LcEqUc
  newPTIS->DiffLc = False;
#endif
  newPTIS->IndentIncr = indentIncr;
  newPTIS->prev = pTopInclStk;
  /* Test for errors/warnings while err() stills works */
  {
    Tstring p = SearchDot(fileName);

    if (p!=NULL && StrEq(p+1, "c")) errWS(DontInclBodyFile | Warn2, fileName);}
  if (headerFile) {
    /* Search whether file previously included, but inside a block */
    {
      register const TincldInBlk *w;

      for (w = headListIIB; w != NULL; w = w->prev) {
        if (StrEq(w->includedFName, fileName)) {
          TposInSrc wp = srchPosInclLvl0(newPTIS);

          if ((wp.lineNb!=w->lineNb || wp.fileName!=w->includingFName)
              && (wp.lineNb!=posLastInclWa.lineNb || wp.fileName!=
						      posLastInclWa.fileName)) {
            errWFName(AlrdIncldInBlk|Warn3|PossErr, w->lineNb, w->
					  includingFName, NULL, fileName, NULL);
            posLastInclWa.lineNb = wp.lineNb;
            posLastInclWa.fileName = wp.fileName;}  /* to prevent multiple
								      errors. */
          locNstLvl = 0;  /* to prevent adding again to list */
          break;}}}
    /* Search if circular chain of inclusion of header files */
    {
      const TinclStkElt *w;
      Tstring cmpsgHdrFName = NULL;

      for (w = newPTIS; w->InsideHdrFile; w = w->prev) {
        Tstring curFName = IndicatedFName(w->fileName);

        if (w->curHdrFName!=curFName && isHeaderFile(curFName)) cmpsgHdrFName =
				 curFName;  /* returning to ComposingHdr file */
        if ((cmpsgHdrFName!=NULL || cmpsgHdr) && StrEq(curFName, fileName)) {
          errWSS(CmpsgHdrWithSelf | Warn1, fileName, (cmpsgHdrFName == NULL)?
						   curHdrFName : cmpsgHdrFName);
          goto OkL;}}}}
  if (cmpsgHdr) {
    if (!headerFile || !insideHdrFile) err0(IlgCmpsgHdr | Warn1);
    else if (isBodyHdrFile(fileName) && !isBodyHdrFile(curHdrFName)) errWS(
					     IlgCmpsgHdr1|Warn1|Rdbl, fileName);
    else goto OkL;
    cmpsgHdr = False;}
OkL:
  if (inclNxt && savPtrDirArr==NULL) {err0(InclNxtIlg); inclNxt = False;}
  if (nestLvl != 0) indentIncr = 0;  /* to avoid 'BadIndent' errors in
						files included inside blocks. */
  if (sysFl) sysHdrFile = sysAdjHdrFile = True;
  if (headerFile && sysHdrFile) {
    /* Check if adjust file is to replace header file */
    const TadjFilesDesc *ptrAdjDesc;

#ifdef LcEqUc
    SearchAdjFiles(fileName, sameLowerCaseName(fileName, ptrAdjDesc->
							      amendFName, True))
#else
    SearchAdjFiles(fileName, False)
#endif
          if (ptrAdjDesc->noLoadSysFile) {
            adjustFile = True;
            openSrcFile(ptrAdjDesc->adjFName);
            goto openOkL;}
          break;}}}}
  /* Open included file */
#if defined(VMS) && defined(__ALPHA)
prefixRmvdL:
#endif
  {
    Tchar *fNameBuf;
    static const TdirName noPrefix[] = {EmptyDirName, EmptyDirName , NULL};  /* 'Emp-
			   tyDirName' twice, because of quoted include files. */
    const TdirName *ptrDirArray = (
#ifdef VMS
				   skipPath(fileName) != fileName
#else
  /*~zif LitLen(DirSepar) != 1 "Following line to be amended !!!" */
				   *fileName == DirSepar[0]
#endif
				  )? &noPrefix[0]
				   : (sysFl)
				     ? dirArray + 1
				     : dirArray;
    size_t lgtFileN = strlen(fileName) + 1;  /* '+1' for trailing '\0' */
    size_t lgtPrefix;
#ifdef VMS
    Tchar *pos;

    /* Manage 'dir/file' form (=>'dir:file') */
    if ((pos = strchr(fileName, '/')) != NULL) {
      *pos = ':';  /* replace '/' by ':' */
      ptrDirArray = &noPrefix[0];}
#endif

    if (inclNxt) ptrDirArray = savPtrDirArr;
    /* Try possible prefixes to open include file (and make a permanent copy
       of its name). */
    for (;;) {
      /* Create full file name */
      if (*ptrDirArray != NULL) {
        lgtPrefix = LgtD(*ptrDirArray) + PosLgtAddedPath;
        fNameBuf = allocPermSto(lgtPrefix + lgtFileN + (PosCmpsgFlg -
							      PosLgtAddedPath));
        memcpy(fNameBuf + (PosCmpsgFlg - PosLgtAddedPath), *ptrDirArray++,
								     lgtPrefix);
        strcpy(fNameBuf + lgtPrefix + (PosCmpsgFlg - PosLgtAddedPath),fileName);
        if (openSrcFile1(fNameBuf + LgtHdrAddedPath)) break;
        freeLastPermSto();}
      if (*ptrDirArray==NULL || !sysHdrFile && *(ptrDirArray + 1)==NULL /* do
		     not look in system directory for quoted include file. */) {
#if defined(VMS) && defined(__ALPHA)
        /* Remove possible part before '/' */
        if (pos != NULL) {fileName = pos + 1; goto prefixRmvdL /*~BackBranch*/;}
#endif
#ifdef VMS
        if (sysHdrFile) errWS(UnknSysHdrFile, fileName);
        else
#endif
/**/    errWS(InaccFile, fileName);
        restoInclInfoAndPopStk(newPTIS);
        return;}}  /* if no file can be opened, ignore '#include' */
#ifdef VMS
    if (pos != NULL) *((TstringNC/*~OddCast*/)curFileName + (pos - fileName))
					 = '/';  /* restore '/' replacing ':' */
#endif
    savPtrDirArr = ptrDirArray;
    *fNameBuf = (Tchar)cmpsgHdr;}
openOkL:
  if (headerFile) {
    Tstring nakedFName = IndicatedFName(curFileName);

    if (locNstLvl != 0) {  /* header file included inside block: record it */
      register TincldInBlk *newIncldElt  = allocIncldFElt();
      TposInSrc wp = srchPosInclLvl0(newPTIS);

      newIncldElt->includedFName = nakedFName;
      newIncldElt->lineNb = wp.lineNb;
      newIncldElt->includingFName = wp.fileName;
      newIncldElt->prev = headListIIB;
      headListIIB = newIncldElt;}
    if (! prevFileSysHdr) {  /* would-be header file (system header files
							  considered 'flat'). */
      if (! cmpsgHdr) {  /* real header file */
        curHdrFName = nakedFName;
        if (insideHdrFile) {
          insideHdrInHdr = True;  /* header file included inside header file */
          goto notIncldAtLvl0L;}
        insideHdrFile = True;}
      else {  /* "composing" header */
        if (insideHdrInHdr) goto notIncldAtLvl0L;
        /* Composed header included at level 0 => composing header behaves as if
           included at level 0. */}
      (void)addLvl0InclFName(nakedFName);  /* jot down files included at
								     level 0. */
notIncldAtLvl0L:
      headListPriv = NULL;}  /* reset *~PrivateX* */
    newPTIS->headUTList = headUndfTagsList;
    headUndfTagsList = NULL;}
  else if (insidePrivNT() /* inside reach of *~Private* */
						   ) addIncldFilesToPriv(False);
  pTopInclStk = newPTIS;  /* only done here because of err() */
  lineNb--;  /* because of extra 'newline' put by end of directive processing */
}

/*~Undef savPtrDirArr */

static void mngOptListTok(void)
{
  if (begLastTokBuf != NULL) {free(begLastTokBuf); begLastTokBuf = NULL;}
  if (listTok) {
    MyAlloc(begLastTokBuf, lgtLastTokBuf);
    endLastTokBuf = begLastTokBuf + lgtLastTokBuf;
    pLastTokBuf = begLastTokBuf;
    ovfldTokBuf = False;
    getTokLvl =  0;}
  else getTokLvl = 1;  /* so, no storing */
  tokLvl0 = getTokLvl;
}

static void mngOptMsgLimit(void)
{
  msgLimit = (msgLimitFl)
	     ? initMsgLimit
	     : (interactivOutptDev)
	       ? DfltMsgLimit
	       : INT_MAX;
}

static void mngOptVerbose(void)
{
  verbose = (fullVerbose)
		? FullVerbo
		: (moreInfMsg)
		  ? HalfVerbo
		  : Terse;
}

TcharStream nxtChFromTxt(void)
{
  char c;
  const char *ptrS = srcPtr;

  NxtCh
  srcPtr = ptrS;
  return (TcharStream)c;
}

char *nxtChunkOfTxt(void)
/* Loads next chunk of source text, managing the circular source buffer.
   At entry, ptrS points just after ending EndCh. */
{
  register char *ptrS = (char * /*~OddCast*/)endSrcChunk;
  int lgt;	/* (max) length of chunk of text to load (including
							     terminating \0). */

  if (ptrS == oldMaxPtrS) {  /* if next text chunk already loaded (by a
					preceding searchNxtNL() or splice()). */
    endSrcChunk = nxtEndSrcChunk;
    return begSBuf;}
  lgt = (int)(ptrS - begSBuf) - deltaPtrS - (lineSize + 1)*NbSrcLinesKept;  /*
		  preserve (maximum) number of characters needed before ptrS. */
  if (nlPosP1 <= ptrS) {  /* normal case (no 'circular buffer' effect) */
    int minLgt = (int)(nlPosP1 - begSBuf) - lineSize - (2);  /* 1 to get back
		    to NL position, 1 to keep NL (begin marker for 1st line). */

    if (lgt < minLgt) lgt = minLgt;}  /* free space before beginning of
							      preceding line. */
  if (lgt >= 0)
    if (endSBuf - ptrS > transfSize) {  /* if enough space at end of buffer,  */
      lgt = (int)(endSBuf - ptrS);      /*   use it (in order to maximise
								 oldMaxPtrS). */
      oldMaxPtrS = endSBuf;}  /* to prevent oldMaxPtrS from indicating 'already
							  loaded' text chunk. */
    else {	/* load at beginning of buffer */
      oldMaxPtrS = ptrS;  /* remember (logical) end of circular buffer */
      if (nlPosP1 > ptrS) nlPosP1 = begSBuf + 1; /* to force subsequent reset,
				for nlPosP1 becomes meaningless in that case. */
      ptrS = begSBuf;}
  else {  /* characters to be kept start at end of circular buffer */
    int minLgt;

    lgt += (int)(oldMaxPtrS - ptrS);
    minLgt = (int)(nlPosP1 - ptrS) - lineSize - (2);
    if (lgt < minLgt) lgt = minLgt;}
  if ((uint)(adSmshCh - ptrS) < (uint)lgt) ClrSmshCh;  /* if last identifier
							 will be overwritten. */
  if ((uint)(nlPosP1 - 1 - ptrS) < (uint)lgt) nlPosP1 = begSBuf - NbSrcLinesKept
			*lineSize; /* if NL is overwritten, its position becomes
			  meaningless (see use of 'distErrBegLine' in err()). */
  {
    size_t readLgt;	/* length of chunk of text really loaded */
    register char *endBuf;

    readLgt = fread(ptrS, 1, (size_t)(lgt - 1), srcStream);
    endBuf = ptrS + readLgt;
    if (readLgt==0 || ferror(srcStream)) {
      if (ferror(srcStream) | fclose(srcStream)!=0 /* '|' so that fclose always
		   called. */) {srcPtr = ptrS; errWS(InptFileErr, curFileName);}
      endSrcChunk = NULL;}  /* end of file seen */
    else endSrcChunk = endBuf;
    *endBuf = EndCh;}  /* end of loaded text */
  return ptrS;
}

static void openSrcFile(Tstring fileName)
{
  if (! openSrcFile1(fileName)) fatalErr(InaccFile, fileName);
}

static bool openSrcFile1(Tstring fileName)
{
  Tstream w;

  if ((w = fopen(fileName, "r")) == NULL) return False;
  srcStream = w;
  curFileName = fileName;
  MyAlloc(curSrcMngtBlk, sizeof(TsrcMngtBlk));
  begSBuf = &curSrcMngtBlk->idPlusSrc[LgtHdrId + MaxLgtId];  /* reserve an
	identifier name buffer in front of the source buffer, buffer used in
	case an identifier straddles both ends of (circular) source buffer,
	because nameStrings must always be contiguous. */
  {
    register char *w;

    srcPtr = w = begSBuf + (SizeSrcBuffer - 1 - 1);  /* see following
							    initializations. */
    *w++ = '\n';  /* simulate initial NL (to be able to manage preprocessor
						    directive on first line). */
    endSrcChunk = w;
    *w++ = EndCh;	/* simulate end of loaded text */
    oldMaxPtrS = endSBuf = w;}
  lineNb = 0;
  frstLineOfFile = True;
  return True;
}

static bool prmtrzMsg(Tstring x, const Tstring *tabPrm) /*~PseudoVoid*/
{
  register char c;
  static char lastChar;
  uint w;
  static bool skip;
  static int lvl = -1;
  bool resul = False;

  if (x != NULL) {
    if (++lvl == 0) skip = False;  /* start in no-skipping mode */
    while ((c = *x++) != '\0') {
      if (c == '\xFF') resul = True;
      else if (c=='@' && *x=='0') {
        if (! moreInfMsg) skip = !skip;
        x++;}
      else if (! skip)
        if (c=='@' && tabPrm!=NULL && (w = (uint)(*x - '1'))<(uint
	      /*~OddCast*/)*tabPrm) {prmtrzMsg(*(tabPrm + w + 1), tabPrm); x++;}
        else emitC(lastChar = c);}
    if (--lvl<0 && skip && lastChar!='?') emitC('.');}  /* message ending
								      period. */
  return resul;
}

static bool recursiveInclusion(Tstring fileName) {
  const TinclStkElt *w;

  for (w = pTopInclStk; w != NULL; w = w->prev) {
    if (StrEq(fileName, skipPath((w->InsideHdrFile)? IndicatedFName(w->fileName)
						  : w->fileName))) return True;}
  return False;
}

static void resetArgPtr(void)
{
  dfltArgsPtr = strcpy(copDfltArgs, PrefixDCCDFLTS);  /* copied because modi-
							  fied (' ' => '\0'). */
  strcpy(copDfltArgs + LitLen(PrefixDCCDFLTS), dfltArgs);
  pArg = valInitParg;
  heedDccOption = True;
}

static void resetOptions(void)
{
  askConstFl = callCompil = callCompilW = chkBool = chkEffic = chkFctRetTyp =
   chkInclPos = chkIndent = chkNumCst = chkPortbl = chkPossErr = chkRdbl =
   emitTrailer = goodPrgmg = warnFl = warnNUI = warnNUP = wrapFl = True;
  chkEmptParList = chkNmdTypParFl = chkUCTags = fullVerbose = givAlwsFName =
   kwAsMacName = moreIndexTypeChk = moreInfMsg = morePrtblChk = msgLimitFl =
   noWarn = oldMIM = printStat = reportHghsWaFl = signalAllErr =
   verifAllPtrForConst = False;
  compilerName = NULL;
  initMsgLimit = DfltMsgLimit;
  lvlNoCompil = ((uint)WarnMsk>>SHIFTWARN) + 1;
  mskFrstChId = sMskFrstChId = DfltMskFrstChId;
  mskFrstChId1 = sMskFrstChId1 = DfltMskFrstChId1;
  stopAfterMsg = interactivOutptDev;
  tabSpacing = DfltTabSpacing;
  verbose = (stopAfterMsg)? FullVerbo : Terse;
  initTypBuf(lineSize * (2 /* arbitrary */));
  mngOptListTok();
  mngOptMsgLimit();
}

static void restoInclInfoAndPopStk(TinclStkElt *locPTInclS)
{
  indentIncr = locPTInclS->IndentIncr;
  sysHdrFile = sysAdjHdrFile = locPTInclS->ShdrFile;
  pTopInclStk = freeInclStkElt(locPTInclS);
}

#ifdef LcEqUc
static bool sameLowerCaseName(const char *x, const char *y, bool identity)
{
  for (;; x++, y++) {
    if (*x == '\0') return (!identity || *y=='\0');
    if (RealChar(*x) != RealChar(*y)) return False;}
}
#endif

void saveTokChar(char c)
{
  if (pLastTokBuf == endLastTokBuf) {pLastTokBuf = begLastTokBuf; ovfldTokBuf
									= True;}
  *pLastTokBuf++ = c;
}

static const char *searchNxtNL(register const char *ptrS, ptrdiff_t ctr)
/* Search until next NL, or until seen lineSize chars on error line; returns
   pointer on this character. */
{
  char c;
  const char *prevEndSrcChunk = NULL, *oldEndSrcChunk = NULL;

  if (ctr == 0) {deltaPtrS = 1; ctr = 1;}
  else {
    if (ptrS == begSBuf) {ptrS = oldMaxPtrS; oldEndSrcChunk = endSrcChunk
							  ; endSrcChunk = ptrS;}
    BackUp;}
  do {
    deltaPtrS++;  /* to limit length of loaded text chunk, so as not to destroy
		     last NL. Value = 1 too much, so can also serve as flag (in
		     nxtChunkOfTxt()). */
    for (;;) {  /* get next character; may cause (but only once) loading of
							     next text chunk. */
      if (ptrS == endSrcChunk) {
        if (oldEndSrcChunk == NULL) prevEndSrcChunk = ptrS /* = endSrcChunk */;
        else {prevEndSrcChunk = oldEndSrcChunk; oldEndSrcChunk = NULL;}
        ptrS = nxtChunkOfTxt();
        if (ptrS != begSBuf) prevEndSrcChunk = NULL;}  /* no circular effect */
      c = *ptrS++;
#if False
    if (c == '\?') {          /* trigraph? */
      if (ptrS == endSrcChunk) ptrS = nxtChunkOfTxt();
      c = *ptrS++;
      if (c == '\?') ptrS = trigraph(ptrS, &c);/* *doIt* c not ds reg */
      else {BackUp; c = '\?';}
      break;}
#endif
      if (c!='\\' || !splice((char * /*~OddCast1*/)ptrS)) break; ptrS--;}
								 /* splicing? */
    if (c=='\n' || c==EndCh && FileClosed) break;  /* found NL (or end of
								source file). */
  } while (ctr++ <= lineSize);
  BackUp;
  deltaPtrS = 0;  /* back to normal case */
  if (prevEndSrcChunk != NULL) {
    nxtEndSrcChunk = endSrcChunk;  /* because of possible splice() */
    endSrcChunk = prevEndSrcChunk;}
  else if (oldEndSrcChunk != NULL) endSrcChunk = oldEndSrcChunk;
  return ptrS;
}

bool splice(register char *ptrS)
/* On entry we have just read a backslash, and ptrS points at the next
   character. */
{
  if (ptrS == endSrcChunk) {  /* end of buffer */
    const char *prevEndSrcChunk = ptrS /* = endSrcChunk */;

    ptrS = nxtChunkOfTxt();
    if (ptrS == begSBuf) {nxtEndSrcChunk = endSrcChunk
		       ; endSrcChunk = prevEndSrcChunk;}}  /* circular effect */
  if (*ptrS != '\n') return False;
  /* Line splicing: remove '\\' and '\n' by shifting end of buffer */
  {
    const char *prevEndSrcChunk = NULL;

    if (ptrS == begSBuf) {  /* circular effect */
      prevEndSrcChunk = endSrcChunk;
      endSrcChunk = nxtEndSrcChunk;
      nxtEndSrcChunk -= LitLen("\\\n");
      *((char * /*~OddCast*/)oldMaxPtrS - 1) = *++ptrS;}
    memmove(ptrS - (LitLen("\\\n") - 1), ptrS + 1, (size_t)(endSrcChunk -ptrS));
    if (prevEndSrcChunk != NULL) endSrcChunk = prevEndSrcChunk;
    else endSrcChunk -= LitLen("\\\n");}
  lineNb++;
  return True;
}

static TposInSrc srchPosInclLvl0(const TinclStkElt *w)
/* Search level 0 including file */
{
  TposInSrc result;

  while (w->InsideHdrFile) {w = w->prev;}
  result.fileName = w->fileName;
  result.lineNb = w->srcMngtBlk->lineNb;
  return result;
}

static void storeDMacTxt(Tchar c)
{
  if (pStoDMacTxt < endDMacBuf) *pStoDMacTxt++ = c;
}

void sysErr(Tstring x) /*~NeverReturns*/
{
  fatalErr(SysError, x);
}

/****static char *trigraph(register const char *ptrS, char *pEquivCh)
  a traiter non dans NxtCh (sauf ??/) 
{
  sysErr(55);
  *pEquivCh = *ptrS;
  return ptrS;
}*/

static bool waitAndAnalAnswer(void) /*~PseudoVoid*/
{
  char c;
  bool resul = False;

  (void)fflush(outputStream);
  while ((c = getchar()) != '\n') {
    if (c == '#') stopAfterMsg = False;
    if (ToLower(c) == ExplainMsgChar) resul = True;};
#ifdef CrEchoedAsNewLine
  ResetSpaceAtEndOfLine;  /* kill previous '\n' */
#endif
  return resul;
}

/* End DCMAIN.C */
