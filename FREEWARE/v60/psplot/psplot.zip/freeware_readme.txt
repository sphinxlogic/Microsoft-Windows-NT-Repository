PSPLOT, GRAPHICS, Fortran library for creating PostScript files

PSPLOT is a Fortran-callable library of subroutines used
for creating publication-quality graphics in the form of
PostScript files. It is written in Fortran 77 and supports
the standard 35 PostScript fonts and color.
