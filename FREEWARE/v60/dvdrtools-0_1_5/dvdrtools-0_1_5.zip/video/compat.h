#ifndef HAVE_STRSEP
char *strsep(char **stringp,const char *delim);
#endif

#ifndef O_BINARY
#define O_BINARY 0
#endif
