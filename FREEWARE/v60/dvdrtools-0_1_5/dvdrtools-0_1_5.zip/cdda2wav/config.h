/* @(#)config.h	1.4 01/12/19 Copyright 1998,1999 Heiko Eissfeldt */
/*
 *	Adaption for mconfig.h from make file system.
 *
 *	Copyright (c) 1997 J. Schilling
 */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; see the file COPYING.  If not, write to
 * the Free Software Foundation, 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
 */

#include <mconfig.h>

#if	__STDC__-0 != 0 || (defined PROTOTYPES && defined STDC_HEADERS)
#define UINT_C(a)	(a##u)
#define ULONG_C(a)	(a##ul)
#define USHORT_C(a)	(a##uh)
#define CONCAT(a,b)	a##b
#else
#define UINT_C(a)	((unsigned) a)
#define ULONG_C(a)	((unsigned long) a)
#define USHORT_C(a)	((unsigned short) a)
#define CONCAT(a,b)	a/**/b
#endif

#include "xconfig.h"
#if defined HAVE_FORK && (defined (HAVE_SMMAP) || defined(HAVE_USGSHM) || defined(HAVE_DOSALLOCSHAREDMEM))
#define HAVE_FORK_AND_SHAREDMEM
#undef FIFO
#define FIFO
#else
#undef FIFO
#endif
#if	!defined	HAVE_MEMMOVE
#define	memmove(dst, src, size)	movebytes((src), (dst), (size))
#endif
