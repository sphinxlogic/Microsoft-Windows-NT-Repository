/* VMS definitions for use by ZTNS4 */
 
#define SSs_NORMAL      1
#define SSs_BADPARAM	20
#define SSs_DRVERR      140
#define SSs_ILLIOFUNC   244
#define SSs_MEDOFL      420
#define SSs_WRITLCK     604
#define SSs_DATAOVERUN  2104
#define SSs_ENDOFFILE   2160
#define SSs_ENDOFTAPE   2168
#define SSs_BEGOFTAPE   2576
 
#define MTsM_BOT        65536
#define MTsM_EOF        131072
#define MTsM_EOT        262144
#define MTsM_HWL        524288
#define MTsM_LOST       1048576
 
#define IOs_WRITECHECK  10
#define IOs_DISPLAY	19
#define IOs_WRITECHECKH 24
#define IOs_WRITELBLK   32
#define IOs_READLBLK    33
#define IOs_REWINDOFF   34
#define IOs_REWIND      36
#define IOs_SKIPRECORD  38
#define IOs_WRITEOF     40
#define IOsM_FCODE      63
#define IOsM_FMODIFIERS 65472
#define IOsM_DATACHECK  16384
#define IOsM_NOWAIT     128
