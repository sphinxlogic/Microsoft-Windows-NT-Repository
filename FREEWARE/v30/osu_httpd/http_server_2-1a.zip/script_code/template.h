/*
 * define prototypes for the template.c module.
 */
typedef int (*template_callback)(void *arg, char *buffer, int length );

int set_default_template_fields ( int count, char **name, char **value );

int process_template_file ( char *fname, 
	template_callback out, void *out_arg,	/* normal output */
	template_callback escape, void *esc_arg);	/* meta output */	

int process_template ( char *template, int t_len,
	template_callback out, void *out_arg,	/* normal output */
	template_callback escape, void *esc_arg);	/* meta output */	
