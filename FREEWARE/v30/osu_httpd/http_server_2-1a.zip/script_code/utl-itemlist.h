#define notthere 1
