int write_gif_header ( 
	int width, int height, 		/* Size of screen */
	int gct_size,                   /* Number of entries in color table */
	unsigned char *gct, 		/* Color table 3 bytes/entry  (r,g,b)*/
	int background,			/* Background color pixel index*/
	int (*output)(void*, int, char *), /* output function */
	void *outarg );			/* user-arg for output routine*/

int write_gif_image ( 
	int width, int height, 		/* Size of image */
	int max_pixel,			/* Highest pixel value in image */
 	unsigned char *image, 		/* Image data, 1 byte/pixel */
	int interlace,			/* Only set if you've interlaced image*/
	int (*output)(void*, int, char *), /* User-supplied output function */
	void *outarg );			/* user-arg for output function */
