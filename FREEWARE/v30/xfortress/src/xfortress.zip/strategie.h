extern prise();
extern calc();
