void calc();
void alphabeta();
void prise();
