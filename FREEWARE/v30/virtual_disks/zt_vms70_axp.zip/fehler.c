/* FEHLER [german for "error"] abort a program with a message.
 *
 * w.j.m. 1982 (FORTRAN version, would not always work)
 * w.j.m. 1985 (MACRO version)
 * w.j.m. 1991 (C version)
 *
 * usage:
 *	FEHLER(textdsc)			|* error message (length.le.255) *|
 *	struct dsc$descriptor *textdsc;	|* passed by descriptor 	 *|
 *
 * *OR*
 *	FEHLER(text)		|* error message (length.gt.1)  *|
 *	char *text;		|* passed by reference (.ASCIZ) *|
 */

#include descrip

void FEHLER(unsigned short *ptr)
{
	unsigned int s;
	$DESCRIPTOR(msgdsc,"?");	/* address & length to be filled in */
	unsigned int msgvec[4];
	static const $DESCRIPTOR(fehler_name,"FEHLER");
	globalvalue shr$_text;
	extern unsigned lib$analyze_sdesc();
	extern void lib$stop(),sys$putmsg();

	
/* decide upon call format ... */

	if(*ptr < 256) {	/* most probably a descriptor */
		s = lib$analyze_sdesc(ptr,
				      &msgdsc.dsc$w_length,
				      &msgdsc.dsc$a_pointer);
	} else {
		s = 0;
	}
	if((s & 1) == 0) {	/* got to be an .ASCIZ string */
		msgdsc.dsc$a_pointer = (char*)ptr;
		{ 			/* avoid VAXCRTL strlen() */
			char *p = (char*)ptr; while(*p) p++;

			msgdsc.dsc$w_length = p - (char*)ptr;
		}
	}

/* setup for $PUTMSG */

	msgvec[0] = 3;		/* # of following longwords */
	msgvec[1] = (shr$_text & 0x0000fff8) |
		    0x08000004;		/* fake user facility (required for 
					 * $FAO), and force severity = fatal */
	msgvec[2] = 1;		/* # of $FAO arguments */
	msgvec[3] = (unsigned int)(&msgdsc);

/* output the message (unless overriden process "message" default */

	sys$putmsg(msgvec,0,&fehler_name,0);	/* don't care for status now */

/* LIB$STOP for traceback (don't output the message again) */

	lib$stop(msgvec[1] | 0x10000000);
}


#ifdef TESTING
main(argc)
{
	extern void FEHLER();

	if(argc > 1) {
		$DESCRIPTOR(dsc,"######## passed by descriptor #######");
		FEHLER(&dsc);
	} else {
		FEHLER("######## passed by reference #######");
	}
}
#endif
