char *version_string = "GNU Bison version 1.22\n";
