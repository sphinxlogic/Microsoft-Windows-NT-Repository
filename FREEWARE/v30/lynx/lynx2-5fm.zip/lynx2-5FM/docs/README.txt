
                       How to obtain the Lynx help files
                                       
   The Lynx help files are included with the distribution of Lynx sources
   and documentation. Links to sites which supply the distribution are
   maintained in the [1]Lynx Enhanced Pages.
   
   Once you have downloaded and extracted the distribution, set HELPFILE
   in the lynx.cfg as:
   file://localhost/FULL_PATH_TO_HELP_FILES/lynx_help_main.html
   
   Additional instructions for HELFILE configuration are in the lynx.cfg
   file.

References

   1. http://www.nyu.edu/pages/wsn/subir/lynx.html
