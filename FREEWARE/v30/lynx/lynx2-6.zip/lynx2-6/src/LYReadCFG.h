
#ifndef LYREADCFG_H
#define LYREADCFG_H

#ifndef LYSTRUCTS_H
#include "LYStructs.h"
#endif /* LYSTRUCTS_H */

extern void read_cfg PARAMS((char *cfg_filename));
extern BOOLEAN have_read_cfg;

#endif /* LYREADCFG_H */

