#include "Wlib.h"
#include "images.h"
#include "defs.h"
#include "data.h"

W_Window gal;

char *imagedir;
int verbose_image_loading = 0;
int forceMono = 1;

int xpm = 1, useOR = 1;

W_Color backColor = 0;

int buttonDown = 0;

char *imagedirend = 0;

W_Window baseWin;

W_Image *playerShip, *playerTorp, *enemyTorp, *shieldImage;

int useBuffered = 1;

int score;
int paused;

int ships;

int level;

int nextBonus;

int gameOver=1;
int getting_name = 0;

int counter;

int mouseControl = 0;

int alien_shape[6] = {
    I_ALIEN1,
    I_ALIEN2,
    I_ALIEN3,
    I_ALIEN4,
    I_ALIEN5,
    I_ALIEN6
};

int weapon = 0;
int maxtorps = 4, numtorps = 0;

int plx = 200;

int movespeed = MINSPEED;

#ifdef SOUND
char *unixSoundPath=SOUNDDIR,
     *unixSoundDev=SOUNDDEV;
int playSounds=1;
#endif

int plshield = 0;

int title_page=0, pagetimer=300;
