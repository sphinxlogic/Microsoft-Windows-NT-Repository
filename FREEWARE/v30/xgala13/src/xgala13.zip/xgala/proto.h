/* main.c */
void xgal_exit(int v);
int main(int argc, char **argv);
/* x11window.c */
void W_Initialize(char *str);
int W_Mono(void);
void W_ClearBuffer(W_Window window);
int W_IsBuffered(W_Window window);
void W_Buffer(W_Window window, int on);
void W_DisplayBuffer(W_Window window);
void W_RenameWindow(W_Window window, char *str);
W_Window W_MakeWindow(char *name, int x, int y, int width, int height, W_Window parent, char *cursname, int border, W_Color color);
void W_ChangeBorder(W_Window window, int color);
void W_MapWindow(W_Window window);
void W_UnmapWindow(W_Window window);
int W_IsMapped(W_Window window);
void W_FillArea(W_Window window, int x, int y, unsigned int width, unsigned int height, W_Color color);
void W_CacheClearArea(W_Window window, int x, int y, int width, int height);
void W_FlushClearAreaCache(W_Window window);
void W_ClearArea(W_Window window, int x, int y, unsigned int width, unsigned int height);
void W_ClearWindow(W_Window window);
void W_GetEvent(W_Event *wevent);
int W_EventsPending(void);
void W_NextEvent(W_Event *wevent);
void W_MakeLine(W_Window window, int X0, int Y0, int X1, int Y1, W_Color color);
void W_DrawPoint(W_Window window, int x, int y, W_Color color);
void W_CacheLine(W_Window window, int X0, int Y0, int X1, int Y1, int color);
void W_FlushLineCaches(W_Window window);
void W_CachePoint(W_Window window, int x, int y, int color);
void W_FlushPointCaches(W_Window window);
void W_MakeTractLine(W_Window window, int X0, int Y0, int X1, int Y1, W_Color color);
void W_DrawSectorHighlight(W_Window window, int x, int y, int width, int h, W_Color color);
void W_WriteAnyTriangle(W_Window window, int X1, int Y1, int X2, int Y2, int X3, int Y3, W_Color color);
void W_WriteTriangle(W_Window window, int x, int y, int s, int t, W_Color color);
void W_ShadowText(W_Window window, int x, int y, W_Color color, char *str, int len, W_Font font);
void W_WriteText(W_Window window, int x, int y, W_Color color, char *str, int len, W_Font font);
void W_MaskText(W_Window window, int x, int y, W_Color color, char *str, int len, W_Font font);
void W_DirectMaskText(W_Window window, int x, int y, W_Color color, char *str, int len, W_Font font);
void W_FreeImage(W_Image *image);
W_Image *W_BitmapToImage(unsigned int width, unsigned int height, char *bits);
W_Image *W_CreateCombinedImage(W_Image **imagelist, W_Color color);
int W_LoadImage(W_Image *image);
void W_OverlayImage(W_Window window, int x, int y, int frame, W_Image *image, int overframe, W_Image *overimage, W_Color color);
void W_DrawImage(W_Window window, int x, int y, int frame, W_Image *image, W_Color color);
void W_DrawImageNoClip(W_Window window, int x, int y, int frame, W_Image *image, W_Color color);
void W_DrawImageOr(W_Window window, int x, int y, int frame, W_Image *image, W_Color color);
void W_DrawImageBar(W_Window win, int x, int y, int len, W_Image *image);
void W_TileWindow(W_Window window, W_Image *image);
void W_UnTileWindow(W_Window window);
W_Window W_MakeTextWindow(char *name, int x, int y, int width, int height, W_Window parent, char *cursname, int border);
struct window *newWindow(Window window, int type);
W_Window W_MakeScrollingWindow(char *name, int x, int y, int width, int height, W_Window parent, char *cursname, int border);
W_Window W_MakeMenu(char *name, int x, int y, int width, int height, W_Window parent, int border);
void W_Beep(void);
int W_WindowWidth(W_Window window);
int W_WindowHeight(W_Window window);
int W_Socket(void);
void W_DestroyWindow(W_Window window);
void W_SetIconWindow(W_Window win, W_Window icon);
int checkMapped(char *name);
int checkBuffered(char *name);
void W_WarpPointer(W_Window window, int x, int y);
int findMouseInWin(int *x, int *y, W_Window window);
void W_Flush(void);
void W_AutoRepeatOff(void);
void W_AutoRepeatOn(void);
int W_StringWidth(char string[], W_Font font);
void W_TranslatePoints(W_Window window, int *x, int *y);
void W_ResizeWindow(W_Window window, int neww, int newh);
void W_ResizeMenu(W_Window window, int neww, int newh);
void W_ResizeText(W_Window window, int neww, int newh);
void W_Deiconify(W_Window window);
void W_DrawShield(W_Window window, int centerx, int centery, unsigned int diameter, W_Color color);
void W_Sync(void);
void W_WriteArc(int filled, W_Window window, int x, int y, int width, int height, int angle1, int angle2, W_Color color);
void W_GetMouse(W_Window window, int *x, int *y, int *but);
void W_SetRGB16(W_Color color, int r, int g, int b);
void W_BlankCursor(W_Window window);
/* images.c */
W_Image *getImage(int offset);
#ifndef __DECC
int cmpfilenames(const void *left, const void *right);
#endif
void loadImageByFilename(char *filename);
void loadAllImages(void);
/* data.c */
/* paths.c */
void path_dir(int path, int pos, int *dir, int *steer);
void start_path(int path, struct alien *al);
void new_alien(int level, int i, struct alien *al);
/* title.c */
void undo_pause(void);
void do_pause(void);
void center_text(char *text, int y, W_Color color);
void do_title(void);
void init_titles(void);
/* explosions.c */
void undo_explosions(void);
void do_explosions(void);
void new_explosion(int x, int y, int type);
void score_flagship(int x, int y, int ne);
void init_explosions(void);
/* score.c */
void undo_score(void);
void do_score(void);
void init_score(void);
/* highscore.c */
void undo_name(void);
void do_name(void);
int score_key(W_Event *ev);
int check_score(int score);
void show_scores(void);
void load_scores(void);
/* prize.c */
void init_prizes(void);
void new_prize(int x, int y);
void undo_prizes(void);
void do_prizes(void);
/* sound.c */
void init_sound(void);
void play_sound(int k);
void maybe_play_sound(int k);
void sound_completed(int k);
void kill_sound(void);
