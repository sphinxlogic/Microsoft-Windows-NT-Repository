/*
 * sound.c - Platform Independant Sound Support - Apr. 1995
 *
 * Copyright 1994-1995 Sujal M. Patel (smpatel@wam.umd.edu)
 * Conditions in "copyright.h"          
 */

#include <stdio.h>
#ifdef __STDC__
#include <stdlib.h>
#endif
#include <unistd.h>
#include <sys/time.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/stat.h>
#include "data.h"



static int soundfd;
static char audioOK = 1;
static char sound_flags[20]; /* Sound Flag for sound 1-19 */



void init_sound ()
{
  int i, child,fd[2];
  char *argv[4];
  char filename[512];
#ifndef VMS
#ifdef linux
  char *arch = "linux";
#else
#ifdef __FreeBSD__
  char *arch = "freebsd";
#else
#ifdef __NetBSD__
  char *arch = "netbsd";
#else
#ifdef sun
  char *arch = "sun";
#else
#ifdef foo
  char *arch = "foobar";
#else
  char *arch = "generic";
#endif
#endif
#endif
#endif
#endif

  signal(SIGCHLD, SIG_IGN);

  if(unixSoundPath[0] == '?')  {
      audioOK = 0;
      return;
  };

  /*  Create a pipe, set the write end to close when we exec the sound server,
      and set both (is the write end necessary?) ends to non-blocking   */
  pipe(fd);
  soundfd=fd[1];

  if( !(child=fork()) )  {
      close(fd[1]);
      dup2(fd[0],STDIN_FILENO);
      close(fd[0]);
      sprintf (filename, SOUNDSERVER);
      argv[0] = filename;
      argv[1] = unixSoundPath;
      argv[2] = unixSoundDev;
      argv[3] = NULL;
      execvp(filename, argv);
      fprintf (stderr, "Couldn't Execute Sound Server (xgal.sndsrv.%s)!\n", arch);
      exit (0);
  };
  close(fd[0]);

  sleep(1);

  if (kill(child, 0))  {
      audioOK = 0;  
      close(soundfd);
  };

  for (i = 0; i < 19; i++) sound_flags[i] = 0;
#endif /* VMS */
} 

void play_sound (k)
int k;
{
#ifndef VMS
  char c;

  c = k;
  if ((playSounds) && (audioOK)) write (soundfd, &c, sizeof (c));
#endif
}



void maybe_play_sound (k)
int k;
{
#ifndef VMS
  char c;

  if (sound_flags[k] & 1) return;

  sound_flags[k] |= 1;

  c = (unsigned char)(k);
  if ((playSounds) && (audioOK)) write (soundfd, &c, sizeof (c));
#endif
}



void sound_completed (k)
int k;
{
#ifndef VMS
  sound_flags[k] &= ~1;
#endif
}



void kill_sound ()
{ 
  char c;

#ifndef VMS
  c = -1;               
  if ((playSounds) && (audioOK)) write (soundfd, &c, sizeof (c));
#endif
}
