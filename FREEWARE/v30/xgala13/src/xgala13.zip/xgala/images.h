/* images.h.  Contains the #defines and extern's for all the image management
   data [BDyess] */
/* automatically created by scripts/mkimgsrc */

#include "Wlib.h"

extern W_Image imagearray[];
extern int shipImageOffset[];
extern int teamImageOffset[];
W_Image * getImage P((int offset));
W_Image * getShipImage P((int team, int ship));
void loadImageByFilename P((char *filename));
void loadAllImages P((void));

#define I_DEFAULT              0
#define I_ALIEN1               0
#define I_ALIEN2               1
#define I_ALIEN3               2
#define I_ALIEN4               3
#define I_ALIEN5               4
#define I_ALIEN6               5
#define I_ETORP                6
#define I_EXPLOSION            7
#define I_EXTRA                8
#define I_MINISHIP             9
#define I_MTORP                10
#define I_PAUSE                11
#define I_PLAYER1              12
#define I_PLAYER2              13
#define I_PLAYER3              14
#define I_PR_BLANK             15
#define I_PR_DOUB              16
#define I_PR_SHIELD            17
#define I_PR_SING              18
#define I_PR_SPEED             19
#define I_PR_TRIP              20
#define I_S1000                21
#define I_S2000                22
#define I_S4000                23
#define I_S500                 24
#define I_SHIELD               25
#define I_TITLE                26
#define I_LAST                 26
