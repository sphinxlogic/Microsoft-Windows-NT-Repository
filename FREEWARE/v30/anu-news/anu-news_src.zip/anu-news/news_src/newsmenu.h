#define menu_escape_pressed "--escape pressed--\0"
#define escape_option -2
