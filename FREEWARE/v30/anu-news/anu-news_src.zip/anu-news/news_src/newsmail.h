/*
**  MODIFICATION HISTORY:
**	V6.1b9	17-Sep-1994     Mark Martinec   mark.martinec@ijs.si
**	  - code cleanup to preserve the read-only nature of string literals
**	    (strategically placed 'const' attribute to string parameters)
**/

#ifndef _NEWSMAIL_H
#define _NEWSMAIL_H

#include <maildef.h>

#ifdef __DECC
#pragma member_alignment save
#pragma nomember_alignment   /* no member alignment - this is a VMS structure */
#endif
  /* note: callable mail uses non-standard itemlist (last field) */
struct mai_itmlst {
  unsigned short bl;	/* buffer length */
  unsigned short ic;	/* item code */
  void *ba;		/* buffer address */
  unsigned int *rl;	/* return length address; NB: not unsigned short *! */
};
#ifdef __DECC
#pragma member_alignment restore
#endif

extern int mail$mailfile_begin(), mail$mailfile_end(),
	   mail$mailfile_open(), mail$mailfile_close(),
	   mail$mailfile_purge_waste(), mail$mailfile_compress(),
	   mail$mailfile_info_file(),
	   mail$message_begin(), mail$message_end(),
	   mail$message_select(), mail$message_info(),
	   mail$message_get(), mail$message_delete(), mail$message_copy(),
	   mail$user_begin(), mail$user_end(),
	   mail$user_get_info(), mail$user_set_info(),
	   mail$send_begin(), mail$send_end(),
	   mail$send_add_attribute(), mail$send_add_bodypart(),
	   mail$send_add_address(), mail$send_message();

#endif	/* _NEWSMAIL_H */
