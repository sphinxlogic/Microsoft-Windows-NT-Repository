extern char *h_news[] ; 

extern char *main_menu_tx[] ; 

extern char *h_mail_index[] ; 

extern char *h_simple_index[] ; 

extern char *h_mail_view[] ; 

extern char *h_folder_maint[] ; 

extern char *h_folder_open[] ; 

extern char *h_folder_save[] ; 

extern char *h_folder_fcc[] ; 

extern char *h_address_book[] ; 

extern char *h_use_address_book[] ; 

extern char *h_select_nickname[] ; 

extern char *h_takeaddr_screen[] ; 

extern char *h_attachment_screen[] ; 

extern char *h_mail_text_att_view[] ; 

extern char *h_composer[] ; 

extern char *h_composer_browse[] ; 

extern char *h_composer_ins[] ; 

extern char *h_composer_search[] ; 

extern char *h_composer_to[] ; 

extern char *h_composer_cc[] ; 

extern char *h_composer_bcc[] ; 

extern char *h_composer_from[] ; 

extern char *h_composer_reply_to[] ; 

extern char *h_composer_custom_addr[] ; 

extern char *h_composer_custom_free[] ; 

extern char *h_composer_news[] ; 

extern char *h_composer_fcc[] ; 

extern char *h_composer_subject[] ; 

extern char *h_composer_attachment[] ; 

extern char *h_composer_placeholder[] ; 

extern char *h_config_generic[] ; 

extern char *h_config_generic_feature_list[] ; 

extern char *h_config_generic_radio[] ; 

extern char *h_config_pers_name[] ; 

extern char *h_config_user_id[] ; 

extern char *h_config_user_dom[] ; 

extern char *h_config_smtp_server[] ; 

extern char *h_config_nntp_server[] ; 

extern char *h_config_inbox_path[] ; 

extern char *h_config_folder_spec[] ; 

extern char *h_config_news_spec[] ; 

extern char *h_config_default_fcc[] ; 

extern char *h_config_postponed_folder[] ; 

extern char *h_config_read_message_folder[] ; 

extern char *h_config_newsrc_path[] ; 

extern char *h_config_signature_file[] ; 

extern char *h_config_addressbook[] ; 

extern char *h_config_global_addrbook[] ; 

extern char *h_config_init_cmd_list[] ; 

extern char *h_config_comp_hdrs[] ; 

extern char *h_config_custom_hdrs[] ; 

extern char *h_config_saved_msg_name_rule[] ; 

extern char *h_config_fcc_rule[] ; 

extern char *h_config_sort_key[] ; 

extern char *h_config_ab_sort_rule[] ; 

extern char *h_config_char_set[] ; 

extern char *h_config_editor[] ; 

extern char *h_config_image_viewer[] ; 

extern char *h_config_domain_name[] ; 

extern char *h_config_prune_date[] ; 

extern char *h_config_enable_full_hdr[] ; 

extern char *h_config_enable_pipe[] ; 

extern char *h_config_enable_tab_complete[] ; 

extern char *h_config_quit_wo_confirm[] ; 

extern char *h_config_enable_jump[] ; 

extern char *h_config_enable_alt_ed[] ; 

extern char *h_config_alt_ed_now[] ; 

extern char *h_config_enable_bounce[] ; 

extern char *h_config_enable_agg_ops[] ; 

extern char *h_config_enable_flag[] ; 

extern char *h_config_can_suspend[] ; 

extern char *h_config_expanded_folders[] ; 

extern char *h_config_expanded_addrbooks[] ; 

extern char *h_config_compose_news_wo_conf[] ; 

extern char *h_config_compose_rejects_unqual[] ; 

extern char *h_config_quell_local_lookup[] ; 

extern char *h_config_preserve_start_stop[] ; 

extern char *h_config_enable_incoming[] ; 

extern char *h_config_attach_in_reply[] ; 

extern char *h_config_include_header[] ; 

extern char *h_config_sig_at_bottom[] ; 

extern char *h_config_use_fk[] ; 

extern char *h_config_del_skips_del[] ; 

extern char *h_config_auto_expunge[] ; 

extern char *h_config_auto_read_msgs[] ; 

extern char *h_config_read_in_newsrc_order[] ; 

extern char *h_config_post_wo_validation[] ; 

extern char *h_config_select_wo_confirm[] ; 

extern char *h_config_use_current_dir[] ; 

extern char *h_config_save_wont_delete[] ; 

extern char *h_config_save_advances[] ; 

extern char *h_config_force_low_speed[] ; 

extern char *h_config_show_delay_cue[] ; 

extern char *h_config_auto_open_unread[] ; 

extern char *h_config_auto_include_reply[] ; 

extern char *h_config_select_in_bold[] ; 

extern char *h_config_folder_extension[] ; 

extern char *h_config_disable_config_screen[] ; 

extern char *h_config_disable_password_cmd[] ; 

extern char *h_config_disable_update_cmd[] ; 

extern char *h_config_disable_kblock_cmd[] ; 

extern char *h_config_quote_all_froms[] ; 

extern char *h_config_normal_fg[] ; 

extern char *h_config_normal_bg[] ; 

extern char *h_config_reverse_fg[] ; 

extern char *h_config_reverse_bg[] ; 

extern char *h_config_news_uses_recent[] ; 

extern char *h_oe_detach_no[] ; 

extern char *h_os_index_whereis[] ; 

extern char *h_os_index_whereis_agg[] ; 

extern char *h_oe_add_full[] ; 

extern char *h_oe_add_nick[] ; 

extern char *h_oe_add_addr[] ; 

extern char *h_oe_crlst_full[] ; 

extern char *h_oe_crlst_nick[] ; 

extern char *h_oe_crlst_addr[] ; 

extern char *h_oe_adlst_addr[] ; 

extern char *h_oe_editab_nick[] ; 

extern char *h_oe_editab_full[] ; 

extern char *h_oe_editab_addr[] ; 

extern char *h_oe_editab_fcc[] ; 

extern char *h_oe_editab_comment[] ; 

extern char *h_ab_edit_a_field[] ; 

extern char *h_oe_editab_al[] ; 

extern char *h_oe_searchab[] ; 

extern char *h_oe_searchrl[] ; 

extern char *h_oe_save[] ; 

extern char *h_oe_chooseabook[] ; 

extern char *h_oe_takeaddr[] ; 

extern char *h_oe_take_or_replace[] ; 

extern char *h_oe_takename[] ; 

extern char *h_oe_takenick[] ; 

extern char *h_oe_jump[] ; 

extern char *h_oe_broach[] ; 

extern char *h_oe_foldsearch[] ; 

extern char *h_oe_foldadd[] ; 

extern char *h_oe_foldrename[] ; 

extern char *h_oe_login[] ; 

extern char *h_oe_passwd[] ; 

extern char *h_oe_choosep[] ; 

extern char *h_oe_customp[] ; 

extern char *h_oe_searchview[] ; 

extern char *h_oe_keylock[] ; 

extern char *h_oe_export[] ; 

extern char *h_wt_expire[] ; 

extern char *h_wt_delete_old[] ; 

extern char *h_wt_auger_in[] ; 

extern char *h_select_sort[] ; 

extern char *h_mini_setup[] ; 

extern char *h_sticky_personal_name[] ; 

extern char *h_sticky_inbox[] ; 

extern char *h_sticky_smtp[] ; 

extern char *h_sticky_user_id[] ; 

extern char *h_sticky_domain[] ; 

extern char *h_bounce[] ; 

extern char *h_incoming_add_folder_host[] ; 

extern char *h_incoming_add_folder_name[] ; 

extern char *h_incoming_add_folder_nickname[] ; 

extern char *h_anon_forward[] ; 

extern char *h_news_subscribe[] ; 

extern char *h_pipe_msg[] ; 

extern char *h_pipe_attach[] ; 

extern char *h_select_by_num[] ; 

extern char *h_select_txt_from[] ; 

extern char *h_select_txt_to[] ; 

extern char *h_select_txt_cc[] ; 

extern char *h_select_txt_subj[] ; 

extern char *h_select_txt_all[] ; 

extern char *h_attach_index_whereis[] ; 

extern char *h_kb_lock[] ; 

extern char *h_config_whereis[] ; 

extern char *h_config_add[] ; 

extern char *h_config_change[] ; 



extern char **h_texts[];

