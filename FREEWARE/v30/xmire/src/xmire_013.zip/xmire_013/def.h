/* xmire -- mire under X
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*+
 * Title            : xmire
 * Subject          : Mire sous X.
 * File             : def.h
 * Author           : Martin Vicente <vicente@cena.dgac.fr> DGAC/CENA/SID
 * Last Modified By : Martin Vicente
 * Last Modified On : Tue Sep 19 21:02:54 1995
-*/


#ifdef __vms__
# include <sys$library:stdlib.h>
#else
# include <stdlib.h>
#endif

#if !defined EXIT_SUCCESS || !defined EXIT_FAILURE
#  ifdef __vms__
#    define EXIT_SUCCESS  1
#    define EXIT_FAILURE  02000000000L
#  else
#    define EXIT_SUCCESS  0
#    define EXIT_FAILURE  1
#  endif
#endif

enum {null = NULL};
enum bool {false, true};
enum exit {success = EXIT_SUCCESS, failure = EXIT_FAILURE};

typedef enum bool bool;
