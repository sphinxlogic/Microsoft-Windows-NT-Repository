char *version = "@(#)\
XKeyCaps 2.29; Copyright (c) 1991, 1992, 1993, 1994, 1995 Jamie Zawinski (jwz@netscape.com)";
