char *version_string = "3.72.1";

/*
  Local variables:
  version-control: never
  End:
 */
