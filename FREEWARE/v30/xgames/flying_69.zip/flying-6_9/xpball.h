//
// Erweiterung der PBall-Klasse um X-Spezifika
//
class PBall : public PBallTop {
	public:
		PBall( PBallType mode=BillardQueue, char *display=0l );
		~PBall();

	protected:
		virtual void Update();

		virtual void Warp( const Vec2 &dest );
		virtual void RedrawPointer();						// Mausanzeige
		virtual void SetPointer( int x, int y );		// Mausanzeige

	private:
		struct _XDisplay	*rem_dpy;
		int					scr;
		Real					w2n_x, w2n_y;
};
