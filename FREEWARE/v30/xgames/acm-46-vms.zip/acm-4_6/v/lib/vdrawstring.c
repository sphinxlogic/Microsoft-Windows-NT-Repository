#include "Vlib.h"

void VDrawString(v, win, gc, p, str, len)
Viewport *v;
Window	 win;
GC	 gc;
VPoint	 *p;
char	 *str;
int	 len; {

	register int	x, y;

	if (v->flags & VPPerspective) {
		x = v->Middl.x + (int) (v->Scale.x * p->x / p->z);
		y = v->Middl.y - (int) (v->Scale.y * p->y / p->z);
	}
	else {
		x = v->Middl.x + (int) (v->Scale.x * p->x);
		y = v->Middl.y - (int) (v->Scale.y * p->y);
	}

	XDrawString (v->dpy, win, gc, x, y, str, len);

}
