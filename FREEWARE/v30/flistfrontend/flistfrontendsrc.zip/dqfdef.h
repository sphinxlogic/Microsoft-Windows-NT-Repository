/******************************************************************************
 * Copyright 1984 by Thomas E. Dickey.  All Rights Reserved.                  *
 *                                                                            *
 * You may freely copy or redistribute this software, so long as there is no  *
 * profit made from its use, sale trade or reproduction. You may not change   *
 * this copyright notice, and it must be included in any copy made.           *
 ******************************************************************************/
/* $Id: dqfdef.h,v 1.2 1984/12/08 02:25:42 tom Exp $ */

#define	DQF$M_ACTIVE	0x1
#define	DQF$V_ACTIVE	0x0
