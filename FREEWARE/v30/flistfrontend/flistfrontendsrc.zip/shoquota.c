/******************************************************************************
 * Copyright 1995 by Thomas E. Dickey.  All Rights Reserved.                  *
 *                                                                            *
 * You may freely copy or redistribute this software, so long as there is no  *
 * profit made from its use, sale trade or reproduction. You may not change   *
 * this copyright notice, and it must be included in any copy made.           *
 ******************************************************************************/
#ifndef NO_IDENT
static char *Id = "$Id: shoquota.c,v 1.3 1995/06/06 13:37:08 tom Exp $";
#endif

#include <string.h>

void	shoquota (char *bfr)
{
	strcpy (bfr, "QUOTA-display not implemented");
}
