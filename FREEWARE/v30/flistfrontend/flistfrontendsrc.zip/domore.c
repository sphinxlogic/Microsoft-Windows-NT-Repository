/******************************************************************************
 * Copyright 1985 by Thomas E. Dickey.  All Rights Reserved.                  *
 *                                                                            *
 * You may freely copy or redistribute this software, so long as there is no  *
 * profit made from its use, sale trade or reproduction. You may not change   *
 * this copyright notice, and it must be included in any copy made.           *
 ******************************************************************************/
#ifndef NO_IDENT
static char *Id2 = "$Id: domore.c,v 1.2 1985/01/14 12:42:30 tom Exp $";
#endif

#define	main_incl	more
#include	"browse.c"
