/******************************************************************************
 * Copyright 1995 by Thomas E. Dickey.  All Rights Reserved.                  *
 *                                                                            *
 * You may freely copy or redistribute this software, so long as there is no  *
 * profit made from its use, sale trade or reproduction. You may not change   *
 * this copyright notice, and it must be included in any copy made.           *
 ******************************************************************************/
/* $Id: canopen.h,v 1.1 1995/06/04 01:58:17 tom Exp $
 *
 * interface of canopen.c
 */
extern	int	canopen (char *name_);
