/* This file is made obsolete by Scrollbar.h */

/*
 * Only allow the use of the old name when the back compatability
 * flag is set.
 * 
 * Chris Peterson - 12/15/89
 */

#ifdef XAW_BC
#    include <X11/Xaw/Scrollbar.h>
#endif 

