/* This file is made obsolete by Paned.h */

/*
 * Only allow the use of the old name when the back compatability
 * flag is set.
 * 
 * Chris Peterson - 12/15/89
 */

#ifdef XAW_BC
#ifdef vax11c
#    include <X11Xaw/Paned.h>
#else
#    include <X11/Xaw/Paned.h>
#endif /* vax11c */
#endif 

