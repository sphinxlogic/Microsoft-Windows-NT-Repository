/****************************************************************/
/*								*/
/* ext.h:	some ext's for all				*/
/*								*/
/*		Design: Walter Benzing 1994			*/
/*		NO RIGHTS RESERVED				*/
/*								*/
/****************************************************************/

#ifndef _EXT_H
#define _EXT_H

/* external declarations */

extern double CO_Base(double);
extern void CO_CalculateBases(ViewportInfo *);
extern int CO_Cast2Double(ViewportInfo *, XDimInfo *);
extern int CO_Cast2UChar(ViewportInfo *, XDimInfo *);
extern int CO_Data2Int(ViewportInfo*, XDimInfo *);
extern double CO_Inter(double, double, ViewportInfo*);
extern void CO_MinMax(double*, double*, int, double*);
extern void CO_MinMaxChar(double*, double*, int, unsigned char*);
extern int CO_NextStep(double, double, double*, double*, double*,
	ViewportInfo*);
extern int CO_NewData(int, int, int, XDimInfo*);
extern int CO_Point(int, int, double*, double *, double *,
	ViewportInfo*, XDimInfo*);
extern int CO_StartSpline(int, double, double*, double*, XDimInfo*);
extern double CO_Spline(double, double, int, double*, double*);
extern void FI_AddLink(int, int, char*, char*, XDimInfo*);
extern int FI_AsciiExportData(char*, XDimInfo*);
extern void FI_DeleteLink(int, ViewportInfo *, XDimInfo*);
extern int FI_GetLink(char*, ViewportInfo*, XDimInfo*);
extern int FI_GifExportPic(char *, XDimInfo*);
extern int FI_ImportAsciiData(XDimInfo*);
extern int FI_ImportGifPic(XDimInfo*);
extern int FI_LoadData(XDLinks*, XDimInfo*);
extern int FI_LoadDeco(XDimInfo*);
extern int FI_LoadPref(XDimInfo*);
extern void FI_RemoveWasteLinks(int, XDimInfo*);
extern int FI_SaveData(XDimInfo*);
extern int FI_SaveDeco(XDimInfo*);
extern int FI_SavePref(XDimInfo*);
extern char *FI_StripFilename(char*);
extern int FI_WriteValue(int, int, int);
extern void GR_AllocateColors(XDimInfo*);
extern void GR_ColoredGridImage(myCoor, myCoor, myCoor, myCoor, int,
	ViewportInfo *, XDimInfo *);
extern void GR_InitColorImport( int, XDColorInfo*, XDHardwareInfo*);
extern void GR_InitColorInfo(XDColorInfo*);
extern void GR_InitDeco(myPixel*, myPixel, myPixel);
extern void GR_InitGraphics(XDimInfo*);
extern void GR_HiddenGridImage(myCoor, myCoor, myCoor, myCoor, int,
	ViewportInfo *, XDimInfo *);
extern void GR_HideLine(myPixel, int, int, int, int,
	myCoor *, myCoor *, int, int, myPixel *);
extern void GR_myHiddenLine(myPixel, int, int, int, int,
	myCoor *, myCoor *, int, int, myPixel *);
extern void GR_myTriangle(myPixel*, myCoor, myCoor, myCoor,
	myCoor, myCoor, myCoor, myCoor, myCoor, myCoor, int, int, myPixel*);
extern int GR_ReadPixel(int, int);
extern void GR_ResetAllDecoding(XDimInfo*);
extern int GR_ResizeViewport(ViewportInfo *, XDimInfo *);
extern void GR_Trans(ViewportInfo*, Pixel*, Boolean, int);
extern void GR_Triangle(myPixel *, myCoor, myCoor, myCoor, myCoor, myCoor,
	myCoor, myCoor, int, int, myPixel*);
extern void HW_AllocateColor(int, unsigned short,
	unsigned short, unsigned short, XDimInfo*);
extern void HW_AvailableColors(XDimInfo*);
extern void HW_ClearWindow(Window , ViewportInfo*, XDimInfo*);
extern void HW_ClearPict(Window , ViewportInfo*, XDimInfo*);
extern void HW_DrawLine(int , int , int , int , Window, XDHardwareInfo*);
extern void HW_DrawText(char *, int, int, int, Window,
	XDHardwareInfo *);
extern void HW_FillBox(int, int, int, int, Pixel, Window, XDimInfo*);
extern void HW_FreeUnusedColors(XDimInfo*);
extern void HW_GetInfo(XDHardwareInfo*);
extern void HW_PutLine(myPixel, int, int, int, int, int, int, 
	myPixel*, XDHardwareInfo*);
extern void HW_PutText(char *, int, int, int, int, myPixel, int,
	myPixel *, XDHardwareInfo *);
extern void HW_DrawLines(Window, XPoint*, int, XDHardwareInfo*);
extern void HW_TextExtent(char*, int*, int*, XDHardwareInfo*);
extern int HW_Image(int, int, int, int, myPixel*, Window, Pixel*, XDHardwareInfo*);
extern void HW_SetFore(Pixel, XDHardwareInfo *);
extern void HW_SetBack(Pixel, XDHardwareInfo*);
extern void MA_Abs(Widget, XtPointer, XtPointer);
extern void MA_AbsPhi(Widget, XtPointer, XtPointer);
extern void MA_Add(int, void*, void*);
extern void MA_CAdd(int, void*, void*);
extern void MA_CalcFFT(double*, double*, int, int, double);
extern void MA_CDiv(int, void*, void*);
extern void MA_CMul(int, void*, void*);
extern void MA_CSub(int, void*, void*);
extern void MA_cxy(Widget, XtPointer, XtPointer);
extern void MA_Exp(Widget, XtPointer, XtPointer);
extern void MA_GetOffset(Widget, XtPointer, XtPointer);
extern void MA_GetScale(Widget, XtPointer, XtPointer);
extern void MA_HiLoPass(int, void*, void*);
extern void MA_Interpolate(int, int, ViewportInfo*, XDimInfo*);
extern void MA_Log(Widget, XtPointer, XtPointer);
extern void MA_Log10(Widget, XtPointer, XtPointer);
extern void MA_Matrix(int, void*, void*);
extern void MA_Median(int, void*, void*);
extern void MA_MirrorX(Widget, XtPointer, XtPointer);
extern void MA_MirrorY(Widget, XtPointer, XtPointer);
extern void MA_Neg(Widget, XtPointer, XtPointer);
extern void MA_okEditVal(int, void*, void*);
extern void MA_Offset(int, void*, void*);
extern void MA_PopMatrix(int, void*, void*);
extern void MA_Quad(Widget, XtPointer, XtPointer);
extern void MA_Scale(int, void*, void*);
extern void MA_Spline(int, int, ViewportInfo*, XDimInfo*);
extern void MA_Sqrt(Widget, XtPointer, XtPointer);
extern void MA_1x(Widget, XtPointer, XtPointer);
extern void MA_StartAdd(Widget, XtPointer, XtPointer);
extern void MA_StartCAdd(Widget, XtPointer, XtPointer);
extern void MA_StartCDiv(Widget, XtPointer, XtPointer);
extern void MA_StartCMul(Widget, XtPointer, XtPointer);
extern void MA_StartCSub(Widget, XtPointer, XtPointer);
extern void MA_StartDiv(Widget, XtPointer, XtPointer);
extern void MA_StartFFT(Widget, XtPointer, XtPointer);
extern void MA_StartHiLo(Widget, XtPointer, XtPointer);
extern void MA_StartMul(Widget, XtPointer, XtPointer);
extern void MA_StartNew(Widget, XtPointer, XtPointer);
extern void MA_StartOtherF(Widget, XtPointer, XtPointer);
extern void MA_StartSub(Widget, XtPointer, XtPointer);
extern void WD_CancelColorEdit(Widget , XtPointer , XtPointer);
extern ViewportInfo *WD_CopyViewport(String, String, String,
	ViewportInfo*, ViewportInfo*, XDimInfo*);
extern void WD_CreateColors(Widget, XDimInfo*);
extern void WD_CreateCut(Widget, XDimInfo*);
extern void WD_CreateEditDeco(Widget, XDimInfo*);
extern int WD_CreateEditMatrix(String, String, String,
	int, int, int, int, XDimInfo*);
extern void WD_CreateHelp(Widget, XDimInfo*);
extern void WD_CreateImEx(Widget, XDimInfo*);
extern void WD_CreateLink(Widget, XDimInfo*);
extern void WD_CreateMain(Widget, XDimInfo*);
extern void WD_CreateMath(Widget, XDimInfo*);
extern void WD_CreatePos(Widget, XDimInfo*);
extern void WD_CreateViewport(Widget, XtPointer, XtPointer);
extern void WD_DrawInput(Widget , XtPointer , XtPointer);
extern void WD_InitFont(XDimInfo*);
extern void WD_LinkView(Widget , XtPointer , XtPointer);
extern void WD_ManageWinPref(Widget , XtPointer , XtPointer);
extern void WD_ManageGridPref(Widget , XtPointer , XtPointer);
extern void WD_ManageImport(Widget , XtPointer , XtPointer);
extern void WD_ManageExport(Widget , XtPointer , XtPointer);
extern void WD_ManageMovPref(Widget , XtPointer , XtPointer);
extern void WD_okColorEdit(Widget , XtPointer , XtPointer);
extern void WD_okColorNew(Widget , XtPointer , XtPointer);
extern void WD_okCreateLink(Widget , XtPointer , XtPointer);
extern void WD_okDeleteLink(Widget , XtPointer , XtPointer);
extern void WD_okGetMatrix(Widget, XtPointer, XtPointer);
extern void WD_PopCreateLink(Widget , XtPointer , XtPointer);
extern void WD_PopCut(Widget, XtPointer, XtPointer);
extern void WD_PopDeleteLink(Widget , XtPointer , XtPointer);
extern void WD_PopEdit(Widget , XtPointer , XtPointer);
extern void WD_PopInput(char*, char *, int, int, XDimRetFunc, XDimInfo*);
extern void WD_PopInput2(char*, char *, int, int, char*, char*, int, int,
	XDimRetFunc, XDimInfo*);
extern void WD_PopTypeCast(int, int, XDimInfo*);
extern void WD_PopShowLink(Widget , XtPointer , XtPointer);
extern void WD_PositionDeco(Widget , XtPointer , XtPointer);
extern void WD_RecLoadData(XDLinks*, ViewportInfo*, XDimInfo*);
extern void WD_RecSaveData(XDimInfo*);
extern void WD_RedrawCut(double, double, ViewportInfo*, XDimInfo*);
extern void WD_RedrawLink(XDimLink*, ViewportInfo*, XDimInfo*);
extern void WD_RedrawMath(XDimInfo*);
extern void WD_ReInitDeco(XDimInfo*);
extern void WD_SaveData(Widget, XtPointer, XtPointer);
extern void WD_Select2Delete(Widget , XtPointer , XtPointer);
extern void WD_SetBackground(Widget, XDColorInfo*);
extern void WD_SetFastRedraw(Widget, XtPointer, XtPointer);
extern void WD_SetNormalRedraw(Widget, XtPointer, XtPointer);
extern void WD_SetTitle(int, ViewportInfo*, String, String, XDimInfo*);
extern void WD_ViewportMessage(ViewportInfo* , XDimInfo*);
extern void WD_XDimError(XDimInfo*, Widget);
extern void WD_XDimMessage(XDimInfo*);
extern void XD_GoodBye(void);
extern void XT_DeleteColorRow(Widget , XtPointer , XtPointer);
extern void XT_DestroyViewport(Widget , XtPointer , XtPointer);
extern void XT_DestroyMatrix(Widget , XtPointer , XtPointer);
extern void XT_ForceActRedraw(Widget, XtPointer, XtPointer);
extern void *XT_GetNamedRedraw(char*, XDimInfo *);
extern int XT_GetRedrawIndex(void *, XDimInfo *);
extern void XT_Histogramm(Widget, XtPointer, XtPointer);
extern void XT_SetViewport(Widget , XtPointer , XEvent*, Boolean*);
extern void XT_ManageIt(Widget , XtPointer , XtPointer);
extern void XT_NormalRedraw(Widget, XtPointer, XtPointer);
extern void XT_NotifyPaletteChanged(XDimInfo*);
extern void XT_Popitup(Widget , XtPointer , XtPointer);
extern void XT_PopnGrab(Widget , XtPointer , XtPointer);
extern void XT_Popdown(Widget , XtPointer , XtPointer);
extern void WD_PopMath(char*, char*, int, XDimRetFunc, XDimInfo*);
extern void XT_Redraw(Widget , XtPointer , XtPointer);
extern void XT_RedrawColors(Widget , XtPointer , XtPointer);
extern void XT_RedrawColorRow(Widget , XtPointer , XtPointer);
extern void XT_RedrawComFilled(Window, ViewportInfo*, ViewportInfo*, XDimInfo*);
extern void XT_RedrawComHFilled(Window, ViewportInfo*, ViewportInfo*, XDimInfo*);
extern void XT_RedrawCut2D(Window, ViewportInfo*, ViewportInfo*, XDimInfo*);
extern void XT_RedrawDecoVector(Widget , XtPointer , XtPointer );
extern void XT_RedrawFilled(Window, ViewportInfo*, ViewportInfo*, XDimInfo*);
extern void XT_RedrawGrid(Window, ViewportInfo*, ViewportInfo*, XDimInfo*);
extern void XT_RedrawHFilled(Window, ViewportInfo*, ViewportInfo*, XDimInfo*);
extern void XT_RedrawHidden(Window, ViewportInfo*, ViewportInfo*, XDimInfo*);
extern void XT_RedrawLines(Window, ViewportInfo*, ViewportInfo*, XDimInfo*);
extern void XT_RedrawZoomedDeco(Widget , XtPointer , XtPointer );
extern void XT_StartRotLeft(Widget , XtPointer , XtPointer);
extern void XT_StartRotRight(Widget , XtPointer , XtPointer);
extern void XT_StartRotUp(Widget , XtPointer , XtPointer);
extern void XT_StartRotDown(Widget , XtPointer , XtPointer);
extern void XT_StartZoomZPlus(Widget , XtPointer , XtPointer);
extern void XT_StartZoomZMinus(Widget , XtPointer , XtPointer);
extern void XT_StartZoomXYPlus(Widget , XtPointer , XtPointer);
extern void XT_StartZoomXYMinus(Widget , XtPointer , XtPointer);
extern void XT_StartMoveLeft(Widget , XtPointer , XtPointer);
extern void XT_StartMoveRight(Widget , XtPointer , XtPointer);
extern void XT_StartMoveUp(Widget , XtPointer , XtPointer);
extern void XT_StartMoveDown(Widget , XtPointer , XtPointer);
extern void XT_StopTimer(Widget , XtPointer , XtPointer);
extern void XT_UnmanageIt(Widget , XtPointer , XtPointer);

#endif /* _EXT_H */
