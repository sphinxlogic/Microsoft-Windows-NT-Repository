/*
 *  Copyright (c) 1992, 1994 John E. Davis  (davis@amy.tch.harvard.edu)
 *  All Rights Reserved.
 */
extern int replace_next(char *, char *);

#ifndef Sixteen_Bit_System
extern void append_region_to_kill_array (int *);
extern void insert_from_kill_array (int *);
extern void copy_region_to_kill_array (int *);
extern int Kill_Array_Size;
#endif
