/* It is too bad that this cannot be done at the preprocessor level.  
 * Unfortunately, C is not completely portable yet.
 */
#include <stdio.h>
#include "slang.h"

int main (int argc, char **argv)
{
   unsigned int min_version, sl_version, a, b, c;
   if (argc != 3)
     {
	fprintf (stderr, "Usage: %s <PGM> <SLANG-VERSION>\n", argv[0]);
	return 1;
     }
   sscanf (argv[2], "%u", &min_version);
#ifndef SLANG_VERSION
   sl_version = 0;
#else
   sl_version = SLANG_VERSION;
#endif
   
   a = min_version/10000;
   b = (min_version - a * 10000) / 100;
   c = min_version - (a * 10000) - (b * 100);

   if (sl_version < min_version)
     {
	fprintf (stderr, "This version of %s requires slang version %d.%d.%d\n",
	      argv[1], a, b, c);
	return 1;
     }
   return 0;
}

	    
	    
  
