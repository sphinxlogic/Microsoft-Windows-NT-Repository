#include <stdio.h>
#include "config.h"
#include "sysdep.h"
#include "slang.h"
#include "keymap.h"
#include "misc.h"
#include "paste.h"
#include "screen.h"
#include "ledit.h"
#include "ins.h"
#include "display.h"
#include "hooks.h"

int (*JMouse_Event_Hook)(void);
void (*JMouse_Hide_Mouse_Hook) (int);
int Suspend_Mouse_Events;

#ifdef USE_GPM_MOUSE
# include "gpmmouse.c"
#else
#if defined(msdos) || defined(__GO32__)
# include "pcmouse.c"
#else
int (*X_Open_Mouse_Hook)(void);
void (*X_Close_Mouse_Hook)(void);
#endif /* ibmpc */
#endif /* USE_GPM_MOUSE */
