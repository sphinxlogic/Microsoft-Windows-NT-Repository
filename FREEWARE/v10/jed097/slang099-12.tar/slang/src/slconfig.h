#ifndef _confwcc_h_
#define _confwcc_h_

#ifdef __WATCOMC__

#ifndef msdos
#define msdos
#endif

#ifndef  DOS386
#define  DOS386
#endif

#ifndef  FLOAT_TYPE
#define  FLOAT_TYPE
#endif

#ifndef  HAS_MEMCPY
#define  HAS_MEMCPY
#endif

#ifndef  HAS_MEMCMP
#define  HAS_MEMCMP
#endif

#ifndef  HAS_MEMSET
#define  HAS_MEMSET
#endif

#ifndef  HAS_MEMCHR
#define  HAS_MEMCHR
#endif

#endif /* __watcomc__ */

#endif /* _slconfig_h_ */
