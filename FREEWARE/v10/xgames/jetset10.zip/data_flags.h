#ifndef DATA_FLAGS_H_
#define DATA_FLAGS_H_

#include "data.h"

#define ROOM_LIANE		(1<<0)
#define ROOM_NO_AUTOMOVE	(1<<1)
#define ROOM_DBL_AUTOMOVE	(1<<2)
#define ROOM_SPECIAL		(1<<3)


extern unsigned long room_flags[NROOM];

#endif /* DATA_FLAGS_H_ */
