#ifndef DATA_COLORS_H_
#define DATA_COLORS_H_

#include "data.h"

extern unsigned char room_border[NROOM];
extern unsigned char room_colors[NROOM][3];

#endif /* DATA_COLORS_H_ */

