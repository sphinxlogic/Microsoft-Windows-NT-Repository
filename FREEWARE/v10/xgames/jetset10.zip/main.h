/* main.h */

#ifndef MAIN_H_
#define MAIN_H_


#include <X11/Xlib.h>
#include <X11/Xos.h>
#include <X11/Xutil.h>
#include <X11/IntrinsicP.h>
#include <X11/StringDefs.h>
#ifdef VMS
#include <X11Xaw/Box.h>
#include <X11Xaw/Command.h>
#include <X11Xaw/Form.h>
#else
#include <X11/Xaw/Box.h>
#include <X11/Xaw/Command.h>
#include <X11/Xaw/Form.h>
#endif
#if 0
#ifdef VMS
#include <X11Xaw/Scrollbar.h>
#else
#include <X11/Xaw/Scrollbar.h>
#endif /* VMS */
#endif
#include <X11/Shell.h>


#include "widget.h"


extern XtAppContext application_context;
extern Display *display;
extern MyWidget canvas_widget;
extern Pixmap canvas;
extern Widget roomname_widget;
extern Widget itemstaken_widget;
extern Widget lives_widget;
extern Widget tripswitch_widget;
extern Widget discovery_widget;
extern Widget play_button;
extern MyWidget time_widget;

extern int depth;
extern GC gc_scroll;
extern GC gc_string;
extern GC gc_time;
extern GC gc_black;
extern GC gc_white;
extern GC gc_copyplane;
extern GC gc_xorchar;
extern GC gc_xorplane[4];
extern GC gc_and[4];
extern GC gc_zero;
extern GC gc_three;
extern GC gc_dash[4];
extern Colormap colormap;
#define NBCOLORS 4
extern GC gcs[NBCOLORS];
extern unsigned long pixels[NBCOLORS];
extern int color_display;

#endif /* MAIN_H_ */
