#ifndef GAME_H_
#define GAME_H_

#include "data.h"

#define NB_FLASHES_COLOR 5
#define NB_FLASHES_MONO 5

#define WIN_ITEMS 175


#define STATE_PRESENT	0
#define STATE_PLAYING	1
#define STATE_DYING	2
#define STATE_ROCKET	3
#define STATE_TELEPORT	4
#define STATE_BOAT	5
extern int global_state;
extern int discovery_mode;
extern int has_won;
extern int nb_items_taken;
extern int nb_lives;
extern int time_cnt;

extern unsigned char room_data[YROOM][XROOM];
extern int room_no;

extern int goright;
extern int goleft;
extern int dojump;


extern void move (void);
extern void die (void);
extern void new_game (void);
extern int load_game (void);
extern int save_game (int emergency);
extern void emergency (int sig);

#endif /* GAME_H_ */
