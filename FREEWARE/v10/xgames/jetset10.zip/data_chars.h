#ifndef DATA_CHARS_H_
#define DATA_CHARS_H_

#include "data.h"

extern int room_chars[NROOM][8];
typedef struct {
    unsigned char fg;
    unsigned char bg;
} FgBg;
extern FgBg char_colors[NCHARS];

#endif /* DATA_CHARS_H_ */

