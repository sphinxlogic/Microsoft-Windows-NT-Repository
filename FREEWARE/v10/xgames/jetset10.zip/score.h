#ifndef SCORE_H_
#define SCORE_H_


#define SCORE_ACTIVE	0 /* save score as active (quit) */
#define SCORE_DEAD	1 /* save score as inactive (dead/won) */
#define SCORE_REMOVE	2 /* remove the active score of this player */

extern void save_score (int items, int deaths, int time_cnt, int flag);
extern void print_scores (int all);


#endif /* SCORE_H_ */
