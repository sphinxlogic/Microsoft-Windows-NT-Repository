#ifndef DATA_H_
#define DATA_H_

#define NROOM 134
#define NCHARS 446
#define NMONSTERS 307

#define XROOM 32
#define YROOM 16

#define I_NOTHING	0
#define I_WALLSOFT	1
#define I_WALLHARD	2
#define I_DIE		3
#define I_STAIRRIGHT	4
#define I_MOVELEFT	5
#define I_ITEM		6
#define I_STAIRLEFT	7
#define I_MOVERIGHT	8

extern char room_name[NROOM][33];
typedef struct {
    unsigned char data[YROOM][XROOM];
} Room;
extern Room rooms[NROOM];

#endif /* DATA_H_ */

