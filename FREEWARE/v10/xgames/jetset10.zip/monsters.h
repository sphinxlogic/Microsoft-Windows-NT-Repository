#ifndef MONSTERS_H_
#define MONSTERS_H_

#define monsters_width 32
#define monsters_height 9824
extern char monsters_bits[];

#endif /* MONSTERS_H_ */
