#ifndef DATA_SPRITE_H_
#define DATA_SPRITE_H_

#include "data.h"

extern unsigned char room_sprite[NROOM];

#endif /* DATA_SPRITE_H_ */

