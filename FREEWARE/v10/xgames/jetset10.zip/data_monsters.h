#ifndef DATA_MONSTERS_H_
#define DATA_MONSTERS_H_

#include "data.h"

#define MO_ARROW	(1<<0)
#define MO_OFF_IS_X	(1<<1)
#define MO_FIXED_DIR	(1<<2)
#define MO_ONE_WAY	(1<<3)
#define MO_LIFT		(1<<4)
#define MO_FRIENDLY	(1<<5)

typedef struct {
    int sprite;
    int counter;
    int reload;
    int x;
    int y;
    int dx;
    int dy;
    int color;
    int flags;
    int offsetmask;
} Monster;

#define MONSTERS_PER_ROOM 8

typedef Monster RoomMonsters[MONSTERS_PER_ROOM];

extern RoomMonsters room_monsters[NROOM];

#endif /* DATA_MONSTERS_H_ */
