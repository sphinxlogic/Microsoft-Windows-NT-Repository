#ifndef DATA_NEIGHB_H_
#define DATA_NEIGHB_H_

#include "data.h"

#define DIR_LEFT	0
#define DIR_UP		1
#define DIR_RIGHT	2
#define DIR_DOWN	3

extern int room_neighb[NROOM][4]; /* left, above, right, below */

#endif /* DATA_NEIGHB_H_ */

