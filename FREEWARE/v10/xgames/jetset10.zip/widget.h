/* widget.h */

#ifndef WIDGET_H_
#define WIDGET_H_

#include <X11/Xlib.h>
#include <X11/IntrinsicP.h>


/*
 * New resource
 */


/* #define XtNmyPlayerno "myPlayerno" */
/* #define XtCMyPlayerno "MyPlayerno" */


/*
 * New fields for My widget class record
 */


typedef struct {
    int dummy;
} MyClassPart;


/*
 * Full class record declaration
 */


typedef struct _MyClassRec {
    CoreClassPart core_class;
    MyClassPart my_class;
} MyClassRec;

extern MyClassRec myClassRec;
extern WidgetClass myWidgetClass;


/*
 * New fields for My widget record
 */


typedef struct _MyPart {
    Pixmap store;
    GC gc;
} MyPart;


/*
 * Full instance record declaration
 */


typedef struct _MyRec {
    CorePart core;
    MyPart my;
} MyRec, *MyWidget;









extern void Update_Screen (MyWidget w);
extern void Update_Zone (MyWidget w, int x, int y, int width, int height);







#endif /* WIDGET_H_ */
