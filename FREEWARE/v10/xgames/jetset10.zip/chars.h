#ifndef CHARS_H_
#define CHARS_H_

#define chars_width 16
#define chars_height 7136
extern char chars_bits[];

#endif /* CHARS_H_ */
