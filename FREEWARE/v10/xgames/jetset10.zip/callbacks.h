#ifndef CALLBACKS_H_
#define CALLBACKS_H_

#include "data.h"

extern void quit_button_cb (void);
extern void play_button_cb (void);
extern void discovery_cb (void);
extern void set_play_state (void);
extern void set_discovery_state (void);

extern void set_timeout (void);


#if 0
#define SLIDERSIZE (NROOM-1)
#define SLIDERTHUMB 5
extern void slider_jump_cb ();
extern void slider_scroll_cb ();
#endif

#endif /* CALLBACKS_H_ */
