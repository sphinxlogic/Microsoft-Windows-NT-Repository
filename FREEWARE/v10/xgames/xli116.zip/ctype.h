

#ifndef CTYPE_H
#define CTYPE_H



/*
 *	VAX-11 "C" runtime compatible ctype include
 */

#define _U	01
#define _L	02
#define _N	04
#define _S	010
#define _P	020
#define _C	040
#define _X	0100
#define _B	0200

#define	_ctype_	$$PsectAttributes_NOWRT$$_ctype_
extern	char	_ctype_[];

/*
 *	The following bit of ugliness is to ensure that the __ctype__[]
 *	initialization is brought in from the VAX-11 "C" runtime library
 */


#ifdef __cplusplus
extern "C" {
#endif  


extern c$v_ctypedefs();

#ifdef __cplusplus
}
#endif




static int __ctype__dummy(){c$v_ctypedefs();}
 
/*
 *	ctype macros:  Note we need to strip the character to 7-bit ascii
 */
#define isalpha(c)	(_ctype_[(c) & 0x7f] & (_U | _L))
#define isupper(c)	(_ctype_[(c) & 0x7f] & _U)
#define islower(c)	(_ctype_[(c) & 0x7f] & _L)
#define isdigit(c)	(_ctype_[(c) & 0x7f] & _N)
#define isxdigit(c)	(_ctype_[(c) & 0x7f] & (_N | _X))
 /* #define isspace(c)	((_ctype_[(c) & 0x7f] & _S)&&((c) >= 0)) */
#define isspace(c)	(_ctype_[(c) & 0x7f] & _S)
#define ispunct(c)	(_ctype_[(c) & 0x7f] & _P)
#define isalnum(c)	(_ctype_[(c) & 0x7f] & (_U | _L | _N))
#define isprint(c)	(_ctype_[(c) & 0x7f] & (_P | _U | _L | _N | _B))
#define isgraph(c)	(_ctype_[(c) & 0x7f] & (_P | _U | _L | _N))
#define iscntrl(c)	(_ctype_[(c) & 0x7f] & _C)
#define isascii(c)	((unsigned)(c) <= 0177)

#define toupper(c)        ((c)>='a' && (c)<='z')?((c)-'a'+'A'):(c)
#define tolower(c)        ((c)>='A' && (c)<='Z')?((c)-'A'+'a'):(c)



/* #define toupper(c)	((c)-'a'+'A') */
/* #define tolower(c)	((c)-'A'+'a') */
#define toascii(c)	((c)&0177)



#endif

