optimize='-O1'
usemymalloc='y'
d_voidsig=define
usevfork=false
d_charsprf=undef
ccflags="-ansiposix -signed"
