/*   Perl hooks into the routines in vms.c for interconversion
 *   of VMS and Unix file specification syntax.
 *
 *   Version:  1.0
 *   Author:   Charles Bailey  bailey@genetics.upenn.edu
 *   Revised:  15-Nov-1994
 */

#include <nam.h>  /* for NAM$C_MAXRSS */

#include "EXTERN.h"
#include "perl.h"
#include "XSUB.h"

XS(XS_File__VMSspec_vmsify)
{
    dXSARGS;
    if (items != 1) {
	croak("Usage: File::VMSspec::vmsify(spec)");
    }
    {
	char *	spec = (char *)SvPV(ST(0),na);
	    char buf[NAM$C_MAXRSS+1];
	    ST(0) = sv_newmortal();
	    if (tovmsspec(spec,buf) != NULL) sv_setpv(ST(0),buf);
    }
    XSRETURN(1);
}

XS(XS_File__VMSspec_unixify)
{
    dXSARGS;
    if (items != 1) {
	croak("Usage: File::VMSspec::unixify(spec)");
    }
    {
	char *	spec = (char *)SvPV(ST(0),na);
	    char buf[NAM$C_MAXRSS+1];
	    ST(0) = sv_newmortal();
	    if (tounixspec(spec,buf) != NULL) sv_setpv(ST(0),buf);
    }
    XSRETURN(1);
}

XS(XS_File__VMSspec_pathify)
{
    dXSARGS;
    if (items != 1) {
	croak("Usage: File::VMSspec::pathify(spec)");
    }
    {
	char *	spec = (char *)SvPV(ST(0),na);
	    char buf[NAM$C_MAXRSS+1];
	    ST(0) = sv_newmortal();
	    if (pathify_dirspec(spec,buf) != NULL) sv_setpv(ST(0),buf);
    }
    XSRETURN(1);
}

XS(XS_File__VMSspec_fileify)
{
    dXSARGS;
    if (items != 1) {
	croak("Usage: File::VMSspec::fileify(spec)");
    }
    {
	char *	spec = (char *)SvPV(ST(0),na);
	    char buf[NAM$C_MAXRSS+1];
	    ST(0) = sv_newmortal();
	    if (fileify_dirspec(spec,buf) != NULL) sv_setpv(ST(0),buf);
    }
    XSRETURN(1);
}

XS(XS_File__VMSspec_vmspath)
{
    dXSARGS;
    if (items != 1) {
	croak("Usage: File::VMSspec::vmspath(spec)");
    }
    {
	char *	spec = (char *)SvPV(ST(0),na);
	    char buf[NAM$C_MAXRSS+1];
	    ST(0) = sv_newmortal();
	    if (tovmspath(spec,buf) != NULL) sv_setpv(ST(0),buf);
    }
    XSRETURN(1);
}

XS(XS_File__VMSspec_unixpath)
{
    dXSARGS;
    if (items != 1) {
	croak("Usage: File::VMSspec::unixpath(spec)");
    }
    {
	char *	spec = (char *)SvPV(ST(0),na);
	    char buf[NAM$C_MAXRSS+1];
	    ST(0) = sv_newmortal();
	    if (tounixpath(spec,buf) != NULL) sv_setpv(ST(0),buf);
    }
    XSRETURN(1);
}

XS(boot_File__VMSspec)
{
    dXSARGS;
    char* file = __FILE__;

    newXS("File::VMSspec::vmsify", XS_File__VMSspec_vmsify, file);
    newXS("File::VMSspec::unixify", XS_File__VMSspec_unixify, file);
    newXS("File::VMSspec::pathify", XS_File__VMSspec_pathify, file);
    newXS("File::VMSspec::fileify", XS_File__VMSspec_fileify, file);
    newXS("File::VMSspec::vmspath", XS_File__VMSspec_vmspath, file);
    newXS("File::VMSspec::unixpath", XS_File__VMSspec_unixpath, file);
    ST(0) = &sv_yes;
    XSRETURN(1);
}
