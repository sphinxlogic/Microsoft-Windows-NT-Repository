use ExtUtils::MakeMaker;
WriteMakefile(LIBS => ["-lm -lposix -lcposix"]);
