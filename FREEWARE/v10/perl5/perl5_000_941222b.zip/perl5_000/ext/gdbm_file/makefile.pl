use ExtUtils::MakeMaker;
WriteMakefile(LIBS => ["-lgdbm", "-ldbm"]);
