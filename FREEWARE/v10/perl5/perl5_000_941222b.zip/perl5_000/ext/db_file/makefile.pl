use ExtUtils::MakeMaker;
WriteMakefile(LIBS => ["-ldb"]);
