use ExtUtils::MakeMaker;
WriteMakefile(
    'LINKTYPE'  => 'static',
    'DEFINE'	=> '-DSDBM -DDUFF',
    'SKIP'	=> [qw(static static_lib dynamic dynamic_lib)],
    'clean'
	=> {'FILES' => 'dbu libsdbm.a dbd dba dbe x-dbu *.dir *.pag'}
);


sub MY::post_constants {
	'
LIBOBJS = sdbm.o pair.o hash.o
LIBSRCS = sdbm.c pair.c hash.c
HDRS = tune.h sdbm.h pair.h $(PERL_SRC)/config.h

all :: static

static ::	libsdbm.a

libsdbm.a: $(LIBOBJS)
	ar cr libsdbm.a $(LIBOBJS)
	$(RANLIB) libsdbm.a

$(LIBOBJS): $(HDRS)

config ::

lint:
	lint -abchx $(LIBSRCS)
';
}


sub MY::realclean {
	'
realclean :: clean
	rm -f Makefile
';
}


sub MY::postamble {
	'
sdbm.o : sdbm.c $(PERL_SRC)/config.h sdbm.h tune.h pair.h 
hash.o : hash.c $(PERL_SRC)/config.h sdbm.h 
pair.o : pair.c $(PERL_SRC)/config.h sdbm.h tune.h pair.h 
';
}
