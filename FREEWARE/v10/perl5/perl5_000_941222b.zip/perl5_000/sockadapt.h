/*  sockadapt.h
 *
 *  Authors: Charles Bailey  bailey@genetics.upenn.edu
 *           David Denholm  denholm@conmat.phys.soton.ac.uk
 *  Last Revised: 08-Nov-1994
 *
 *  This file should include any other header files and procide any
 *  declarations, typedefs, and prototypes needed by perl for TCP/IP
 *  operations.
 *
 *  This version is set up for perl5 with socketshr 0.9C TCP/IP support.
 */

#include <socketshr.h>

/* we may not have netdb.h etc, so lets just do this here  - div */
/* socketshr.h takes care of the rest */
/* no harm doing this for all .c files - needed only by pp_sys.c */

struct netent {
	char *n_name;
	char **n_aliases;
	int n_addrtype;
	long n_net;
};
