/* $Id: copyright.h,v 1.1 1994/01/24 14:31:16 spb Rel spb $ */
/*

Copyright 1994 by the Stephen Booth, the University of Edinburgh

Permission to use, copy, modify, distribute, and sell this software and its
documentation for any purpose is hereby granted without fee, provided that
the above copyright notice appear in all copies and that both that
copyright notice and this permission notice appear in supporting
documentation, and that the name of the author not be used in advertising or
publicity pertaining to distribution of the software without specific,
written prior permission. The author makes no representations about the
suitability of this software for any purpose.  It is provided "as is"
without express or implied warranty.

*/
