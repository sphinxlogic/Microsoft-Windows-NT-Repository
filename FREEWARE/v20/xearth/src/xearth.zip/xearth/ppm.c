/*
 * ppm.c
 * kirk johnson
 * july 1993
 *
 * RCS $Id: ppm.c,v 1.1 1993/07/19 10:32:22 tuna Exp $
 *
 * Copyright 1993 by Kirk Lauritz Johnson (see the included file
 * "kljcpyrt.h" for complete copyright information)
 */

#include "xearth.h"
#include "kljcpyrt.h"

static FILE  *outs;
static int    bytes_per_row;


void ppm_setup(s)
     FILE *s;
{
  outs          = s;
  bytes_per_row = wdth * 3;

  fprintf(outs, "P6\n%d %d\n255\n", wdth, hght);
}


void ppm_row(row)
     uchar *row;
{
  assert(fwrite(row, 1, bytes_per_row, outs) == bytes_per_row);
}
