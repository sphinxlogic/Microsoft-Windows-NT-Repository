static char *screensaver_id =
	"@(#)xscreensaver 1.24.2(VMS), by Jamie Zawinski (jwz@mcom.com)";
