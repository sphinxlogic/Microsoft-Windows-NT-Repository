static char *screensaver_id =
	"@(#)xscreensaver 1.24, by Jamie Zawinski (jwz@mcom.com)";
