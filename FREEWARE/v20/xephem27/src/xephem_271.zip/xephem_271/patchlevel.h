/* this string constant defines the current version of xephem.
 * it is used by versionmenu.c to display the version in the Intro banner.
 */

#define	PATCHLEVEL	"Version 2.7.1, 21 August 1995"
