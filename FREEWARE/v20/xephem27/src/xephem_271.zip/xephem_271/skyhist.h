/* include file to hook skyviewmenu.c and skyhist.c together.
 * we are just trying this split to keep skyviewmenu.c from growing endlessly.
 */


/* history record */
typedef struct {
    double fov;           /* sv_fov value */
    double azra;          /* sv_azra value */
    double altdec;        /* sv_altdec value */
    int aa_mode;          /* aa_mode value */
} SvHistory;


/* skyviewmenu.c */
extern void svh_goto P_((SvHistory *hp));
extern void svh_get P_((SvHistory *hp));


/* skyaux.c */
extern void svh_create P_((Widget mb));
