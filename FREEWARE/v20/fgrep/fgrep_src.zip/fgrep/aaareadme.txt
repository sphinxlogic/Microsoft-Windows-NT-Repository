GNU fgrep v1.1  -  Search a file for a pattern

This version of GNU fgrep v1.1 was taken via anonymous ftp from
prep.ai.mit.edu and modified to run under VMS.  It compiles under
VMS using GNU C or VAX C and was tested with GNU C v1.39.1 and
VAX C v3.1 under VMS v5.4-2.

Ported to run under OpenVMS AXP on July 3, 1993.  Tested with DEC C V1.3
and OpenVMS AXP V1.5.

As supplied, VMSMAKE.COM also compiles SHELL_MUNG.C, which will allow
fgrep to handle wildcarded file specs and some redirection.

To install:

	$ @VMSMAKE.COM
	$ FGREP :== $dev:[dir]FGREP.EXE
	$ LIBRARY/HELP/INSERT library GREP

New to this distribution:

	GETOPT.C		Taken from GNU grep distribution because
				it wasn't in the GNU fgrep distribution
	GREP.RNH		RUNOFF source for on-line VMS help
	SHELL_MUNG.C		Jym Dyer's routine to emulate UNIX shell
	FGREP.C			Modified for VMS
	UNIX.H			Modified for VMS
	STD.H			Modified for VMS
	VMSMAKE.COM		DCL command procedure to build fgrep
	DESCRIP.MMS		MMS procedure to build fgrep

This version of grep also includes a few VMS-specific (bracketed by #ifdef VMS)
changes.  Specifically:

    1.  Added call to shell_mung
    2.  Modified error() so that strerror accepted two arguments
    3.  The exit statuses were changed to better fit VMS:
            Meaning                  UNIX       VMS
            -------                  ----       ---
            matches found               0         1
            no matches found            1         3
            error                       2        44 (SS$_ABORT)
    4.  Modified print_line to use printf when printing lines instead of
        putchar.  Much faster output on VMS.

I also modified SHELL_MUNG.C to allow it to be compiled by GNU C.

Any suggestions/comments/etc. can be sent to the address below.

Hunter Goatley, VAX Systems Programmer      E-mail: goathunter@WKUVX1.BITNET
Academic Computing, STH 226                 Voice:  (502) 745-5251
Western Kentucky University
Bowling Green, KY 42101
