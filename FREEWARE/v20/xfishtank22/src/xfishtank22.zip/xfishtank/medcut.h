
struct colr_data {
	int red, green, blue;
};

extern void MedianCount();
extern void MedianSplit();
extern void ConvertColor();
