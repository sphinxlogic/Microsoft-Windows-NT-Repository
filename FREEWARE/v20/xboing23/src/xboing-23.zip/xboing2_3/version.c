char *dateString = "Sat Feb 18 17:10:04 CET DST 1995";
char *whoString = "Pmoreau";
char *machineString = "OpenVMS_VAX on SUBVAX  V6.0 VAXstation_4000-60 VAX";
int buildNum = 0;
