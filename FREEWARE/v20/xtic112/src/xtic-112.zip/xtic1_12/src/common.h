#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

#define min(A,B) ((A)<(B)? (A):(B))
#define max(A,B) ((A)>(B)? (A):(B))
#define NPROPERTIES 4
#define BOARDLENGTH 4
#define BOARDSIZE ((BOARDLENGTH)*(BOARDLENGTH))
#define NPIECEPOS (BOARDSIZE)
#define VALPOS (NPIECEPOS+1)
#define FULLBOARDSIZE (BOARDSIZE+2)
#define NPIECES 16  /* 2^NPROPERITES */
#define NPROPPOS (NPIECES)
#define NPIECESIZE (NPIECES+2*NPROPERTIES)
#define NPIECE 1  /* how many of a kind? */ 
#define NGAMETYPES 3
#define NLEVELS 6
#define INFINITY 100000

long endgame();
int selpospiece(int piece,int* outpiece, int* outpos);
void addpiece(int piece, int pos);
void removepiece(int piece, int pos);
int boardval();
 
int board[FULLBOARDSIZE];
int npiece[NPIECESIZE];

int pivotpos[BOARDSIZE];
int pivotpiece[NPIECES];
enum {NORMAL,NODIAGS,TORUS} gametype;
enum {SELPIECE,SELPOS,ENDGAME} gamestatus;
enum {HUMAN,COMPUTER} firstplayer;
