static String fallback_resources[] = {
  "*posB1.fromHoriz:	posA1",
  "*posC1.fromHoriz:	posB1",
  "*posD1.fromHoriz:	posC1",
  "*posB2.fromHoriz:	posA2",
  "*posC2.fromHoriz:	posB2",
  "*posD2.fromHoriz:	posC2",
  "*posB3.fromHoriz:	posA3",
  "*posC3.fromHoriz:	posB3",
  "*posD3.fromHoriz:	posC3",
  "*posB4.fromHoriz:	posA4",
  "*posC4.fromHoriz:	posB4",
  "*posD4.fromHoriz:	posC4",
  "*posA2.fromVert:	posA1",
  "*posB2.fromVert:	posB1",
  "*posC2.fromVert:	posC1",
  "*posD2.fromVert:	posD1",
  "*posA3.fromVert:	posA2",
  "*posB3.fromVert:	posB2",
  "*posC3.fromVert:	posC2",
  "*posD3.fromVert:	posD2",
  "*posA4.fromVert:	posA3",
  "*posB4.fromVert:	posB3",
  "*posC4.fromVert:	posC3",
  "*posD4.fromVert:	posD3",
  "*piece1.fromHoriz:	piece0",
  "*piece2.fromHoriz:	piece1",
  "*piece3.fromHoriz:	piece2",
  "*piece5.fromHoriz:	piece4",
  "*piece6.fromHoriz:	piece5",
  "*piece7.fromHoriz:	piece6",
  "*piece9.fromHoriz:	piece8",
  "*piece10.fromHoriz:	piece9",
  "*piece11.fromHoriz:	piece10",
  "*piece13.fromHoriz:	piece12",
  "*piece14.fromHoriz:	piece13",
  "*piece15.fromHoriz:	piece14",
  "*piece4.fromVert:	piece0",
  "*piece5.fromVert:	piece1",
  "*piece6.fromVert:	piece2",
  "*piece7.fromVert:	piece3",
  "*piece8.fromVert:	piece4",
  "*piece9.fromVert:	piece5",
  "*piece10.fromVert:	piece6",
  "*piece11.fromVert:	piece7",
  "*piece12.fromVert:	piece8",
  "*piece13.fromVert:	piece9",
  "*piece14.fromVert:	piece10",
  "*piece15.fromVert:	piece11",
  "xtic.geometry:	200x520",
  "xtic.maxHeight: 520",
  "xtic.minHeight: 520",
  "xtic.maxWidth: 200",
  "xtic.minWidth: 200",
  "*background:	Grey",
  "*Command.width:		40",
  "*Command.height:	40",
  "*Command.background:	White",
  "*Command.highlightThickness:	2",
  "*Command.borderWidth:	1",
  "*menubox.borderWidth:	0",
  "*menubox.width:		180",
  "*MenuButton.width:	60",
  "*MenuButton.height:	20",
  "*MenuButton.menu.quit.label:	Quit",
  "*MenuButton.menu.restart_human.label:        New game: You start",
  "*MenuButton.menu.restart_computer.label:	New game: I start",
  "*messageform.borderWidth:	0",
  "*messagetext.width:	180",
  "*cursorName:	top_left_arrow",
  NULL
};

  static char* level_name[] = {
    "level1","level2","level3","level4","level5","level6"};
  static char* level_label[] = {
    "  Level: trivial",
    "  Level: easy",
    "  Level: medium",
    "  Level: hard",
    "  Level: very hard",
    "  Level: don't try"};
  static char* chosen_level_label[] = {
    "x Level: trivial",
    "x Level: easy",
    "x Level: medium",
    "x Level: hard",
    "x Level: very hard",
    "x Level: don't try"};

  static char* gametype_name[] = {
    "gamenormal","gamenodiags","gametorus"};
  static char* gametype_label[] = {
    "  Game Type: Normal",
    "  Game Type: Nodiags",
    "  Game Type: Torus"};
  static char* chosen_gametype_label[] = {
    "x Game Type: Normal",
    "x Game Type: Nodiags",
    "x Game Type: Torus"};

  static char* pos_name[] = {
    "posA1", "posB1", "posC1", "posD1",
    "posA2", "posB2", "posC2", "posD2",
    "posA3", "posB3", "posC3", "posD3",
    "posA4", "posB4", "posC4", "posD4"
  };

  static char* piece_name[] = {
    "piece0","piece1","piece2","piece3",
    "piece4","piece5","piece6","piece7",
    "piece8","piece9","piece10","piece11",
    "piece12","piece13","piece14","piece15"
  };

typedef struct {
  int posno;
  int* outpiece;
} *PosPtr,PosData;

typedef struct {
  int pieceno;
  int* outpiece;
} *PiecePtr,PieceData;

typedef struct {
  int level;
} *LevelPtr,LevelData ;

typedef struct {
  int gametype;
} *GametypePtr,GametypeData;


