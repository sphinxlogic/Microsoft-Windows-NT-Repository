#include "common.h"

static void sppmax(int piece, int* maxval, int refminval, int depth);
static void sppmin(int piece, int* minval, int refmaxval, int depth);
extern int maxdepth;
