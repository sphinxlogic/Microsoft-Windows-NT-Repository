/* If you want Imake to leave your binary in the standard place where
 * Imake wants to leave binaries, then leave the two lines below as shown.
 * If you want to install it in a different directory, uncomment and
 * edit the first line and comment the second.Beware that you may 
 * run into problem if your preferred directory does not exist and 
 * you try to execute "make install" */

#define XTIC_BIN_DIR
/* #define XTIC_BIN_DIR BINDIR=/home/mjo/local/bin */

/* Compiler over-ride for Imakefiles.
 * Leave it as shown to get your default compiler.
 * Uncomment the second line (and change it) 
 * to use another compiler (gcc in this case). Doing so
 * may cause some trouble! */

#define COMPILER
/*#define COMPILER CC=gcc*/

/*  Linker flags needed to locate and link in the Xpm library
 *  Change this to the correct place, if needed */

#define XPMLIBRARY -L/usr/local/lib -lXpm
