#define PDSFIXED	(1)
#define	PDSVARIABLE	(2)
#define PDSTRASH	(-1)
#define VICAR		(3)

