/* net.h
 *
 * includes, definitions and external variables needed, by net.c
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <unistd.h>

#include "netprotos.h"

#define NET_PORT 6789			/* port for transmission */

#ifndef VMS
extern int errno;
#else
#include <errno.h>
#endif /* VMS */

