#define FILENAME           13
#define TITLE              27
#define PHONE              26
#define LISTSTR            20

typedef struct tagSESSION
{
    char      szTitle[TITLE];
    char      szPhone[PHONE];
    int       iProtocol;
    char      szScript[FILENAME];
} SESSION;

typedef struct tagPORT
{
    int       iComPort;
    int       iBaudRate;
    int       iFlowCtl;
    int       iParity;
    int       iDataBits;
    int       iStopBits;
} PORT;

typedef struct tagTERMINAL
{
    int       iTerminal;
    int       iFontSize;
    int       iCaret;
    int       iBufLines;
    int       iRows;
    int       iCols;
    long      crFore;
    long      crBack;
    int      bCRLF;
    int      bEcho;
    int      bColors;
    char      szFont[LISTSTR];
} TERMINAL;

typedef struct tagDIR
{
    SESSION     Session;
    PORT        Port;
    TERMINAL    Terminal;
} DIR;

