#define _CLIENT_C
//----------------------------------------------------------------- 
// CLIENT.C - MDI Client window management. 
// 
// MAKEMDI adaptation of Windows 3.1 SDK MAKEAPP system. 
// 
// MDI application design based on Chapter 7 of	 
// "Windows 3: A Developer's Guide" by Jeffrey Richter. 
// 
// Adaptation developed with permission of the author by  
// John F. Holliday, Technisoft Corporation 
// Telephone: (515) 472-9803, CompuServe: 71271,634 
//
// [DMM]	25-Nov-1992: Fixed crashing on exit
//			Also tabified file to tabsize of 4
//
//			David M. Miller, Business Visions, Inc.
//			Telephone: (212) 747-6118
//			CompuServe: 72676,327
//			internet: dmiller@hera.sbi.com
// 
// NOTES:	The MDI client manages any number of MDI child windows. 
// These routines are written to manage all available child 
// window classes and created instances. 
//----------------------------------------------------------------- 
#include "makemdi.h"



BOOL Client_Initialize(APP * papp)
//----------------------------------------------------------------- 
// Initialize all MDI child window classes. 
//----------------------------------------------------------------- 
{
	if (!Sheet_Initialize(papp))
		return 0;
	if (!Chart_Initialize(papp))
		return 0;
	return TRUE;
}



void Client_Terminate(APP * papp)
{
}
