/*
 * July 5, 1991
 * Copyright 1991 Lance Norskog And Sundry Contributors
 * This source code is freely redistributable and may be used for
 * any purpose.  This copyright notice must be maintained. 
 * Lance Norskog And Sundry Contributors are not responsible for 
 * the consequences of using this software.
 */

/*
 * Sound Tools miscellaneous stuff.
 */

char *sizes[] = {
	"NONSENSE!",
	"bytes",
	"shorts",
	"longs",
	"32-bit floats",
	"64-bit floats",
	"IEEE floats"
};

char *styles[] = {
	"NONSENSE!",
	"unsigned",
	"signed (2's complement)",
	"u-law",
	"a-law"
};

char readerr[] = "Premature EOF while reading sample file.";
char writerr[] = "Error writing sample file.  You are probably out of disk space.";

#include "st.h"

/* Utilities */

/* Read short, little-endian: little end first. VAX/386 style. */
unsigned short
rlshort(ft)
ft_t ft;
{
	unsigned char uc, uc2;
	uc  = getc(ft->fp);
	uc2 = getc(ft->fp);
	return (uc2 << 8) | uc;
}

/* Read short, bigendian: big first. 68000/SPARC style. */
unsigned short
rbshort(ft)
ft_t ft;
{
	unsigned char uc, uc2;
	uc2 = getc(ft->fp);
	uc  = getc(ft->fp);
	return (uc2 << 8) | uc;
}

/* Write short, little-endian: little end first. VAX/386 style. */
unsigned short
wlshort(ft, us)
ft_t ft;
unsigned int us;
{
	putc(us, ft->fp);
	putc(us >> 8, ft->fp);
	if (ferror(ft->fp))
		fail(writerr);
}

/* Write short, big-endian: big end first. 68000/SPARC style. */
unsigned short
wbshort(ft, us)
ft_t ft;
unsigned int us;
{
	putc(us >> 8, ft->fp);
	putc(us, ft->fp);
	if (ferror(ft->fp))
		fail(writerr);
}

/* Read long, little-endian: little end first. VAX/386 style. */
unsigned long
rllong(ft)
ft_t ft;
{
	unsigned char uc, uc2, uc3, uc4;
/*	if (feof(ft->fp))
		fail(readerr);		/* No worky! */
	uc  = getc(ft->fp);
	uc2 = getc(ft->fp);
	uc3 = getc(ft->fp);
	uc4 = getc(ft->fp);
	return ((long)uc4 << 24) | ((long)uc3 << 16) | ((long)uc2 << 8) | (long)uc;
}

/* Read long, bigendian: big first. 68000/SPARC style. */
unsigned long
rblong(ft)
ft_t ft;
{
	unsigned char uc, uc2, uc3, uc4;
/*	if (feof(ft->fp))
		fail(readerr);		/* No worky! */
	uc  = getc(ft->fp);
	uc2 = getc(ft->fp);
	uc3 = getc(ft->fp);
	uc4 = getc(ft->fp);
	return ((long)uc << 24) | ((long)uc2 << 16) | ((long)uc3 << 8) | (long)uc4;
}

/* Write long, little-endian: little end first. VAX/386 style. */
unsigned long
wllong(ft, ul)
ft_t ft;
unsigned long ul;
{
int datum;

	datum = (ul) & 0xff;
	putc(datum, ft->fp);
	datum = (ul >> 8) & 0xff;
	putc(datum, ft->fp);
	datum = (ul >> 16) & 0xff;
	putc(datum, ft->fp);
	datum = (ul >> 24) & 0xff;
	putc(datum, ft->fp);
	if (ferror(ft->fp))
		fail(writerr);
}

/* Write long, big-endian: big end first. 68000/SPARC style. */
unsigned long
wblong(ft, ul)
ft_t ft;
unsigned long ul;
{
int datum;

	datum = (ul >> 24) & 0xff;
	putc(datum, ft->fp);
	datum = (ul >> 16) & 0xff;
	putc(datum, ft->fp);
	datum = (ul >> 8) & 0xff;
	putc(datum, ft->fp);
	datum = (ul) & 0xff;
	putc(datum, ft->fp);
	if (ferror(ft->fp))
		fail(writerr);
}

/* Read and write words and longs in "machine format".  Swap if indicated. */

/* Read short. */
unsigned short
rshort(ft)
ft_t ft;
{
	unsigned short us;

/*	if (feof(ft->fp))
		fail(readerr);		/* No worky! */
	fread(&us, 2, 1, ft->fp);
	if (ft->swap)
		us = swapw(us);
	return us;
}

/* Write short. */
unsigned short
wshort(ft, ui)
ft_t ft;
unsigned int ui;
{
	unsigned short us;
	us = ui;
	if (ft->swap)
		us = swapw(us);
	if (fwrite(&us, 2, 1, ft->fp) != 1)
		fail(writerr);
}

/* Read long. */
unsigned long
rlong(ft)
ft_t ft;
{
	unsigned long ul;

/*	if (feof(ft->fp))
		fail(readerr);		/* No worky! */
	fread(&ul, 4, 1, ft->fp);
	if (ft->swap)
		ul = swapl(ul);
	return ul;
}

/* Write long. */
unsigned long
wlong(ft, ul)
ft_t ft;
unsigned long ul;
{
	if (ft->swap)
		ul = swapl(ul);
	if (fwrite(&ul, 4, 1, ft->fp) != 1)
		fail(writerr);
}

/* Read a binary double float */
double
rdouble(ft)
ft_t ft;
{
	double d;
	        	
	fread(&d,sizeof(d),1,ft->fp);
	return d;
}

/* Write a binary double float */
double
wdouble(ft,d)
ft_t ft;
double d;
{	
	if (fwrite(&d,sizeof(double),1,ft->fp) != 1)
		fail(writerr);
}

/* Convert an unsigned 8-bit value stored as a double
   to a signed long value by shifting left 24
   bits and xor'ing the MSB */
long
dbl_to_ub(d)
double d;
{
	return LEFT((long)((char) d),24) ^ 0x80000000L;
}

/* Convert a signed 8-bit value stored as a double
   to a signed long value by shifting left 24 bits */
long
dbl_to_sb(d)
double d;        	
{
	/* returns a signed byte from d, left shifted */
	return LEFT((long)((char) d),24);
}


/* Convert an unsigned 16-bit value stored as a double
   to a signed long value by shifting left 16 bits */
long
dbl_to_us(d)
double d;
{
        return LEFT(((long) d) ,16);       
}

/* Convert a signed 16-bit value stored as a double to
   a signed long value by shifting left 16 bits and
   xor'ing the MSG */
long
dbl_to_ss(d)
double d;
{
	return LEFT((long) d,16) ^ 0x80000000L;
}

/* Convert an unsigned byte value stored as a signed long
   to a double value by right shifting 24 bits and xor'ing
   the MSB */
double
ub_to_dbl(ub)
unsigned long ub;
{
	return (double) (RIGHT(ub,24)^0x80);
}

/* Convert a signed by value stored as a signed long
   to a double value by right shifting 24 bits */
double
sb_to_dbl(sb)
unsigned long sb;        	
{
	return (double) RIGHT((signed long) sb,24);
}


/* Convert an unsigned 16-bit value stored as a signed
   long to a double value by right-shifting 16 bits */
double
us_to_dbl(us)
unsigned long us;
{
	return (double) (RIGHT(us,16));
}

/* Convert a signed 16-bit value stored as a signed long
   to a double value by right-shifting 16 bits and xor'ing
   the MSB */
double
ss_to_dbl(ss)
unsigned long ss;
{
	return (double) ((signed int)(RIGHT(ss,16) ^ 0x8000));
}

/* Byte swappers */

unsigned short
swapw(us)
unsigned int us;
{
	return ((us >> 8) | (us << 8)) & 0xffff;
}

unsigned long
swapl(ul)
unsigned long ul;
{
	return (ul >> 24) | ((ul >> 8) & 0xff00) | ((ul << 8) & 0xff0000) | (ul << 24);
}

/* dummy routine for do-nothing functions */
int nothing() {;}

/* dummy drain routine for effects */
null_drain(effp, obuf, osamp)
eff_t effp;
long *obuf;
long *osamp;
{
	*osamp = 0;
}

/* here for linear interp.  might be useful for other things */
gcd(a, b) 
long a, b;
{
	if (b == 0)
		return a;
	else
		return gcd(b, a % b);
}

lcm(a, b) 
long a, b;
{
	int m;

	return (a * b) / gcd(a, b);
}

/* sine wave gen should be here, also */
